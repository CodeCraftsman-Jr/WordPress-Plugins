=== Plugin Name ===
Contributors: louyx
Author URL: http://louyblog.wordpress.com/
Plugin URL: http://l0uy.wordpress.com/teg/extended-recent-comments/
Tags: widget, recent, comments, extended, comment, extended-recent-comments
Requires at least: 2.9
Tested up to: 3.0
Stable tag: 1.2

Add a recent comments widget that shows Gravatars.

== Description ==

This plugin adds a new widget that displays recent comments with the author avatar.

== Changelog ==

= 1.2 =
* Adding French language translation (thanks Devil505 ^.^)

= 1.1 =
* Adding Arabic language translation

= 1.0 =
* Initial release

== Installation ==

1. Download the plugin, unzip it and upload it to `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. Go to Appreaance &raquo; Widgets and add the 'Extended Recent Comments'.
