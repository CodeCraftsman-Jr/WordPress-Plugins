=== Plugin Name ===
Contributors: hthoene
Donate link: 
Tags: unit converter, construction, calculator
Requires at least: 2.1
Tested up to: 2.9
Stable tag: 1.1

This unit converter provides your visitos with an easy to use tool to convert units like area, length, mass etc. Several units are specific for the Construction and wood working industry.

== Description ==

This is a simple little widget to convert between multiple units. 
Currently the supported unit categories are

* Area

* Length

* Mass

* Temperature

* Volume Liquid

* Volume Solid


Conversion is done as the user enters numbers in real time.

This converter is provided for free by http://ecolog-homes.com . If you install it on your website or blog, please keep the small reference to our website in the footer.


== Installation ==

Installation is done the usual way:

1. Upload files to you /wp-content/plugins/ directory (preserve sub-directory structure if appliccable)

2. Activate the plugin through the 'Plugins' menu in WordPress


== Changelog ==

= 1.0 =
* First version
