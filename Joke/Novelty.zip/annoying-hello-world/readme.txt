=== Annoying Hello World ===
Contributors: Boolex.com
Tags: annoying, hello, world, hello world, troll
Requires at least: 3.5
Stable tag: 0.1
License: GPLv2 or later

Annoyingly adds "Hello World" every post created!

== Description ==

Annoyingly adds "Hello World" every post created!

== Installation ==

Upload the "Annoying Hello World" plugin to your blog, Activate it.

1, 2, 3: You're done!


== Changelog ==

= 0.1 =
*Release Date - 25th June, 2015*

* Annoyingly adds "Hello World" every post created!