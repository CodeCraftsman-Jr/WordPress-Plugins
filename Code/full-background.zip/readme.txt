=== Full Background ===
Contributors: Alobaidi
Donate link: http://j.mp/WPTime_donations
Tags: image background, background image, responsive, full background, responsive background, full, background, option, options, retina, rtl, random, random background, rotate background, rotate, rotating, easy, unlimited, rotator, widget, Post, plugin, admin, posts, sidebar, google, twitter, images, comments, page, shortcode, image
Requires at least: 3.1
Tested up to: 4.3.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add responsive full background to your website easily, random background support and unlimited backgrounds, compatible with all major browsers.

== Description ==

### Full Background 

Add responsive full background to your website easily, random background support and unlimited backgrounds, compatible with all major browsers and with phone and tablet.

### Features

1. Responsive.
2. Compatible with all major browsers and with phone and tablet.
3. Random background support and unlimited backgrounds.
4. Easy to use, one option only.

### Live Demo 

* [http://wp-plugins.in/wordpress-background-image](http://wp-plugins.in/wordpress-background-image)

### Rate The Plugin

* [Please rate Responsive Full Background plugin](https://wordpress.org/support/view/plugin-reviews/full-background#postform)

### See Also

* [Collection of 87 themes for $69 only.](http://j.mp/ET_WPTime)
* [Premium WordPress themes on Creative Market.](http://j.mp/CM_WPTime)
* [Premium WordPress themes on Themeforest.](http://j.mp/TF_WPTime)
* [Premium WordPress plugins on Codecanyon.](http://j.mp/CC_WPTime)

### More Plugins

* [My Plugins](https://profiles.wordpress.org/alobaidi#content-plugins)

== Installation ==

1. Upload 'full-background' folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Plugins menu > Full Background.
4. In "Backgrounds Links" field, enter list of backgrounds links, one link per line, will be display random background, but if you want one background only, enter one link only.

For more info, [Read this article](http://wp-plugins.in/wordpress-background-image).

== Frequently Asked Questions ==

* For more info, [Read this article](http://wp-plugins.in/wordpress-background-image).
* [For more questions or help, contact me.](http://wp-plugins.in/1XnA5Qr)
* [Or ask me on twitter.](http://wp-plugins.in/1L6zCZL)

== Changelog ==

= 1.0.1 =

1. Fixing background position if user is logged in.
2. Random background support.

### Usage

1. After update, go to Plugins menu > Full Background.
2. You will find new field "Backgrounds Links".
3. In "Backgrounds Links" field, enter list of backgrounds links, one link per line, will be display random background, but if you want one background only, enter one link only.

[Read about this update](http://wp-plugins.in/wordpress-background-image)

= 1.0.0 =

* First version.

== Upgrade Notice ==

Currently not available.