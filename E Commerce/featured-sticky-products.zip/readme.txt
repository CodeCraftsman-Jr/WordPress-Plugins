=== Featured-sticky-products ===
Contributors: Dan Milward, Tom Howard, Jeffry Ghazally, 
Donate link: http://www.instinct.co.nz/e-commerce
Tags: e-commerce, shop, cart, featured product,featured,sticky product, ecommerce 
Requires at least: 2.9
Tested up to: 2.9
Stable tag: 0.1

Featured Sticky Products is a Featured Products upgrade to the Wp-e-Commerce Plugin

== Description ==

The Featured sticky product plugin allows users to select (using a gmail-like star system) on the edit-products page which will then display a larger view of the selected product on the products pages.

If you have more than one featured product it will choose one randomly. 
If you are on a category page it will show only featured products from that selected category.

== Installation ==

1. Upload the folder 'featured-sticky-products' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

= Upgrade Notice =

Simply copy the new files across and replace the old files saving the ones you've modified.

If you experience database errors try de-activating and re-activating your plugin. 



== Readme Validator ==

This readme was made using:
wordpress.org/extend/plugins/about/validator/

Totally totally cool tool!!
