=== Plugin Name ===
Contributors: ggggqqqqihc
Tags: image, post, flickr
Requires at least: 2.0
Tested up to: 3.1
Stable tag: 0.1

Flickr Over GFW is a plugin for people where flickr's image library is blocked. With this plugin, you can link any image from flickr freely and your visitors can see them.

== Description ==

GFW stands for 'Great Fire Wall'. It is used for blocking some websites (like flickr.com) from China mainland. So people in China cannot see any pictures of flickr. This plugin will grab the pictures from flickr image library by your web server. So you need a web server that located in which flickr isn't blocked, for example, US.

== Requirements ==

* A web server that can visit flickr's libraries directly
* 'allow_url_fopen' of php.ini should be "1".