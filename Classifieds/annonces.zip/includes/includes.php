<?php

	require_once(ANNONCES_LIB_PLUGIN_DIR. 'sfform/require_once.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_passerelle.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_annonces.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_attributs.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_attributs_group.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_filters.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_export.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'Zip/Zip.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'Ftp/Ftp.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'eav.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'gmap.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'photo.class.php');

	require_once(ANNONCES_LIB_PLUGIN_DIR. 'displayDesign.class.php');

	require_once(ANNONCES_LIB_PLUGIN_DIR. 'options.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_annonces.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'admin_attributs.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'eav.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'frontend.class.php');
	require_once(ANNONCES_LIB_PLUGIN_DIR. 'installation.class.php');