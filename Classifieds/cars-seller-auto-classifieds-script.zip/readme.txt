=== Car Seller - Auto Classifieds Script   ===
Contributors: arunkushwaha87
Donate link: http://www.supportlive24x7.com/index.php/pay-now?secure_payment=VWoxZzJWYnM0NVR2dzZtQ2xFakxYQT09
Tags: Car, Car Sale, Car Seller, Car Dealer, Auto car, Auto Classifieds Script, Bootstrap, Responsive 
Requires at least: 3.0.1
Tested up to: 4.3.1
Stable tag: 2.1.0
License: Apache License v2.0
License URI: http://www.apache.org/licenses/LICENSE-2.0.html


Car Dealers Auto Classifieds Script plugin is completely designed to build rich features car classifieds websites with ease.
== Description ==


<a href="mailto:arunkushwaha87@gmail.com">Please write me for Pro version.</a>
Car Dealers Auto Classifieds Script plugin is completely designed for car sellers to build rich features in car classifieds websites with ease.



Car Dealers - Auto Classifieds Script plugin is designed for Car Dealers looking for a powerful and inexpensive tool to manage their vehicles. 

This plugin is an absolute solution for car dealership or car classified websites. It provides car dealers with an Admin Panel that gives full control over the content and car listing. 

The plugin has been designed with the interfaces to help users to use the application with ease and this script is user friendly and fully functional.


Since Car Dealers - Auto Classifieds Script is a WordPress Plugin you can leverage all the power of WordPress to make your site stand out from the rest.

New Features added:- 

1. New look with responsive design.
2. Bootstrap js and css.
3. Bootstrap responsive image slider for every added listing.
4. New location field added with google map API integrated.
5. Search form with fields such as name, category, model and price. Your visitors will be able to use the search form to find the vehicles that most interest them.

Main features:-

1. Online Request form for more information. 
2. You can select the currency according to the location. 
3. You can upload the image slider and other specifications for each car. 
4. You can show the list of categories in the widget position using "Car seller category list widget".
5. Easy to Use Admin Area. Admin can add and remove vehicles, upload photos & change prices with ease.
6. Fast Load Times. The plugin is optimized to load fast, helping to reduce visitor bounce rates.
7. The design and functionality is fully responsive.

<code>[latest_cars number_of_cars_to_show]

Use this shortcode to show the latest cars

example:
[latest_cars 5]
</code>

Also you can show the list of category on widget position using "Car seller category list widget".



For more feature and support please write me at arunkushwaha87@gmail.com, ping me on skype: arunkushwah87 or visit http://www.supportlive24x7.com

== Installation ==

Here's how to install the plugin:

= Using The WordPress Dashboard =
1. Go to the admin area and navigate to the 'Add New' in the plugins menu
2. Navigate to the 'Upload Plugin' area
3. Select "car-seller-auto-classified-script.zip" from your computer
4. Click 'Install Now'
5. Activate the plugin

OR Using FTP

1. Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation
2. Activate the plugin from Plugins page


Go to your admin area and expand the menu for "Carsellers" and click on "Settings". Adjust your settings as desired.

You're now ready to start adding vehicles to your site. 

Click on "Car categories" listed under "Carsellers" to add new category.

Click on "Add New Car" listed under "Carsellers" to add new vehicle.


<code>[latest_cars number_of_cars_to_show]

Use this shortcode to show the latest cars

example:
[latest_cars 5]
</code>



== Frequently Asked Questions ==
For more feature and support please write me at arunkushwaha87@gmail.com, ping me on skype: arunkushwah87 or visit http://www.supportlive24x7.com


<code>[latest_cars number_of_cars_to_show]

Use this shortcode to show the latest cars

example:
[latest_cars 5]
</code>

Also you can show the list of category on widget position using "Car seller category list widget".


== Screenshots ==
1. `Carseller page`
2. `Carseller detail page`
3. `Full Detail page`
4. `Latest car shortcode view`
5. `Latest carseller sidebar widget`
6. `Admin view for latest carseller sidebar widget`
7. `Latest car shortcode zoom view`
8. `Category Links sidebar widget`
9. `Admin view Category Links sidebar widget`
10. `Admin view Search form sidebar widget`
11. `Search form sidebar widget`


== Changelog ==