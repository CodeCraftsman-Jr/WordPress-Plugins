=== Widget Indicadores Económicos para Colombia ===
Contributors: AppLab - Laboratorio de Ideas
Donate link: http://www.applab.in/
Tags: indicador, economico, colombia, dolar, petroleo, euro, dólar, económico
Requires at least: 2.0.2
Tested up to: 3.3.1
Stable tag: 1.0

Widget desarrollado para mostrar los indicadores económicos más relevantes en Colombia.

== Description ==
Este Widget contiene el valor actualizado a pesos colombianos para el Dólar, Euro, Petróleo, Café, entre otros indicadores.

Para ver más Indicadores Económicos, puede visitar nuestro portal http://www.applab.in/

== Installation ==
Esta sección describe como instalar y activar el plugin.

Ejemplo:

1. cargue `applab-indicadoresCO.php` en la carpeta `/wp-content/plugins/applab-indicadores/`

2. Active el plugin a través de la opción 'Plugins' del menu en WordPress

3. En la opción 'Widgets' desplace 'Indicadores Económicos' hacia el área donde lo desea visualizar.

== Frequently Asked Questions ==
= Puedo agregar otros Indicadores? =
En esta versión no es posible, aunque estamos trabajando en ello para las futuras entregas.

== Screenshots ==
1. Área Administrable.
2. Visualización.

== Changelog ==
= 1.0 =
* Título personalizable
* Ajuste de ancho.