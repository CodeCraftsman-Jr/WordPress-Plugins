﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'lv', {
	fontSize: {
		label: 'Izmērs',
		voiceLabel: 'Fonta izmeŗs',
		panelTitle: 'Izmērs'
	},
	label: 'Šrifts',
	panelTitle: 'Šrifts',
	voiceLabel: 'Fonts'
});
