﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'km', {
	fontSize: {
		label: 'ទំហំ',
		voiceLabel: 'Font Size',
		panelTitle: 'ទំហំ'
	},
	label: 'ហ្វុង',
	panelTitle: 'ហ្វុង',
	voiceLabel: 'ហ្វុង'
});
