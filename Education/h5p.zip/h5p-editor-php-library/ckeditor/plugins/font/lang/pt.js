﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'pt', {
	fontSize: {
		label: 'Tamanho',
		voiceLabel: 'Tamanho da Letra',
		panelTitle: 'Tamanho da Letra'
	},
	label: 'Tipo de Letra',
	panelTitle: 'Nome do Tipo de Letra',
	voiceLabel: 'Tipo de Letra'
});
