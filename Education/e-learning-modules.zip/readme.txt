=== e-learning-modules ===
Contributors: peter-g
Version: 1.0.0
Tags: e-learning, modules, knowledge, text, content
Requires at least: 2.5
Tested up to: 2.9
Stable tag: trunk

Sidebar widget that presents every day new lessons, quizes and/or multiple choice questions with the intention to enrich your weblog with pedagogical elements and units of educational material.

== Description ==

Sidebar widget that presents every day new lessons, quizes and/or multiple choice questions with the intention to enrich your weblog with pedagogical elements and units of educational material.

Code and further information will be published in a few days.

== Installation ==

Comming soon ...