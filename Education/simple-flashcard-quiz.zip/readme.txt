=== Simple Flashcard Quiz ===
Contributors: Gero Gothe
Tags: quiz, flashcards
Requires at least: 4.2.1
Tested up to: 4.2
Stable tag: 1.2
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple Flashcards lets you create a simple quiz with questions and awnsers by using shortcode that you include in your page/post.


== Description ==
Simple Flashcards lets you create a simple quiz with questions and awnsers by using shortcode that you include in your page/post.

Usage:
Your Quiz hast to be positioned inside a following shorcode [flashcard] ... [/flashcard]. Questions and awnsers a simply separated by the following tag: [==].

Example:  
[flashcard title="Your Quiz" draft=yes]  
A sample question  
[==]  
A sample awnser  
[==]  
Another question  
[==]  
Another awnser  
[/flashcard]    

That's all. You can add images or anything else wherever you want. Try it out!    

Options:  
* title=Your title  
* draft=yes -> Topic is not yet completed (shows a small message)

== Installation ==
Upload the simple-flashcards directory to your plugins directory ('.../wp-content/plugins').
Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==
1. Integrate Quizzes on any post/page by using shortcode
2. Awnser questions...
3. Assess the awnser
4. Repeat questions


== Changelog ==

= 1.2 =
* Changes in stylesheet
* Added draft=yes (case sensitive) option
* Scrolling to top of flashcard improved

= 1.1 =
Multiple Instances of Flashcards on a page/post implemented

= 1.0 =
Initial WordPress release 2015-05-20

