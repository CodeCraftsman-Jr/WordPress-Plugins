<div class="ib-edu-course-difficulty">
	<span class="label"><?php _e( 'Difficulty:', 'ibeducator' ); ?></span>
	<?php echo esc_html( $difficulty['label'] ); ?>
</div>
