<div class="ib-edu-course-categories">
	<span class="label"><?php _e( 'Categories:', 'ibeducator' ); ?></span>
	<?php echo $categories; ?>
</div>
