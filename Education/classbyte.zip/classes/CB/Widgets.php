<?php
namespace CB;

if (!defined("ABSPATH")) exit;

class Widgets
{
    public function __construct()
    {

    }
}