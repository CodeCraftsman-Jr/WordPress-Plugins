=== Plugin Name ===
Contributors: classbyte
Donate link: http://www.classbyte.com
Tags: CPR Training, ClassByte
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The ClassByte plugin allows you to connect your instance of ClassByte to your WordPress website.

== Description ==

The ClassByte plugin allows you to connect your instance of ClassByte to your WordPress website.

What this Plugin will do

*   Create pages for your students to see what courses you have available
*   Allow your students to sign up for courses and pay
*   Allow your students to see their course history
ble tag should indicate the Subversion "tag" of the latest stable version, or "trunk," if you use `/trunk/` for
stable.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `classbyte.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the new CLASSBYTE menu on your left admin bar
4. Enter your credentials provided by ClassByte

== Frequently Asked Questions ==

= Is ClassByte Free? =

The WordPress plugin is absolutely free. However you must have a functional ClassByte account and ask our sales team to enable the plugin for your account.

= How do I sign up for ClassByte =

Visit us at www.classbyte.com

== Screenshots ==



== Changelog ==

= 1.0 =


= 2.0 =
* Enabled Promo Codes
* Enabled Product Add Ons
* Fixed formatting Issues

= 2.5 =
*Replaced Bootstrap CSS calls with CB Calls to prevent bootstrap based theme conflicts
*Added validate promo code button
*Added email functionality
*Added validate API credentials functionality.


== Upgrade Notice ==





`<?php code(); // goes in backticks ?>`