<div class="wpfooter-banner">
	<a target="_blank" href="http://www.psd2html.com/wordpress-development.html?utm_source=wp-plugin&utm_medium=banner&utm_campaign=guideme">
		<img class="psd2html-banner banner-730x125" src="<?php echo GuideMe::plugin_url() . '/images/banner-580x99.png'; ?>" width="290" alt="psd2html.com" />
	</a>
</div>