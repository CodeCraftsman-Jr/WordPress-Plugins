=== Giornalismo Story Details ===
Contributors: Arena Pigskin
Tags: Giornalismo, custom write panel
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.en.html

Creates a custom write panel for use in the Giornalismo theme.

== Description ==
Adds custom fields for the Giornalismo theme for featured photo credit, caption, featured video link and three story highlights.

== Installation ==
1. In the WordPress dashboard, go to "Plugins" -> "Add New" and search for "Giornalismo Story Details."
2. Click "Install" and activate the plugin.

== Changelog ==
= 1.0 =
- Initial Release