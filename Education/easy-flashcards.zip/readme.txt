=== Easy Flashcards===
Contributors: Sage Sony
Tags: flashcard,flash,card,flip,animation,language,vocabulary,learn,memory
Donate link:
Author URI: https://profiles.wordpress.org/sagesony
Requires at least: 3.7
Tested up to: 4.0
Stable tag: 0.1

Easy Flashcard Plugin allows you to easily create,design and manage flashcards for your wordpress site.

== Description ==

Easy Flashcards is a plugin which allows you to create, design and manage flashcards through your Wordpress dashboard. It allows you to easily add, delete and edit Flashcards.It also allows you to design your own flashcard through the admin panel. On creating, it generates a Shortcode which on putting in any of your posts or pages,displays a wonderful series of flashcards. These flashcards flip to show their backside on mouse hover.

== Installation ==

This plugin follows the [standard WordPress installation method][]:


1. Download the zipped file.
1. Extract and upload the contents of the folder to /wp-contents/plugins/ folder
1. Go to the Plugin management page of WordPress admin section and enable the 'Easy Flashcards' plugin
1. Go to the Easy Flashcards page in wordpress dashboard menu to create or edit the flashcards.
1. Add the shortcode (and any options) [easy_flashcard id=#] to a post to display your flashcards!

[standard WordPress installation method]: http://codex.wordpress.org/Managing_Plugins#Installing_Plugins

== Frequently Asked Questions ==

= How can I create flashcards using Easy Flashcards? =

Just go to 'Dashboard'->'Manage Flashcards'-> 'Manage Flashcards'  to create or edit existing flashcards. Put the generated shortcode [easy_flashcard id=#] in any of your posts or pages to display flashcards.

= How can I change the color or font-size on my flashcards =

Just go to 'Dashboard'->'Manage Flashcards'-> 'Flashcards Settings' to change card width,height,border radius, background color , text color and text size on flashcards


== Screenshots ==

1. Screenshot of Easy Flashcards manage page
2. Screenshot of Easy Flashcards design page
2. Screenshot of Easy Flashcards displayed on web page
2. Screenshot of Easy Flashcards displayed on web page

== Changelog ==

= 0.1 =
Initial release 
