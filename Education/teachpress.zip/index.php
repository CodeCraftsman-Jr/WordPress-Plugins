<?php
/**
 * Leave this file to block unauthorised access to the directory
 * @package teachpress
 * @license http://www.gnu.org/licenses/gpl-2.0.html GPLv2 or later
 * @since 0.4.0
*/
