=== Vocabulary Words ===
Contributors: EdwinHuertas
Donate link: http://www.earlytorise.com/issues/wise/word-definitions/
Tags: vocabulary, dictionary,glossary,words,speech,vocabulary words
Requires at least: 2.0.2
Tested up to: 2.6.1
Stable tag: 1.0

Become a more persuasive writer & speaker ... build your confidence and intellect ...  just by spending 10 VERY enjoyable minutes a day

== Description ==

This widget has been created by Early To Rise; a publishing company dedicated to improving the lives of people all around the world. Early To Rise believes that by improving your vocabulary, you greatly increase the chances of being a successful business person. 

Become a more persuasive writer and speaker ... build your self-confidence and intellect ... increase your attractiveness to others ... just by spending 10 VERY enjoyable minutes a day with ETR's new Words to the Wise.

This widget will display random <a href="http://www.earlytorise.com/issues/wise/word-definitions/" target="_blank">vocabulary words</a> from ETRs Word to the Wise dictionary of success words to your web site visitors.


== Installation ==

1. Upload the Daily-Word folder to your plug-in folder (wp-content\plugins) and activate it from the Plug-in section of your Word Press administration console.
2. Enable the 'widget' using your admin (Design >> Widgets)

You're done!

== Frequently Asked Questions ==

= What is this plugin? =

This plugin will display a 'success' word from ETR's Word To The Wise CD. It will display a new word to each visitor.

= How often do the words change? =

We've set it to refresh and show a new word to every web page visit.

= What is Early To Rise? =

EarlyToRise.Com is an online health and wealth publication. Our mission is to provide important, useful ideas about wealth accumulation and preservation, business success, enhanced productivity, and optimum health � all while offering direction that inspires readers to achieve most any goal set forth.

== Screenshots == 
None
