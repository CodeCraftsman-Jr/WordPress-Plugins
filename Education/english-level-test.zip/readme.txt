=== English Level Test ===
Contributors: NowSquad
Donate link: 
Tags: English level test, e-learning, english, leveltest, tests
Requires at least: 3.3
Tested up to: 3.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Offer your blogs visitors the posibility to take an english level test according to the Common European Framework of Reference levels.

== Description ==

This widget loads an www.englishleveltest.com widget inside an iframe with the theme as a parameter, bright and dark posibilities. Unlike the full www.englishleveltest.com version this one does NOT require any contact information to your visitors. Also a "powered by" link is displayed below the leveltest, it can be disabled from the widget configuration.

== Installation ==

1. Upload `nowlt-widget.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Appearance -> Widgets menu, add it to your desired sidebar position, configure the widget's settings and save.

== Screenshots ==

1. Level test Question.
2. Level test Results.

== Changelog ==

= 1.0.0 =
* Initial commit
= 1.0.1 =
* Fixed bug that pointed to a local url