<?php
Header('HTTP/1.0 403 Forbidden');

/* End of File */