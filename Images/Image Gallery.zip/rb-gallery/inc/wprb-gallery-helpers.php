<?php 

function rb_gallery_albums()
{
    global $wpdb;
    return $wpdb->prefix . "rbgallery_albums";
}




