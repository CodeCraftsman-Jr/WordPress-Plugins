=== Plugin Name ===
Contributors: utsavsinghrathour, codepixelzmedia, vishalbasnet23
Tags: gallery, photo gallery, image gallery, lightbox, shortcode, simple gallery, image slider, picture gallery, add album, add gallery, add picture, add pictures, album, foto, fotoalbum, galery, gallary, gallery, gallery image, image, multiple pictures, photo, photoalbum, photogallery, pictures, slide show, slideshow, upload images, upload photos, view images, website gallery, responsive gallery
Requires at least: 3.9

Tested up to: 4.2.4
Stable tag: 2.2

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add gallery feature to your website. Supports lightbox and shortcodes to display your gallery images anywhere.


== Description ==

Simple Gallery Plugin. Easy to use gallery plugin that lets you add gallery feature to your website. Supports lightbox and shortcodes to display your gallery images anywhere.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `code-gallery` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You are good to go.


== Screenshots ==

1. This shows the default look of the gallery. 
2. Pop up powered by Blueimp.

== Changelog ==

* 1.0: First release.
* 2.0: Major changes. Undefined Variable issue solved. Gallery is now responsive.Layout issues fixed. Border and fixed height removed.
* 2.2: Added shortcode panel for easier copying on the admin post
