<div id="fbg-photos-travel">
  <div class="fbg-slide" id="fbg-slide" style="height: <?php echo $photoHeight ?>px; width: <?php echo $photoWidth ?>px; padding:1px 1px 2px 1px;">

	</div>
</div>
<div style="clear: both"></div>
