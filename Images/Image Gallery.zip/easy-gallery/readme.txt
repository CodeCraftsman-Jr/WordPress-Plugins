=== Plugin Name ===
Contributors: mmenciassi
Tags: gallery, slideshow, carousel
Requires at least: 3.3.1
Tested up to: 3.3.2
Stable tag: 0.3
License: GPLv2

A very easy gallery for your posts, pages and custom posts. Carousel and Slideshow with many jQuery effects and thumbs previews.

== Description ==

This plugin use the jQuery plugin jCycle. Thank's to jCycle **Easy Gallery** is able to override the default standard wordpress gallery and create a gallery with effects.
This will be very easy to do, you need only install and activate this plugin and create and put gallery into your posts, pages or custom posts in the same way you did use untill now. 

== Installation ==

1. Download file `easy-gallery.zip`
2. Uncompress .zip file
3. Upload `/easy-gallery/` folder under the `/wp-content/plugins/` directory
4. Activate the plugin through the 'Plugins' menu in WordPress
5. That's all.

This plugin override your gallery When you'll use wordpress standard gallery [gallery] 

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 0.3 =
Added a default CSS style

= 0.2 =
Added next and previous arrows, add thumbnails previews

= 0.1-alpha =
First version, it works fine but more features needed

== Arbitrary section ==

