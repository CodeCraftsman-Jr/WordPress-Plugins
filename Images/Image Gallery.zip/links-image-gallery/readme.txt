=== Plugin Name ===
Contributors: joelpittet
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=H9WZLAB9A9HC6
Tags:links, link, image, gallery
Requires at least: 2.9
Tested up to: 3.0.1
Stable tag: 1.0

Allows the Links' Advanced Image Address to use the gallery images with the modal

== Description ==

This plugin will extend the Links' Advanced Image Address field to add a Image icon next to it and use the Gallery Modal to choose an image from the gallery and upload new images.


== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Changelog ==

= 1.0 =
* Initial Release


