=== Space gallery ===
Contributors: www.gopiplus.com, gopiplus 
Donate link: http://www.gopiplus.com/work/2010/08/14/space-gallery/
Author URI: http://www.gopiplus.com/work/2010/08/14/space-gallery/
Plugin URI: http://www.gopiplus.com/work/2010/08/14/space-gallery/
Tags: Image, Slideshow, Space, Gallery
Requires at least: 3.4
Tested up to: 4.2.2
Stable tag: 6.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
Want to display images as a slideshow in the page or post? Then use space gallery WordPress plugin.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2010/08/14/space-gallery/](http://www.gopiplus.com/work/2010/08/14/space-gallery/)

*   [Live Demo](http://www.gopiplus.com/work/2010/08/14/space-gallery/)		
*   [More info](http://www.gopiplus.com/work/2010/08/14/space-gallery/)					
*   [Comments/Suggestion](http://www.gopiplus.com/work/2010/08/14/space-gallery/)			
*   [About author](http://www.gopiplus.com/work/)				

Want to display images as a slideshow in the page or post? Then use space gallery WordPress plugin. Its just another image slideshow show gallery. Space Gallery is a JQuery based slideshow plugin that provides smoky out of the fantasy effect to images. Bring in a smooth sliding effect to image views with this wonderful JavaScript slider.

**Plugin configuration**

Short code for pages and posts: Paste the given short code in the posts and pages. the name of the XML file available in the short code.

Add directly in the theme: Use the given PHP code to add the gallery to your theme files directly.
	
== Installation ==	

**Methode 1**

*   Unpack the *.zip file and extract the /space-gallery/ folder.    
*   Drop the 'space-gallery' folder into your 'wp-content/plugins' folder.    
*   In word press administration panels, click on plug-in from the menu. 	  
*   You should see your new 'space-gallery' plug-in listed under Inactive plug-in tab.			
*   To turn the word presses plug-in on, click activate.   
 
**Methode 2**		
		
*	Go to 'add new' menu under 'plugins' tab in your wordpress admin.		
*	Search 'space-gallery' plugin using search option.		
*	Find the plugin & Click 'Install Now' link.		

== Frequently Asked Questions ==

* How to arrange the width & Height of the plug-in?.
* How to arrange border around the image?.
* How to arrange perspective height?.
* How to arrange minimum scale for the image in the back?.
* How to arrange animation duration?.
		
[Answer](http://www.gopiplus.com/work/2010/08/14/space-gallery/)

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2010/08/14/space-gallery/

2. Admin Screen. http://www.gopiplus.com/work/2010/08/14/space-gallery/

== Upgrade Notice ==

= 1.0 =
				
First version

= 2.0 =

a) Only Admin can access this plugin in the admin.
b) Tested UpTo 3.2.1
c) JS Script has been added as per WP standard.

= 3.0 =

Tested upto 3.3

= 4.0 =

Tested upto 3.4
Random disply option disabled
"getting the < character" issue fixed

= 5.0 =

New demo link, www.gopiplus.com

= 5.1 =

Major update
All XML files removed and introduced directory option. from this version onwards gallery images loading from the mentioned directory. in the admin we have option to set the image directory location
Tested up to WordPress 3.5
Avoid registering the alternate jQuery.
From this version we are using existing wordpress jQuery.

= 6.0 =

Tested upto 3.6

= 6.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (space-gallery.po) available in the languages folder.

= 6.2 =

1. Tested up to 3.9

= 6.3 =

1. Tested up to 4.0

= 6.4 =

1. Tested up to 4.1

= 6.5 =

1. Tested up to 4.2.2

== Changelog ==

= 1.0 =		

First version

= 2.0 =

a) Only Admin can access this plugin in the admin.
b) Tested UpTo 3.2.1
c) JS Script has been added as per WP standard.

= 3.0 =

Tested upto 3.3

= 4.0 =

Tested upto 3.4
Random disply option disabled
"getting the < character" issue fixed

= 5.0 =

New demo link, www.gopiplus.com

= 5.1 =

Major update
All XML files removed and introduced directory option. from this version onwards gallery images loading from the mentioned directory. in the admin we have option to set the image directory location
Tested up to WordPress 3.5
Avoid registering the alternate jQuery.
From this version we are using existing wordpress jQuery.

= 6.0 =

Tested upto 3.6

= 6.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (space-gallery.po) available in the languages folder.

= 6.2 =

1. Tested up to 3.9

= 6.3 =

1. Tested up to 4.0

= 6.4 =

1. Tested up to 4.1

= 6.5 =

1. Tested up to 4.2.2