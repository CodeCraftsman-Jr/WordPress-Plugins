=== img.ly gallery ===
Contributors: fisio, pepijnkoning
Donate link: http://fis.io/
Tags: widget, twitter, photos, pictures
Requires at least: 2.2
Tested up to: 2.9.1
Stable tag: trunk,

Display your recent img.ly pictures gallery in a widget.

== Description ==

Display your recent img.ly pictures gallery in a widget. based on My Twitpics plugin by Pepijn Koning.

== Installation ==

1. Upload `imgly-gallery` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Specify Twitter ID and other options in the 'Widgets' control panel in WordPress admin.
4. or, use `<?php imgly_pics($username = fisio, $num = 5); ?>` instead of widgets stuff.

== Frequently Asked Questions ==

== Screenshots ==

1. Drag to use it in the widgets panel

== Changelog ==

== Upgrade Notice ==

== Arbitrary section ==

== A brief Markdown Example ==
