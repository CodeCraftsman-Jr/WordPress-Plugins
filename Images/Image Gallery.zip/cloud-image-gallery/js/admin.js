jQuery(document).ready(function(){
	jQuery('.showColorPicker').wpColorPicker();
})