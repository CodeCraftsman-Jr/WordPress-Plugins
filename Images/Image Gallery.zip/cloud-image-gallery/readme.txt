=== Cloud Image Gallery ===
Contributors: rukon
Tags: gallery, image gallery, plugin, pop-up image gallery, responsive image gallery, image,creative image gallery
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=rukon%2einfo%40gmail%2ecom&lc=US&item_name=Webdeveloper&no_note=0�cy_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Requires at least: 1.0.1
Tested up to: 4.2.1
Stable tag: gallery, image gallery, plugin, pop-up image gallery, responsive image gallery.

Cloud image gallery is nice image gallery plugin.it is full responsive. it has 9 themes , Options page, custom css and more. please visit our demo page.

== Description ==
<h4><a href="http://plugin.digitalbd.net/doc/cloudimagegallery/">Full documentaction here</a></h4>
<h4><a href="http://plugin.digitalbd.net/cloud-image-gallery/">Live Demo</a></h4>
<p>
Cloud image gallery is nice image gallery plugin.it is full responsive. it has 9 themes , Options page, custom css and more. please visit <a href="http://plugin.digitalbd.net/cloud-image-gallery/">our demo page.</a>
</p>

<h4>Features</h4>
<ul>
	<li><strong>Responsive</strong></li>
	<li><strong>9 Themes</strong></li>
	<li><strong>Shortcode</strong></li>
	<li><strong>Shortcode with category selector</strong></li>
	<li><strong>Options page</strong></li>
	<li><strong>full customizable</strong></li>
	<li><strong>Custom css box</strong></li>
	<li><strong>Dragable</strong></li>
	<li><strong>Unlimited Image Upload</strong></li>
	<li><strong>Pop-up Image box with image caption.</strong></li>
	<li><strong>Nice animations</strong></li>
	<li><strong>Auto play image gallery.</strong></li>
</ul>
<hr>
<h4><strong>User By shortcode in your page or post</strong></h4>
<code>
[cigallery] 
</code>
and more..
<a href="http://plugin.digitalbd.net/cloud-image-gallery/">Please visit our demo page.</a>
<h4><a href="http://plugin.digitalbd.net/doc/cloudimagegallery/">Full documentaction here</a></h4>
== Installation ==
 <strong>Installing Through Dashboard:</strong>
 <ol>
 	<li>Go to Plugins -> Add New -> Upload</li>
 	<li>Choose the installable ZIP file (that you have download in your computer from wordpress.org) Upload that file.</li>
 	<li>Now, click on activate link to activate the plugin.</li>
 </ol>
    
    
    

 
<strong>Note : After install complte please go  to the settings menu and click the \"Save\" Button
1 Cloud Gallery > Settings
 </strong>
<strong>Installing Through FTP:</strong>
<ol>
	<li>Extract the installable ZIP file (that you have download in your computer from wordpress.org) Upload the extracted folder into wp-content/plugins directory.</li>
	<li> Activate the plugin through the \'Plugins\' menu in WordPress.</li>
</ol>
    
   

 
Note : After install complte please go  to the settings menu and click the \"Save\" Button
1 Cloud Gallery > Settings

== Screenshots ==
1. Image Gallery
2. Pop-up image/ Full image
3. Setting page/ Options Page

== Changelog ==
1.0.1