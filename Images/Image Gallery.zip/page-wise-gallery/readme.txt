=== Page Wise Gallery ===
Contributors:  Anupa Anand , anandmahalakshmi 
Donate link: http://greenlemon.in/
Tags: gallery, attachement
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Page Wise Gallery Gives you unique gallery for each page/Post.

== Description ==
= Page Wise Gallery =
Page Wise Gallery is a simple and easy plugin for you to create unique gallery for your pages or posts. The plugin automatically creates a gallery for the page or post with the attached images on that page or post. 

You can implement in three ways:

1.Simply add the pwg widget to the sidebar : Where you can set the size of the thumnail

2.-OR- Use the shortcode [pwg_gallery] on your post or page

3.-OR- add <?php echo do_shortcode('[pwg_gallery]'); >? On your page template.

== Installation ==

1. Upload extracted `page-wise-gallery` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the `Plugins` menu in WordPress
3. You are all done

You can now use the widget or the shortcode to implement the Page Wise Gallery


== Frequently Asked Questions ==

= The pop up feature is not working for my page wise gallery =

Please make sure you have installed the Fancy box plugin (https://wordpress.org/plugins/easy-fancybox/)



== Screenshots ==

1. screenshot-1 shows the admin widget area section

2. screenshot-1 shows the front end widget area section

== Changelog ==

= 1.0 =

Initial Version



== Upgrade Notice ==

= 1.0 =
Initial version
