 jQuery(document).ready(function($) {

         /* $('#nrig').bjqs({
            height      : 320,
            width       : 620,
            responsive  : true
          });
         */
     
    });