jQuery('body').append('<div id="fb-root"></div>');

(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=636262096435499";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

jQuery(document).ready(function() {
  jQuery('.tablenav.bottom').after('<div style="clear:both"></div>\n\
<div class="large-12">\n\
    <div class="mg-promo">\n\
    <p class="mg-promo-title"><a href="http://maxgalleria.com/shop/category/addons/?utm_source=mgfree&utm_medium=tout&utm_campaign=tout " target="_blank">Try these terrific MaxGalleria Addons<br>Every Addon for $49 or any single Addon for $29 for 1 site</a></p>\n\
    <div class="small-6 medium-6 large-6 columns sources">\n\
    <p class="section-title"><span>Layout Addons</span></p>\n\
    <div class="row top-margin">\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-image-carousel/?utm_source=mgfree&utm_medium=image-carousel&utm_campaign=image-carousel"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-image-carousel-cover.png" alt="MaxGalleria Image Carousel Addon" title="MaxGalleria Image Carousel Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-image-carousel/?utm_source=mgfree&utm_medium=image-carousel&utm_campaign=image-carousel">Image Carousel</a></h3><p>Turn your galleries into carousels</p>\n\
      </div>\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-albums/?utm_source=mgfree&utm_medium=albums&utm_campaign=albums"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-albums-cover.png" alt="MaxGalleria Albums Addon" title="MaxGalleria Albums Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-image-carousel/?utm_source=mgfree&utm_medium=albumso&utm_campaign=albums">Albums</a></h3><p>Organize your galleries into albums</p>\n\
      </div>\n\
    </div>\n\
    <div class="row top-margin">\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-image-showcase/?utm_source=mgfree&utm_medium=imageshowcase&utm_campaign=imageshowcase"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-image-showcase-cover.png" alt="MaxGalleria Image Showcase Addon" title="MaxGalleria Image Showcase Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-image-showcase/?utm_source=mgfree&utm_medium=imageshowcase&utm_campaign=imageshowcase">Image Showcase</a></h3><p>Showcase image with thumbnails</p>\n\
      </div>\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-video-showcase/?utm_source=mgfree&utm_medium=videoshowcase&utm_campaign=videoshowcase"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-video-showcase-cover.png" alt="" title="" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-video-showcase/?utm_source=mgfree&utm_medium=videoshowcase&utm_campaign=videoshowcase">Video Showcase</a></h3><p>Showcase video with thumbnails</p>\n\
      </div>\n\
    </div>\n\
    <div class="row top-margin">\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-masonry/?utm_source=mgfree&utm_medium=masonry&utm_campaign=masonry"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-masonry-cover.png" alt="Maxgalleria Masonry" title="Maxgalleria Masonry" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-masonry/?utm_source=mgfree&utm_medium=masonry&utm_campaign=masonry">Masonry</a></h3><p>Display Images in a Masonry Grid</p>\n\
      </div>\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-image-slider/?utm_source=mgfree&utm_medium=imageslider&utm_campaign=imageslider"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-image-slider-cover.png" alt="MaxGalleria Image Slider Addon" title="MaxGalleria Image Slider Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-image-slider/?utm_source=mgfree&utm_medium=imageslider&utm_campaign=imageslider">Image Slider</a></h3><p>Turn your galleries into sliders</p>\n\
      </div>\n\
    </div>\n\
   </div>\n\
   <div class="small-6 medium-6 large-6 columns sources">\n\
    <p class="section-title"><span>Media Sources</span></p>\n\
    <div class="row top-margin">\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-facebook/?utm_source=mgfree&utm_medium=facebook&utm_campaign=facebook"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-facebook-cover.png" alt="MaxGalleria Facebook Addon" title="MaxGalleria Facebook Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-facebook/?utm_source=mgfree&utm_medium=facebook&utm_campaign=facebook">Facebook</a></h3><p>Add Facebook photos to galleries</p>\n\
      </div>\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-slick-for-wordpress/?utm_source=mgfree&utm_medium=slick&utm_campaign=slick"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-slick-for-wordpress-cover.png" alt="Slick for WordPress" title="Slick for WordPress" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-slick-for-wordpress/?utm_source=mgfree&utm_medium=slick&utm_campaign=slick">Slick for WordPress</a></h3><p>The Last Carousel You&#39;ll ever need!</p>\n\
      </div>\n\
    </div>\n\
    <div class="row top-margin">\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-instagram/?utm_source=mgfree&utm_medium=instagram&utm_campaign=instagram"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-instagram-cover.png" alt="MaxGalleria Instagram Addon" title="MaxGalleria Instagram Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-instagram/?utm_source=mgfree&utm_medium=instagram&utm_campaign=instagram">Instagram</a></h3><p>Add Instagram images to galleries</p>\n\
      </div>\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-flickr/?utm_source=mgfree&utm_medium=flickr&utm_campaign=flickr"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-flickr-cover.png" alt="MaxGalleria Flickr Addon" title="MaxGalleria Flickr Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-flickr/?utm_source=mgfree&utm_medium=flickr&utm_campaign=flickr">Flickr</a></h3><p>Pull In Images from your Flickr stream</p>\n\
      </div>\n\
    </div>\n\
    <div class="row top-margin">\n\
      <div class="medium-6 large-6 columns addon-item">\n\
        <a href="http://maxgalleria.com/shop/maxgalleria-vimeo/?utm_source=mgfree&utm_medium=vimeo&utm_campaign=vimeo"><img width="200" height="200" src="http://cdn.maxgalleria.com//wp-content/themes/maxgalleriaplatform/images/catalog/maxgalleria-vimeo-cover.png" alt="MaxGalleria Vimeo Addon" title="MaxGalleria Vimeo Addon" /></a><h3><a href="http://maxgalleria.com/shop/maxgalleria-vimeo/?utm_source=mgfree&utm_medium=vimeo&utm_campaign=vimeo">Vimeo</a></h3><p>Use Vimeo videos in your galleries</p>\n\
      </div>\n\
    </div>\n\
   </div>\n\
   </div>\n\
  </div>');
  jQuery('.wrap h2').prepend(
    '<div class="mg-logo"><div>Brought to you by<a href="http://maxfoundry.com" target="_blank"><img src="' +
    mg_promo.pluginurl +
    '/images/max-foundry.png" alt="Max Foundry" /></a>makers of <a href="http://maxbuttons.com/?ref=mbpro" target="_blank">MaxButtons</a> and <a href="http://maxinbound.com/?ref=mbpro" target="_blank">MaxInbound</a></div>\n\
<div class="fb-like" ><a href="https://twitter.com/maxfoundry" class="twitter-follow-button" data-show-count="true" data-show-screen-name="false">Follow</a></div></div>'
  );
  jQuery('.wrap h1').prepend(
    '<div class="mg-logo"><div>Brought to you by<a href="http://maxfoundry.com" target="_blank"><img src="' +
    mg_promo.pluginurl +
    '/images/max-foundry.png" alt="Max Foundry" /></a>makers of <a href="http://maxbuttons.com/?ref=mbpro" target="_blank">MaxButtons</a> and <a href="http://maxinbound.com/?ref=mbpro" target="_blank">MaxInbound</a></div>\n\
<div class="fb-like" ><a href="https://twitter.com/maxfoundry" class="twitter-follow-button" data-show-count="true" data-show-screen-name="false">Follow</a></div></div>'
  );
		
  !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs')	
		
});