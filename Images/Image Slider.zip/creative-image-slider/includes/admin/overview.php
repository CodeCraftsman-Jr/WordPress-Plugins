<div id="cpanel">
	<div class="icon">
		<a href="admin.php?page=cis_sliders" title="Sliders">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/sliders.png' , __FILE__ );?>" /><br />
						Sliders
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon">
		<a href="admin.php?page=cis_items" title="Items">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/images.png' , __FILE__ );?>" /><br />
						Items
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon">
		<a href="admin.php?page=cis_categories" title="Categories">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/template.png' , __FILE__ );?>" /><br />
						Categories
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>


<div id="cpanel">
	<div class="icon" style="float: right;">
		<a href="http://creative-solutions.net/wordpress/creative-image-slider" target="_blank" title="">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/shopping_cart.png' , __FILE__ );?>" /><br />
						Buy Commercial Version
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon" style="float: right;">
		<a href="http://creative-solutions.net/forum/creative-image-slider-wordpress/" target="_blank" title="">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/forum.png' , __FILE__ );?>" /><br />
						Support Forum
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon" style="float: right;">
		<a href="http://creative-solutions.net/wordpress/creative-image-slider" target="_blank" title="">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/project.png' , __FILE__ );?>" /><br />
						Homepage
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
