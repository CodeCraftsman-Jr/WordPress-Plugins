tinyMCE.addI18n("en.slideshow",{
	title : "Insert a slideshow",
	desc : "Insert a slideshow"
});