tinyMCE.addI18n("it.slideshow",{
	title : "Inserisci slideshow",
	desc : "Inserisci slideshow"
});