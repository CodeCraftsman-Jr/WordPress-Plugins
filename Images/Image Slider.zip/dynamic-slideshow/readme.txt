=== Dynamic Slideshow ===
Donate link: http://www.xpertshelp.com
Author: Ashok kumar Das
Contributors:
Tested up to: 2.8
Stable tag: 0.5



It is a superb plugin through which you can easily add a wonderful dynamic slideshow within few mins. It's a full dynamic slideshow. You can set any amount of image from admin.  You can also set width, height and delay from admin.  
Here, another fantactic option is to set image caption in the image footer. From admin you can change anything related with the text . Such as font family, font color, font size and also change text postion from admin.


== Screenshots ==

1. Show some sample of general options.

2. YOu can show how can upload images.



== Installation ==

Installing should be a piece of cake and take fewer than five minutes.

1. Upload the folder "slideshow" to the "wp-content/plugins" directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. From the main menu choose "Options->slideshow" and set width, height, slideshow delay and images".
4. You Just put `<?php slideshow(); ?>` in your template.

