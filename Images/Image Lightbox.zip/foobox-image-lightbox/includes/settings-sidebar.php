<div id="foobox-free-settings-header"></div>
<?php
$size = 160;
?>
<div class="demo-gallery" style="margin-top: 35px;">
	<a title="This is the settings page you get with the <a target='_blank' href='<?php echo Foobox_Free::FOOBOX_URL; ?>'>PRO version of FooBox</a>!" href="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox1.jpg">
		<img title="FooBox PRO Settings Page" src="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox1_thumb.jpg">
	</a>
	<a title="Another settings page you get with the <a target='_blank' href='<?php echo Foobox_Free::FOOBOX_URL; ?>'>PRO version of FooBox</a>! Mmmmm, pretty..." href="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox2.jpg">
		<img title="Another FooBox PRO Settings Page" src="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox2_thumb.jpg">
	</a>
	<a title="One more settings page that you get with the <a target='_blank' href='<?php echo Foobox_Free::FOOBOX_URL; ?>'>PRO version of FooBox</a>! Try resizing your browser window" href="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox3.jpg">
		<img title="Yet Another FooBox PRO Settings Page" src="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox3_thumb.jpg">
	</a>
	<a style="display:none" href="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobot.png">
		<img title="I, FooBot" src="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobot.png">
	</a>
	<a style="display:none" href="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox.png">
		<img title="<a target='_blank' class='caption_call_to_action' href='<?php echo Foobox_Free::FOOBOX_URL; ?>'>Get The PRO version now!</a>" src="<?php echo trailingslashit(FOOBOXFREE_URL); ?>img/foobox.png">
	</a>
</div>