<h1> We detect that you edit our website so we redirect you to this page. <a href="<?php echo $_GET['r']; ?>">Click Here to Rediect Back to your page</a></h1>
