=== Defa Online Image Protector Free Edition ===
Contributors: Juthawong Naisanguansee
Donate link: http://www.juthawong.com/donate
Tags: Defa Online Image Protector , Protect Image Download , XHTML , Java , HTML5 , PHP , Javascript , Copycat , Right click , disabled , free , open source,Image Stolen , Watermarks , Game , Photo , Blogging , Image , Tags , Facebook , Stackoverflow , Imgur , BBCode , Imageshack , Shutter , stock , sell , image selling , commercial , image download , save as , save link as , save picture as , save page as, stolen , steal , fight , prevent , website , audiojungle , envato , photo market , photo selling , youtube , youimage
Requires at least: 3.3
Tested up to: 4.2
Stable tag: 3.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Protect your image from download as hard as we could.

== Description ==

Defa Online Image Protector - Protect your image from download by browser and external software and also hotlinking.

We encrypted the url link prevent user from knowing the the real destination of image and protect image from second connection.


How to use this software ?

Install and add this html tag to the page you want to protect image

&lt;protect&gt;&lt;/protect&gt;

What is this version ?

This version is Defa Online Image Protector without website protector. It more compatible with the web but less secure.




Note : Although there is no 100% real way to protect your image from download. Defa Online Image Protector make it hardest to grab while still make image interactable on the site unlike java and flash.

Why Second Connection not all connection ?

If we protect all connection image will not display on some browser and make compatibility issue . Moreover , If the user pc display image. They already got image in cache that some browser just intercept the cache and get it.

Defa Online Image Protector is just making it hard to get the image out of the browser.


Caution : Defa Online Image Protector doesn't protect from screen capture.
Caution 2 : Please use Defa Online Image Protector only the page you want to protect. Defa Online Image Protector can effect your google ranking and server memory resources.

== Installation ==

1. Upload `imageprotector` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= A question that someone might have =

How to use this software ?

Install and add this html tag to the page you want to protect image

&lt;protect&gt;&lt;/protect&gt;

What is this version ?

This version is Defa Online Image Protector without website protector. It more compatible with the web but less secure.


Why Second Connection not all connection ?

If we protect all connection image will not display on some browser and make compatibility issue . Moreover , If the user pc display image. They already got image in cache that some browser just intercept the cache and get it.

Defa Online Image Protector is just making it hard to get the image out of the browser.



What do these software doing?

It protect your image from download by browser and external software and also hotlinking.

We encrypted the url link prevent user from knowing the the real destination of image and protect image from second connection.

Encounter Problems ? 

Open ticket or read wiki at Sourceforge.
http://sourceforge.net/projects/defaprotectimagedownload/

Distribute our code at Github
https://github.com/juthawong/Defa-Online-Image-Protector-Protect-Image-Download

== Screenshots ==

1. http://a.fsdn.com/con/app/proj/defaprotectimagedownload/screenshots/save2.png/182/137
2. http://a.fsdn.com/con/app/proj/defaprotectimagedownload/screenshots/save.png/182/137

== Changelog ==
1.0 Startup

== Upgrade notice ==



== Arbitrary section 1 ==


