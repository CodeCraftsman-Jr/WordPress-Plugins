<?php
//This code has been modified for Image Protector Online
header('X-UA-Compatible: IE=edge,chrome=1');
//Written By Juthawong Naisanguansee

ob_start();

?>
<meta http-equiv="imagetoolbar" content="no" />
