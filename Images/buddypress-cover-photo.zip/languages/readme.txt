Please translate the bpcp.po and save the translated file as your_Local.mo  e.g en_US.mo or nl_NL.mo etc
