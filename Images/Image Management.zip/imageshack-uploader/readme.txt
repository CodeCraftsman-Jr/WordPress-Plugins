=== ImageShack Uploader ===
Contributors: arnee
Donate link: http://www.arnebrachhold.de/redir/sitemap-paypal
Tags: imageshack, post, images
Requires at least: 2.1
Stable tag: 1.2

This plugin allows you to upload images from your WordPress post screen to ImageShack and to insert them with the thumbnail into your post with a few clicks.

== Description ==

ImageShack is a free easy-to-use hosting service which allows you to upload your images and share them with others. 
You can embed these images directly into your website and use the auto generated thumbnails.

== Installation ==

1. Upload the plugin to your `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Check your posting screen and you'll see a new tab named "ImageShack" and the image upload form

== Frequently Asked Questions ==

= Does this plugin work with PHP4? =

Yes, since version 1.0.1b it is compatible with PHP4.

= Does this plugin work with WordPress 2.0 =

Maybe... I didn't test it, but the chances are high that it will work.

= Does this plugin work with WordPress 2.5 =

Yep, version 1.1 works fine with WP 2.5.

== Screenshots ==

1. Upload interface in WordPress 2.1
2. After the upload has finished, you can insert the thumbnails or upload another image.