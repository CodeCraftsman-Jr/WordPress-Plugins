=== Plugin Name ===
Contributors: alexandanthony, Adzbierajewski
Donate link: http://anthony.strangebutfunny.net/
Tags: imageshack, post, images
Requires at least: 3.5.1
Tested up to: 3.5.1
Stable tag: 4.0

This plugin allows you to upload images to ImageShack.com directly from your posting screen.
See http://anthony.strangebutfunny.net/my-plugins/easiest-newsletter/ for help
 
== Description ==

This plugin allows you to upload images to ImageShack.com directly from your posting screen.
See http://anthony.strangebutfunny.net/my-plugins/easiest-newsletter/ for help

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the directory `/easiest-imageshack-uploader/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. The tab "ImageShack" will appear in your add media section of the add posts and pages.

== Screenshots ==

1. Here's a screenshot of it in action

== Changelog ==

= 1.0 =
* Initial Release

= 2.0 =
* Moved the upload form to below the "From Computer" tab in the media page.

== Frequently Asked Questions ==

= Is this plugin compatible with WordPress Multi Site? =

Yes!, This plugin has been tested with WordPress Multi Site and works perfectly.