=== HTML5 Simple Video Gallery ===
Contributors: Rudloff
Tags: video, gallery, html5
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl.html
Requires at least: 4.0
Tested up to: 4.0

Shortcodes that help build a simple video gallery for WordPress

== Description ==

This plugin adds two shortcodes html5_video_gallery and html5_video_post that help you integrate a simple HTML5 video gallery into your website.

== Installation ==
1. Upload the `events-manager-osm` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Add the [html5_video_gallery cat="myCategoryNumber"] shortcode to your gallery page
1. Add the [html5_video_post url="myVideoUrl"] shortcode to your video pages

== Changelog ==

= 0.1 =
* Initial release
