HTML5 Simple Video Gallery
==================

Shortcodes that help build a simple video gallery for WordPress
