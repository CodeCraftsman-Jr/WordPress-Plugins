=== Embed Mobypicture ===
Contributors: timanrebel
Tags: embed, mobypicture
Requires at least: 2.8
Tested up to: 2.8.4
Stable tag: 1.0

Embed Mobypicture photos or videos in your posts or pages

== Description ==

Embed Mobypicture makes it easy to embed Photos or Videos from Mobypicture into your blogposts or pages by using the [mobypicture] shortcode. 

== Installation ==

1. Upload the `embed-mobypicture` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =
* Initial version
* Supports pohot and video