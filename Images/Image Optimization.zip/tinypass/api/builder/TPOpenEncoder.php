<?php

class TPOpenEncoder {

	public function encode($msg) {
		return $msg;
	}

	public function decode($msg) {
		return $msg;
	}

}

?>
