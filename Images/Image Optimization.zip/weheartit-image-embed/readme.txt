=== WeHeartIt Image Embed ===
Contributors: lonuongvit
Donate link: http://anybuy.vn/lo-quay-vit.htm
Tags: weheartit images
Requires at least: 2.8.0
Tested up to: 4.0.1 
Stable tag: trunk
License: GPLv2 or later

== Description ==

This plugin help you insert images from your weheartit.com account to content very quickly.

Feature:

- Search images and insert to content
- Change title and size before insert

== Installation ==

1. Unzip the weheartit-image-embed.zip
2. Copy weheartit-image-embed folder to wp-content/plugins
3. Go to Plugins/Installed Plugins, find WeHeartIt Image Embed and click Active
4. Enjoy!

== Screenshots ==

1. `/assets/screenshot-1.jpg`
2. `/assets/screenshot-2.jpg`
3. `/assets/screenshot-3.jpg`
4. `/assets/screenshot-4.jpg`

== Frequently Asked Questions ==

= Need support? =

Comment to my twitter (https://twitter.com/lonuongvit)

== Changelog ==

= 1.0 =
*  WeHeartIt Image Embed plugin released

== Upgrade Notice ==

= 1.0 =
* This is first version