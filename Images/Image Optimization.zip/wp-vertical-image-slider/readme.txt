=== wordpress vertical image slider plugin ===
Contributors:nik00726
Donate link:http://www.i13websolution.com/donate-wordpress_image_thumbnail.php
Tags:wordpress vertical image slider,wordpress vertical slider,wordpress vertical thumbnail scroller,wp vertical image slider,wordpress vertical vertical image sliders,wordpress slider with thumbnails,wordpress banner slider,wordpress vertical image slider with images,
Requires at least:3.0
Tested up to:4.3
Version:1.0
Stable tag:trunk
License:GPLv2 or later
License URI:http://www.gnu.org/licenses/gpl-2.0.html
== Description ==


This is beautiful vertical image slider for wordPress blogs and sites.Admin can manages any number of images into the vertical slider.
Admin can add,edit and delete slider images.Before add slider to wordPress blog admin can preview a slider.Admin can set height,width of slider images.Admin can also set speed,Number Of visible images into slider,Circular slider.Admin can also set if want to slide images with up and down arrow or by automatic slider.

**Find WordPress Vertical Image Slider Pro Plugin(Unlimited Slider + Mass Image Upload + Much More) at [Vertical Image Slider Pro](http://www.i13websolution.com/wordpress-pro-plugins/wordpress-vertical-image-slider-pro-plugin.html)**

**Live demo at [WordPress Vertical Image Slider](http://blog.i13websolution.com/live-preview-vertical-thumbnail-slider-pro/)**

**Please rate this plugin if you find it useful**


**=Features=**


1. Add any number of images to vertical slider.

2. Edit images and image name.

3. Image name is used as alt tag for seo.

4. Preview your slider before use it.

5. Slider installation into theme is simple just add shortcode 
to theme or pages/posts.

6. changes to images height,width

7. Changes to slider speed is easy.

8. Admin can set slider as slide with arrow left and right arrow.

9. Admin can set slider as circular slider.

10. Support WordPress responsive admin panel.

**=Pro Version Features=**

1. Unlimited Slider(Multiple sliders).

2. Mass Images Upload. 

3. Use WordPress Media Uploader(wp>3.5) image upload. 

4. Add wordpress featured image in vertical slider directly from post/page add/edit.

5. Slider Easing Effects(select your desired slider easing effect from 16 easing effect).

6. No advertisements.

7. If image description set it will added to image title tag for seo.

8. Now admin can display slider according image order.

9. Open image link in new tab or same tab.

10. Support WordPress responsive admin panel.



[Get Support](http://www.i13websolution.com/contacts)


== Installation ==

This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. upload wp-vertical-image-slider folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use wordpress image slider.

### Usage ###

1.Use of wordpress vertical  slider is easy after activating plugin go to Vertical Imaages Slider.

2.You can manage images by Manage images menu.

3.You can set settings for this plugin using slider settings menu.

4.You can add this slider to your wordpress page/post by adding this shortcode to [print_vertical_thumbnail_slider] 

OR you can add this to your theme by adding this code echo do_shortcode('[print_vertical_thumbnail_slider]'); to your theme


== Screenshots ==

1. Slider Setting
2. Manage Images 
3. Preview Slider
4. Pro version manage sliders
5. Pro version slider add/edit
6. Pro version manage images
7. Pro version add/edit image
8. Pro version featured image add/edit

== License ==

This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.


== Changelog ==

= 1.0 =

* Stable 1.0 first release


== Upgrade notice ==

* Stable 1.0 first release


== Frequently asked questions ==

1.How to use ?

For More info use readme installation and usage notes.
