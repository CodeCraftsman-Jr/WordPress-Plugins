=== Subitem AL Slider ===
Contributors: alexdtn 
Donate link: https://secure.avangate.com/order/checkout.php?PRODS=4638772&QTY=1&CART=1&CARD=1&ORDERSTYLE=nLWo45a5jLg=
Tags: slider, slideshow, wordpress slider, image slider, responsive slideshow, image Rotator, jquery slider, Photo Slider, slider plugin, javascript slider, responsive slider, featured-content-slider, Horizontal slider, wp slider, vertical slider, best slider plugin, javascript slideshow, slideshow manager, slideshow plugin, image slideshow, jquery slideshow, wordpress slideshow, vertical slides, responsive, plugin, slider widget, widget slider, widget slideshow, widget, widgets, seo, wordpress seo, media, page, slide, slides, image, images, slide show, slider shortcode, picture slider, text slider, text slides, text slideshow, jquery image slider, slider wordpress, image slider wordpress, wordpress slider plugin, html slider, html image slider, html jquery slider, jquery gallery slider, slider js, js image slider, js slideshow, javascript slideshow, js slide show, javascript image slider, simple jquery slider, simple slider, simple image slider, simple jquery image slider, simple javascript image slider, js image rotator, javascript image rotator, banner slider, jquery banner slider, jquery banner, banner slideshow, free image slider, free slider, free sliders, image sliders, jquery image sliders, jquery slider plugin, slider plugin, jquery slider plugins, responsive slider jquery,  jquery vertical slider, vertical image slider jquery, jquery horizontal slider, horizontal image slider jquery, jquery photo slider, photo gallery jquery, jquery photo slideshow, jquery slideshow, jquery image slideshow, jquery slideshow tutorial, website slider, free slider for website, best jquery slider, slideshow html, html image slideshow, jquery image gallery, jquery gallery plugin, slideshow maker online, slideshow online, photo slideshow online, responsive slider, image slider responsive, jquery slide, jquery slide show, jquery image slide, responsive slideshow jquery, slideshow responsive, photo slide show, slide show html, picture slide show, slide show online, responsive gallery slider, jquery slider tutorial, web slider, slider maker, anything slider, slideshow creator,  slideshow for website, image slideshow, simple slideshow, jquery rotator, photo show, slider widget, image slider widget, wordpress slider widget, best wordpress silders, new slider, last version slider, last sliders, new sliders, easy setup slider, free jquery slider, best responsive slider, responsive slider pligin, wordpress jquery plugin, plugin slideshow wordpress, website image slider, jquery image slider plugin, widget slider wordpress, responsive slider free, slider image jquery, slider images for website, latest slider, latest sliders, latest image slider, latest slideshow, latest jquery slider, great jquery slider, jquery slideshow plugins, responsive image slider jquery, vertical slider wordpress, banner slider wordpress, slider images jquery
Requires at least: 3.6
Tested up to: 4.2.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Subitem AL Slider is an excellent wordpress plugin with lots of capabilities. You can manipulate with chains of actions applied to item.

== Description ==

You can see demo at <br>
<a href="http://al-plugins.biz/subitem-al-slider/">Subitem AL Slider Live Demo</a><br>
Subitem AL Slider can manipulate text, image and video items. You can create and apply different effects. Only your imagination can prevent you create a wonderfull presentation or something else.

### Main features of the slider

*   Responsive design.
*   Capability to add images.
*   Capability to add texts.
*   Capability to add custom html templates.
*   Capability to make buttons.
*   Capability to add video (youtube, vimeo ...). Read faq for important details.
*   Capability to attach css rules to text items and to slider.
*   Generate shortcodes to add to pages or posts or template file.
*   Capability to add links.
*   You can add a set of css rules to any text item.
*   You can add slider as widget.
*   Capability to setup right/left buttons in slider.
*   Many two side effects.
*   Full width, full screen and default modes.
*   You can add slides indicators.
*   Preloader (with lazy load).
*   SEO optimized.
*   Crossbrowser.
*   W3C Valid: HTML & CSS (on demo site there are errors only in theme).
*   Make a chain of custom effects.
*   Import/Export capabilities
*   And much more...

== Installation ==

1. Upload `subitem-al-slider` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create new project
4. Upload images using upload button in "Slider Items" tab
5. Add main info and backgrounds in "Slider Main Info" tab
6. Fill section "Slider Containers"
7. Get codes from "Paste Code" tab and insert into page/post/template.

== Frequently Asked Questions ==

1.How can i set background of text item transparent?
In field style of text item add : Example - background-color:rgba(55,55,55,0.1);

2. Where can i setup my slider?
You can setup it in admin area and in cfg/cfg.php file (additional settings).

3. How can i add button to the slider?
Fist of all you need to upload images for buttons into wordpress.
In �Main Slider Info� tab, in field �Apply Classes� describe selectors(example: classes) with background url properties of your buttons.
CSS Example ( .info_btn{ background:url(�http://example.com/wordpress/wp-content/uploads/2014/22/info.png�) no-repeat; } ).
Add in �Slider Items� tab new text items for your button with text or if you want without it (use �&nbsp;�).
In current text item section in field �Classes List� apply described earlier classes.
Use this item in your group.
All images used in such case not imported and exported.

== Screenshots ==

1.  Simple AL Slider frontend.
2.  Simple AL Slider admin page 1.
3.  Simple AL Slider admin page 2.
4.  Simple AL Slider admin page 3.
5.  Simple AL Slider admin page 4.
6.  Simple AL Slider admin page 5.
7.  Simple AL Slider admin page 6.

== Changelog ==

= 1.0 =
* First version.

== Upgrade Notice ==

= 1.0 =
First version.
