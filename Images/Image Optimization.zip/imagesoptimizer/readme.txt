=== Easy Watermark and Images Optimize ===
Contributors: spnova
Donate link: http://www.ehalimedvedi.ru/2010/05/tailand-otzyvy-i-mify/
Tags: watermark, optimize, images
Requires at least: 1.0
Tested up to: 2.9
Stable tag: 1.4
Version: 1.4

== Description ==
A simple way to optimize your images and to watermarks. Not only new images can be optimized, but already uploaded ones too.  

When adding/editing the image you will see 2 new fields: "Optimize" and "Add watermark". All the changes will be made automatically without page reloading by only clicking the needed function. 

You can preview the image before making the changes. 

== Installation ==
1. Upload full directory into your wp-content/plugins directory
2. Set CHMOD 777 to plugin directory wp-content/plugins/imagesoptimizer
3. Activate the plugin at plugin administration page
4. Setup your watermark on plugin settings page.

== Changelog ==
 
= 1.4 =
 * Some updates

= 1.0 =
 * New plugin.

= Version 1.4, Jun 3, 2010 =

== Frequently Asked Questions == 

....

== Upgrade Notice ==

= 1.4 =
 * Now you can change text colors and transparent.

= 1.0 =
 * New plugin.

== Screenshots ==

1. Administration interface in WordPress 2.9

== Licence ==

GPL

== Translations ==

en
