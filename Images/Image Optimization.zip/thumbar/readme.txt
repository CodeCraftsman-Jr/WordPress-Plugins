=== Thumbar ===
Contributors: Thumbar.com
Donate link: https://thumbar.com
Tags: thumbar, thumbbar, plugin, plugins, rate, rating, ratings, vote, votes, voting, star, stars, like, dislike, widget, widgets, social, sidebar, comment, comments, post, posts, page, pages, search, google, admin, administrator, review, reviews, snippets, ajax, jquery, buddypress, bbpress, javascript, wordpress
Requires at least: 2.6
Tested up to: 4.2.4
Stable tag: 1.009
License: GPLv2 or later

The only free rating plugin that provides both live feedback and mirrors itself at Thumbar.com to boost your exposure.

== Description ==

#### Free Stats Galore
* Shows up counts, down counts, total, and percent voted up
* Two-tone bars provide a quick visual summary of votes
* Slim profile integrates easily into your content

[Thumbar](https://www.thumbar.com/images/thumbar.png)

#### Free Exposure: Forget SEO or Paying for Ads
* Each Thumbar syncs itself and a snippet of your content at Thumbar.com in real time
* At Thumbar.com, your snippets are searchable, sortable, rateable, and backlinked to your blog

== Installation ==

1. Download the plugin to your blog.

2. If you don't have a Thumbar member id, create a free account at Thumbar.com (takes 20 seconds).

3. Log into Thumbar.com, click on Tools, and find uid="x" in the code displayed.

4. Edit ../wp-content/plugins/thumbar/thumbar-wp.php, setting uid="x" to your member id, and save it.

5. In your WP Dashboard under Plugins find Thumbar and click on Activate.

6. Refresh your blog's home page, rate one of your posts, and when prompted, log into Thumbar.

7. Done.

== Changelog ==

= 1.0 =
* New: Initial release

= 1.001 =
* Readme update

= 1.002 =
* Readme update

= 1.003 =
* Readme update

= 1.004 =
* Readme update

= 1.005 =
* Readme update

= 1.006 =
* Readme update

= 1.006 =
* Readme update

= 1.007 =
* Readme update

= 1.008 =
* Readme update

= 1.009 =
* Readme update