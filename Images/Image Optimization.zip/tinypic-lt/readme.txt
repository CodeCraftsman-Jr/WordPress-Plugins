=== Plugin Name ===
Contributors: Jati MYW
Donate link: http://limitedtemplates.com/
Tags: tinypic, tinypiclt, images, picture, photo, metabox, admin, upload to tinypic, images hosting, upload images, upload video
Requires at least: 2.9.1
Tested up to: 2.9.1
Stable tag: 1.0

Adds metabox TinyPic widget to upload photos or videos while writing a new post or page.

== Description ==

TinyPicLT plugin add tinypic metabox widget, this is simple plugin that allow you to upload image or video while writing a new post or page without go to any page, this plugin might/can help you to keep your idea in writing an article, so simple and useful.
TinyPicLT Plugin written by [Jati](http://limitedtemplates.com/ltb/tinypic-lt-wordpress-plugin.html "LimitedTemplates.com")

== Installation ==

1. Upload the folder "tinypic-lt"  to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress
3. Done and enjoy ;)

== Frequently Asked Questions ==

[TinyPicLT](http://limitedtemplates.com/ltb/tinypic-lt-wordpress-plugin.html "TinyPicLT")

== Screenshots ==

1. /trunk/screenshot-1.png
2. /trunk/screenshot-2.png

== Changelog ==

= 1.0 =
* Plugin release

== Upgrade Notice ==

= 1.0 =
Plugin release.