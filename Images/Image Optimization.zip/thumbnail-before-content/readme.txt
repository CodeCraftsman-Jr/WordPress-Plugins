=== Plugin Name ===
Contributors: adam.ainsworth
Donate link: http://mesklin.net/
Tags: before content, post thumbnail, featured image
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 0.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a simple plugin that automatically inserts the post thumbnail (featured image) before the post content.

== Description ==

Does exactly what it says on the tin, if you want your Featured Image to be inserted before the content in your pages or posts, and your theme doesn't support this, then this is the plugin for you.

No styling is done by default, this will be added in a future version.

== Installation ==

1. Upload the `thumbnail-before-content` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Do you have any FAQs? =

Not right now...

== Changelog ==

= 0.9 =
Initial launch