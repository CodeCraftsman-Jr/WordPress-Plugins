<?php

add_action( 'wp_enqueue_scripts', 'load_toggle_psd_assets' );

function load_toggle_psd_assets() {

    wp_register_script( 'toggle-psd-js', plugins_url( 'assets/js/toggle-psd.min.js', dirname( __FILE__ ) ), array( 'jquery', 'underscore', 'backbone' ) );

    $data = Toggle_PSD::get_json();
    wp_localize_script( 'toggle-psd-js', 'togglePSDModels', $data );
    wp_enqueue_style( 'toggle-psd-css', plugins_url( 'assets/css/toggle-psd.min.css', dirname( __FILE__ ) ) );
    wp_enqueue_script( 'toggle-psd-js', plugins_url( 'assets/js/toggle-psd.min.js', dirname( __FILE__ ) ), array( 'jquery', 'underscore', 'backbone' ) );
}
