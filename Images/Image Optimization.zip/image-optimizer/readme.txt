=== Image Optimizer ===
Contributors: yejun
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=3494945
Tags: images,optipng,jhead,post,admin,minimize,optimize
Requires at least: 2.7
Tested up to: 2.7.1
Stable tag: trunk

Reduce uploaded images's size with Optipng and Jhead. There is no option for this plugin.

== Description ==

Reduce uploaded images's size with Optipng and Jhead. There is no option for this plugin.

It only reduce size of png and jpeg files. If you want to use other format, please convert them before uploading.

Requirement:

* [Optipng](http://optipng.sourceforge.net/)

* [JHead](http://www.sentex.net/~mwandel/jhead/)

* Disable safe mode in PHP

Change log:

* 3/29/2009  1.0: Initial release.

== Installation ==

1. Upload `image-optimizer.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Upload a png or jpeg to test it