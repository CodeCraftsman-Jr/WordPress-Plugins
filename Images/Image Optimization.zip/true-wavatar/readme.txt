=== Plugin Name ===
Contributors: Julian Widya Perdana
Donate link: http://mr.hokya.com/donate
Tags: gravatar, avatar, comment. comments, image, thumb, thumbnail, screenshot
Requires at least: 2.0.2
Tested up to: 2.9.*
Stable tag: 4.3

Display true thumbnail image of commentator's URL as avatar on comments template instead of using Gravatar


== Description ==

You don't have to put any PHP codes, it will automatically replace all gravatars on your pages into true web thumbnail of linked site even on the dashboard. The screenshot is automatically generated from thumbspot.com so you don't have to worry about PHP codes, but keep in mind that it will works only if you're online.


== Installation ==


1. Upload the zipped file to yoursite/wp-content/plugins
1. Activate the plugin through the 'Plugins' menu in WordPress