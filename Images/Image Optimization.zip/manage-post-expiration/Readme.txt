=== Manage Post Expiration===

Contributors: Cyberlobe Technologies
Tags: expire post manage date
Requires at least: 1.5
Tested up to: 3.2
Stable tag: 1.1


== Description ==

Manage Post Expiration plugin basically helps to set an expiry date for the post. The post gets expired after specified date and is not visible and is unpublished.

== Installation ==

1> Download the plugin and activate it for the use.
2> After this, on any new post or edit post page you will be given the option for setting an expiry date for the post. 

== Changelog ==

Solved bugs related to other plugins

== License ==

This plugin is free for everyone!