jQuery(document).ready(function($) {
    $("#wpcloudy-tabs .hidden").removeClass('hidden');
    $("#wpcloudy-tabs").tabs();
});