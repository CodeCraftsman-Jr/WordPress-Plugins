=== Plugin Name ===
Contributors: erwanpia
Donate link: http://tablet-photography.com/
Tags: ipad, tablet, gallery, images, swipe, touch, smartphones, ipod
Requires at least: 3.5
Tested up to: 3.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Provides automatic lightbox for desktop and touch swipe enabled gallery on ipad and tablets for native galleries.

== Description ==

lightweight integration of colorbox lightbox, touchswipe image slider for tablets, with worpdress native galleries using worpdress mobile detection function.

 automatically adds lightbox to all jpg, gif links including single images, and assembles them in a gallery that works on tablets and smartphones too.

<a href="http://tablet-photography.com">Demo available on tablet-photography.com : get your IPAD out ! </a>
 
== Changelog ==
= 1.1 =
* 20130219  : now works with single images not just galleries

= 1.0 =
* integrates colorbox and photoswipe

== Upgrade Notice ==
= 1.1 =
now works with single images not just galleries
= 1.0 =
first version 
 
 