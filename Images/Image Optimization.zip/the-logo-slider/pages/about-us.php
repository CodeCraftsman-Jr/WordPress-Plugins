<div class="wrap netgo-facebook-post-setting">
  <h2><?php _e('About Us','');?></h2>
  
  <table class="form-table">
		<tbody>
		<tr valign="top">
			<td>
			<p>For any business approach it is important to know about the company in whose you are giving your dream project and investing money too.We are not a brand but our work is too branded.</p>
			<p>We are a team of 20 expert developers with 5+ years of dedicated experience. We have few Magento certified developers with great portfolio. </p>
			<p class="about-title">Why Us?</p>
			<ol>
			<li>Hard working.</li>
			<li>Will keep you updated about you project.</li>
			<li>Punctual</li>
			<li>Affordable</li>
			<li>Believes in your satisfaction.</li>
			</ol>
			
			<p>Visit the link to see our portfolio <a href="http://find-my-work.com/netattingo/" target="_blank">Our Portfolio.</a></p>
			
			</td>
		</tr>
		
		</tbody></table>
  
</div>