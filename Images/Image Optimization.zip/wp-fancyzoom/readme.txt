=== WP FancyZoom ===
Contributors: sgranade
Donate link: http://granades.com/wp-fancyzoom/
Tags: images, image, post, admin, popup, javascript, media
Requires at least: 2.0.4
Tested up to: 2.8.4
Stable tag: 1.2

WP FancyZoom brings the cool popup image zooming of FancyZoom to your
Wordpress blog.

== Description ==

WP FancyZoom is a simple way to add the [FancyZoom image overlay
script](http://www.fancyzoom.com/ "The FancyZoom homepage") to your
blog. In short, FancyZoom is a nice, modern way of making popup
images. You put a thumbnail image in your post and link to the
full-size image. If a user clicks on the thumbnail, the full-size
image zooms in over the current window. When the user clicks on the
zoomed picture, it goes away. Want to see it in action? [Check out this
post](http://granades.com/2006/07/13/how-to-disassemble-a-toilet-in-many-easy-steps/
"A post with the popup images plugin in action.").

Nifty features:
* The zoom effect is super sexy.
* No extra work needed when you write a post: any direct link to an
image will automatically get the FancyZoom treatment.
* Any `title='...'` attribute in your link automatically turns into a
caption.
* This plugin is a drop-in replacement for my previous Simple Popup
Images plugin.
* That zoom effect? Still super sexy.

== Installation ==

1. Grab the latest version
2. Put the entire plugin folder in your wp-content/plugins/ folder
3. Activate the plugin in your Wordpress admin panel
