<div class="cta padding-bottom">
	<h3>Credits</h3>
	<ul>
	
	   <li>
	      <strong>Quality Photos and Inspiration</strong><br/>
	      <a href="https://unsplash.com/" target="blank">Unsplash.com</a> - Free (do whatever you want) high-resolution stock photos.
	   </li>
	   
	   <li>
	      <strong>Images and API</strong><br/>
	      <a href="https://unsplash.it" target="blank">Unsplash It</a> - Access to Unsplash stock photo library and <a href="https://unsplash.it/list" target="blank">API</a> was provided by the amazing team at <a href="https://unsplash.it" target="blank">Unsplash It</a>.
	   </li>
	   
  </ul>
  <a class="visit" target="blank" href="https://unsplash.com/"><i class="fa fa-chevron-circle-right"></i> Visit Unsplash.com</a>
</div>