=== Video Gallery ===
Contributors: gurkanoluc
Donate link: http://gurkanoluc.com/
Tags: posts, videos, post, video, video gallery
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 1.0.5

Video gallery plugin which allows you to build video galleries from your youtube, vimeo and dailymotion videos.

== Description ==

With this video gallery plugin, you can create galleries from your youtube, vimeo and dailymotion videos.

You can embed your videos as a gallery or single video. 

== Installation ==

1. Upload video-gallery directory to your /wp-content/plugins directory.
2. Be sure video-gallery/thumbs directory is writable.

== Frequently Asked Questions ==

== Screenshots ==

1. Main screen
2. List & Edit screen

== Changelog ==

= 1.0 =
* First version of plugin

= 1.0.5 =
* JavaScript i18n moved to PHP file.
* I18N bugs fixed.
* JavaScript bug in video delete fixed.
