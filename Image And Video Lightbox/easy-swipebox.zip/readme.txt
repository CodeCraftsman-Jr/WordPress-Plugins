=== Plugin Name ===
Contributors: LeoPeo
Donate link: 
Tags: image, video, gallery, fancybox, swipebox
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 0.9.1
License: The MIT License (MIT)
License URI: http://opensource.org/licenses/MIT

This plugin enable SwipeBox jQuery extension to all links to image or Video (Youtube / Vimeo).

== Description ==

This plugin enable SwipeBox jQuery extension to all links to image or Video (Youtube / Vimeo).
Please, for contributions, issues and questions visit https://github.com/leopuleo/easy-swipebox

== Installation ==

1. Download the plugin from Wordpress repository.
1. Upload the plugin folder in `/plugins/`. 
1. Activate the plugin.

Done! Now all link to image or Youtube/Vimeo opens in a beautiful touch/swipe lightbox.

== Frequently Asked Questions ==

Please, for contributions, issues and questions visit https://github.com/leopuleo/easy-swipebox

== Screenshots ==


== Changelog ==

= 0.9.1 =
* Bug fix: Added JPEG extension support
* Bug fix: Use image title as link title (alt fallback)

= 0.9 =
* First commit