# Easy SwipeBox (Wordpress Plugin)
This Wordpress plugin enable [SwipeBox jQuery extension](http://brutaldesign.github.io/swipebox/ "SwipeBox jQuery extension") on all links to image or Video (Youtube / Vimeo).
