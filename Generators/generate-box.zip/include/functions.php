<?php
/*
	plugin functions
*/
?>