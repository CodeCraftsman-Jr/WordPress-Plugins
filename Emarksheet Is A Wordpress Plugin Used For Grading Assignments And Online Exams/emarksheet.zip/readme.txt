=== Online Marksheet Creator : eMarksheet ===
Contributors: rohitashv
Link: http://impulsesoftech.com
Tags: emarksheet, online marksheet creator, create marksheet online, online marksheet
Requires at least: 4.0
Stable tag: 2.8

This is a simple and unique wordpress plugin to create a simple marksheet using wordpress. You can also give a link to your users to see the result and print it.

== Description ==

This is a simple and unique wordpress plugin to create a simple marksheet using wordpress. You can also give a link to your users to see the result and print it.

In this you have to follow just simple steps :


a) Add class


b) Add Subject


c) Enroll Student

d) Add marks

e) Print Marksheet

These are the basic features.

**Premium Features**

1) Allws students to search result by roll no and DOB

2) Students Details Update

3) Update Institute Logo

4) Update Students Marks

5) Export results to excel

6) Add Semester to class

To See a Demo and purchase this 

Go to the site http://impulsesoftech.com/index.php/emarksheet-premium/

For Support Go to Link :

http://impulsesoftech.com/forum/

or discuss more about it you can send a mail on ucerturohit@gmail.com

== Installation ==

This section describes how to install the plugin and get it working.



1. Unzip archive and upload the entire folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions == 

== Screenshots ==
1. Add Class
2. Add Subject
3. Add Student
4. Add Marks 1
5. Add Marks 2
6. Setting for the school
7. Print Marksheet1
8. Print Marksheet2
9. Frontend Result

== Changelog ==
 
=0.2=
First Version released

=1.3=
Now Print option is available at front end
and you can minimum passing marks on each Subject
Uninstall feature is also available

=1.31= 
minor bug resolved

=1.33=
minor bug resolved

=2.6=
minor bug resolved

=2.8 ==
minor bug resolved
