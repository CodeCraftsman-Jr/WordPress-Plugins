<link rel='stylesheet' type='text/css' href='<?php echo plugins_url('/bootstrap/css/bootstrap.css', __FILE__); ?>' />
<link rel='stylesheet' type='text/css' href='<?php echo plugins_url('/bootstrap/css/bootstrap-responsive.css', __FILE__); ?>' />
<div class=" span12 alert alert-info" style="margin-top:20px;">
<h3>Help & Support</h3>
<hr/>
<strong>Creating Marksheet : </strong> <br/><br/>To Create a marksheet, just follow the following Steps : <br/><br/>
Step 1 : Add Class <br/>
Step 2 : Add subject to the class added in step 1 <br/>
Step 3 : Enroll Student <br/>
Step 4 : Add Marks<br/>
Step 5 : Print Marksheet<br/><br/>
<hr/>
<strong>Premium Features : </strong>
<br/>
1) Allws students to search result by roll no and DOB
2) Students Details Update
3) Update Institute Logo
4) Update Students Marks
5) Export results to excel
6) Add Semester to class
<hr/>
<strong>Regarding Support : </strong><br/><br/>
in case of any support : <br/>
1. you can send us mail at <strong><em>ucerturohit[at]gmail[dot]com</em></strong>/a
