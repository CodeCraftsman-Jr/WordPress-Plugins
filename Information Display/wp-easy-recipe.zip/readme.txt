=== WP EASY RECIPE===
Contributors: india-web-developer
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZEMSYQUZRUK6A
Tags: WP Easy Recipe,Easy Recipe,Recipe,Simple Recipe
Requires at least: 2.8
Tested up to: 4.3
Stable tag: 1.2

Add "WP EASY RECIPE" on your website.

== Description ==

"WP EASY RECIPE" is a very simple plugin for add to "Recipe" content with seprate category and tags on your site in a easy way. This is fully responsive plugin

Use [wp_recipe_list_page] sortcode for reterive all the recipe pages

= Features =
 * Shortcode [wp_easy_recipe_slider] for recipe feature image slider (responsive)
 * Shortcode [wer_recipe_of_the_day] for get the "Recipe Of The Day"
 * Shortcode [wer_ten_best_recipe] for get the "10 Best Recipe"
 * Option for add .HTML In URL
 * Image Upload Option On Category

== Installation ==

Step 1. Upload wp-easy-recipe folder to the `/wp-content/plugins/` directory

Step 2. Activate the plugin through the Plugins menu in WordPress

== Frequently Asked Questions ==

 * How publish all the recipe post on any spefic page?

  Create a new page and add [wp_recipe_list_page] sortcode 

 * How update the social media content on details page?

  Find the "WP Easy Recipe" settings from admin ("Settings" >> "WP Easy Recipe") and update the content of social media


== Screenshots ==

1. screenshot-1.png


== Changelog == 

= 1.1 = 

 * Added shortcode [wp_easy_recipe_slider] for recipe feature image slider (responsive)
 * Added shortcode [wer_recipe_of_the_day] for get the "Recipe Of The Day"
 * Added shortcode [wer_ten_best_recipe] for get the "10 Best Recipe"
 * Added an option for add .HTML In URL
 * Image Upload Option On Recipe Category

= 1.0 = 
 * First stable release 
