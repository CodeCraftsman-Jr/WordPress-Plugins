=== Copy Alerts ===

Donate Link: http://pdxt.com/
Tags: Plagiarism Detection, Copyright Protection, Viral Visibility, Copy Alerts, Content Visibility, Copyright Notification, Content Copying, Copying Detection
Contributors: Mark Nelson
Requires at least: 2.3
Tested up to: 2.7
Stable tag: 1.1.0

THIS PLUGIN IS NO LONGER ACTIVE AS COPYALERTS HAS BEEN SHUTDOWN - PLEASE DO NOT USE.

== Description ==

THIS PLUGIN IS NO LONGER ACTIVE AS COPYALERTS HAS BEEN SHUTDOWN - PLEASE DO NOT USE.

== Installation == 

THIS PLUGIN IS NO LONGER ACTIVE AS COPYALERTS HAS BEEN SHUTDOWN - PLEASE DO NOT USE.

== Frequently Asked Questions ==

THIS PLUGIN IS NO LONGER ACTIVE AS COPYALERTS HAS BEEN SHUTDOWN - PLEASE DO NOT USE.

== Screenshots ==
