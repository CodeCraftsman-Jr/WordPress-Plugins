=== Comment Keywords ===
Contributors: LimeiraStudio 
Tags: comments, comment notification, notifications, notify, keywords, administration, admin, email, plugin
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 0.1

== Description ==

When a comment contains any of specified words in its content it will be sent to administrator with highlighted keywords, in despite of disabled global option about comments notifications.
Keywords can be noted in the administrative panel


**Requirements**

* PHP 5.2.0 or newer

== Installation ==

1. Upload the folder comment-keywords to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings->Comment Keywords to specify your keywords.

== Changelog ==

= 0.1 =

* Initial release
