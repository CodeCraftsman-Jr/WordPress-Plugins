=== My Comments Elsewhere ===
Contributors: ImprovingTheWeb
Donate link: http://www.improvingtheweb.com/donate/
Tags: comment, comments, notification, aggregation, trackback, pingback, admin, widget, digest, backtype, cocomment
Requires at least: 2.5
Tested up to: 2.7
stable tag: 1.0

This plugin collects the comments you posted on other people's websites and lets you display them on your own blog.

== Description ==

This plugin will track all comments you make on other blogs and download them back to your own site. You can then display these comments as a paginated listing, install a widget, or automatically create daily/weekly digest posts.

The plugin uses either [BackType](http://www.backtype.com/) or [CoComment](http://www.cocomment.com/) to track your comments.

**More info**

* See the [Example Implementation](http://www.improvingtheweb.com/my-comments-across-the-web/).
* Check out [My Comments Elsewhere](http://www.improvingtheweb.com/wordpress-plugins/my-comments-elsewhere/) for more information.
* Check out my other [Wordpress plugins](http://www.improvingtheweb.com/).

== Installation ==

1. Download the plugin.
2. Unzip the plugin and upload the directory to `wp-content/plugins`.
3. Activate the plugin.
4. Go to the "My comments elsewhere" options page and follow instructions.

== Links ==

Check out [my blog](http://www.improvingtheweb.com/) for more wordpress plugins and tips.