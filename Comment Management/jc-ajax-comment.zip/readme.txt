=== JC Ajax Comments ===
Contributors: webdesignjc
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=25BYCRDE6D2PW
Tags: ajax comments, ajax comment, ajax comments form, ajax comment form, error message ajax
Requires at least: 3.3
Tested up to: 4.0.1
Stable tag: 4.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ajax in wordpress comments, this plugin makes the error message is displayed in a popup and updates the comments.

== Description ==


Ajax functionality to comments, this plugin makes the error message is displayed in a popup window and updates the comments.

<a href="http://webdesignjc.com/recaptchawp/index.html" target="_blank">Plugin Website</a>


== Installation ==

1. Upload the `jc-ajax-comment` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin via the 'Plugins' menu in WordPress.


== Frequently asked questions ==



== Screenshots ==

1. Example comments form
2. Example error comment
3. Example success comment
3. Example woocommerce comment form
3. Example success woocommerce comment
== Changelog ==



== Upgrade notice ==

