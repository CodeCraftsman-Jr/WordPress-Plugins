=== Comment Meta Display ===
Contributors: sparkweb
Donate link: http://wordpress.org/extend/plugins/comment-meta-display/
Tags: comments, meta, custom fields
Requires at least: 2.9
Tested up to: 4.3
Stable tag: 1.1
View comment meta beneath the comment on the admin edit screen.

== Description ==

View comment meta beneath the comment on the admin edit screen.

Note that this is display-only and doesn't add or save comment meta.



== Frequently Asked Questions ==

*How can I set the comment meta?*

You can read more about this at my tutorial [found here](http://www.soapboxdave.com/2010/02/using-wordpress-comment-meta/).


== Installation ==

Copy the folder to your WordPress
'*/wp-content/plugins/*' folder.


== Screenshots ==

1. Comment Meta Display on Comment Edit Screen


== Changelog ==

= 1.1 (4/28/2014) =
* Improve Display

= 1.0 (8/18/2011) =
* Initial Release


== Upgrade Notice ==

None
