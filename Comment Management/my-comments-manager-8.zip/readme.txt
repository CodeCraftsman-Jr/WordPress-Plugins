=== My Comments Manager ===
Contributors: rtCamp
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9488824
Tags: Comments, Comment, multi author, Plugins, Dashboard, Moderation, Admin
Requires at least: WP 2.9
Tested up to: WPMU 2.9.2
Stable tag: 1.3

Comments Manager for multi-author blogs, where each author can manage comments posted on his/her articles.

== Description ==

This is useful for multi-author blogs where each author can manage comments posted on his/her articles.
S/he can see all comments on one screen to which s/he hasn't replied.

Though it is developed originally for multi-author blog, single-author blog user can also benefit from this as using this plugin will always give you list of unreplied comments on a single screen.

Any comment to which you post a reply, or choose to ignore (see screenshot) will automatically disappear form unreplied comments list.

== Installation ==
1. Download the zip and unzip it.
2. Upload "my-comments-manager" directory into WordPress plugins directory i.e. "wp-content/plugins" (For WPMU: wp-contents/mu-plugins) .
4. Go to "Dashboard >> Plugins" menu and activate "My Comments Manager".
5. You can access My Comments Manager from "Dashboard >> Comments >> My Comments Manager".


That's it ... Have fun!

== Screenshots ==

1. My Comments Mangaer Admin Menu
2. Link to Unreplied Comments in Edit Comments
3. Menu in My Comments Manager
4. Ignore button in My Comments Manager
