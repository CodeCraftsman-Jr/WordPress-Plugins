
=== LMB^Box Comment Quicktags 2.4 ===

Plugin: LMB^Box Comment Quicktags
Plugin URI: http://aboutme.lmbbox.com/lmbbox-plugins/lmbbox-comment-quicktags/
Description: Inserts a quicktag toolbar in the blog comment form.
Version: 2.4 <img src="http://aboutme.lmbbox.com/plugins-updates.php?plugin=lmbbox-comment-quicktags&amp;version=2.4" alt="Checking For Updates ..." title="Checking For Updates ..." />
Author: Thomas Montague
Author URI: http://aboutme.lmbbox.com

LMB^Box Comment Quicktags -> Was WP Comment Quicktags Plus!
version 2.4 2006-02-08
By Thomas Montague

This Plugin is modified code from Owen Winkler's Comment Quicktags Plugin
****** Plugin Info ********
Plugin Name: Comment Quicktags
Plugin URI: http://www.asymptomatic.net/wp-hacks
Description: Inserts a quicktag toolbar on the blog comment form.
Version: 1.0
Author: Owen Winkler
Author URI: http://www.asymptomatic.net


== Upgrade Notice ==

If upgrading from version 2.0 or earlier of LMB^Box Comment Quicktags, you MUST ...

1. Please refer to Step 4 of the Installation Section in the main readme.txt file.
2. The Styles have been modified and need to be updated in your theme's styles.css file!

== End of Upgrade Notice ==


=== End of LMB^Box Comment Quicktags ===

