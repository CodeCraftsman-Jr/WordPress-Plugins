comment-approved
================

 This WordPress plugin will sent out a customizable notification to a user that has left an comment on your site after approval of the comment. It's a tiny plugin which I hope to expand in the near future. Let me know if you miss something.

Icon by Max Steenbergen / maxsteenbergen.com