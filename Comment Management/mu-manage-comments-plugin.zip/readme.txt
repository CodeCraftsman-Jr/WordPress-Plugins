=== MU Manage Comments Plugin ===
Tags: MU, Comments, Moderation
Donate link: http://www.blogseye.com/buy-the-book/
Requires at least: 2.8
Tested up to: 3.3
Contributors: Keith Graham
Stable tag: 1.0

Lists on one page unmoderated and spam comments for all MU blogs for moderation.

== Description ==
Conveniently shows a list of blogs with spam or unmoderated comments so that the Network Administrator can manage the the comments on network blogs. The list shows counts by blog with links to each comment.

Installations with very large numbers of networked blogs will have trouble with this plugin in that PHP may time out before the plugin completely loads. This is best used on small to moderate sized MU installations.

If the Stop Spammer Registration Plugin is installed, it also allows admins to report spam to the SFS database.

== Installation ==
1. Download the plugin.
2. Upload the plugin to your wp-content/plugins directory.
3. Activate the plugin.
only visible to Network Administrators

== Changelog ==

= 1.0 =
* initial release 


== Support ==
This plugin is free and I expect nothing in return. If you wisht to support my programming, buy my book: 
<a href="http://www.blogseye.com/buy-the-book/">Error Message Eyes: A Programmer's Guide to the Digital Soul</a>
Other plugins:
<a href="http://wordpress.org/extend/plugins/permalink-finder/">Permalink Finder Plugin</a>
<a href="http://wordpress.org/extend/plugins/open-in-new-window-plugin/">MU Manage Comments Plugin</a>
<a href="http://wordpress.org/extend/plugins/kindle-this/">Kindle This - publish blog to user's Kindle</a>
<a href="http://wordpress.org/extend/plugins/stop-spammer-registrations-plugin/">Stop Spammer Registrations Plugin</a>
<a href="http://wordpress.org/extend/plugins/no-right-click-images-plugin/">No Right Click Images Plugin</a>
<a href="http://wordpress.org/extend/plugins/collapse-page-and-category-plugin/">Collapse Page and Category Plugin</a>
<a href="http://wordpress.org/extend/plugins/custom-post-type-list-widget/">Custom Post Type List Widget</a>

