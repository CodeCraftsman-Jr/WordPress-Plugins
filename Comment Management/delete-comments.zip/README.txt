=== Delete Comments ===
Contributors: gaurav.mittal
Donate link: http://gauravmittal.in/index.php/donate/
Tags: admin, comments, delete, delete comments, mass delete, mass delete comments, pending, plugin, spam
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 This plugin comes with feature that allow to delete the comments based on category,users or all at once. It's best for victims of spammer attacks

== Description ==

This plugin comes with very feature that allow to delete the comments based on category, users or all at once. It's best for victims of spammer attacks. This plugin allows admin to delete comment as needed by them. Additional to this comments can be deleted via Dashboard or Admin Panel.

If you don't spammy comments at your site then this plugin is best for you. Well wordpress do come with a feature which all you to selectively disable comments on individual posts. Well if  you don't know how to disable comments on individual posts, there are instructions in the FAQ. Else you can contact our support team we are 24/7 available to guide you and give best solution. 

If you come across any bugs or have suggestions related the plugin, then please use the plugin support forum.Our team will help you in the best way and resolve the issue.

**Main Features:**

*   Remove All Comments
*   Remove Comments Category Wise
*   Remove Comments By user



**Coming soon**
* Filter spam comments *

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `gm-delete-comments.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Tools > Delete Comments

== Frequently Asked Questions ==

= What "Remove All Comments" Can Do =

This will remove all comments from blog/website, also from database.

= What about "Remove Category Wise"? =

This will delete comments category wise e.g delete comments from post which relates to that category.

= What about "Remove Comments By User"? =

This will delete comments of that particular user.

== Screenshots ==

1. Delete Comments From Here

== Changelog ==

= 1.0 =
Release Date: August 1, 2015

* Initial release

== Upgrade Notice ==

= 1.0 =
Release Date: August 1, 2015

* Initial release

== A brief Markdown Example ==

1. Remove All Comments
1. Remove Category Wise
1. Remove Comments By User
