=== Comments Count Filter ===
Contributors: Ainun Nazieb
Tags: posts, comments
Tested up to: 3.0
Requires at least: Maybe All
Stable tag: 1.1

Makes the comments from post author not to be counted

== Description ==

Makes the comments from post author not to be counted in each post comments number.
Note: the post author must login before giving a comment.

== Installation ==

1. Upload `comments_count_filter.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.1 =
* Now filter emails too, so post author doesn't need to login before posting comment to get filtered

= 1.0 =
* Initial release