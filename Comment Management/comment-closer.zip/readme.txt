=== Comment Closer ===
Plugin Name: Comment Closer
Plugin URI: http://www.swarmstrategies.com/comment_closer
Text Domain: comment_closer
Description: This plugin resolves the <i/> problem with formatting tags in comments.
Author: Matt Parrott
Author URI: http://www.swarmstrategies.com/matt
Donate URI: http://www.swarmstrategies.com/
Version: 0.1.1
Last change: 10.26.2011
Licence: GPL2
Tags: comment, overrun, tag
Requires at least: 3.2
Tested up to: 3.2
Stable tag: 0.1.0

== Description ==
This plugin resolves the <i/> problem with formatting tags in comments.

= Requirements =
1. WordPress version 3.2 and later
1. PHP 5

== Installation ==
Standard, no settings.

== Screenshots ==

== Frequently Asked Questions ==

== Other Notes ==

= Acknowledgements =

== Changelog ==

= v0.1.1 (10/26/2011) =
* complety new code