=== Liz Comment Counter by Ozh ===
Contributors: ozh
Tags: comment, comments, badge, ozh, widget, liz, liz strauss, lorelle, social
Donate link: http://planetozh.com/exit/donate
Requires at least: 2.8
Tested up to: 9.9
Stable tag: trunk

A highly configurable badge to show off the number of comments your blog has.

== Description ==

**Liz Strauss Comment Counter** is a highly configurable badge (very similar to the Feedburner one, except it's more configurable) to show off the number of comments your blog has.

This plugin was made in celebration of [Liz Strauss](http://www.successful-blog.com/) dedication to blog community building so you, too, can show the world how social your blog is.

For a more detailed documentation and screenshots of the interface, please visit its official page: [Liz Comment Counter](http://planetozh.com/blog/my-projects/liz-strauss-comment-count-badge-widget-wordpress/ "Liz Comment Counter by Ozh")

**Tip:** To keep track of this plugin's evolution and features, you are advised to subscribe to the [author's feed](http://planetozh.com/exit/feed)

Ho, and if you like this plugin, please rate it 5 stars! :) -------------------->

== Screenshots ==

1. The admin interface is very flexible
2. The color picker is totally neat
3. Featuring a variety of color presets if you're lacking color ideas

== Installation ==

1. Unzip & upload the plugin directory inside your `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to 'Widgets' and configure
