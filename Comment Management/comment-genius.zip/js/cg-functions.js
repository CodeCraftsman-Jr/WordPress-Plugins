jQuery(document).ready(function($){
    $('.cg_colorPicker').wpColorPicker();
});
