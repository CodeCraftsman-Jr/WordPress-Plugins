=== MDC Comment Toolbar ===
Contributors: mukto90, medhabidotcom
Donate link: http://mukto.medhabi.com/
Tags: comment, comment editor, comment wysiwsg, media uploader, media comment, comment photo upload, mdc
Version: 1.1
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

MDC Comment Toolbar enables rich editor toolbar with media uploader in comment field.

== Description ==

MDC Comment Toolbar enables rich editor toolbar with media uploader in comment field.

== Installation ==

1. Upload the `mdc-comment-toolbar` folder and its contents to your `wp-contents/plugins` directory.
2. Activate in the `Plugins` menu.
3. Configure from WordPress admin area.
4. You are done!

== Screenshots ==

1. Configure page
2. Comment form in Twenty Thirteen theme.
3. Download page with different video formats