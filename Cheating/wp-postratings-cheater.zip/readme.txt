=== WP-PostRatings Cheater ===
Contributors: queeez
Donate link: https://sites.google.com/site/manfredfettinger/divers/wordpress
Tags: WP-PostRatings, Ratings Cheat, Cheating, Post Ratings Cheating
Requires at least: 2.8
Tested up to: 3.4.1
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is an enhancement to the famous WP-PostRatings Plugin by Lester 'GaMerZ' Chan -
Set rating values as you like!

== Description ==

If you are tired to endure the bad reviews of your articles or nobody wants to review them, then do it yourself! 
You can choose the values of ratings, users and average ratings of your own easily with this plugin
It only works with the plugin "WP-PostRatings" (checked with Version 1.72 of it)


== Installation ==

1. Upload directory `wp-postratings-cheater` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to `WP-Admin -> Ratings Cheater`


== Frequently Asked Questions ==

= I get the message 'Plugin WP-PostRatings seems not to be active' =

Please ensure that you have the WP-PostRatins Plugin installed and activated! This plugin is only an enhancement to this!

= What about the version of the WP-PostRatings Plugin =

This plugin was developed and testet with version 1.72 of WP-PostRatings. If you have troubles with a lower version, please update to the newest.
If you have troubles with a higher version of WP-PostRatings, please contact me.

= How to change ratings =

Please change the average value - this is the value of the stars. Also you have to enter the number of users rated. The score is calculated from average value * users


== Upgrade Notice ==

Before upgrading deinstall and install afterwards new!


== Screenshots ==

1. Admin - Settings Menu

== Changelog ==
= Version 1.5 (21-04-2015) =
* FIXED: Bug when using other database prefix
		 Thanks to user mlloret
= Version 1.4 (07-08-2013) =
* FIXED: Fixed bug - PHP Parse Error in some cases
         Fixed buc - Star rating does not change after a user gave real rating

= Version 1.3 (03-01-2013) =
* FIXED: Fixed bug - before only rating of latest article could be changed

= Version 1.2 (03-01-2013) =
* FIXED: Fixed bug - before only rating of latest article could be changed

= Version 1.0 (11-11-2012) =
* Initial Release





