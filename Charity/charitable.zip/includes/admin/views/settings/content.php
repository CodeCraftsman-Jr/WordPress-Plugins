<?php
/**
 * Display section heading in settings area.
 *
 * @author  Studio 164a
 * @package Charitable/Admin Views/Settings
 * @since   1.0.0
 */

echo $view_args[ 'content' ];
?>