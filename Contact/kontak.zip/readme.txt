=== Kontak ===
Contributors: tekinoypi
Donate link: http://tekinoypi.com/
Tags: captcha, kontak ,contact form, contact form plugin, contact me, contacts, contacts form plugin, kontak form, copy, feedback, feedback form, form, request, text
Requires at least: 3.0.0
Tested up to: 3.3.1
Stable tag: trunk

Kontak is a free contact form plugin that is coded in HTML5 / CSS3 and has CAPTCHA that does not use PHP sessions. Messages are sent by email.

== Description ==

<p>Kontak is a Wordpress&nbsp;contact form&nbsp;plugin that has the following features:</p>
<ul>
<li>Coded in HTML5</li>
<li>Enable/Disable Captcha</li>
<li>Captcha is not using PHP sessions</li>
<li>Customizable fields:&nbsp;                    
<ul>
<li>Subject for email</li>
<li>FROM and TO email headers</li>
</ul>
</li>
<li>(Optional) Customize CSS.</li>
</ul>

<p>View demos:&nbsp;</p>
<ul>
<li><a target="_blank" href="http://racketroll.com/wp-plugins/">http://racketroll.com/wp-plugins/</a> </li>
<li><a target="_blank" href="http://www.onegirlfactory.com/" title="Lynn Lopez's portfolio">http://www.onegirlfactory.com/</a></li>
</ul>

<p>More Info</p>
<ul>
<li><a target="_blank" href="http://tekinoypi.com/articles/binary-matters/post/75/kontak-web-form">Kontak Web Form</a> </li>
</ul>

== Installation ==

1. Go to WP admin site to install plugin and activate
2. Click on the "Kontak" link at the bottom left navigation/menu
3. Customize the following required field values: FROM and Recipient's email address
4. On the page wherein you want to see the contact form just paste the value that's in the "Shortcode Name". The default is "[kontak-web-form]".
5. Test and enjoy.


== Frequently Asked Questions ==

= I'm confused what email address should I use for the FROM field? =

Most web hosting services require that you use an email address that has the same domain name with your site, wherein your Wordpress site is installed.
For example, if your website is located at this URL http://www.yoursite.com, then the email address for the FROM email header should be something like , admin@yoursite.com.

== Frequently Asked Questions ==

= I'm confused what email address should I use for the FROM field? =

Most web hosting services require that you use an email address that has the same domain name with your site, wherein your Wordpress site is installed.
For example, if your website is located at this URL http://www.yoursite.com, then the email address for the FROM email header should be something like , admin@yoursite.com.

= What about the Recipient's email? =

This email address is where messages would be sent, and would be used for the "TO" header value. You can type in your Gmail, Yahoo Mail email address here.

= Where can I get support and report bugs? =

Send me a message please http://www.tekinoypi.com/contact/.

== Screenshots ==

1. Kontak administration page to screenshot-1.jpg.
2. Kontak web form to screenshot-2.jpg.

== Changelog ==

= 1.0 =
* Initial release.
