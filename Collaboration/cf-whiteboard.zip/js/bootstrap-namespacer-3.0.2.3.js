;
(function($) {
	$.fn.bootstrap_modal = $.fn.modal.noConflict();
	$.fn.bootstrap_dropdown = $.fn.dropdown.noConflict();
	$.fn.bootstrap_scrollspy = $.fn.scrollspy.noConflict();
	$.fn.bootstrap_tab = $.fn.tab.noConflict();
	$.fn.bootstrap_tooltip = $.fn.tooltip.noConflict();
	$.fn.bootstrap_popover = $.fn.popover.noConflict();
	$.fn.bootstrap_affix = $.fn.affix.noConflict();
	$.fn.bootstrap_alert = $.fn.alert.noConflict();
	$.fn.bootstrap_button = $.fn.button.noConflict();
	$.fn.bootstrap_collapse = $.fn.collapse.noConflict();
	$.fn.bootstrap_carousel = $.fn.carousel.noConflict();
	// $.fn.bootstrap_typeahead = $.fn.typeahead.noConflict();
})(window.jQuery);
