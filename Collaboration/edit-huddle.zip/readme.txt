=== Edit Huddle ===
Contributors: Tim Barsness mark@edithuddle.com
Tags: edithuddle
Requires at least: 2.0
Tested up to: 3.2
Stable tag: 2.5.3
License: GPLv2 or later

