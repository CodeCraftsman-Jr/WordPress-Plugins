=== Invoiced WP ===
Author URI: http://inoicedwp.com
Plugin URI: http://inoicedwp.com
Contributors: rpletcher
Donate link: http://ryanpletcher.com/support-the-site
Tags: invoice, e-downloads, ecommerce, e commerce, e-commerce, invoicing, billing, wp-ronin, wp ecommerce, invoiced
Requires at least: 3.7
Tested up to: 4.1

Stable Tag: 1.1.0

License: GNU Version 2 or Any Later Version

The Most effective way to Get Paid by your clients.  Create it directly from your website.

== Description ==

The Most effective way to Get Paid by your clients.  Rather that using a spreadsheet or word processor sent through to get your invoices to your customers Invoiced WP makes the creation of invoices faster and easier.  Send it directly from your webiste and get paid.


Features of the plugin include:

* Create Invoices
* Create Quotes
* Paypal or Manual Payments
* Complete payment history
* Customize Invoices
* Create discount
* Line Item or Invoice templates
* Extensible with many [add-ons](http://invoicedwp.com/addons/) Coming Soon.
* Developer friendly with dozens of actions and filters. [Support](http://invoicedwp.com/support)

Automatic emailing coming soon

More information at [Invoiced WP.com](https://inoicedwp.com/).

**Follow this plugin on [GitHub](https://github.com/rpletcher/invoicedWP)**

**Languages**

InvoicedWP is offered in the following lanquages:

1. English

Would you like to help translate the plugin into more languages? Let us know.

== Installation ==

1. Activate the Plugin
2. Go to the permalink settings and hit the save button with no changes
3. Start Creating invoices by accessing the InvoicedWP menu on the left
4. Access the options to configure the invoice the way that you want
5. Start creating invoices

== Frequently Asked Questions ==




== Screenshots ==

1. Sample Invoice
2. Create invoice
3. Currencies offered
4. Save data
5. Extra Options
6. Use templates

== Changelog ==
= 1.1.0: May 25, 2015 =

*ADD: Permalink options added
*FIX: General fixes and spelling corrections


= 1.0.1: April 20, 2015 =

* First offical release!
