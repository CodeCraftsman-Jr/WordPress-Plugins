# InvoicedWP
### The Most effective way to Get Paid by your clients

This is the public repository of _InvoicedWP_, the most effective way to Get Paid by your clients by making sure your customers can access their invoice anywhere.

#### Bug Reports
If you are a user looking for Techincal Support, please use the ['Support'](http://invoicedwp.com/support/) section of the website. This repository is for development related issues and tracking only. If you request support in this arena, you will be asked to visit the following page.

http://invoicedwp.com/support/

To Setup invoicedWP, do the following:

1. Download the repository

2. Access your Wordpress Site.

3. Go to plugins and choose the option to add New

4. Choose to Upload Plugin and find the zip you downloaded

5. Start Creating invoices by accessing the InvoicedWP menu on the left
