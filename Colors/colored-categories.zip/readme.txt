=== Colored Categories ===
Contributors: Mountianinja, Brandon Camenisch
Donate link:http://www.brandoncamenisch.com
Tags: Categories, Taxonomies, Color, Colored, Category
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Use this plugin to attach a color to each of your categories, Great for creating a distinguishing look for each category on your site.

== Description ==

Use this plugin to attach a color to each of your categories, Great for creating a distinguishing look for each category on your site.

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
== Screenshots ==
1. This is a screenshot close up of the colored cateogries.

2. Fullscreen view from the category screen.

updates version 1.5

Delete the option from array on category deletion

Better handling of id's when a new category is created

Better Security for ajax requests using nonces

