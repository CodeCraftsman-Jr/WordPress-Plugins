=== Snippet Highlight ===
Contributors: wpdprx
Donate link: http://wordpress.designpraxis.at/
Tags: post, Formatting, snippet, code, highlighting, line numbering, 
Requires at least: 2.1
Tested up to: 2.3.1

Highlights your code snippets. With line numbering.

== Description ==

After reading about Dean Edwards star-light syntax highlighting library on phpblogger.net,
I decided to turn the results of their tutorial into a WordPress Plugin called Snippet-Highlight.


== Installation ==

1. download and unzip
2. upload plugin folder into yourWordPress plugin directory
3. activate the plugin
4. paste your code into your post between &lt;pre&gt;&lt;/pre&gt; tags

== Notes ==

Beware of multiple php start and end tags!

