=== Medicare Quote Widget ===
Contributors: trevhud, eHealth Medicare
Donate link: http://www.ehealthmedicare.com
Tags: Medicare, eHealth, eHealthMedicare
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.4
License: GPLv2 or later

Medicare Quote Widget helps visitors get Medicare quotes.

== Description ==

Medicare Quote Widget allows site owners to display a form that sends a zip code to the eHealth Medicare census page so that visitors can get Medicare quotes.

*Note: This plugin calls back to http://www.ehealthmedicare.com for data. It uses a "post" function to send the zip code entered into the widget to the eHealth Medicare census page.

== Installation ==

Upload the Medicare Quote Widget plugin to your blog, and activate it in the plugins section.

Go to Appearance/widgets to add the Medicare Quote Widget to your blog. You can drag it from "Available Widgets" to your widget area.

== Frequently Asked Questions ==

How do I find out more information about Medicare?

You can go to www.medicare.gov or www.ehealthmedicare.com to learn more about the Medicare program.

== Changelog ==

Added assets 4/24/2013
Fixed styling 5/2/2013

== Upgrade Notice ==

Please email trevor.hudson@ehealth.com for upgrade suggestions.

== Screenshots ==

This is how the widget looks in a sidebar.