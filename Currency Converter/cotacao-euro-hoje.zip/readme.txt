=== Plugin Name ===
Contributors: febeckers
Donate link: http://www.cotacaoeurohoje.com/
Tags: cotação euro, euro hoje
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cotação do Euro em relação ao Real (moeda do Brasil). Tenha a cotação do euro em seu site - atualizado diariamente direto do site do Banco Central do Brasil.

== Description ==

Cotação do Euro em relação ao Real (moeda do Brasil). Tenha a cotação do euro em seu site - atualizado diariamente direto do site do Banco Central do Brasil.

== Installation ==

1. Faça o download do arquivo compactado;
 1.1 - Você pode subir pelo seu painel do Wordpress. Vá em: Plugins -> Adicionar Novo -> Fazer Upload do Plugin (compactado);
 1.2 - Você pode subir pelo FTP. Descompacte o plugin e envie a pasta do Plugin Cotação Euro para o diretório "Plugins";

2. Ative o Plugin em seu painel no Wordpress

3. Inclua o plugin na sidebar do seu blog
 3.1 - Vá até Aparência -> Widgets. Lá você verá aopção "Cotação Euro Hoje". Arraste para a sua lista de itens da sidebar;
 3.2 - Sugestão: Sugerimos o plugin "Widget CSS Classes". Com ele, você pode definir uma classe (css) e customizar da forma como você desejar (para deixar ainda mais parecido com seu layout);

== Frequently Asked Questions ==

= A cotação é pega onde? =
Diretamente do site do banco central através de um webservice.

= Qual a origem da informação? =
A consulta é feita diretamente no site do Banco Central (através de um webservice);

= A Atualização é com qual frequência? =
Diariamente, o valor da cotação do euro é atualizado automaticamente;

= Preciso pagar algo para utilizar o plugin? =
Não, ele é gratuito. Basta que você deixei o link para o desenvolvedor do plugin;

= Preciso enviar meu dados para utilização? =
R.: Não, basta fazer o download no site wordpress.org

= Meu site tem cunho comercial, poso utilizar gratuitamente o plugin? =
R.: Sim, ele é gratuito. Basta que você deixei o link para o desenvolvedor do plugin;

= Estou com dúvidas, para quem devo escrever? =
R.: febeckers@gmail.com

== Screenshots ==

1.  Após subir os arquivos, vá até a lista de plugins e faça a ativação;
2. Vá até Aparência -> Widgets. Veja a opção "Cotação Euro Hoje" entre seus widgets;
3. Arraste-o até sua lista de widgets ativas na sidebar (pode ser no rodapé, cabeçalho e onde mais estiver ativo suas widgets)

== Changelog ==

- Correção de textos: Readme.txt 
- Correção de codificação BOM
- Correçõe de textos

== Arbitrary section ==

== A brief Markdown Example ==