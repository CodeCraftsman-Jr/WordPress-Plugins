# agp-font-awesome-collection

The latest Font Awesome icons with HTML and shortcodes usage, dynamic visualizer for TinyMCE, promotion widget and other features in the one plugin

# Installation

1. Download a copy of the plugin
2. Unzip and Upload 'AGP Font Awesome Collection' to a sub directory in '/wp-content/plugins/'.
3. Activate the plugin through the 'Plugins' menu in WordPress.
