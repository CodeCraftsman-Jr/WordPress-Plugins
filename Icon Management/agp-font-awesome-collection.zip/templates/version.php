<?php
    $version = Fac()->getIconRepository()->getVersion();
?>
<div class="fac fac-version-template">
    Font Awesome Version <span><?php echo $version;?></span>
</div>
