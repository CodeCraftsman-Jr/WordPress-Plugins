<?php
    $args = $params;
?>
<div class="fac-constructor-preview">
    <h2>Preview</h2>
    <div class="fac-constructor-preview-container"></div>    
    <div class="fac-constructor-spinner">
        <img src="<?php echo Fac()->getAssetUrl('images/spinner.gif');?>"/> 
    </div> 
    
</div>


