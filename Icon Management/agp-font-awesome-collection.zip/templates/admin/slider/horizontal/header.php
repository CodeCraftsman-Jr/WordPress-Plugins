    <th>Headline</th>
    <th>Description</th>
    <th>Icon</th>    
    <th>Link URL</th>
    <th>Text Color</th>
    <th>Background Color</th>    
    <th class="tbl-actions">Actions</th>
