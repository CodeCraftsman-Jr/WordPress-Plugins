<?php
namespace Agp\FontAwesomeCollection\Core;

class Agp_DbConnectException extends Agp_ExceptionAbstract {
}


