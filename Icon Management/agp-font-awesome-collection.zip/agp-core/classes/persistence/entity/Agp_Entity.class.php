<?php
namespace Agp\FontAwesomeCollection\Core;

class Agp_Entity extends Agp_EntityAbstract {
}
