    <th>Title</th>
    <th>Description</th>
    <th width="170px" class="tbl-actions">Actions</th>
