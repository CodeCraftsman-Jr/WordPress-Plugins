<?php
return array(
    'template' =>'Blank',
    'displayName' => 'Blank',
    'fields' => array(
    ),
);
