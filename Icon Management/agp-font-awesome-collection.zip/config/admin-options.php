<?php
return array(
    'page' => 'fac-settings',
    'title' => 'AGP Font Awesome Collection Settings',
    'tabs' => include (__DIR__ . '/admin-options-tabs.php'),
    'fields' => include (__DIR__ . '/admin-options-fields.php'),
    'fieldSet' => include (__DIR__ . '/admin-options-fieldset.php'),
);