<?php
return array(
    'fac-global-settings' => array(
        'title' => 'Turning on modules',
    ),
);