<?php
return array(
    'template' =>'version',
    'displayName' => 'Current Version',
    'developerOnly' => TRUE,    
    'fields' => array(),
);
