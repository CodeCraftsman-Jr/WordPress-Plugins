<?php
return array(
    'shape_type' => array(
        'rounded' => 'Rounded',
        'round' => 'Round',
        'square' => 'Square',        
    ),
    'slider_types' => array(
        'default' => 'Default',
    ),
    'link_target' => array(
        '_self' => '_self',
        '_blank' => '_blank',
        '_parent' => '_parent',
        '_top' => '_top',        
    ),    
    'align' => array(
        'center' => 'Center',        
        'left' => 'Left',        
        'right' => 'Right',        
    ),
    'shortcodes' => array( 'Fac_Settings', 'getCustomShortcodesFieldSet' ),
    
);