=== Textiler ===
Contributors: iwongu
Tags: post, formatting, textile
Requires at least: 2.0
Tested up to: 2.2
Stable tag: 1.1

This plugin supports Textile syntax for posts.

== Description ==

This plugin supports *Textile* syntax for posts. It's just a thin wrapper of *Textile 2.0.0*.

1. The Textile syntax works only in between '{{{'  and '}}}.' A single post can have one or more Textiler blocks. But usually a full post might be in a block.
1. To see all supported Textile syntax, go [Textiler plugin test page](http://ideathinking.com/blog-v2/?p=44) or [Textile
page](http://textile.thresholdstate.com/).

= Preview =

* [Textiler plugin test page](http://ideathinking.com/blog-v2/?p=44)


== Installation ==

1. Unzip the plugin archive.
1. Upload the directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

