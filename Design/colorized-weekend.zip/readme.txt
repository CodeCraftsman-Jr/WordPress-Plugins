=== Colorized Weekend ===
Contributors: V.J.Catkick
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2933164
Tags: function, color, weekend, date string
Requires at least: 2.6
Tested up to: 2.8.1
Stable tag: 4.3

This plugin adds color tags on your date string.

== Description ==

Replacable function 'the_time_colored()' works exactly same as original fuction 'the_time()' but it adds span tag with color code and classes before its string so you can modify its color by using with control panel.

This function also adds class names for each span tags so not only weekend, you can add CSS to color them.

== Installation ==

Place the file in your /wp-content/plugins/ directory
and activate through the administration panel.

After that, modify 'the_time()' function to 'the_time_colored()'.
*no need to modify its arguments.

Then at control panel, turn each switch on.

== Frequently Asked Questions ==

== Screenshots ==

