=== Colorful Post ===
Contributors: Jason Zhao
Donate link: http://psd.to-html.com
Tags: post, posts, plugin, widget, admin, colorful posts, color title, title, post title
Requires at least: 3.3
Tested up to: 4.3
Stable tag: 1.0.3
License: GPLv2 or later

A simple 'post title color' plugin that lets you select the color of your post title manually.

== Description ==

A simple 'post title color' plugin that lets you select the color of your post title manually.


Features:

* Add a color picker just under your post title in editor mode
* Option to reset all colors to default with one click

== Installation ==

**Option 1 - Automatic install**

Use the plugin installer built into WordPress to search for the plugin. WordPress will then download and install it for you.

**Option 2 - Manual install**

1. Make sure the files are within a folder.
2. Copy the whole folder inside the wp-content/plugins/ folder.
3. In the backend, activate the plugin. You can now select related posts when you create or edit blog posts, pages etc.

== Frequently Asked Questions ==

= Where can I find the color picker =

It's just under the post title in post editor

== Screenshots ==


== Changelog ==
= 1.0.3 =
* 2015-10-14
* Fix version issue

= 1.0.2 =
* 2015-09-05
* Updated readme text

= 1.0.1 =
* 2015-08-17
* Fixed various text inaccuracies

= 1.0.0 =
* 2015-08-01
* Initial release. No known issues.

== Upgrade Notice ==

Either let WordPress do the upgrade or just overwrite the files.
