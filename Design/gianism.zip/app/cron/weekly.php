<?php

namespace Gianism\Cron;


abstract class Weekly extends Daily
{

    const INTERVAL = 'weekly';



} 