<?php

namespace Gianism\Cron;


abstract class Monthly extends Daily
{
    const INTERVAL = 'monthly';


} 