=== Fonts ===
Contributors: wordpresssites
Donate link:http://wpsites.net/donate-to-wp-sites/
Tags: fonts,font,wysiwyg
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add More Font Styles & Sizes To Your Visual Editor in WordPress

== Description ==

This plugin adds 2 drop down menus to your visual editor with additional sizes and fonts:

1. A button for Styles
2. A button for Sizes

New: You can also add your own selection of Google or Custom fonts including premium fonts, to your editor:



Add Google fonts http://wpsites.net/wordpress-admin/add-google-web-fonts-to-your-wordpress-editor/


Add custom fonts http://wpsites.net/wordpress-themes/add-custom-fonts-to-the-wordpress-editor/
 

== Screenshots ==

1. This is the Font Family menu

2. This is the Font Sizes menu
