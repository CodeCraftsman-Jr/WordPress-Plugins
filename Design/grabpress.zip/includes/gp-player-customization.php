        <div style="display:none;" id="dialog-form"  title="Customize your player">
          <span class="gp-popup-description">
            <p>To maximize pre-roll ad revenue, set player to Auto-Play, with a width of 400 pixels or higher.</p>
          </span>
          <form>
            <fieldset>

              <div class="auto-play"><input type="checkbox" name="autoplay" checked id="autoplay" />Auto-Play</div>
              <div class="gp-emdeg-width">
                <label for="p_width">Width</label><br /><input style="width:250px;" type="text" name="p_width" id="p_width"><br />
              </div>
              <div class="gp-emdeg-height">
                <label for="p_height">Height</label><br><input style="width:250px;" type="text" name="p_height" id="p_height" ><br><br />
              </div>
              <div class="embed_code" style="display:none;font-size:10px;width:250px;margin-bottom:0px;"></div>
              <br />
            </fieldset>
          </form>

        </div>   