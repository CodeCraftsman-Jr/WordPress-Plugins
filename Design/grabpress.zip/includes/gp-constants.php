<?php
define( 'CURRENT_VERSION', '3.0.3' );
define( 'PRODUCTION_ENV', 'grabnetworks' );
define( 'DEVELOPMENT_ENV', 'grabqa' );
define( 'GP_USER', 'grabpress' );
define( 'GP_JP_LASTEST_STABLE', 'http://downloads.wordpress.org/plugin/jetpack.latest-stable.zip' );
define( 'GP_PRODUCT_TYPE_ID', '3');
define( 'GP_VIP_PRODUCT_TYPE_ID', '4');
