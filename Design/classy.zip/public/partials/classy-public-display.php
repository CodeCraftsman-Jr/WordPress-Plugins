<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://mediacause.org
 * @since      1.2.3
 *
 * @package    Classy
 * @subpackage Classy/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
