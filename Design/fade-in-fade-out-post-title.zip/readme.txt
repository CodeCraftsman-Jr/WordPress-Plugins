=== Fade in fade out post title ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/
Author URI: http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/
Plugin URI: http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/
Tags: fade, fade in, fade out, plugin, widget
Requires at least: 3.4
Tested up to: 4.2.2
Stable tag: 9.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
Fade in fade out post title wordpress plugin; With this plugin display the post title with fade in fade out effect.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/](http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/)

*   [Live Demo](http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/)	
*   [More info](http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/)				
*   [Comments/Suggestion](http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/)		
*   [About author](http://www.gopiplus.com/work/)			

Everyone loves fading in and fading out; it is an excellent way to transition between two messages, Fade in fade out post title word press plugin retrieve the post tile as per your selection and create the fade in and fade out message galley into the website.

**Features of this plugin**

*   Widget option.
*   Easy to customize.
*   Short code available for page.
*   Short code available for post.

[Click here](http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/) to see detail information about this plugin.	

**Plugin configuration**

*   Drag and drop the widget.		
*   Add directly in the theme.		
*   Short code for posts and pages.		
	
== Installation ==

[See Installation Instruction and Configuration information and Demo](http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/)	   

== Frequently Asked Questions ==

1. How to arrange the plugin fade-in setting?

2. Is possible to add the plugin more than one time in the same post or page?

3. How to change the fade-in text CSS?	

[Answer page](http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/)			

== Screenshots ==

1. http://www.gopiplus.com/work/2011/07/31/fade-in-fade-out-post-title-wordpress-plugin/

== Changelog ==

= 1.0 =			

First version.

= 2.0 =						

Small short code bug fixed.

= 4.0 =

Reset Query issue has been fixed.
Tested up to 3.3

= 5.0 =

Tested up to 3.4

= 6.0 =

Tested upto 3.4.1
JavaScript loaded by using the wp_enqueue_scripts hook (instead of the init hook), This will avoid the JavaScript, Jquery conflict.
Slight changes in the short code implementation, but no need to change the short code.

= 7.0 =

New demo link, http://www.gopiplus.com

= 8.0 =

Tested up to 3.4.2

= 8.1 =

Tested up to 3.5

= 9.0 =

Tested up to 3.6
Added some security feature.

= 9.1 =

Tested up to 3.7 beta1
Option to switch plugin into 4 different language (english, dutch, french, german).  BETA try.

= 9.2 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (fifoposttitle.po) available in the languages folder. Translators Welcome.

= 9.3 =

1. Tested up to 3.9

= 9.4 =

1. Tested up to 4.0

= 9.5 =

1. Tested up to 4.1

= 9.6 =

1. Tested up to 4.2.2

== Upgrade Notice ==

= 1.0 =				

First version.

= 2.0 =						

Small short code bug fixed.

= 4.0 =

Reset Query issue has been fixed.
Tested up to 3.3

= 5.0 =

Tested up to 3.4

= 6.0 =

Tested up to 3.4.1
JavaScript loaded by using the wp_enqueue_scripts hook (instead of the init hook), This will avoid the JavaScript, Jquery conflict.
Slight changes in the short code implementation, but no need to change the short code.

= 7.0 =

New demo link, www.gopiplus.com

= 8.0 =

Tested up to 3.4.2

= 8.1 =

Tested up to 3.5

= 9.0 =

Tested up to 3.6
Added some security feature.

= 9.1 =

Tested up to 3.7 beta1
Option to switch plugin into 4 different language (english, dutch, french, german).  BETA try.

= 9.2 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (fifoposttitle.po) available in the languages folder. Translators Welcome.

= 9.3 =

1. Tested up to 3.9

= 9.4 =

1. Tested up to 4.0

= 9.5 =

1. Tested up to 4.1

= 9.6 =

1. Tested up to 4.2.2