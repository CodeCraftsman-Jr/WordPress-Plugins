(function($){
	$.ajaxPrefilter=function(){console.log("Prefilter!");};
})(jQuery);
