Grid for Wordpress
====

This plugin is a reference implementation which integrates the grid platform into wordpress.
It allows you to build landing pages using grid.


## Setup

To set up grid, copy this to wp-content/plugins/grid/. While we're still developing and there is no final release, you have to ensure, that the grid library (which can be found at https://github.com/palasthotel/grid) lies in wp-content/plugins/grid/lib.

After putting everything in place, simply enable the grid plugin. You will get a set of new menu items and new post types.


## Use

For now, there is no Info on how to use it. I hope we'll be able to change this soon.

## License

GPL v3 - see license.txt
