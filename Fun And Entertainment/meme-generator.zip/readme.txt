=== Meme Generator ===
	Contributors: paratheme
	Donate link: http://paratheme.com
	Tags: meme generator, meme, meme online, 
	Requires at least: 3.8
	Tested up to: 4.2.4
	Stable tag: 1.0
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	Awesome meme generator.

== Description ==
Meme Generator  allows you to add functionality genarate meme's to your WordPress powered website, plug & play use via short-codes anywhere.


### Meme Generator by http://paratheme.com
* [Live Demo! &raquo;](http://paratheme.com/demo/meme-generator/)



<strong>Plugin Features</strong>


* Unlimited sticker or art.
* Text art.
* Meme preview.
* z-index, opacity, rotation of sticker.




== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>Meme Generator</strong>" activate it.<br />

After activate plugin you will see "Meme & Meme Sticker" menu at left side on WordPress dashboard.<br />

<br />
<strong>How to use on page.</strong><br />


Use following short-code to display meme generator anywhere in page content. `[meme_generator]`<br />

before starting you need to add some meme & sticker via custom post "Meme Sticker" with thumbnail image. 






== Screenshots ==

1. screenshot-1
2. screenshot-2
3. screenshot-3
4. screenshot-4
5. screenshot-5
6. screenshot-6



== Changelog ==

	
	= 1.0 =
    * 17/04/2015 Initial release.
