<?php
  
  if(function_exists('add_theme_support')) {
     add_theme_support('post-thumbnails');
     }
  
?>
