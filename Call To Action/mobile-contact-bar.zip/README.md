# Mobile Contact Bar

Welcome to the official repository for Mobile Contact Bar WordPress plugin.



* Website: https://bansaghi.github.io/mobilecontactbar/
* WordPress repository: http://wordpress.org/plugins/mobile-contact-bar/
* GitHub repository: https://github.com/bansaghi/mobile-contact-bar/
* Readme: https://github.com/bansaghi/mobile-contact-bar/blob/master/readme.txt



### Credits

* [WP Color Picker](https://github.com/Codestar/codestar-wp-color-picker) by Codestar
* [Font Awesome](http://fontawesome.io/) by Dave Gandy

