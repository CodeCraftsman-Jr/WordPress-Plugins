=== EURO 2012 Countdown ===
Contributors: Steve
Tags: EURO 2012, football, championship, countdown, informer, widget, plugin
Requires at least: 2.8
Tested up to: 3.0.1
Stable tag: 1.0.1

The widget shows the countdown that left till the start of the Euro 2012 football championship.

== Description ==

For all football fans is dedicated.
And also for those who is looking forward to the start of the Euro 2012 football championship.
You can place this widget on your site and watch the countdown that left till the start.

Look at the screenshots or at the widget website: [euro2012en.500v.net](http://euro2012en.500v.net "EURO 2012 Countdown").

== Installation ==

Typical and easy installation like any other widget.

== Screenshots ==

1. The output of the widget on the site.
