jQuery(document).ready(function($){
	$('.dnxcd_datepicker').datepicker({
		dateFormat : 'dd-mm-yy'
	});
});
