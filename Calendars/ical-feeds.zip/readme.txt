=== iCal Feeds ===
Contributors: maximevalette
Donate link: http://maxime.sh/paypal
Tags: uri.lv, ical, posts, feed, future, calendar, agenda
Requires at least: 3.0
Tested up to: 4.3
Stable tag: 1.2.4

Generate a customizable iCal feed of your present and future blog posts.

== Description ==

With the iCal Feeds WordPress plugin you can have an iCal feed to have your blog posts
(past and future with a customizable secret parameter) in your favorite iCal software: Google Agenda,
Outlook, Hotmail...

== Installation ==

1. Copy the ical-feeds folder into wp-content/plugins
2. Activate the plugin through the Plugins menu
3. Configure your feed from the new iCal Feeds Settings submenu

== Changelog ==

= 1.2.4 =
* Fixed event delay setting.
* Fixed timezone issue.

= 1.2.3 =
* Improved SQL queries.

= 1.2.2 =
* Category feed fix.
* Multiple categories support.

= 1.2.1 =
* Slug fix.

= 1.2 =
* Better at handling timezones.

= 1.1 =
* You can now specify a time interval per blog post.

= 1.0 =
* First version. Enjoy!
