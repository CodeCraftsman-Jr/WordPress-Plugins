<?php

/**
 * Some argument was of invalid type.
 *
 * @author     Time.ly Network Inc.
 * @since      2.0
 *
 * @package    AI1EC
 * @subpackage AI1EC.Model
 */
class Ai1ec_Invalid_Argument_Exception extends Ai1ec_Exception {
}