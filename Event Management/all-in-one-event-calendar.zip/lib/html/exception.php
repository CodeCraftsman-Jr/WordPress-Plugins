<?php

/**
 * Exception which occurs during HTML generation.
 *
 * @author     Time.ly Network, Inc.
 * @since      2.0
 * @package    Ai1EC
 * @subpackage Ai1EC.Exception
 */
class Ai1ec_Html_Exception extends Ai1ec_Exception {
}