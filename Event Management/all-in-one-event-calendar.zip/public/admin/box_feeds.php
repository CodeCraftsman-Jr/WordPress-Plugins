<div class="timely">
	<ul class="ai1ec-nav ai1ec-nav-tabs">
		<?php $calendar_feeds->render_tab_headers() ?>
	</ul>
	<div class="ai1ec-tab-content">
		<?php $calendar_feeds->render_tab_contents() ?>
	</div>
</div>

