<div class="ai1ec-form-group">
  <label for="ai1ec_daily_count" class="ai1ec-control-label ai1ec-col-sm-3">
	  <?php _e( 'Every', AI1EC_PLUGIN_NAME ); ?>:
  </label>
  <div class="ai1ec-col-sm-9">
    <?php echo $count; ?>
  </div>
</div>
