<div class="wrap">
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row">
					<?php _e( 'Successfully imported events:', AI1EC_PLUGIN_NAME ) ?>
				</th>
				<td>
					<?php echo $imported_events ?>
				</td>
			</tr>
		</tbody>
	</table>
</div>
