<?php get_header(); ?>
<div class="event_wrapper">
weewe
</div>
<?php get_footer(); ?>