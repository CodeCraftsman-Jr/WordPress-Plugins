<?php get_header(); ?>
<div class="event_wrapper">
	<?php echo do_shortcode( '[event_calender]' );?>
</div>
<?php get_footer(); ?>