=== Interstrategy Events Manager ===
Contributors: billerickson, gregfarries
Tags: listing, event, events, manager, events-manager
Requires at least: 3.2
Tested up to: 3.2.1
Stable tag: 1.0

Allows you to manage your events. 

== Description ==

More formal documentation is coming, [but here's a start]( http://wordpress.org/support/topic/plugin-interstrategy-events-manager-documentation?replies=5#post-2393218)

== Changelog ==

= 1.0 =
* First version!

== Upgrade Notice ==

= 1.0 =
First version!