<div class="slide_down_box" id="slide_down_box">
    <div class="display">

    </div>
    <div class="incoming" style="display: none;"></div>
    <a href="#" id="dismiss_loader" class="epl_button_small" style=""><span class=""></span><?php epl_e( 'Close' ); ?></a>
</div>

<div id="epl_overlay" class="">
    <div></div>

</div>

<div id ="epl_loader">
    <img  src ="<?php echo EPL_FULL_URL; ?>images/ajax-loader2.gif" alt="loading..." />
</div>