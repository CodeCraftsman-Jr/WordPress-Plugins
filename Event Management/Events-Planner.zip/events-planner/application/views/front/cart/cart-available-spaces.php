<div class="section">
    <div class="clearfix"><?php epl_e('Available Spaces'); ?></div>
    <?php echo $available_spaces_table; ?>



</div>