<table class="epl_prices_table">
    <tr>
        <th>
            <?php

            epl_e( 'Type' );
            ?>
        </th>

        <th>
            <?php

            epl_e( 'Price' );
            ?>
        </th>
        <th>
            <?php

            epl_e( 'Quantity' );
            ?>
        </th>

    </tr>

    
    <?php echo $prices_table; ?>


</table>