
<tr>
    <td>
        <?php

       echo $price_name;
        ?>
    </td>

    <td>
<?php

       echo epl_get_currency_symbol() . $price;
?>
    </td>
    <td>
<?php

       echo  $price_qty_dd['field'];
?>
    </td>

</tr>