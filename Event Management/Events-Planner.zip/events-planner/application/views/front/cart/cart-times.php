<?php if ( isset( $event_time ) ):

    ?>
    <div class="epl_times_wrapper">


        <span>Time: </span>

    <?php echo $event_time; ?>

</div>

<?php endif; ?>