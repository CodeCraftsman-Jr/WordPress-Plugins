
<div  class="row_wrapper clearfix">
    <?php echo $el['label']; ?>
    <div class="field_wrapper">
        <?php echo $el['field']; ?>

        <small><?php echo $el['description']; ?></small>
    </div>
</div>