
    <div class="section">

        <div class=""> <?php epl_e('Payment Details'); ?></div>

        <div><strong><?php epl_e('Amount Paid'); ?> <?php echo get_the_regis_payment_amount(); ?></strong></div>
        <div><strong><?php epl_e('Date Paid'); ?> <?php echo get_the_regis_payment_date(); ?></strong></div>
        <div><strong><?php epl_e('Transaction ID'); ?> <?php echo get_the_regis_transaction_id(); ?></strong></div>

    </div>

