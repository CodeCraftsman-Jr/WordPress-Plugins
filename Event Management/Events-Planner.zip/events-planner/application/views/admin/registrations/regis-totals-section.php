<div id="epl_totals_wrapper">

    <?php


    echo $cart_totals;


    ?>


</div>