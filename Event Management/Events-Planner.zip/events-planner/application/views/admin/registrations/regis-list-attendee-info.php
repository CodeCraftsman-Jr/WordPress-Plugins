<table class="epl_regis_list_attendee_info">

    <tr>
        <td><?php epl_e('Due'); ?></td>
        <td><?php epl_e('Paid'); ?></td>
        <td></td>

    </tr>
    <tr>
        <td><?php echo $grand_total; ?></td>
        <td><?php echo $amount_paid; ?></td>
        <td><?php echo $snapshot_link; ?></td>
    </tr>
    
</table>