<tr>
    <td class="epl_regis_field_label_wrapper">
        <?php echo $el['label']; ?>
    </td>
    <td>
        <?php echo $el['field']; ?>

    </td>
</tr>