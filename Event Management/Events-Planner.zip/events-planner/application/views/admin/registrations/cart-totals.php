<div class="epl_cart_section">

    <table class="epl_totals_wrapper epl_w100pct">

        <tr class="epl_grand_total">

            <td class="epl_w200">Total</td>
            <td class="epl_total_price epl_w100 epl_ta_r"> <?php echo epl_get_formatted_curr($total_price); ?></td>
        </tr>


    </table>
   
    
</div>