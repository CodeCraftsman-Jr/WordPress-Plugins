<table class="epl_form_data_table" cellspacing="0" id="epl_pay_profile_fields">
    <?php

    echo current( ( array ) $epl_pay_profile_fields );
    ?>

</table>