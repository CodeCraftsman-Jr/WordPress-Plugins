<table class="epl_form_data_table" cellspacing="0">
    <?php

    echo current( $epl_org_field_list );
    ?>



</table>

<?php echo epl_show_ad ('Easily add and access more fields here.'); ?>