<div id="list_of_fields_for_forms_wrapper">
    <ul class="list_of_fields_for_forms">
        <?php

        echo $field_list_for_forms;
        ?>
    </ul>
</div>