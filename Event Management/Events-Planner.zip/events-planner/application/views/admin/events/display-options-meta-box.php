
<div id="recurrence_section">
    <table class="epl_form_data_table" cellspacing ="0" id ="">
          <?php foreach ( $fields as $row ) : ?>

        <?php echo $row; ?>

        <?php endforeach; ?>
    </table>

</div>