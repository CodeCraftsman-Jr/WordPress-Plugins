<div id="">

    <div id="epl_recurrence_section" class="">

        <?php echo $recurrence_section; ?>

    </div>


</div>
