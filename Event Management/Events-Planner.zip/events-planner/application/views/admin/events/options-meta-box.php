
<div id="recurrence_section">
    <table class="epl_form_data_table" cellspacing ="0" id ="">
        <tr>
            <td>Status</td>
            <td> <?php echo $_f['_epl_event_status']['field']; ?><?php echo $_f['_epl_event_status']['description']; ?> </td>
        </tr>


    </table>

    <div class="epl_box epl_info">
        <div class="epl_box_content">

           NOTE: You must publish this post for users to be able to see it.

        </div>
    </div>
</div>