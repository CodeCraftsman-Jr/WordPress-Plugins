
<div id="epl_event_type_0">

    
    <div id="epl_event_type_section">


        <?php echo $event_type_section; ?>

    </div>
    <div id="epl_dates_section">


        <?php echo $dates_section; ?>

    </div>

</div>

