<div class="epl_box epl_info">
    <div class="epl_box_content">

        These forms will be presented during the registration process.  If you don't need to collect information from additional attendees,
        don't select any forms in the "Forms for all attendees" section.
    </div>
</div>

<div class="epl_box">
    <table class="form-table" class="epl_box">
        <?php

        echo current( $epl_forms_fields );
        ?>
    </table>
</div>