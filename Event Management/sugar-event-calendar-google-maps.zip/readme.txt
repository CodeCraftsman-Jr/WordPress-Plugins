=== Sugar Event Calendar - Google Maps ===
Author URI: http://pippinsplugins.com
Plugin URI: http://pippinsplugins.com/sugar-calendar-maps
Contributors: mordauk
Donate link: http://pippinsplugins.com/support-the-site
Tags: Google Maps, maps, Events, Event Calendar, Sugar Event Calendar, Pippin Williamson, Pippin's Plugins, pippinsplugins, gravityforms
Requires at least: 3.2
Tested up to: 4.2
Stable Tag: 1.2

Adds simple Google Maps to events in Sugar Event Calendar

== Description ==

[Sugar Event Calendar](http://pippinsplugins.com/sugar-event-calendar) is a a simple, elegant Event Calendar plugin for WordPress that keeps event management incredibly simply. This is an add-on plugin for Sugar Event Calendar that lets you easily display a Google Map of the event location on the event details page.


This plugin requires [Sugar Event Calendar](http://pippinsplugins.com/sugar-event-calendar).

== Installation ==

1. Activate the plugin
2. Enter an address in the Event Configuration meta box
3. The Google Map will be automatically displayed below the event description


== Frequently Asked Questions ==

None at this time.


== Screenshots ==

1. Event Configuration
2. Google map


== Changelog ==

= 1.2 =

* Updated Google Maps API to v3
* Improved map display on responsive pages

= 1.1 =

* Added localization

= 1.0 =

* First offical release!

== Upgrade Notice ==

Added localization for internationalization