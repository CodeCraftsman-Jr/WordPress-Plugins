=== Plugin Name ===
Contributors: Jake Ruston
Donate link: http://www.jakeruston.co.uk
Tags: widget, widgets, sidebar, post, posts, events, event
Requires at least: 2.0.2
Tested up to: 3.0.0
Stable tag: 1.2.4

This events plugin allows you to display all of the upcoming events in a location which you specify!

== Description ==

This events plugin allows you to display all of the upcoming events in a location which you specify!

You can also enter a search term to make it only show specific types of events. For example, you could enter the location as London and enter the Query as Music. This would show the latest music events in London.

There should be events available worldwide, so you can use this plugin in a vast amount of different countries.

== Installation ==

1. Upload `jr-events.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit the JR Events Settings in your Administration Panel
4. Enable the Widget through the Appearance --> Widgets tab.

== Frequently Asked Questions ==

= Does this work? =

Yes.

== Changelog ==

= 1.0 =
* Initial Release
