<!DOCTYPE html>
<html class="no-js"> 
   <head>
       <meta charset="utf-8">
       <meta http-equiv="X-UA-Compatible" content="IE=edge">
       <title>EventAppi Activate Account</title>
       <meta name="description" content="">
       <meta name="viewport" content="width=device-width, initial-scale=1">
   </head>
   <body>
       <p>Hello there,</p>
       
       <p>In order to publish the event you just created, you have to confirm the creation of your account. <br />
           Use the link below to do that. Once you're done, you will be able to see your event live.</p>
       
       <p><a href="<?php echo $data['url']; ?>"><?php echo $data['url']; ?></a></p>
       
       <p>Thank you for using EventAppi!</p>
   </body>
</html>