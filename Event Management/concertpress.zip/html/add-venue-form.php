

<div class="venue-hide">

	<p>
		<label for="venueName">Venue name</label>
		<input type="text" value="" class="cp-clear" id="venue-name" name="venueName">
	</p>

	<p>
		<label for="venueUrl">Venue website</label>
		<input type="url" value="" class="cp-clear" id="venue-url" name="venueUrl">
	</p>

	<p>
		<label for="venueAddress">Venue address</label>
		<input type="text" value="" class="cp-clear" id="venue-address" name="venueAddress">
	</p>

</div>