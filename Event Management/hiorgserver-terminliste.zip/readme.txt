=== HiOrg-Server Termine ===
Contributors: babsitz,hiorgserver
Tags: hiorg-server, drk, terminliste, hiorg, hiorg server
Requires at least: 3.0
Tested up to: 4.3.1
License: GPL

Dieses Plugin zeigt in einem Widget die öffentlichen Terminen aus dem HiOrg-Server Ihrer Organisation an.

== Description ==
Dieses Plugin zeigt in einem Widget die öffentlichen Terminen aus dem [HiOrg-Server](http://www.hiorg-server.de "HiOrg-Server") Ihrer Organisation an.

== Installation ==
= Voraussetzungen =
* WordPress Version 3.0 und später (getestet mit 4.3.x)

= Installation =
1. Plugin im Menü 'Plugins' installieren und aktivieren
1. Gehen Sie zu Design -> Widgets
1. Drag & Drop des Widgets in die gewünschte Sidebar
1. Geben Sie Ihr "Organisations-Kürzel" und klicken Sie auf speichern

== Screenshots ==
nothing here

== Other Notes ==
= Acknowledgements =
nothing here

= License =
Gute Nachrichten! Dieses Plugin kann von jedem genutzt werden, da es unter der GPL veröffentlicht wurde, kann es auf jedem privaten und kommerziellen Blog benutzt werden.

== Changelog ==
= v0.8 (2015-10-09) =
* Fehlerbehandlungen
= v0.7 (2015-10-09) =
* Im Widget können nun auch die Links zu den einzelnen Terminen im HiOrg-Server angezeigt werden.
= v0.6 (2015-10-07) =
* Problem mit Zeitzonen bzw. Sommer- und Winterzeit behoben
= v0.5 (2015-07-08) =
* Wahlweise auch Zeitraum der Terminanzeige wählbar
= v0.4 (2015-05-27) =
* Backslash vor Sonderzeichen wurde entfernt
= v0.3 (2015-05-12) =
* Erste Veröffentlichung des Plugins.