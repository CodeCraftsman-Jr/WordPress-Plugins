# HiOrg-Wordpress
Plugin für Wordpress CMS zur Anzeige von Terminen aus HiOrg-Server

Autor: Jörg Klebsattel / HiOrg Server GmbH

Lizenz: GPL