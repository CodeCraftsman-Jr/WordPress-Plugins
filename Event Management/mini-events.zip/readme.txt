=== Mini Events ===
Contributors: peter.featherstone
Donate link: http://www.peterfeatherstone.com/donate/
Tags: events, mini, event
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a very small, simple events plugin

== Description ==

This is a very small, simple events plugin.

Please note that I have created this plugin as a personal project to use across various sites that I make, therefore there will be no custom support or feature requests in regards this plugin.

You are of course more than welcome to use it however if you wish and it fulfils your needs.

It currently supports the following shortcode with options:

[events] - Shows all events with all types

== Installation ==

1. Upload `mini-events` to the `/wp-content/plugins/` directory
2. Activate the plugin through the `Plugins` menu in WordPress
3. Create your new Testimonials and use shortcodes to display

Alternatively:

1. Login to your WordPress admin area
2. Search for `Mini Events`
3. Click install `Mini Events`
4. Activate through the `Plugins` menu in WordPress or when asked during installation
5. Set your options from the Mini Events admin area

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0 (17th Feb 2015) =

* Initial Version Released.

== Upgrade Notice ==