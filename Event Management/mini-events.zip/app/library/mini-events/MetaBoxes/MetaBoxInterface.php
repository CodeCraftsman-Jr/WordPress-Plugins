<?php

interface ME_MetaBoxInterface {
    
    
    public function display( $post, $args );
    public function save( $post );

    
}