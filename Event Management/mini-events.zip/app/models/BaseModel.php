<?php

class ME_BaseModel {
   
    
}