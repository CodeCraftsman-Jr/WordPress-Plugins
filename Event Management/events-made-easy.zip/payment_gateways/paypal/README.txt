PayPal Buy Now and PayPal IPN Class
http://ptdev.net
Copyright 2008 Roberto Gomes
Released under the GPL

README FILE

These classes help in the creation of Paypal Buy Now buttons and the receiving and processing of Paypal's IPN requests.

You should already be familiarized with paypal and IPN before attempting to use these classes

Each class can be used separately

You must create and upload certificates for encryption to work, follow the instructions at:

https://www.paypal.com/IntegrationCenter/ic_button-encryption.html#step1


Please check the Example_*.phps files for sample code

You have to import the file ipn.sql on the scripts folder into your database if you want to use database logging.

Included is the Add Event javascript function which is only needed if you want to use automatic submission (proceeding to paypal without having to click the button)


Please post any problems or bugs to the corresponding post on my blog

http://ptdev.net