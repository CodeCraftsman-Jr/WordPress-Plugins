<?php

defined('SAGEPAY_SDK_PATH') || exit('No direct script access.');

/**
 * SagepayApi exceptions type
 *
 * @category  Payment
 * @package   Sagepay
 * @copyright (c) 2013, Sage Pay Europe Ltd.
 */
class SagepayApiException extends Exception
{

}
