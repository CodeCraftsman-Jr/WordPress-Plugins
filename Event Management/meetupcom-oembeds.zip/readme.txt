=== Meetup.com oEmbeds - Easily embed events, groups, more!===
Contributors: bradparbs
Donate link: http://bradparbs.com/
Tags: meeting, oembeds, meetup, meetup.com, events, groups, embed
Requires at least: 3.2
Tested up to: 3.3.2
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simply paste in a Meetup.com URL to a page or post, and it will display the event, group, ect. 

== Description ==

Simply paste in a Meetup.com URL to a page or post, and it will display the event, group, ect. 


== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Paste a Meetup.com URL into a page or post.

== Changelog ==

= 1.0 =

* initial release