<?php

namespace Evp\Bundle\PaymentBundle\PaymentHandler\Exception;

class OrderIntegrityException extends WebToPayHandlerException
{
} 