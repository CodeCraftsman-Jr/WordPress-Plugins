<?php

namespace Evp\Bundle\PaymentBundle\PaymentHandler\Exception;

class WebToPayHandlerException extends \Exception
{
} 