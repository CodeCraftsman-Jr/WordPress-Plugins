<?php

namespace Evp\Bundle\TicketMaintenanceBundle\Annotation;

/**
 * Determines which fields need to be a unique token
 *
 * Class UniqueToken
 * @package Evp\Bundle\TicketMaintenanceBundle\Annotation
 * @Annotation
 */
class UniqueToken
{
}