<?php

namespace Evp\Bundle\TicketMaintenanceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EvpTicketMaintenanceBundle extends Bundle
{
}
