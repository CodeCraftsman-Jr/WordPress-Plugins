<?php

namespace Evp\Bundle\TicketMaintenanceBundle\Entity;

/**
 * Specifies that the class can generate unique tokens
 *
 * Interface TokenAwareInterface
 * @package Evp\Bundle\TicketMaintenanceBundle\Entity
 */
interface TokenAwareInterface
{

} 