<?php

namespace Evp\Bundle\ReportingBundle\Exception;

/**
 * Class ReportFormNotFoundException
 */
class ReportFormNotFoundException extends \Exception
{

} 
