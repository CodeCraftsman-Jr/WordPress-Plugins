<?php
/**
 * Interface to recognize Entity, which properties needs to be corrected by UTC offset
 *
 * @author Valentinas Bartusevičius <v.bartusevicius@evp.lt>
 */

namespace Evp\Bundle\TicketBundle\Entity;

/**
 * Class UtcOffsetMutableInterface
 */
interface UtcOffsetMutableInterface {

} 