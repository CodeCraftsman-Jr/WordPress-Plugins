<?php
namespace Evp\Bundle\TicketBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Evp\Bundle\TicketBundle\Entity\TicketType;
use Evp\Bundle\TicketBundle\Entity\User;

/**
 * Class DiscountRepository
 * @package Evp\Bundle\TicketBundle\Repository
 */
class DiscountRepository extends EntityRepository
{
}
