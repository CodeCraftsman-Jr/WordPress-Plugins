<?php

namespace Evp\Bundle\TicketBundle\Exception;

/**
 * Class StepNotFoundException
 */
class StepNotFoundException extends \Exception
{
}
