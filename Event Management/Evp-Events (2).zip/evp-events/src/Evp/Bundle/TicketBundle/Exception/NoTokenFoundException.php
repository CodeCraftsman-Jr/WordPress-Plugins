<?php

namespace Evp\Bundle\TicketBundle\Exception;

/**
 * Class NoTokenFoundException
 */
class NoTokenFoundException extends \Exception
{
}
