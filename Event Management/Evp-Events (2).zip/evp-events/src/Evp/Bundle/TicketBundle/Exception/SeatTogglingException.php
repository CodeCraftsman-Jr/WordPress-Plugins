<?php

namespace Evp\Bundle\TicketBundle\Exception;

/**
 * Class UnableToToggleException
 * @package Evp\Bundle\TicketBundle\Exception
 */
class SeatTogglingException extends \Exception {

} 