<?php

namespace Evp\Bundle\TicketBundle\Exception;

/**
 * Class CodeStrategyNotFoundException
 */
class CodeStrategyNotFoundException extends \Exception {

} 
