<?php
namespace Evp\Bundle\TicketBundle\EventDispatcher;

class UserSessionEvents {
    const SESSION_CREATED = 'user_session.created';
    const SESSION_DESTROYED = 'user_session.destroyed';
}