<?php
/**
 * Bearer User interface
 * @author Valentinas Bartusevičius <v.bartusevicius@evp.lt>
 */

namespace Evp\Bundle\DeviceApiBundle\Entity\User;

/**
 * Class BearerUserInterface
 * @package Evp\Bundle\DeviceApiBundle\Entity\User
 */
interface BearerUserInterface {

} 