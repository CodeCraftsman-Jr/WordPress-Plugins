INSERT IGNORE INTO `evp_steps` (`id`, `parameter`) VALUES (1, 'ticket_type_discount'),(2, 'user_details_fill'),(3, 'payment_window'),(4, 'payment_type_selection'),(7, 'seat_selection');
