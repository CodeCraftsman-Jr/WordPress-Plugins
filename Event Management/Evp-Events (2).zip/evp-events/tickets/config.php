<?php

const WP_DEVELOPMENT = 'app_dev.php';
const WP_PRODUCTION = 'app.php';
const WP_CURRENT_ENV = WP_PRODUCTION;