=== Hello World ===
Contributors: Kau-Boy
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7914504
Tags: hello, dolly, yoda
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0


In tribute to the famous "Hello Dolly" plugin by Matt Mullenweg comes this new plugin. And how could someone possible name a new default plugin other than "Hello World", as it's THE definition for a default example :)

== Change Log ==

= 0.1 =
* First stable release with lyrics for "Hello World", "Yoda quotes" and the original "Hello Dolly" lyrics
* Time invested for this release: 120min