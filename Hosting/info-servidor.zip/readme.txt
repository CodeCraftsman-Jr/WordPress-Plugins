=== Plugin Name ===
Contributors: v0ltr4n
Tags: server, servidor, info, informacion, version
Requires at least: 2.6
Tested up to: 2.7
Stable tag: trunk

== Description ==

Este plugin te da infomacion basica acerca de tu servidor asi como:

-Informacion de php

-Informacion de apache

-Informacion de mysql

-Informacion de libreria GD

-Nombre del servidor

-Espacio

== Installation ==

1.Descomprimir el cotenido del archivo en una carpeta

2.Subir el archivo a la carpeta wp-content de tu WordPress

3.Activar el plugin

4.Visualizar el plugin en la seccion tablero

== Screenshots ==

1. Informacion General
2. Informacion Apache y Php
3. Informacion Mysql y GD