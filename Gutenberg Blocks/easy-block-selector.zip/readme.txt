=== Easy Block Selector ===
Contributors: sekishi
Donate link: http://lab.planetleaf.com/donate/
Tags: tinymce, editor , select , text , shortcodes , short code , contents

Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: 0.1.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extend the range selection of TinyMCE.

== Description ==

Enable to simplify the selection of the enclosing shortcode and html element on TinyMCE richedit.
This is simple plugin.
but it's a very useful plugin.

Demonstration
http://lab.planetleaf.com/development/wordpress/write-wordpress-plugin.html

== Installation ==

1. Upload the entire `treeview-on-contents` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 0.1.1 =
fix bug

= 0.1.0 =
* NEW: Initial release.


== Upgrade Notice ==

No upgrade, so far.

