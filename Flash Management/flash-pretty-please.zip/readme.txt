=== Plugin Name ===
Contributors: 
Donate link: href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&amp;hosted_button_id=E8N9D537FB8WN
Tags: Flash, Apple, Steve Jobs


Detects iPhone/iPad/iPod and pops up a message that asks to users to politely contact apple asking for Flash.

== Description ==

This plug in detects the iPod, iPhone. and iPad user agent.  It then pops up a message that asks users to write or fax Steve Jobs and very politely ask him to make Flash available as an option for the iPhone, iPad or iPod.

To see an example on your browser regardless of whether you are using an iDevice see here <a href="http://it.language101.com/flash-pretty-please-demo-page/">http://it.language101.com/flash-pretty-please-demo-page/</a>

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make sure '<?php wp_footer(); ?>` is in your templates

== Screenshots ==

1.  screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)


== Changelog ==

= 1.1 =
*Now works if you have wordpress in a different directory than the website root directory
*Fixed some width issues to make it look better on idevices
= 1.0 =
*Plugin Released :) 
 


