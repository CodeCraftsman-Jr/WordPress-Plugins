=== css-wapuu-shortcode ===
Contributors: mismith227,spicagraph,hnle
Tags: csswapuu,wapuu,shortcode
Requires at least: 1.0.8
Tested up to: 1.0
Stable tag: 1.0.8
License: GPL v2 license or any later version.

It is a plug-in that embed wapuu drawn by CSS in the short code.

== Description ==
It is a plug-in that embed wapuu drawn by CSS in the short code.

[This Plugin published on GitHub.](https://github.com/mismith0227/csswapuu_shortcode)

CSSWapuu
[CSSWapuu.](https://github.com/mismith0227/csswapuu)

【How to use】
It embeds the [css_wapuu] to post or fixed page .

【When you want to change the size】

scale=

* 400px
[css_wapuu scale=1]
* 200px
[css_wapuu scale=0.5]
* 4000px
[css_wapuu scale=10]

== Installation ==
* A plug-in installation screen is displayed in the WordPress admin panel.
* It installs in `wp-content/plugins`.
* The plug-in is activated.

== Changelog ==

= 1.0.5 =
* update,add image

= 1.0.4 =
* edit

= 1.0 =
* First release

== Special Thanks ==

She gave me draw a cover image.
[spicagraph](https://profiles.wordpress.org/spicagraph/)

Contributors
* [hnle](https://profiles.wordpress.org/hnle)
