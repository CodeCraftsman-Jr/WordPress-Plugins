=== Plugin Name ===
Contributors: johnnytee
Donate link: http://johndturner.com/wordpress-stuff/plugins/colourlovers-rss-widget/
Tags: colourlovers, color, lovers, rss
Requires at least: 2.5
Tested up to: 2.7.1
Stable tag: 0.01

Widget displays COLOURlovers.com feeds with images in the sidebar.

== Description ==

Widget displays COLOURlovers.com feeds with images in the sidebar.

For more info on COLOURlovers.com feeds see: [COLOURlovers.com](http://www.colourlovers.com/rss)

                   
== Installation ==

1. Upload the folder `colourlovers-rss-widget` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Add the widget to your sidebar
1. Enter Title
1. Enter your Feed URL
1. Enter how many to display

