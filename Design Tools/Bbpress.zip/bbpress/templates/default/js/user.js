if ( window.location.hash === '#password' ) {
	document.getElementById('pass1').focus();
}