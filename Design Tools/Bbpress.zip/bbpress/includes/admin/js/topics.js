jQuery( document ).ready( function() {
	jQuery( '#misc-publishing-actions' ).find( '.misc-pub-section' ).first().remove();
	jQuery( '#save-action' ).remove();
} );
