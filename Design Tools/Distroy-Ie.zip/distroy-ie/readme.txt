=== Distroy IE ===
Contributors: qqworld
Tags: ie
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

我讨厌IE，所以我制作这个插件告诉人们不要使用IE，至少使用IE8+

== Description ==

本插件将创建一个只在低于IE8版本的IE浏览器上显示“用户正在使用低版本IE”的警告图片，并且提供了10款更好的浏览器下载链接。大家一定觉得奇怪，作为中国互联网络垄断地位的大哥大腾讯旗下的腾讯TT浏览器为何没有在列表里呢？因为，因为腾讯TT用的是IE的Trident内核，如果不升级IE的话，一样不能用，一样慢得人心烦。希望讨厌IE浏览器的开发者喜欢。

== Installation ==

1. 上传 `distroy-ie` 目录到 `/wp-content/plugins/` 文件夹
1. 在wordpress的 '插件' 菜单中激活该插件

== Screenshots ==

1. 使用低于IE8版本的IE浏览器就会看到这样的图片，并且可以选择图片中提供的10款浏览器下载安装

== Changelog ==

= 1.2 =
* 去掉了不必要的脚本

= 1.1 =
* 修复了一个小bug

= 1.0 =
* 插件诞生，改自QQWorld Framework for WP的一个内置插件

== Upgrade Notice ==

= 1.0.1 =
小小的更新，建议点一下升级。

= 1.0 =
讨厌IE的开发者一定要下载安装哦！