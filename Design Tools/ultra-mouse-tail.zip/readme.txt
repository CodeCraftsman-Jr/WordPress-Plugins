=== Ultra Mouse Tail ===
Tags: Mousetail, jQuery Mousetail, Awesome Mousetail, jQuery Mouse effect, WP Mousetail Plugin, Mouse Text, Ultra Mouse Tail, Mouse Animation, Cursor Text, wordpress cursor Text, Cursor Animation, themeultra 
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This is Awesome WordPress plugin. if you want to see some animated text always staying with mouse cursor this plugin is perfect. <br /> For full documentation of this plugin ---> <a target="blank" href="http://www.themeultra.com/downloads/ultra-mouse-tail/">Documentation</a> <br /> Plugin Demo ---> <a target="blank" href="http://www.themeultra.com/demos/ultra-mouse-tail/">Demo</a> <br /> For Support ( Submit Ticket ) ---> <a target="blank" href="http://www.themeultra.com/support/">Live Support</a> 

== Installation ==

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. After Activate "Ultra Camera Slider", U Can See a new menu "Ultra Mouse Tail" in Settings Menu on your WordPress Dashboard. 
6. If you want to change the cursor text need to go "Ultra Mouse Tail" in Settings Menu on your WordPress Dashboard than change the text and click "Save Change" button.



== Frequently Asked Questions ==
 All Support Available here --->  <a target="blank" href="http://www.themeultra.com/support/">Official Support</a> 




== Screenshots ==
1. Ultra Setting Menu in WordPress Dashboard Menu.
2. Cursor Text Setting Menu.
3. Ultra Mouse Tail Plugin in WordPress Plugin Directory.
4. It's Awesome cursor Effect in Your Website.

== Changelog ==

= 1.0 =
* Initial Release

= 1.0.1 =
* First Update