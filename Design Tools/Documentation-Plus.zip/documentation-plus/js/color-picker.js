	jQuery(document).ready(function(jQuery)
		{	


			//jQuery('').wpColorPicker();
					
					


		});