jQuery(document).ready(function () {
	jQuery('.sonicblink').sonicblink();
});