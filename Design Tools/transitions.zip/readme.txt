=== <a href="http://krisjaydesigns.com/?p=946" target="_blank">Transitions - AJAX/jQuery Effects</a> ===
Contributors: krisjay
Author: Kris Jonasson
Author URI: http://krisjaydesigns.com
Plugin URI:  http://krisjaydesigns.com/?p=946
Tags: jquery, effects, AJAX, ajax, jQuery, fading, login, admin, plugin, options, transition, page, pages, fade, website, wordpress 
Version: 0.5a
Requires at least: 2.0.2
Tested up to: 3.0
Stable tag: 0.5a

Adds Fade In/Out Transition between Pages on your whole site. powered with jQuery. Hooks To All < a href's

== Description ==

**YOU NEED JAVASCRIPT ON IN YOUR BROWSER!**

Have You Ever Wanted Your Website or Blog To Have The Transition Effects That a AJAX Powered Website Possess?
Now You Can With This Simple Plug N Play WordPress Plugin Powered With jQuery.

 - Easy To Use and Set-up Via the Options Page.

 - Tested in IE7, IE8, FF 3.5, And Opera 10. Works Good For The Most Part Accross Those Browsers.

 - <a href="http://testing.gdsweb.ca/" target="_blank">Click Here</a> to check out the working demo.

== Installation ==

**What To Do**

1. Download the zip to your hardrive.
2. Upload to your 'Plugin' Directory via On-site Uploader (zip).
3. Second Last, Click 'Activate Plugin'.
4. Options Page Under 'Settings' in Admin Sidebar.

*After Activation, Your Pages Should Start To Have The Transition Effects*

**If Plugin Stalls Directly After Activation Don't Worry! Just Refresh The Page!!*

***Requires JS ON in your Browser to work!! (but who doesn't have it on and is surfing the net!?)

== Frequently Asked Questions ==

= Will This Plugin Be Actively Developed? =

*Yes*. Development of this plugin will be **very active**.

= Will The Transition Effect Remain After A WordPress Core Update? =

 *Yes!* :)

= Why Did You Limit The Admin Pannels Transitions To Only Fade In? =

 It Was Interfering With The 'Built In' File Uploader. Too Busy to Figure Out A Work-Around...Any Takers?

== Screenshots ==

<a href="http://testing.gdsweb.ca/" target="_blank">Click Here</a> to check out the working demo.

== Upgrade Notice ==

= 0.5a =
* Fixed a qlitch in the Admin Panel.

== Changelog ==

= 0.5a =
* Fixed a qlitch in the Admin Panel.

= 0.4a =
* Options Page is HERE!! - June 12, 2010.
* Set Background Color to Fade Out/In.
* Use Background Image To Fade Out/In.
* Upload Image To WP-Gallery via ThickBox.
* Farbtastic ColorPicker via Options Page!

= 0.3 A =
* Cleaned up the Code a Bit.
* Compressed/limited the empty lines in the plugin.

= 0.2 A =
* Configured Transitions To Fade In AND Out! - 02.24.2010.
* Limited Admin Pannel Transitions To Only Fade In Until Bug is Worked Out - 02.24.2010.

= 0.1 A =
* Alpha Release - 02.22.2010.


`<?php code(); // goes in backticks ?>`