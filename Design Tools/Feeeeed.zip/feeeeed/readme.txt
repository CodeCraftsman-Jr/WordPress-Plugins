=== Feeeeed ===
Contributors: AI.Takeuchi
Donate link: http://takeai.silverpigeon.jp/
Tags: rss, feed, wordpress
Requires at least: 3.4
Tested up to: 4.2.2
Stable tag: 0.9.10

When rss-feed unsupported browser(Chrome and older than IE6) will be access rss-feed on your website then this plugin be displaying html formatted rss-feed or redirect url or displaying your message.

Demonstration site is here!!
http://takeai.silverpigeon.jp/


== Description ==

When rss-feed unsupported browser(Chrome and older than IE6) will be access rss-feed on your website then this plugin be displaying html formatted rss-feed or redirect url or displaying your message.


= Translators =

* Romanian (ro_RO) - [Alexander Ovsov](http://webhostinggeeks.com/)
* German (de_DE) - [Rian Kremer](http://vcacursus.tel/)
* Dutch (nl_NL) - [Rene](http://wpwebshop.com/premium-wordpress-themes/)
* Belorussian (be_BY) - [Marcis Gasuns](http://pc.de/)
* Japanese (ja) - [AI.Takeuchi](http://takeai.silverpigeon.jp/)

If you have created your own language pack, or have an update of an existing one, you can send [gettext PO and MO files](http://codex.wordpress.org/Translating_WordPress) to [me](http://takeai.silverpigeon.jp/) so that I can bundle it into Feeeeed. You can [download the latest POT file from here](http://plugins.svn.wordpress.org/feeeeed/trunk/lang/feeeeed.pot).


== Installation ==

1. Upload the entire Feeeeed folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Visit Settings Feeeeed.
4. Settiong and save.


== Changelog ==

= 0.9.10 =
* Fix and Compatible with WordPress 4.2.2.

= 0.9.7 =
* Translation for Romanian has been newly created by Alexander Ovsov.

= 0.9.6 =
* Bug fix: about tinymce editor.

= 0.9.5 =
* Bug fix: about tinymce editor.

= 0.9.4 =
* Support Wordpress 3.2.

= 0.9.3 =
* Fix: missing message.

= 0.9.2 =
* Fix: missing message.

= 0.9.1 =
* Bug fix: about tinymce editor.

= 0.9.0 =
* Translation for German has been newly created by Rian Kremer.

= 0.8 =
* Translation for Dutch has been newly created by Rene.

= 0.7 =
* Translation for Belorussian has been newly created by Marcis Gasuns.

= 0.6 =
* Bug fixed.

= 0.5 =
* Include language file (pot file).
* Bug fixed.


== Screenshots ==

1. screenshot-1.png


