<?php

class FI_Pre extends FI_Extension
{
	function what_group () { return 'pre'; }
}

?>