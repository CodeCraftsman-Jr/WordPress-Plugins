<?php

class FI_Results extends FI_Extension
{
	var $original_text;
	
	function what_group () { return 'result'; }
}

?>