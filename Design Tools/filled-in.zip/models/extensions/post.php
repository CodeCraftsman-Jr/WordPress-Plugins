<?php

class FI_Post extends FI_Extension
{
	function what_group () { return 'post'; }
}

?>