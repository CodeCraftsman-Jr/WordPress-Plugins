# fartscroll.js

Everyone farts. And now your web pages can too.

_Now with 100% less jQuery! (Sorry, jQuery, we still love you)_

### Setup:

1. Include "fartscroll.js" in your page.
2. Initialize the fartscroll plugin once the DOM has loaded:

```javascript
// Fart every 400 pixels scrolled
fartscroll(); 

// Fart every 800 pixels scrolled
fartscroll(800);
```
    
More info at [http://theonion.github.io/fartscroll.js/](http://theonion.github.io/fartscroll.js/).
