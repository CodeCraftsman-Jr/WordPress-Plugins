
<div class="awe-color-palette count-<?php echo count($palette); ?>">

	<div class="palette cf">
	<?php foreach( $palette as $color ) { ?>
		<div class="color" style="background-color: #<?php echo $color; ?>;"><span>#<?php echo $color; ?></span></div>
	<?php } ?>
	</div>

</div>
