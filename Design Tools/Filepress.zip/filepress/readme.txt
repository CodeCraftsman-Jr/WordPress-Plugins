=== Filepress ===
Contributors: choppedcode
Donate link: http://www.choppedcode.com/donations
Tags: webdav, files, ftp
Requires at least: 2.1.7
Tested up to: 3.9.1
Stable tag: 1.0.1

Filepress is a plugin that allows you to edit your Wordpress files from any file browser.

== Description ==

Tired of having to use ftp and other archaic mechanisms to edit your Wordpress files?

Filepress is a plugin that allows you to edit your Wordpress files from any file browser. It uses WebDav technology to provide a seemless integration experience between your desktop and your Wordpress site.

== Installation ==

1. Upload the `filepress` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to the plugin settings menu and configure the plugin options.

== Changelog ==

= 1.0.1 =
* Verified compatibility with latest version of Wordpress

= 1.0.0 =
* Replaced remote logo with local file

= 0.9.2 =
* Updated instructions
* Tested with Windows 7 File Explorer
	
= 0.9.1 =
* Alpha release
* Tested with Mac OSX Finder
