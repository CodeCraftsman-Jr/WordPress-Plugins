=== De Praktijk Index ===
Contributors: Leon Hooijer,
Tags: De Praktijk Index, Bilthoven, Real Time Monitoring, HSMR
Donate link: http://www.depraktijkindex.nl
Requires at least: 3.6
Tested up to: 3.9
Stable tag: 0.3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin for De Praktijk Index, Bilthoven.

== Description ==
Plugin for De Praktijk Index, Bilthoven.

== Changelog ==
= 0.1 =
* Initial release.

= 0.2 =
* Added sortable "Last Modfied" column to all edit overviews (It checks if Salient is active)

= 0.2.1 =
* Unknown

= 0.3.1 =
* Extend the Bogo-plugin with the Salient Theme tags

== Upgrade Notice ==
= 0.1 =
* Initial release.

= 0.2 =
* Added sortable "Last Modfied" column to all edit overviews (It checks if Salient is active)

= 0.2.1 =
* Unknown

= 0.3.1 =
* Extend the Bogo-plugin with the Salient Theme tags
