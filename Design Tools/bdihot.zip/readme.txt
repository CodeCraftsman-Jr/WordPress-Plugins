=== Random Joke (Bdihot.co.il) ===
Contributors: ramiy
Tags: sidebar, widget, bdihot, humor, jokes, random, joke, hebrew, rtl
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 0.4

This plugin allows you to add random joke to your site using wordpress sidebar widget.

== Description ==

This plugin allows you to add random jokes from <a href="http://www.bdihot.co.il/">bdihot.co.il</a> website, using the wordpress widget systems.

Display random jokes everywhere on your site. Add as many widgets as you need. Set each widget it's individual set of options.

Features:

* Dashboard widgets - random jokes in the back-end for the site operators.
* Sidebar widgets - random jokes in the front-end for your users.

For more information, installation instructions and screenshots, visit <a href="http://www.bdihot.co.il/wordpress_plugin/">plugin homepage</a>.

== Installation ==

1. Add new plugin through 'Plugins' > 'Add New' menu in your WordPress dashboard.
2. Search for 'bdihot'.
3. Install the plugin and activate it.

== Screenshots ==

1. Random Joke on WordPress Dashboard.
2. Sidebar widget sittings.
3. Random Joke on TwentyTen sidebar.

== Changelog ==

= 0.4 (03.10.2014) =
* Tested up to WordPress 4.0

= 0.3 (20.05.2012) =
* Joke title parameter to control the title display.
* Powered by parameter to control the poweredby text display.

= 0.2 (07.04.2012) =
* Added Dashboard-Widget.

= 0.1 (01.01.2012) =
* Initial release.
