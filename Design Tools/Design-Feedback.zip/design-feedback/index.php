<?php 
// Silence is golden