<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://getCycles.io
 * @since      0.1
 *
 * @package    Design_Feedback
 * @subpackage Design_Feedbacke/admin
 * @author     Design Feedback
 */

class Design_Feedback_Deactivator {

	public static function deactivate() {

	}

}
