<div class ="view_feedback">
    
    <div class ="title">Feedback from <span id = "name"></span></div>
    <div id ="at"></div>
    <div id ="feedback"></div>
    <div class ="ajax"></div>
    
</div>