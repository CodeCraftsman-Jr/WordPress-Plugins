=== E-Learning Critical Thinking ===
Contributors: Intellum
Donate link: http://www.intellum.com/
Tags: E-Learning, sidebar
Requires at least: 2.8
Tested up to: 3.01
Stable tag: 2.8

Allows you to add a critical thinking corner to your sidebar to ask questions about your post, leave reminders, notes, and tips

== Description ==

This plugin allows you to add questions, tips, reminders, and notes to the sidebar of a blog post.  It is geared towards educators (corporate and institutional) to enable a better <a href="http://www.intellum.com">E-learning</a> environment.

Features include:

*   Sidebar tips

*   Sidebar notes

*   Sidebar questions

*   Sidebar reminders


E-Learning Critical Thinking was built by Intellum, an <a href="http://www.intellum.com">LMS company</a>, to help educators who use WordPress.
== Installation ==

1. Download the plugin and upload into your wp-content/plugins  directory (unzip the file if you uploaded the zip).
1. Activate the plugin.
1. Add the widget to your sidebar: Appearance > Widgets, click and drag the E-Learning Corner widget to your sidebar. You may rename the title if you like.
1. Underneath a post, you will see a box titled "E-Learning Critical Thinking", add your content.

== Screenshots ==

1. Add / Edit the E-Learning content
2. How the content is displayed


