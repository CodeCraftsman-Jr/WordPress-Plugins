=== WP Documenter ===

Contributors: asaquzzaman
Tags: Documenter, Documentation, Book, Text, Note
Requires at least: 3.1
Tested up to: 3.9
Stable tag: 0.1
License: GPLv2 or later


== Description ==
	Create your documentation and document's single page template for frontend.

== Installation ==

	1. Unzip and upload the hrm directory to /wp-content/plugins/
    2. Activate the plugin through the Plugins menu in WordPress

Browser Compatibility

    1. Google Chrome
    2. Firefox.

= Usage =
    Create documentation from Documenter menu and add the shortcode [doc_documenter doc_id="your documenter id"]

== Screenshots ==

== Changelog ==
	Nothing

== Frequently Asked Questions ==

You can contact with me joy.mishu@gmail.com with this email address. You can ask me any kinds of question about this plugin.

== Upgrade Notice ==

Nothing to say

Thanks for beign with me.



