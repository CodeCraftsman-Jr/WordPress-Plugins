<style>

.hrm-author-wrap .hrm-author-dis-ul li{
    font-size: 14px;
    line-height: 28px;
    list-style-type: initial;
    margin-left: 3%;
}
</style>
<div class="wrap hrm-author-wrap">
	<h2>You can discuss with me about &#8594;</h2>
	<ul class="hrm-author-dis-ul">
		<li>Any kinds of bug of this plugin</li>
		<li>Extra feature</li>
		<li>How to improve existance featuer</li>
		<li>How to improve this plugin</li>
		<li>Any kinds of query about this plugin</li>
		<li>Hire me with a cup of cofee for any kinds of customization of wordprss plugin, theme and widgets</li>
	</ul>
	<h2>
		<a href="http://mishubd.com/contact/" target="_blank" class="btn button-primary">
			Contact With Me
		</a>
	</h2>

</div>