# How to Translate
If you would like to contribute with a Translation to any language, just head over to the [Transifex Project](https://www.transifex.com/projects/p/fakerpress/) page, and do the translations there.

Our team will include them on the Repo before releasing a version.

---

### Automation
Keep in mind that we intend to make this a bit more automated, the issue [#12](https://github.com/iryz/fakerpress/issues/12) will acomplish that. Check the progress of this task over there.