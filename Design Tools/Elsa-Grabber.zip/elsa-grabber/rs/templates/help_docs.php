<?php
_e('<a href="http://savitov.ru/ELSAGR/" target=_blank>Справочник по функциям плагина</a>','ELSAGR');
?>
