<?php _e('Plugin site &mdash; <a target=_blank href="http://savitov.ru/ELSAGR/">Elsa grabber</a>   <br />
Facebook &mdash; <a target=_blank href="http://www.facebook.com/pages/ElSa-Grabber/245560198797041">http://www.facebook.com/pages/ElSa-Grabber/245560198797041</a> <br />
Vk &mdash; <a target=_blank href="http://vk.com/elsagrabber">http://vk.com/elsagrabber</a><br />
<div id="fb-root"></div>
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
<fb:like-box href="http://www.facebook.com/pages/ElSa-Grabber/245560198797041" width="400" show_faces="false"
border_color="" stream="false" header="true">
</fb:like-box>
<br><br>
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<g:plusone href="http://savitov.ru/ELSAGR/"></g:plusone>','ELSAGR');
?>
