<div id="wpbody" class="wrap">
<div id="elsagr_main2"><div id="elsagrfmp">
<div class="elsagrlogo76"> </div> <h1> ELSA GRABBER v. <?php global $_wopt; echo $_wopt['elsa-opt-version']['b'];?></h1> <br />
  <div id="elsagrfmplogo"> </div>

  <div id="elsagrfmpmenu">
   <ul>
      <li> <a href="#a"><?=__('О плагине','ELSAGR');?></a></li>
      <li> <a href="#lic"><?=__('Лицензия','ELSAGR');?></a></li>
      <li> <a href="#am"><?=__('От разработчика','ELSAGR');?></a></li>
      <li> <a href="#b"><?=__('Справка','ELSAGR');?></a></li>
      <li> <a href="#c"><?=__('Параметры','ELSAGR');?></a></li>
      <li> <a href="#d"><?=__('О разработчике','ELSAGR');?></a></li>
      <li> <a href="#e"><?=__('Купить ключ','ELSAGR');?></a></li>
      <li> <a href="#f"><?=__('Ответы на вопросы','ELSAGR');?></a></li>
      <li> <a href="#g"><?=__('Ссылки','ELSAGR');?> </a></li>

  </div>  <br/>


     <div id="elsagrfmpt">

      <a name="a"></a> <br /> <h1><?=__('О плагине','ELSAGR');?></h1>
         <span class="elsagrinner">
         <?=convertrequire(dirname(__FILE__).'/help_about_plugin.php'); ?>
         </span>

      <br/><br/>
      
      <a name="lic"></a>  <h1><?=__('Лицензия','ELSAGR');?></h1>
         <span class="elsagrinner">
         <?=convertrequire(dirname(__FILE__).'/help_lic.php'); ?>
         </span>

      <br/><br/>
      
      
      <a name="am"></a>  <h1><?=__('От разработчика','ELSAGR');?></h1>
         <span class="elsagrinner">
         <?=convertrequire(dirname(__FILE__).'/help_from_devel.php'); ?>
         </span>
         
         
         
      <br/><br/>
      <a name="b"></a>  <h1><?=__('Справка','ELSAGR');?></h1>
         <span class="elsagrinner">
         <?=convertrequire(dirname(__FILE__).'/help_docs.php'); ?>
         </span>
         


      <br/><br/>
      <a name="c"></a>  <h1><?=__('Параметры','ELSAGR');?></h1>
         <span class="elsagrinner">
         <?=convertrequire(dirname(__FILE__).'/help_settings.php'); ?>
         </span>

      <br/><br/>
      <a name="d"></a>  <h1><?=__('О разработчике','ELSAGR');?></h1>
         <span class="elsagrinner">
          <?=convertrequire(dirname(__FILE__).'/help_devel.php'); ?>
         </span>

      <br/><br/>
      <a name="e"></a>  <h1><?=__('Купить ключ','ELSAGR');?></h1>
         <span class="elsagrinner">
          <?=convertrequire(dirname(__FILE__).'/help_buykey.php'); ?>
         </span>
         
      <br/><br/>
      <a name="f"></a>  <h1><?=__('Ответы на вопросы','ELSAGR');?></h1>
         <span class="elsagrinner">
          <?=convertrequire(dirname(__FILE__).'/help_faq.php'); ?>
         </span>

      <br/><br/>
      <a name="g"></a>  <h1><?=__('Ссылки','ELSAGR');?></h1>
         <span class="elsagrinner">
         <?=convertrequire(dirname(__FILE__).'/help_links.php'); ?>
         </span>
         
     </div>
</div> </div> </div>
