<?php
_e('Разработчик &mdash; <a href="http://savitov.ru">Иннокентий Савитов</a>, Россия <br />E-mail &mdash; <a href="mailto:kesha@savitov.ru">kesha@savitov.ru</a> <br />','ELSAGR');
?>
