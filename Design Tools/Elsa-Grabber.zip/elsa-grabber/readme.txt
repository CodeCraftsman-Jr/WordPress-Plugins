﻿=== ElSa grabber ===
Contributors: Elchesav
Tags: grabber, ElSa grabber, RSS, RSS grabber, post, posts, auto poster, plugin, RSS parser, grabber, parser html, autoposter, auto publisher, autoblog, parser
Requires at least: 2.8
Tested up to: 3.5
Stable tag: 4.0.5

The given plug-in copies materials from other sites.<br />
More information search on http://savitov.ru/ELSAGR/

== Description ==

EN<br>
The given plug-in copies materials from other sites.

Copying occurs through parsing RSS of a tape of a site-source, however, information extraction can occur not only from RSS, but also from site pages.

Distinctive features of the given plug-in:
<br>1. Parsing RSS of a tape of a site – a source and extraction of the information from it.
<br>2. Parsing HTML of pages of a site – a source and extraction of the information from it.
<br>3. Download pictures from a site – a source on a site – the receiver.
<br>4. Support of different codings of the text.
<br>5. Support wrong HTML.
<br>6. Import of the received data on a site – the receiver.
<br>7. Start under the schedule.
<br>8. Evident testing of the task and a debugging facility.

<br><br>

If u have any problem with my plugin u can write me to kesha@savitov.ru  <br>
For more information search on http://savitov.ru/ELSAGR/

RU
<br>Данный плагин копирует материалы с других сайтов.

Копирование происходит через парсинг RSS ленты сайта-источника, однако, извлечение информации может происходить не только из RSS, но и из страничек сайта.

<br>Отличительные особенности данного плагина:
<br>1. Парсинг RSS ленты сайта – источника и извлечение информации из нее.
<br>2. Парсинг HTML страниц сайта – источника и извлечение информации из нее.
<br>3. Закачка картинок с сайта – источника на сайт – приемник.
<br>4. Поддержка разных кодировок текста.
<br>5. Поддержка синтаксически неправильного HTML.
<br>6. Импорт полученных данных на сайт – приемник.
<br>7. Запуск по расписанию.
<br>8. Наглядное тестирование задания и средства отладки.
<br><br>

При проблемах пишите мне на  kesha@savitov.ru  <br>
Сайт плагина http://savitov.ru/ELSAGR/


== Installation ==

1. Upload `ElSa grabber` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Set settings in the menu parameters

== Changelog ==

= 4.0.5 =
* All information on http://savitov.ru/ELSAGR/

= 4.0.4 =
* All information on http://savitov.ru/ELSAGR/

= 4.0.3 =
* All information on http://savitov.ru/ELSAGR/

= 4.0.2 =
* All information on http://savitov.ru/ELSAGR/

= 4.0.1 =
* Initial release

== Upgrade Notice ==
Если вы используете прежние версии плагина то для избежания потери заданий скопируйте их себе из папки /task которая находится в папке плагина

== Screenshots ==
1. List of task
2. Settings
