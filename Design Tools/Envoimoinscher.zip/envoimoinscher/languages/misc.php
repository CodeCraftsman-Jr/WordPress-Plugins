<?php
// ne sert à rien sauf à stocker des chaînes pour traduction

function dummy_function(){
	echo __('The EnvoiMoinsCher delivery plugin for WooCommerce connects your site to over 15 carriers and simplifies your shipping process.', 'envoimoinscher');
}