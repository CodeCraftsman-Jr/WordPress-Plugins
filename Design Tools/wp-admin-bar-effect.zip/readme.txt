﻿=== WP Admin Bar Effect ===
Contributors: 23r9i0
Donate link:
Tags: Admin, Admin bar, Effect, Customize menu, menu, Toolbar
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: 2.5.3
License: GPL2

Add effect to admin bar for show & hide with mouse hover

== Description ==

Hide or show the desktop bar with a single effect and add a link to site inside sidebar (optional).
In addition you can control the speed, sensitivity to active the effect.

== Installation ==

1. Upload the 'wp-admin-bar-effect' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. If you want to customize a bit the look and feel of wabe, go to the Options Page under General Options in the WordPress Admin panel


== Changelog ==
= 2.5.3 =
* Add Disabled plugin update on PHP 5.3, last updated Require 5.4 or later
* Restore old version
= 2.5.2 =
* fix error quicklinks in 4.1
= 2.5.1.1 =
* fix error name function
= 2.5.1 =
* fix constant developer
= 2.5 =
 * Update plugin for WordPress 3.8
 * Rewrite Plugin Class
 * Use dashicons for default image and allow use.
= 2.4 =
 * remove older versions

== Screenshots ==

1. screenshot

== Upgrade Notice ==
= 2.5.3 =
Add Disabled plugin update on PHP 5.3, last updated Require 5.4 or later