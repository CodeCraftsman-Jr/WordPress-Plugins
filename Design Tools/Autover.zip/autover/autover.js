function a(b) {
	return b+2;
}
