=== Tabs Ultimate ===
Contributors: jeffbullins
Donate link: http://www.thinklandingpages.com
Tags:   jquery tabs, tabs, Tabs plugin, tabs plugin jquery, tabs plugin wordpress, tabs short-code, tabs Widget, responsive, responsive tabs, shortcode, tab, tabs shortcode
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An easy way to place a tabs ultimate with content on your Wordpress site.

== Description ==


An easy way to place a tabs ultimate with content on your Wordpress site.

###Quick Start Guide

* [tabs ultimate quick start guide at thinklandingpages.com] (http://www.thinklandingpages.com/tabs_ultimate/)

###What you get when you use the Tabs Ultimate tabs ultimate

*  Place a tabs with a simple shortcode [tabs_ultimate id="%postId%"]
*  Fully Responsive tabs
*  Put tabs on any post or page.
*  Unlimited tabs
*  User interface to create tabs


###Add tabs ultimate to any post or page

Whether you are writing a post about your company or another company, you can include a well formatted tabs group.


###Tabs Ultimate 

Add as many tabs to your site as you like.  Tabs Ultimate lets you create tabs  and save them for when ever you are ready to use them.

###Quick Start Guide

* [tabs ultimate quick start guide at thinklandingpages.com] (http://www.thinklandingpages.com/tabs_ultimate/)

== Installation ==


1. Upload `tabs ultimate` to the `/wp-content/tabs ultimates/` directory
1. Activate the tabs ultimate through the 'Tabs Ultimates' menu in WordPress
1. Click **Tabs Ultimate** on the admin menu to enable and set your options.


== Frequently Asked Questions ==

= Do I have to know how to program or design? =

No.  Tabs ultimate does the programming and design.

= Is there a limit to the number of tabs I can create? =
No, unlimited tabs can be created.

= Can the tabs be put on my homepage? =
Yes, you can put tabs on your homepage by using the Tabs Ultimate shortcode on you homepage.

= Can I put tabs on any post or page? =
Yes, use the tabs ultimate shortcode, [tabs_ultimate id="%postId%"] on your pages and posts.


== Screenshots ==

[See screenshots at thinklandingpages.com] (http://www.thinklandingpages.com/tabs_ultimate/)


== Changelog ==

= 1.0 =
* First Release


