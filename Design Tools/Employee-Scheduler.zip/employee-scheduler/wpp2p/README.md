lib-posts-to-posts
==================

This repository contains the library for managing connections and connection types. It does not contain any UI code.

It is meant to be integrated into a theme or a plugin.

See the [`_p2p_load()`](https://github.com/scribu/wp-posts-to-posts/blob/master/posts-to-posts.php) from the original Posts 2 Posts plugin to see what's needed for initializing it.
