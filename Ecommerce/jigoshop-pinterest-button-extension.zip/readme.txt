=== Jigoshop Pinterest Button Extension ===
Contributors: jeremy_61
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=MDCLRH8MMLR98
Tags: Jigoshop, Pinterest, Jigoshop Pinterest Extension, e-commerce
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 1.0.0

Easily add a Pinterest Pin-it button to your Jigoshop single product pages. This allows customers to easily post your product images directly to Pinterest.

== Description ==
There is an option added to the Product Details tabs when adding a new product. The new tab is called Pinterest where there is a checkbox to either enable or disable Pinterest from appearing on a product. The Pin-it button is not automatically added to all products.

Visit [61 Extensions](http://61extensions.com/ "Jigoshop Extensions") and contact us for assistance.
  

== Installation ==
<p>Installation:</p>
<ol>
<li>Login to your wordpress admin</li>
<li>Go to the Plugins page</li>
<li>Click "Add New"</li>
<li>Once you're on the "Install Plugins" page, click the "Upload" link. </li>
<li>After you click the upload option, click the "choose file" button, which will open a standard, filesystem dialog. Navigate to where you've save the plugin zip, and choose the plugin zip file. </li>
<li>Once the path to the file is in the box, click the "Install Now button. </li>
<li>After you've done that, your file should now show up in your "Installed Plugins" page. </li>
<li>Click Activate on the "Jigoshop Pinterest Pin-it Button"</li>
</ol>
== Screenshots ==
1. Pin-it Button added to a product


== Changelog ==
= 1.0 =
* Initial release


== Upgrade Notice ==

== Frequently Asked Questions ==
