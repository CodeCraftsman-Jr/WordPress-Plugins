<?php
function is_checked($i){
    if($i==0) $checked="checked";
    else $checked = NULL;
    
    return $checked;
}
?>
