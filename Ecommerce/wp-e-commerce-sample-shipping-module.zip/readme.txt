=== Plugin Name ===
Contributors: leewillis77
Tags: e-commerce, shipping
Requires at least: 2.8
Tested up to: 4.3
Stable tag: 0.2

Sample shipping module for the WP E-Commerce system.

== Description ==

Sample shipping module for the WP E-Commerce system. Used to illustrate the tutorial here:

http://getshopped.org/resources/docs/get-involved/writing-a-new-shipping-module/

Download this and customise to your own needs.

== Installation ==

*You Must* already have the following plugin installed:

1. [WP e-Commerce](http://wordpress.org/extend/plugins/wp-e-commerce/)
2. See the tutorial [here](http://getshopped.org/resources/docs/get-involved/writing-a-new-shipping-module/)

== Frequently Asked Questions ==

* How do I make this module do XXXX ?
See the tutorial [here](http://getshopped.org/resources/docs/get-involved/writing-a-new-shipping-module/) and ask in the WP E-Commerce [forums](http://getshopped.org/forums/)

== Changelog ==

= 0.2 =
Compatibility with WP e-Commerce 3.7.6

= 0.1 =
* Initial Release
