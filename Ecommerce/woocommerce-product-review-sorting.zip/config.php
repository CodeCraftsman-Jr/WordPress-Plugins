<?php

define('WC_PRODUCT_REVIEW_SORTING_PLUGIN_TOKEN', 'wc-product-review-sorting');

define('WC_PRODUCT_REVIEW_SORTING_TEXT_DOMAIN', 'product_review_sorting');

define('WC_PRODUCT_REVIEW_SORTING_PLUGIN_VERSION', '1.0.0');
?>