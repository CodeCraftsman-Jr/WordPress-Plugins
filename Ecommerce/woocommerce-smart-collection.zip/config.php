<?php

define('DC_WOO_SMART_COLLECTION_PLUGIN_TOKEN', 'dc-Woo-Smart-Collection');

define('DC_WOO_SMART_COLLECTION_TEXT_DOMAIN', 'Woo_Smart_Collection');

define('DC_WOO_SMART_COLLECTION_PLUGIN_VERSION', '1.0.7');

?>