<? 

printf(json_decode(file_get_contents($url)));

?>