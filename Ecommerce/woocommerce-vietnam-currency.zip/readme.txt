﻿== Woocommerce Vietnam Currency ==
Contributors: Thach Pham
Tags: woocommerce,vietnamese,vietnam dong
Donate link: http://thachpham.com
Requires at least: 3.5.1
Tested up to: 3.6.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Thêm loại tiền tệ Việt Nam Đồng (VNĐ) vào Woocommerce và tích hợp tính năng tự chuyển tỷ giá VNĐ sang USD để sử dụng thanh toán qua Paypal.

== Description ==
Woocommerce Vietnam Currency là plugin bổ sung loại tiền tệ Việt Nam Đồng (VNĐ) vào hệ thống tiền tệ trong Woocommerce.

Ngoài ra nó cũng có thêm tính năng cho phép kích hoạt phương thức thanh toán qua PayPal đối với loại tiền tệ VNĐ bằng cách tự động chuyển tỷ giá VNĐ sang USD khi thanh toán qua PayPal. Bạn có thể tự tùy chỉnh tỷ giá chuyển đổi.

== Installation ==
1. Upload thư mục \'woocommerce-vietnam-currency\' vào wp-content/plugins
1. Kích hoạt plugin trong khu vực Plugins -> Installed Plugins
1. Vào Settings -> Woocommerce VND tùy chỉnh tỷ giá chuyển đổi.

== Frequently Asked Questions ==
= Tôi có thể tùy chỉnh tỷ giá chuyển đổi không?
Hoàn toàn được.


== Screenshots ==
1. Thêm VNĐ vào hệ thống Woocommerce
2. Hiển thị tiền tệ VNĐ khi thanh toán.
3. Tự chuyển VNĐ sang USD khi thanh toán qua PayPal.