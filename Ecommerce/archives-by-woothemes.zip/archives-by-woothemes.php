<?php
/**
 * Plugin Name: Archives by WooThemes
 * Plugin URI: http://woothemes.com/
 * Description: This plugin has been retired. Thanks for using it!
 * Author: Matty Cohen | WooThemes
 * Version: 0.0.0
 * Author URI: http://woothemes.com/
 */
?>