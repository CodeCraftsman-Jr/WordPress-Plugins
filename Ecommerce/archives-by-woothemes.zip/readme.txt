=== Archives by WooThemes ===
Contributors: woothemes,mattyza,jeffikus
Donate link: http://woothemes.com/
Tags: retired
Requires at least: 3.4.2
Tested up to: 3.5.2
Stable tag: 0.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin has been retired. Thanks for using it!

== Description ==

This plugin has been retired. Thanks for using it!

== Changelog ==

= 0.0.0 =
* This plugin has been retired. Thanks for using it!