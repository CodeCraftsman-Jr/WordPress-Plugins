<?php
/*
 * Bissmillah
 * This file will call api's to Facebook album
 * to import photos of visitor
 * 
 * moved as Addon plugin 3 September, 2014
 */
