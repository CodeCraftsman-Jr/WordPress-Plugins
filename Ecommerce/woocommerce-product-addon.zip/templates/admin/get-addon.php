<?php
/*
 * this is just to explain PRO features
 */

$proFeatures .= '<p>';
$proFeatures .= '<h2>'.__('Best Photo Editing Tool', 'nm-personalizedproduct').'</h2>';
$proFeatures .= __('This plugin can be used as best Photo Editing Tool to allow your users to upload and Edit Photos online using world\'s best Photo Editor \'Aviary\'. There is an Add-on for this','nm-personalizedproduct');
$proFeatures .= '<br><br><a class="button" target="_blank" href="http://www.aviary.com/">'.__('What is Aviary?','nm-personalizedproduct').'</a>';
$proFeatures .= ' <a class="button-primary" href="">'.__('See Demo','nm-personalizedproduct').'</a>';
$proFeatures .= ' <a class="button-primary" href="">'.__('Get Pro + Addon','nm-personalizedproduct').'</a>';
$proFeatures .= '</p>';


$proFeatures .= '<br>More detail: <a href="http://www.najeebmedia.com/import-facebook-photos-to-wordpress-woocommerce-addon/">Demo</a>';

echo $proFeatures;
?>
