=== Paypal Standard Gateway for Ninja Forms ===
Contributors: aman086
Donate link: http://webholics.in
Requires at least: 3.5
Tags: ninja forms,forms,field,payment gateway,payment gateways,nf paypal,ninja paypal,paypal standard gateway,donation,recurring,trial,donation,ninja forms paypal gateway
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later

Paypal Standard Gateway for Ninja Forms

== Description ==
Paypal Standard Gateway for Ninja Forms lets you create forms integrated with paypal payment gateway. You can create custom order form and take payments using Paypal standard account.

Features:

* Easy to Integrate
* IPN Integration
* Enable/Disable Paypal gateway on individual Forms
* Fields Mapping

Get <a href="http://codecanyon.net/item/ninja-forms-paypal-standard-payment-gateway/10047955">PRO</a> version for more features:
`
PRO Version Features:

* Recurring Payments
* Trial Period option
* Advance Reports
* and many more...
`

== Installation ==
* Upload the plugin to wp-content->plugins directory,
* Activate it from wordpress dashboard
* Edit Form and you will see Paypal Settings in Forms Settings tab

== Screenshots ==
1. Paypal Standard Settings

== Changelog ==
= 1.0 =
Intial Release