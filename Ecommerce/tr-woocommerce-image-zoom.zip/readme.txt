=== Tr Woocommerce Image Zoom ===
Contributors: BestThemeRoad
Author URI: https://profiles.wordpress.org/bestthemeroad
Author: Theme Road
Donate link: 
Tags:  hover over image to zoom, mouse over image zoom, mouse over zoom image, product image cloud zoom, woocommerce gallery, woocommerce gallery plugin, woocommerce image gallery plugin, WooCommerce Product Gallery, woocommerce product gallery plugin, woocommerce product gallery slider, woocommerce zoom, woocommerce zoom image plugin, woocommerce zoom magnifier, woocommerce zoom plugin, zoom image on hover,ecommerce product magnify plugin, image gallery zoom, jquery picture zoom, photo zoom add on, picture zoom plugin, woocommerce product zoom, woocommerce zoom
Requires at least: 3.5
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will add image zoom fearure in your woocommerce product image.


== Description ==

### Tr Woocommerce Image Zoom by http://themeroad.net

This plugin will add image zoom fearure in your woocommerce product image.

Plugin Features

 * No need any extra settings.
 * Very light weight.
 * Work with all WordPress theme.
 * Easy to use.
 * Developer friendly & easy to customize.
 * Powered by Elevate Zoom.




* [Our Premium Plugins](http://themeroad.net/154-2/)
 * [TR WP Custom Login](http://themeroad.net/Products/wp-custom-login-page/)
 * [TR Advanced Price Plan Pro](http://themeroad.net/Products/tr-price-plan-pro/)
 * [TR WooCommerce Image Zoom PRO](http://themeroad.net/Products/tr-woocommerce-image-zoom-pro/)
 * [TR Carousel Slider Pro](http://themeroad.net/Products/tr-carousel-slider-pro-4/)
 * [TR Logo Slider Pro](http://themeroad.net/Products/tr-logo-slider-pro/)
 * [TR Filterable Portfolio Pro](http://themeroad.net/Products/204/)
 * [TR Nice Accordion Pro](http://themeroad.net/Products/tr-premium-accordion-pro/)





== Frequently asked questions == 


1. Is it a Responsive Plugin?
 Ans: Yes.
2. Have any options to contact for solve our problem?
 Ans: Ofcourse,why not. Just mail us BestThemeRoad@gmail.com or comments  to solve your problem.


== Screenshots ==

1. This is the view of the admin panel page
2. This is the view of the plugin when you add this in the any page or footer of the post
3. This is the view of the plugin when you add this in the widgets in your sites



== Changelog ==

= 1.0 =
* Initial release

