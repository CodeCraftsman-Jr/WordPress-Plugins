=== etruel Stock in list for eshop plugin ===
Contributors: etruel
Donate link: http://www.netmdp.com/temas/wordpress/
Tags: Stock, plugin, edit-in-place, eshop, e-shop, esilfe, column
Requires at least: 2.6
Tested up to: 2.8.2
Stable tag: 0.1c

Plugin for eshop plugin. Show a clickable "out of Stock" in one column in the list of posts then you do not need edit a post for change this value.

== Description ==

Plugin for **[eshop](http://wordpress.org/extend/plugins/eshop/)** plugin of *Rich Pedley* .
Show a checkbox clickable of "**Out of Stock**" in one column in the list of posts then you do not need edit a post only for change this value.
If the user haven`t "eshop" capabilities then only see if have stock.

May be PHP5 is required!

Copyright 2009.
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version. 

[Traducción al español de Argentina de la Licencia GNU](http://www.spanish-translator-services.com/espanol/t/gnu/gpl-ar.html)

== Installation ==

You can either install it automatically from the WordPress admin, or do it manually:

1. Unzip "esilfe" archive and put the folder into your plugins folder (/wp-content/plugins/).
2. Activate the plugin from the Plugins menu.

== Frequently Asked Questions ==

= Can I use this plug-in without eshop plugin? =

No.

= If I use this plugin, won't all registered users be able to edit the Stock field? =

No. Only the user's rol that have "eshop" capabilities created by eshop plugin.

= Waiting others questions? =

Yeah.

== Screenshots ==

1. The column in Post's List Admin page.

== Changelog ==

= 0.1c =
* upgrade for WP2.8.2
* fixed little bugs

= 0.1 =
* initial release
* [more info in spanish, en español](http://www.netmdp.com/2009/07/esilfe-plugin/)

