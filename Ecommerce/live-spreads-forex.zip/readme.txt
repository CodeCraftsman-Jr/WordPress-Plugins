=== Plugin Name ===
Contributors: (trader.tools)
Tags: Forex, FX, Live Spreads, Forex Spreads
Requires at least: 3.4.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This free plugin will display the data shown at http://trader.tools/ on your site. 

== Requirement ==

registration is required. We need your url for the code to work, the code uses ajax to call the data.
registration is painless just send the URL ( http://domain.com or if subdomain http://sub.domain.com ) to plugins@trader.tools WITH SUBJECT [activate my plugin] and as soon as you have a reply - the data will stream in.

== Installation ==

Unpack plugin code in your plugins directory and activate thru admin

== Screenshots ==

Screenshot.png included

== Changelog ==

= 1.0 =
* released November 4, 2014

== Changelog ==

= 2.0 =
* released January 5,2015