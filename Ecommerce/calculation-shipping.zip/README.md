# Calculation Shipping

Contributors: caicedo1089 <br />
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=Y5HAX83JLCXR2 <br />
Tags: Calculation Shipping, Calculator, Carrier, Shipping, Calculadora de Envios, Envios <br />
Requires at least: 3.0.1 <br />
Tested up to: 3.4 <br />
Stable tag: 0.2 <br />
License: MTI <br />
License URI: http://www.opensource.org/licenses/mit-license.php <br />

## Description

Plugin WordPress que realiza el cálculo estandar de los envíos.
