=== Calculation Shipping ===
Contributors: caicedo1089
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=Y5HAX83JLCXR2
Tags: Calculation Shipping, Calculator, Carrier, Shipping, Calculadora de Envios, Envios 
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 0.2
License: MTI
License URI: http://www.opensource.org/licenses/mit-license.php

Plugin WordPress que realiza el cálculo estandar de los envíos

== Description ==

Plugin WordPress que realiza el cálculo estandar de los envíos.
