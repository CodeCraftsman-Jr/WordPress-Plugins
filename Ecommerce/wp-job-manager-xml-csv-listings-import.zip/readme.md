#WP Job Manager Add-On

## Add-On Issues

* Not sure how to assign to Guest User.

* Upload video

* Check that radio is selecting first option