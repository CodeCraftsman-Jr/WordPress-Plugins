jQuery(document).ready(function($){

    if( sessionStorage.getItem('wc_cart_hash') == '' ){
        sessionStorage.removeItem('wc_fragments');
    }


});

