<?php
/**
 * This file is part of TheCartPress.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once( 'MainSettings.class.php' );
require_once( 'CurrencyCountrySettings.class.php' );
require_once( 'TaxSettings.class.php' );

require_once( 'PluginsList.class.php' );
require_once( 'PluginsListShipping.class.php' );

require_once( TCP_CHECKOUT_FOLDER . 'CheckoutSettings.class.php' );
require_once( TCP_CHECKOUT_FOLDER . 'CheckoutEditor.class.php' );

require_once( 'FirstTimeSetup.class.php' );

//require_once( 'EMarketingSettings.class.php' );