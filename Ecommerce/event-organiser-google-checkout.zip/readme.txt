=== Event Organiser Google Checkout ===
Contributors: stephenharris
Donate link: http://www.wp-event-organiser.com/donate
Tags: events, event, tickets, bookings, Google Checkout, registration, ticketing,
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 1.0

Sell event tickets through Google Checkout. Requries Event Organiser & Event Organiser Pro

== Description ==

This plug-in adds Google Checkout to the available payment gateways in Event Organiser Pro.

Event Organiesr Google Checkout requries **Event Organiser 2** or higher and **Event Organiser Pro 1.0.1** or higher

== Installation ==

Installation is standard and straight forward. 

1. Go to your 'Plug-ins' admin page, and go to 'Add New', 'Upload'
1. Select event-organiser-google-checkout.zip and click 'install now'
1. Activty the plug-in
1. Proceed to 'Event Organsier' under your site's Settings admin tab to set up the plug-in

== Frequently Asked Questions ==


== Changelog ==
