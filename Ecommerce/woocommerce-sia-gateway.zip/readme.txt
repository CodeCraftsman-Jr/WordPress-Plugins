===WooCommerce Sia Payment Gateway===
Contributors: (iwcontribution)
Tags: WooCommerce Sia Payment Gateway, WooCommerce extension
Requires at least: 4.2.2
Tested up to: 4.2.2
Sia allows secure payment.
==Description==
This is Woocommerce Sia Payment Gateway extension which helps to make payment securely.
== Installation ==
1.Download the Sia Payment Gateway plugin zip file and extract to the  `/wp-content/plugins/` directory.
2.Activate the plugin through the 'Plugins' menu in WordPress Admin.
== Screenshots ==

= 1.0 =
The First Release

