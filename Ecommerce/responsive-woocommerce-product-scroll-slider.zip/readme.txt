=== Responsive Woocommerce Product Scroll Slider ===
Contributors: Raju
Donate link: http://prosperent.couponfortoday.com/
Tags: slider,responsive slider,OwlCarousel-master,lazyLoad,themes,Woocommerce slider,responsive,slider,slider , Woocommerce,plugin,image,posts,shortcode,Woocommerce,links,Woocommercepage,Woocommerce plugin,Woocommerce slider plugin,Woocommerce best scroll plugin,Woocommerce best slider plugin, Woocommerce slider
Requires at least: 3.0
License: GPLv2 or later
Tested up to: 4.2
Stable tag: V3.0

Woocommerce Scroll Slider Plugin is a beautifully designed and an OwlCarousel-master plugin.
== Description ==

The Responsive Woocommerce Scroll slider plugin comes by default with a beautiful, responsive, modern theme.
This plugin is designed for users and the UI is very intuitive and easy to use.

= Features =

* Option to display Title or not.
* Responsive scroll slider
* Insert scroll slider anywhere on your site using a simple shortcode
* Works on iOS, Android and other mobile devices

I hope you like and love my plugin in the same way like I do and to love it you have to actually install and use it. Please install the plugin and use it.


== Screenshots ==

1. Responsive Woocommerce Product Scroll Slider
2. Responsive Woocommerce Product Scroll Slider admin settings


= Technical support =

Dear users, our plugins are available for free download. If you have any questions or recommendations regarding the functionality of our plugins (existing options, new options, current issues), please feel free to contact us Email: raju@wpfreeplugin.com. Please note that we accept requests in English only. All messages in another languages won't be accepted.


If this has helped you and saved you time please consider a donation via PayPal to:
rajuranjan.239@gmail.com

== Installation ==

1. Upload and extract the zip file downloaded to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on the new menu item "Woocommerce Product Slider" and do necessary setting.
4. Place [woopsc]  in your template where you want the Woocommerce product scroller to be displayed.
5. If you want to add woocommerce scroll slider shortcode  directly into template then please use 
	<?php do_shortcode('[woopsc]'); ?>
	

== Frequently Asked Questions ==

= When can I use this plugin? =
You can use this plugin only when you have installed the WooCommerce Plugin.
= How can I use this plugin in template file?  =
If you want to add woocommerce scroll slider shortcode  directly into template then please use 
	<?php do_shortcode('[woocommerce scroll slider]'); ?>
					OR
	<?php do_shortcode('[woopsc]'); ?>

= When can I use this plugin? =
You can use this plugin only when you have installed the WooCommerce Plugin.


== Changelog ==

= V3.0 - 07/04/2015 =
* Fix - Cannot send session cache limiter - headers already sent problem
* Fix - Displaying all the products or display only specific product categories.
* Fix - Code Easily Modify.


= V2.0 - 2014/04/18 =

== Upgrade Notice ==

= V2.0 Latest =