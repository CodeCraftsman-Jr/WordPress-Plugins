<?php
  if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
  }
?>

<div class="error">
	<p><?php _e( '"' . XO10_WC_CATS_PLUGIN_OFFICIAL_NAME . '" not activated because the WooCommerce plugin is not active.'); ?></p>
</div>