(function ( $ ) {
	"use strict";

	$(function () {

		$(document).ready(function() {

		});
	});

}(jQuery));