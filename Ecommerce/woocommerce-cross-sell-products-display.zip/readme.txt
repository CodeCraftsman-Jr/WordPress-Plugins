=== Woocommerce Cross Sell Products Display ===
Contributors:logicfire
Donate link: 
Tags: woo commerce, wordpress, cross-sells products, woo commerce cross-sell products 
Requires at least: 3.0
Tested up to: 4.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allow to display cross sell products on single product page.

== Description ==

Allow to display cross sell products on single product page.
* Shortcode [wcsp_cross_sell orderby="rand” order=“ASC” product_num=“5” display_columns=“3” title=“Some title..” category=“Category ID”]


== Installation ==

If you would prefer to do things manually then follow these instructions:

1. Upload the `woocommerce-cross-sell-products-display` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Settings -> Cross Sell Products Settings, click on WordPress

== Changelog ==

16/3/2015
Added:
Display cross sell products by category.
* Shortcode [wcsp_cross_sell orderby="rand” order=“ASC” product_num=“5” display_columns=“3” title=“Some title..” category=“Category ID”]
* Work with shortcode only.
