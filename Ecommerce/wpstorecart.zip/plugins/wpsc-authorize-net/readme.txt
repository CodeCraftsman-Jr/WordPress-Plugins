=== wpStoreCart 3+ Authorize.NET SIM Payment Gateway ===
Contributors: jquindlen
Donate link: http://wpstorecart.com/
Tags: wpStoreCart
Requires at least: 3.3.0
Tested up to: 3.5
Stable tag: 2.0.1

wpStoreCart 3+ Authorize.NET SIM Payment Gateway

== Description ==

wpStoreCart 3+ Authorize.NET SIM Payment Gateway

Requires wpStoreCart 3.0.6 or higher

== Installation ==

- 

== Frequently Asked Questions ==

-

== Screenshots ==
 
1. wpStoreCart 3+ Authorize.NET SIM Payment Gateway

== Changelog ==

= 2.0.1 =
* Fixed: Issue with payment status not updating was patched
* Fixed: Typo fixed
* Fixed: Switched to $wpscPaymentGateway['final_price_with_discounts'] for final price to properly reflect discounts

= 2.0.0 =
* New release!

== Upgrade Notice ==

= 2.0.0 =
* New release!
