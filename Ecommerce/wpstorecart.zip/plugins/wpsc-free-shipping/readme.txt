=== wpStoreCart Free Shipping  ===
Contributors: jquindlen
Donate link: http://wpstorecart.com/
Tags: wpStoreCart
Requires at least: 3.3.0
Tested up to: 3.5
Stable tag: 1.0.0

Offer free shipping when an order is over a certain monetary value.

== Description ==

Offer free shipping when an order is over a certain monetary value.  
For example, with this plugin, you can make free shipping available 
after $50 in items are added to cart.

== Installation ==

Replace this with your installation instructions

== Frequently Asked Questions ==

Replace this with your FAQ

== Screenshots ==
 
1. Offer free shipping when an order is over a certain monetary value.

== Changelog ==

= 1.0.0 =
* First release!

== Upgrade Notice ==

= 1.0.0 =
* First release!