=== wpStoreCart 3+ 2Checkout Payment Gateway ===
Contributors: jquindlen
Donate link: http://wpstorecart.com/
Tags: wpStoreCart
Requires at least: 3.3.0
Tested up to: 3.5
Stable tag: 2.0.1

wpStoreCart 3+ 2Checkout Payment Gateway

== Description ==

wpStoreCart 3+ 2Checkout Payment Gateway

== Installation ==

-

== Frequently Asked Questions ==

-

== Screenshots ==
 
1. wpStoreCart 3+ 2Checkout Payment Gateway

== Changelog ==

= 2.0.1 =
* Changed payment calculation to $wpscPaymentGateway['final_price_with_discounts']

= 2.0.0 =
* New release!

== Upgrade Notice ==

= 2.0.0 =
* New release!
