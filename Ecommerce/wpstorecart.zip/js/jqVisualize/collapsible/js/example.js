$(function(){
	$('h2').collapsible();
});