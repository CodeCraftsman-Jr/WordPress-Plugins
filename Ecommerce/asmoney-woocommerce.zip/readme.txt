=== Plugin Name ===
Contributors: AsMoney
Donate link: https://www.asmoney.com
Tags: Bitcoin, Litecoin, Cryptocurrencym Payment gateway, Merchant
Requires at least: 1.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Accept Bitcoin and Altcoins on your WooCommerce powered website with AsMoney.

== Description ==

This plugin allow you to accept different kinds of cryptocurrencies via AsMoney, Just Open an Asmoney account and active merchant and set merchant data on this plugin.


Payments from AsMoney balance mark as complete after payment instantly but cryptocurrency payments mark as pending and after get 3 confirmation payment will be completed.


== Installation ==

1. Login to WP admin area, Go to Plugins >> Click Add new >> Choose upload plugin and Upload zip plugin package
2. Go to Woocommerce setting >> check out >> Payment methods >> set your AsMoney SCI information.

== Frequently Asked Questions ==

What is AsMoney fees?
There is no fees for accept cryptocurrency payments.

What currencies the plugin support?
USD and EUR, Your customers go to payment gateway and their bitcoin/altcoins change to USD and EUR with live rate and your AsMoney balance will be charged.

Can I change my AsMoney USD/EUR balance to bitcoin/altcoins?
Yes, You can change your balance to bitcoin and other cryptocoins in your AsMoney account area.

== Changelog == 

Initial Release : v1.0