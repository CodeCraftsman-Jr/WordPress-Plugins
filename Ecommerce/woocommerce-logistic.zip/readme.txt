=== WooCommerce Logistic ===
Contributors: agenciamagma, Carlos Cardoso Dias
Donate link: http://www.agenciamagma.com.br
Tags: woocommerce logistic, woocommerce logistica, woocommerce, logistic, stock, stock position, position
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WooCommerce Logistic saves information about the location of the product in stock.

== Description ==

WooCommerce Logistic inserts a field on the product page so that the user can tell where the item is located in your inventory.

= Descrição em Português =

WooCommerce Logistic insere um campo na página do produto , permitindo que o usuário informe onde o item está localizado em seu estoque.

== Installation ==

1. Upload the contents of `woocommerce-logistic` to the `/wp-content/plugins/woocommerce-logistic/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Do I have to install WooCommerce to use this plugin? =

Yes. The plugin was been tested under WooCommerce 2.3.5, so that might be enough.

== Screenshots ==

1. This screenshot shows the field added.

== Changelog ==


= 1.0 =
* First version.

== Upgrade Notice ==

= 1.0 =
First version.
