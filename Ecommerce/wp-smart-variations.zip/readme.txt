=== WP Smart Variations ===
Contributors: rajanit2000,a2ztechnologies
Tags:  WP-Commerce change variations, wp-ecommerce, variations, variations checkbox, variations radio, product variations, ecommerce variations
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is WP eCommerce variations Plugin for WP eCommerce Site. Its use to WP-Commerce change variations from selects to inputs

== Description ==

This is WP eCommerce variations Plugin for WP eCommerce Site. Its use to swap select box to radio buttons for Product variations

= Custom Options =
	
	1. Install Plugin
	2. No need short code
	3. No need functions

== Installation ==

	1. Its very simple Install and Active
	
== Frequently Asked Questions ==

1. Is this plugin working without WP eCommerce Plugin?

	No, WP eCommerce Plugin is required for this plugin

== Screenshots ==

1. screenshot-1.png 

== Changelog ==

= 1.0 =

* New: WP eCommerce Variation Plugin

== Upgrade Notice ==

The current version of WP Smart Wishlist requires WordPress 3.0 or higher. If you use older version of WordPress, you need to upgrade WordPress first.