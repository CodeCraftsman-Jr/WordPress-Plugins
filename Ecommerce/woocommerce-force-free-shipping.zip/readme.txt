=== WooCommerce Force Free Shipping ===
Contributors: vendidero
Tags: woocommerce, woothemes, shipping, shipping method, free shipping
Requires at least: 3.8
Tested up to: 4.2
Stable tag: 0.1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Automatically selects and forces free shipping within WooCommerce cart and checkout if is applicable.

== Description ==

This Plugin ensures that your WooCommerce customers are forced to benefit from free shipping if method is available during checkout.
Free shipping will be automatically selected and all other methods are being temporarily disabled.

== Installation ==

= Minimale Voraussetzungen =

* WordPress 3.8 or newer
* WooCommerce 2.2 or newer

== Changelog ==

= 0.1.0 = 
* Release

== Upgrade Notice ==

= 0.1.0 =
no upgrade - just install :)