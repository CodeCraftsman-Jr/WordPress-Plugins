=== Plugin Name ===
Contributors: Hemant Dhote.
Donate link: 
Tags: minimum weight, order by weight, woo-commerce order per weight, woo-commerce weight, woocommerce .
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allow you to set the minimum weight per order .It will show an error message if the weight is less that the define

== Description ==

This plugin allow you to set the minimum weight per order .It will show an error message if the weight is less that the define 


== Installation ==

This section describes how to install the plugin and get it working.

1.Upload the entire woo-commerce-min-weight  Plugin folder to the /wp-content/plugins/ directory.

2.Activate the plugin through the 'Plugins' menu in WordPress.

3.You will find 'Woo-commerce-Min-weight' menu in your WordPress admin panel.

== Frequently Asked Questions ==

= Will this plugin support the latest version of woo-commerce =

Yes.

= Will it also work for the miniumn quantity =

No it will not work for the minimum quantity it will only work for weight.


== Screenshots ==

1. screenshot-1.png.

2. screenshot-2.png

== Changelog ==

= 1.0 =
1.Basic Version

