=== Bitcoin Price Ticker ===

Contributors: suicidalfish
Tags: bitcoin, excahnge ticker, mtgox, btcchina, bitstamp, btce
Donate link: http://www.rjmacarthy.com/
Requires at least: 3.0.1
Tested up to: 4.1
Stable Tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A sidebar widget plugin which displays the prices of Bitcoin for four of the most popular exchange websites.

* BTC China
* MT Gox
* BTC-e
* Bitstamp

It is installed exactly like a normal plugin through the admin area. 

Prices are live for each individual exchange website, therefore if the website is down for any reason no results will update or show for the specific exchange.  The widget allows you to change show or hide different exchanges in the settings menu.

The widget will automatically update with the current price of Bitcoin.

It takes a lot of time and effort co create plugins! If you like this plugin please donate Bitcoin to:

1JokP92X916fbvdT9pVdegqrt7c8hCFXJ4 

Thank you!

== Installation ==

1. Upload contents of bitcoin-exchange-rate-ticker.zip to the `/wp-content/plugins/` directory.
2. Activate the plugin through the \\\\\\\\\\\\\\\'Plugins\\\\\\\\\\\\\\\' menu in WordPress
3. Use the widgets menu on your wordpress theme to add the widget to the sidebar.

== Frequently Asked Questions ==

If you have any questions please e-mail me at richardmacarthy@hotmail.com and I'll be happy to answer them.

== Screenshots ==

1. Sidebar widget screenshot showing all tickers.

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.

= 1.0.1 =
* Bug Fixes

= 1.0.2 =
* Style Updates