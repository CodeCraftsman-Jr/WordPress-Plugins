﻿=== PrintWidget by fotube.com ===
Contributors: Delivergo
Donate link: http://euxira.com/
Tags: PrintWidget, Affiliate, Mass Customisation
Requires at least: 3.3.0
Tested up to: 3.3.0
Stable tag: 0.91

PrintWidget by fotube.com

== Description ==

The PrintWidget plugin by fotube.com offers you a easy way to monetarize the traffic of blogs & website 
with printing products & personalised gifts. 
 
More information coming soon ...

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload PrintWidget folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/0.8/screenshot-1.jpg` (or jpg, jpeg, gif)
2. This is the second screen shot

== Changelog ==

= 0.91 =
* Fix some bugs.