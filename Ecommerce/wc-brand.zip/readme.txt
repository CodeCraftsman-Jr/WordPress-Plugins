===Woocommerce Brand===
Contributors: (iwcontribution)
Tags: Woocommerce Brand, Woocommerce extension, Woocommerce, Brand
Requires at least: 3.5.1
Tested up to: 4.2.2
Woocommerce Brand allows add Brand for products and display in the fronend.

== Description ==
This is Woocommerce Brand extension which helps to add Brand for products and display in the fronend.
Here you can add brand feature image.
There are four types of diplay user can choose from backend widget section.

== Installation ==
1. To run this extension make sure that you have installed woocommerce plugin and activate it.
2. Download the Woocommerce Brand plugin zip file and extract to the  `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress Admin.

== Screenshots ==
1. Brand crousel.
2. Brand dropdown.
3. Brand A to Z Filter.
4. Brand thubnail.
5. Backend widget section.

= 1.0 =
The First Release

