=== Marketpress Frontend ===
Contributors: Corlax Technologies
Tags:  Membership, Plugins, WordPress, Marketpress, eCommerce, Frontend, Publish Product
Requires at least: 3.9
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Running MaketPress Store  and want to provide your user to publish product from frontend then this plugin will help you to do this. Just install activate and add your shortcode for start.

 ** Features:- **

 * Edit Post
 * Support Membership Plugin
 * Add Custom Field
 * Ajax Upload
 * Ajax Form Validation
 * disable Visual editor for content
 * enable Visual editor for excerpt
 * Help Text For Tag
 * Limit Number Of Post
 * Other bugs fixs (Category ajax error fix, PHP error, Login Issue, Change Submit Button Text)
 * Let User Submit Post From Frontend
 * Support Download File for digital download
 * support price and sale price (for discount)
 * Post Type and taxnomy Support
 * Publish post or Pending post
 * Enable/disable Captcha
 * Success Message

==Installation==
1. Download the plugin  file
2. Unzip the file to /wp-content/plugins/ folder on your site
3. Activate it through admin.
4. Insert this shortcode [wp_store_frontend] where you want to show your form in frontend