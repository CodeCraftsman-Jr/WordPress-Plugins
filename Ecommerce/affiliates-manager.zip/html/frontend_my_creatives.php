<?php
/**
 * Added to display affiliate creatives via the front page
 * @UNUSED
 */
// global (if needed)
?>

<div class="wrap">
	<div class="user-profile-links">
		<a href="?sub=reporting">Reporing</a> |
		<a href="?sub=creatives">Creatives</a>
	</div>

	<br />
	I've made it to the my creatives page

</div>