<?php _e( 'Welcome to the affiliate control panel.', 'wpam' );
