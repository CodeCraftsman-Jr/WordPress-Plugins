<?php
/**
 * Added to display affiliate creatives via the front page
 * @UNUSED
 */
// global (if needed)
?>

<div class="wrap">
	<div class="user-profile-links">
		<a href="?sub=reporting">Reporting</a> |
		<a href="?sub=creatives">Creatives</a>
	</div>

	<br />

	<?php

	// need to pull in data elements first

	// Pull in the page template
	require_once WPAM_BASE_DIRECTORY . "/html/admin/affiliate_cp_home.php";



	?>

</div>