<div class="wrap">
	<h2><?php _e( 'New Affiliate', 'wpam' ) ?></h2>
	<div id="message" class="updated"><p><?php _e( 'New Affiliate has been created', 'wpam' ) ?></p></div>
</div>