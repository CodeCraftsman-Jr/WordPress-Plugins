<div class="wrap">
<h2><?php _e( 'Affiliate Management Control Panel', 'wpam' ) ?></h2>
</div>