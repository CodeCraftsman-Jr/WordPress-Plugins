<div class="wrap">
	 <h2><?php _e( 'Confirmed', 'wpam' ) ?></h2>
	 <h3><?php _e( 'Your payment details have been submitted', 'wpam' ) ?></h3>
	<br />
<?php printf( __( 'Now would be a great time to go pick <a href="%s">some creative</a> and get started.', 'wpam' ), $this->viewData['creativesLink'] ) ?>

<br/>
</div>
