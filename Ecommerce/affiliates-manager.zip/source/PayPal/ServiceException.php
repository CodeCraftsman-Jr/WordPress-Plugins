<?php
/**
 * @author John Hargrove
 * 
 * Date: 1/3/11
 * Time: 9:28 PM
 */

class WPAM_PayPal_ServiceException extends Exception { }