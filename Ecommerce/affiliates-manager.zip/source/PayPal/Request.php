<?php
/**
 * @author John Hargrove
 * 
 * Date: 1/3/11
 * Time: 5:41 PM
 */

class WPAM_PayPal_Request {
}
