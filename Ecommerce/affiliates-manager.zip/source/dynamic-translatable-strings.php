<?php
/* These strings are generated dynamically. We have mentioned them here so the plugin can at least translate the strings. */
//affiliate_register_form.php
_e( 'Address Line 1', 'wpam' );
_e( 'Address Line 2', 'wpam' );
_e( 'Zip Code', 'wpam' );
_e( 'Company Name', 'wpam' );
_e( 'Website URL', 'wpam' );
