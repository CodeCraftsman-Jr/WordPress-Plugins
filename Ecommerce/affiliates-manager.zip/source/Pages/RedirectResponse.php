<?php
/**
 * @author John Hargrove
 * 
 * Date: May 30, 2010
 * Time: 5:53:33 PM
 */

class WPAM_Pages_RedirectResponse {
}
