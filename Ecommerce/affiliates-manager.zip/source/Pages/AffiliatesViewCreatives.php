<?php
/**
 * @author John Hargrove
 * 
 * Date: May 30, 2010
 * Time: 6:08:24 PM
 */

class WPAM_Pages_AffiliatesViewCreatives extends WPAM_Pages_PublicPage
{
	public function processRequest($request)
	{
		// TODO: Implement processRequest() method.
	}

	public  function isAvailable($wpUser) {
		// TODO: Implement isAvailable() method.
	}
}
