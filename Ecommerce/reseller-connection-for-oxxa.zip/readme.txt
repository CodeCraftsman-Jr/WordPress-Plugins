=== Plugin Name ===
Contributors: vlijmen
Tags: oxxa.com, domain reseller, widget, settings, dutch, english, dashboard, stats, status check, availability check
Requires at least: 3.5.0
Tested up to: 4.3
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Reseller Connection for OXXA.com let's your users manage their domainnames with their Wordpress website profile and login.

== Description ==

Reseller Connection for OXXA.com let's your users manage their domainnames with their Wordpress website profile and login. At this moment users can only check their registered domains. Updates coming soon!

I'm doing my best to make it safe, but using it is at your own risk ofcourse!

* Settings page
* Users field for OXXA.com connection
* English and Dutch
* Let users see their domainnames. [rcfo-nh-page-list]

Coming soon:

* Check availabilitie of domainnames
* Let users update their renewal settings

== Installation ==

1. Upload the files `oxxa-reseller-connection` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the settings page, fill in the details
5. Added [rcfo-nh-page-list] to the desired page where users can see their domainnames.

== Frequently Asked Questions ==

- Nothing yet, questions? Let me know!
Made a translation? Send it to me!

== Screenshots ==



== Changelog ==

= 0.0.1 =
* First version only connection and settings