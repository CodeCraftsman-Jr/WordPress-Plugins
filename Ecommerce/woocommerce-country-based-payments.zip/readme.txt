=== WooCommerce - Country Based Payments ===
Contributors: ivan_paulin
Donate link: http://ivanpaulin.com/
Tags: woocommerce, payment gateway, country, countries, payment gateways, country payment
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Choose which payment gateway will be available in country/countries.

== Description ==

This plugin gives you option to choose which payment gateway will be available in certain country, or countries.

If you need to have certain payment gateway to be available in all countries, don't set option for it.


== Installation ==

1. Upload `woocommerce-country-based-payment` folder to the `/wp-content/plugins/` directory
2. Activate the "WooCommerce - Country Based Payments" through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Initial release.

= 1.1 =
* Fix 'Invalid payment method' error

= 1.1.2 =
* Update readme.txt file