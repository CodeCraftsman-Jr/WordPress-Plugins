
-----------------------

# AWooCommerce - Country Based Payments

Choose which payment gateway will be available in country/countrie

-----------------------

### Description

This plugin gives you option to choose which payment gateway will be available in certain country, or countries.

If you need to have certain payment gateway to be available in all countries, don't set option for it.

### Compatibility

This WooCommerce addon is compatible with:
* WooCommerce 2.3.11

### Installation

1. Upload `woocommerce-country-based-payment` folder to the `/wp-content/plugins/` directory
2. Activate the "WooCommerce - Country Based Payments" through the 'Plugins' menu in WordPress

### Changelog
Please see `readme.txt` for changelog
