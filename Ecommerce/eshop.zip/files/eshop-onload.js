$eshopj=jQuery.noConflict();
$eshopj(document).ready(function () {
    $eshopj('#eshopgateway').submit();

});