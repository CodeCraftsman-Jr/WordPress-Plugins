<?php
//special settings - copy from paypal index if none.
$itemoption='on0_';
?>