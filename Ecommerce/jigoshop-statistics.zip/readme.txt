=== JigoShop Statistics ===
Contributors: jamesckemp
Tags: jigoshop, sales, statistics, bestsellers
Requires at least: 3.0
Tested up to: 3.3.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

JigoShop statistics gives you essential sales statistics for your JigoShop store.

== Description ==

Statistics are massively important, that's why I've created JigoShop Statistics. This plugin will allow you to see:

* Lifetime Sales
* Sales this month
* Average order value
* Total number of sales
* Bestsellers

Follow me on Twitter to keep up with the latest updates [@jamesckemp](https://twitter.com/#!/jamesckemp/)

== Installation ==

* Install and activate the plugin.
* Go to Jigoshop > Statistics.

== Changelog ==

= 1.0.1 =
* Fixed stats for 0 sales

= 1.0 =
* This is the first release of JigoShop Statistics.

== Upgrade Notice ==

= 1.0.1 =
* Fixed stats for 0 sales

= 1.0 =
* This is the first release of JigoShop Statistics.