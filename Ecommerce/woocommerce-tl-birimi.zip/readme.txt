=== WooCommerce TL Birimi ===

Contributors: gnckampus, woothemes

Donate link: http://www.gencmedya.com

Tags: woocommerce market, tl simge, Turkish lira, the new icon, new tl icon, woocommerce, woocommerce Turkish currency, yeni t&#252;rk liras&#305; simgesi, t&#252;rk&#231;e, woo, woothemes

Requires at least: 3, 4.1+ and WooCommerce 2.3+

Tested up to: 4.1.1

Stable tag: 2.2

License: GPLv3

License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Direkt olarak eklentiyi aktif ediyorsunuz sitenizde otomatik olarak TL simgesi gorunuyor.

Dileyen arkadaslarimiz tl simgesi yerine TL yazdirabilir, bunun icin yenitl.php dosyasi icinde 34. satir da bulunan,
`<span class="TL"></span>` kod yerine `TL` seklinde duzenleyerek dosyayi guncelleyebilirler.

Woocommerce panelden "Turk lirasi"ni secmelisiniz.

[Plugin yapimci: gencmedya.com](http://www.gencmedya.com)


= Feedback =

* Geri donusleriniz bizim icin onemli, daha fazla gelistirmek adina!

* Twitter uzerinden takip edebilirsiniz [@gencmedya](http://twitter.com/#!/gencmedya)

* Destek icin takip edebilirsiniz [Facebook sayfamiz](http://www.facebook.com/gencmedya)

  Demo icin tiklayin --> [dogadayiz.net](https://dogadayiz.net)
  
  tavsiye : woocommerce sanal pos --> [Woocommerce Sanal POS](http://eticaretmusterisi.com)
  
  Pluginimiz e-ticaret sisteminizde sorunsuz kullanabileceginiz woocommerce sanal pos desteklidir.

== Installation ==

1. Eklentiyi zipten cikartip wp-content dizinine yukleyiniz. `/wp-content/plugins/`.

2. Eklentilere gelip `Woocommerce TL birimi` yazan eklentiyi aktif ediniz.

3. Woocommerce genel ayarlar altindan Turk Lirasini seciniz.

4. Eklenti otomatik olarak aktif oluyor sizide zahmetten kurtariyor uzerinedir :).

**Please note:** You must run WordPress 3.0 or higher and WooCommerce 1.4 or higher in order tun this plugin. This is due to changes in WooCommerce v1.4+!

== Screenshots ==

1. Sepetten bir goruntu.
2. Admin panelden Turk Lirasini secmelisiniz.
3. Sepetten baska bir goruntu.
4. Admin panelden gorunumu.
5. Tek sayfa gorunumu.

== Changelog ==

= 2.2 =

* Readme.txt duzenlemesi

= 2.1 =

* Admin panel icin duzenlemeler.
* Responsive font boyutu, her stile ve temaya uygun font boyutu.
* Yeni daha profesyonel bir gelistirici eklendi.

= 1.1 =

* Font olarak eklenmistir. (i love wordpress).

= 1.0 =

* ilkler guzeldir.

== Upgrade Notice ==

= 2.1 =

* Admin panel icin guncelleme yapildi daha stabil calisiyor. 

= 1.1 =

* Yeni versiyonda eksiklikler giderildi. Sorunsuz Calisiyor. 