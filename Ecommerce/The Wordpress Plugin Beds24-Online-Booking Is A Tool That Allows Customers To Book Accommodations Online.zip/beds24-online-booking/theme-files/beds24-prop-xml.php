<!-- This file can be modified and placed in your theme directory, The plugin will search for a file with this name there first and use it if it exists -->
<div class="B24-Property">
    <h2 class="B24-H1Property">
    <?php echo $name; ?>
    </h2>
    <div class="B24-ProppriceButton">
            <div class="B24-Propprice">
            From: <?php echo $bestprice; ?>
            </div>  
        <div class="B24-Bookbutton">
        <a target="_blank" href="<?php echo $bookurl; ?>">Book Now</a>
        </div>
    </div>

</div>
