=== gpc-kits ===
Contributors: leticia_larr
Tags: kits
Tested up to: 2.8.6
Requires at least: 2.8.4
Stable tag: trunk

This plugin installs the kits for development with GPC plugins

== Description ==
Features:
* General class to access WordPress database (tables, rows)
* General class to retrieve WordPress users information
* General class to retrieve WordPress categories information
* General class to manage files
* General class to manage images
* General class to validate and parse I/O data
* Miscellaneous class with some others useful function as:
	- function to sort an array
* Multi language (PO edit) support

1. Plugins developers
* In the class folder are all the classes that this kits brings to plugins developers. Each function in classes
are well documented and are the best place to go for helps in order to use the functions.

== Installation ==
1. Upload the whole plugin folder to your /wp-content/plugins/ folder.
2. Go to the 'Plugins' page in the menu and activate the plugin.