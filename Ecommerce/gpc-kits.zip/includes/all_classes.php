<?php
$plugin_dir = GpcKits::$plugin_dir;

include($plugin_dir . '/classes/address.class.php');
include($plugin_dir . '/classes/categories.class.php');
include($plugin_dir . '/classes/cookies.class.php');
include($plugin_dir . '/classes/countries.class.php');
include($plugin_dir . '/classes/dbobject.class.php');
include($plugin_dir . '/classes/files.class.php');
include($plugin_dir . '/classes/images.class.php');
include($plugin_dir . '/classes/locale.class.php');
include($plugin_dir . '/classes/miscellaneous.class.php');
include($plugin_dir . '/classes/users.class.php');
include($plugin_dir . '/classes/validator.class.php');
include($plugin_dir . '/classes/wordpress_misc.class.php');
?>