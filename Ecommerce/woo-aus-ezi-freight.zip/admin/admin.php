<?php
require_once EFW_PLUGIN_DIR.'/admin/setting/class-efw-settings.php';

new EFW_settings();