<?php
/*
Plugin Name: jtFrame
Plugin URI: http://jumptag.co.za/projects/jtFrame
Description: A framework to simplify the development of wordpress frameworks
Version: 0.1
Author: Barry Roodt - Jumptag Web Development
Author URI: http://jumptag.co.za/
*/
	class hmdSqlUpdate {
		function hmdSqlUpdate() {
		}
	}
?>
