window.erated = {
  "config": {
    "align": "vertical",
    "color": "#334550",
    "key": "b1909932aac1c5510c044d",
    "waitForApiResponse": true,
    "locale": "en",
    "mode": "slider",
    "privacy": {
      "firstNameOnly": true
    },
    "reputationMode": "marketplaces",
    "renderOn404": false,
    "view": "buyer",
    "width": 330,
    "headless": false,
    "tutorMode": "start"
  },
  "userData": {
    "sha1Email": erated_params
  }
};