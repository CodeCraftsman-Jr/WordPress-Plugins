<?php
/*
 * Update procedures for version 1.2.3.4
 *
 *
 *
 */
	$GLOBALS['mdjm_debug']->log_it( 'No update procedures required for version ' . MDJM_VERSION_NUM );