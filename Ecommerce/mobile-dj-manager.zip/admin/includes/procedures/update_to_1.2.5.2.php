<?php
/*
 * Update procedures for version 1.2.5.2
 *
 *
 *
 */
	class MDJM_Upgrade_to_1_2_5_2	{
		function __construct()	{
			$GLOBALS['mdjm_debug']->log_it( 'No updates required for version 1.2.5.2' );
		}
	}
	
	new MDJM_Upgrade_to_1_2_5_2();