/*
 * mdjm-colour-picker.js
 * 04/03/2015
 * @since 1.1
 * Display a colour picker option for all fields with the div id "mdjm-colourpicker"
 */
	jQuery(document).ready(function($){
		$('.mdjm-colour-field').wpColorPicker();
	});