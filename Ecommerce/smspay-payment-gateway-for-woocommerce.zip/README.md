# SMSpay WooCommerce
Drop in SMSpay payment method for WooCommerce

## Todos
- Add test mode switch in GUI
