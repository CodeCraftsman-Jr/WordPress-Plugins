=== Discount for TheCartPress ===
Contributors: thecartpress
Donate link: http://thecartpress.com/collaborate-to-grow-and-support-thecartpress/
Tags: discount, dicounts, TheCartPress, ecommerce, e-commerce, store, shop, shopping, shopping cart, cart, custom post type, taxonomy, taxonomies, ecomerce, products, CartPress
License: GPLv2 or later
Requires at least: 3.1
Tested up to: 4.3
Stable Tag: 1.3.4

TheCartPress Discount is a plugin for TheCartPress. It allows to set discount ranges by total amount.

== Description ==

TheCartPress Discount is a plugin for TheCartPress. It allows to set discount ranges by total amount.

= TheCartPress Discount =

* Allows to edit the discounts ranges

= Unlimited features =

* TheCartPress-discount is compatible with TheCartPress and has been developed by TheCartPress Team.

= More info and Community =

* [TheCartPress Extend](http://extend.thecartpress.com): plugins, themes and custom development
* [TheCartPress Demo](http://demo.thecartpress.com)
* [TheCartPress Community/Support](http://community.thecartpress.com/activity/)
* [TheCartPress Site](http://thecartpress.com)

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload TheCartpress Discount to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click the new link 'discount' in the menu of TheCartPress

== Frequently Asked Questions ==

= Requirements =

Up to WodPress 3.1 and TheCartPress 1.1.5

= What is the plugin license? =

This plugin is released under a GPL license.

== Screenshots ==

1. Discounts admin page

== Upgrade Notice ==

== Changelog ==
= 1.3.4 =
* Discount by products: Search by SKU

= 1.3.3 =
* New functions for coupons

= 1.3.2 =
* Coupons by Product

= 1.3 =
* Coupon exists function

= 1.2 =
* Language support

= 1.1.2 =
* TheCatPress 1.2.6 compatible

= 1.1.1 =
* Discount metabox: 'Exclude the product from Discount by Order' bug

= 1.1.0 =
* Fix a bug when deactivate TheCartPress

= 1.0.9.1 =
* suport for TheCartPress 1.2.5

= 1.0.9 =
* Discount layout: Admin setting
* Discounts by Order: applied to each product
* Product admin panel: add discount by product and allows to exclude from Discount by Order (only if apply to each product)

= 1.0.8 =
* Compatible with TheCartPress 1.2
* Public API available

= 1.0.6 =
* minor bug fixes

= 1.0.5 =
* minor bug fixes

= 1.0.4 =
* Hides coupon textbox if no coupons activated
* Fix free shipping issue

= 1.0.3 =
* Coupons
* Discounts by options
* Html5 ready

= 1.0.2 =
* Fix some bugs

= 1.0.1 =
* Cart discounts
* Product discounts

= 1.0 =
* First public version.
