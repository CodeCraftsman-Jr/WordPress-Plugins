=== WooCommerce Pending Orders in AdminBar ===
Contributors: nipoto
Donate link: http://ideyeno.ir
Tags: stable, woocommerce, woocommerce adminbar, wordpress adminbar, orders notification, pending orders, orders count, wordpress, وردپرس, ووکامرس, سفارش
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.5
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show WooCommerce Pending Orders Count in WordPress AdminBar ...

== Description ==

Show WooCommerce Pending Orders Count in WordPress AdminBar

نمایش تعداد سفارشات در انتظار تحویل ووکامرس در منوی ادمین وردپرس

= Languages =
* فارسی (fa_IR)
* English (en_US)

= از ما حمایت کنید : =
[ * * * * * ](https://wordpress.org/support/view/plugin-reviews/woocommerce-count-orders-in-adminbar?rate=5#postform/)

= با ما در ارتباط باشید : =
* http://hamyarwp.com/wc-pending-orders-count-in-adminbar/
* info@ideyeno.ir 

== Installation ==

1. Visit 'Plugins > Add New'
2. Search for 'WC Pending Orders Count in AdminBar'
3. Activate WC Pending Orders Count in AdminBar from your Plugins page.

== Screenshots ==

1. Screenshot 1
2. Screenshot 2

== Changelog ==

= 1.5 =
* bugFix

= 1.4 =
* فراهم کردن امکان ترجمه به زبان های دیگر
* اضافه شدن زبان انگلیسی (en_US)

= 1.3 =
* updated

= 1.2 =
* bugfix

= 1.1.0 =
* Edit url

= 1.0.5 =
* ScreenShot :| 

= 1.0.4 =
* new Plugin Url 

= 1.0.3 =
* readme file edited ...

= 1.0.2 =
* screenshot :-"

= 1.0 =
* Initial commit.