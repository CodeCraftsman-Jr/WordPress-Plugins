<div class="wpsc-customer-account-settings">
	<?php wpsc_customer_account_tabs(); ?>
	<?php wpsc_user_messages(); ?>
	<div class="wpsc-customer-account-settings-form">
		<?php wpsc_customer_settings_form(); ?>
	</div>
</div>