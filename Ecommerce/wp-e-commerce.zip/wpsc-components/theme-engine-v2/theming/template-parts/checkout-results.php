<?php wpsc_user_messages(); ?>
<div class="wpsc-checkout wpsc-checkout-results">
	<?php wpsc_transaction_theme(); ?>
</div>