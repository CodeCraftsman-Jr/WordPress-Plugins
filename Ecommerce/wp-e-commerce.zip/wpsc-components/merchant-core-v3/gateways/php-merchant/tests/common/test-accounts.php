<?php
// @todo: Update to use canonical test accounts rather than those of individuals.
$test_accounts = array(
	'paypal-express-checkout' => array(
		'api_username'  => 'pro_1304085877_biz_api1.garyc40.com',
		'api_password'  => '1304085909',
		'api_signature' => 'AvoRfECzHW0KLVBSrJC70dNDVgEQA2j69L5ydKo3JhQBCJCNrZTj2zS8',
		'test'          => true,
	),
	'paypal-ec-oa' => array(
		'api_username'      => 'paypal-facilitator_api1.omarabid.com',
		'api_password'      => '1404523024',
		'api_signature'     => 'An5ns1Kso7MWUdW4ErQKJJJ4qi4-AnIgHxdxM4-jkGKkkOhcO0fD-Av5',
		'test' => true,
	),
	'paypal-pro-oa' => array(
		'api_username'      => 'wpp_api1.omarabid.com',
		'api_password'      => '4WQY6WGGAGS4JPEA',
		'api_signature'     => 'AFcWxV21C7fd0v3bYYYRCpSSRl31AboWy-uBCAMW9aDx8JwAq7ryYemY',
		'test' => true,
	),
);
