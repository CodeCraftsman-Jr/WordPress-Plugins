=== DudaPro for WordPress ===

Tags: dudapro, duda, api, mobile, multi-screen

Requires at least: 3.8

Tested up to: 4.1.1

Stable tag: 2.6.12



This plugin extends functionality so you can include duda multi-screen and mobile preview in your own site. Upgrade to the premium version to cpature leads, accept payments, delete accounts, receive support @ more!



== Description ==


This pluign is the "missing duda wordpress plugin" that duda never released.  Currently it allow you to embed the mobile

and multi-screen funtionality on your site so clients can create sites within your own branded website. It also creates WordPress users

so they can login from your website and edit their website.  




Features:



* Show & Create Multi-Screen sites

* Show & Create Mobile Sites

* Show Mobile Preview or Mobile Comparison

* Cretes WordPress accounts 

* Creates a login page so they can login and then edit their mobile or D1 site

* more features in the premium version!







== Installation ==



1. Click install or upload `duda-pro.zip` to the `/wp-content/plugins/` directory



2. Activate the plugin through the 'Plugins' menu in WordPress



3. Go to the admin and then choose 'DudaPro'. Enter your  License Key and API credentials



4. Place the shortcode [dudapro_mobile] or [dudapro_multiscreen] on any page you would like to show the previews.





= Uploading in WordPress Dashboard =



1. Navigate to the 'Add New' in the plugins dashboard

2. Navigate to the 'Upload' area

3. Select `duda-pro.zip` from your computer

4. Click 'Install Now'

5. Activate the plugin in the Plugin dashboard



= Using FTP =



1. Download the plugin

2. Extract the plugin directory to your computer

3. Upload the plugine directory to the `/wp-content/plugins/` directory

4. Activate the plugin in the Plugin dashboard





== Frequently Asked Questions ==



= It's not working? =

Make sure the shortcodes are correct and you have entered your API information correctly.


= Does this work with any Dudamobile plan =

Yes! Now that all resellers are DudaPro we can all take advantage of this!



= It won't work, what could be wrong? =

Make sure you enter all the  Duda API settings.  



= Do I have to edit code to make this work? =

Absolutely not! Just install the plugin, add your api settings in the settings tab and then use the shortcodes [dudapro_mobile]  [dudapro_multiscreen]  [dudapro_client_login] Simple!





= Does this use all the API functions =

No but the premium version uses most of them! Check it out at 







== Changelog ==


= 2.6.11 =

* Send clients custom emails

* Added a login shortcode for clients to login

* WP users are created for each user that creates a site preview





= 2.1.0 =

* Added Stripe for payment processing

* Added a call to action custom text field









= 2.0.2 =

* Complete code rewrite to allow us to easily extend features

* You will need to add your license & settings if you had a previos version, sorry. This is a one time deal.







= 1.0 =

* A change since the previous version.

* Another change.



= 0.5 =

* List versions from most recent at top to oldest at bottom.



== Upgrade Notice ==



= 1.0 =

Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.



= 0.5 =

This version fixes a security related bug.  Upgrade immediately.



== Arbitrary section ==



This plugin will have frequent updates.  By default WordPress only checks for updates every 12 hours.

