=== Hello Rumi ===
Contributors: aqibgatoo
Requires at least: 3.0
Stable tag: 1.0
Tested up to: 4.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin shows you a random quote written by the greatest mystic sufi poet of all time Rumi.
== Description ==

This plugin shows you a random quote written by the greatest mystic sufi poet of all time Rumi.This is a plugin based on Matt Mullenweg's Hello dolly plugin. When activated you will randomly see a quote in the upper right of your admin screen on every page.