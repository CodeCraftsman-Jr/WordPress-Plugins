=== Easy Digital Downloads - Digital Badge ===
Contributors: cklosows,mordauk
Tags: Easy Digital Downloads, badges, downloads, digital products
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later

Allow a product to be marked as Digital and have a badge after its title to indicate as such.

== Description ==

Make it clear that your products are digital and will be downloaded, not physically delivered with a simple, customizable badge. This plugin will extend the title of your downloads with the string of your choice, like [digital] or [download]. Individually actiavte for each product in your catalog.

Also supports the Recurring Payments extension for Easy Digital Downloads. When enabled, you can also mark items as [subscription] or any other term to signify this is a recurring payment.

== Screenshots ==
1. Adds a badge to the title when flagged as 'Digital'
2. The Settings Screen, show integration with the Recurring Payments Extension enabled
3. Cart View

== Changelog ==
= 1.0 =
* NEW: Initial Release
