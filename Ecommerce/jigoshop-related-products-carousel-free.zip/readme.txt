=== Plugin Name ===
Contributors: relatedcontentwp
Donate link: http://relatedcontentwp.com/donate
Tags: JigoShop Related Products, Related Products carousel, Products carousel, JigoShop Addon, JigoShop
Requires at least: 3.5
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Jigoshop Related Products Carousel Free is a plugin what enable an awesome related Products careousel under every single products.


== Description ==


This plugin is only for WordPress most popular shop plugin Jigoshop. It will add a related product after single product with a carousel style. After installing this plugin, the plugin will start work itself. You don't have to configure anything. Easy Enough! 

<h2>Free version features</h2>
<ul>
	<li>Easy install process</li>
	<li>Responsive touch enabled carousel</li>
	<li>All Major Browser Supported</li>
	<li>Very minimalist & lightweight</li>
	<li>Works in any wordpress theme</li>
</ul>


<p>We also offer premium version of this plugin. We added many of extra features in premium version of this plugin. Checkout those features</p>

<h4>Detailed documentation</h4>
<p>In permium version of this plugin, we provide hand picked detailed documentation for help. The documentation helps you using this plugin effectly, learn how manage carousel, carousel mobile settings, color setting etc.</p>

<a target="_blank" href="http://docs.relatedcontentwp.com/jigo-related-downloads-carousel/" class="button button-primary">See online documentation</a>

<h4>Change every settings</h4>
<p>We've added an awesome, easy & effective option panel in permium version of this plugin. You can change each &amp; every settings of this plugin. You can change colors, you can change styles etc directly form option panel.</p>
<a target="_blank" href="http://relatedcontentwp.com/jigo-related-downloads-carousel/" class="button button-primary">See Screenshots</a>

<h4>5 Preloaded styles</h4>
<p>There is 5 preloaded modern carousel style added in premium version. You can choose that styles form its options panel. We are adding styles day by day. We offer free update in premium version. Check styles screenshots form here.</p>
<a target="_blank" href="http://relatedcontentwp.com/jigo-related-downloads-carousel/" class="button button-primary">See Styles Preview</a>

<h4>Awesome support team</h4>
<p>Our all premium plugin includes dedicated support. You just have to inform us how we can help you. Our support team is always ready to assist you if you face any problem like installation, confugring or others. </p>

<h4>Free updates</h4>
<p>All of our plugin is updating continueasly. We are adding more freatures day by day. We are adding new styles & other features too. You will get those updates by free! We will inform you after each updates with updating instructions.</p>

<h4>Cheapper than other premium plugin</h4>
<p>Our premium plugin is cheaper than other premium plugin, no monthly or yearly subscription, no other condtion. You need purchase one time &amp; you will get all features, updates life time. Really!</p>

<h4><a target="_blank" href="http://codecanyon.net/item/jigo-related-downloads-carousel/10400059?ref=relatedcontentwp">Purchase premium version now! Only $16</a></h4>
			


== Installation ==

Installing this plugin as regular wordpress plugin. After installing this plugin, the plugin will start work itself. You don't have to configure anything. Easy Enough! 


== Screenshots ==

1. Demo

== Changelog ==

= 1.0 =
* First Release