<?php
define( 'SUPERFERO_API', 'http://www.superfero.com/' );
define( 'SUPERFERO_TOKEN', 'sf' );
define( 'SUPERFERO_OPTION', 'sf_' );
define( 'SUPERFERO_VERSION', '1.2.0' );
define( 'SUPERFERO_PAGE_TITLE', 'Superfero Courses' );
define( 'SUPERFERO_PAGE_CONTENT', '<div id="superfero-groups"></div>' );
define( 'SUPERFERO_PAGE_STATUS', 'publish' );
define( 'SUPERFERO_PAGE_TYPE', 'page' );
define( 'SUPERFERO_COMMENT_STATUS', 'closed' );
define( 'SUPERFERO_PING_STATUS', 'closed' );
?>