=== PRyC WooCommerce: Edit all orders ===
Contributors: PRyCpl
Tags: WordPress, WooCommerce, Order, Orders, Edit
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin add filter to enable edit options to all orders (all statuses)

== Description ==
Plugin add filter to enable edit options to all orders (all statuses)

== Installation ==
1. Upload `pryc-woocommerce-edit-all-orders` dir to the `/wp-content/plugins/` directory
2. Activate the plugin through the \'Plugins\' menu in WordPress

== Screenshots ==

== Changelog ==
1.0.1: First public ver.