=== Shop On Page: Easy, simple affiliate ads for your website ===
Contributors: abagher
Donate link: https://www.wepay.com/donations/441995958
Tags: affiliate ads, shopping, money, advertising, revenue, adsense, adwords, marketing
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Make money on your website. Adds a "Shop" button to your page. Make money on purchases. 

== Description ==

Make money on your website. Adds a "Shop" button to your page. Make money on purchases. Free to sign up, easy to use.

We select only top-quality products from the largest e-commerce companies across the world.
We support Amazon, Flipkart, and Belliscity today. More will be added soon. 

Join TrulyShare Shop On Page, [Sign up for free](http://www.trulyshare.com/publishers/new), and get started immediately.

If you have a question, please consult our [User Forum](http://trulyshare.freeforums.org).

If you would rather not use our plugin, you can sign up directly by starting [here](http://www.shoponpage.com).


== Installation ==

1. Upload `shoponpage.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Enter your publisher ID. If you do not have a publisher ID, [Sign up for free](http://www.trulyshare.com/publishers/new).

== Frequently asked questions ==

= Is it free to use? =
Yes.

= When do I get paid? =
You earn money when your users BUY products from your page in our widget. You will be contacted by our accounting team when you earn more than $20 USD.

= Does it conflict with AdSense? or others? =
No, our button appears on the left side of the screen and only shows ads when users click on it. 

== Screenshots ==

1. http://www.shoponpage.com/images/step_1.png

== Changelog ==
Changed the link on the readme file to point to the right place.


== Upgrade notice ==
Corrects some issues referencing the right plugin.


== Arbitrary section 1 ==

