<?php

define('DC_EDD_DISCOUNTS_BY_TIME_PLUGIN_TOKEN', 'dc-edd-discounts-by-time');

define('DC_EDD_DISCOUNTS_BY_TIME_TEXT_DOMAIN', 'edd_discounts_by_time');

define('DC_EDD_DISCOUNTS_BY_TIME_PLUGIN_VERSION', '1.0.0');
?>