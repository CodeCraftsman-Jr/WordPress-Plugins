=== RybonsCoupon ===
Contributors: Panthelope Technologies
Donate link:
Tags: Coupon, Discount, Sale
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1

Offer your shoppers discount coupons from Rybons.com.ng. Visit rybons.com.ng to register your store.

== Description ==

Rybons Coupon allows you offer coupon discounts on store. With this extension, shoppers can apply coupons gotten from the rybons platform. To get started, visit rybons.com.ng, and register your store. Once store has been verified, you will receive and email containing your merchant key.

== Installation ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision
