<?php
/****************************************************************************
 ** file: templates/navbar.php
 **
 ** The top navigation bar.
 ***************************************************************************/
 
 global $MP_buyat_plugin;
?>

<ul>
    <li class='like-a-button'><a href="/wp-admin/options-general.php?page=csl-mp-buyat-options">Settings: General</a></li>       
</ul>
