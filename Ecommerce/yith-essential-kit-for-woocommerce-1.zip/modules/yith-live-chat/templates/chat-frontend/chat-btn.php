<div id="YLC_chat_btn" class="chat-chat-btn" style="ylc.styles">
    <div class="chat-ico chat fa fa-comments"></div>
    <div class="chat-ico ylc-toggle fa fa-angle-ylc.arrow"></div>
    <div class="chat-title">
        ylc.title
    </div>
</div>