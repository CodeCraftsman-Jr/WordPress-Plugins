<div id="YLC_cnv" class="chat-wrapper">
    <div id="YLC_load_msg" class="chat-load-msg">
        ylc.load_msg
    </div>
</div>
<div id="YLC_cnv_bottom" class="chat-bottom">
    <div class="chat-notify">
        <div id="YLC_popup_ntf"></div>
    </div>
    <div class="chat-cnv-reply">
        <div class="user-avatar">
            <img src="ylc.avatar" />
        </div>
        <div class="chat-cnv-input">
            <textarea name="msg" class="chat-reply-input" id="YLC_cnv_reply" placeholder="ylc.reply_ph"></textarea>
        </div>
    </div>
</div>