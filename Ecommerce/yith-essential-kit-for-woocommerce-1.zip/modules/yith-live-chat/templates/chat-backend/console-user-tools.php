<div class="sidebar-header">
    ylc.save_chat_btn
    <button id="YLC_end_chat" data-cnv-id="ylc.obj_user_data" class="button">
        <i class="fa fa-times"></i>
        ylc.button_text
    </button>
    <br />
    <span id="YLC_save_ntf"></span>
</div>

