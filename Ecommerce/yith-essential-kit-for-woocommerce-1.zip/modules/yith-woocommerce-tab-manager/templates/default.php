<?php
/**
 * Created by PhpStorm.
 * User: Your Inspiration
 * Date: 16/03/2015
 * Time: 11:40
 */
?>

<p> <?php echo $content ?></p>