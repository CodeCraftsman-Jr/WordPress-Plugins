<?php

global $states;

$states['CA'] = array(
	'AB' => __( 'Alberta', 'ignitewoo_events' ),
	'BC' => __( 'British Columbia', 'ignitewoo_events' ),
	'MB' => __( 'Manitoba', 'ignitewoo_events' ),
	'NB' => __( 'New Brunswick', 'ignitewoo_events' ),
	'NF' => __( 'Newfoundland', 'ignitewoo_events' ),
	'NT' => __( 'Northwest Territories', 'ignitewoo_events' ),
	'NS' => __( 'Nova Scotia', 'ignitewoo_events' ),
	'NU' => __( 'Nunavut', 'ignitewoo_events' ),
	'ON' => __( 'Ontario', 'ignitewoo_events' ),
	'PE' => __( 'Prince Edward Island', 'ignitewoo_events' ),
	'QC' => __( 'Quebec', 'ignitewoo_events' ),
	'SK' => __( 'Saskatchewan', 'ignitewoo_events' ),
	'YT' => __( 'Yukon Territory', 'ignitewoo_events' )
);
