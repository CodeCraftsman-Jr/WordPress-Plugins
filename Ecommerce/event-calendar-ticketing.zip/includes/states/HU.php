<?php

global $states;

$states['HU'] = array(
	'BK' => __( 'Bács-Kiskun', 'ignitewoo_events' ),
	'BE' => __( 'Békés', 'ignitewoo_events' ),
	'BA' => __( 'Baranya', 'ignitewoo_events' ),
	'BZ' => __( 'Borsod-Abaúj-Zemplén', 'ignitewoo_events' ),
	'BU' => __( 'Budapest', 'ignitewoo_events' ),
	'CS' => __( 'Csongrád', 'ignitewoo_events' ),
	'FE' => __( 'Fejér', 'ignitewoo_events' ),
	'GS' => __( 'Győr-Moson-Sopron', 'ignitewoo_events' ),
	'HB' => __( 'Hajdú-Bihar', 'ignitewoo_events' ),
	'HE' => __( 'Heves', 'ignitewoo_events' ),
	'JN' => __( 'Jász-Nagykun-Szolnok', 'ignitewoo_events' ),
	'KE' => __( 'Komárom-Esztergom', 'ignitewoo_events' ),
	'NO' => __( 'Nógrád', 'ignitewoo_events' ),
	'PE' => __( 'Pest', 'ignitewoo_events' ),
	'SO' => __( 'Somogy', 'ignitewoo_events' ),
	'SZ' => __( 'Szabolcs-Szatmár-Bereg', 'ignitewoo_events' ),
	'TO' => __( 'Tolna', 'ignitewoo_events' ),
	'VA' => __( 'Vas', 'ignitewoo_events' ),
	'VE' => __( 'Veszprém', 'ignitewoo_events' ),
	'ZA' => __( 'Zala', 'ignitewoo_events' )
);
