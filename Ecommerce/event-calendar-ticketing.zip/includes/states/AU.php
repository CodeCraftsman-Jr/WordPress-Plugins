<?php

global $states;

$states['AU'] = array(
	'ACT' => __( 'Australian Capital Territory', 'ignitewoo_events' ),
	'NSW' => __( 'New South Wales', 'ignitewoo_events' ),
	'NT'  => __( 'Northern Territory', 'ignitewoo_events' ),
	'QLD' => __( 'Queensland', 'ignitewoo_events' ),
	'SA'  => __( 'South Australia', 'ignitewoo_events' ),
	'TAS' => __( 'Tasmania', 'ignitewoo_events' ),
	'VIC' => __( 'Victoria', 'ignitewoo_events' ),
	'WA'  => __( 'Western Australia', 'ignitewoo_events' )
);
