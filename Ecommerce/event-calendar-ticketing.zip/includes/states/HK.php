<?php

global $states;

$states['HK'] = array(
	'HONG KONG'       => __( 'Hong Kong Island', 'ignitewoo_events' ),
	'KOWLOON'         => __( 'Kowloon', 'ignitewoo_events' ),
	'NEW TERRITORIES' => __( 'New Territories', 'ignitewoo_events' )
);
