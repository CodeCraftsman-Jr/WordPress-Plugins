<?php

global $states;

$states['ZA'] = array(
	'EC'  => __( 'Eastern Cape', 'ignitewoo_events' ) ,
	'FS'  => __( 'Free State', 'ignitewoo_events' ) ,
	'GP'  => __( 'Gauteng', 'ignitewoo_events' ) ,
	'KZN' => __( 'KwaZulu-Natal', 'ignitewoo_events' ) ,
	'LP'  => __( 'Limpopo', 'ignitewoo_events' ) ,
	'MP'  => __( 'Mpumalanga', 'ignitewoo_events' ) ,
	'NC'  => __( 'Northern Cape', 'ignitewoo_events' ) ,
	'NW'  => __( 'North West', 'ignitewoo_events' ) ,
	'WC'  => __( 'Western Cape', 'ignitewoo_events' )
);