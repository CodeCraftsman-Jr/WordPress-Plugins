<p>
  <?php _e('Sorry, it seems your browser is not supported by WooCommerce POS. '); ?>
  <?php _e('If possible, please <a href="http://browsehappy.com/">update your browser</a>, we recommend either Chrome or Firefox.'); ?>
</p>
<div class="responsive"><img src="http://woopos.com.au/wp-content/uploads/2015/05/compatibility-chart.jpg" alt="Browser Compatibility Chart" /></div>
<p>
  <?php _e('If you believe you have received this message in error please contact support via <a href="mailto:support@woopos.com.au">support@woopos.com.au</a>'); ?>
</p>