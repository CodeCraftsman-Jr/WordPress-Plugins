<ul class="hotkeys">
  {{#each []}}
  <li>
    <input type="text" value="{{key}}" disabled>
    {{label}}
  </li>
  {{/each}}
</ul>