# Do not place language files here. 

Wordpress will automatically download the appropriate language pack for your locale.