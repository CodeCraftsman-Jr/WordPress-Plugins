<?php
/*
Plugin Name: Ni Woocommerce Sales Report
Description: Ni Woocommerce Sales Report  help top keep the track of daily, weekly, monthly and yearly sales report. It provides the list of order details.
Author: Anzar Ahmed
Version: 1.5
Author URI: http://mywebdesire.com/
License: GPLv2
*/
include_once('include/base-sales-report.php'); 
$GLOBALS['BaseSalesReport'] = new BaseSalesReport();
?>
