=== Ni Woocommerce Sales Report ===
Contributors: Anzar Ahmed
Tags: woocommerce, wordpress woocommerce,print sales report, woocommerce report, sale report,product report, item report, woocommerce sales, today sales, Customer sales, country sales, item sales, sales report plugin, sales report cart, daily sales, weekly sales, monthly sales, yearly sales,print sales product, print sales order 
Requires at least: 4.1.1
Tested up to: 4.3.1
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ni Woocommerce Sales Report  help top keep the track of daily, weekly, monthly and yearly sales report. It provides the list of order details.

== Description ==

Ni Woocommerce Sales Report help top keep the track of daily, weekly, monthly and yearly sales report. It provides the list of order details. It provide the total sales, total customer, daily sales and daily customer.

Some Features.

* Fast And Easy Install
* Total Sales
* Total Order
* Today Sales
* Today Total 
* Today Customer
* Sales order list
* Filter by date, Today Date, Yesterday Date,  Last 7 days, Last 30 days, This year
* Print sales order report



== Installation ==

1. Use the WordPress plugin installer or upload files to WordPress plugin directory.
1. Activate plugin from admin panel.
1. sales report. 

== Frequently Asked Questions ==

= Where i can get help? =

Click on support tab or email : i.anzar14@gmail.com

= Do you customize this plugin? =

Yes, as per requirement we can customize this plugin.

== Screenshots ==

1. Summary Report.
2. Sales Order List.
3. Print option page.

== Changelog ==

= version 1.5 - 20-October-2015 =
BugFix: Internal bugFix

= version 1.4 - 18-October-2015 =

* Added:  Print sales order product
* Added:  Sales summary (Qty, Tax and Product Total) at the bottom of the sales list
* Change: Plugin menu icon 
* Tested: Compatible With WordPress 4.3.1
* Tested: Compatible With Woocommerce 2.4.7

= version 1.3 - 22-Aug-2015 =

* Added: Last 10 days order filter  
* Tested: Compatible With WordPress 4.3
* Tested: Compatible With Woocommerce 2.4.5

= version 1.2 =
* Added: Order Status

= version 1.1 =
* Fixed: Woocommerce Price Format
* Added: Total Quantity
* Added: Total Tax 
* Added: Total Product 
* Tested: Compatible With WordPress 4.2.2

= version 1.0 =
* Initial relese

== Upgrade Notice ==

New Features add upgrade please.

== Disclaimer ==

It is not responsible for any harm or wrong doing this Plugin may cause. Users are fully responsible for their own use. This Plugin is to be used WITHOUT warranty.