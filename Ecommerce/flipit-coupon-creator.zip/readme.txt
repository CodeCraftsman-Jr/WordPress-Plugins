=== Plugin Name ===
Contributors: Flipit Coupon Plugin
Donate link: http://www.flipit.com
Tags:  Coupon reader, Flipit, kortingscode, coupons
Requires at least: 3.2.1
Tested up to: 3.2.1
Stable tag: 4.3



== Description ==

With this plugin you can rapidly display coupons from  Flipit.com on your Wordpress Website. Just attach the widget to your sidebar, and the coupons will be shown on your website.


== Installation ==

This section describes how to install the plugin and get it working.
1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

**PLEASE NOTE**

== Changelog ==

= 1.0 =
* Version 1

== Upgrade Notice ==
= 1.1.2 =
The plugin will be updated frequently so please always use the latest version
