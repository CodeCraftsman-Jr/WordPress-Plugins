=== EAN product database search ===
Contributors: pleep.net
Tags: pleep.net, EAN database, EAN search, product search, reviews, product reviews
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.saleshare.de/

Das Plugin ermöglicht das Einbinden von Produktdaten und Verkäuferinformationen über einen Shortcode, der den EAN-Code des Produkts enthält.

== Description ==

Das Plugin ermöglicht das Einbinden von Produktdaten und Verkäuferinformationen über einen Shortcode, der den EAN-Code des Produkts enthält.

Bitte benachrichtige uns über Fehler, damit wir diese so bald wie möglich beheben können: kontakt[at]webworks-nuernberg.de

Weitere Informationen unter http://www.saleshare.de/

== Installation ==

1. Das Plugin lässt sich über das Wordpress Plugin Verzeichnis installieren. Alternativ kann das entpackte Zip-File auch via FTP hochgeladen werden.
2. Aktiviere das Plugin nach dem Upload/der Installation
3. Erstelle einen Beitrag oder Artikel und füge den Shortcode ein: Zum Beispiel [pleep ean="00885909943074"]

== License ==

The plugin is free for everyone. The license is the GPLv2 (<a href="http://www.gnu.org/licenses/gpl-2.0.html">http://www.gnu.org/licenses/gpl-2.0.html</a>)
