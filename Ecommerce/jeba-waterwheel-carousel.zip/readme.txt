=== Jeba Waterwheel Carousel ===
Tags: carousel, tiny carousel, awesome carousel, jeba carousel, post carousel, Waterwheel Carousel
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Jeba Waterwheel Carousel is an awesome carousel, super lightweight plugin for your wordpress website post carousel. 

== Description ==

This plugin will enable awesome carousel in your wordpress theme. You can use the jeba tiny carousel via shortcode in everywhere you want, even in theme files. 

Our all plugin: http://prowpexpert.com/jeba


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use shortcode in page, post or in widgets.
4. If you want use the Jeba Waterwheel Carousel in your theme php, Place `<?php echo do_shortcode('[carousel]'); ?>` in your templates.
5. In the [carousel] shortcode you can change post_type="", title="", count="" . Here count is total post. 
Shortcodes

<strong>Use Jeba Waterwheel Carousel shortcode</strong>
<pre>[carousel]</pre>

<strong>Here can change</strong>
<pre>[carousel post_type="" title="" count=""]</pre>

== Frequently Asked Questions ==



== Screenshots ==

1. Installed in demo server.
2. Another demo.



== Changelog ==

= 1.0 =
* Initial Release