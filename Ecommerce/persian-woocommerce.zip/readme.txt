﻿=== Persian Woocommerce ===
author: Persian Woocommerce
Contributors: Persianscript, hannanstd
author URI: http://www.woocommerce.ir/
Donate link: http://woocommerce.ir/donate.html
plugin URI: http://www.woocommerce.ir/download.html
Tags: woocommerce, persian woocommerce, woocommerce farsi, iran, iranian, rtl, fa_IR,states,iranian rials,iranian tomans, woocommerce.ir,affiliate, cart, checkout, commerce, configurable, digital, download, downloadable, e-commerce, ecommerce, inventory, reports, sales, sell, shipping, shop, shopping, stock, store, tax, variable, widgets, woothemes, wordpress ecommerce
Requires at least: 3.0
Tested up to: 4.2

This plugin extends the WooCommerce shop plugin with complete Persian(Farsi) language packs

== Description ==
**Persian Woocommerce**
This plugin extends the WooCommerce shop plugin with complete Persian(Farsi) language packs

= Features =
* Translate All part of woocommerce to Persian (farsi)
* Enables Iran States in Woocommerce Settings and customers Orders!
* Enables iranian Rials and Tomans Currency 
* Enables Replace the words
* and...

= Compatibility =
* Woocommece 2.3.x
* Wordpress 4.x

= Support =
*  [Persian Support in woocommerce.ir](http://woocommerce.ir/)

= Fa =
* بسته فارسی ساز ووکامرس شما را قادر می سازد تا فروشگاه ساز ووکامرس را به فارسی تبدیل کنید.
* با نصب این بسته می توانید:

* واحد پولی ریال و تومان را به واحد های پولی اضافه کنید
* لیست استان های ایران را اضافه کنید
* ووکامرس را به صورت کامل فارسی کنید
* افزوده شدن لیست شهر های ایران
* راست چین سازی بخش مدیریت فروشگاه
* و...

== Installation ==
1. Upload `persian-woocommerce` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= Where can I find more information and documentation about the plug-in? =

You can read complete documentations on the [woocommerce.ir](http://www.woocommerce.ir)


== Screenshots ==


== Changelog ==
= 2.3.9.2 =
* رفع باگ
= 2.3.9.1 =
* افزوده شدن امکان انتخاب شهر توسط کاربر
= 2.3.9 =
* افزوده شدن امکان انتخاب شهر توسط کاربر
= 2.3.8 =
* فارسی سازی عبارات جدید برای ووکامرس 2.3.8
= 2.3.7 =
* فارسی سازی عبارات جدید برای ووکامرس 2.3.7
= 2.2.10 =
* بروزرسانی تازه برای نسخه 2.2.10
= 1.4 =
* سازگاری با ووکامرس 2.2
= 1.3 =
* سازگاری با ووکامرس 2.1.2
= 1.2 =
* Compatibility with woocommerce 2.1.x
= 1.1 =
* bug fixed
= 1.0 =
* First version

== Upgrade Notice ==
= 2.3.9.2 =
* رفع باگ
= 2.3.9.1 =
* پس از بروزرسانی لطفا آموزش را مطالعه کنید
= 2.3.9 =
* پس از بروزرسانی لطفا آموزش را مطالعه کنید
= 2.3.8 =
* افزوده شدن واحد پولی هزار تومان و ترجمه عبارات تازه
= 2.3.7 =
* فارسی سازی عبارات جدید برای ووکامرس 2.3.7
= 2.2.10 =
* بروزرسانی تازه برای نسخه 2.2.10
= 1.4 =
* سازگاری با ووکامرس 2.2
= 1.3 =
* سازگاری با ووکامرس 2.1.2
= 1.2 =
* Compatibility with woocommerce 2.1.x
= 1.1 =
* bug fixed
= 1.0 =
* First version

==Traducciones ==
You can read complete documentations on the [woocommerce.ir](http://www.woocommerce.ir)
