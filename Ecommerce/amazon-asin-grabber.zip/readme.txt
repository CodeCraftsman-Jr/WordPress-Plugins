=== Amazon ASIN Grabber ===
Contributors: Sigit prasetya nugroho
Tags: asin,asin generator,amazon asin grabber,asin grabber, asin grab,grab asin code,amazon asin code
Requires at least: 3.0
Tested up to: 3.9.1
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

With Amazon Asin Grabber plugin, you can grab unlimited Amazon Asin Code. Make sure your hosting powerful, before you grab thousands of ASIN :) 

== Description ==
With Amazon Asin Grabber plugin, you can grab unlimited Amazon Asin Code from amazon site (.com/.de/.at .. etc ). Make sure your hosting is more powerful, before you grab thousands of ASIN :).
Thank you for using my plugin. for more info visit me on http://seegatesite.com

== Installation ==

Upload the Amazon Asin Grabber plugin to your blog, Activate it,this plugin will be replace at settings->amazon asin grabber .You're done!

== Changelog ==
= 1.0 =
* Initial release