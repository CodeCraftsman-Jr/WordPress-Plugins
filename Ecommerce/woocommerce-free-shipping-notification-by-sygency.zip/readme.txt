=== WooCommerce free shipping notification by Sygency ===
Contributors: aivaraszelba, sygency
Tags: woocommerce, amount, cart, checkout, ecommerce, free shipping, free shipping notification, left, native, notification, remaining, shipping, widget
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=hello%40sygency%2ecom&lc=US&item_name=Few%20drinks%20for%20sygency%2ecom%20team&no_note=0¤cy_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Requires at least: 3.7
Tested up to: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin shows how much money user should spend in order to get free shipping if available.

== Description ==
Every customer loves free stuff and your customers will be happy to buy a little bit more products from your website, if they know that the shipping will be free.

This plugin adds a native WooCommerce notification to your shop cart and mini cart in widget, that notifies the customers of the amount left to qualify for Free Shipping.

== Installation ==
1. Upload WooCommerce free shipping notification by Sygency plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the \'Plugins\' menu in WordPress
3. Go to WooCommerce > Settings > Shipping > Free Shipping and write sum of money into Minimum Order Amount field.

== Frequently Asked Questions ==
Can I translate your plugin?
Yes, plugin is ready for translation.

Can I use this in mini Cart Widget?
Yes, plugin already do this.

== Screenshots ==
1. Notifications example in cart.

== Changelog ==
= 1.1 =

Initial Release

== Upgrade Notice ==
Notification in Cart and Mini Cart in Widget Area.