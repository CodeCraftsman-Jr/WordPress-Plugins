<!-- HealCode MINDBODY Widget Plugin for WordPress -->
<!-- Footer for pages -->

<div style="clear: both;"></div>
  
<p></p>

<div style="width: 100%">
    <div class="hc_feedback">
        
        <!-- Footer Links, including tech support and social media -->
        <a target="_blank" href="https://healcode.zendesk.com/hc/en-us/articles/203647654-Putting-widgets-on-WordPress-ORG-using-shortcodes-generated-by-a-plugin-Advanced-" class="instruct">Instructions</a>
        <a target="_blank" href="http://www.healcode.com/tech_support" class="">Tech Support</a>
         <a target="_blank" href="https://manager.healcode.com/users/sign_in" class="">Login to HealCode</a>
        <a target="_blank" href="https://www.facebook.com/HealCode" class="">Like us on Facebook</a> 
        <a target="_blank" href="https://twitter.com/healcode" class="">Follow us on Twitter</a>
        
    </div>
    <p></p>
</div>

<p style="clear: both;"></p>


    
