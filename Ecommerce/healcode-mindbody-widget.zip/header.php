<!-- HealCode MINDBODY Widget Plugin for WordPress -->
<!-- Header for pages -->

<!-- Style Section - Remove in the future as is not necessary 
<style>
#text {margin:50px auto; width:500px}
.hotspot {color:#900; padding-bottom:1px; border-bottom:1px dotted #900; cursor:pointer}
#tt {position:absolute; display:block; }
#tttop {display:block; height:5px; margin-left:5px;}
#ttcont {display:block; padding:2px 10px 3px 7px;  margin-left:-400px; background:#666; color:#FFF}
#ttbot {display:block; height:5px; margin-left:5px; }
</style>
-->


<!-- Header Links to our About page in WordPress and HealCode -->

<div style="margin-top: 10px">
<table style="float:right; ">
    <tr>
        
        <td style="float:right;">
            <a class="hc_header_link" style="margin-left:8px;" target="_blank" href="https://wordpress.org/plugins/healcode-mindbody-widget/">About</a>
        </td>
        <td style="float:right;">
            <a class="hc_header_link" target="_blank" href="http://www.healcode.com">HealCode</a>
        </td>

    </tr>
</table>
</div>

<div style="clear: both"></div>

