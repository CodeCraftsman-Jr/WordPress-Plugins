<?php

/* Will be removed in the future completely - KB */

?>
