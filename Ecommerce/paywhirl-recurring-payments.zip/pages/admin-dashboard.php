<?php defined('ABSPATH') or die();


// Admin Dashboard page


?>
<div class="paywhirl-dashboard-page">
	<iframe src="https://www.paywhirl.com/dashboard"></iframe>
</div>