<?php defined('ABSPATH') or die();


// Admin Subscribers page


?>
<div class='paywhirl-subscribers-page paywhirl-page flex-container'>
	<header>
		<div class="center-contents a24 c10 d8">
			<div class='logo'></div>
		</div>
	</header>
	<div class='page-title'>
		Subscribers
	</div>
	<div class='flex'>
		<div class='subscribers-table flex-container'></div>
	</div>
</div>