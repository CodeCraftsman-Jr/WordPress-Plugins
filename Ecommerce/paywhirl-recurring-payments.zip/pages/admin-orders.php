<?php defined('ABSPATH') or die();


// Admin Orders page


?>
<div class='paywhirl-orders-page paywhirl-page flex-container'>
	<header>
		<div class="center-contents a24 c10 d8">
			<div class='logo'></div>
		</div>
	</header>
	<div class='page-title'>
		Orders
	</div>
	<div class='flex'>
		<div class='flex-container'>
			<div>
				<div class="page-selector"></div>
			</div>
			<div class="flex">
				<div class='orders-table flex-container'></div>
			</div>
		</div>
	</div>
</div>