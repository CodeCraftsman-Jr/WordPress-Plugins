=== monaviscompte ===
Contributors: monaviscompte
Donate link: none
Tags: widget, customer reviews, monaviscompte, mon avis compte
Requires at least: 3.0.1
Tested up to: 4.2.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows to install in a few minutes a monaviscompte rating label (widget) on your site for immediate collection of customers reviews.

== Description ==

The monaviscompte plugin is the fastest way to display and collect customer reviews on your WordPress website.

The advantages of this plugin are:

* Improve from the first customer reviews your ranking in search engines
* Multiply your client orders thanks to the power of reviews (+15% conversion from the first review)
* Improve your service and innovate thanks to the content of reviews
* Demonstrate your customer culture and differentiate your company from your competitors

== Installation ==

1. Download the 'monaviscompte' plugin from the WordPress plugins directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the 'Widgets' menu in WordPress and find the 'monaviscompte' widget
4. Drag and drop to your sidebar
5. Enter the item id and access key given in your monaviscompte administration space, and choose the size and the color of the widget
6. Click on 'Save'

== Frequently Asked Questions ==

= What do I need to use this plugin? =

All your need is a business account on monaviscompte.fr. To do so, just contact our business team on business@monaviscompte.fr or go to https://business.monaviscompte.fr.

== Screenshots ==

1. Edit the widget configuration for the 'Widgets' menu
2. The monaviscompte widget will display on the sidebar of any page of your WordPress website

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
* No upgrade instructions.