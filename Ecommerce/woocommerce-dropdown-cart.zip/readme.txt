=== WooCommerce Dropdown Cart ===
Contributors: svincoll4
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=QZUJY7DR3JYWS&lc=VN&item_name=WooCommerce%20Dropdown%20Cart%20Plugin&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: cart, ecommerce, woocommerce, widgets, plugins
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 1.4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A widget plugin for WooCommerce to display the cart at top of page

== Description ==

Just place the Widget on your sidebar to display these icons.

== Installation ==

1. Download and unzip the plugin into your WordPress plugins directory (usually /wp-content/plugins/).
2. Activate the plugin through the 'Plugins' menu in your WordPress Admin.
3. Place the widget on your sidebar through the 'Widgets' menu in your WordPress Admin.


== Frequently Asked Questions ==

No questions.

== Screenshots ==

1. In normal
2. In expanded

== Changelog ==

= 1.4.1 =
* Fix dropdown cart on IE, EDGE

= 1.4 =
* Add option to show the widget on cart/checkout page

= 1.3.3 =
* Fixed the plural of 'item' text


= 1.3.2 =
* Fixed z-index to 10, thanks Pigo3934blog
* Fixed to close the dropdown popup when people click outside

= 1.3.1 =
* Updated the translated text "items"
* Updated "hide empty" option

= 1.3 =
* Updated CSS

= 1.2 =
* Updated CSS

= 1.1 = 
* Fixed errors on woocommerce 2.1.5

== Upgrade Notice ==

Nothing.