#About WooCommerce module
Paymentwall module for WordPress WooCommerce.

### Requirement
* Woocommerce v2.0 or greater
* WordPress v3.8 or greater
* PHP 5.2.4 or greater

#Installation
To install Paymentwall WooCommerce module, please follow the [instructions](https://www.paymentwall.com/en/documentation/WooCommerce/1409).

After cloning the repository don't forget to install Paymentwall PHP API library (**required**):
`git submodule init` and then `git submodule update`