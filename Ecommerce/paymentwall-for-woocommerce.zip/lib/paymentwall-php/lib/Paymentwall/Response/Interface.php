<?php

interface Paymentwall_Response_Interface
{
	public function process();
}