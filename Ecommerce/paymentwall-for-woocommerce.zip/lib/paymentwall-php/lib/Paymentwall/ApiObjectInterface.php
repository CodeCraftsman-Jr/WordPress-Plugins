<?php

interface Paymentwall_ApiObjectInterface
{
	public function getCard();
}