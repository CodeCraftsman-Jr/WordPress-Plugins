=== Boleto Simples ===
Contributors: ooprogramador
Tags: Boleto, Boleto Simples, Bill bank
Requires at least: 4.0
Tested up to: 4.2.3
Stable tag: 0.5
License: GPLv2 or later

== Description ==
Boleto Simples its a simple method to generate Bills.

=== Features ===

* Easy generating bills of donation
* Easy method of configuring.
* See the last 50 bills generated

== Installation ==

Upload the Boleto Simples plugin to your blog, Activate it, then enter your [boletosimples.com.br API key and Token](http://boletosimples.com.br/), and put the shortcode where you want show the Boleto Simples form.

Tks for download ;)