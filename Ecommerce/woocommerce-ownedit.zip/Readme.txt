=== Owned it - Conversation Rate Optimization  - WooCommerce Extension ===

Tags: Owned it, Converstion optimization, Lead Generation, Shoping cart Abandonment, Social Referrals, Social Following, Facebook Likes, Facabook fan, Twitter Followers.
Requires at least: Wordpress 3.0
Tested up to: 4.2.2
Stable tag: 2.0
Contributors: Owned it Ltd
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==


Owned it is an easy to use on-store conversion optimization tool that helps you to create targeted and personalized marketing campaigns for your visitors and customers. Owned it provides you with its award winning technology to run a variety of campaigns such as Exit prevention, Happy hour promotions, Deal of the day, Product notifications, Stock level indicator, Cross selling, Up selling, Location based promotions, Preventing cart abandonment and many more in just a few clicks.

Read More at www.ownedit.com

Suggestions / Feature Request

If you have suggestions or a new features request, feel free to get in touch with us via the contact form of our website

You can also follow us on Twitter! <a target="_blank" href="https://twitter.com/owned_it"> @owned_it </a> 


== Installation ==


Stage 1 


1. Download the plugin from WordPress Plugin Directory

2. Unzip the folder, and use your FTP program to upload plugin files to your WordPress plugins (wp-content/plugins/) directory.

3. Activate the plugin from the 'Plugins' menu in WordPress, go to Stage 2

or

1. Click 'Add New' option from your WordPress plugin page after login to your WordPress installation

2. Search for 'Owned it WooCommerce' extension.

3. Install the plugin, go to Stage 2


Stage 2

Enter your Owned it store ID to your Plugin. (Go to WordPress Settings, open Owned it and enter the store ID)

Note: Owned it store ID is generated for each store you add to Owned it and this can be found on Owned it Dashboard -> Account Settings -> Store Settings Tab.



== Upgrade Notice ==
Use word press version 3.0 above

== Screenshots ==
1. Use Owned It to
2. Insights
3. How it works?=== Owned it - Conversation Rate Optimization  - WooCommerce Extension ===

Tags: Owned it, Converstion optimization, Lead Generation, Shoping cart Abandonment, Social Referrals, Social Following, Facebook Likes, Facabook fan, Twitter Followers.
Requires at least: Wordpress 3.0
Tested up to: 4.2.2
Stable tag: 2.0
Contributors: Owned it Ltd
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==


Owned it is an easy to use on-store conversion optimization tool that helps you to create targeted and personalized marketing campaigns for your visitors and customers. Owned it provides you with its award winning technology to run a variety of campaigns such as Exit prevention, Happy hour promotions, Deal of the day, Product notifications, Stock level indicator, Cross selling, Up selling, Location based promotions, Preventing cart abandonment and many more in just a few clicks.

Read More at www.ownedit.com

Suggestions / Feature Request

If you have suggestions or a new features request, feel free to get in touch with us via the contact form of our website

You can also follow us on Twitter! <a target="_blank" href="https://twitter.com/owned_it"> @owned_it </a> 


== Installation ==


Stage 1 


1. Download the plugin from WordPress Plugin Directory

2. Unzip the folder, and use your FTP program to upload plugin files to your WordPress plugins (wp-content/plugins/) directory.

3. Activate the plugin from the 'Plugins' menu in WordPress, go to Stage 2

or

1. Click 'Add New' option from your WordPress plugin page after login to your WordPress installation

2. Search for 'Owned it WooCommerce' extension.

3. Install the plugin, go to Stage 2


Stage 2

Enter your Owned it store ID to your Plugin. (Go to WordPress Settings, open Owned it and enter the store ID)

Note: Owned it store ID is generated for each store you add to Owned it and this can be found on Owned it Dashboard -> Account Settings -> Store Settings Tab.



== Upgrade Notice ==
Use word press version 3.0 above

== Screenshots ==

1. Use Owned It to
2. Insights
3. How it works?

== Changelog ==

= 2.0 =
<ul>
	<li>Readme file was changed.</li>
	</li>Included pre puchase and post purchase scripts</li>
</ul>

= 1.0 =
<ul>
	<li>Initial release</li>
</ul>


== Frequently Asked Questions ==
If you have suggestions or questions, feel free to get in touch with us via the contact form of our website or via email - support@ownedit.com 

