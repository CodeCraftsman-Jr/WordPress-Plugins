<?php
class Pay_Exception extends Exception{
    
}