<?php
class Pay_Api_Exception extends Pay_Exception{
    
}