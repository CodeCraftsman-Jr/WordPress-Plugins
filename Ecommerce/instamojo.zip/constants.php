<?php

// Application ID given by Instamojo for interacting with the API
define('APPLICATION_ID', 'acd73b5ac8ccd76be2dafc46e082d415');

?>
