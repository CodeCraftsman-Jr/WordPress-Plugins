=== InviteReferrals ===
Contributors: InviteReferrals
Tags: refer a friend, referral, referral program, customer referral campaign, contest, customer referral program, referrals, affiliate, ambassador, marketing, invitereferrals, refer friends, invite referrals, invitereferral, invitereferrals, invite friends, viral marketing, social marketing, , social, promotion, tell a friend, word of mouth, widget, Tags: refer a friend, referral, referral program, customer referral campaign, contest, customer referral program, referrals, affiliate, ambassador, marketing, invitereferrals, refer friends, invite referrals, invitereferral, invitereferrals, invite friends, viral marketing, social marketing, , social, promotion, tell a friend, word of mouth, widget, campaigns, contests, Customer Referral Campaigns, customer referrals, email marketing, Facebook, friend, friends, google plus, increase, increase sales, marketing campaign, referral campaign, Referral Marketing, Refiral, sales, social media, social media marketing, twitter, viral, viral marketing, woocommerce, invitebox, invite box, referralcandy, friend buy, getambassador
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.0
Licence : GPLv2

Design and launch customer referral campaigns within minutes in WooCommerce.

== Description ==
InviteReferrals : Simplest Referral Marketing Software to design and launch Customer Referral Campaigns within minutes to reach new customers. Install once, edit or create multiple campaigns without changing the code ever on your site.
http://www.invitereferrals.com

Creating campaign does not require any technical knowledge. You also get an Facebook referral Timeline app.

You can set up 4 types of Rewards:
<ol>
<li>Share - Invite 50 friends to unlock gratification</li>
<li>Registration - Reward referrers for successful referral registrations.</li>
<li>Sale - Reward referrers for getting new sales.</li>
<li>Mobile App Install - Reward referrers for getting Mobile App Installs.</li>
</ol>

Watch quick 1 minute introduction
[youtube http://www.youtube.com/watch?v=cJmT8lK2Aps]

InviteReferrals is available in 25+ languages including swedish, russian, romanian, polish, latvian, latin, korea, greek, french, finnish, dutch, danish, arabic, italy, german, spanish, portuguese, thai. To help us support more languages (only 25 translations required), contact us on alliances@tagnpin.com

== Features ==
<ul>
<li>Multiple types of referral widgets</li>
<li>Mobile compatible - works on all device types</li>
<li>Detailed Analytics</li>
<li>Fully customizable email templates, campaign views, and referral invite content through WYSIWYG editor</li>
<li>Select from multiple customer referral options including facebook share,whatsapp, twitter, email, chat, google+, linkedin, pinterest etc</li>
<li>Built for marketers. No code changes required after one time integration</li>
<li>Select from 4 types of Rewards - Share, Sale,Registration, Mobile app Install</li>
<li>Identify and reward most influential referrers based on filters like invites sent, referral site visits or referral sales.</li>
<li>Select between unique/static coupons, or any other form of gratification like offline shipment.</li>
<li>Referral fraud prevention mechanisms are built right into your referral campaign. It includes spam proof notification system, identification of suspicious participants or manual conversion review among many other mechanisms</li>
<li>All referral campaign data can be exported.</li>
<li>Full automation</li>
<li>Create Facebook Referral App</li>
<li>Non-blocking, high-performance code</li>
</ul>

Free Plan And Paid Plans
<ul>
<li>We offer 15 days free trial period which includes 100 Participants.</li>
<li>We also offer different pricing plans with assortment of features and capabilities. For further details please visit : http://www.invitereferrals.com/campaign/site/price</li>
</ul>


== Installation ==

This section describes how to install the plugin and get it working.

1. You can either use the automatic plugin installer or your FTP program to upload plugin files to your wp-content/plugins/invitereferrals directory. Make sure the source files reside in this directory. 
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Visit your InviteReferrals Options (*Right Panel Settings Tab - InviteReferrals*) for Wordpress All Versions of Wordpress. 
4. Paste the key you received from http://www.InviteReferrals.com/ or get it from your www.InviteReferrals.com as explained in step 5.
5. Get Secret Key and brandid (used in edit module setting) as explained in the following steps
<ul>
<li>Go to www.invitereferrals.com and login (using information from registration)</li>
<li>Go to the "Integration section -> Plugin" on sidebar</li>
<li>Note the BrandID and Secret Key</li>
</ul>

== Frequently Asked Questions ==

You can find the FAQ and get support **[here](http://www.invitereferrals.com/campaign/documentation/home)**
Write to us at support@tagnpin.com for any query

== Screenshots ==
1. Live Referral Contest Screen Shot
2. Live Referral Contest Screen Shot - 2
3. Plugin Configuration settings
4. Widget in plugin directory
5. Admin panel preview
6. InviteReferrals Logo

=========================
This plugin only integrates InviteReferrals javascript sdk with wordpress woocommerce. 
InviteReferrals is a cloud SAAS service and the referral campaigns are hosted on InviteReferrals servers.
