=== MeinPreis ===
Contributors: meinpreis
Donate link: http://www.mein-preis.net/site/wordpress-plugin#donate
Tags: Preisverlauf, Amazon, Preisvergleich
Requires at least: 2.7
Tested up to: 3.4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

MeinPreis erlaubt dir den Preisverlauf eines Produkts auf deiner Seite einzubinden. 

== Description ==
MeinPreis erlaubt dem dir den Preisverlauf eines Produkts auf deiner Seite einzubinden. 

Ein Beispiel für einen Preisverlauf mit Produktbild wäre:
[productInfo:B004Q3QSWQ]
oder
[productInfo:http://www.amazon.de/dp/B007H72C64]

Ein Beispiel ohne Produktbild wäre:
[meinpreis:B004Q3QSWQ]
oder
[meinpreis:http://www.amazon.de/dp/B007H72C64]

Das Plugin versucht im Falle einer URL die Produkt Id zu extrahieren. Einfach ausprobieren, welche funktionieren.

Weitere Details auf: <a href="http://www.mein-preis.net/site/wordpress-plugin">Mein Preis Wordpress Plugin</a>

== Installation ==
Ganz normale Plugin Installation

== Screenshots ==
1. So sieht das Plugin auf einer Seite aus
2. So kann der Preisverlauf eines Produkts auf einer Seite engebunden werden

== Frequently Asked Questions ==

Nothing yet

== Upgrade Notice ==

= 1.0.6 =
Es können nun auch Amazon Urls statt nur der Produktnummer verwendet werden 

= 1.0.0 =
Initial release

== ChangeLog ==

= Version 1.0.0 =

* Initial release!
