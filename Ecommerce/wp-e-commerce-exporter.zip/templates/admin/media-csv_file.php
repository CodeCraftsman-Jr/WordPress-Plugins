<div class="postbox-container">
	<div class="postbox">
		<h3 class="hndle"><?php _e( 'CSV File', 'wpsc_ce' ); ?></h3>
		<div class="inside">
			<textarea style="font:12px Consolas, Monaco, Courier, monospace; width:100%; height:200px;"><?php echo $contents; ?></textarea>
		</div>
		<!-- .inside -->
	</div>
	<!-- .postbox -->

</div>
<!-- .postbox-container -->
