=== Instagram To WooCommerce Products ===
Contributors: yehudah
Donate link: http://wpdevplus.com/support-us/
Tags: woocommerce, instagram, tags, hashtags
Requires at least: 4.0
Tested up to: 4.1.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Display Instagram images of your products, or any image based on a hashtag.

== Description ==

Display Instagram images of your products, or any image based on a hashtag.

The plugin includes:

* Built in responsive lightbox.
* Adjustable grid layout.
* Integrated to woocommerce UI.

= Setup is quick and easy =
1. Type your instagram api code in the plugin settings.
2. Add a hashtag to each product you’d like to display Instagram images on.
3. You’re done!

== Installation ==
1. Download the the plugin.
2. Decompress the ZIP file and upload the contents of the archive into `/wp-content/plugins/`.
3. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
= Where do I get my instagram "client secret id" ?
You can create one here: <https://instagram.com/developer/clients/manage/>

= Where do I input instagram client id key ? where are the settings ? =
The plugin settings are in woocommerce settings under the currency section. Look in the screenshots.

= Where do I input the hashtag ? ==
When you add your product, there is a tab called "Instagram" . Look in the screenshots. 

== Screenshots ==
1. instagram tab in woocommerce new product page
2. plugin settings (under woocommerce settings)

== Changelog ==
1.0 - initial release