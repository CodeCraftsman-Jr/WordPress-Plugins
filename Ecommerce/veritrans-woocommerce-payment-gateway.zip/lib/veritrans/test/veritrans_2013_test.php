<?php 

class Veritrans2013Test extends PHPUnit_Framework_TestCase
{
  
}