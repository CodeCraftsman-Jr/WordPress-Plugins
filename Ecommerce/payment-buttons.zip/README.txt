﻿=== Payment Buttons ===
Contributors: mbj-webdevelopment
Tags: PayPal, PayPal Button, Buy Now Button, Add to Cart Button, Subscribe Button
Requires at least: 3.8
Tested up to: 4.3.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Easy PayPal Payment Buttons

== Description ==

= Introduction =

Easily add PayPal payment options to your WordPress website.

* Buy Now
* Add to Cart
* Donate
* Subscribe

== Installation ==

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Payment Buttons" and click Search Plugins. Once you've found our plugin you can view details about it such as the the rating and description. Most importantly, of course, you can install it by simply clicking Install Now.

= Manual Installation =

1. Unzip the files and upload the folder into your plugins folder (/wp-content/plugins/) overwriting previous versions if they exist
2. Activate the plugin in your WordPress admin area.


= configuration =

Easy steps to install the plugin:

*	Upload "payment-buttons" folder/directory to the /wp-content/plugins/ directory
*	Activate the plugin through the 'Plugins' menu in WordPress.
*       Go to: Settings > Checkout > PayPal Button  to configure the plugin.

== Screenshots ==

1. Create PayPal button with multiple option