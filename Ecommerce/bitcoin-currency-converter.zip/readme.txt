=== Bitcoin Currency Calculator ===

Contributors: suicidalfish
Tags: bitcoin, currency converter, usd, gbg, eur, mtgox
Donate link: http://www.rjmacarthy.com/
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A sidebar widget or shortcode entry to display a Bitcoin to USD, GBP or EUR.  

Plugin uses live data from MT Gox to convert Bitcoin to real currency.

Plugin data gathers data from API found at http://btcrate.com/

If you like this plugin please donate Bitcoin to:

1JokP92X916fbvdT9pVdegqrt7c8hCFXJ4

== Installation ==

1. Upload contents of bitcoin-calculator to the `/wp-content/plugins/` directory.
2. Activate the plugin through the \\\\\\\\\\\\\\\'Plugins\\\\\\\\\\\\\\\' menu in WordPress
3. Use the widgets menu on your wordpress theme to add the widget to the sidebar.
4. Use the shortcode entry '[bitcoin-currency-calculator]' to display the converter on a page or a post.

== Frequently Asked Questions ==

1. Q: No data is displaying?  A: Please make sure CURL is enabled on your php.ini for your hosting.

If you have any questions please e-mail me at richardmacarthy@hotmail.com and I'll be happy to answer them.

== Screenshots ==

1. Screenshot showing converter.

== Changelog ==
= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.1 =
* Initial release.