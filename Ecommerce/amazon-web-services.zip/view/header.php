<div class="wrap aws-main" data-view="<?php echo $page; ?>">

	<h2><?php echo esc_html( $page_title ); ?></h2>