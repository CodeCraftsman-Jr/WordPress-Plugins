=== Ewire Payment Module ===
Contributors: KristianPress
Donate link: http://ewirepayment.codeplex.com
Tags: netpayments,accept ewire,ewire payments
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 1.0

== Description ==
Release notes: ewirepayment.codeplex.com

** Version 1.0B **

This version is without complete,renew and cancel externally.
Therefore remember, when a Ewire order has been submitted it shall be
completed in your ewire account on ewire.dk.


Ewire can not be held responsible for any damages or errors caused by the package,
problem resolving goto: ewirepayment.codeplex.com.

Good Luck,
The Ewire Module Team

== Installation ==
1. Open the folder "Wordpress" folder.
2. Copy the folder "wp-content" into the folder:
3. Goto your Wordpress - WP E Commerce backend and find Ewire under "Payment Options"
4. Mark it and "Update"
5. Choose Ewire from the list at the right and configure it with the information found at your Ewire account under "Business".
You're good to go!

== Frequently Asked Questions ==
= Ask in a forum = 
Goto ewirepayment.codeplex.com
= Invalid paramters =
Check language, currency that it is correct

== Screenshots ==
1. Backend Picture
2. Backend Picture
3. Testmode Picture
4. Frontend Picture
5. Frontend Picture


