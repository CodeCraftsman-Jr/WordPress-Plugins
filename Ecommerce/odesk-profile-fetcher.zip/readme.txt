=== Odesk Profile Fetcher ===
Contributors: Rey Calantaol
Plugin URL: http://reygcalantaol.com/odesk-profile-fetcher/
Plugin Demo: http://reygcalantaol.com/php-programmer-asp-programmer-web-developer-about/
Tags: odesk profile,odesk
Requires at least: 3.0
Tested up to: 3.3.2
Stable tag: 0.11

Display your odesk profile into your wordpress blog.

== Description ==

Odesk Profile Fetcher is a wordpress plugin that uses Odesk API to display your odesk.com profile to your website. This plugin requires Odesk.com account. If you do not have one, please visit https://www.odesk.com/referrals/track/reyborn?redir=https%3A%2F%2Fwww.odesk.com%2Fusers%2F%7E%7E3b4cb1884e0b769a.
Please provide your profile key, you can found it at your Odesk public profile page somewhere below your photo at the last part of the permalink.

Informations that this plugin pulled from your Odesk profile are Overview, Resume, Word History and Feedback, Tests, and Portfolio. This is one good way to advertise your skills and expertise over the web and make it visible to everyone.

Please follow the link below to view the live action of the plugin:
http://reygcalantaol.com/php-programmer-asp-programmer-web-developer-about/

Follow this link to view documentation and download page:
http://reygcalantaol.com/odesk-profile-fetcher/


== Features ==

1. Built-in profile widget
2. Easy page setting.
3. Easy usage, just post this shortcode in post or page "[odesk_profile]".

== Installation ==

1. Extract zip in the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Provide you odesk profile number at Settings -> Odesk Profile Fetcher
4. Lastly, use this shortcode in post or page "[odesk_profile]".

== Frequently Asked Questions ==

Where can I find the odesk profile unique key?

You can find your odesk profile key in your public odesk profile.
Below your profile photo, your see a permalink, the last part of your permalink is your odesk unique key.


== Changelog ==
= 0.11 =
Adding proxy support and redirection if odesk fails
= 0.10 =
The first released version