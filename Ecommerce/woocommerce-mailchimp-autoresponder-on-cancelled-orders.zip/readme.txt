=== Plugin Name ===
Contributors: victoor89
Donate link: http://victorfalcon.es/
Tags: woocommerce, mailchimp, failed order, cancelled order, autorresponder
Requires at least: 3.8
Tested up to: 3.8.1
Stable tag: 3.8.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Send an email to clients when the order is cancelled or failed. These email can improve your conversions rates by a 50%.

== Description ==

When an order is failed or cancelled we add that user email to a mailchimp list. Then you can create in Mailchimp an autorresponder that invite the user to try again. If you add a discount you can improve the conversions rates by a 50% or more.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to your Woocommerce Integrations Settings page and add your data

== Frequently Asked Questions ==



= What about foo bar? =



== Screenshots ==
1. Settings page

== Changelog ==
= 1.0.1 =
* Now it works. Solved bugs.
= 1.0 =
* Stable version. It's just work fine.

== Upgrade Notice ==

= 1.0.1 =
* Now it works. Solved bugs.

= 1.0 =
* Stable version.
