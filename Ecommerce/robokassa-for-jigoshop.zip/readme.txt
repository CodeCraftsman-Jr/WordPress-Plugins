=== Robokassa for Jigoshop ===
Contributors: loomst, akurganow
Tags: robokassa, payment getaway, jigoshop, ecommerce
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 0.9.1

Allows you to use Robokassa payment gateway with the Jigoshop ecommerce plugin.

== Description ==

*В Robokassa прописываем:

*Оповещение о платеже - имя сайта]/jigoshop/robokassacallback.php

*Ссылка об удачном платеже - имя сайта]/jigoshop/robokassathanks.php

*Ссылка о неудачном платеже - имя сайта]/jigoshop/robokassacancel.php
  
  
*В бесплатной версии в корзине и на страницах оформления заказа, присутствуют ссылки на авторов плагина

== Installation ==

1. Ensure you have latest version of [WooCommerce](http://www.woothemes.com/woocommerce/) plugin installed
2. Unzip and upload contents of the plugin to your `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress


== Changelog ==
= 0.9.1 =
* Added restriction to the free version, previous version are not available
= 0.9 =
* First public release
