=== Opes WP Ads Manager ===
Contributors: twapaw
Tags: ads, ad, advert, adverts, advertisement, advertisements, manager, plugin
Requires at least: 3.5.0
Tested up to: 4.2.0
Stable tag: 1.2.0
License: GPLv2 or later

Opes WP Ads Manager allows you to show advertisements on the website

== Description ==

Opes WP Ads Manager is a simple plugin that allows you to show advertisements as a widget on the website

<strong style="font-size: 18px;"> Just works! </strong>

Major features in Opes WP Ads Manager include:

* <strong style="font-size: 18px;">Since version 1.2.0 only one widget can be add and only two ads can be shown</strong>
* An ad as a custom post type
* An every ad can link to specific web page
* A widget generator
* A custom post featured image used as an ad
* Ad sizes management (use Regenerate Thumbnails plugin to extend management of the sizes image files)

PRO Version (available soon) features:

* Stats
* Not limited widgets and ads can be add
* Management of order of ads in a widget

== Installation ==

* Upload the Opes WP Ads Manager plugin to your blog and activate it
* Go to "OWP Ads Manager" and generate widgets
* Go to "OWP Ads Manager -> Ad Sizes" and ad sizes
* Go to "Apperance -> Widgets" and set the widgets in sidebars & do not forget about handles configuring the widgets!
* Upload ad images as media!
* Create your first Ad with ad image as featured image!

== Changelog ==

= 1.2.0 =
*Release Date - 25th April, 2015*

* EXTENSION: <strong style="font-size: 18px;">Since version 1.2.0 only one widget can be add and only two ads can be shown</strong>
* INFO: * <strong style="font-size: 18px;">Full version is PRO version (available soon)</strong>
* ADD: managing advert sizes (use Regenerate Thumbnails plugin to extend management of the sizes image files)
* ADD: deleting advert sizes & position widgets

= 1.1.0 =
*Release Date - 7th April, 2015*

* FIXED: bug with ads querying when stop date was empty
* <strong style="font-size: 18px;">Since version 1.1.0 only one widget can be add and only one ad can be shown</strong>
* <strong style="font-size: 18px;">Full version is PRO version (available soon)</strong>

= 1.0.0 =
*Release Date - 7th April, 2015*

* It is first release
