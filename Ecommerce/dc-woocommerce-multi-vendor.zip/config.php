<?php
define('PLUGIN_TOKEN', 'dc-product-vendor');

define('TEXT_DOMAIN', 'dc_product_vendor');
define('PLUGIN_VERSION', '1.0.0');
?>