=== JennyClicks Buy Now Buttons Plugin ===
Contributors: jennyclicks
Donate link: http://jennyclicks.com/plugincreator/
Tags: sales, make money, buy, buy now, buy now buttons, sell online
Requires at least: 2.0.2
Tested up to: 3.2.1
Stable tag: 4.3

JennyClicks buy now buttons plugin enables you to sell more online by using awesome buy now buttons in your WP post or pages.

== Description ==

If you sell online then use JennyClicks buy now buttons plugin to increase your sales & conversions.

This plugin allows you to add stunning buy now buttons which literally force your website visitors to buy from you. Just use a short code in your WP post or pages to use these HOT sales sucking buttons.

This plugin was built using world's first WP Plugin Creator, now literally anyone can make their own plugin & get exposed to millions of WP users. Just visit http://jennyclicks.com/plugincreator


== Installation ==

Installing JennyClicks Buy Now Buttons Wordpress plugin is very easy. Just copy the "jennyclicksbuynowbuttons" folder & paste it into your wp-content/plugins folder.
For detailed instruction on how to install manually, visit http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation

After installing the plugin, the next thing you need to do is activate the plugin by logging in to your Wordpress blog admin panel & clicking on installed plugins 
sub menu link. Once you activate JennyClicks buy now buttons plugin, you will find a new tab. Just click on that tab & follow the instructions there to use the plugin.

For any help, contact www.jennyclicks.com/support

== Frequently Asked Questions ==

Q.What this plugin is all about?

This plugin help you increase your sales by allowing you to add stunning & beautiful buy now buttons to your WP posts OR pages OR sidebar.

Q.I need some help with plugin?

You are more than welcome to contact JennyClicks support for any help, suggestions & feedback by visiting www.jennyclicks.com/support

Q.Can I create a plugin like this?
Yes definitely. With JennyClicks WP plugin creator, you don't need any technical skills to create WP plugins. Just visit http://jennyclicks.com/plugincreator & create your own plugin to get exposed to millions of Wordpress users.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot

== Changelog ==

= 1.0 =
The most recent version of JennyClicks buy now buttons plugin.
