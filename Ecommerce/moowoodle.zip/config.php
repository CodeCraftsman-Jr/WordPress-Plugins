<?php

define('DC_WOODLE_PLUGIN_TOKEN', 'dc-woodle');

define('DC_WOODLE_TEXT_DOMAIN', 'woodle');

define('DC_WOODLE_PLUGIN_VERSION', '1.0.0');

define('DC_WOODLE_PLUGIN_SERVER_URL', 'http://plugins.dualcube.com');

?>