var loyalty_debug = loyaltyConfig.debug;
var loyalty_antiflicker = loyaltyConfig.antiflicker;
var loyalty_delay = loyaltyConfig.delay;

jQuery('html').loyalty({
	debug: loyalty_debug,
	antiflicker: loyalty_antiflicker,
	delay: loyalty_delay
});