<?php
if (!defined( 'WP_UNINSTALL_PLUGIN' ) ){
	exit();
}

// Delete options from WP_OPTIONS table
delete_option( 'loyalty_debug' );
delete_option( 'loyalty_antiflicker' );
delete_option( 'loyalty_delay' );

?>