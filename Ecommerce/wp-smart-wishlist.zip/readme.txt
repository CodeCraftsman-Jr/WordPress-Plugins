=== WP Smart Wishlist ===
Contributors: rajanit2000,a2ztechnologies
Tags: wishlist, wp-ecommerce, wp-ecommerce wishlist, saved products, products, ecommerce, ecommerce wishlist
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is Wish List Plugin for WP eCommerce Site. 

== Description ==

This is Wish List Plugin for WP eCommerce Site. Its use to add wishlist like shopping cart. 

= Custom Options =
	
	1. Install Plugin
	2. Add Smart Wish List Widget from your theme
	3. No need short code
	4. No need functions
	5. Just install and add wishlist widget on your sidebar or where you want in your theme 

== Installation ==

	1. Add Smart Wish List Widget from your theme
	
== Frequently Asked Questions ==

1. Is this plugin working without WP eCommerce Plugin?

	No, WP eCommerce Plugin is required for this plugin

== Screenshots ==

1. screenshot-1.png 
2. screenshot-2.png 

== Changelog ==

= 1.0 =

* New: Wishlist Plugin

= 2.0 =

* Update: Table structure
* New: Comfortable for Bootstrap Themes 

== Upgrade Notice ==

The current version of WP Smart Wishlist requires WordPress 3.0 or higher. If you use older version of WordPress, you need to upgrade WordPress first.