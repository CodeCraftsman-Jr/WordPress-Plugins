<?php

class Test_RT_Plugin_Update extends RT_WP_TestCase {
	public $rtpluginupdate;

	public function test_constructor() {
		//https://rtcamp.com/wp-content/uploads/rt-lib-plugin.json

		$this->rtpluginupdate;
	}
}
