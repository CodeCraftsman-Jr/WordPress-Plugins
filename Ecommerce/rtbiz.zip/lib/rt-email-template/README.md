RT Email Template
==========

Responsive email template class base on Zurb Ink email template framework

```
$rt_email_template = new RT_Email_Template( );
```

`get_header` method will return header of email with css.

`get_footer` method will return footer of email.