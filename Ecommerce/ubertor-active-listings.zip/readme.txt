Simple read me file for the Ubertor Active Listings widget.

1) Copy the plugin file - listings.php to your Wordpress plugins folder (ie: /wp-content/plugins/listings.php)

2) Login to your Wordpress dashboard and activate the plugin

3) Goto the widgets section in your dashboard and draft the new widget to your sidebar

4) Give the widget a title ie: Active Listing and type in your Ubertor website address ie: http://www.mywebsite.com