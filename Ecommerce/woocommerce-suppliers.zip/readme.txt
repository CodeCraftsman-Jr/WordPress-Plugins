=== WooCommerce Suppliers ===
Contributors: agenciamagma, Carlos Cardoso Dias
Donate link: http://www.agenciamagma.com.br
Tags: woocommerce suppliers, woocommerce fornecedores, woocommerce, suppliers, fornecedores, fornecedor, supplier
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WooCommerce Suppliers inserts the suppliers taxonomy associated with the product custom post.

== Description ==

WooCommerce Suppliers creates the suppliers taxonomy, allowing the user to associate one or more suppliers to a product.

= Descrição em Português =

WooCommerce Fornecedores cria a taxonomia fornecedores, permitindo ao usuário associar um ou mais fornecedores à um produto.

== Installation ==

1. Upload the contents of `woocommerce-suppliers` to the `/wp-content/plugins/woocommerce-suppliers/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Do I have to install WooCommerce to use this plugin? =

Yes. The plugin was been tested under WooCommerce 2.3.5, so that might be enough.

== Screenshots ==

1. This image shows the suppliers registration area.

== Changelog ==


= 1.0 =
* First version.

== Upgrade Notice ==

= 1.0 =
First version.
