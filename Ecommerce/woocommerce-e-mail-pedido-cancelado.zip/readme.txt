=== Woocommerce E-mail Pedido Cancelado ===
Contributors: agenciamagma, Carlos Cardoso Dias
Donate link: http://www.agenciamagma.com.br
Tags: woocommerce, e-mail, cancelamento, pedido, pedido cancelado, woocommerce cancelamento
Requires at least: 4.0.1
Tested up to: 4.0.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Send email to user when his order is cancelled.

== Description ==

This plugin sends an e-mail to let the user know that his order has been cancelled by the system and/or administrator.

= Descrição em Português =

Este plugin envia um e-mail para o cliente quando seu pedido é cancelado pelo sistema e/ou administrador.

== Installation ==

1. Upload `woocommerce-email-pedido-cancelado.php` to the `/wp-content/plugins/woocommerce-email-pedido-cancelado/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Do I have to install Woocommerce to use this plugin? =

Yes. The plugin was been tested under woocommerce 2.2.8, so that might be enough.

== Screenshots ==

1. This screenshot shows an example of the e-mail delivered to the user.

== Changelog ==

= 1.0.1 =
* E-mail with WooCommerce template.

= 1.0 =
* First version.

== Upgrade Notice ==

= 1.0.1 =
This version uses a cool WooCommerce default template for e-mails.

= 1.0 =
First version.
