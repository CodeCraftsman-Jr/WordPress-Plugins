=== TicketHeere - Online kaartverkoop ===
Contributors: bpluijms
Plugin URI: http://wordpress.org/extend/plugins/ticketheere/
Author URI: http://wordpress.geev.nl
Tags: Event support, event tickets
Requires at least: 3.8
Tested up to: 4.3
Stable tag: 0.3
License: GPLv2

This plugin adds a widget and a shortcode to WP for easy integration of TicketHeere - Event ticketing
== Description ==
Need to sell tickets for your event? TicketHeere will save your day! This plugin adds a widget and shortcode to your website for easy integration of TicketHeere.
For more information about TicketHeere, please visit [www.ticketheere.nl](http://www.ticketheere.nl) (Dutch only).

**Dutch Description**
TicketHeere is de online bezoekersregistratie dienst van DeJonckHeere. Met deze plugin van TicketHeere integreer je eenvoudig je ticket webshop in je WordPress website.
Voor meer informatie over de diensten van DeJonckHeere en alle functies en mogelijkheden van TicketHeere kijk je op [www.ticketheere.nl](http://www.ticketheere.nl).

== Installation ==

1. Install TicketHeere either via the Wordpress.org plugin directory or by uploading the files to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Create an account on our website and go to "Channels". 
4. Copy paste settings to TicketHeere plugin.

== Upgrade Notice ==
Please backup first.

== Screenshots ==

== Changelog ==
***TicketHeere***
= 2015.08.11 version 0.3 =
* Fixed PHP 4 constructor style in widget

= 2014.03.30 version 0.2 =
* Excluded ticket js for better support with older themes
* Fixed some errors while in DEMO mode

= 2014.03.15- version 0.1 =
* First release

== Frequently Asked Questions ==
= Where can I find more information about this plugin and TicketHeere =
You can find more information on [our website](http://www.ticketheere.nl/).