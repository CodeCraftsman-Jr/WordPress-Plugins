var org=djh.org;
var ev=djh.ev;
var med=djh.med;
var useTunnel = true;
var tunnelurl = djh.tunnelUrl;

  (function() {
    var jh = document.createElement('script');
    jh.type = 'text/javascript'; 
    jh.async = true;
    jh.src = 'https://shop.ticketheere.nl/js/integrate.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(jh, s);
  })();
