==== Bulk Stock Update for WooCommerce ====
Contributors: webmumbai
Tags: bulk stock update, bulk stock mannage, update product stock, update prouct quantity, one page update stock
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://plugins.web-mumbai.com/

Update/Manage Product Stock Properties

== Description ==

"Bulk Stock Update for WooCommerce" is a plugin which allows you to manage stock properties. This version support list of Simple Product Manage Stock, Variable Products  Manage Stock and  Variation Product Manage Stock

If you have an interest in customization this plugin please let me know.

== Installation ==
1. Install the Bulk Stock Update for WooCommerce
2. Activate the plugin
3. Wordpress Admin > Products > Bulk Stock Update

== Frequently Asked Questions ==
Q: This product Pro Version availbale?
A: Yes.

== Changelog ==
= 1.1.1 - 2015-09-06 =
* Tested: tested in latest wordpress 4.3
* Tested: tested in latest WooCommerce 2.4.6
* Fix: Small bugs fixing


= 1.1 - 2015-08-22 =
* Tested: tested in latest wordpress 4.2.2
* Tested: tested in latest WooCommerce 2.4.5
* Added: Tab CSS

= 1.0 =
* Initial Release


== Upgrade Notice ==
= 1.1.1 - 2015-09-06 =
* Tested: tested in latest wordpress 4.3
* Tested: tested in latest WooCommerce 2.4.6
* Fix: Small bugs fixing

= 1.1 - 2015-08-22 =
* Tested: tested in latest wordpress 4.2.2
* Tested: tested in latest WooCommerce 2.4.5

= 1.0 =
* Initial Release

== Screenshots ==
1. List of Simple Products
2. List of Variable Products
3. List of Variation Products