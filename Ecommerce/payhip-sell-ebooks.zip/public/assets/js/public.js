(function ( $ ) {
    "use strict";

    $(function () {        

    });

}(jQuery));