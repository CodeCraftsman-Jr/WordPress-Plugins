	<table class="wp-list-table widefat fixed bookmarks">
		<thead>
	    	<tr>
	        	<th><?php _e('Instructions','woocommerce-better-feeds');?></th>
	        </tr>
	    </thead>
	    <tbody>
	        <tr>
	        	<td>
	            	<ol>
		            	<li><?php _e('Select which elements you want to include to your feed.','woocommerce-better-feeds');?></li>
	                	<li><?php _e('Select the image size you want to keep in your rss feed.','woocommerce-better-feeds');?></li>
	                    <li><?php _e('Click Save Changes','woocommerce-better-feeds');?></li>
						<li><?php _e('You are done.','woocommerce-better-feeds');?></li>
						<li><?php _e('Now you can check your feeds','woocommerce-better-feeds');?></li>
	                </ol>
	            </td>
	        </tr>
	    </tbody>
	</table>
</div>