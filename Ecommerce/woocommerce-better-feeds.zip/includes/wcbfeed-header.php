<div class="wrap">
<h2>WooCommerce Better Feeds</h2><br/>
<table width="100%">
	<tr>
    	<td valign="top">