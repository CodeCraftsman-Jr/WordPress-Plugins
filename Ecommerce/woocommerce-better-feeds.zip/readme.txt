=== WooCommerce Better Feeds ===
Contributors: elsteno
Tags: price, woocoomerce, featured image, rss, feed, image in rss feed, price in rss feed
Requires at least: 4.0.
Tested up to: 4.2
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin adds featured image and price to your rss feeds

== Description ==

This plugin adds featured image and price to your rss feeds

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Choose your options

== Screenshots ==

1. The settings page

== Frequently Asked Questions ==

= Can i change the image size ? =

Yes, you can change the image size from the settings page of the plugin.

== Upgrade Notice ==
This is the first version


== Changelog ==

= 1.1 =
* Some fixes

= 1.0 =
* First Release

