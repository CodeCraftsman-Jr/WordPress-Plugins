<?php
define(PAUKERFILE, 'pauker.pau');
define(PAUKERUPLOADPATH, '../wp-content/uploads/pauker/');
define(PAUKEROPENPATH, 'wp-content/uploads/pauker/');
?>