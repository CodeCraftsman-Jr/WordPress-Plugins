=== Pauker ===
Contributors: Moe
Donate link: www.mysse.net/
Tags: widget, pauker, vocabulary
Requires at least: 2.2
Tested up to: 2.8.0
Stable tag: 0.1

This plugin adds a widget that displays a random flash card from a Pauker data set and a second widget to display stats. See http://pauker.sourceforge.net/ for more details on Pauker.

== Description ==

This plugin adds a widget that displays a random flash card from a Pauker data set and a second widget to display stats. See http://pauker.sourceforge.net/ for more details on Pauker.

== Installation ==

1. Upload Files to the `/wp-content/plugins/` directory (or install it using the 'Plugins' page in Admin Backend)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the Pauker widgets in your sidebars and click '[EDIT]' to set the titles
4. Use Settings -> Pauker to upload a Pauker data set

== Frequently Asked Questions ==

= Where can I ask for help? =

try paukerReMoVeThIs@mysseAnDtHiS.net

== Screenshots ==
