<div class="ec_admin_leftmenu">
    <div class="ec_admin_leftmenu_inner arrow_pos_1">
        <div class="ec_admin_leftmenu_header">EasyCart Setup</div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "basic-setup" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=basic-setup">Basic Setup</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "basic-settings" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=basic-settings">Basic Settings</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "colorize-easycart" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=colorize-easycart">Colorize EasyCart</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "payment-settings" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=payment-settings">Payment Setup</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "advanced-language" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=advanced-language">Advanced Language</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "advanced-setup" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=advanced-setup">Advanced Options</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "woo-importer" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=woo-importer">Import From WooCommerce</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "google-merchant" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=google-merchant">Google Merchant Setup</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "mymail-integration" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=mymail-integration">MyMail Newsletter Integration</a></div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "design-management" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=store-setup&ec_panel=design-management">Design File Management</a></div>
    </div>
</div>