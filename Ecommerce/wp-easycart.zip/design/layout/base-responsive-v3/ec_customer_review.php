<div class="ec_customer_review">
  <div class="ec_customer_review_title">
    <?php $review->display_review_title(); ?>
  </div>
  <div class="ec_customer_review_date">
    <?php $review->display_review_date("F j, Y"); ?>
  </div>
  <div class="ec_customer_review_stars">
    <?php $review->display_review_stars(); ?>
  </div>
  <div class="ec_customer_review_description">
    <?php $review->display_review_description(); ?>
  </div>
</div>
