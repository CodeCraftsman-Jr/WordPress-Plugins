<?php 

define("DOMPDF_UNICODE_ENABLED", true);
define("DOMPDF_PDF_BACKEND", "CPDF");

define("DOMPDF_DEFAULT_FONT", "dejavu sans");


define("DOMPDF_ENABLE_REMOTE", true);
define("DOMPDF_ENABLE_CSS_FLOAT", true);

define("DOMPDF_ENABLE_PHP", true);

//define("DEBUGCSS", true);
//define("DEBUG_LAYOUT", true);
//define("DEBUG_LAYOUT_LINES", false);
//define("DEBUG_LAYOUT_BLOCKS", false);
//define("DEBUG_LAYOUT_INLINE", false);

//define("DEBUG_LAYOUT_PADDINGBOX", false);
