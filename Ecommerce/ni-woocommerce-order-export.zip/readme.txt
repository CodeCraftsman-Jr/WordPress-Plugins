=== Ni Woocommerce Order Export ===
Contributors: Anzar Ahmed
Tags:Tags: woocommerce, order, export xls,export csv, woocommerce order, woocommerce order export, woocommerce sales, today sales, order sales, order export plugin, sales report cart, daily sales, weekly sales, monthly sales, yearly sales  
Requires at least: 4.1.1
Tested up to: 4.2.2
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ni Woocommerce Order Export help you to keep the track of daily,weekly,monthly and yearly sales and export the billing email address and billing name. 

== Description ==

* Ni Woocommerce Order Export help top keep the track of daily, weekly, monthly and yearly sales report. 
* It provides the list of order details. 
* It provide the total sales, total customer, daily sales and daily customer.
* You can export billing address and email address.
* Filter the report by date range

Some Features.

* Fast And Easy Install
* Total Sales
* Total Order
* Today Sales
* Today Total 
* Today Customer
* Sales order list
* Filter by date, Today Date, Yesterday Date,  Last 7 days, Last 30 days, This year
* Export billing name and email address
* Print button to print order list



== Installation ==

1. Use the WordPress plugin installer or upload files to WordPress plugin directory.
1. Activate plugin from admin panel.
1. Order Export. 

== Frequently Asked Questions ==

= Where i can get help? =

Click on support tab or email : i.anzar14@gmail.com

= Do you customize this plugin? =

Yes, as per requirement we can customize this plugin.

= Do you export more columns such as billing address, shipping address and other order details? =

Yes, as per requirement we can add more columns.

= Can you provide the filter base on customer name or email address? =

Yes, we can add the filter on customer name, billing email and order number etc.

== Screenshots ==

1. Sales Summary.
2. Order List.
2. Order Export.


== Changelog ==

= version 1.2 =
* Added:  Print button to print order list
* Tested: Compatible With WordPress 4.2.2
* Tested: Compatible With Woocommerce 2.3.11

= version 1.1 =
* Fixed:  Woocommerce Price Format
* Added:  Order Total
* Added:  Currency Columns
* Tested: Compatible With WordPress 4.2.2
* Tested: Compatible With Woocommerce 2.3.10


= version 1.0 =
* Initial relese

== Upgrade Notice ==

New Features add upgrade please.

== Disclaimer ==

It is not responsible for any harm or wrong doing this Plugin may cause. Users are fully responsible for their own use. This Plugin is to be used WITHOUT warranty.