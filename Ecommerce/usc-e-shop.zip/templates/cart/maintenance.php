<?php
$html = '<div id="maintenance-page">

<div class="post">
<p>'.__('Maintaining now', 'usces').'</p>
<p>'.__('Please wait for a while.', 'usces').'</p>
</div>

</div>';
?>
