=== Easy Digital Downloads QR Code ===
Contributors: chriscct7
Requires at least: 4.0
Tested up to: 4.2
Contributors: chriscct7
Donate link: http://donate.chriscct7.com/
Tags: easy digital downloads, edd, edd qr code, edd qr, qr, qr code
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Generate QR codes for your products!

== Installation ==

1. Unzip the archive on your computer
2. Upload `easy-digital-downloads-qr-code` directory to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

None Yet

== Support And Contributing ==

All support for chriscct7 plugins are done via the forum on wordpress.org.

If you'd like to help, feel free to contribute at the [GitHub Repo](https://github.com/chriscct7/easy-digital-downloads-qr-code) for this plugin.

== Frequently Asked Questions ==

Haven't had any yet

== Changelog ==
= 1.1.1 =
* FIX: XSS vulnerability in query args

= 1.1.0 =
* Fixes issue with metabox display

== Upgrade Notice ==
= 1.0.0 =
* Initial Release
