=== INTERSWITCH WEBPAY FOR WOOCOMMERCE ===
Contributors: myeverlasting
Tags: woocommerce, payment gateway, mastercard, visa cards, interswitch, verve cards, verve, nigeria, webpay, ecommerce, essl
Requires at least: 3.5
Tested up to: 4.3
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a simple plugin that helps you accept mastercard, visa card and verve cards on your woocommerce store, by connecting your store to the number one payment gateway in Nigeria (WEBPAY by interswitch). The plugin requires you change your store language to English and Currency to Naira.
It comes with the requery transactions feature and will help you pass interswitch UAT in no time.




== Description ==

Th Interswitch's webpay payment processor plugin that connects your woocommerce powered store to the number one payment gateway in Nigeria (interswitch's webpay) and enable you process cards such as :

*  -- Visa --
*  -- Verve --
*  --Mastercard --


*  ABOUT WEBPAY
Webpay is interswitch's proprietary payment gateway and interswitch is Nigeria's leading payment processor/switching company.
               The API enables your to accept payment from your customers holding the following cards :
                * Verve Card (Nigeria's number one card brand ) 
                * Mastercard 
                * VISA Card 
                
 Transactions are settled bank account as agreed upon with interswitch on sign-up and this is performed in T+24 hours where T = Transaction time.
*  THE PLUGIN
Start accepting payments on your website in 4 easye steps :
                *   Sign up for webpay
                *   Install wordpress, woocommerce and prepare your store
                *   Download my plugin 
                *   Install and start using
*   HOW TO INSTALL
            	*   Download and install current version of 
                *   login to your dashboard
                *   Install, activate and enable Woocommerce plugin
                *   Change your store currency to Naira
                *   install the plugin : INTERSWITCH WEBPAY FOR WOOCOMMERCE
                *   Activate the plugin
                *   Click settings, and populate input fields with your product id, mac key and other configuration data from interswitch
                *   Enable Sandbox(test) or production (live)
                *   To re-query transactions: go to your admin menu and click webpay requery, insert transaction reference and click requery button 
                *   Interswitch Webpay will be available as a payment option on-checkout
 

