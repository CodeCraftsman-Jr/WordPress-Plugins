<?php
if(!defined($widgetPrefix . 'WIDGET_VERSION'))
	define($widgetPrefix . 'WIDGET_VERSION', '2.0.2');