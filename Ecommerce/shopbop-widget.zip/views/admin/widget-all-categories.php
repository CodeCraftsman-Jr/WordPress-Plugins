<select name="<?php echo $optionsName; ?>[widget_all_category]" style="min-width: 200px">
    <option value=''>- Select Category -</option>
    <?php echo $categories ?>
</select>