Just Arrived <input type="radio" name="widget_pane_to_open" value="justarrived" <?php if($pane == 'justarrived') echo 'checked="checked"'; ?> />&nbsp;&nbsp;&nbsp;&nbsp;
Shop <input type="radio" name="widget_pane_to_open" value="shop" <?php if($pane=='shop') echo 'checked="checked"'; ?> />&nbsp;&nbsp;&nbsp;&nbsp;
Featured <input type="radio" name="widget_pane_to_open" value="featured" <?php if($pane=='featured') echo 'checked="checked"'; ?> />&nbsp;&nbsp;&nbsp;&nbsp;
Random <input type="radio" name="widget_pane_to_open" value="random" <?php if($pane=='random') echo 'checked="checked"'; ?> />&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<span class="description">Choose the widget pane that you wish to be open when the widget is displayed.</span>
</span>