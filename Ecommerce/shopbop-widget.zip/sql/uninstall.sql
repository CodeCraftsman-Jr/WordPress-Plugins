DROP TABLE IF EXISTS `%PREFIX%shopbop_cache` ;
|
DROP TABLE IF EXISTS `%PREFIX%shopbop_category_assignments`;