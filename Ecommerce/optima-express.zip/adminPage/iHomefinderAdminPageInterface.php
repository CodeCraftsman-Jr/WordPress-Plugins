<?php

interface iHomefinderAdminPageInterface {
	
	public function getPage();
	
	public function registerSettings();
	
}