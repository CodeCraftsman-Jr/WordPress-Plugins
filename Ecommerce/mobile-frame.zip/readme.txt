=== Mobile Frame ===
Contributors: toledoroy
Tags: mobile,responsive,images,display,frame,iphone,ipad,photos,screenshot
Donate link: http://www.virtual-brick.com/project/mobile-frame/
Requires at least: 3.2.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display your images in a mobile device frame.

== Description ==
This plugin allows you to display images in a full size iPhone or iPad frame.
For long images in-frame scroll is enabled (See Demo)


= Available types = 
* iphone - iPhone 6 Black
* ipad	- iPad 1 Black

for more examples check out our website.

== Installation ==
Installation is quick and simple, no configuration necessary.
Just install, activate and use the shortcodes where you want them

To display an images in a mobile device frame. Wrap image with shortcode 
1. [mobileframe type=\"iphone\"]	[/mobileframe] to display it in an iPhone frame.
1. [mobileframe type=\"ipad\"]	[/mobileframe] to display it in an iPhone frame.

When inserting an image, or later on the edit image screen select None under "Link To" 


== Screenshots ==
1. iPad
2. iPhone

== Changelog ==

= 1.1 =
* Added More Devices

= 1.0 =
* Stable Release


