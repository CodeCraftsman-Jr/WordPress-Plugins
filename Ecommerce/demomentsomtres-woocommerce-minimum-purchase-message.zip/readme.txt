=== DeMomentSomTres Woocommerce Minimum Purchase ===
Contributors: marcqueralt
Donate link: http://demomentsomtres.com/english/wordpress-plugins/woocommerce-minimum-purchase/
Tags: woocommerce, minimum purchase
Requires at least: 3.9.1
Tested up to: 4.2.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin for woocommerce shows a message when user doesn't reach a minimum sale amount

== Description ==

This plugin for woocommerce shows a message when user doesn't reach a minimum sale amount

= Features =

* Custom message
* Custom amount
* Bootstrap ready
* Language ready

== Installation ==

This plugin can be installed as any other plugin if a few requirements are met.

== Frequently asked questions ==

TBD

== Screenshots ==

TBD

== Changelog ==
= 1.0.1 =
* Bootstrap ready

= 1.0 =
* First release

== Upgrade notice ==

If you are upgrading from versions prior to 1.0.1, you should rewrite your parameters.