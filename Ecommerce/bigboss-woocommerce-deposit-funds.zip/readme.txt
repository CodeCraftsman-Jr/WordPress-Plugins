=== Bigboss WooCommerce deposit funds ===
Contributors:bulbulbigboss
=======
Donate link: http://bigbosstheme.com/donate-us/
Tags: woo,woo funds, woocommerce deposit, WooCommerce deposit funds,deposit funds,bigboss,bigboss deposit funds, wordpress deposit funds
Requires at least: 3.5
Tested up to:4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Bigboss WooCommerce deposit  Funds is working with woo-commerce and  Allow customers or user to deposit funds into their accounts and they will able to buy using  their deposit  funds . you have to add some deposit product from woo-commerce product section and user can upload their money using this .


How To install Bigboss WooCommerce Account Funds  on your wordpress site  here you will get <a target="_blank" href="http://bigbosstheme.com/video-tutorial/">Video tutorials</a> to use this plugin

If you face any problem then contact us or see more details about bigboss <a target="_blank" href="http://bigbosstheme.com/woocommerce-deposit-funds/">woocommerce deposit</a>


== Installation ==


1.Upload Bigboss WooCommerce Account Funds   to the /wp-content/plugins/ directory


2.Activate the plugin through the 'Plugins' menu in WordPress 

3.Go to WooCommerce> Account Funds  area and customizing it as your need 

4. Add new product from woocommerce product section and make product data type deposit 


5.Go to widget area and just drug and drop My account funds widget to your sidebar 

=======




Basic Use 
Add new product from woocommerce product section and make product data type deposit 
You can add more deposit product  like $5,$10,$100 or any 


then go to apprearance  > widget >  My Account Funds>  

just drug and drop where you want to display this plugin 

select your custom post type , select number of post you want to show 

if you face any problem then please contact with me http://bigbosstheme.com/about-us



== Frequently Asked Questions ==

= A question that someone might have =

if you face any problem using Bigboss-WooCommerce-deposit-funds plugin then please ask question to me 

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

please see the http://bigbosstheme.com/our-new-plugin-on-the-air-bigboss-woocommerce-deposit-funds/ to see full screenshot 

1.

2.

3.

4.

5.

6.

=======
== Changelog ==

= 1.0 =
* A change since the previous version.
* No change yet.

= 0.5 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 0.5 =
This version fixes a security related bug.  Upgrade immediately.

== Arbitrary section ==
for more please visit http://www.bigbosstheme.com


== A brief Markdown Example ==

Ordered list:

1. <a href="http://bigbosstheme.com">online coding</a>

2. <a href="http://bigbosstheme.com">Coders at work</a>
3. <a href="http://bigbosstheme.com">Bigboss theme</a>

Unordered list:

* <a href="http://bigbosstheme.com">bigboss plugin</a>
* <a href="http://bigbosstheme.com/contact-us/">contact me</a>
* <a href="http://bigbosstheme.com/video-tutorial/">Video tutorials</a>

Here's a link to [WordPress](http://wordpress.org/ " Bigboss-WooCommerce-deposit-funds ") and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`