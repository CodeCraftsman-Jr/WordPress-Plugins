<div class="wcf_product_control">
    <label>Bokföringskonto</label>
    <p>
        <input type="text" name="_wcf_product[account]" value="<?php if(!empty($meta['account'])) echo $meta['account']; ?>"/>
        <span>Ange bokföringskonto</span>
    </p>
</div>