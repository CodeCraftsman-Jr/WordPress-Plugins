=== Plugin Name ===
Contributors: XxXYonIXxX
Donate link: http://www.scolpy.net/
Tags: woocommerce, gateway, phone order, offline payment
Requires at least: 3.3.1
Tested up to: 4.3
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html