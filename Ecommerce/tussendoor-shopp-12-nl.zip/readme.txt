=== Tussendoor Shopp 1.2.* NL / Dutch plugin ===
Contributors: Tussendoor
Tags: tussendoor, shopp, nederlands, dutch ,translate, language, vertaling
Requires at least: 3.0
Tested up to: 3.8
Stable tag: 1.3

Deze plugin biedt u de vertaling voor de Shopp 1.2.* plugin naar het Nederlands

== Description ==


= Nederlands / Dutch =
Meer informatie via: [klik hier](http://www.tussendoor.nl/wordpress-plugins/shopp-12-dutch-language-file/)
Via deze Shopp 1.2.* NL plugin beschikt u direct over de volledige vertaling van de Shopp plugin. U dient enkel de plugin te installeren, activeren en uw vertaling is compleet. De vertaling voor zowel front- als backend. 


*	**Opties / options **
Vertaling Shopp backend;
Vertaling Shopp front-end. 

Er zijn geen opties / instellingen of andere pagina's in deze plugin. Simpelweg activeren en klaar is kees.

= Custom / Maatwerk plugins =

Are you looking for custom made solutions or plugins for your WordPress site? You can always contact us via support@tussendoor.nl. Please provide us as much information as possible. You can also check our other plugins via the [Tussendoor tag](https://wordpress.org/plugins/tags/tussendoor) or via our [profile page](https://profiles.wordpress.org/tussendoor/) here at WordPress. 

Some of our premium plugins can be found at [Codecanyon](http://codecanyon.net/user/Tussendoor/portfolio) or our [own website](http://www.tussendoor.nl/wordpress-plugins/).

= Nederlands =
Ben je op zoek naar maatwerk oplossingen of pugins voor je WordPress website? Dan kun je altijd contact met ons opnemen via support@tussendoor.nl. Verschaf aub zo veel mogelijk  informatie bij je aanvraag. Je kunt ook een kijkje nemen bij onze andere plugins via de [Tussendoor tag](https://wordpress.org/plugins/tags/tussendoor) of op ons [profiel hier op WordPress](https://profiles.wordpress.org/tussendoor/).

Een aantal premium plugins zijn te vinden op [onze eigen website](http://www.tussendoor.nl/wordpress-plugins/) en op [Codecanyon](http://codecanyon.net/user/Tussendoor/portfolio).

== Installation ==

= Nederlands / Dutch =
Het installeren van de Shopp 1.2.*  vertaling is net zo eenvoudig als alle andere plugin. Plaats de inhoud in de plugin map (wp-content/plugins), activeer de plugin en je bent klaar. Er zijn geen opties of instellingen nodig.
Voor meer informatie / screenshots kun je bij de volgende tab kijken.

== Screenshots ==

1. Setup pagina in het engels
2. Setup pagina in het Nederlands (na activeren plugin)
3. Product toevoegen in het Engels
4. Product toevoegen in het Nederlands (na activeren plugin)

== Changelog ==

= todo =
*	Upadate / toevoegen nieuwe woorden / zinnen bij update Shopp

= 1.3 = 
*	Updated translation files, thanks to Erik de Vries ([wpwebbouw.nl](wpwebbouw.nl)) for translating!

= 1.0 =
*	Initial release


== Translations ==

* 	nl_NL 

== Links == 
*	 Will follow
