tinyMCE.addI18n({en_US:{
simpleTruliaStats:{	
desc : 'Insert Trulia Graph'
}}});