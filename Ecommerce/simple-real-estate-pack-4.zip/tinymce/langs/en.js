tinyMCE.addI18n({en:{
simpleTruliaStats:{	
desc : 'Insert Trulia Graph'
}}});
