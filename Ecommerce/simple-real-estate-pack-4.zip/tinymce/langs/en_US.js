tinyMCE.addI18n({en_US:{
tsimpleTruliaStats:{	
desc : 'Insert Trulia Graph'
}}});