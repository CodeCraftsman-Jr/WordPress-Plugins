<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="<?php echo admin_url(); ?>/css/install.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo SHOPP_ADMIN_URI; ?>/styles/admin.css" type="text/css" />
	</head>
	<body id="error-page" class="shopp-update">
	<?php echo $response; ?>
	</body>
</html>