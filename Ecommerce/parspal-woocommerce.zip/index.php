<?php
/*
Plugin Name: درگاه پرداخت پارس پال افزونه ووکامرس
Version: 4.0.2
Description:  درگاه پرداخت پارس پال برای افزونه ووکامرس
Plugin URI: http://woocommerce.ir/
Author: ووکامرس فارسی
Author URI: http://woocommerce.ir/
*/
include_once("class-wc-gateway-parspal.php");
//By HANNANStd in PersianScript.ir ==> woocommerce.ir