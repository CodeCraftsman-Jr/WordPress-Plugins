From: %from_name% (%from_email%)
IP: %user_ip%
User Agent: %user_agent%

------------------------------

%message%

------------------------------


---
Sent from %site_name%
%site_url%