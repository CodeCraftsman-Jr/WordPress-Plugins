Hi %username%,

Your withdraw request has been approved, congrats!

You sent a withdraw request of:

Amount: %amount%
Method: %method%

We'll transfer this amount to your preferred destination shortly.

Thanks for being with us.

---
%site_name%
%site_url%