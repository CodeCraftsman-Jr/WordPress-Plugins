Hello there,

A new seller has been registered to your site (%site_url%).

Seller Details:
------------------------

Seller: %seller_name%
Seller Store: %store_url%

To edit seller access and details visit - %seller_edit%

---
%site_name%
%site_url%