=== Woocommerce Mellat Bank Gateway ===
author: ووکامرس فارسی
Contributors: Persianscript, hannanstd
author URI: http://www.woocommerce.ir/
Donate link: http://www.woocommerce.ir/donate.html
plugin URI: http://www.woocommerce.ir/plugins.html
Tags: woocommerce, commerce, e-commerce, commerce, shop, virtual shop, mellat bank, mellat, iran, persian, farsi,woocommerce persian, e-commerce, ووکامرس, ووکامرس فارسی,mellat woocommerce,بانک ملت,درگاه پرداخت,payment gateway,mellat,woocommerce payment
Requires at least: 4.0
Tested up to: 4.2

پرداخت اینترنتی وجه به وسیله درگاه پرداخت بانک ملت

== Description ==
**Woocommerce Mellat Bank Gateway** این افزونه شما را قادر می سازد تا براحتی اقدام به ایجاد درگاه پرداخت اینترنتی بانک ملت برای پرداخت های محصولات ووکامرس کنید

= امکانات =
 * سازگار با ووکامرس 2.2.x و 2.3.x
 * پنل تنظیمات ساده و کاربرپسند
 * تنظیم پیام دلخواه در هنگام پرداخت موفقیت آمیز ، انصراف از پرداخت و یا لغو پرداخت
 * قابلیت نمایش کد رهگیری و شماره ارجاع بانک ملت همراه با کد میانبر
 * نمایش خطاهای درگاه پرداخت
 * قابلیت پرداخت بر اساس واحد پولی ریال و یا تومان و یا هزار تومان و ...
 
= نیازمندی ها و افزونه های پیشنهادی دیگر =
*  [بسته فارسی ساز ووکامرس](https://wordpress.org/plugins/persian-woocommerce/)
*  [افزونه ارسال پیامک در ووکامرس](https://wordpress.org/plugins/persian-woocommerce-sms/)

= پشتیبانی =
*  [پشتیبانی در ووکامرس فارسی](http://woocommerce.ir/)

== Installation ==
1. پوشه `mellat-woocommerce` را در مسیر `/wp-content/plugins/` آپلود کنید
2. افزونه را از طریق منوی 'افزونه ها' در وردپرس فعال کنید
3. تنظیمات افزونه را می توانید از طریق قسمت تنظیمات ووکامرس / تسویه حساب انجام دهید

== Frequently asked questions ==

= Where can I find more information and documentation about the plug-in? =

You can read complete documentations on the [woocommerce.ir](http://www.woocommerce.ir)


== Screenshots ==
1. Settings page
2. payment page

== Changelog ==
= 4.0.1 =
* سازگاری با واحد پولی هزار تومان و تعریف فیلتر برای واحد های پولی آینده
= 4.0.0 =
* بازنویسی مجدد افزونه و سازگاری با ووکامرس 2.3.x


== Upgrade Notice ==
= 4.0.1 =
* سازگاری با واحد پولی هزار تومان و تعریف فیلتر برای واحد های پولی آینده
= 4.0.0 =
* پس از بروزرسانی ، تنظیمات درگاه را مجددا انجام دهید


== Traducciones ==
You can read complete documentations on the [woocommerce.ir](http://www.woocommerce.ir)
