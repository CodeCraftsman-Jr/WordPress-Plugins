=== MarketPress Australia Post ===
Contributors: Corlax Technologies
Tags:  eCommerce, Plugins, WordPress
Requires at least: 3.9
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The extension help you to ship products in and around Australia. Plugin get shipping rates from Australia Post�s Shipping API Automatically.

Support following services:-
*AUS PARCEL REGULAR
*PARCEL POST PLUS 500G SATCHEL
*AUS PARCEL REGULAR SATCHEL 3KG
*AUS PARCEL REGULAR SATCHEL 5KG
*AUS PARCEL EXPRESS
*AUS PARCEL EXPRESS SATCHEL 500G
*AUS PARCEL EXPRESS SATCHEL 3KG
*AUS PARCEL EXPRESS SATCHEL 5KG
*AUS PARCEL COURIER
*AUS PARCEL COURIER SATCHEL MEDIUM
*AUS PARCEL PLATINUM
==Installation==
1. Download the plugin  file
2. Unzip the file to /wp-content/plugins/ folder on your site
3. Activate it through admin.