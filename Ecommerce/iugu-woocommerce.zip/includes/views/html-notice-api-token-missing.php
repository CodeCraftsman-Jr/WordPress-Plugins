<?php
/**
 * Admin View: Notice - API Token missing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="error">
	<p><strong><?php _e( 'Iugu Disabled', 'iugu-woocommerce' ); ?></strong>: <?php _e( 'You should inform your Account ID.', 'iugu-woocommerce' ); ?>
	</p>
</div>
