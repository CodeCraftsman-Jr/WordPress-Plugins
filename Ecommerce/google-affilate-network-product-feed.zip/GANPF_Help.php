<div class="wrap"><div id="icon-ganpf-help" class="icon32"><br />
</div><h2><?php _e('Help Using the Google Affiliate Network Product Feed Plugin','gan'); ?><?php $this->InsertVersion(); ?></h2>
<?php $this->PluginSponsor(); ?>
<ul>
<li><a href="#Introduction">Introduction</a></li>
<li><a href="#SupportGAN">Ways to support the Google Affiliate Network Product Feed Plugin</a></li>
</ul>
<a name="Introduction"></a><h3>Introduction</h3>  
<a name="SupportGAN"></a><h3>Ways to support the Google Affiliate Network Product Feed Plugin</h3>
<div id="gan_donateHelp"><form action="https://www.paypal.com/cgi-bin/webscr" method="post"><?php _e('Donate to Google Affiliate Network plugin software effort.','gan'); ?><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="B34MW48SVGBYE"><input type="image" src="https://www.paypalobjects.com/WEBSCR-640-20110401-1/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"><img alt="" border="0" src="https://www.paypalobjects.com/WEBSCR-640-20110401-1/en_US/i/scr/pixel.gif" width="1" height="1"></form></div><br clear="all" />
<div id="gan_donateHelp">Buy some Deepwoods Software <a href="http://www.deepsoft.com/home/products/dwsmerch/" target="_blank">merchandise</a></div><br clear="all" />
</div>

