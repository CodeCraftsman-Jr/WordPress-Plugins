=== Google Affiliate Network Product Feed ===
Contributors: RobertPHeller
Donate link: http://www.deepsoft.com/GAN-Products
Tags: gan,affiliate,google,plugin,products
Requires at least: 3.0
Tested up to: 3.3
Stable tag: 0.0

A plugin to import GAN Product Feeds into a ShopperPress or WordPress blog.

== Description ==

This plugin imports GAN Product Feeds as product posts into either a 
ShopperPress or conventual WordPress blog.  It is highly experimental. The 
code works, but it is not considered a fully functional and supported plugin
at this time.  Use at your own risk.

== Installation ==

Unpack the plugin archive under the wp-content/plugins directory and
then activate the plugin.

== Frequently Asked Questions ==

Support is handled either with [Deepwoods Software's
Bugzilla][bugreport] (submit any bugs and feature requests to the
Bugzilla) or though the [Deepwoods Software's Support page][support]
(use this for  comments or for general questions).

= Something does not work. What should I do? =

Submit a bug at [Deepwoods Software's Bugzilla][bugreport].

= I have another question that is not listed here. What should I do? =

Submit one on [Deepwoods Software's Support page][support]. You can also submit
a documentation bug at [Deepwoods Software's Bugzilla][bugreport] as well.

[bugreport]: http://bugzilla.deepsoft.com/enter_bug.cgi?product=Google%20Affiliate%20Network%20Product%20Feed "Deepwoods Software Bugzilla"
[support]: http://www.deepsoft.com/support/ "Deepwoods Software's Support page"

== Changelog ==

= 0.0 =
* Initial release.

== Upgrade Notice ==

= 0.0 =
Initial release.


