=== DC - Easy Wordpress Paypal Payment/ Donations Plugin ===
Contributors: dattardwp-21
Donate link: http://http://www.dart-creations.com/joomla-25-and-joomla-3-modules/75-donate-a-beer
Tags: paypal, payment, donate
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This Wordpress plugin makes it very easy to accept payments online on your Wordpress website. Our highly customizable plugin / shortcode enables you to accept Paypal Donations and Payments quickly and easily with no programming knowledge. You can also use it to accept payments online using Paypal as your online payment gateway. 

== Description ==

This is a Paypal Wordpress plugin provided by [DART Creations](http://www.dart-creations.com/ "Your favorite Wordpress plugins")

The plugin offers the following features:

* Allows you to decide whether to display a Paypal logo Image or your own text 
* Customizable Paypal email
* Paypal Name of Organization to send money to
* User selectable Currency for Payment (if you want to)
* Choose whether to enable timed payments or subscriptions, and choose the frequency of the timed payment (Weekly, Monthly, Annually)
* Fixed value or user entered monetary value, with smallest amount of payment possible
* Choice of default currency
* Choice of text for Submit button e.g. Donate, Pay Now etc.
* Return address (URL) when payment is complete
* Cancel address (URL) in case payment is cancelled.
* Locale


== Installation ==

To install the module, simple go to (Plugins > Add New> Upload Plugin), choose the file you have downloaded above and click on the upload and install button. Use it by clicking on the Paypal logo in the post visual editor to enter the shortcode

== Frequently Asked Questions ==

= Do you have any FAQs? =

Not yet - we will populate them as we go.


== Screenshots ==

1. screenshot-1.png
1. screenshot-2.png

== Changelog ==

= 1.0 =
* Released first version


