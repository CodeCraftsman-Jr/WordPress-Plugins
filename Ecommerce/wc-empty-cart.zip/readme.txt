===Woocommerce Empty Cart===
Contributors: (iwcontribution)
Tags: Woocommerce, Empty Cart, Woocommerce Extension
Requires at least: 3.1.2
Tested up to: 4.2.2
Empty Cart allows cart to be empty.

== Description ==
This is Woocommerce Empty Cart extension which helps to make cart empty.

== Installation ==
1. To run this extension make sure that you have installed woocommerce plugin and activate it.
2. Download the Empty cart plugin zip file and extract to the  `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress Admin.

== Screenshots ==
1. WooCommerce Backend Settings "General" page.
2. This is Front-End Empty Cart Page. By Clicking on that you can clean your cart.

= 1.0 =
The First Release

