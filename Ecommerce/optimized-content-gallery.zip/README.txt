=== Optimized Content Gallery ===
Plugin Author: alxconn
Contributors: iePlexus, alxconn, bdicicco
Donate link: No Thanks
Tags: images, gallery, slideshow, photos, page, post, featured, plugin
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 0.2

Clone of iePlexus' brilliant Featured Content Gallery optimized for Wordpress 3.0 and for performance.

== Description ==

Optimized Content Gallery is a fork of iePlexus' brilliant Featured Content Gallery that has been optimized for Wordpress 3.0 for performance and ease of use.

== Installation ==

TODO

== Frequently Asked Questions ==

TODO

== Screenshots ==

TODO

== Usage ==

TODO