
--
-- Remove tables query for `%%WP_PREFIX%%example_plugin`
--

DROP TABLE IF EXISTS `%%WP_PREFIX%%example_plugin`;