=== StubWire.com Event Manager ===
Contributors: redbrad0
Donate link: 
Tags: event, events, ticket, tickets, ticketing, attend, attendee, attending, attendance, ticketing, event ticketing, theatre
Requires at least: 3.3
Tested up to: 3.5
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Manage and sell tickets to any event directly on your website.

== Description ==

Allows you to list out all your events from StubWire.com by placing a small shortcode on the page to display the content. You will then be able to edit the templates to display as much, or as little information about each event you have scheduled. A Buy Now button will be placed on your site with a tracking code so you know exactly where your visitors came from inside your [StubWire.com](http://www.stubwire.com/) Reporting Features.

== Installation ==

1. Upload the entire `stubwire` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Login with your StubWire.com account in the Plugin Settings. If you need any help please contact our venue/promoter hotline at 877-970-7882.