=== SB Hotel Rooms ===
Contributors: mrumengan
Donate link: http://sitebridge.net/donate/
Tags: hotel, rooms, hotel rooms
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin to manage your hotel (or villas) rooms

== Description ==

This plugin help you manage you hotel rooms in the most simplest way. You can just use the rooms or you can add room's category with a simple click on the settings section.
It will only use your standard wordpress tables to store the rooms data.

== Installation ==

1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

1. Can I group or categorize my rooms?
Yes you can, go to settings > rooms options and check the "With Room Types & Facilities"

== Screenshots ==

1. http://sitebridge.net/wp-content/uploads/2012/10/screenshot1.png
2. http://sitebridge.net/wp-content/uploads/2012/10/screenshot2.png

== Changelog ==
1.0.0
- First full version release summary:
	- Rooms custom post type
	- Room detail & price
	- Room Types*
	- Room Pictures
	- jQuery Lightbox for Room Pictures gallery*
	- Plugin doesn't print out any stylesheet, except in jQuery Lightbox
	
* Can be swithced on/off from Settings > Room Options 

0.2r1.1r1
- Fixed bug fail to add pictures to content instead added to room's pictures 

0.2.1r1
- Fixed bug in showing room's pictures, if none added shows error in front end

0.2.1
- Added room pictures management
- Pictures showed in frontend as plain html, no css / style attached

0.1.1
- Added room detail on Room view

0.1
- First release, but usable
- Lot of features will be added weekly

== Upgrade notice ==




== Plans ==

This plugin will be the based plugin for more plugins to come, supporting or extending this