{\rtf1\ansi\ansicpg1252\cocoartf1331\cocoasubrtf120
{\fonttbl\f0\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww18900\viewh11540\viewkind0
\deftab720
\pard\pardeftab720

\f0\fs24 \cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 === Plugin Name ===\
Contributors: InvoicesOnline\
Donate link: http://www.invoicesonline.co.za/\
Tags: woocommerce, invoicing, invoicesonline\
Requires at least: 3.0.1\
Tested up to: 4.0\
Stable tag: 4.0\
\
Provides integration between www.invoicesonline.co.za and the woocommerce wordpress plugin. \
\
== Description ==\
\
Provides integration between www.invoicesonline.co.za and the woocommerce wordpress plugin. This plugin allows invoices, pro-forma invoices and clients to be created on invoicesonline inside of wordpress. It provides full integration of the invoicesonline system for use with woocommerce.\
\
== Installation ==\
\
1. Upload `woo-io` folder to the `/wp-content/plugins/` directory\
2. Activate the plugin through the 'Plugins' menu in WordPress\
3. Get your APi Access codes from invoicesonline.co.za and anter them into the Invoices Onlines Settings screen.\
4. Save and your ready to go.}