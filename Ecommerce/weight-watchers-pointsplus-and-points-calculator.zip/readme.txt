=== Weight Watchers Points & PointsPlus Calculator ===
Contributors: figaronymous
Donate link: http://www.zekemoore.com
Tags: calculators,widgets,nutrition,diet,weight-watchers,food,health
Requires at least: 2.0.0
Tested up to: 3.0
Stable tag: trunk

Sidebar widget that calculates Weight Watchers Points or PointsPlus values.

== Description ==

Sidebar widget that calculates Weight Watchers Points or PointsPlus values.  The user inputs a food's protein, carb, fat, and fiber content to obtain the food's PointsPlus value.  The user may also choose to use Weight Watchers' older Points algorithm by inputting a food's calorie, fat, and fiber content to obtain the food's Points value.

== Installation ==

1. Upload all files to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Visit your Widgets management area and drag the widget to the desired location.

== Frequently Asked Questions ==

= Questions here? =

Answers here.

== Screenshots ==

== Changelog ==
