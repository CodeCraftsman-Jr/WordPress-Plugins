=== Plugin Name ===
Contributors: enzolarosa
Tags: ecommerce,catalog,page,catalog page,list,service,prodoct,catalogo,servizi,elenco
Requires at least: 3.0
Tested up to: 3.3.2
Stable tag: 1.1.2.2

Crea facilmente la pagina per il tuo catalogo di prodotti e di servizi nel tuo sito.

== Description ==

Grazie all'uso di questo plugin potrai creare aggiungendo un semplice short code all'interno della tua pagina, 
un catalogo con la lista dei prodotti e dei servizi che offri.

Se hai dei suggerimenti per il plugin <a href="http://www.vincenzolarosa.it/1656-catalog-page.html" target="_blank">lascia un commento su questa pagina</a>.

La demo del plugin la trovi su questa pagina <a href="http://www.vincenzolarosa.it/demo-catalog-page" target="_blank">Catalog Page Demo</a>


== Installation ==

Scarica l'archivio, ed estrai il file, e successivamente

1. Carica il file catalog_page.php nella cartella `/wp-content/plugins/` del tuo sito
1. Attiva il plugin della pagina 'Plugins' la trovi nel menu di WordPress
1. Aggiungi lo short code [catalog_page] nella pagina dove vuoi compaia il catalogo


== Screenshots ==

1. Setting Page.
1. Front End Page. La demo del plugin la trovi su questa pagina <a href="http://www.vincenzolarosa.it/servizi-prodotti" target="_blank">Catalog Page Demo</a>.
1. Barra di navigazione tra i servizi.

== Changelog ==

= 1.1.2.2 =
1. Corretto bug riguardante il titolo del servizio

= 1.1.2 =
1. Aggiunta la possibilit� di cambiare lo stile alla barra di navigazione 

= 1.1 =
1. Aggiunta barra di navigazione per i servizi

= 1.0.4 =
1. Corretto il bug (like button e send button)
1. Aggiunta immagine per i dettagli
1. Possibilit� di cambiare le dimensioni dell'imagine in evidenza

= 1.0.3 =
1. Aggiunta pagina delle opzioni