<?php

define('DC_CHECKOUT_TERMS_CONDITIONS_POPUP_PLUGIN_TOKEN', 'dc-checkout-terms-conditions-popup');

define('DC_CHECKOUT_TERMS_CONDITIONS_POPUP_TEXT_DOMAIN', 'checkout_terms_conditions_popup');

define('DC_CHECKOUT_TERMS_CONDITIONS_POPUP_PLUGIN_VERSION', '1.0.0');
?>