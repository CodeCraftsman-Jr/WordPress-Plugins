# edd-continue-shopping
Adds a Continue Shopping link to the Easy Digital Downloads checkout cart.
