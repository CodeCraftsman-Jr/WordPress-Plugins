<?php
/**
 * Helper Functions
 *
 * @package     EDD\PluginName\Functions
 * @since       1.0.0
 */


// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;



