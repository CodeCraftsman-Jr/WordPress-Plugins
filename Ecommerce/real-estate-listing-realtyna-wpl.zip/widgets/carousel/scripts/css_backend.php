<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.wpl_carousel_widget_backend_form{margin: 10px 0;}
.wpl_carousel_widget_backend_form input[type='text']{width: 100%;}
.wpl_carousel_widget_backend_form select{width: 100%;}
.wpl_carousel_widget_backend_form > div{padding-bottom:15px;}
.wpl_carousel_widget_backend_form label{display: block;padding-bottom: 5px;font-size:11px;font-weight:bold;}
.wpl_carousel_widget_backend_form > h4{color:#1e8cbe;font-size:1.2em;margin: 15px 0 5px;padding-bottom: 10px;}
.wpl-carousel-opt input[type=checkbox]{vertical-align: text-bottom;display: inline-block;margin: 0 5px 0 0;}
.wpl_carousel_widget_backend_form input[type=checkbox] + label{vertical-align:top;display:inline-block;}
.wpl-carousel-widget-layout{text-transform: capitalize;}
</style>