ALTER TABLE `#__wpl_properties` CHANGE `mls_id` `mls_id` VARCHAR( 30 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;
INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(99, 'style', 'Googlefont', 0, '', 1, 'wpl-google-font', 'http://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic|Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700|Scada:400italic,700italic,400,700|Archivo+Narrow:400,40', '', '', '1', '', 0, 35.00, 2);

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(31, 'shortcode', 'my profile shortcode', 0, 'it used for showing my profile', 1, 'wpl_my_profile', 'wpl_html->load_profile_wizard', '', '', '', '', 0, 99.99, 2);

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(34, 'shortcode', 'Profile show shortcode', 0, 'it used for showing a profile', 1, 'wpl_profile_show', 'wpl_controller->f:profile_show:display', '', '', '', '', 0, 99.99, 2);

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(32, 'shortcode', 'Add/Edit listing shortcode', 0, 'it used for showing Add/Edit listing view', 1, 'wpl_add_edit_listing', 'wpl_html->load_add_edit_listing', '', '', '', '', 0, 99.99, 2),
(33, 'shortcode', 'Listing Manager shortcode', 0, 'it used for showing Listing Manager', 1, 'wpl_listing_manager', 'wpl_html->load_listing_manager', '', '', '', '', 0, 99.99, 2);

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(20, 'widget', 'WPL Agents Widget', 0, '', 1, 'widgets.agents.main', 'widgets_init', 'WPL_agents_widget', '', '', '', 0, 99.99, 2);

INSERT INTO `#__wpl_cronjobs` (`id`, `cronjob_name`, `period`, `class_location`, `class_name`, `function_name`, `params`, `enabled`, `latest_run`) VALUES
(3, 'Check All Updates', 24, 'global', 'wpl_global', 'check_all_update', '', 1, '2014-04-05 13:19:29');

UPDATE `#__wpl_cronjobs` SET `cronjob_name`='Remove Expired tmp Directories' WHERE `id`='2';

UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='8';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='13';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='14';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(21, 'sidebar', 'Property Show Bottom', 0, 'Appears on bottom of single property/property show page', 1, 'wpl-pshow-bottom', '', '', '', '', '', 0, 99.99, 2),
(22, 'sidebar', 'Profile Show Top', 0, 'Appears on top of agent show/profile show page', 1, 'wpl-profileshow-top', '', '', '', '', '', 0, 99.99, 2);

UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='2';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='3';

ALTER TABLE `#__wpl_activities` ADD `association_type` TINYINT( 4 ) NOT NULL DEFAULT '1', ADD `associations` TEXT NULL;

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(50, 'backend_listing_target_page', NULL, 1, 4, 'wppages', 'Backend Listing Target', '{"tooltip":"Used for backend views"}', '{"show_empty":1} ', 99.00);

ALTER TABLE `#__wpl_users` ADD `access_change_user` TINYINT( 4 ) NOT NULL DEFAULT '0' AFTER `access_public_profile`;

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(36, 'realtyna_username', NULL, 0, 1, 'text', '', '', '', 99.00),
(37, 'realtyna_password', NULL, 0, 1, 'text', '', '', '', 99.00),
(38, 'realtyna_verified', '0', 0, 1, 'text', '', '', '', 99.00);

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(105, 'javascript', 'AjaxFileUpload', 0, '', 1, 'ajaxFileUpload', 'js/libs/bower_components/ajaxfileupload.min.js', '', '', '', '', 0, 100.00, 2),
(104, 'javascript', 'HoverIntent', 0, '', 1, 'hoverIntent', 'js/libs/bower_components/hoverintent/jquery.hoverIntent.js', '', '', '', '', 0, 100.00, 1),
(103, 'javascript', 'Transit', 0, '', 1, 'transit', 'js/libs/bower_components/transit/jquery.transit.min.js', '', '', '', '', 0, 100.00, 1),
(102, 'javascript', 'customScrollBarJS', 0, '', 1, 'customScrollBarJS', 'js/libs/bower_components/malihu-custom-scrollbar-plugin-bower/jquery.mCustomScrollbar.concat.min.js', '', '', '', '', 0, 100.00, 1),
(101, 'javascript', 'Chosen', 0, '', 1, 'ChosenJS', 'js/libs/bower_components/chosen/public/chosen.jquery.min.js', '', '', '', '', 0, 100.00, 1);

DELETE FROM `#__wpl_extensions` WHERE `id`='93';
DELETE FROM `#__wpl_extensions` WHERE `id`='95';

UPDATE `#__wpl_activities` SET `activity`='agent_info:profileshow' WHERE `id`='12';

UPDATE `#__wpl_activities` SET `association_type`='1';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='98';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='102';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='89';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='101';

INSERT INTO `#__wpl_units` (`id`, `name`, `type`, `enabled`, `tosi`, `index`, `extra`, `extra2`, `extra3`, `extra4`, `seperator`, `d_seperator`, `after_before`) VALUES
(7, 'Hectare', 2, 0, 10000, 7, '', '', '', '', '', '', 0);

ALTER TABLE `#__wpl_settings` CHANGE `setting_value` `setting_value` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;

INSERT INTO `#__wpl_dbst` (`id`, `kind`, `mandatory`, `name`, `type`, `options`, `enabled`, `pshow`, `plisting`, `searchmod`, `editable`, `deletable`, `index`, `css`, `style`, `specificable`, `listing_specific`, `property_type_specific`, `table_name`, `table_column`, `category`, `rankable`, `rank_point`, `comments`, `pwizard`, `text_search`, `params`) VALUES
(313, 0, 3, 'Property Title', 'text', 'null', 1, '0', 1, 0, 1, 0, 1.00, '', '', 1, '', '', 'wpl_properties', 'field_313', 1, 0, 0, '', '1', 0, '[]');

ALTER TABLE `#__wpl_properties` ADD `field_313` VARCHAR( 50 ) NULL AFTER `field_312`;
UPDATE `#__wpl_dbcat` SET `listing_specific`='' WHERE `id`='7';

INSERT INTO `#__wpl_dbst_types` (`id`, `kind`, `type`, `enabled`, `index`, `queries_add`, `queries_delete`) VALUES
(14, '[0][1]', 'url', 1, 1.00, 'ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` varchar(50) NULL; UPDATE #__wpl_dbst SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];', 'ALTER TABLE `#__[TABLE_NAME]`\r\nDROP `field_[FIELD_ID]`;');

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(24, 'sidebar', 'Property Listing Top', 0, 'Appears below of Google map in property listing page', 1, 'wpl-plisting-top', '', '', '', '', '', 0, 99.99, 2);

UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='1';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='2';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='3';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='5';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='6';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='11';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='12';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='13';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='14';

UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='903';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='900';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='901';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='902';
UPDATE `#__wpl_dbst` SET `editable`='1', `deletable`='1' WHERE `id`='904';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='905';
UPDATE `#__wpl_dbst` SET `editable`='1', `deletable`='1' WHERE `id`='907';
UPDATE `#__wpl_dbst` SET `editable`='1', `deletable`='1' WHERE `id`='908';
UPDATE `#__wpl_dbst` SET `editable`='1', `deletable`='1' WHERE `id`='909';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='914';

UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='400';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='401';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='402';
UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='403';

UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='4';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='5';

ALTER TABLE `#__wpl_extensions` CHANGE `param2` `param2` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL;
UPDATE `#__wpl_extensions` SET `param2`='http://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic|Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700|Scada:400italic,700italic,400,700|Archivo+Narrow:400,40|Lato:400,700,900,400italic|BenchNine' WHERE `id`='99';

UPDATE `#__wpl_dbst` SET `index`='3.50' WHERE `id`='171';
UPDATE `#__wpl_dbst` SET `text_search`='1' WHERE `id`='308';

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(51, 'log', '0', 1, 1, 'select', 'WPL log', NULL, '{"values":[{"key":0,"value":"Disabled" },{"key":1,"value":"Enabled"}]}', 120.00);

UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='51';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='52';

INSERT INTO `#__wpl_extensions` (`id`,`type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(108, 'javascript', 'Modernizr', 0, '', '', 'modernizer', 'js/modernizr.custom.js', '', '', '1', '', 0, 99.99, 0);

UPDATE `#__wpl_extensions` SET `param5`='' WHERE `id`='108';
UPDATE `#__wpl_extensions` SET `enabled`='1' WHERE `id`='108';

UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='10';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='11';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='9';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='8';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `n_[FIELD_ID]` tinyint(4) NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `n_[FIELD_ID]_distance` int NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `n_[FIELD_ID]_distance_by` tinyint(4) NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''n_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='7';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` text NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='5';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` int(11) NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='3';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `f_[FIELD_ID]_options` text NULL; ALTER TABLE `#__[TABLE_NAME]` ADD `f_[FIELD_ID]` tinyint(4) NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''f_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='4';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` varchar(50) NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='1';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` float NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='2';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` date NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='12';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` datetime NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='13';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` varchar(50) NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='14';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='18';

CREATE TABLE IF NOT EXISTS `#__wpl_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `additional_memberships` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `additional_users` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `additional_emails` text COLLATE utf8_unicode_ci,
  `options` text COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;

INSERT INTO `#__wpl_menus` (`id`, `client`, `type`, `parent`, `page_title`, `menu_title`, `capability`, `menu_slug`, `function`, `separator`, `enabled`, `index`, `position`, `dashboard`) VALUES
(13, 'backend', 'submenu', 'WPL_main_menu', 'Notifications', 'Notifications', 'admin', 'wpl_admin_notifications', 'b:notifications:home', 0, 1, 2.05, 0, 0);

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(109, 'javascript', 'Handlebars', 0, '', 1, 'handlebars', 'js/handlebars.js', '', '', '', '', 0, 109.99, 0);

INSERT INTO `#__wpl_setting_categories` (`id`, `name`, `showable`, `index`) VALUES (5, 'Notifications', 1, 99.00);

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(53, 'wpl_sender_email', '', 1, 5, 'text', 'Sender email', NULL, '', 121.00),
(54, 'wpl_sender_name', '', 1, 5, 'text', 'Sender name', NULL, '', 122.00);

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(55, 'property_location_pattern', '[street_no] [street][glue] [location4_name][glue] [location3_name][glue] [location2_name][glue] [location1_name] [zip_name]', 1, 3, 'text', 'Property Location Pattern', NULL, '', 123.00),
(56, 'user_location_pattern', '[location5_name][glue][location4_name][glue][location3_name][glue][location2_name][glue][location1_name] [zip_name]', 1, 3, 'text', 'User Location Pattern', NULL, '', 124.00);

UPDATE `#__wpl_extensions` SET `param2`='https://maps.google.com/maps/api/js?libraries=places&sensor=true' WHERE `id`='94';
UPDATE `#__wpl_settings` SET `type`='wppages' WHERE `id`='25';

UPDATE `#__wpl_extensions` SET `param2`='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic|Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700|Scada:400italic,700italic,400,700|Archivo+Narrow:400,40|Lato:400,700,900,400italic|BenchNine' WHERE `id`='99';

INSERT INTO `#__wpl_events` (`id`, `type`, `trigger`, `class_location`, `class_name`, `function_name`, `params`, `enabled`) VALUES
(4, 'notification', 'contact_agent', 'libraries.event_handlers.notifications', 'wpl_events_notifications', 'contact_agent', '', 1);

INSERT INTO `#__wpl_notifications` (`id`, `description`, `template`, `subject`, `additional_memberships`, `additional_users`, `additional_emails`, `options`, `params`, `enabled`) VALUES
(2, 'Contact to listing agent from listing page', 'contact_agent', 'New Contact', '', '', '', NULL, '', 1);

INSERT INTO `#__wpl_activities` (`id`, `activity`, `position`, `enabled`, `index`, `params`, `show_title`, `title`, `association_type`, `associations`) VALUES
(23, 'listing_contact', 'pshow_position2', 1, 99.00, '', 1, 'Contact Agent', 1, '');

UPDATE `#__wpl_dbst` SET `table_column`='locations' WHERE `id`='41';
UPDATE `#__wpl_dbst` SET `table_column`='locations' WHERE `id`='911';
UPDATE `#__wpl_dbst` SET `options`='' WHERE `id`='6';

ALTER TABLE `#__wpl_item_categories` DROP `parent_kind`;
DROP TABLE `#__wpl_notices`;

UPDATE `#__wpl_dbst` SET `text_search`='1' WHERE `id`='312';
UPDATE `#__wpl_dbst` SET `text_search`='1' WHERE `id`='313';

CREATE TABLE IF NOT EXISTS `#__wpl_kinds` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `table` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `#__wpl_kinds` (`id`, `name`, `table`) VALUES
(0, 'Property', 'wpl_properties'),
(2, 'User', 'wpl_users');

UPDATE `#__wpl_settings` SET `index`='50.00' WHERE `id`='50';
UPDATE `#__wpl_settings` SET `title`='Property Pattern' WHERE `id`='55';
UPDATE `#__wpl_settings` SET `title`='User Pattern' WHERE `id`='56';

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(65, 'location_separator3', '', 1, 3, 'separator', 'Location Method', '', '', 4.50),
(63, 'location_separator1', '', 1, 3, 'separator', 'Location Keywords', '', '', 98.00),
(64, 'location_separator2', '', 1, 3, 'separator', 'Location Patterns', '', '', 122.00);

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(66, 'permalink_separator', '', 1, 4, 'separator', 'WPL Permalink', '', '', 0.90);

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(67, 'sender_separator', NULL, 1, 5, 'separator', 'Notification Sender', NULL, NULL, 120.50);

DELETE FROM `#__wpl_settings` WHERE `id`='3';

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(68, 'resize_separator', NULL, 1, 2, 'separator', 'Resize', NULL, NULL, 1.50),
(69, 'watermark_separator', NULL, 1, 2, 'separator', 'Watermark', NULL, NULL, 4.50);

UPDATE `#__wpl_settings` SET `index`='109.00' WHERE `id`='31';
UPDATE `#__wpl_settings` SET `index`='51.00' WHERE `id`='22';
UPDATE `#__wpl_settings` SET `index`='52.00' WHERE `id`='27';
UPDATE `#__wpl_settings` SET `index`='53.00' WHERE `id`='51';

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(70, 'global_separator', NULL, 1, 1, 'separator', 'Global', NULL, NULL, 0.05),
(71, 'listing_pages_separator', NULL, 1, 1, 'separator', 'Listings', NULL, NULL, 98.00),
(72, 'users_separator', NULL, 1, 1, 'separator', 'Users', NULL, NULL, 107.00),
(73, 'io_separator', NULL, 1, 1, 'separator', 'I/O Application', NULL, NULL, 116.00);

INSERT INTO `#__wpl_activities` (`id`, `activity`, `position`, `enabled`, `index`, `params`, `show_title`, `title`, `association_type`, `associations`) VALUES
(24, 'user_contact', 'profile_show_position1', 0, 99.00, '{"top_comment":""}', 1, 'Contact', 1, '');

INSERT INTO `#__wpl_notifications` (`id`, `description`, `template`, `subject`, `additional_memberships`, `additional_users`, `additional_emails`, `options`, `params`, `enabled`) VALUES
(3, 'Contact to agent from profile page', 'contact_profile', 'New Profile Contact', '', '', '', NULL, '', 1);

INSERT INTO `#__wpl_events` (`id`, `type`, `trigger`, `class_location`, `class_name`, `function_name`, `params`, `enabled`) VALUES
(5, 'notification', 'contact_profile', 'libraries.event_handlers.notifications', 'wpl_events_notifications', 'contact_profile', '', 1);

UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='313';

ALTER TABLE `#__wpl_properties` CHANGE `last_modified_time_stamp` `last_modified_time_stamp` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `#__wpl_users` ADD `last_modified_time_stamp` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `rendered`;

UPDATE `#__wpl_dbst` SET `index`='1.00' WHERE `id`='308';
UPDATE `#__wpl_dbst` SET `index`='0.50' WHERE `id`='313';
UPDATE `#__wpl_dbst` SET `index`='0.60' WHERE `id`='312';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(36, 'service', 'Helps Service', 0, 'For running WPL Helps', 1, 'init', 'helps->run', '9999', '', '', '', 0, 99.99, 1);

ALTER TABLE `#__wpl_dbcat` ADD `params` TEXT NULL;
ALTER TABLE `#__wpl_dbcat` DROP `icon`, DROP `rankable`;

UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='41';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='911';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='53';

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
ALTER TABLE `#__wpl_users` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT;

ALTER TABLE `#__wpl_location1` ADD `abbr` VARCHAR(100) NULL AFTER `name`;
ALTER TABLE `#__wpl_location2` ADD `abbr` VARCHAR(100) NULL AFTER `name`;
ALTER TABLE `#__wpl_location3` ADD `abbr` VARCHAR(100) NULL AFTER `name`;
ALTER TABLE `#__wpl_location4` ADD `abbr` VARCHAR(100) NULL AFTER `name`;
ALTER TABLE `#__wpl_location5` ADD `abbr` VARCHAR(100) NULL AFTER `name`;
ALTER TABLE `#__wpl_location6` ADD `abbr` VARCHAR(100) NULL AFTER `name`;
ALTER TABLE `#__wpl_location7` ADD `abbr` VARCHAR(100) NULL AFTER `name`;

UPDATE `#__wpl_location1` SET `abbr`='US' WHERE `id`='254';
UPDATE `#__wpl_location2` SET `abbr`='AL' WHERE `id`='6001';
UPDATE `#__wpl_location2` SET `abbr`='AK' WHERE `id`='6002';
UPDATE `#__wpl_location2` SET `abbr`='AS' WHERE `id`='6003';
UPDATE `#__wpl_location2` SET `abbr`='AZ' WHERE `id`='6004';
UPDATE `#__wpl_location2` SET `abbr`='AR' WHERE `id`='6005';
UPDATE `#__wpl_location2` SET `abbr`='CA' WHERE `id`='6006';
UPDATE `#__wpl_location2` SET `abbr`='CO' WHERE `id`='6007';
UPDATE `#__wpl_location2` SET `abbr`='CT' WHERE `id`='6008';
UPDATE `#__wpl_location2` SET `abbr`='DE' WHERE `id`='6009';
UPDATE `#__wpl_location2` SET `abbr`='DC' WHERE `id`='6010';
UPDATE `#__wpl_location2` SET `abbr`='FM' WHERE `id`='6011';
UPDATE `#__wpl_location2` SET `abbr`='FL' WHERE `id`='6012';
UPDATE `#__wpl_location2` SET `abbr`='GA' WHERE `id`='6013';
UPDATE `#__wpl_location2` SET `abbr`='GU' WHERE `id`='6014';
UPDATE `#__wpl_location2` SET `abbr`='HI' WHERE `id`='6015';
UPDATE `#__wpl_location2` SET `abbr`='ID' WHERE `id`='6016';
UPDATE `#__wpl_location2` SET `abbr`='IL' WHERE `id`='6017';
UPDATE `#__wpl_location2` SET `abbr`='IN' WHERE `id`='6018';
UPDATE `#__wpl_location2` SET `abbr`='IA' WHERE `id`='6019';
UPDATE `#__wpl_location2` SET `abbr`='KS' WHERE `id`='6020';
UPDATE `#__wpl_location2` SET `abbr`='KY' WHERE `id`='6021';
UPDATE `#__wpl_location2` SET `abbr`='LA' WHERE `id`='6022';
UPDATE `#__wpl_location2` SET `abbr`='ME' WHERE `id`='6023';
UPDATE `#__wpl_location2` SET `abbr`='MH' WHERE `id`='6024';
UPDATE `#__wpl_location2` SET `abbr`='MD' WHERE `id`='6025';
UPDATE `#__wpl_location2` SET `abbr`='MA' WHERE `id`='6026';
UPDATE `#__wpl_location2` SET `abbr`='MI' WHERE `id`='6027';
UPDATE `#__wpl_location2` SET `abbr`='MN' WHERE `id`='6028';
UPDATE `#__wpl_location2` SET `abbr`='UM' WHERE `id`='6029';
UPDATE `#__wpl_location2` SET `abbr`='MS' WHERE `id`='6030';
UPDATE `#__wpl_location2` SET `abbr`='MO' WHERE `id`='6031';
UPDATE `#__wpl_location2` SET `abbr`='MT' WHERE `id`='6032';
UPDATE `#__wpl_location2` SET `abbr`='NE' WHERE `id`='6033';
UPDATE `#__wpl_location2` SET `abbr`='NV' WHERE `id`='6034';
UPDATE `#__wpl_location2` SET `abbr`='NH' WHERE `id`='6035';
UPDATE `#__wpl_location2` SET `abbr`='NJ' WHERE `id`='6036';
UPDATE `#__wpl_location2` SET `abbr`='NM' WHERE `id`='6037';
UPDATE `#__wpl_location2` SET `abbr`='NY' WHERE `id`='6038';
UPDATE `#__wpl_location2` SET `abbr`='NC' WHERE `id`='6039';
UPDATE `#__wpl_location2` SET `abbr`='ND' WHERE `id`='6040';
UPDATE `#__wpl_location2` SET `abbr`='MP' WHERE `id`='6041';
UPDATE `#__wpl_location2` SET `abbr`='OH' WHERE `id`='6042';
UPDATE `#__wpl_location2` SET `abbr`='OK' WHERE `id`='6043';
UPDATE `#__wpl_location2` SET `abbr`='OR' WHERE `id`='6044';
UPDATE `#__wpl_location2` SET `abbr`='PW' WHERE `id`='6045';
UPDATE `#__wpl_location2` SET `abbr`='PA' WHERE `id`='6046';
UPDATE `#__wpl_location2` SET `abbr`='PR' WHERE `id`='6047';
UPDATE `#__wpl_location2` SET `abbr`='RI' WHERE `id`='6048';
UPDATE `#__wpl_location2` SET `abbr`='SC' WHERE `id`='6049';
UPDATE `#__wpl_location2` SET `abbr`='SD' WHERE `id`='6050';
UPDATE `#__wpl_location2` SET `abbr`='TN' WHERE `id`='6051';
UPDATE `#__wpl_location2` SET `abbr`='TX' WHERE `id`='6052';
UPDATE `#__wpl_location2` SET `abbr`='UT' WHERE `id`='6053';
UPDATE `#__wpl_location2` SET `abbr`='VT' WHERE `id`='6054';
UPDATE `#__wpl_location2` SET `abbr`='VI' WHERE `id`='6055';
UPDATE `#__wpl_location2` SET `abbr`='VA' WHERE `id`='6056';
UPDATE `#__wpl_location2` SET `abbr`='WA' WHERE `id`='6057';
UPDATE `#__wpl_location2` SET `abbr`='WV' WHERE `id`='6058';
UPDATE `#__wpl_location2` SET `abbr`='WI' WHERE `id`='6059';
UPDATE `#__wpl_location2` SET `abbr`='WY' WHERE `id`='6060';

ALTER TABLE `#__wpl_user_group_types` ADD `editable` TINYINT(4) UNSIGNED NOT NULL DEFAULT '1', ADD `deletable` TINYINT(4) UNSIGNED NOT NULL DEFAULT '1', ADD `index` FLOAT(5, 2) NOT NULL DEFAULT '99.00';
ALTER TABLE `#__wpl_user_group_types` ADD `params` TEXT NULL, ADD `enabled` TINYINT(4) NOT NULL DEFAULT '1';

UPDATE `#__wpl_user_group_types` SET `editable`='0', `deletable`='0', `index`='1.00' WHERE `id`='1';
UPDATE `#__wpl_user_group_types` SET `editable`='0', `deletable`='0', `index`='2.00' WHERE `id`='2';

UPDATE `#__wpl_dbst` SET `editable`='1' WHERE `id`='906';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2]' WHERE `id`='6';

UPDATE `#__wpl_dbst` SET `specificable`='1' WHERE `id`='912';
UPDATE `#__wpl_dbst` SET `specificable`='1' WHERE `id`='913';
ALTER TABLE `#__wpl_dbst` ADD `user_specific` VARCHAR(200) NULL AFTER `property_type_specific`;

UPDATE `#__wpl_dbst` SET `category`='10' WHERE `id`='912';
UPDATE `#__wpl_dbst` SET `category`='10' WHERE `id`='911';
UPDATE `#__wpl_dbst` SET `category`='10' WHERE `id`='913';

INSERT INTO `#__wpl_user_group_types` (`id`, `name`, `editable`, `deletable`, `index`, `params`, `enabled`) VALUES (3, 'Guests', 0, 0, 0.50, NULL, 1);
UPDATE `#__wpl_users` SET `membership_type`='3' WHERE `id`='-2';
UPDATE `#__wpl_users` SET `membership_type`='3' WHERE `id`='0';

ALTER TABLE `#__wpl_users` DROP `maccess_rank_start`, DROP `maccess_attach`;
ALTER TABLE `#__wpl_users` DROP `maccess_renewal_period`;

ALTER TABLE `#__wpl_properties` CHANGE `field_312` `field_312` VARCHAR(70) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
CHANGE `field_313` `field_313` VARCHAR(70) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;

INSERT INTO `#__wpl_dbst_types` (`id`, `kind`, `type`, `enabled`, `index`, `queries_add`, `queries_delete`) VALUES
(19, '[0][1][2]', 'boolean', 1, 19.00, 'ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` TINYINT( 4 ) NOT NULL DEFAULT ''[DEFAULT_VALUE]''; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];', 'ALTER TABLE `#__[TABLE_NAME]`\r\nDROP `field_[FIELD_ID]`;');

ALTER TABLE `#__wpl_properties` ADD `show_address` TINYINT(4) NOT NULL DEFAULT '1' AFTER `location7_name`;

UPDATE `#__wpl_settings` SET `title`='Watermark Logo' WHERE `id`='11';
DELETE FROM `#__wpl_activities` WHERE `id`='1';

ALTER TABLE `#__wpl_dbst_types` ADD `options` TEXT NULL;

ALTER TABLE `#__wpl_users` ADD `index` FLOAT(5, 2) NOT NULL DEFAULT '99.00' AFTER `membership_type`;

UPDATE `#__wpl_dbst` SET `editable`='1', `specificable`='0' WHERE `id`='51';
UPDATE `#__wpl_dbst` SET `editable`='1', `specificable`='0' WHERE `id`='52';

ALTER TABLE `#__wpl_users` ADD `access_receive_notifications` TINYINT(4) NOT NULL DEFAULT '1' AFTER `access_change_user`;
ALTER TABLE `#__wpl_items` ADD `item_extra4` TEXT NULL AFTER `item_extra3`, ADD `item_extra5` TEXT NULL AFTER `item_extra4`;
ALTER TABLE `#__wpl_properties` ADD `source` VARCHAR(100) NOT NULL DEFAULT 'wpl' AFTER `alias`, ADD `last_sync_date` TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `source`;

UPDATE `#__wpl_dbst` SET `enabled`='2' WHERE `id`='313';
UPDATE `#__wpl_dbst` SET `enabled`='2', `deletable`='0' WHERE `id`='312';
UPDATE `#__wpl_dbst` SET `enabled`='2', `deletable`='0' WHERE `id`='308';

UPDATE `#__wpl_settings` SET `index`='3.00' WHERE `id`='50';
INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(90, 'property_alias_pattern', '[property_type][glue][listing_type][glue][location][glue][rooms][glue][bedrooms][glue][bathrooms][glue][price]', 1, 4, 'pattern', 'Property Link Pattern', '{"tooltip":"You can remove the parameters or change the positions. Don''t add new parameters!"}', '', 4.00);

UPDATE `#__wpl_settings` SET `type`='pattern' WHERE `id`='55';
UPDATE `#__wpl_settings` SET `type`='pattern' WHERE `id`='56';

ALTER TABLE `#__wpl_dbst` CHANGE `index` `index` FLOAT(9, 3) NOT NULL DEFAULT '99.00';

ALTER TABLE `#__wpl_property_types` DROP `keyword`;
ALTER TABLE `#__wpl_menus` CHANGE `index` `index` FLOAT(6, 3) NOT NULL DEFAULT '1.00';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`)
VALUES (110, 'javascript', 'qTips', '0', '', '1', 'qtips', 'js/qtips/jquery.qtip.min.js', '', '', '', '', '0', '110.00', '1');

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`)
VALUES (111, 'javascript', 'ImageLoaded', '0', '', '1', 'imageloaded', 'js/qtips/imagesloaded.pkg.min.js', '', '', '', '', '0', '110.01', '1');

ALTER TABLE `#__wpl_user_group_types` ADD `default_membership_id` INT(10) NOT NULL DEFAULT '-1' AFTER `name`;

UPDATE `#__wpl_user_group_types` SET `editable`='1' WHERE `id`='1';
UPDATE `#__wpl_user_group_types` SET `editable`='1' WHERE `id`='2';
UPDATE `#__wpl_user_group_types` SET `editable`='1' WHERE `id`='3';

ALTER TABLE `#__wpl_user_group_types` ADD `description` TEXT NULL AFTER `default_membership_id`;
ALTER TABLE `#__wpl_users` ADD `maccess_short_description` TEXT NULL AFTER `maccess_upgradable_to`, ADD `maccess_long_description` TEXT NULL AFTER `maccess_short_description`;

ALTER TABLE `#__wpl_properties` ADD `expired` TINYINT(4) NOT NULL DEFAULT '0' AFTER `confirmed`;
ALTER TABLE `#__wpl_users` ADD `expired` TINYINT(4) NOT NULL DEFAULT '0' AFTER `maccess_long_description`, ADD `expiry_date` DATETIME NULL AFTER `expired`;

UPDATE `#__wpl_dbst` SET `specificable`='0' WHERE `id`='310';
UPDATE `#__wpl_dbst` SET `specificable`='0' WHERE `id`='311';

UPDATE `#__wpl_user_group_types` SET `editable`='1' WHERE `id`='1';
UPDATE `#__wpl_user_group_types` SET `editable`='1' WHERE `id`='2';
UPDATE `#__wpl_user_group_types` SET `editable`='1' WHERE `id`='3';

ALTER TABLE `#__wpl_activities` ADD `client` TINYINT(4) NOT NULL DEFAULT '2';

UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='8';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='9';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='10';
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_si` double NOT NULL DEFAULT ''0''; ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]_unit` int NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='11';

INSERT INTO `#__wpl_cronjobs` (`id`, `cronjob_name`, `period`, `class_location`, `class_name`, `function_name`, `params`, `enabled`, `latest_run`) VALUES
(5, 'Maintenance', 24, 'global', 'wpl_global', 'execute_maintenance_job', '', 1, '2014-12-31 11:54:17');

UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.modernizr.min.js' WHERE `id`='108';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.jquery.qtip.min.js' WHERE `id`='110';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.imagesloaded.min.js' WHERE `id`='111';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.jquery.chosen.min.js' WHERE `id`='101';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.handlebars.min.js' WHERE `id`='109';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.jquery.hoverintent.js' WHERE `id`='104';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.jquery.mcustomscrollbar.min.js' WHERE `id`='102';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.ajaxfileupload.min.js' WHERE `id`='105';
UPDATE `#__wpl_extensions` SET `param2`='js/libraries/wpl.jquery.transit.min.js' WHERE `id`='103';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
('114', 'javascript', 'Spinner', '0', '', '1', 'spinner', 'js/libraries/wpl.jquery.spin.min.js', '', '', '', '', '0', '100.10', '1');

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
('115', 'javascript', 'Realtyna-Lightbox', '0', '', '1', 'realtyna-lightbox', 'js/libraries/realtyna/realtyna.lightbox.min.js', '', '', '', '', '0', '200.02', '1');

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
('116', 'javascript', 'Realtyna Framework', '0', '', '1', 'realtyna-framework', 'js/libraries/realtyna/realtyna.min.js', '', '', '', '', '0', '200.00', '1');

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
('107', 'js_default_path', 'js/libraries', '0', '1', 'text', 'JS Default Path', '', '', '106.00');

INSERT INTO `#__wpl_dbst` (`id`, `kind`, `mandatory`, `name`, `type`, `options`, `enabled`, `pshow`, `plisting`, `searchmod`, `editable`, `deletable`, `index`, `css`, `style`, `specificable`, `listing_specific`, `property_type_specific`, `user_specific`, `table_name`, `table_column`, `category`, `rankable`, `rank_point`, `comments`, `pwizard`, `text_search`, `params`) VALUES
(20, 0, 0, 'Alias / Permalink', 'text', '', 2, '0', 0, 0, 1, 0, 1.020, '', '', 0, '', '', '', 'wpl_properties', 'alias', 1, 0, 0, '', '0', 0, '');

UPDATE `#__wpl_extensions` SET `param2`='wpl_extensions->wpl_admin_menus' WHERE `id`='1';
ALTER TABLE `#__wpl_users` ADD `maccess_wpl_color` VARCHAR(10) NULL AFTER `maccess_long_description`;

UPDATE `#__wpl_extensions` SET `index`='200.10' WHERE `id`='115';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(117, 'javascript', 'Realtyna Utility', 0, '', 1, 'realtyna-utility', 'js/libraries/realtyna/realtyna.utility.min.js', '', '', '', '', 0, 200.01, 1);

ALTER TABLE `#__wpl_activities` ENGINE=InnoDB;
ALTER TABLE `#__wpl_addons` ENGINE=InnoDB;
ALTER TABLE `#__wpl_cronjobs` ENGINE=InnoDB;
ALTER TABLE `#__wpl_dbcat` ENGINE=InnoDB;
ALTER TABLE `#__wpl_dbst_types` ENGINE=InnoDB;
ALTER TABLE `#__wpl_events` ENGINE=InnoDB;
ALTER TABLE `#__wpl_extensions` ENGINE=InnoDB;
ALTER TABLE `#__wpl_filters` ENGINE=InnoDB;
ALTER TABLE `#__wpl_item_categories` ENGINE=InnoDB;
ALTER TABLE `#__wpl_kinds` ENGINE=InnoDB;
ALTER TABLE `#__wpl_listing_types` ENGINE=InnoDB;
ALTER TABLE `#__wpl_logs` ENGINE=InnoDB;
ALTER TABLE `#__wpl_menus` ENGINE=InnoDB;
ALTER TABLE `#__wpl_notifications` ENGINE=InnoDB;
ALTER TABLE `#__wpl_property_types` ENGINE=InnoDB;
ALTER TABLE `#__wpl_room_types` ENGINE=InnoDB;
ALTER TABLE `#__wpl_setting_categories` ENGINE=InnoDB;
ALTER TABLE `#__wpl_sort_options` ENGINE=InnoDB;
ALTER TABLE `#__wpl_unit_types` ENGINE=InnoDB;

UPDATE `#__wpl_sort_options` SET `field_name`='p.mls_id' WHERE `id`='1';
UPDATE `#__wpl_settings` SET `setting_value`='p.mls_id' WHERE `id`='23' AND `setting_value`='p.mls_id+0';

INSERT INTO `#__wpl_dbst` (`id`, `kind`, `mandatory`, `name`, `type`, `options`, `enabled`, `pshow`, `plisting`, `searchmod`, `editable`, `deletable`, `index`, `css`, `style`, `specificable`, `listing_specific`, `property_type_specific`, `user_specific`, `table_name`, `table_column`, `category`, `rankable`, `rank_point`, `comments`, `pwizard`, `text_search`, `params`) VALUES
(21, 0, 0, 'Location Text', 'text', '{"if_zero":"1","call_text":"Call"}', 2, '0', 0, 0, 1, 0, 1.021, '', '', 0, '', '', '', 'wpl_properties', 'location_text', 2, 0, 0, '', '0', 0, '');

ALTER TABLE `#__wpl_dbst` ADD `flex` TINYINT(4) NOT NULL DEFAULT '1' AFTER `params`;
UPDATE `#__wpl_dbst_types` SET `queries_add`='ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` varchar(100) NULL; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];' WHERE `id`='14';

UPDATE `#__wpl_dbst` SET `name`='Gender' WHERE `id`='906';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
('118', 'javascript', 'Realtyna Tagging', '0', '', '1', 'realtyna-tagging', 'js/libraries/realtyna/realtyna.tagging.min.js', '', '', '', '', '0', '202.00', '1');

ALTER TABLE `#__wpl_kinds` ADD `plural` VARCHAR(100) NULL, ADD `dbcat` TINYINT(4) NOT NULL DEFAULT '1', ADD `addon_id` INT(10) NOT NULL DEFAULT '0';
UPDATE `#__wpl_kinds` SET `plural`='Properties' WHERE `id`='0';
UPDATE `#__wpl_kinds` SET `plural`='Users', `dbcat`='0', `addon_id`='9' WHERE `id`='2';

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(126, 'google_api_key', null, 1, 1, 'text', 'Google API key', NULL, NULL, 55.00);

ALTER TABLE `#__wpl_users` ADD `about` TEXT NULL AFTER `last_name`;
INSERT INTO `#__wpl_dbst` (`id`, `kind`, `mandatory`, `name`, `type`, `options`, `enabled`, `pshow`, `plisting`, `searchmod`, `editable`, `deletable`, `index`, `css`, `style`, `specificable`, `listing_specific`, `property_type_specific`, `user_specific`, `table_name`, `table_column`, `category`, `rankable`, `rank_point`, `comments`, `pwizard`, `text_search`, `params`, `flex`) VALUES
(915, 2, 0, 'Personal Data', 'separator', 'null', 1, '1', 0, 1, 1, 1, 10.000, NULL, NULL, 1, NULL, NULL, NULL, 'wpl_users', NULL, 10, 1, 0, NULL, '1', 1, NULL, 1),
(916, 2, 0, 'Company Data', 'separator', 'null', 1, '1', 0, 1, 1, 1, 10.060, NULL, NULL, 1, NULL, NULL, NULL, 'wpl_users', NULL, 10, 1, 0, NULL, '1', 1, NULL, 1),
(917, 2, 0, 'Contact information', 'separator', 'null', 1, '1', 0, 1, 1, 1, 10.100, NULL, NULL, 1, NULL, NULL, NULL, 'wpl_users', NULL, 10, 1, 0, NULL, '1', 1, NULL, 1),
(918, 2, 0, 'About', 'textarea', '{"advanced_editor":"0","rows":"7","cols":"41"}', 1, '1', 1, 1, 1, 1, 10.035, NULL, NULL, 1, '', '', '', 'wpl_users', 'about', 10, 1, 0, NULL, '1', 1, NULL, 1);

UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='900';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='901';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='906';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='902';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='903';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='914';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='905';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='904';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='907';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='908';
UPDATE `#__wpl_dbst` SET `searchmod`='1' WHERE `id`='909';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(26, 'sidebar', 'Profile Listing Top', 0, 'Appears in Profile listing page', 1, 'wpl-profile-listing-top', '', '', '', '', '', 0, 99.99, 2),
(27, 'sidebar', 'WPL Hidden', 0, 'Appears no where! Use it for widget short-codes.', 1, 'wpl-hidden', '', '', '', '', '', 0, 99.99, 2);

ALTER TABLE `#__wpl_kinds` CHANGE `addon_id` `addon_name` VARCHAR(100) NULL;
UPDATE `#__wpl_kinds` SET `addon_name`='' WHERE `id` ='0';
UPDATE `#__wpl_kinds` SET `addon_name`='membership' WHERE `id`='2';

UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='114';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='116';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='115';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='117';
UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='118';

ALTER TABLE `#__wpl_dbst` ADD `accesses` TEXT NULL AFTER `user_specific`;
ALTER TABLE `#__wpl_dbst` ADD `accesses_message` VARCHAR(100) NULL AFTER `accesses`;

ALTER TABLE `#__wpl_dbst_types` CHANGE `kind` `kind` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '[0][1]';

UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='1';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='2';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='3';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][4]' WHERE `id`='4';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='5';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='6';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][4]' WHERE `id`='7';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][4]' WHERE `id`='8';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][4]' WHERE `id`='9';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][4]' WHERE `id`='10';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='11';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='12';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='13';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='14';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='19';
UPDATE `#__wpl_dbst_types` SET `kind`='[0][1][2][4]' WHERE `id`='20';

UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='109';

ALTER TABLE `#__wpl_kinds` ADD `index` FLOAT(6, 3) NOT NULL DEFAULT '99.00', ADD `params` TEXT NULL, ADD `enabled` TINYINT(4) NOT NULL DEFAULT '1';
ALTER TABLE `#__wpl_kinds` ADD `map` VARCHAR(10) NULL DEFAULT 'marker' AFTER `addon_name`;

UPDATE `#__wpl_dbst` SET `plisting`='0' WHERE `id`='51';
UPDATE `#__wpl_dbst` SET `plisting`='0' WHERE `id`='52';

INSERT INTO `#__wpl_dbst` (`id`, `kind`, `mandatory`, `name`, `type`, `options`, `enabled`, `pshow`, `plisting`, `searchmod`, `editable`, `deletable`, `index`, `css`, `style`, `specificable`, `listing_specific`, `property_type_specific`, `user_specific`, `accesses`, `accesses_message`, `table_name`, `table_column`, `category`, `rankable`, `rank_point`, `comments`, `pwizard`, `text_search`, `params`, `flex`) VALUES
(910, 2, 0, 'Location Text', 'text', '{"if_zero":"1","call_text":"Call"}', 2, '0', 0, 0, 1, 0, 10.055, '', '', 0, '', '', '', '', '', 'wpl_users', 'location_text', 10, 0, 0, '', '0', 0, '', 1);

UPDATE `#__wpl_dbst` SET `table_column`='', `text_search`='0' WHERE `id`='53';

ALTER TABLE `#__wpl_properties` DROP `description`;
ALTER TABLE `#__wpl_properties` DROP `googlemap_title`;
ALTER TABLE `#__wpl_properties` DROP `property_rank`;

UPDATE `#__wpl_dbst` SET `name`='List Date' WHERE `id`='19';

INSERT INTO `#__wpl_dbst` (`id`, `kind`, `mandatory`, `name`, `type`, `options`, `enabled`, `pshow`, `plisting`, `searchmod`, `editable`, `deletable`, `index`, `css`, `style`, `specificable`, `listing_specific`, `property_type_specific`, `user_specific`, `accesses`, `accesses_message`, `table_name`, `table_column`, `category`, `rankable`, `rank_point`, `comments`, `pwizard`, `text_search`, `params`, `flex`) VALUES
(22, 0, 0, 'Category', 'ptcategory', '', 2, '0', 0, 1, 0, 0, 1.045, '', '', 0, '', '', '', NULL, NULL, NULL, NULL, 1, 0, 0, '', '0', 0, '', 0);

UPDATE `#__wpl_settings` SET `params`='{"html_element_id":"wpl_watermark_uploader","request_str":"admin.php?wpl_format=b:settings:ajax&wpl_function=save_watermark_image"}' WHERE `id`='11';
UPDATE `#__wpl_extensions` SET `param2`='https://maps.google.com/maps/api/js?libraries=places,drawing&sensor=true' WHERE `id`='94';

UPDATE `#__wpl_dbst` SET `type`='text' WHERE `id`='5';

ALTER TABLE `#__wpl_properties` ADD `parent` int(11) unsigned NOT NULL COMMENT 'Parent' AFTER `mls_id`;

ALTER TABLE `#__wpl_activities` AUTO_INCREMENT=1000;

UPDATE `#__wpl_extensions` SET `title`='Helps Service', `description`='For running WPL Helps', `param2`='helps->run' WHERE `id`='36';

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(141, 'location_suffix_prefix', 'County, Avenue, Ave, Boulevard, Blvd, Highway, Hwy, Lane, Ln, Square, Sq, Street, St, Road, Rd', 0, 3, 'text', 'Location Suffixes/Prefixes', '{"html_class":"long"}', '', 141.00);

INSERT INTO `#__wpl_events` (`id`, `type`, `trigger`, `class_location`, `class_name`, `function_name`, `params`, `enabled`) VALUES
(39, 'notification', 'user_registered', 'libraries.event_handlers.notifications', 'wpl_events_notifications', 'user_registered', '', 1);

INSERT INTO `#__wpl_notifications` (`id`, `description`, `template`, `subject`, `additional_memberships`, `additional_users`, `additional_emails`, `options`, `params`, `enabled`) VALUES 
(5, 'Sends after registration process.', 'user_registered', 'Your Account has been registered.', '', '', '', NULL, '', '1');

DELETE FROM `#__wpl_extensions` WHERE `id`='32';
DELETE FROM `#__wpl_extensions` WHERE `id`='33';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(123, 'javascript', 'jQuery Time Picker', 0, '', 1, 'jquery-time-picker', 'js/libraries/wpl.jquery.timepicker.min.js', '', '', '', '', 0, 202.00, 2);

ALTER TABLE `#__wpl_users`
CHANGE `main_email` `main_email` varchar(255) COLLATE 'utf8_general_ci' NULL,
CHANGE `membership_type` `membership_type` varchar(10) COLLATE 'utf8_general_ci' NULL,
CHANGE `maccess_property_types` `maccess_property_types` varchar(255) COLLATE 'utf8_general_ci' NULL,
CHANGE `maccess_upgradable_to` `maccess_upgradable_to` text COLLATE 'utf8_general_ci' NULL,
CHANGE `textsearch` `textsearch` text COLLATE 'utf8_general_ci' NULL,
CHANGE `location_text` `location_text` varchar(255) COLLATE 'utf8_general_ci' NULL,
CHANGE `rendered` `rendered` text COLLATE 'utf8_general_ci' NULL;

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(124, 'action', 'User Login', 0, 'Calls after user login', 1, 'wp_login', 'wpl_users->user_loggedin', '10', '2', '', '', 0, 99.99, 2);

UPDATE `#__wpl_extensions` SET `client`='2' WHERE `id`='110';

ALTER TABLE `#__wpl_users` ENGINE=InnoDB;
ALTER TABLE `#__wpl_units` ENGINE=InnoDB;
ALTER TABLE `#__wpl_settings` ENGINE=InnoDB;
ALTER TABLE `#__wpl_dbst` ENGINE=InnoDB;

DELETE FROM `#__wpl_extensions` WHERE `id`='98';

ALTER TABLE `#__wpl_location1` ENGINE = InnoDB;
ALTER TABLE `#__wpl_location2` ENGINE = InnoDB;
ALTER TABLE `#__wpl_location3` ENGINE = InnoDB;
ALTER TABLE `#__wpl_location4` ENGINE = InnoDB;
ALTER TABLE `#__wpl_location5` ENGINE = InnoDB;
ALTER TABLE `#__wpl_location6` ENGINE = InnoDB;
ALTER TABLE `#__wpl_location7` ENGINE = InnoDB;
ALTER TABLE `#__wpl_locationtextsearch` ENGINE = InnoDB;
ALTER TABLE `#__wpl_locationzips` ENGINE = InnoDB;

INSERT INTO `#__wpl_dbst_types` (`id`, `kind`, `type`, `enabled`, `index`, `queries_add`, `queries_delete`) VALUES
(20, '[0][1][2][4]', 'checkbox', 1, 20.00, 'ALTER TABLE `#__[TABLE_NAME]` ADD `field_[FIELD_ID]` TINYINT( 4 ) NOT NULL DEFAULT ''0''; UPDATE `#__wpl_dbst` SET `table_name`=''[TABLE_NAME]'', `table_column`=''field_[FIELD_ID]'' WHERE id=[FIELD_ID];', 'ALTER TABLE `#__[TABLE_NAME]`\r\nDROP `field_[FIELD_ID]`;');

INSERT INTO `#__wpl_settings` (`id`, `setting_name`, `setting_value`, `showable`, `category`, `type`, `title`, `params`, `options`, `index`) VALUES
(166, 'txtimg_color1', '000000', 0, 1, 'text', 'Text to Image color', NULL, NULL, 166.00);

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(129, 'javascript', 'WPL Common javascript', '0', '', '1', 'wpl_common_javascript', 'js/wpl.commons.min.js', '', '', '', '', '0', '100.11', '2');

INSERT INTO `#__wpl_notifications` (`id`, `description`, `template`, `subject`, `additional_memberships`, `additional_users`, `additional_emails`, `options`, `params`, `enabled`) VALUES
(6, 'Send to friend', 'send_to_friend', 'Send to friend', '', '', '', NULL, '', 1),
(7, 'Request a visit', 'request_a_visit', 'Request a visit', '', '', '', NULL, '', 1);

INSERT INTO `#__wpl_events` (`id`, `type`, `trigger`, `class_location`, `class_name`, `function_name`, `params`, `enabled`) VALUES
(40, 'notification', 'request_a_visit_send', 'libraries.event_handlers.notifications', 'wpl_events_notifications', 'request_a_visit', '', 1),
(41, 'notification', 'send_to_friend', 'libraries.event_handlers.notifications', 'wpl_events_notifications', 'send_to_friend', '', 1);

UPDATE `#__wpl_dbst` SET `type`='tag', `options`='{"ribbon":"1","widget":"1","color":"29a9df","text_color":"ffffff","default_value":"0"}' WHERE `id`='400';
UPDATE `#__wpl_dbst` SET `type`='tag', `options`='{"ribbon":"1","widget":"1","color":"d21a10","text_color":"ffffff","default_value":"0"}' WHERE `id`='401';
UPDATE `#__wpl_dbst` SET `type`='tag', `options`='{"ribbon":"1","widget":"1","color":"3cae2c","text_color":"ffffff","default_value":"0"}' WHERE `id`='402';
UPDATE `#__wpl_dbst` SET `type`='tag', `options`='{"ribbon":"1","widget":"1","color":"666666","text_color":"ffffff","default_value":"0"}' WHERE `id`='403';

UPDATE `#__wpl_dbst` SET `pshow`='0' WHERE `type`='separator';

ALTER TABLE `#__wpl_dbcat` ADD `pdf` TINYINT(4) NOT NULL DEFAULT '0' AFTER `pshow`;
UPDATE `#__wpl_dbcat` SET `pdf`=`pshow`;

ALTER TABLE `#__wpl_dbst` ADD `pdf` TINYINT(4) NOT NULL DEFAULT '0' AFTER `pshow`;
UPDATE `#__wpl_dbst` SET `pdf`=`pshow`;

ALTER TABLE `#__wpl_items` ENGINE = InnoDB;
UPDATE `#__wpl_dbst` SET `plisting`='1' WHERE `id`='136';

ALTER TABLE `#__wpl_dbcat` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `#__wpl_units` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT;

UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='567';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='300';
UPDATE `#__wpl_dbst` SET `deletable`='0' WHERE `id`='301';

UPDATE `#__wpl_settings` SET `options`='{"show_empty":"1"}' WHERE `id`='25';
UPDATE `#__wpl_dbst` SET `plisting`='1' WHERE `id`='150';

UPDATE `#__wpl_settings` SET `setting_name`='io_public_key', `params`='{"readonly":"readonly"}' WHERE `id`='34';
UPDATE `#__wpl_settings` SET `setting_name`='io_private_key', `params`='{"readonly":"readonly"}' WHERE `id`='35';

INSERT INTO `#__wpl_extensions` (`id`, `type`, `title`, `parent`, `description`, `enabled`, `param1`, `param2`, `param3`, `param4`, `param5`, `params`, `editable`, `index`, `client`) VALUES
(131, 'service', 'WPL Service', 0, 'For running WPL service', 1, 'init', 'wpl->run', '9999', '', '', '', 0, 99.99, 2);

DELETE FROM `#__wpl_extensions` WHERE `id`='94';