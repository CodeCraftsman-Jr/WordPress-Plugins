<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<div class="wrap">
    <div class="wpl_message_container" id="wpl_message_container">
        <?php echo $this->message; ?>
	</div>
</div>
