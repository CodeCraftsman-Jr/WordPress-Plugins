<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.location_breadcrumb{ border: 1px solid #CCC; padding: 12px; border-radius: 5px; vertical-align: middle;}
.wpl_create_new{ margin-left:5px; vertical-align:middle;}
.location_tools{ margin:15px 0 0 0;}
.location_tools a{ border: solid 1px #888; border-radius: 3px; padding:5px; text-decoration:none; color: #666;}
#wpl_location_settings_lightbox .wpl_setting_form_container label.wpl_st_label{width: 125px; float: left; display: block;}
#wpl_location_settings_lightbox input[type=text]{font-weight: normal; width: 150px;}
#wpl_location_settings_lightbox .wpl_setting_form_tooltip{display: none;}
.wpl_no_item{text-align: center; cursor: pointer;}
.separator-name{padding-left: 30px; margin: 10px 0;}
hr{width: 90%; margin-bottom: 0;}
</style>