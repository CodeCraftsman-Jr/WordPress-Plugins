<?php
/** no direct access * */
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
#options_section label{width: 125px;}
.notification_top_bar{margin: 0 0 10px 0;}
.wpl_right_section{float: right;}
.wpl_left_section{float: left;}
#notification_filter{width: 500px;}
.clearfix{clear: both;}
.gray_tip{font-style: italic; color: #999999; font-size: 13px;}
.noti-wp .prow label{vertical-align: top !important;}
.manager-wp .action-btn.disable{cursor: default;}
</style>