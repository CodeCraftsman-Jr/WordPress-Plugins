<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<div class="wpl-wrapper-class">
    <?php include $path; ?>
</div>
<script type="text/javascript">
    (function($){$(function(){isWPL();})})(jQuery);
</script>