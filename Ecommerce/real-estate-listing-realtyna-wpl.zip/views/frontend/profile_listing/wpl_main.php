<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');

_wpl_import('views.frontend.profile_listing.wpl_abstract');

class wpl_profile_listing_controller extends wpl_profile_listing_controller_abstract
{
    public $wplraw = 0;
}