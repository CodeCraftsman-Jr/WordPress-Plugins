<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');

_wpl_import('views.frontend.property_listing.wpl_abstract');

class wpl_property_listing_controller extends wpl_property_listing_controller_abstract
{
    public $wplraw = 0;
}