=== Woocommerce Variable Product Ajax ===
Contributors: webdesignjc
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=25BYCRDE6D2PW
Tags: ajax variable product, ajax woocommerce, woocommerce ajax, variable product ajax, product ajax woocommerce, product ajax
Requires at least: 3.3
Tested up to: 4.0.1
Stable tag: 4.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin activate add to cart ajax on varible product in Woocommerce

== Description ==


This plugin enabled varible add product to Cart with ajax in WooCommerce, the detail shown in an overlay.

<a href="http://webdesignjc.com" target="_blank">Plugin Website</a>


== Installation ==

1. Upload the `woocommerce-variable-product-ajax` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin via the 'Plugins' menu in WordPress.


== Frequently asked questions ==



== Screenshots ==

1. Woocommerce Variable Product Ajax 1
2. Woocommerce Variable Product Ajax 2
3. Woocommerce Variable Product Ajax 3
4. Woocommerce Variable Product Ajax 4
5. Woocommerce Variable Product Ajax 5
6. Woocommerce Variable Product Ajax 6
7. Woocommerce Variable Product Ajax 7

== Changelog ==



== Upgrade notice ==

