Si ce message a &eacute;t&eacute; format&eacute; en HTML,
indiquez comment vous voulez l&rsquo;envoyer:<br />
<ul>
<li><b>HTML</b> - HTML aux utilisateurs qui ont indiqu&eacute; qu&rsquo;ils voulaient recevoir leurs emails au format HTML, et format texte pour tous les autres</li>
<li><b>texte</b> - texte brut pour tout le monde</li>
<li><b>texte et HTML</b> - Un gros email qui contient &agrave; la fois le format HTML et le format texte brut (emails plus lourds, mais ils ont plus de chance de s&rsquo;afficher correctement pour la plupart des utilisateurs)</li>
<li><b>PDF</b> - Le texte du message est envoy&eacute; comme pi&egrave;ce-jointe au format PDF</li>
<li><b>texte et PDF</b> - Un email qui contient la version du message au format texte seulement, avec une pi&egrave;ce-jointe au format PDF</li>
</ul>

<b>Note importante:</b> la version PDF sera une conversion du message au format texte, pas du message au format HTML.