<p>Si vous utilisez un mod&egrave;le, ce message sera plac&eacute; l&agrave; o&ugrave; vous aurez mis le code-raccourci [CONTENT] dans votre mod&egrave;le.</p>
<p>En plus de [CONTENT], vous pouvez ajouter [FOOTER] (pied de page) et [SIGNATURE] pour ins&eacute;rer l&rsquo;information du pied de page et la signature du message, mais tout ceci est facultatif.</p>
