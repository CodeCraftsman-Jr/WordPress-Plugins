<b>Embargar un mensaje</b>
<p>Puede embargar un mensaje para que no se env&iacute;e hasta la fecha y hora que especifique. El valor por defecto es hoy a las 0:00, de modo que el mensaje se env&iacute;a inmediatamente.</p>
<p><b>Nota</b>: el embargo determina el momento en que comenzar&aacute; el env&iacute;o del mensaje. Esto no significa que los mensajes llegar&aacute;n a los usuarios precisamente en ese momento.
</p>
