Enter the subject of your message. You cannot use placeholders in the subject.
