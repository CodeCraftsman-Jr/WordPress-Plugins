<p>Puoi aggiungere al messaggio tutti gli allegati che vuoi, ma il numero selezionato
&egrave; definito dalla tua configurazione.</p>
<p><b>Nota bene:</b> Gli allegati saranno inclusi nelle email con formato HTML, e saranno aggiunti come link ai messaggi in formato testo.</p>
<p>Il campo descrizione sar&agrave; usato solo nei messaggi in formato testo</p>
