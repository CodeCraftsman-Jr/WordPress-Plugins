Questa opzione permette di impostare il sistema perch&eacuto; crei automaticamente un nuovo messaggio
che &egrave; l'esatta copia del messaggio corrente, definito dall'intervallo da te specificato.
Se usate questa opzione, &egrave; importante utilizzare anche l'opzione "blocco", altrimenti
il vostro messaggio verr&agrave; inviato pi&ugrave; volte, sommergendo i vostri utenti di 
una quantit&agrave; enorme di messaggi identici!.
