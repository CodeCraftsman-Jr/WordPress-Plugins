<b>Blocca un messaggio</b>
<p>Puoi bloccare un messaggio in modo che non sia inviato prima della data e ora che indichi.
Di default sar&agrave; inviato immediatamente. </p>
<p><b>Nota bene</b>: il blocco imposta il momento in cui il messaggio verr&agrave; spedito.
Questo non significa che i messaggi arriveranno nella caselle di posta degli utenti a quell'ora.
</p>
