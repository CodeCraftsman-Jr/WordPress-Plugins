Se questo messaggio &egrave; formattato in HTML,
indicare come deve essere inviarlo:<br />
<ul>
<li><b>HTML</b> - HTML per gli utenti che hanno indicato che vogliono ricevere le email in formato HTML, e formato testo semplice per tutti gli altri</li>
<li><b>text</b> - solo testo per tutti</li>
<li><b>text and HTML</b> - Un'unica grande email che contenga entrambi </li>
<li><b>PDF</b> - Il testo del messaggio come allegato PDF</li>
<li><b>text and PDF</b> - Una email che contenga il messaggio in testo semplcie, con un PDF allegato</li>
</ul>

<b>Nota:</b> La versione PDF &egrave; la conversione del messaggio in formato testo semplice, non HTML.
