<p>Voc&ecirc; pode adicionar em suas mensagens quantos anexos quiser, mas o n&uacute;mero aqui definido depende da sua configura&ccedil;&atilde;o.</p>
<p><b>Aten&ccedil;&atilde;o:</b> Os anexos ser&atilde;o inclu&iacute;dos nos emails tipo HTML e ser&atilde;o adicionados atrav&eacute;s de um link para o site nos emails tipo Texto</p>
<p>O campo Descri&ccedil;&atilde;o ser&acute; utilizado somente nas mensagem tipo texto</p>
