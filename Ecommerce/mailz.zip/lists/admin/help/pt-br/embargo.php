<b>Veto tempor&aacute;rio de uma mensagem</b>
<p>Voc&ecirc; pode programar o veto tempor&aacute;rio de uma mensagem para que ela n&atilde;o seja enviada antes de uma certa data ou hora definida.
O padr&atilde;o est&aacute; definido como hoje &agrave; 0:00, logo ser&aacute; enviada imediatamente. </p>
<p><b>Por favor, aten&ccedil;&atilde;o</b>: o veto tempor&aacute;rio tem efeito sobre a hora em que a mensagem come&ccedil;ar&aacute; a ser enviada. Isso n&atilde;o significa que ela realmente chegar&aacute; na caixa de mensagem dos usu&aacute;rios nesta hora.</p>
