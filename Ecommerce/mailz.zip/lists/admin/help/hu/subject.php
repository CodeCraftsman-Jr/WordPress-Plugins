Írja be az üzenet tárgyát. A tárgyban nem használhat helyőrzőket.
