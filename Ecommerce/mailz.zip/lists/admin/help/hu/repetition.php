Ezzel a lehetőséggel a rendszer automatikusan készít egy új üzenetet,
mely a jelenlegi üzenet pontos másolata, az Ön által megadott időköz által meghatározva.
Ennek a lehetőségnek a használatakor a "zárolás" lehetőség használata is fontos, mert különben
folyamatosan fogja küldeni az üzenetet, ami azt idézi elő, hogy a felhasználók
sok üzenetet fognak kapni, melyek teljesen ugyanazok.

