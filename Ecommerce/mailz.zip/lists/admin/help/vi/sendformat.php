H&atilde;y ch&#7881; ra &#273;&#7883;nh d&#7841;ng b&#7841;n mu&#7889;n g&#7917;i th&#432; c&#7911;a m&igrave;nh:<br />
<ul>
<li><b>HTML</b> - &#272;&#7883;nh d&#7841;ng HTML s&#7869; g&#7917;i t&#7899;i h&#7897;i vi&ecirc;n &#273;&#259;ng k&yacute; nh&#7853;n HTML, v&agrave; &#273;&#7883;nh d&#7841;ng Text s&#7869; g&#7917;i t&#7899;i nh&#7919;ng ng&#432;&#7901;i c&ograve;n l&#7841;i.</li>
<li><b>text</b> - g&#7917;i &#273;&#7883;nh d&#7841;ng text t&#7899;i t&#7845;t c&#7843; h&#7897;i vi&ecirc;n</li>
<li><b>text and HTML</b> - m&#7897;t email l&#7899;n bao g&#7891;m c&#7843; HTML v&agrave; Text (c&aacute;ch n&agrave;y d&ugrave;ng &#273;&#432;&#7907;c v&#7899;i t&#7845;t c&#7843; h&#7897;i vi&ecirc;n)</li>
<li><b>PDF</b> - g&#7917;i th&#432; nh&#432; l&agrave; m&#7897;t file PDF &#273;&iacute;nh k&egrave;m</li>
<li><b>text and PDF</b> - email c&oacute; text v&agrave; k&egrave;m theo m&#7897;t file PDF</li>
</ul>

<b>L&#432;u &yacute;:</b> File PDF t&#7841;o ra t&#7915; email c&oacute; &#273;&#7883;nh d&#7841;ng Text ch&#7913; kh&ocirc;ng ph&#7843;i l&agrave; HTML.