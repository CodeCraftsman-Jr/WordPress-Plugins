<p>Hier finden Sie verschiedene Funktionen, um die Abonnentendaten in Ihrer Datenbank zu bereinigen.
Einige dieser Funktionen sind sehr m&ouml;chtig und ver&auml;ndern Ihre Abonnentendaten ohne R&uuml;ckfrage.
Benutzen Sie diese Befehle also nur, wenn Sie genau wissen, was Sie tun.
Es ist zudem empfehlenswert, vorher ein Backup aller Daten anzulegen.
</p>
