<p>Hier k&ouml;nnen Attribute f&uuml;r Administratorenkonten definiert werden.
Die Attributwerte lassen sich in Nachrichten integrieren, welche die Administratoren an ihre Listen senden.</p>
<p><a href="#new">Neues Attribut</a></p>