<p>Aqu&iacute; puede identificar los atributos que quiere que los
administradores introduzcan, que pueden entonces ser inclu&iacute;dos
en los correos que env&iacute;an a sus listas.
</p>
<p><a href="#new">A&ntilde;adir uno</a></p>