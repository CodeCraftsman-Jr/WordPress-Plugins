Puede usar &#171;Volver a poner en cola&#187; para reenviar un
mensaje. De este modo el mensaje se enviar&aacute; a los usuarios que
se hayan inscrito despu&eacute;s de que enviase el mensaje. No se
enviar&aacute; a los usuarios que ya lo han recibido.
<p>Si escoje ver el mensaje podr&aacute; reenviarlo a una lista diferente</p>
<?php if (TEST) { ?>
<br /><b>Nota:</b> Est&aacute; funcionando en modo de prueba, por lo
que los mensajes se reenviar&aacute;n a los usuarios que los han recibido.
<?php } ?>
