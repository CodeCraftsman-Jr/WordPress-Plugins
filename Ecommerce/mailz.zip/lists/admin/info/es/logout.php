<br/>
<p>Gracias por utilizar <?php echo NAME?>.<br/>Esperamos que haya
logrado su objetivo.</p>
<p>Se ha desconectado.</p>
<p>Para volver a conectarse haga click <a href='?page=home'>aqu&iacute;</a>.</p>

