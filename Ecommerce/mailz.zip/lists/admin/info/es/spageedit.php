<p>Aqu&iacute; puede crear p&aacute;ginas a trav&eacute;s de las
cuales sus usuarios podr&aacute;n inscribirse en sus listas.</p>
<p>Puede escojer cualquier conjunto de atributos y listas de los que
est&aacute;n definidos en su sistema. Si una lista o atributo no
est&aacute; aqu&iacute; tiene que a&ntilde;adirlo antes. Los atributos tomar&aacute;n por
defecto sus valores globales de atributo, pero puede reorganizarlos y
cambiar los valores por defecto. Tambi&eacute;n puede cambiar el que
un atributo sea obligatorio o no. Esto solo afectar&aacute; a la
obligatoriedad de un atributo en el momento en que los usuarios se
inscriban a trav&eacute;s de la p&aacute;gina.</p>