<br /><?php echo PageLink2("messages","Volver a la lista de mensajes")?>
<br /><a href="#resend">Enviar este mensaje a otra lista</a>
