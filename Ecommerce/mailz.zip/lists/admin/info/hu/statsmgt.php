
<p>Ezen az oldalon látható visszakeresési célból a statisztika. Jelenleg még kissé nyers, s a következő verziókban frissíteni kell.</p>
<p>Kérjük, hogy észrevételeit és javaslatait küldje be a <a href="http://mantis.phplist.com/">Mantis</a> hibakövetőbe</p>