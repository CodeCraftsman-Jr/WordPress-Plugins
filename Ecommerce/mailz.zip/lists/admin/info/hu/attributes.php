<p>Itt azonosíthatja be az emberek által beírandó tulajdonságokat, hogy fel tudjanak iratkozni a listákra.
<br />A tulajdonságok "globálisak", pl, az összes listára érvényesek.</p>
<p><a href="#new">Új hozzáadása</a></p>
