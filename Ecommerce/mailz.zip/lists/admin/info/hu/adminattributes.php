<p>Itt azonosíthatja be azokat az adminisztrátorok által beírandó tulajdonságokat, melyeket betehetnek az ő listáikra küldött e-mailekbe.
</p>
<p><a href="#new">Új hozzáadása</a></p>