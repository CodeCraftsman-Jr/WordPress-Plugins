<h3>Ezen az oldalon a <?php echo NAME?> megfelelő működése érdekében beállítandó dolgok gyors ellenőrzőlistája látható.</h3>

