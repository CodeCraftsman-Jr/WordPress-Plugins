<p>Itt kell megadnia a webhely pontos értékeit.<br/>
Az értékekben bizonyos <b>helyőrzőket</b> használhat.
A helyőrzők úgy néznek ki, mint például a <b>[NÉMISZÖVEG]</b>, ahol a <i>NÉMISZÖVEG</i> eltérő lehet.
Néhány hasznos helyőrző:
</p>
<div class="placeholders">
<ul>
<li>WEBSITE - a webhely címeként begépelt szöveg
<li>DOMAIN - a tartományként begépelt szöveg
<li>SUBSCRIBEURL - a rendelési oldal helye
<li>UNSUBSCRIBEURL - a lemondási oldal helye
<li>BLACKLISTURL - a lemondási oldal helye az ismeretlen felhasználók számára
<li>PREFERENCESURL - annak az oldalnak a helye, ahol a felhasználók módosíthatják az adataikat
<li>CONFIRMATIONURL - annak az oldalnak a helye, ahol a felhasználóknak vissza kell igazolniuk a megrendelésüket
</ul>
</div>
<!--A fejléchez és a lábléchez a következő kódot használhatja a külső dokumentumok belevételéhez:
<br/>
<b>[URL:&lt;A betöltendő oldal teljes URL-címe&gt;]</b>-->

