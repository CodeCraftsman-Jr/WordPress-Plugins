<p>Ezen az oldalon látható a <?php echo NAME?> listán történt események listája, amit érdemes lehet áttekinteni.
A bejegyzések listázása fordított időrendi sorrendben történik.</p>
