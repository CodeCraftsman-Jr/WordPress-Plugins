Itt vehet föl több e-mail címet a listáira. A tulajdonságokat az első sorban kell beazonosítani a fájlban. Szövegsor attribútumként kerülnek létrehozásra, ha nem léteznek.
