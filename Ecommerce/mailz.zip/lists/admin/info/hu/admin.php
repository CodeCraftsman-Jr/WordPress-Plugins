<hr/>
<p>Állítsa be az oldalmegtekintési engedélyeket a rendszerben:</p>
<ul>
<li>Mind: Az adminisztrátornak korlátozások nélküli joga van megtekinteni az oldalt</li>
<li>Nézet: Az adminisztrátor megtekintheti az oldalak tartalmát, viszont nem módosíthat semmit. Ez jelenleg csak
a "felhasználó", "felhasználók" és "tagok" oldalakon működik.</li>
<li>Nincs: Az adminisztrátor nem láthatja ezt az oldalt</li>
<li>Tulajdonos: Az adminisztrátor megtekintheti ezt az oldalt, viszont csak megtekintheti azoknak a listáknak a tartalmát, melyeknek a tulajdonosa</li>
</ul>
