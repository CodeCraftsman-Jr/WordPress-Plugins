
<p>Ezekkel a funkciókkal a felhasználókat kezelheti. Kilistázhatja és megkeresheti a felhasználókat,
importálhatja és exportálhatja őket, vagy újraegyeztetheti a felhasználói adatbázist az érvénytelen bejegyzések megtalálásához.</p>
<p>A listán szereplő felhasználók megtekintéséhez menjen a listához, majd kattintson a "tagok megtekintése" hivatkozásra.</p>