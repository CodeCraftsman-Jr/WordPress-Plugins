<p>Itt található a kapott visszapattanók listája. A legtöbb esetben felhasználóhoz és üzenethez kerülnek beazonosításra.
Élő rendszer használata esetén ne törölje a visszapattanókat, mert a rendszer nem tudná
beazonosítani a folyamatosan visszapattanókat a visszaérkezésük után. Jelenleg csak megtekinthet egy visszapattanót,
(még) nincs mód a visszapattanó rendszerbeazonosításának hatálytalanítására. Némely esetben ez azt jelentheti,
hogy valami visszapattanóként megjelölt, mikor csak "A postaláda megtelt" ideiglenes hiba volt.</p>
