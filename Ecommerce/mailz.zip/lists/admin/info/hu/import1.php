Itt több e-mail címet vehet fel a listáira. Valamennyi e-mail címnek ugyanazokkal a tulajdonságokkal kell rendelkeznie, melyeket alább azonosíthat be.
