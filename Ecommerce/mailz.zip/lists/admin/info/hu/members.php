<br />A Törlés csak erről a listáról távolítja el ezt a személyt
