
<p>Op deze pagina vind u functies die met gebruikersmanagement te maken hebben. U kan gebruikers
weergeven, zoeken, importeren en exporteren of de gebruikersdatabase controleren op ongeldige velden.</p>
<p>Om abonnees van een bepaalde lijst te overzien, ga naar de desbetreffende lijst en selecteer dan "leden"</p>
