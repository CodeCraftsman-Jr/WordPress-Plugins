Hier kan je verschillende emails aan je lijst toevoegen. Alle emails moeten dezelfde attributen hebben, dewelke je onderaan kan geven.
