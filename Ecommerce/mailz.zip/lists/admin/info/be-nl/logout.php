<br/>
<p>Hartelijk dank om gebruik te maken van <?php echo NAME?>.<br>We hopen dat alles naar wens is verlopen en dat u uw doel heeft kunnen bereiken.</p>
<p>U bent nu uitgelogd.</p>
<p>Om opnieuw in te loggen, klik <a href='?page=home'>hier</a>.</p>

