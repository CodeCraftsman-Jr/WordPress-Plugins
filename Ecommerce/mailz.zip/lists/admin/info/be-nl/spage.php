<h1>Maak verschillende inschrijf pagina's.</h1>
<p>Deze pagina laat u toe om pagina's aan te maken waarop gebruikers zich kunnen inschrijven op uw lijsten.</p>
<p>U kan alle attributen en lijsten die zijn vastgelegd in het systeem selecteren. Als een lijst of
attribuut hier niet tussen staat, dan zal u deze eerst moeten toevoegen. U kan geen globale attrubuten aanpassen, <br />
maar u kan ze hier wel herpositioneren en andere waarden toevoegen. U kan ook aangeven
of een attribuut noodzakelijk is of niet. Al deze instellingen hebben enkel betrekking op de ingave op deze pagina.</p>
