<p>Hier moet je de correcte waarden voor jou website specifieren.<br/>
Je kan bepaalde <b>Placeholders</b> gebruiken in je waarden.
Placeholders zien eruit als <b>[SOMETEXT]</b>, waar <i>SOMETEXT</i> verschillend kan zijn.
Enkele nuttige placeholders zijn:
<ul>
<li>WEBSITE - het adres dat je typt voor je website
<li>DOMAIN - de tekst die je typt voor je domein
<li>SUBSCRIBEURL - de locatie van de Inschrijf pagina
<li>UNSUBSCRIBEURL - de locatie van de Uitschrijf pagina
<li>PREFERENCESURL - de locatie van de pagina waar gebruikers hun details kunnen wijzigen
<li>CONFIRMATIONURL - de locatie van de pagina waar gebruikers hun inschrijving moeten bevestigen
</ul>
<!--Voor de header en de footer kan je de volgende code gebruiken om externe documenten in te voegen:
<br/>
<b>[URL:&lt;Volledige URL naar de te laden pagina&gt;]</b>-->
</p>
