<p>Maak hier alle attributen aan die beheerders moeten invullen zodat ze kunnen worden ingesloten in emails die zij zenden naar hun lijst(en).
</p>
<p><a href="#new">Voeg een nieuwe toe</a></p>
