<h1>Deze pagina toont een snelle controlelijst van instellingen die nodig zijn om <?php echo NAME?> correct te laten functioneren</h1>
