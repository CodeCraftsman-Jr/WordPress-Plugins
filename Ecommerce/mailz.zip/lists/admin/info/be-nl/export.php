U kan gebruikers op datum exporteren.<br/>
Als u op de "Export" knop klikt, dan zal u een popup venster krijgen om het bestand te downloaden. Dit zal een TAB afgebakend tekstbestand zijn die de resultaten van uw export query bevatten.<br/>
U kan dit bestand in de meeste spreadsheet applicaties gebruiken.
