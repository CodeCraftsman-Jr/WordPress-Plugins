<br /><?php echo PageLink2("berichten","Terug naar de lijst met Berichten")?>
<br /><a href="#resend">Zend dit bericht naar een andere lijst</a>
