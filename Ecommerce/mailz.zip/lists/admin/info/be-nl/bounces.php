<p>Dit is de lijst met ontvangen bounces. In de meeste gevallen zullen ze worden geidentificeerd voor een gebruiker en een bericht. 
Als u werkt met een een live systeem, verwijder dan geen bounces want anders zal het systeem de terugkerende bounces niet kunnen herkennen
Momenteel kan u enkel een bounce bekijken,
er is (nog) geen manier om de systeem identificatie van de bounce op te heffen. In sommige gevallen kan dit betekenen 
dat iets is gemarkeerd als bounce, terwijl het enkel een "Mailbox vol" tijdelijke error was.</p>
