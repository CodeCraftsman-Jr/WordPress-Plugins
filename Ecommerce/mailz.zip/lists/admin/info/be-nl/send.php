<p>Om een bericht te zenden dient u de informatie onderaan in te vullen. De minimum vereiste voor een geldig bericht
is de informatie in de "Inhoud" tab. Zorg ervoor dat u de wijzigingen opslaat VOORALLEER naar een andere tab te gaan, anders zal u deze gegevens verliezen.
Om het bericht af te maken en te verzenden, kiest u voor de "Lijsten" tab, selecteer 
alle lijsten waarnaar u het bericht wilt versturen en klik op de knop "Verzend bericht naar geselecteerde Mailinglijst".</p>
