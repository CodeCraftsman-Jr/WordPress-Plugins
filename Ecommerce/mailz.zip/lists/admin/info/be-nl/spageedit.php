<p>Deze pagina laat u toe om pagina's aan te maken die gebruikt worden door gebruikers om zich in te schrijven op uw lijsten.</p>
<p>U kan alle attributen en lijsten die zijn vastgelegd in uw systeem selecteren. Als een lijst of
attribuut hier niet staat, dan zul u deze eerst moeten toevoegen. Waarden voor attributen standaard aan uw globale attribuut waarden, <br />
maar u kan ze hier her-positioneren, en andere waarden toevoegen. U kan ook
aangeven of een attribuut noodzakelijk is of niet. Deze instellingen hebben enkel betrekking op de huidige inschrijf pagina.</p>
