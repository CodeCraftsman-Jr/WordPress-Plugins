U kan "terug in wachtrij" gebruiken om een bericht opnieuw te verzenden. Hiermee kan u het bericht opniew versturen naar gebruikers die zich na de oorspronkelijke zending hebben ingeschreven. Het bericht zal niet meer verzonden worden aan gebruikers die het reeds ontvangen hebben.
<p>Als u een bericht bekijkt, dan zal u de mogelijkheid hebben om het opnieuw te verzenden aan een andere lijst</p>
<?php if (TEST) { ?>
<br /><b>Opmerking:</b> Momenteel werkt u nog in test mode. Hierdoor zal het bericht "herzonden" worden naar alle gebruikers die het al ontvangen hebben.
<?php } ?>
