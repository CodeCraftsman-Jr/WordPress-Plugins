<p>Hier kan u extra velden (attributen) ingeven die gebruikers al dan niet dienen in te vullen als ze zich abonneren op een lijst.
<br />Attributen zijn "globaal". Dwz dat deze gegevens voor alle lijsten zullen worden opgevraagd.</p>
<p><a href="#new">Voeg een nieuwe attribuut toe</a></p>
