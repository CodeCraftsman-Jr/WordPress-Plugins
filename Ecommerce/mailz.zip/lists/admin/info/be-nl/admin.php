<hr/>
<p>Bewerk de gegevens van een beheerder. Zowel de logingegevens (Naam / wachtwoord) als rechten volgens toegewezen
functie, kunnen hier op de verschillende onderdelen in PhpList aangegeven worden.</p>
