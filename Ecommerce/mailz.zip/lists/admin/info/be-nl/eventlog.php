<p>Deze pagina geeft de evenementen weer die reeds gebeurd zijn in <?php echo NAME?> die mogelijks interessant zijn om te bekijken.
De waarden zijn weergegeven in omgekeerde chronologische volgorde</p>
