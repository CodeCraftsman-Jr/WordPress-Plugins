<br/>
<p>Merci d&rsquo;avoir utilis&eacute; <?php echo NAME?>.<br/>Nous esp&eacute;rons que vous &ecirc;tes satisfait(e).</p>
<p>Vous &ecirc;tes maintenant d&eacute;connect&eacute;(e).</p>
<p>Pour vous reconnecter, cliquez <a href='?page=home'>ici</a>.</p>

