Vous pouvez choisir de "Remettre dans la file d&rsquo;attente" un message pour le renvoyer.  Ceci enverra le message aux utilisateurs qui se seront inscrits sur la liste apr&egrave;s votre premier envoi.  Mais cela ne renverra pas le message aux utilisateurs qui ont d&eacute;j&agrave; re&ccedil;u le message.
<p>Si vous affichez un message, vous pourrez le renvoyer &agrave; une autre liste</p>
<?php if (TEST) { ?>
<br /><b>Note:</b> Vous travaillez en mode test; les messages seront "Renvoy&eacute;s" aux utilisateurs qui l&rsquo;ont d&eacute;j&agrave; re&ccedil;u.
<?php } ?>
