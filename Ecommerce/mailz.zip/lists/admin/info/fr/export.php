Vous pouvez exporter les utilisateurs en fonction de la date.<br/>
Si vous cliquez sur le bouton "Exporter", une fen&ecirc;tre appara&icirc;tra pour t&eacute;l&eacute;charger le fichier. Le fichier sera un fichier texte (d&eacute;limit&eacute; par des TABULATIONS) comportant le r&eacute;sultat de votre requ&ecirc;te.<br/>
Vous pouvez exploiter ce fichier dans la plupart des tableurs.