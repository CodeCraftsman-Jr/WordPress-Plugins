<p>Vous devez sp&eacute;cifier ici les valeurs correspondant &agrave; votre site web.<br/>
Vous pouvez utiliser certains <b>codes-raccourcis</b> dans les valeurs choisies.
Les codes-raccourcis ressemblent &agrave; <b>[DUTEXTE]</b>, o&ugrave; <i>DUTEXTE</i> sera remplac&eacute; par la valeur de l&rsquo;attribut correspondant.
Quelques codes-raccourcis utiles install&eacute;s par d&eacute;faut:
</p>
<div class="placeholders">
<ul>
<li>WEBSITE - l&rsquo;adresse que vous tapez pour votre site web
<li>DOMAIN - le texte que vous tapez pour votre nom de domaine
<li>SUBSCRIBEURL - l&rsquo;adresse de votre page d&rsquo;inscription
<li>UNSUBSCRIBEURL - l&rsquo;adresse de votre page de d&eacute;sinscription
<li>PREFERENCESURL - l&rsquo;adresse de la page dans laquelle les utilisateurs peuvent mettre &agrave; jour les renseignements les concernant
<li>CONFIRMATIONURL - l&rsquo;adresse de la page o&ugrave; les utilisateurs doivent confirmer leur inscription
</ul>
</div>
<!--Pour l'en-tete et le pied de page, vous pouvez utiliser le code suivant pour inclure des documents externes:
<br/>
<b>[URL:&lt;Adresse internet complete de la page a charger&gt;]</b>-->
