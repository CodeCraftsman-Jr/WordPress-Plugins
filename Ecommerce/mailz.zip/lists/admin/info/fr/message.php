<br /><?php echo PageLink2("messages","Retour vers la liste des messages")?>
<br /><a href="#resend">Envoyer ce message &agrave; une autre liste</a>
