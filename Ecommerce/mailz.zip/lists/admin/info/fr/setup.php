<h3>Cette page affiche une liste d&rsquo;&eacute;l&eacute;ments qui doivent &ecirc;tre mis en place pour que <?php echo NAME?> fonctionne correctement </h3>

