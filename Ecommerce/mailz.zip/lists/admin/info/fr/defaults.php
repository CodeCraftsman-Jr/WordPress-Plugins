<h3>Ajoutez des attributs qui peuvent &ecirc;tre utiles</h3>
Choisissez les attributs par d&eacute;faut que vous voulez ajouter &agrave; votre syst&egrave;me de listes de diffusion: