<p>Qui devi specificare i valori corretti del tuo sito internet.<br/>
Puoi usare i <b>Segnaposto</b> predefiniti nei tuoi valori.
Segnaposto del tipo <b>[SOMETEXT]</b>, dove <i>SOMETEXT</i> puo essere differente.
Alcuni segnaposto utili sono:
</p>
<div class="placeholders">
<ul>
<li>WEBSITE - l'indirizzo che hai specificato per il tuo sito
<li>DOMAIN - Il testo che hai specificato per il tuo dominio
<li>SUBSCRIBEURL - la posizione della pagina di iscrizione
<li>UNSUBSCRIBEURL - la posizione della pagina di cancellazione iscrizione
<li>PREFERENCESURL - la posizione della pagina dove gli utenti possono aggiornare i propri dettagli
<li>CONFIRMATIONURL - la posizione della pagina dove gli utenti possono confermare la loro iscrizione
</ul>
</div>
<!--Per header e the footer puoi usare il seguente codice per includere documenti esterni:
<br/>
<b>[URL:&lt;Full URL of page to load&gt;]</b>-->
</p>
