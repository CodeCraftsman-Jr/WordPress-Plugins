<p>Questa pagina permette di creare pagine utilizzabili dagli utenti per iscriversi alle tue liste.</p>
<p>Puoi selezionare qualsiasi gruppo di attributi e liste definite nel tuo sistema. Se una lista o 
attributo non sono elencati qui, &egrave; necessario aggiungerli . I valori per gli attributi sono predefiniti
dagli attibuti globali, ma puoi reimpostarli qui, e aggiungere differenti valori predefiniti. Puoi inoltre
definire se un attributo &egrave; necessario oppure no. Questo avr&agrave; effetto rendendo gli attributi necessari o meno quando gli utenti usano quella pagina per iscriversi.</p>
