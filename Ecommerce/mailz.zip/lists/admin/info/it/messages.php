Puoi usare "Rimetti in coda" per reinviare un messaggio. Questo far&agrave; s&igrave; che il messaggio venga trasmesso agli utenti che si sono iscritti successivamente a quando hai inviato il messaggio. Non sar&agrave; ritrasmesso agli utenti l'hanno gi&agrave; ricevuto.
<p>Visualizzando il messaggio sar&agrave; possibile ritrasmetterlo a una differente lista</p>
<?php if (TEST) { ?>
<br /><b>Nota:</b> Stai operando in modalit&agrave; test, i messaggi saranno "reinviati" agli utenti che lo hanno gi&agrave; ricevuto.
<?php } ?>
