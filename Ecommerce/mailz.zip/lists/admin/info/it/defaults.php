<h3>Aggiungi alcuni possibili attributi utili</h3>
Scegli gli attributi che vuoi aggiungere al tuo sistema di mailinglist:
