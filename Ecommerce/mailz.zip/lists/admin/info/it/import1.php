Qui puoi aggiungere inidirizzi email multipli alle tue liste. Tutte le email devono avere gli stessi attributi, che puoi identificare qui di seguito.
