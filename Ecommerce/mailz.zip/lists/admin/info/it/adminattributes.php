<p>Qui puoi identificare gli attributi che vuoi che gli amministratori inseriscano, e che saranno inclusi nelle email che ciascuno spedir&agrave; alle proprie liste.
</p>
<p><a href="#new">Aggiungi</a></p>
