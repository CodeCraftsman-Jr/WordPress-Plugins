<p>Qui puoi impostare gli attributi che vuoi che le persone inseriscano per iscriversi alle liste.
<br />Gli attributi sono "globali" e saranno applicati a tutte le liste.</p>
<p><a href="#new">Aggiungi</a></p>
