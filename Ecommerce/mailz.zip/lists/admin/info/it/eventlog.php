<p>Questa pagina elenca gli eventi importanti accaduti in <?php echo NAME?>.<br/>
L'elenco &egrave; visualizzato in ordine cronologico decrescente</p>
