<br /><?php echo PageLink2("messaggi","Ritorna alla lista dei messaggi")?>
<br /><a href="#resend">Invia questo messaggio a un'altra lista</a>
