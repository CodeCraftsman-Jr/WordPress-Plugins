<p><h3>Questa pagina serva per pulire il database degli utenti</h3></p>
