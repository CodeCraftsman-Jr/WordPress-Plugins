Puoi esportare gli utenti basandoti sulle date.<br/>
Se fai click sul pulsante "Esporta", si aprir&agrave; un box per il download dell'archivio.  Questo &egrave; un 
archivio delimitato da TAB contenente i risultati della tua richiesta di esportazione sulla base dei parametri scelti.<br/>
Questo archivio &egrave; utilizzabile dalla maggior parte degli applicativi di foglio elettronico.
