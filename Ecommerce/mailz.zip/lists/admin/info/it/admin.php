<hr/>
<p>Imposta i permessi di visualizzazione:</p>
<ul>
<li>Tutti: gli amministratori hanno accesso alla pagina senza alcuna restrizione</li>
<li>Visualizza: gli amministratori possono vedere il contenuto delle pagine, ma non possono apportarevi modifiche. Questa opzione si utilizza normalmente per le pagine "utente", "utenti" e "membri".</li>
<li>Nessuno: gli amministratori non possono visualizzare questa pagina</li>
<li>Proprietario: gli amministratori possono vedere di questa pagina solo il contenuto delle liste di propriet&agrave;</li>
</ul>
