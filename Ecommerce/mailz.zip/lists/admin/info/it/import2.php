Qui puoi aggiungere email multiple alle tue liste. Gli attributi devono essere identificati nella prima riga del file. Gli attributi saranno creati come attributi di testo se non esistono.
