<p>Questo &egrave; l'elenco delle email respinte. Nella maggior parte dei casi sono identificate da un utente e
un messaggio. Se stai eseguendo da un sistema attivo, non cancellare le email respinte perch&eacute; il sistema potrebbe non riuscire a
identificare le email respinte pi&ugrave; volte. Attualmente puoi visualizzare un'unica mail respinta,
non vi &egrave; nessun modo (attualmente) per sovrascrivere il sistema di identificazione delle emails respinte. In alcuni casi questo pu&ograve;
contrassegnare come rimbalzo un messaggio soggetto ad un errore temporaneo di "Casella mail piena".</p>
