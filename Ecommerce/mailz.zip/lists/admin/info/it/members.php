<br />L'opzione Elimina rimuover&agrave; questa persona soltanto dalla lista
