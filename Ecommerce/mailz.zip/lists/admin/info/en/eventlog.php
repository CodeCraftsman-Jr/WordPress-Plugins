<p>This page lists events that have happend in <?php echo NAME?> that may be of interest to review.
The entries are listed in reverse chronological order</p>
