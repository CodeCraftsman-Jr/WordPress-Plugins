<p><h3>This page allows you to clean up the database of users</h3></p>
