<hr/>
<p>Set permissions to view pages in the system:</p>
<ul>
<li>All: admin has access to page without restrictions</li>
<li>View: admin can view content of pages, but not change anything. This currently only works
for the "user", "users" and "members" pages.</li>
<li>None: admin cannot see this page</li>
<li>Owner: admin can see this page, but only see the content of the lists they own</li>
</ul>
