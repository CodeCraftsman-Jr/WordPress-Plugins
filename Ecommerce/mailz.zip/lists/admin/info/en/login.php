<p class="information">This document requires you to log in</p>
