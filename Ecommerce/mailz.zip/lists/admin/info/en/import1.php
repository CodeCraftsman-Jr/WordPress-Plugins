Here you can add multiple emails to your lists. All emails need to have the same attributes, which you can identify below.
