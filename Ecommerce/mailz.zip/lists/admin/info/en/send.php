<p class="information">To send a message fill out the information below. The minimum requirement for a valid message
is the information in the "Content" tab. Make sure to save your changes before going to a new tab 
or they will be lost. To finish your message and send it for real, choose the "Lists" tab, select 
your lists and click the button "Send Message to Selected Mailinglists"</p>