<br />Delete will remove this person from this list only
