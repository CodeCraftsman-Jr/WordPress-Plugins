Here you can add multiple emails to your lists. Attributes need to be identified on the first line in the file. They will be created as textline attributes if they don't exist.
