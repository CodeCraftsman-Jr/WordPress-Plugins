
<!-- all info is in the info file -->
<?php
if (!ALLOW_IMPORT) {
  print $GLOBALS['I18N']->get('import is not available');
  return;
}
?>