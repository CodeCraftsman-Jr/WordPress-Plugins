<?php
require(dirname(__FILE__).'/integrator.inc.php');
require(dirname(__FILE__).'/misc.inc.php');
require(dirname(__FILE__).'/shared.inc.php');
require(dirname(__FILE__).'/support-us.inc.php');
