=== Parcelware ===
Contributors: pronamic, remcotolsma
Tags: parcelware, postnl, post, tnt, csv, woocommerce, export, deprecated, adopt-me
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create Parcelware importable CSV files from the orders in your WordPress webshop.

== Description ==

> This plugin is deprecated so Pronamic wil no longer support and maintain this plugin.
> 
> If you want to help maintain the plugin, fork it on [GitHub](https://github.com/pronamic/wp-parcelware) and open pull requests.


== Installation ==


== F.A.Q. ==


== Screenshots ==


== Changelog ==

= 1.0.1 =
*	Added an deprecated notice.

= 1.0.0 =
*	Added default XML row in the export.
*	Updated support for WooCommerce version 2.2.11.

= 0.3.2 =
*	Updated README

= 0.3.1 =
*	Changed to use a blank space in place of Surname for missing Company name

= 0.3.0 =
*	New settings page for documentation and Pronamic information

= 0.2.3 =
*	Fixed bug with items not correctly being added
*	Can now specify XML items

= 0.2.2 =
*	Fixed bug with housenumbers like 88a and 88-90.

= 0.2.1 =
*	Fixed 'Error jQuery image editor, switch WYSIWYG / HTML' by updating jquery-ui-min.js to version 1.9.2.

= 0.2 =
*	WooCommerce parser fixed to output a correct CSV file that can be handled by Parcelware
*	Redistributed functions to be able to have a specific parser to take over.

= 0.1 =
*	Initial release
