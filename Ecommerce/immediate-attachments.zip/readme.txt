=== Immediate Attachments ===
Contributors: illutic, onexa
Donate link: 
Tags: email, attachments
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 0.4

== Description ==

Immediate Attachments is a plugin that gives you the ability to present downloads to your visitors and receive a message immediately after the attachment(s) have been sent.

Please visit the [Immediate Attachments plugin page - Dutch](http://hiranthi.nl/wordpress/snelle-bijlagen/) for more information.


== Installation ==

Put the imm-att folder inside your wp-plugins folder. The pugin has not been tested with WP MultiSite.


== Frequently Asked Questions ==

-

== Screenshots ==

Please visit the [Immediate Attachments plugin page - Dutch](http://hiranthi.nl/wordpress/snelle-bijlagen/) for screenshots & user examples.


== Changelog ==
= 0.4 =
* Form action URL fixes

= 0.3.1 =
