=== Plugin Name ===
Contributors: merlinmonmouth
Donate link: http://www.jem-products.com
Tags: woocommerce
Requires at least: 4.0
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a simple Minimum Order Amount to Woocommerce

== Description ==
Adds a simple Minimum Order Amount to Woocommerce

Just enter the amount and a message - it's that simple!


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `woocommerce-minim-order.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Is it really that easy? =

Yes! I built this to be as simple as possible


== Screenshots ==

1. The admin screen
2. An example error message

== Changelog ==

= 1.0 =
* Initial version

== Upgrade Notice ==

= 1.0 =
Initial version


