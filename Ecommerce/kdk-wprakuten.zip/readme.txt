=== Rakuten product ===
Contributors: johna1203
Tags: shortcode, rakuten, kodokuman,楽天,アフィリエイト,affiliate
Requires at least: 3.1
Tested up to: 3.4
Stable tag: 0.4.2.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Search Rakuten product and add shortcodes!

== Description ==
現在はショートコードを利用して、楽天の市場の商品、楽天ブックスを投稿に表示させる事ができます。
前回と比べてかなりよくなりました、自分のアフィリエイトID追加ができるし！

後、いろんな工夫もしています！
AJAXを利用して、楽天にリクエストしているからプラグインのせいで
ページの表示が遅くなる事はないです。

今は商品検索と書籍検索だが、他のサービス対応する為に開発が進められています。

完全に生まれ変わった、Rakuten productを是非試してみて下さい！

バグがあれば、教えて下さい Twitter : @johna1203
もしくは、サーポートページまでお問い合わせください、http://blog.kodokuman.com/kdk-wprakuten-support/


== Screenshots ==

1. [メディア追加の画面]
アップロード/挿入ボタンから、メディア追加ウィンドウの"楽天"タブから開く商品を検索する事が出来ます。

2. 書籍検索や商品検索 screenshot-2.png
検索すると下に商品が表示されます。

3. コード追加ボタン screenshot-3.png
コード追加ボタンをクリックする事で、投稿にショートコードが追加されます。

4. ショートコードが追加された！ screenshot-4.png
これで、投稿にショートコードが追加されました。
後は、投稿を公開するだけです。

5. ブログの画面 screenshot-5.png
ショートコード付きで、記事を公開すると楽天の商品や本の画像が表示されます。

== Changelog ==

= 0.4.2.4 =
*　商品を検索した際に、件数などを表示
* 古いバージョンのショートコードに対応させました。

= 0.4.2.3 =
* IE8に対応させました。

= 0.4.2.2 =
* バグ修正
* 画面に”すべて表示”ってあらわれていた！それを削除

= 0.4.0 =
* 検索オプションが増えた。
* 専用タブになった。
* パフォーマンスの強化
