=== WooCommerce Billink plugin ===
Contributors: Tussendoor
Tags: tussendoor, billink, woocommerce, gateway
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 1.1.8

== Description ==


= Nederlands / Dutch =
Meer informatie via: [klik hier](http://www.tussendoor.nl/wordpress-plugins/wordpress-woocommerce-billink-plugin/)

= Engels / English =
More info: [click here](http://www.tussendoor.nl/wordpress-plugins/wordpress-woocommerce-billink-plugin/)

== Changelog ==

= 1.1.7 =
*	Added translation for Chamber of Commerce

= 1.1.7 =
*	Not displaying errors fixed

= 1.1.6 =
*	Now compatible with WooCommerce 2.3.8

= 1.1.5 =
*	Bug fixes

= 1.1.4 =
*	Bug fixes

= 1.1.3 =
*	Added support for WordPress 3.9

= 1.1 =
*	WooCommerce actief check
*	KvK validatie

= 1.0 =
*	Initial release

== Translations ==

* 	nl_NL 
* 	en_EN

== Links == 
*	 Will follow
