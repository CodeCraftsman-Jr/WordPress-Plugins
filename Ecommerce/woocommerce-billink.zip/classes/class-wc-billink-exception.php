<?php
/**
 * WooCommerce Billink Exception Class
 * 
 * @class WC_Billink_Exception
 */
class WC_Billink_Exception extends Exception {

}
