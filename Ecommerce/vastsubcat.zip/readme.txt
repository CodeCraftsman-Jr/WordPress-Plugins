=== VastSubCat 0.9 ===Contributors: asafche
Donate link: http://wordpress.freeall.org/?page_id=344
Tags: admin, Categories, Category, Write, Post, list, checklist
Requires at least: 2.8
Tested up to: 2.9
Stable tag: trunk
Show vast categories and sub-categories with collapsable list in edit post admin panel 

== Description ==

This plugin was created for overcome situations when you have 11 categories & 170 sub-categories (true story!) and you're trying to find a specific one, for taggin' a post in it.

The plugin remove the default categories checklist, and puts a collapsable list that makes it easy on such cases.

I've used some code structure of Kevin Lanteri's plugin "Admin-only Category". thanks.

This plugin was built with funding of [http://www.bashro.co.il/about.php](http://www.bashro.co.il/about.php "www.bashro.co.il").

Note: for now, doesn't support category tree's of depth > 1. 

== Installation ==

1. Upload `VastSubCat` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Choose `VastSubCat` in the plugin menu within the admin panel, for turn on/off the hirarchal lock of categories.

== Frequently Asked Questions ==

For all questions, please contact me @ asaf@freeallweb.org

== Changelog ==
= 0.9 = 
* BugFix: Now support IE8 also.

= 0.8 = 
* Adedd: an admin panel setting page
* Upgraded: toggle on/off for locking the categories in hirarchal mode
* BugFix: The Popular categories tabis back

= 0.7 =
* Plugin released!

== Donation ==
**You can help** us continue developing, [here](http://wordpress.freeall.org/?page_id=344 "Donate.").
