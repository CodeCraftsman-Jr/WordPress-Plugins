<div>
 <img src='{image_src}' alt='{image_alt}' />
 <h2>{image_title}</h2>
 <p>{image_description} <a href='{image_link}'>more</a></p>
</div>