<div class="orbisius_cyberstore">
    <?php Orbisius_CyberStoreUtil::output_orb_widget('author'); ?>
</div>

