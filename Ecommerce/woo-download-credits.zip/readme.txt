=== Woo Download Credits ===
Contributors: brandonmuth,pankajagrawal
Donate link: http://muth.co/
Tags: credits, download credits
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Lets your customers buy "download credits" in bulk, then use those credits for downloadable/virtual products in your Woo Commerce shop.

== Description ==
Woo Download Credits lets you sell products in your Woo Commerce shop using credits which customers can buy in bulk, then use towards individual products. Customers purchase credits, then each time they buy a product using Download Credits, credits are deducted from their account. They can replenish their credits when needed. 

== Installation ==

You may directly upload the zip folder from admin or place the extracted files in wp-content/plugins directory. Once installed, navigate to Woo Commerce > Download Credits to set your pricing / credits structure. Then, on each individual Woo product, look for the Credits Required for Download field and enter the value of your choosing.

== Frequently Asked Questions ==



== Screenshots ==

1. screenshot-1
2. screenshot-2
3. screenshot-3
4. screenshot-4
5. screenshot-5
6. screenshot-6
7. screenshot-7


