=== WooCommerce Simple Registration ===
Contributors: Astoundify, SpencerFinnell
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=contact@appthemer.com&item_name=Donation+for+Astoundify WP Job Manager Regions
Tags: woocommerce, woocommerce registration, woocommerce register, woocommerce registration form, woocommerce form
Requires at least: 3.6
Tested up to: 4.2.1
Stable tag: 1.0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

A simple plugin to add a [woocommerce_simple_registration] shortcode to display the registration form on a separate page.

== Description ==

A simple plugin to add a [woocommerce_simple_registration] shortcode to display the registration form on a separate page.

== Installation ==

1. Upload the folder `woocommerce-simple-registration to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the shortcode `woocommerce_simple_registration` on a self-created page to display the registration form.

== Changelog ==

= 1.0.1 =

* woocommerce-simple-registration.php author, version text changes.

= 1.0.0 =

* Initial release
