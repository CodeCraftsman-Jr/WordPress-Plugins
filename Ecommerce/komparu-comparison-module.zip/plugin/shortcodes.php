<?php

$plugin->shortcode->add('compmodule', 'compmodule');