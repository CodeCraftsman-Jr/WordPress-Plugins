=== Komparu Comparison Module ===
Contributors: Komparu B.V.
Tags: komparu, compare
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: 1.0.17

Enables easy embedding with komparu.com comparison widgets into your posts.

== Description ==
Please note that this plugin requires registration at “partner.komparu.com” backend. And requires connection available to “api.komparu.com”.

Enables easy embedding with komparu.com comparison widgets into your posts.

Login to your Komparu account, get a list of your sites and easily embed them into your Wordpress post or page.

Plugin is cloaking all Komparu links pretending like there\'s no additional software installed.

== Installation ==
1. Go to your WordPress admin section. Then navigate to “Plugins” → “Add New”
2. Then click “Upload Plugin” button at the top of the screen.
3. Drag and dropp your compmodule.zip file to the file input. Or click “Choose file” and then find it on your computer. Then click “Install Now”. This will install plugin on your WordPress.
4. After the file is uploaded you will see a screen offering you to activate the plugin. Please, activate it.
5. When you activate Komparu plugin you will see a warning saying that you have to enter your Komparu credentials.
6. Enter your Username and Password with which you are logging into your partner backend of Komparu. Leave X-Auth-Domain and API call frequency as they are by default. Please change them only if you are 100% sure what you are doing.
7. When you have your credentials set the warning message would disappear. You will be able to see all your websites listed on one page.
8. Copy the shortcode to the clipboard for the site you want to embed into specific page. And paste it into the text editor. Please note that even though you can have more than one shortcode embedded on single page, we would not recommend this.
9. Save the page. You will your widget embedded on your website.
