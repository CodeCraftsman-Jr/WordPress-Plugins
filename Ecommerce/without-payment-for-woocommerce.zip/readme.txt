=== Without payment for WooCommerce ===
Contributors: northmule
Donate link: http://www.zixn.ru/
Tags: without, payment getaway, woo commerce, woocommerce, ecommerce
Requires at least: 3.6
Tested up to: 4.1
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 		
Payment gateway woocommeerce, without charge or obligation. Payment for the goods only after a call to the store Manager.

== Description ==

* Платёжный шлюз woocommeerce, без оплаты и обязательств. 
* Оплата товара только после звонка менеджера магазина.
* Платёжный шлюз подойдёт интернет магазином не определившимся с оплатой или если вы предлагаете консультацию по товару или услуги и только потом предлагаете клиенту способы олпаты.

Если возникнут проблемы, [сообщите об ошибке](http://www.zixn.ru/plagin-payment-woocommerce.html)


== Installation ==
1. Убедитесь что у вас установлена посленяя версия плагина [WooCommerce](http://www.woothemes.com/woocommerce)
2. Распакуйте архив и загрузите "without-payment-woocommerce" в папку ваш-домен/wp-content/plugins
3. Активируйте плагин

== Screenshots ==
1. Общие настройки шлюза. 
2. То что видят клиенты.
3. Подтверждение заказа.
4. Ваша страница уведомления о подтверждение заказа.


== Changelog ==
= 1.2.1 =
* fix empty cart order
= 1.2 =
* Теперь нет проверки валюты магазина
* У всех созданных заказов статус «В обработке»
= 1.1 =
* Добавлены дополнительные опции
= 1.0 =
* Релиз

