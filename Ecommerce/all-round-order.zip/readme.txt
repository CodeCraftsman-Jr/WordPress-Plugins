=== All Round Order ===
Contributors: itsjinlie 
Tags: page order,post order,custom post type order, attachment order
Requires at least: 3.6 or higher
Tested up to: 4.1.0
Stable tag: 1.1.0

Order all items(Pages, Posts, Custom Post Types and attachments) easily with a drag and drop feature

== Description ==

This plugin let you order all items(pages, posts, custom post types and attachments) easily by using a drag and drop sortable javascript.

No configuration is necessary.

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

== Changelog ==
= 1.0.0 =
Initial Release
= 1.1.0 =
Fix issue on wordpress 4.1
