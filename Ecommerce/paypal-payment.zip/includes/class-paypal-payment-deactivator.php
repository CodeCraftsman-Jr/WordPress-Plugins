<?php

/**
 * @class       MBJ_PayPal_Payment_Deactivator
 * @version	1.0.0
 * @package	paypal-payment
 * @category	Class
 * @author      johnny manziel <phpwebcreators@gmail.com>
 */
class MBJ_PayPal_Payment_Deactivator {

    /**
     * @since    1.0.0
     */
    public static function deactivate() {
       
    }

}
