<?php
global $wpdb, $woocommerce;
?>
    <div id="yith-wsfl-messages"></div>

<?php yit_plugin_get_template(YWSFL_DIR, 'saveforlater-' . $template_part . '.php', $atts ) ?>