//var fullscreen_galleria_url = '';
var fullscreen_galleria_postid = 0;
var fsg_settings = {"transition": "slide", "overlay_time": "2222", "show_title": true, "show_description": true, "show_camera_info": true, "show_thumbnails": true, "show_permalink": false, "show_attachment": true, "show_caption": false, "show_sharing": false, "image_nav": false, "auto_start_slideshow": false, "true_fullscreen": true, "w3tc": false, "load_in_header": true};
var fullscreen_galleria_attachment = true;
var fsg_photobox = {};
var fsg_json = {};
