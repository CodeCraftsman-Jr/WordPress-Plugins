<h3 class="dashboard_widget_title">
	<span><?php self::_e('Invoice Status') ?></span>
</h3>
<div class="dashboard_widget inside">
	<div class="main">
		<a href="<?php si_purchase_link() ?>" target="_blank">Upgrade</a> for this chart and more.
	</div>
</div>