<div id="send_doc_options_wrap" class="admin_fields clearfix">
	<?php sa_admin_fields( $fields, 'send_metabox' ); ?>
	<div id="quick_send_option" class="form-group">
		<span class="label_wrap">&nbsp;</span>
		<div class="input_wrap">
			<a href="javascript:void(0)" class="button" id="send_doc_notification"><?php si_e('Send Estimate') ?></a> <span class="helptip" title="<?php si_e("Make sure to save all information before sending your estimate.") ?>"></span>
		</div>
	</div>
	
</div>