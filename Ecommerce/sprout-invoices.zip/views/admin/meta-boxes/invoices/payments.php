<div id="admin_payments_options_wrap" class="admin_fields clearfix">
	<?php sa_admin_fields( $fields ); ?>
	<div id="admin_payments_option" class="form-group">
		<span class="label_wrap">&nbsp;</span>
		<div class="input_wrap">
			<a href="javascript:void(0)" class="button" id="add_admin_payments"><?php si_e('Quick Add') ?></a> <span class="helptip" title="<?php si_e("Add the payment now or save/update the invoice above") ?>"></span>
		</div>
	</div>
	
</div>