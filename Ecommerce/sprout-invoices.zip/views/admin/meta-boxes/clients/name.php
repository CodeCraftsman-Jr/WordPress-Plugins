<div id="subject_header" class="clearfix">
	<?php $title = ( $status != 'auto-draft' ) ? get_the_title( $id ) : '' ; ?>
	<h2><?php echo esc_html( $title ); ?></h2>
</div>