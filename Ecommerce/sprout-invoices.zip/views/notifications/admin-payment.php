---------------------------------------------
Payment Summary
---------------------------------------------

Invoice ID: [invoice_id]
[invoice_edit_url]
Client: [client_name]
[client_edit_url]
Invoice Total: [invoice_total]
Payment Total: [payment_total]
All Payments: [invoice_total_payments]

---------------------------------------------
