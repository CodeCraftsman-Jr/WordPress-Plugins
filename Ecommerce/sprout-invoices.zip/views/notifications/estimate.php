[name]

[admin_note]

---------------------------------------------
Estimate Summary
---------------------------------------------

[estimate_subject]

Estimate ID: [estimate_id]
Estimate date: [estimate_issue_date]
Client: [client_name]
P.O. Number: [estimate_po_number]
Amount: [estimate_total]

[line_item_plain_list]

You can view the estimate here:
[estimate_url]

Thank you!
---------------------------------------------
