---------------------------------------------
Estimate Accepted
---------------------------------------------

[estimate_subject]

Invoice Created: [invoice_id]
[invoice_edit_url]

Estimate ID: [estimate_id]
[estimate_edit_url]
Client: [client_name]
[client_edit_url]
Amount: [estimate_total]

Nice Work!

---------------------------------------------
