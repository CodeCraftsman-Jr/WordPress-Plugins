---------------------------------------------
Payment Summary
---------------------------------------------
[name]

[invoice_subject]

Invoice ID: [invoice_id]
Issue date: [invoice_issue_date]
Client: [client_name]
P.O. Number: [invoice_po_number]
Amount: [invoice_total]
Payment Total: [payment_total]
Payments: [invoice_total_payments]

The detailed invoice can be found here: [invoice_url]

Thank you for your business.
---------------------------------------------
