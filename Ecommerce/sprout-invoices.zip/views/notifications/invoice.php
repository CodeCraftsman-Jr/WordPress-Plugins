[name]

[admin_note]

---------------------------------------------
Invoice Summary
---------------------------------------------

[invoice_subject]

Invoice ID: [invoice_id]
Issue date: [invoice_issue_date]
Client: [client_name]
P.O. Number: [invoice_po_number]
Amount: [invoice_total]
Deposit Due: [invoice_deposit_amount]
Due: [invoice_due_date]
Payments: [invoice_total_payments]

[line_item_plain_list]

The detailed invoice can be found here: [invoice_url]

Thank you!
---------------------------------------------
