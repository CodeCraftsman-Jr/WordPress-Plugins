Dear [name],

This is a friendly reminder to let you know that Invoice [invoice_id] is [invoice_past_due_date] days past due. If you have already sent the payment, please disregard this message. If not, we would appreciate your prompt attention to this matter.

Thank you for your business.

Cheers!
