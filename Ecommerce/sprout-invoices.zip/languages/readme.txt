********************************************************

  Sprout Invoices i18n
  ====================
  
  Do not put custom translations here. They will be deleted
  on update.
  
  Keep custom translations in /wp-content/languages/sprout-apps/
  
  You want to translate, help, or improve a translation.
  
  Join our WP-Translations Community at
  https://www.transifex.com/projects/p/sprout-invoices/

  More info at http://wp-translations.org/

********************************************************
