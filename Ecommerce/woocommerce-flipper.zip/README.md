WooCommerce Flipper
=================================

 A very simple plugin that Show's Front and backside view of any product.
