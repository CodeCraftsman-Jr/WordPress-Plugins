=== WooCommerce Flipper ===
Contributors: aumsrini
Donate link:http://beeplugins.com/donations/
Tags: woocommerce, ecommerce, product, images, photos, product photos, front and back
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

To Show Front and backside view of any product.

== Description ==

A very simple plugin that Show's Front and backside view of any product in woo commerce.

You Can View Live Demo Here http://wallpapermass.com/wcflipper/

After install the plugin go to product list page and see the changes.

No short code need for this plugin,becuase it is a built in functionality.

= Need Support ? =

*Visit here for support http://beeplugins.com/forums/?forum=2&topic=1&current_page=1

= Support the plugin =
 
*If you've found the plugin useful, consider making a [donation via Our Website] http://beeplugins.com/donations/  "Donate via our website"

= Upgrade To Pro Version =

Get Pro version Here http://beeplugins.com/product/woocommerce-flipper-pro

**Features**

**Animation**

- 1.Horizontal Flip
- 2.Vertical Flip
- 3.Fade In
- 4.Slide From Down
- 5.Slide From Up
- 6.Slide From Right
- 7.Slide From left

**Category options unlimted**

Select which categories of product want to be flip For example T-shirt,Mobiles to show front and back side view.

== Frequently Asked Questions ==

= How do I control which image is displayed on hover? =

Whichever image is first in the order of product gallery images will appear on hover.

= My secondary image is taller than the main product image and overlaps content when it fades in =

This is due to the secondary image being positioned absolutely. This is the cleanest way I can think to do this with CSS alone. You may want to consider hard cropping your product catalog thumbnails to ensure all images are the same dimensions in product archives.

= It doesn't work. Nothing happens when I hover over images? =

First of all check that the product you're checking has a gallery attached to it. Secondly you should be aware that this plugin uses CSS 3d transforms and will therefore only work in modern browsers.

Please feel free to contribute on <a href="https://github.com/rohithseenu">github</a>.

Note: This plugin uses CSS 3d transforms to show/hide the images and will therefore only work in modern browsers.

== Installation ==

1. Upload `woocommerce-flipper` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!


== Screenshots ==

1. A flipped image.

== Changelog ==

= 0.1 =
* Fix - WooCommerce 2.3.2 compatibility

= 0.1 =
Initial release.
