=== Plugin Name ===
Contributors: adaneasa
Tags: wishlists, cadouri, widgets
Requires at least: 2.0.2
Tested up to: 2.8.6
Stable tag: 0.3

Acest plug-in va ajuta sa publicati listele de cadouri din MakeMeHappy in blogul vostru ca si widget intr-un bara laterala
------------------------------------------
Using this plugin you can integrate your MakeMeHappy wishlists into WordPress as a sidebar widget

== Description ==

Acest plug-in va ajuta sa publicati listele de cadouri din MakeMeHappy in blogul vostru ca si widget intr-un bara laterala
------------------------------------------
Using this plugin you can integrate your MakeMeHappy wishlists into WordPress as a sidebar widget

== Installation ==

1. Incarcati `makemehappy.php` in folderul `/wp-content/plugins/` 
2. Activati pluginul din meniul 'Plugins' din WordPress
3. Alegeti parametrii pluginului in sectiunea Widgets a meniului 'Appearance' in Wordpress
------------------------------------------
1. Upload `makemehappy.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Set plugin parameters into Widgets section of 'Appearance' menu in Wordpress

== Frequently Asked Questions ==

Vizitati http://www.makemehappy.ro daca aveti intrebari. Multumim!
-------
Please visit http://www.makemehappy.ro if you have any questions. Thank you!


== Screenshots ==

1. Activare plugin
2. Configurare plugin din Appearance-Widgets
3. Rezultatul in blog
-------
1. Plugin activation
2. Plugin configuration via Appearance-Widgets
4. The result shown in your blog

== Changelog ==

= 0.3 =
* imbunatatiri design
-------
* design improvements

= 0.2 =
* Inlocuit include cu DomDocument();
-------
* Changed include() to DomDocument();

= 0.1 =
* Prima versiune ce s-a dovedit a nu functiona pe anumite hosturi datorita functiei include(url extern)
-------
* Initial release, proven not to work on some hosts due to include(external url) usage
