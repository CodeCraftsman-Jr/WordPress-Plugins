=== Multisite Ads ===
Contributors: EWSEL
Tags: multisite, head, wp_head, code, include
Donate link: http://ewsel.com/donate
Requires at least: 3.2
Tested up to: 3.4.1
Stable tag: trunk

Includes custom HTML/CSS/JS code in the network.

== Description ==

Includes custom HTML/CSS/JS code in the network.

Very simple, but sometimes useful plugin.

After activation visit Network Admin --> Settings --> Multisite Ads for setup. Nothing else is needed.

Developed for private use, but has perspective for more extensive usage. I can't guarantee any support in the future nor further development, but it is to be expected. Kindly inform me about bugs, if you find any, or propose new features: [info@ewsel.com](mailto:info@ewsel.com?subject=[multisite-Ads]).

== Frequently Asked Questions ==

[Ask me](mailto:info@ewsel.com?subject=[multisite-Ads]).

= What to do if my code isn't inserted into some blogs? =

Ensure that all used templates use the wp_head function. See [WordPress Codex](http://codex.wordpress.org/Function_Reference/wp_head) for more information.

== Changelog ==

= 1.1 =
* translation Option Add
* added donation button on settings page
* Option Page Add
