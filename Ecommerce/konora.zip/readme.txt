=== Konora Form ===
Tags: konora, newsletter, autoresponder
Requires at least: 3.4
Tested up to: 3.9.1
Stable tag: 0.9.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Invia newsletter e autorisponditori con Konora.com

== Description ==

Questo plug-in ti permette di inviare newsletter e autorisponditori interfacciando il 
tuo blog con i servizzi messi a disposizione dal portale [Konora]: www.konora.com

== Installation ==

1. Decomprimi il pacchetto contenente il plugin della giusta directory di WordPress
2. Attiva il plugin dal menu 'Plugins' in WordPress
3. Apri la pagina 'Opzioni Konora' dal menu 'Impostazioni'


== Screenshots ==

1. Page of advertising

== Changelog ==

= 0.9.3 =
* Correct bug in form.php

= 0.9.2 =
* Sostituita la chiamata js alle statistiche con il pixel tracking
* Correct some bugs

= 0.9.1 =
* Migliorato lo script per i form

= 0.9 =
* Salvataggio in locale dei dati inviati
* Il form funziona anche senza il supporto javascript
* Le pagine di tipo leads possono essere disabilitate dall'opzione apposita
* Migliorate le prestazioni del plugin
* Corretti bug minori

= 0.8.5 =
* Correct some bugs

= 0.8.4 =
* Aggiunto l'opzione signup, recurrence e pack nei form

= 0.8.3 =
* Aggiunto l'indirizzo completo nel form

= 0.8.2 =
* Il cookie dello sponsor viene cancellato ogni volta che l'admin entra nel pannello
* Divise le funzioni in public e admin

= 0.7 =
* Aggiunte le le pagine di tipo lead
* Aggiunto l'opzione per selezionare i campi da visualizzare nel fomr
* Aggiunta l'opzione redirect nei form
* Migliorato il supporto al multiblog
* I form sono stati ottimizzati per il mobile
* Corretti bug minori

= 0.6 =
* Migliorate le prestazioni del plugin
* Migliorato il supporto a form multipli all'interno della stessa pagina
* Sostituito l'uso delle librerie curl con l'istruzione file_get_contents() per migliorare la compatibilita'
* Aggiunto il pdf della documentazione all'interno del plugin
* Corretti bug minori

= 0.5 =
* Aggiunto la possibilità di scegliere un foglio di stile diverso per ogni form
* Aggiunte tutte le funzioni di modifica di un form nel widjet

= 0.4 =
* Verifica della corretta formattazione della mail nel form e reso campo obbligatorio
* Riorganizzato il menu delle opzioni
* Corretti bug minori

= 0.3 =
* Aggiunto il widjet
* Invio di una newsletter ogni volta che viene pubblicato un nuovo post
* Migliorata la pagina delle impostazioni

= 0.2 =
* Gli utenti che si registrano su WP vengono registrati su un circolo di Konora

= 0.1 =
* Aggiunto lo shortcode [konora] per visualizzare un form all'interno di una pagina
