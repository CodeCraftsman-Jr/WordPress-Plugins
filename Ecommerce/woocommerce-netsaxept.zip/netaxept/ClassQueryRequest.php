<?php

class QueryRequest {
  
 public $TransactionId;

 
 function QueryRequest   (
        $TransactionId
   )
   {
        $this->TransactionId = $TransactionId;

   }
};

?>
