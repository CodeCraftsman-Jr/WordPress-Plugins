===Woocommerce Netaxept===
Contributors: (iwcontribution)
Tags: WooCommerce Netaxept, WooCommerce extension
Requires at least: 4.2.2
Tested up to: 4.2.2
Netaxept allows secure payment.
==Description==
This is Woocommerce Netaxept Payment Gateway extension which helps to make payment securely.
== Installation ==
1.Download the Netaxept Payment Gateway plugin zip file and extract to the  `/wp-content/plugins/` directory.
2.Activate the plugin through the 'Plugins' menu in WordPress Admin.
== Screenshots ==
1. WooCommerce Backend Settings "Checkout" page.
2. At the bottom you will get different payment gateways where you have to select Credit Card Payment with Gateway ID "ps_nets_payment".
3. Then go to settings of this gateway. Fill the form with credentials as it is shown on the above screenshort.
4. This is Front-End Checkout Page where you have to select Credit Card Payment nets.
= 1.0 =
The First Release

