Clazz.declarePackage ("J.console");
Clazz.declareInterface (J.console, "GenericTextArea");
