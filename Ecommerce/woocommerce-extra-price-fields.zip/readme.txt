=== Woocommerce Extra Price Fields ===
Contributors: aman086
Donate link: http://amansaini.me/
Requires at least: 3.0.5
Tags:woocommerce,ecommerce,woocommerce price extension
Tested up to: 4.2
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Woocommerce Extra Price Fields is Plugin for adding extra price description to show in front end.

== Description ==

Woocommerce Extra Price Fields is Plugin for adding extra price description to show in front end.

It can  be used to show extra info with price e.g $250 per 100gm

= Features: =

* Supports latest woocommerce
* Automatically shows price in front end , no setting required
*  Please send me your feedback  <a href="http://amansaini.me/contact/">here</a> for any new features you want to see in next version of this plugin.I will be glad to receive feedback.

= Want to contribute =

If you want to contribute , please check the github repo
https://github.com/aman086/Woocommerce-extra-price-fields


== Installation ==

To install Woocommerce Extra Price Fields, follow these steps:

1.	Download and unzip the plugin
2.	Upload the entire woocoomece-extra-price-fields/ directory to the /wp-content/plugins/ directory
3.	Activate the plugin through the Plugins menu in WordPress

== Frequently Asked Questions ==

= How to use it? =

Install it and edit/create a new product. Add the info into the newly created fields under price box.For more Info check the screenshots.

= Have Feedback =
Please send me your feedback  <a href="http://amansaini.me/contact/">here</a> for any new features you want to see in next version of this plugin.I will be glad to receive feedback.


== Screenshots ==

1. Front End
2. Backend



== Changelog ==
= 1.4 =
* Fixed issue with info not showing up for variable prices.

= 1.3 =
* Fixed warnings.

= 1.2 =
* Now works with variable products.


= 1.1.1 =
* Changed the field to string from number in admin
* Updated backend screenshot

= 1.1 =
* updated the plugin to have any text in frontend


= 1.0 =
* First stable version released.


== Upgrade Notice ==

= 1.0 =
* First stable version released.


