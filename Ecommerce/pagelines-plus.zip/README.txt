=== PageLines Plus ===
Contributors: highergroundstudio
Donate link: http://highergroundstudio.com/
Tags: pagelines, section, uploader, installer
Requires at least: 2.0.2
Tested up to: 3.4
Stable tag: 1.1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A Wordpress plugin to add enhancements to Pagelines.

== Description ==

A Wordpress plugin to add enhancements to Pagelines. Currently includes a 3rd party section installer. It's created and maintained by [Kyle King](http://twitter.com/HighrGrndStudio) at Higher Ground Studio.


== Installation ==

1. Upload `pagelines-plus` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.1.0 =
* First stable release to Wordpress.org