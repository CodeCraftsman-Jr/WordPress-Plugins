=== WooCommerce Multi Item Slider ===
Contributors: aumsrini
Donate link:http://beeplugins.com/donations/
Tags: woocommerce, ecommerce, product,slider,images slider,photos slider, product photos, category slider
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Woocommerce Multi Category items slider.

== Description ==

woocommerce category slider with a minimal design using CSS animations and jQuery.

After install the plugin use this shortcode [wc_item_slider] anywhere in post or pages


= Need Support ? =

Visit here for support http://beeplugins.com/forums/?forum

= Support the plugin =
 
*If you've found the plugin useful, consider making a donation via Our Website http://beeplugins.com/donations/  for our future works.

== Frequently Asked Questions ==

= How do I select  category for four navigations?

You can go to Wc Slider Settings in admin panel and select which categoery did you  need to promote ? then save changes.


= It doesn't work. Nothing happens after install ? =

First of all check that you have installed woocommerce plugin. Secondly you should check there is any products in your  selected catregory.


Note: This plugin uses modernizr for enabling animations in all devices.

== Installation ==

1. Upload `woocommerce-multi-item-slider` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!


== Screenshots ==

1. Four Category navigation screen.
2. Admin Category Settings screen.

== Changelog ==

= none =

= 0.1 =
Initial release.


== Upgrade Notice ==

= none =
