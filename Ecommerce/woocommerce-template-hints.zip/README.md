#WooCommerce Template Hints#

##Description ##

If this plugin is active then a frame will be inserted around each template that is used by WooCommerce showing the 
file name. Default WooCommerce templates are red and overridden templates are blue.

Hovering over the template name gives the full path of the template being used.

The frames will only be visible to users with 'edit_posts' access. 