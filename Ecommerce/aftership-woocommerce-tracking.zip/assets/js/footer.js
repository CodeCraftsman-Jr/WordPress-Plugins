setTimeout(function(){
	aftership_woocommerce_tracking_onload();
}, 2000);