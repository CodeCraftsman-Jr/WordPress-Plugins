=== SureGifts WooCommerce ===
Contributors: michaael_adeyeri
Donate link:
Tags:
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 4.3
Stable tag: 3.0

Integrates SureGifts gift card codes with your store’s coupon/discount field on cart/checkout page

== Description ==

Integrates SureGifts gift card codes with your store’s coupon/discount field on cart/checkout page


== Installation ==
1.	Register your online store as a merchant to obtain authentication details by filling the contact form at www.suregifts.com.ng/partner-merchant
2.	Upload 'SureGifts WooCommerce' to the '/wp-content/plugins/' directory
3.	Activate the plugin through the 'Plugins' menu in WordPress Plugins Area


== Frequently Asked Questions ==

= Do I need to be a registered merchant with www.suregifts.com.ng? =

Yes

= How do I get my username and password? =

Fill the contact form at www.suregifts.com.ng/partner-merchant or send an e-mail to hello@suregifts.com.ng

== Screenshots ==
1. screenshot-1.png

== Changelog ==

= 1.0.0 =
- Initial Release


== Upgrade Notice ==

= 1.0.0 =
- Initial Release

= 1.0.3 =
- Minor bug fixes

= 1.0.4 =
- Minor bug fixes

= 1.0.5 =
- Minor bug fixes


= 1.2 =
- Add checkout validation logic

= 1.2 =
- Bug fixes

= 3.0 =
- updated API endpoints
-New Authentication logic implemented
