=== Woocommerce to Google merchant center ===

Contributors: asaquzzaman
Tags: merchant center, google merchant center, woo merchant, woocommerce merchant, woocommerce product feed, google product feed, product feed, woocommerce feed, google feed
Requires at least: 3.3
Tested up to: 3.9.1
Stable tag: trunk
License: GPLv2 or later

== Description ==

Submit your product woocommerce to google merchant center.

= Features:  =

Submit your product woocommerce to google merchant center.
After google verification it will be appear in google shop.

This plugin has pro version you will get it from [here](http://mishubd.com/product/woogoo/)

This free verision has product submission limited. Here is available pro version for unlimited product submission.
You will get the por version from [here](http://mishubd.com/product/woogoo/)

[Documentation](http://mishubd.com/documentation/woocommerce-to-google-merchant-center/)

[youtube https://www.youtube.com/watch?v=ZAskOIV6tHk]

[Documentation](http://mishubd.com/documentation/woocommerce-to-google-merchant-center/)

== Installation ==

1. Unzip and upload the wogo directory to /wp-content/plugins/
2. Activate the plugin through the Plugins menu in WordPress

Browser Compatibility

1. Google Chrome
2. Firefox.

= Usage =

[Documentation](http://mishubd.com/documentation/woocommerce-to-google-merchant-center/)

== Screenshots ==

1. Screenshot Settings
2. Screenshot Add button
3. Screenshot Product submit form to merchant center
4. Screenshot Submission error
5. Screenshot Submit success message
6. Screenshot Merchant center view
7. Screenshot Delete button
8. Screenshot Delete button

== Changelog ==
Noting
== Frequently Asked Questions ==

You can contact with me joy.mishu@gmail.com with this email address. You can ask me any kinds of question about this plugin.

== Upgrade Notice ==

Nothing to say

Thanks for beign with me.