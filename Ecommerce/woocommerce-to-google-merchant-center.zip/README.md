=== Woocommerce to Google merchant center ===

Contributors: asaquzzaman
Tags: merchant center, google merchant center, woo merchant, woocommerce merchant
Requires at least: 3.3
Tested up to: 3.9.1
Stable tag: trunk
License: GPLv2 or later

== Description ==
[Documentation](http://mishubd.com/documentation/woocommerce-to-google-merchant-center/)

Submit your product woocommerce to google merchant center.

= Features:  =

Submit your product woocommerce to google merchant center.
After google verification it will be appear in google shop


== Installation ==

1. Unzip and upload the wogo directory to /wp-content/plugins/
2. Activate the plugin through the Plugins menu in WordPress

Browser Compatibility

1. Google Chrome
2. Firefox.

= Usage =

[Documentation](http://mishubd.com/documentation/woocommerce-to-google-merchant-center/)

== Screenshots ==



== Changelog ==
Noting
== Frequently Asked Questions ==

You can contact with me joy.mishu@gmail.com with this email address. You can ask me any kinds of question about this plugin.

== Upgrade Notice ==

Nothing to say

Thanks for beign with me.



