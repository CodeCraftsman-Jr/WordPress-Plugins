<div class="postbox">
	<h3 class="postbox-title"><?php _e( 'This feature is available for pro version', 'wogo'); ?></h3>
	<div class="wogo-feed-form-content">
		<a class="button button-primary" href="http://mishubd.com/product/woogoo/" target="_blank"><?php _e( 'Update to pro version', 'wogo' ); ?></a>
	</div>
</div>
