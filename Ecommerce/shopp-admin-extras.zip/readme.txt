=== Shopp Admin Extras ===
Contributors: crunnells
Tags: shopp, e-commerce
Requires at least: 3.1
Tested up to: 4.1
Stable tag: 1.0.1
License: GPLv2 or later

Adds navigation links on the Orders page and allows you to edit the order status inside the Order page.

== Description ==

Adds navigation links on the Orders page and allows you to edit the order status inside the Order page.

== Installation ==

Upload the Shopp Admin Extras plugin to your blog, then activate it. You're done!

== Changelog ==

= 1.0.1 =
*Release Date - 17th April, 2015*

* Yay, first bug report! Fixed a bug with the order status updater.

= 1.0 =
*Release Date - 16th April, 2015*

* Updated to bring up to speed for WP plugins directory

= 0.1 =
*Release Date - 27th April, 2013*

* First version release!
