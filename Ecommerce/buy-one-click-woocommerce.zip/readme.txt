=== Buy one click WooCommerce ===
Contributors: northmule
Donate link: http://www.zixn.ru/
Tags: woo commerce, woocommerce, ecommerce
Requires at least: 3.8
Tested up to: 4.2
Stable tag: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 		
Кнопка купить в один клик или Buy one click WooCommerce

== Description ==

Плагин является дополнением для Wordpress магазинов с установленным расширением WooCommerce. Buy one click WooCommerce добавляет кнопку «Заказать в один клик» в карточку товара.

Если возникнут проблемы, [сообщите об ошибке](http://www.zixn.ru/plagin-zakazat-v-odin-klik-dlya-woocommerce.html)


== Installation ==
1. Убедитесь что у вас установлена посленяя версия плагина [WooCommerce](http://www.woothemes.com/woocommerce)
2. Распакуйте архив и загрузите "buy-one-click-woocommerce" в папку ваш-домен/wp-content/plugins
3. Активируйте плагин
4. Перейдите в пункт меню «WooCommerce» - «BuyOneClick» для настройки дополнения

== Screenshots ==
1. Кнопка на сайте. 
2. Форма заказа.
3. Настройки дополнения.
4. Заказы.


== Changelog ==
= 1.2 =
* Добавлена поддержка СМС
= 1.1 =
* Исправлены некоторые ошибки в работе плагина
* Добавлена опция включения/отключения показа кнопки
* Добавлены опции «обязательные поля»
* Добавлены варианты поведения формы при отправке заказа
* В Шаблон email сообщения добавлены ФИО и Телефон клиента
= 1.0 =
* Релиз

