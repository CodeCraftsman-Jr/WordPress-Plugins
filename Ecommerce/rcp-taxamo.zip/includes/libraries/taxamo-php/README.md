=== Taxamo PHP bindings

This package provides [Taxamo](http://www.taxamo.com/) PHP bindings. 
