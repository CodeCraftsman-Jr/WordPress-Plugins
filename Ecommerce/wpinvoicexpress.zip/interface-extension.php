<?php

interface Extension {

	public static function enable();

}