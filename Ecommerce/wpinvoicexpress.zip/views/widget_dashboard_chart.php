<div class="invoicexpress-container">
	<canvas id="invoicexpress-chart" width="400" height="150">

	</canvas>
	<p class="loading">Loading data...</p>
</div>