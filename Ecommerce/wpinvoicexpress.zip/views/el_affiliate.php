<span class="affiliate-container">

<p>Don't have an <strong>Invoicexpress</strong> account yet?,
	<a href="https://www.app.invoicexpress.com/accounts/new?affiliate_token=ruicruz_amqa9&amp;language=pt" target="_blank">Sign up here</a>.
</p>

</span>