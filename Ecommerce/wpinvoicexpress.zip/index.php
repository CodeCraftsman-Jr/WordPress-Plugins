<?php
/**
 * Plugin Name: WPInvoicexpress
 * Plugin URI: http://barbershop.pt/wp-invoicexpress-plugin/
 * Description: Add finantial information to your Wordpress Dashboard from Invoicexpress.
 * Version: 1.0
 * Author: Rui Cruz @ barbershop.pt
 * Author URI: http://barbershop.pt
 */

require_once 'RCCore.php';