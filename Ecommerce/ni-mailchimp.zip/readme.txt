=== NI Mailchimp ===
Requires at least: 3.5.0
Tested up to: 4.1
Stable tag: 1.0