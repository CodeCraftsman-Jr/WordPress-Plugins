<?php
	//********************************************************************
	//Amazon Seller Template
	//2014-12
	//********************************************************************

/*** Basic ***/
	$this->addAttributeMapping('feed_product_type', 'feed_product_type',true,true)->localized_name = 'Product Type';
	$this->addAttributeMapping('', 'part_number', true)->localized_name = 'Mfr Part Number';
	$this->addAttributeMapping('', 'model', true)->localized_name = 'Model Number';
	
//connector_quantity, cable_length, read_speed, write_speed....
?>