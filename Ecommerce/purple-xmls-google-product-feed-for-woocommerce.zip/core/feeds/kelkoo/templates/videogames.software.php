<?php
	//********************************************************************
	//Kelkoo categories
	//Video games and software
	//2015-01 Calv
	//********************************************************************

	$this->addAttributeMapping('', 'software-platform', true, false); //Platform (i.e. XBox, PlayStation 2, etc.)

	
?>