<?php
	//********************************************************************
	//Kelkoo categories
	//Books category
	//2015-01 Calv
	//********************************************************************

	$this->addAttributeMapping('', 'book-author', true, false);
	$this->addAttributeMapping('', 'book-format', true, false);
	$this->addAttributeMapping('', 'book-edition', true, false);
	$this->addAttributeMapping('', 'book-publisher', true, false);
?>