<?php
	//********************************************************************
	//Kelkoo categories
	//Movies
	//2015-01 Calv
	//********************************************************************

	$this->addAttributeMapping('', 'movie-director', true, false);
	$this->addAttributeMapping('', 'movie-actors', true, false);
	$this->addAttributeMapping('', 'movie-region', true, false);
	$this->addAttributeMapping('', 'movie-media-rating', true, false);
?>