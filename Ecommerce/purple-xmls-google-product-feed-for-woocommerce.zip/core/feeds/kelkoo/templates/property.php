<?php
	//********************************************************************
	//Kelkoo categories
	//Property
	//2015-01 Calv
	//********************************************************************

	$this->addAttributeMapping('', 'property-type', true, false);
	$this->addAttributeMapping('', 'property-source', true, false);
	$this->addAttributeMapping('', 'propery-garage-parking', true, false);
	$this->addAttributeMapping('', 'property-city', true, false);
	$this->addAttributeMapping('', 'property-zip-code', true, false);
	$this->addAttributeMapping('', 'property-number-rooms', true, false);
	$this->addAttributeMapping('', 'property-surface', true, false);
	$this->addAttributeMapping('', 'property-publication-date', true, false);
	$this->addAttributeMapping('', 'property-tenure', true, false);
?>