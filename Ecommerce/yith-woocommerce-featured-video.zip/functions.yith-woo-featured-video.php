<?php
/**
 * Functions
 *
 * @author Your Inspiration Themes
 * @package YITH Woocommerce Featured Video
 * @version 1.1.0
 */

if ( !defined( 'YITH_WOO_FEATURED_VIDEO' ) ) { exit; } // Exit if accessed directly

