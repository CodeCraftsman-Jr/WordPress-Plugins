<a href="<?php echo $data['url']; ?>" class="SimpleEcommCartAddToCart <?php echo $data['class']; ?>"><?php echo $data['text']; ?></a>
