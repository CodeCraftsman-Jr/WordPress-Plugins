// US lang variables
tinyMCE.addI18n('en.simpleecommcart_dlg',{
simpleecommcart_desc : "Add SimpleEcommCart Product",
simpleecommcart_title : "SimpleEcommCart",
simpleecommcart_button_desc : "Add SimpleEcommCart Product"
});
