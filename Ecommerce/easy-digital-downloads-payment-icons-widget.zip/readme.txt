=== Easy Digital Downloads - Payment Icons Widget ===
Author URI: http://section214.com
Plugin URI: http://section214.com
Contributors: section214
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7FMLUWG3SMMJY
Tags: download, downloads, e-store, eshop, digital downloads, e-downloads, ecommerce, e commerce, e-commerce, selling, wp-ecommerce, wp ecommerce, edd, easy digital downloads, widget
Requires at least: 3.7
Tested up to: 4.1.1
Stable Tag: 1.0.0

Displays the accepted EDD payment method icons in the WordPress sidebar.

== Description ==

Displays the accepted EDD payment method icons in the WordPress sidebar, along with custom text above and/or below the icons.

**Follow this plugin on [GitHub](https://github.com/easydigitaldownloads/EDD-Payment-Icons-Widget)**

== Installation ==

1. Activate the plugin
2. Go to Appearance > Widgets and add the widget

== Changelog ==

= Version 1.0.0 (March 20, 2015) =

* Initial release!
