# WP-eCommerce-toolbar

A WordPress admin bar extension that allows for faster navigation with the WP eCommerce plugin.



