<?php
/**
 * Products Category Redirect page.
 */ ?>
<?php apptivo_ecommerce_get_template( 'product_taxonomy.php' ); ?>