=== Jigoshop Credimax ===
Contributors: ali_ashoor, a7madev
Tags: jigoshop, cart, checkout, ecommerce, shop, payment, gateway
Requires at least: 3.2
Tested up to: 4.1.1

This plugin extends the Jigoshop payment gateways to add in Credimax Payment Gateway.

== Description ==

This plugin extends the Jigoshop payment gateways to add in Credimax Payment Gateway.

It's created by <a href="http://github.com/A1iAshoor" title="Ali Ashoor">Ali Ashoor</a>.

Website: http://www.uskistudios.com
Contact: info[at]uskistudios.com

== Installation ==

1. Upload the `jigoshop-credimax-payment-gateway` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to `Jigoshop > Settings > Payment Gateways` to see your new payment gateway.

== Changelog ==

= 1.0.1 =
* Change description.

= 1.0.0 =
* Initial release.