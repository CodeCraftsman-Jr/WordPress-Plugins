<?php
define('GCL_ROWS_PER_PAGE', '20');
define('GCL_STATUS_DRAFT', '0');
define('GCL_STATUS_ACTIVE_BYUSER', '1');
define('GCL_STATUS_ACTIVE_BYADMIN', '2');
define('GCL_STATUS_ACTIVE_EXPIRED', '3');
define('GCL_STATUS_ACTIVE_REDEEMED', '4');
define('GCL_STATUS_PENDING', '7');
define('GCL_STATUS_PENDING_PAYMENT', '7');
define('GCL_STATUS_PENDING_NOSLOTS', '8');
define('GCL_STATUS_PENDING_BLOCKED', '9');
define('GCL_STATUS_ERROR_OFFSET', '100');
?>