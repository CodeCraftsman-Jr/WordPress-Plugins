=== Konverto ===
Contributors: Jörg_Burbach
Tags: plugin, link, convert, url
Description: Konverto converts every URL in your posts from something like www.domain.com into clickable links
Author URI: http://www.joerg-burbach.de
Plugin URl: http://joerg-burbach.de/plugin-fur-wordpress-konverto/
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=joerg.burbach%40quadworks%2ede
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: 1.1.0
License: GPLv2
 
== Description ==
 
This Plugin converts URLs from www.domain.com to a clickable link.

== Installation ==

1. Upload 'konverto' to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Activate in Preferences of Konverto

Optional:
* Set target to new page or same page
* Add title (which will use the original URL)
* convert mail-addresses to clickable links using mailto


== Changelog ==

1.1.0 - added support for links already clickable

== Frequently Asked Questions ==

1. Konverto removes information from my <a-tag
Currently all <a-tags will be redefined. Version 1.2.0 will fix this.

== Upgrade Notice ==
== Screenshots ==
