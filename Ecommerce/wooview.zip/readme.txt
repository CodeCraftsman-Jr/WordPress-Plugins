=== Plugin Name ===
Contributors:      Joe Rucci (bcslbrands)
Plugin Name:       WooView
Plugin URI:        http://www.wooviewapp.com
Tags:              WooCommerce, WooView, WooMobile, woocommerce app, ecommerce, woo view, mobile shop
Author URI:        http://www.bcslbrands.com
Author:            BCSL Brands, LLC
Requires at least: 3.5
Tested up to:      4.2
Stable tag:        1.2.4
Version:           1.2.4

== Description ==

WooView is the most convenient way to access your WooCommerce shop on the go. You will need to install our free Wordpress plugin on your site, thats it. 

Then you will have access to detailed reports, native graphs, incoming orders and much more!

== Installation ==

1. Upload the 'wooview' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Download the 'WooView' iOS app from the Apple App Store, Free!

== Changelog ==

= 1.2.4 =
* Fix compatibility more issues with WooCommerce 2.3 
* Fix issue with today’s dashboard reporting

= 1.2.2 =
* Fix compatibility more issues with WooCommerce 2.2.8 

= 1.2.1 =
* Fix compatibility issues with WooCommerce 2.2.0 

= 1.0 =
* Initial Release