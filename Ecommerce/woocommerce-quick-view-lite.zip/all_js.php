<?php

echo '<script src="'.$plugins_url.'/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js" type="text/javascript"></script>
	 <script src="'.$plugins_url.'/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.init.min.js" type="text/javascript"></script>';

?>