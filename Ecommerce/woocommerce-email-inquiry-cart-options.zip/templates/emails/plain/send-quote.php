<?php
/**
 * Send quote email
 *
 * @author 		A3rev
 * @package 	woocommerce-email-inquiry-ultimate/templates/emails/plain
 * @version     2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

_e('Please Upgrade to WooCommerce Quotes and Orders plugin', 'wc_email_inquiry');