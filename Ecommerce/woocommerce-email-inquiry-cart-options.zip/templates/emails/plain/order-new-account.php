<?php
/**
 * Customer new account email
 *
 * @author 		A3rev
 * @package 	woocommerce-email-inquiry-ultimate/templates/emails/plain
 * @version     2.0.0
 */

_e('Please Upgrade to WooCommerce Quotes and Orders plugin', 'wc_email_inquiry');

?>
