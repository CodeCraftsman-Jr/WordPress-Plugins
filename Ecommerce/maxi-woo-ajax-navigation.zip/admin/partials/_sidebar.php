<div id="waj-info-place">
    <div id="waj-donation" style="margin-bottom: 0px;">
        Woocommerce Ajax Navigation <small>v<?php echo WAJ::VER ?></small><br>
        <small>
            <a href="http://maxim-kaminsky.com/" target="_blank">Custom Wordpress Development</a> – 
            <a href="http://maxim-kaminsky.com/#contact" target="_blank" title="Got a problem? Send me a feedback!">Contact</a>
        </small>
        <br><br>
    </div>
    <div class="waj-separator">
        <div style="height: 10px; width: 5px; background-color: #cccccc; margin: 0 auto;"><!-- --></div>
    </div>
    <div id="waj-contact">
        <a href="http://wp-vote.net/paypal-payment/?type=little_thank" target="_blank">
            You can buy me some special coffees if you appreciate my work, thank you! >>
        </a>
    </div>
    <div class="waj-separator">
        <div style="height: 10px; width: 5px; background-color: #cccccc; margin: 0 auto;"><!-- --></div>
    </div>
    <div id="waj-ads">
        <p><strong>This Plugin is Proudly Sponsored By</strong></p>
        <div style="width: 250px; margin: 0 auto;">
		<a href="http://wp-vote.net/waj" target="_blank">
                    <img src="<?php echo WAJ::$ADMIN_URL . 'img/wp_foto_vote0.png' ?>" width="250" alt="wp foto vote">
		</a>
	</div>
    </div>
</div>