=== Plugin Name ===
Contributors: kaminsky.m
Donate link: http://wp-vote.net/paypal-payment/?type=little_thank
Tags: Woocommerce, ajax navigation, products, sells, filter
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows your easy insert Woocommerce products list with Ajax navigation, categry and order filter via shortcode.

== Description ==

Easy and fast way show Woocommerce products list with Ajax navigation, categry and order filter via shortcode in any page / post.

In plugin settings your can configure all needed options.

Woocommerce products block design depens on used theme and default Woocommerce styles.

User can filter products by category ang chage they order (all this do also Ajax).

In shortcode setting possible filter shoed products by category ID of products ID`s list (Example: 2,5,8,24).

See [demo on resume/cv template shop](http://www.lebenslaufdesigns.de/ "pluign demo").

For insert products list use
[woo_ajax_nav columns="3" orderby="title" order="asc" per_page="3" product_cat="" ids="" skus=""]
Params:

* `columns`: columns number (1,2,3,4)

* `orderby` and `order`: https://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters

* `per_page`: how many product shows in one page

* `product_cat`: from what category select products

* `ids`: products ids (Example: 2,5,8,24), if need shows just specific products

== Installation ==

1. Unzip plugin archive and upload to the `/wp-content/plugins/` directory or install from Wordpress.org
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Set up plugin settings in Settings => `Woo Ajax Nav` page
4. Place [woo_ajax_nav columns="3" orderby="title" per_page="3" product_cat="" ids="" skus=""] in your page / post

== Frequently Asked Questions ==

= How i can change products block design / layout =

It depends on you theme and Woocommerce styles, this plugin not chages products design, just shows products with default styling.


== Screenshots ==

1. Plugin settings
2. Example

== Changelog ==

= 1.0.1 =
* Released

== Upgrade Notice ==

None