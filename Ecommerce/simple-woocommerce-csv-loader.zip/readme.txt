=== Simple Woocommerce CSV Loader ===
Contributors: mag_oberon
Donate link: http://www.wpthorp.com/
Tags: woocommerce, woocommerce csv importer, woocommerce product import, woocommerce csv product, csv import, csv, plugin, woocommerce csv import, csv loader, woocommerce csv, woocommerce csv import, import woocommerce csv, woocommerce csv file, woocommerce csv tool  
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag:trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Import Categories, Tags, Images, Products and other Product details into WooCommerce.

== Description ==

Mass import hundreds, even thousands of Products into your WooCommerce store with the CSV Import suite. CSV Import suite lets you import all types of products, even product variations!
<blockquote>
<p>Support Blog & Pro Installation: http://www.wpthorp.com/simple-woocommerce-csv-loader/</p>
</blockquote>
= Simple Woocommerce CSV Loader =

* A simple, CSV product loader for WooCommerce.
* Supports importing hundreds or thousands of products at once. (The only limit is your patience!)
* Loads images via URL or local file path. (Now detects and skips duplicate images!)
* Loads hierarchical category structures (see Importing Hierarchical Categories below.)
* Lots of other great features suggested by plugin users (see Cool Stuff It/You Can Do and Full List of Importable Attributes below.)


== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots == 

1. admin area
== Changelog ==

= 1.0.5 =
* Fixed some bugs

== Upgrade notice ==



== Arbitrary section 1 ==

