=== WC State Update ===
Contributors: nwmcinc, Travis Buck
Tags:WooCommerce,State,Store,Checkout
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 4.2
Stable tag: 0.3

== Description ==

The whole purpose of this plugin is to modify the default state dropdown in WooCommerce.  
Clients complained that when they would use a two letter acronym multiple states would show.  
Modifying these settings in a plugin allows WooCommerce to update and not lose the customizations.

== Installation ==
Upload or install wc-state-update.zip

Activate the plugin


== Changelog ==

= 0.1 =
- Initial Revision
= 0.2 =
- Fixed AA, AE, AP state code
= 0.3 =
- Update to MI
