Smart Send PHP SDK
==================

**Version 2.0.1**

Introduction
------------

This repository is a 'wrapper' if you will, for interacting with the Smart Send API (Smart API)

It is designed to make it easier to interact with the API and all its more advanced features:

* Obtaining quotes
* Booking fulfilment from a quote
* Tracking shipping