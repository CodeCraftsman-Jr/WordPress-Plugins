<div class="webweb_wp_plugin">
    <div class="wrap">
        <h2>About</h2>

        <p>This plugin was created by Svetoslav Marinov (Slavi) - <a href="http://slavi.biz" target="_blank">slavi.biz</a> |  <a href="http://orbisius.com" target="_blank">orbisius.com</a> </p>

        <?php include_once(WEBWEB_WP_DIGISHOP_BASE_DIR . '/zzz_contact_form.php'); ?>
    </div>
</div>
