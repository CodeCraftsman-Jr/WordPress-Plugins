<?php echo wpautop('<p><span style="color: #ff0000;"><strong>У вас установлена бесплатная версия Saphali Woocommerce LITE</strong></span></p>
<p><strong>Плагин вносит в магазин следующие дополнения:</strong></p>
<ol>
<li>Улучшенная русская локализация Woocommerce.</li>
<li>В общий список валют добавлены — Украинская гривна (грн.), Российский рубль (руб.), Белорусский рубль (руб.) и Armenian dram (Դրամ)</li>
<li>Управление полями на странице оформления заказа и на странице профиля. Функция позволяет настроить заказную форму регистрации, чтобы настроить магазин на упрощение оформления заказа. Вы можете сделать некоторые поля необязательными при регистрации/оформлении заказа либо удалить их полностью.</li>
<li>Управление количеством колонок в каталоге товаров на странице "Магазин" и в категориях.</li>
</ol>
<p>Подробнее на сайте <strong><a href="http://saphali.com/" target="_blank">www.saphali.com</a></strong></p>

<p>
	<strong>ВНИМАНИЕ!</strong></p>
<p>
	Для простоты и удобства использования <strong>магазина </strong><strong>Woocomerce</strong>,&nbsp; мы <strong>разработали</strong> <strong>дополнительные плагины</strong> <strong>для </strong><strong>Woocomerce</strong><strong>, которые заметно сэкономят ваше время и значительно повысят функциональные возможности вашего магазина.</strong></p>
<p style="padding-left: 30px">
	<strong>Плагины платежных шлюзов для WooCommerce</strong></p>
<table border="1" cellpadding="0" cellspacing="0" style="width:624px;" width="624">
	<tbody>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Приват24</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-privat24-wp-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce LiqPay (прием оплаты с карт VISA и MasterCard)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-liqpay-wp-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce WebMoney</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-webmoney-wp-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Яндекс.Деньги</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-yandex-money-wp-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Яндекс.Деньги (для организаций)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-yandeks-dengi-dlya-organizacij">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Z-payment</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-z-payment-wp-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce QIWI (КИВИ, Россия)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-qiwi-wp-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce QIWI (КИВИ, Международный)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-qiwi-international">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce PayPal (для России и Украины)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-paypal-russia-ukraine-plagin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Интеркасса (Interkassa)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-interkassa-wp-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Единая касса</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-edinaya-kassa-plugin-w1">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce ChronoPay (Хронопей)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-chronopay-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce ONPAY</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-onpay-wordpress">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Uniteller (Юнителлер)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-uniteller-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce E-Pay (&laquo;Казкоммерцбанк&raquo;, Казахстан)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-e-pay-kazkommercbank-kazaxstan">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce RBK Money</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-rbk-money-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Platron (Платрон)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-platron-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce Оплата в БАНКЕ (Украина)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-oplata-v-banke-schet-faktura-ukraina">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce EasyPay</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-easypay">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce WEBPAY (Беларусь)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-webpay">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Woocommerce epay-ArCa плагин (Армения)</strong></p>
			</td>
			<td style="width:153px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-epay-arca-plugin-armeniya">Подробнее</a></strong></p>
			</td>
		</tr>
	</tbody>
</table>
<p style="padding-left: 30px">
	<strong>Плагины оформления доставки для Woocommerce</strong></p>
<table border="1" cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Почта России и служба доставки &laquo;EMS&raquo;</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-pochta-rossii-and-ems-russian-post">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>УНИВЕРСАЛЬНЫЙ плагин доставки</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/delivery-in-region-zone">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Доставка Новой почтой (Украина)</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/dostavka-nova-poshta-ukraina">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Доставка Укрпочтой (автом. расчет доставки)</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-ukrpochta">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WOOCOMMERCE Доставка курьерскими службами Украины</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-dostavka-kurerskimi-sluzhbami-ukrainy">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Доставка в регионы через транспортные компании и курьерские службы</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/delivery-russias-regions-dostavka-transportnoj-kompaniej">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Местная доставка</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-mestnaya-dostavka">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WOOCOMMERCE PICKPOINT &ndash; доставка через постаматы и пункты выдачи</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-postamaty-i-punkty-vydachi-pickpoint">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WOOCOMMERCE Выбор времени доставки</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-vybor-vremeni-i-daty-dostavki">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WOOCOMMERCE Дополнительные методы доставки</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-custom-shipping">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WOOCOMMERCE Товарная накладная</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-tovarnaya-nakladnaya">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>Дополнительный таб ОПЛАТА И ДОСТАВКА</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/tab-oplata-i-dostavka">Подробнее</a></strong></p>
			</td>
		</tr>
	</tbody>
</table>
<p style="padding-left: 30px">
	<strong>Плагины обработки цены</strong> <strong>для WooCommerce</strong></p>
<table border="1" cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce Автоматический конвертер цены</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-avtomaticheskij-konverter-ceny">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce Автоматический генератор цены</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-avtomaticheskij-generator-ceny">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce Каталог &laquo;Для оптовиков&raquo;</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-katalog-dlya-optovikov">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce Каталог &laquo;Для оптовиков&raquo; </strong><strong>PRO</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-katalog-dlya-optovikov-pro">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce Регистрируйся &ndash; Экономь (скидка после авторизации)</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-special-prices-for-logged-in-users">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce Эксклюзивные цены </strong><strong>PRO</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-eksklyuzivnye-ceny-pro">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce Закупочные цены. Отчеты по чистой прибыли</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-zakupochnye-ceny">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce </strong><strong>Конвертер</strong> <strong>валют</strong><strong>. </strong><strong>Мультивалютность</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/multi-currency">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce</strong><strong> Накопительный скидки</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/progressive-discounts-nakopitelnye-skidki">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce</strong><strong> Оптовые цены</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/wholesale-optom-price">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce</strong><strong> Скрытие цен / Режим каталога</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/skrytie-cen-rezhim-kataloga">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;height:19px;">
				<p>
					<strong>WooCommerce</strong><strong> Массовое редактирование цены</strong></p>
			</td>
			<td style="width:168px;height:19px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-massovoe-redaktirovanie-ceny">Подробнее</a></strong></p>
			</td>
		</tr>
	</tbody>
</table>
<p style="padding-left: 30px">
	<strong>Плагины для маркетинга в магазине</strong> <strong>WooCommerce</strong></p>
<table border="1" cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Экспорт товаров в ЯНДЕКС МАРКЕТ</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/yandex-market-export">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. . Экспорт товаров в </strong><strong>Wikimart</strong> <strong>(Викимарт)</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-eksport-tovarov-v-wikimart-vikimart">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Сообщить о поступлении</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/waiting-list-soobshhit-o-postuplenii">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Популярные категории / Популярные товары</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-populyarnye-kategorii-i-tovary">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce. </strong><strong>Накопительные скидки</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/progressive-discounts-nakopitelnye-skidki">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. </strong><strong>Price</strong><strong>.</strong><strong>ua</strong> <strong>(прайсовый интегратор)</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/prajsovyj-integrator-price-ua">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. </strong><strong>Hotline</strong><strong>.</strong><strong>ua</strong><strong> (прайсовый интегратор)</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/prajsovyj-integrator-hotline-ua">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong> Купить в один клик</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-kupit-v-odin-klik">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong> Комбинированные товары</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/kombinirovannye-tovary-grouped-product">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong> Акции</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-akcii-sale">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong> Дополнительный таб &laquo;Аксессуары&raquo;</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-dopolnitelnyj-tab-accessories">Подробнее</a></strong></p>
			</td>
		</tr>
	</tbody>
</table>
<p style="padding-left: 30px">
	<strong>Плагин для </strong><strong>SEO</strong><strong>оптимизации магазина </strong><strong>WooCommerce</strong></p>
<table border="1" cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>Дополнительное (СЕО) описание для товарных категорий</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/dual-description-in-category">Подробнее</a></strong></p>
			</td>
		</tr>
	</tbody>
</table>
<p style="padding-left: 30px">
	<strong>Плагины расширенных функций </strong><strong>WooCommerce</strong></p>
<table border="1" cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce Расширенные товары (УНИВЕРСАЛЬНЫЙ товар-конструктор)</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-universalnyj-produkt-konstruktor">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce Продажа услуг</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-prodazha-uslug">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce. Add to cart Popup</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-add-to-cart-popup">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Документы для продажи</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-documents-for-sale">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Индивидуальный заказ</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-individualnyj-zakaz">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Интерактив (</strong><strong>3 </strong><strong>в</strong><strong> 1)</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-interaktiv">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce. </strong><strong>Прайс</strong> <strong>лист</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-price-list">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Управление вкладками</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-menedzher-tabov">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Управление платежными шлюзами</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-manage-payment-gateways">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Цена выкупа</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-cena-vykupa">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Бренды (производители) </strong><strong>LITE</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/brands-products-lite">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>.</strong> <strong>Бренды (производители) </strong><strong>PRO</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/brands-products-pro">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>.</strong> <strong>Дополнительный таб &laquo;Видео&raquo;</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/product-video-tab">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Импорт товаров из прайсов </strong><strong>CSV</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/woocommerce-import-products-from-csv-price-list">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Недавно просмотренные товары</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/recently-viewed-products-list">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Продвинутый поиск</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/advanced-search">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Альтернативный виджет категории товара</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/widget-product-exlude-category">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Сообщить о поступлении</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/waiting-list-soobshhit-o-postuplenii">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Дополнительный таб (вкладка) </strong><strong>PRO</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/dopolnitelnyj-tab-vkladka-pro">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Дополнительный таб &laquo;</strong><strong>Upsells</strong><strong>&raquo;</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/dopolnitelnyj-tab-upsells">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Дополнительный таб &laquo;Рассрочка&raquo;</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/dopolnitelnyj-tab-rassrochka">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Дополнительный таб &laquo;Инструкции&raquo;</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/dopolnitelnyj-tab-instrukcii">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>WooCommerce</strong><strong>. Фильтр товаров по свойствам </strong><strong>LITE</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/filtr-tovarov-po-svojstvam-lite">Подробнее</a></strong></p>
			</td>
		</tr>
		<tr>
			<td style="width:470px;">
				<p>
					<strong>Плагин &laquo;Отзывы клиентов&raquo; для Вордресс</strong></p>
			</td>
			<td style="width:168px;">
				<p>
					<strong><a href="http://saphali.com/woocommerce-plugins/otzyvy-klientov-wordpress-plugin">Подробнее</a></strong></p>
			</td>
		</tr>
	</tbody>
</table>
<p>
	Весь <strong>каталог русских плагинов для</strong>&nbsp; <strong>WooCommerce</strong> вы найдете по адресу <a href="http://saphali.com/wordpress/woocommerce-plugins.">http://saphali.com/wordpress/woocommerce-plugins.</a></p>
<p>
	Мы открыты для ваших предложений. Ваши идеи, предложения и пожелания по улучшению Lite версии пишите на saphali@ukr.net. Возможно, именно Ваше предложение добавит новые возможности. Если вы заметили какие-либо неточности перевода или ошибки, сообщите нам об этом, и в ближайшее время исправления будут добавлены в плагин.</p>
<p>
	С уважением, администрация Saphali.com.</p>');
?>