<?php

// HTML Code For Form tag generator

?>
<style type="text/css">
#formoptions h4{margin-bottom:0;}
#seloptions .opttext, #seloptions .optprice{width:60%;}
#optionhtml {width:100%;}
</style>


<div id="formgen">
<h3> Functions below available in premium version.</h3> <a href="http://shop.premiumbizthemes.com/?download=simple-price-calculator-wordpress-version"> Click here to purchase premium version </a> <br /> <br />
	Select an option:
	<select id="spc-tagselector">
		<option value="choosetag" disabled selected> Choose tag </option>
		<option value="texttag"> Simple Price Text Box </option>
		<option value="checktag"> Simple Price Checkbox </option>
		<option value="radiotag"> Simple Price Radio Button </option>
		<option value="selecttag"> Simple Price Select Box </option>
		<option value="quanttag"> Simple Price Quantity Tag </option>
		<optgroup label="Email Attributes">			
			<option value="emailcomm">Comments/Special Requests</option>			
	    </optgroup>
	</select>

<h4> Copy this code below and place in editor </h4>
<textarea id="optionhtml" /></textarea> <br />
</div>

