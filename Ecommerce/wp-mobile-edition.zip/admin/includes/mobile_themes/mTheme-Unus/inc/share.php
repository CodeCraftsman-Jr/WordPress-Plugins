<a href="http://www.facebook.com/sharer.php?u=<?php echo wp_get_shortlink(); ?>&t=<?php the_title();?>" target="_blank"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/shf.png" width="24" height="24" border="0" alt="*" /></a>
<a href="https://plus.google.com/share?url=<?php echo wp_get_shortlink(); ?>" target="_blank"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/shg.png" width="24" height="24" border="0" alt="*" /></a>
<a href="http://twitter.com/share?text=<?php the_title();?>&amp;url=<?php echo wp_get_shortlink(); ?>" target="_blank"> <img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/sht.png" width="24" height="24" border="0" alt="*" /></a>
<a href="http://api.addthis.com/oexchange/0.8/offer?title=<?php the_title(); ?> &amp;url=<?php echo wp_get_shortlink(); ?>" target="_blank"> <img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/shi.png" width="24" height="24" border="0" alt="*" /></a>









