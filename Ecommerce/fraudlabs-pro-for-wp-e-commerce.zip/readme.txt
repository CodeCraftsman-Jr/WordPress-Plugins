=== FraudLabs Pro for WP e-Commerce ===
Contributors: FraudLabs Pro
Donate link: http://www.fraudlabspro.com
Tags: fraud, ecommerce, wp-e-commerce, wpec, wpsc
Requires at least: 2.0
Tested up to: 4.2
Stable tag: 1.1

Description: This plugin is an add-on for WP e-Commerce plugin that help you to screen your order transaction, such as credit card transaction, for online fraud.

== Description ==

This plugin is an add-on for WP e-Commerce that help you to screen your order transaction, such as credit card transaction, for online fraud. Its sophisticated and advance engines perform a comprehensive validation from all elements, such as geolocation, proxy, email, blacklisted, BIN, velocity, and many more to accurately unveil a fraud order. The plugin will then display the screening result on WP e-Commerce order page for your review.

Sign up for a Free license key at [http://www.fraudlabspro.com/sign-up](http://www.fraudlabspro.com/sign-up "http://www.fraudlabspro.com/sign-up") and start protecting your business from online fraud.

= More Information =
Please visit us at [http://www.fraudlabspro.com](http://www.fraudlabspro.com "http://www.fraudlabspro.com")


== Changelog ==

* 1.0 First release.


== Installation ==

1. Upload `fraudlabs-pro` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. Enter the License Key at the 'Settings' section.