<?php
/*
Plugin Name: درگاه پرداخت پی لاین افزونه ووکامرس
Version: 4.0.1
Description: پرداخت وجه محصولات ووکامرس به وسیله درگاه پرداخت پی لاین
Plugin URI: http://woocommerce.ir/
Author: ووکامرس فارسی
Author URI: http://woocommerce.ir/
*/
include_once("class-wc-gateway-payline.php");
//By HANNANStd in PersianScript.ir ==> woocommerce.ir