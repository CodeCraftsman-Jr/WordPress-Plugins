<?php

/**
 * The core functions for ticketX
 *
 * @package WordPress
 */

class ticketX {

	function getUserInfo(){


	}

	function checkSecurity(){

	}












}

?>
