=== TicketX ===
Contributors: Xnuiem
Donate link: http://www.thisrand.com/scripts/ticketx
Tags: tickets, support
Requires at least: 2.7
Tested up to: 2.7
Version: 0.1



== Description ==
This is currently only in development.  I do not suggest downloading at this point.


== Installation ==

1. Upload the ticketx directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==


== Change Log ==


== Screenshots==


== Demos ==




== To Do ==



