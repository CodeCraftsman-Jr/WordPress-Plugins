=== Check Wallet ===
Contributors: tomek00
Tags: widget, sidebar, shortcode, bitcoin, coin, btc, faucetbox, microwallet, blockchain, sochain
Donate link: http://wp-learning.net/blog/felajanl
Tested up to: 4.2.2
Stable tag: trunk

Check the balance of your Bitcoin wallet

== Description ==
Use shortcode ([check-wallet]) or widget

CSS (In case of shortcode):

	.check-wallet {
		background-color: #b0c4de;
	}

== Installation ==

1. Extract the plugin folder from the downloaded ZIP file.
2. Upload check-wallet folder to your /wp-content/plugins/ directory.
3. Activate the plugin from the "Plugins" page in your Dashboard.

== Frequently Asked Questions ==
None

== Screenshots ==
1. screenshot-1.png

== Upgrade Notice ==
Nothing

== Changelog ==

None