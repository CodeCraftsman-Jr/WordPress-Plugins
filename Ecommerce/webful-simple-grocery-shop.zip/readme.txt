=== Plugin Name ===
Contributors: sweetdaisy86
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=webfulcreationsvision%40gmail%2ecom&lc=US&item_name=Webful%20Creations%20Vision&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: cart, orders, grocery shop, simple shop, online orders, online shop, grocery store
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin helps users to make their shops online without getting online payments, this is for simple shops and get orders online.

== Description ==

This plugin helps you to make your shop online and add products of your shop with categories, so that your customers can place orders online.

During activation of this plugin it creates 2 pages Products and Checkout with required shortcodes you can change products page to anything but use shortcode. You also can change title of Checkout page but keep url /checkout/ as that is required by plugin. Use the shotcode below to show shopping page in widget or header of your site.

Check live demo http://webfulcreations.com/envato/grocery_order/products/

== Installation ==

During activation of this plugin it creates 2 pages Products and Checkout with required shortcodes you can change products page to anything but use shortcode. You also can change title of Checkout page but keep url /checkout/ as that is required by plugin. Use the shotcode below to show shopping page in widget or header of your site.
Shortcodes

Use following shortcode to list categories and products.

        //Shortcode
        [my_shop]
        
        //PHP function for template.
        <?php my_shop(); ?>
        

Use following shortcode for shopping bag.

        //Shortocode
        [my_bag]
        
        //PHP function for template.
        <? my_bag(); ?>
        

Use following shortcode for checkout page.

        //Shortocode
        [my_checkout]
        
        //PHP function for template.
        <? my_checkout(); ?>
        
== Screenshots ==

1. Screenshot
2. screenshot
3. Screenshot
4. Screenshot
5. Screenshot
6. Screenshot
7. Screenshot
8. Screenshot
9. Screenshot
10. screenshot
11. Screenshot