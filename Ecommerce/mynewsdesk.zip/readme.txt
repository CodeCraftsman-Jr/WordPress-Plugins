=== Mynewsdesk ===
Contributors: mansoormunib, mnddev
Tags: press releases, myNewsDesk, wordpress mynewsdesk, My News Desk, wpMyNewsDesk
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.4

Mynewsdesk (Its wordpress pluign to get connected to mynewsdesk.com site and embedd press releases in your site)

== Description ==

Wordpress Mynewsdesk or wpMynewsdesk is wordpress plugin to intergrte Mynewsdesk pressreleases and news in your Wordpress site very easily. You just need to get unique key from Mynewsdesk and enter it on setting page of Mynewsdesk and everything will be configured automatically.

== Installation ==

1. Download the Mynewsdesk WordPress Plugin, extract it and upload it to your WordPress Plugins folder on your site.
2. Activate the Plugin from the WordPress Administration Plugins tab.
3. Enter unique key under setting in admin panel and that's it.
4. Use short code [mynewsdesk] to display press releases any where in your site
5. Test it out and enjoy!



== Frequently Asked Questions ==

= Where can I get the unique key =
You need to contact mynewsdesk.com team to get your API key. More detail can be found here www.mynewsdesk.com/docs/webservice_pressroom