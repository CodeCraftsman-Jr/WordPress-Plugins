=== Plugin Name ===
Contributors: maennchen1.de
Donate link: http://wpshopgermany.de
Tags: IT-Recht Kanzlei München, IT-Recht, Kanlzei, Shops, Rechtstexte, Recht, Text, AGB, Impressum, Texte, Versandkosten, deutsch, Rechtssicherheit
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 1.0

Mit Hilfe dieses Plugins ist es möglich deutsche rechtssichere Texte (für Shops) über eine API zu aktualisieren.

== Description ==

Mit Hilfe dieses Plugins ist es möglich deutsche rechtssichere Texte  (für Shops) zu aktualisieren. Die Texte werden von der [IT-Recht Kanzlei München](http://www.it-recht-kanzlei.de/Service/rechtstexte_fuer_onlineshops.php?partner_id=150 "IT-Recht Kanzlei - Rechtstexte für den wpShopGermany") bezogen (Abo vorausgesetzt).

Das Plugin wurde für das Wordpress Plugin wpShopGermany entwickelt. Es kann auch ohne das Shop Plugin genutzt werden. 

Um diesen Dienst nutzen zu können ist ein Account bei der [IT-Recht Kanzlei München](http://www.it-recht-kanzlei.de/Service/rechtstexte_fuer_onlineshops.php?partner_id=150 "IT-Recht Kanzlei - Rechtstexte für den wpShopGermany") nötig.

== Installation ==

Zur Installation beachten Sie bitte folgende Schritte:

1. Die Plugindateien nach wp-content/plugins/wpshopgermany-itrecht kopieren, oder über das Wordpress Backend: Plugins > Installieren > Hochladen die ZIP Datei hochladen.
2. Das Plugin im Plugin Menü von Wordpress aktivieren.
3. Seiten für die Texte anlegen. (Im Wordpress Menü "Seiten")
4. API-Token in den Moduleinstellungen erzeugen (Symbol neben Eingabefeld)
5. Die Seiten auswählen auf denen die Texte von der [IT-Recht Kanzlei München](http://www.it-recht-kanzlei.de/Service/rechtstexte_fuer_onlineshops.php?partner_id=150 "IT-Recht Kanzlei - Rechtstexte für den wpShopGermany") eingesetzt werden sollen, oder neue anlegen.
5. Button "Speichern" betätigen.

Die API-URL aus den Einstellungen und auch der API-Key müssen auf Seiten von der [IT-Recht Kanzlei München](http://www.it-recht-kanzlei.de/Service/rechtstexte_fuer_onlineshops.php?partner_id=150 "IT-Recht Kanzlei - Rechtstexte für den wpShopGermany") hinterlegt werden, damit der Abgleich erfolgen kann.

== Screenshots ==

1. IT-Recht 
2. Backend-Einstellungen
3. ShopBackend-Einstellungen

== Changelog ==

