=== SBS - Seat Booking System ===
Contributors: uouapps
Donate link: http://donation.uouapps.com/
Tags:  ecommerce, drag and drop, woocommerce, reservation, room building, restaurant
Requires at least: 3.8
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Drag and drop room building and reservation plugin for WordPress

== Description ==

It's built with woocommerce so you can make the seat reservation with or without taking charges from the customer.

If you are running a restaurant and you want the reservation system via online SBS is the solution for your business.


The features are offered by SBS:

*	Built with WooCommerce
*	Responsive design
*	Drag and drop room building for reservation place
*	Reserve your seat both paid and free options are available to set



Demo Link : [Click Here For Demo](http://188.226.173.21/reservation/)



UOU Apps - App Themes & Premium Plugins Zone

We are an International team of Digital Goods fans that work with an Entrepreneurial spirit to deliver high-end professional applications that support thousands of individuals in converting their virtual business concept into a commercial reality

Who could have ever imagined that within less than 5 minutes you can get your business application running for less than 65$! 

Well this is no longer a promise, it’s a fact; 
So jump on board and make one of these projects become yours… 

One of our premium theme is available for price comparison woocommerce system.

http://uouapps.myshopify.com/collections/frontpage/products/comparis-price-comparison-wordpress-theme

Visit our themeforest portfolio. [UOU Apps](http://themeforest.net/user/uouapps/portfolio?ref=uouapps)



== Installation ==

1. To install the plugin go to the wordpress codex: http://codex.wordpress.org/Managing_Plugins or you can install manually http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation


== Frequently Asked Questions ==
= FAQ =


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png

== Changelog ==

= Changelog =

== Upgrade Notice ==

= Upgrade Notice =


