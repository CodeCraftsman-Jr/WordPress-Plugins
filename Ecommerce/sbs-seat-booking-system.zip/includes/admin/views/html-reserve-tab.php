<li class="reserve_tab reserve_pricing_tab advanced_options show_if_reserve"><a href="#reserve_pricing"><?php _e( 'Costs', 'uou' ); ?></a></li>
