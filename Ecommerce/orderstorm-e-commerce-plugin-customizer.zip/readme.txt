=== OrderStorm eCommerce Plugin Customizer - Deprecated ===

Contributors:  carlosman, dansallis
Donate link: www.orderstorm.com/wordpress-e-commerce-sign-up/ecommerce-wordpress-plugin-pricing/
Tags: e-commerce, ecommerce, shopping cart, ecommerce shopping cart, cart, store
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 0.4.9.11

This plugin has been replaced by the OrderStorm e-Commerce Custom Files Manager.


==Description==
Go to http://wordpress.org/extend/plugins/orderstorm-wordpress-e-commerce-custom/

== Installation ==


== Setup ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.4.9.11 [2011.11.26] =
* Plugin decommissioned, due to name change.

= 0.4.9.10 [2011.11.18] =
* Initial Release

== Upgrade Notice ==

