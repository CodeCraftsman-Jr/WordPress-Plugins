WooCommerce-Breadcrumb-Permalinks
=================================

Allows for breadcrumb permalinks for WooCommerce single product pages with parent and multiple child categories.
