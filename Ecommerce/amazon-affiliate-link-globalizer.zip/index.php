<?php
// Mr. T says: Silence, You Fools !
?>