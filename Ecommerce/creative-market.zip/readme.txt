=== Creative Market ===
Contributors: fristopher
Tags: widget, themes
Requires at least: 3.8
Tested up to: 4.3
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Creative Market Widget allows you to show off an item from Creative Market with ease.

== Description ==

This plugin allows you to drag a widget to your sidebar to show off an item from the Creative Market marketplace.

== Installation ==

To install this plugin, please follow these three steps.

1. Upload `creativemarket` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Drag a widget to the sidebar and specify the url of the marketplace item.

== Changelog ==

= 1.0 =
* First Release
