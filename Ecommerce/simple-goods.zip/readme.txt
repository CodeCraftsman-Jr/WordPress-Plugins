=== Simple Goods ===
Contributors: 
Donate link: 
Tags: Simple Goods, Ecommerce
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 0.11
Version: 0.11
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add Simple Goods checkout directly to your WordPress site & blog. This plugin will turn any Simple Goods links (https://www.simplegoods.co/i/xxxxxxx) into a checkout popup automatically. It also includes support for a simple Buy Button shortcode.

Sign up at https://www.simplegoods.co to get started. Docs and examples can be found at https://www.simplegoods.co/docs/#wordpress

== Description ==

Add Simple Goods checkout directly to your WordPress site & blog. This plugin will turn any Simple Goods links (https://www.simplegoods.co/i/xxxxxxx) into a checkout popup automatically. It also includes support for a simple Buy Button shortcode.

Sign up at https://www.simplegoods.co to get started. Docs and examples can be found at https://www.simplegoods.co/docs/#wordpress

== Installation ==

This plugin makes really easy to add Simple Goods Buy Now buttons to any page.

**To get started:**
1. Install the Simple Goods plugin (Upload)
3. Activate the plugin from the 'Plugins' menu in WordPress
2. Add the shortcode to any post or page where you want the buy now button to appear. For example:
[sgbutton text="Buy Now" link="https://www.simplegoods.co/i/LLBWZDJF"]

Alternatively, add a link to your product wherever you'd like the button to appear. For example:
<a href="https://www.simplegoods.co/i/LLBWZDJF">Buy Now</a>

That's it! Customers can now checkout directly on your WordPress website or blog!

If you have questions or need help just email us: founders@simplegoods.co.

== Frequently asked questions ==



== Screenshots ==



== Changelog ==

0.1 - First release
0.11 - Minor updates and bug fixes

== Upgrade notice ==
