=== WooCommerce bKash ===
Contributors: tareq1988
Donate link: http://tareq.wedevs.com/donate/
Tags: bkash, gateway, woocommerce, bdt, bangladesh
Requires at least: 3.6
Tested up to: 4.1.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

bKash Payment gateway for WooCommerce

== Description ==

bKash Payment gateway for WooCommerce.

Take payment via bKash and verify via transaction ID

[Fork in Github](https://github.com/tareq1988/woocommerce-bkash)

== Installation ==


1. Upload the plugin folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

Nothing here yet

== Screenshots ==

1. Gateway Settings
2. Checkout page
3. Order received page
4. Order details page (pending order)

== Changelog ==

= 1.0 =
* Moved the transaction ID form to order received page and order details page.

= 0.1 =
* First release