<?php echo '<?xml version="1.0" standalone="yes" ?>'; ?>
<ShipWorks moduleVersion="3.1.22.3273" schemaVersion="1.0.0">
	<Error><Code><?php echo $trackingManager->getCode() ; ?></Code>
		<Description><?php echo $trackingManager->getDescription() ?></Description>
	</Error>
</ShipWorks>
