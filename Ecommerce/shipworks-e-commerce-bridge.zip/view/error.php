<?php echo '<?xml version="1.0" standalone="yes" ?>'; ?>
<ShipWorks moduleVersion="3.0.0" schemaVersion="1.0.0">
	<Error>
		<Code>FOO100</Code>
		<Description><?php echo $description?></Description>
	</Error>
</ShipWorks>
