<?php
header('Content-Type: text/xml');

include_once('control/controlConnection.php');