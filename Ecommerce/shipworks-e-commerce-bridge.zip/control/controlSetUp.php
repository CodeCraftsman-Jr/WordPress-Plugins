<?php
// On affiche la page tutoriel sans accès à la base de donnée

include_once(PLUGIN_PATH_SHIPWORKSWORDPRESS.'view/setUp.php');


?>