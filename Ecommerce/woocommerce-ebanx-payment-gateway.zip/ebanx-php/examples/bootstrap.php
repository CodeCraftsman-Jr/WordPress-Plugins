<?php

require_once __DIR__ . '/../vendor/autoload.php';

\Ebanx\Config::set(array(
  'integrationKey' => '1231000',
  'directMode'     => true,
  'testMode'       => true
));
