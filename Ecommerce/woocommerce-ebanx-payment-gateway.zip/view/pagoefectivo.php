<h3>Gracias por su compra</h3>
<p>El codigo CIP es <strong><?php echo $cipCode ?></strong>.</p>
<p>Haga clic en el botón de abajo para imprimir su billete.</p>
<a class="button alt" href="<?php echo $cipUrl ?>" target="_blank">Imprimir billete</a>
<a class="button" href="<?php echo $orderUrl ?>" target="_blank">Detalles de la compra</a>