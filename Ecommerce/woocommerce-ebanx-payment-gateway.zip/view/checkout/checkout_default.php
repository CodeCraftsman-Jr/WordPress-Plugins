<p>No EBANX payment methods are available for this country.</p>

<a class="button" href="<?php echo $checkoutUrl ?>">Choose another payment method</a>