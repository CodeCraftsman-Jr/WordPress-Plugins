<h3>Obrigado por seu pedido</h3>
<p>Clique no botão abaixo para imprimir seu boleto.</p>
<a class="button alt" href="<?php echo $boletoUrl ?>" target="_blank">Imprimir boleto</a>
<a class="button" href="<?php echo $orderUrl ?>" target="_blank">Detalhes do pedido</a>