<h3>Obrigado por seu pedido</h3>
<p>Clique no botão abaixo para imprimir seu boleto.</p>
<a class="button alt" href="<?= $boletoUrl ?>" target="_blank">Imprimir boleto</a>
<a class="button" href="<?= $orderUrl ?>" target="_blank">Detalhes do pedido</a>