=== Shopp Customer Register ===
Contributors: maca134
Tags: Shopp, Customer Registration
Requires at least: 3.0.0
Tested up to: 3.2.1
Stable tag: 0.5.1

Allows users to register as a customer on Shopp without having to place an order.

== Description ==

Shopp Customer Register allows users to register as a customer on Shopp without having to place an order by putting [shopp_regform] on a page or post.

== Installation ==

1. Go to your admin area and select Plugins -> Add new from the menu.
2. Search for "Shopp Customer Register".
3. Click install.
4. Click activate.

== ChangeLog ==

= Version 0.5.1 =

* Added donate button

= Version 0.5 =

* Code cleaned up

= Version 0.4.8 =

* Added: autocomplete="off" to form elements

= Version 0.4.7 =

* Added: Users are now logged in when they registered
* Added: Users and merchants now can be send a notification email

= Version 0.4.6 =

* Wordpress SVN went all wiggly...

= Version 0.4.5 =

* Variable name was incorrectly named.

= Version 0.4.4 =

* Removed Shopp version checking, added custom thankyou message.

= Version 0.4.3 =

* Compatibility with Shopp 1.1.9

= Version 0.4.2 =

* Compatibility with Shopp 1.1.8

= Version 0.4.1 =

* Compatibility with Shopp 1.1.7

= Version 0.4 =

* Added option to take billing information as part of the registration process

= Version 0.3 =

* Initial public release.