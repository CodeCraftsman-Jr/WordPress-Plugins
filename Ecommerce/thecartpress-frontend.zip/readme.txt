=== Frontend for TheCartPress eCommerce Shopping Cart ===
Contributors: thecartpress
Donate link: http://thecartpress.com/collaborate-to-grow-and-support-thecartpress/
Tags: frontend, CartPress, ecommerce, e-commerce, store, shop, shopping, shopping cart, cart, custom post type, taxonomy, taxonomies, ecomerce, products, TheCartPress, html5, Australia
Requires at least: 3.1
Tested up to: 3.8
Stable Tag: 1.4

Allows access to customer's account from the front-end of TheCartPress eCommerce sites

== Description ==

Allows access to customer's account from the front-end of TheCartPress eCommerce sites

= More info and Community =

* [TheCartPress Extend](http://extend.thecartpress.com): plugins, themes and custom development
* [TheCartPress Site](http://thecartpress.com)
* [TheCartPress Community/Support](http://community.thecartpress.com/activity/)
* [TheCartPress Demo](http://demo.thecartpress.com)

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload TheCartpress Frontend to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Requirements =

Up to WodPress 3.1

= What is the plugin license? =

This plugin is released under a GPL license.

== Screenshots ==

== Changelog ==
= 1.3.3 =
* Support for TheCartPress 1.3+

= 1.3.3 =
* Adding hooks
* Supports for copying orders to Shopping cart

= 1.3.2 =
* Minor bugs

= 1.3.1 =
* Minor bugs

= 1.3 =
* New login and register panels
* TheCatPress 1.2.7 compatible

= 1.2 =
* Add a link to the account page in orders emails
* Deny back-end access to customers

= 1.1 =
* Deny back-end access to customers

= 1.0.3 =
* class tcp-store in TheCartPress-FrontEnd pages (My account, my downloads, etc.)

= 1.0.2 =
* My Orders: login to see your orders

= 1.0.2 =
* My account: logging form

= 1.0.0 =
* First public version.

