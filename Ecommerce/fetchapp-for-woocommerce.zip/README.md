fetchapp-wordpress
=======================

Base plugin to connect Wordpress to the FetchApp API.

Currently supports:

* WooCommerce

Upcoming support for:

* WP e-Commerce
