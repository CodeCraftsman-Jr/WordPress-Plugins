=== eShop-invoice ===

Contributors: thomaslcq

Donate link: http://www.pyphp.be/wordpress/eshop-invoice

Tags: eshop, ecommerce, shop, store, estore, stock control, cart, e-commerce, multisite, invoice, order, pdf

Requires at least: 3.0

Tested up to: 3.5.1

Stable tag: 0.4

License: GPLv2 or later


Invoice and Client interface plugin to the "eShop for Wordpress" plugin.



== Description ==



This is a plugin to the eShop shopping cart plugin for WordPress (http://wordpress.org/extend/plugins/eshop/). 
It includes:


* PDF invoices using the excellent html2pdf library (http://html2pdf.fr/)

* Customers "My Orders" view using a short code

* Widget for displaying a link to the "My Orders" page



Documentation is available via [PyPHP.be](http://www.pyphp.be/)

== Installation ==
Activate eShop-Invoice after eShop, that's all.
All texts mentionned on the invoice are customisable via the Admin Dashboard

== Frequently Asked Questions ==
Ain't no questions, yet...

== Screenshots ==

Screenshots available on via [PyPHP.be](http://www.pyphp.be/)


== Changelog == 

Verison 0.4

* corrected security breach. you are really advised to upgrade to this version. Remember to update your templates!
* changed a little the beginning of invoice.php, shoudl avoid blank pages or "?" characters being output

Version 0.3.6

* popping version number

Version 0.3.5

* bugfix in default template, thanks to Karsonito


Version 0.3.4

* Gets currency symbol from eshop core plugin

Version 0.3.3

* Corrects template "default"

Version 0.3.2

* Reverts 0.3.1, buggy

Version 0.3.1

* Trying to get the MediaUploader jquery stuff to work...

Version 0.3

* Added a My Order Widget (development motivated by Claes, thanks for the donation!)


Version 0.2

* Corrected html error in the template, no image defined in Admin will not produce an error (was "File is not %PDF...blabla")

* Removed dependency to eshop-users.php, useless to modify contact methods in this plugin.

Version 0.1

* *NEW* Initial release


== Upgrade Notice ==

Nihil