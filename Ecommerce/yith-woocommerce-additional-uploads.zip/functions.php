<?php

//region    ***************  METAKEY name definition    *******************

if ( ! defined( 'YWAU_METAKEY_ORDER_FILE_UPLOADED' ) ) {
	define( 'YWAU_METAKEY_ORDER_FILE_UPLOADED', '_ywau_order_file' );
}

if ( ! defined( 'YWAU_ACTION_DOWNLOAD_FILE' ) ) {
	define( 'YWAU_ACTION_DOWNLOAD_FILE', 'download-file' );
}
//endregion


