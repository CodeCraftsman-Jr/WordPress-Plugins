=== CBX Woocommerce Plain Sales Stat ===
Contributors: manchumahara,codeboxr,wpboxr 
Donate link:http://wpboxr.com/donate
Tags: woocommerce,sales report,woocommerce report, woocommerce sales log
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0.1

Plain Sales Stat For Woocommerce

== Description ==

Tired of woocommerce builtin sales stat or 3rd party sales stat with lots of features that looks messy(too much techie), try this. We developed this simple and clean sales start for our need, hope this will be useful to you. Check everyday sales count, product item count, sales amount(income) in one sight.

Two Types Statistics

* Daily sales for Single Month
* Last 12 Months Total

Other Features

* Available for both daily and monthly
* Next Previous Month Navigation
* Number of Orders
* Number of Products
* Total Sales Amount

Responsive & WordPress Native

Following wordpress standard Dashboard the stat has wordpress styled layout. Responsive layout adjust with mobile, ipad or table as well as wtih native wordpress. Icons are used as same icons wordpress uses in dashboard.


Month At a Glance

* Month To Date Sales
* Forecasted Sales
* Total Items
* Average Sales/Day
* Avg Orders Per Day

See more details at  http://wpboxr.com/product/woocommerce-plain-sales-report-for-wordpress

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
== Screenshots ==

1. Daily sales log
2. Monthly sales log