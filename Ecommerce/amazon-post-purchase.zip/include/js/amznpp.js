// 
// $Id$
// 
// Copyright 2014-2015 - Loudlever, Inc.
// 
(function( amznpp, $, undefined ) {
  /*
  ---------------------------------------------
      PRIVATE PROPERTIES
  ---------------------------------------------
  */
  
  var WIDGET_CNT = 0;
  var WIDGET_SET = {};

  /* 
  ---------------------------------------------
      PUBLIC FUNCTIONS
  --------------------------------------------- 
  */
  amznpp.append_asin_block = function(val) {
    // nothing here yet
    return false;
  };
  
}( window.amznpp = window.amznpp || {}, jQuery ));
