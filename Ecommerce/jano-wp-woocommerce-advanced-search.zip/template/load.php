<?php
function search_form($args) {

	 include("template.php");
	
}