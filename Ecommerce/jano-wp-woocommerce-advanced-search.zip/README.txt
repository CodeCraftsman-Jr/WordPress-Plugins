=== jano wp and woocommerce advanced search ===
Contributors: janothemes
Donate link: 
Tags: advance search, widget, search widget, ajax search, search, autocomplete, autosuggest, woocommerce, woocommerce search, products search, product search, live search, Predictive Search, wp search, brilliant search, janothemes, janothemes search, ecommerce search, post search, blog search  
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

jano wp and woocommerce advanced search is the best plugin for wordpress and woocommerce, autosuggest products and posts search,

== Description ==

The best ever plugin for wordpress and woocommerce search, it can be use to search products Or posts Or all Posts types,
After installing use the shortcode to make the search form, which you can use in text widget, editor or in template files to create the search form.

after setting up everyting, When you type in anything thing in search box, A list of suggestions will be showed with link to all search results at the bottom of list,

live Demo and Documentation : <a href="http://www.janothemes.com/" target="_blank">Click Here</a>

<strong>We are going to launch the premium version of this plugin in few days.</strong>

features :

<ul>
<li>Show post image in search result.</li>
<li>Show price of products(woocommerce products) in search result.</li>
<li>Show woocommerce on Sale product tag in search result.</li>
<li>Show Excerpt in search result.</li>
<li>Show Categories in search result.</li>
<li>Show Tags in search result.</li>
<li>Multiple form designs.</li>
</ul>

== Installation ==
1. Unzip the downloaded zip file.
2. Upload the plugin folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `Jano wordpress and woocommerce search` from Plugins page

ShortCode : [bt_search_form class="style2" Placeholder=" Search Products" posttype="product" perPage="10" loader="loader-2" loaderImg=""] 

Or &#60;?php echo do_short('[bt_search_form class="style2" Placeholder=" Search Products" posttype="product" perPage="10" loader="loader-2" loaderImg=""]'); ?&#62; for use in template files.

== Frequently Asked Questions ==

== Screenshots ==
1. screenshot-1.jpg

== Translators === Available Languages =* English (Default)* ducth

== Changelog ==

= 1.5 =
* new:  cross is added to search field to empty field.
* update: Search Query.
* update: Plugin Core.
* fixed: miner bugs

= 1.0 =
* Initial release.

== Upgrade Notice ==

