jQuery(document).ready(
                       function()
                       {
                            jQuery("#auction-settings-form").validate();
                            jQuery("#wdm-add-auction-form").validate();
                       }
                       );