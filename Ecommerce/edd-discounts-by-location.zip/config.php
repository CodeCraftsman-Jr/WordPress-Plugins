<?php

define('DC_EDD_DISCOUNTS_BY_LOCATION_PLUGIN_TOKEN', 'dc-edd-discounts-by-location');

define('DC_EDD_DISCOUNTS_BY_LOCATION_TEXT_DOMAIN', 'edd_discounts_by_location');

define('DC_EDD_DISCOUNTS_BY_LOCATION_PLUGIN_VERSION', '1.0.0');
?>