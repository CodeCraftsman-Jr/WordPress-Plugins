<?php

class message extends Exception {
//system messages added to diverse from ordinary exceptions
}
