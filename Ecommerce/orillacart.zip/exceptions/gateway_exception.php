<?php

class gateway_exception extends Exception {
    //put your code here
}
