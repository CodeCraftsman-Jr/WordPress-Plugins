<?php
/* 
 * Silence is golden
 */

