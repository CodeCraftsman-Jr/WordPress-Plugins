=== Woocommerce CSV exporter ===
Contributors: Allaerd
Tags: woocommerce, commerce, e-commerce, ecommerce, inventory, stock, products, import, csv, multiple images, upload, export
Requires at least: 3.7.0
Tested up to: 3.9.1
Stable tag: 1.0.3
Donate link: http://allaerd.org
License: GPLv2 or later 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Export woocommerce products

== Description ==
This plugin is discontinued. It will be part of the importer

== Frequently Asked Questions ==

== Screenshots ==

== Upgrade Notice ==

== Installation ==
* Just like any other plugin. You can check the [documentation](http://allaerd.org/documentation) if you need help.

== Changelog ==

= version 1.0.3 =
* added custom field support

= version 1.0.2 =
* added height

= version 1.0.1 =
* now downloads more than 5 products

= version 1.0.0 =
* first version, support for simple products and variations
