<?php

die("You Shouldn't be here!");