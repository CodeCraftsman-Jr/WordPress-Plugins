
Please check that the constant WPLANG in wp-config.php already defined.
For example

define('WPLANG', 'de_DE');
define('WPLANG', 'en_US');
define('WPLANG', 'fr_FR');
define('WPLANG', 'pt_BR');

If you translate the plugin in your language, 
please send me the language file so that I can add to the next version of the plugin.


    * Email: wpclassified@forgani.com 
	(Please include wpclassified in the subject of your email.)



Thanks,
4gani