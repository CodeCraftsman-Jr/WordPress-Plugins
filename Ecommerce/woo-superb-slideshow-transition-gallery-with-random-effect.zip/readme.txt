=== Woo superb slideshow transition gallery with random effect ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/
Author URI: http://gopi.coolpage.biz/demo/about/
Plugin URI: http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/
Tags: image, slide show, slideshow, gallery, images, widget, translucent, translucent image, imagegallery, sidebar, Transitional
Requires at least: 3.5
Tested up to: 4.3
Stable tag: 7.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
Dont just display images, showcase them in style using this plugin. Randomly chosen Transitional effects in IE browsers, others simple fade in.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/](http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/)

[Live Demo](http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/)	
[More info](http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/)				
[Comments/Suggestion](http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/)		
[About author](http://www.gopiplus.com/work/)			

Dont just display images, showcase them in style using this Woo superb slideshow transition gallery with random effect plugin.
This is an image slideshow gallery that brings each image into view using 1 of 15 randomly chosen 
Transitional effects in IE browsers. For other browsers that don't support these built in effects, a custom fade transition is used instead!

1. Simple, simple, simple.  
2. Easy installation.  
3. Lovable transition effect on IE beowser & simple fade transition in other browser.

We can use this plug-in in three different way.
1.	Go to widget menu and drag and drop the Woo superb slideshow transition gallery with random effect widget to your sidebar location. or <br />

2. Copy and past the mentioned code to your desired template location.		
`<?php woo_show( $type = "widget" , $random = "YES" ); ?>`	

3. Use below code in post or page.		
`[woo-superb-slideshow type="widget" random="YES"]` 		
In above code "widget" is your gallery type, "YES" is random option.		

Note : To best view all image should be in same size, because this plugin not generate any thumnail to display. 
If you have different size images see FAQ question 6 & 7 or visit plugin site for more info.
	
== Installation ==

[See Installation Instruction and Configuration information and Demo](http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/)	   

== Frequently Asked Questions ==

1. How to change the slide delay time?

2. Where to upload my image?

3. How the slide show manages the order?

4. How to split the images for gallery?

5. Where to update the duration of transition?

5. Where to update the pause time between images?

6. To change or use the fixed width?

7. How to arrange the width & height of the slideshow?		

[Answer page](http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/)			

== Screenshots ==

1. Front End Screen. http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/

2. Admin Setting Screen. http://www.gopiplus.com/work/2010/09/19/woo-superb-slideshow-transition-gallery-with-random-effect/

== Changelog ==

= 1.0 =	

First version

= 2.0 =

Only admin can access this plugin in the admin dashboard

= 3.0 =

Tested up to 3.3

= 4.0 =

Tested up to 3.4

= 5.0 =

New demo link, www.gopiplus.com

= 6.0 =

Tested up to 3.5
Admin Delete Link problem has been fixed.
Slight change in the short code, Please find the new short code for your gallery.
New PHP code to load the plugin directly from theme file.

= 7.0 =

Tested up to 3.6

= 7.1 =

Added security feature.
New admin layout.

= 7.2 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (woo-transition.po) available in the languages folder.

= 7.3 =

1. Tested up to 3.9
2. Restricted direct page access.

= 7.4 =

1. Tested up to 4.0

= 7.5 =

1. Tested up to 4.1

= 7.6 =

1. Tested up to 4.2.2

= 7.7 =

1. Tested up to 4.3

== Upgrade Notice ==

= 1.0 =	

first version

= 2.0 =

Only admin can access this plugin in the admin dashboard

= 3.0 =

Tested up to 3.3

= 4.0 =

Tested up to 3.4

= 5.0 =

New demo link, www.gopiplus.com

= 6.0 =

Tested up to 3.5
Admin Delete Link problem has been fixed.
Slight change in the short code, Please find the new short code for your gallery.
New PHP code to load the plugin directly from theme file.

= 7.0 =

Tested up to 3.6

= 7.1 =

Added security feature.
New admin layout.

= 7.2 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (woo-transition.po) available in the languages folder.

= 7.3 =

1. Tested up to 3.9
2. Restricted direct page access.

= 7.4 =

1. Tested up to 4.0

= 7.5 =

1. Tested up to 4.1

= 7.6 =

1. Tested up to 4.2.2

= 7.7 =

1. Tested up to 4.3