=== Create list of categories Woocommerce  ===
Contributors: webdesignjc
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=25BYCRDE6D2PW
Tags: categories woocommerce,list,lista de categorias woocommerce,woocommerce categories
Requires at least: 3.3
Tested up to: 4.0.1
Stable tag: 4.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


This plugin generates a shortcode with WooCommerce category has the option to display the image of the category and list the products in this category may also espesificar the number of products to display, ideal for creating a menu.

== Description ==



This plugin generates a shortcode with WooCommerce category has the option to display the image of the category and list the products in this category may also espesificar the number of products to display, ideal for creating a menu.

<a href="http://webdesignjc.com" target="_blank">Support</a>

== Installation ==

1. Upload the `jc-woocomerce-categories` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin via the 'Plugins' menu in WordPress.
3. Plugin settings are located in Menu "JC Categories Settings".

== Frequently asked questions ==



== Screenshots ==

1. Create list of categories Woocommerce 1
1. Create list of categories Woocommerce 2
1. Create list of categories Woocommerce 3
1. Create list of categories Woocommerce 4
1. Create list of categories Woocommerce 5
1. Create list of categories Woocommerce 6

== Changelog ==



== Upgrade notice ==

