jQuery(document).ready(function($){
	var container = document.querySelector('#cat-products');
	var msnry = new Masonry( container, {
  // options
  columnWidth:0,
  itemSelector: '.item'
});
});