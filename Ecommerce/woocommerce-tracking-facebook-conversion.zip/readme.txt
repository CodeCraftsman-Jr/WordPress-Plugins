=== WooCommerce Tracking Facebook Conversion ===
Contributors: agenciamagma, Pablo Ribeiro, Carlos Cardoso Dias
Donate link: http://www.agenciamagma.com.br
Tags: woocommerce, conversion, facebook, track facebook conversion, track conversion, facebook ads, ads
Requires at least: 4.0.1
Tested up to: 4.0.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Send conversion for facebook ads.

== Description ==

This plugin adds the necessary code to allow the calculation of return on investment in ads on facebook.

= Descrição em Português =

Este plugin insere o código necessário para permitir o cálculo do retorno sobre o investimento em anúncios no facebook.

== Installation ==

1. Upload  the contents of `woocommerce-tracking-facebook-conversion` directory to the `/wp-content/plugins/woocommerce-tracking-facebook-conversion/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Como posso fazer isso funcionar? =

Basta ir em: Criar Público -> Usar gerenciador de anúncios -> Rastreamento de conversão -> Criar Pixel. Escolha a categoria conclusão de compra e digite o nome do pixel de conversão.

== Screenshots ==

1. Plugin settings.
1. How to get the facebook code.
1. Example of facebook's report.

== Changelog ==

= 1.0 =
* First version.

== Upgrade Notice ==

= 1.0 =
First version.
