<?php

class Paay_Exception_ConnectionException extends Exception
{

}