<?php

class Paay_Exception_ApiException extends Exception
{

}