<div class="paay_transaction_error woocommerce-error">
    <?php // echo $var['type']; ?>
    <p class="message"> <?php echo $var['content']; ?> </p>
    <?php // echo $var['info']; ?>
</div>