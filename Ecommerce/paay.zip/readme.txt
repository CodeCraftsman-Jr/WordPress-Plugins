=== Plugin Name ===
Contributors: paay
Donate link: http://www.paay.co/
Tags: plugin, woocommerce, shop, gateway, credit card
Requires at least: 3.8
Depends: WooCommerce
Tested up to: 4.1
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

PAAY WooCommerce plugin lets your customers use PAAY with your WooCommerce shop.

== Description ==

PAAY is the fast, simple and secure way to make purchases online. It’s as simple as typing your phone number and then entering your personal PIN once the transaction appears on your phone. You’re done in 2-steps!

PAAY WooCommerce plugin lets your customers use PAAY with your WooCommerce shop.

== Installation ==

1. Upload `paay-woocommerce` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress (NOTE: Remember to install and activate Woocommerce first!)
3. Go to Settings > PAAY and fill your Merchant's api key/secret and server URL (https://api.paay.co)