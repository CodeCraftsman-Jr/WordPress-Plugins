=== Plugin Name ===

Contributors: shawneggplantstudiosca

Donate link: none

Tags: woocommerce, woocommerce cart, woocommerce attributes

Requires at least: 3.0.1

Tested up to: 4.2.1

Stable tag: 1.0.1

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cleans up the WooComerce Cart Page by hiding product attributes until they are toggled On/Off. 

== Description ==

Cleans up the WooComerce Cart Page by hiding product attributes until they are toggled On/Off. Especially useful for products with many variations, or when combined with Gravity Forms/Ninja Forms.


**Features**

Adds a toggle to the WooCommerce Cart page that hides/shows product attributes.

== Installation ==



1. Upload the `eps-cart-toggle-attributes` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. ??
1. Profit



== Frequently Asked Questions ==

None so far?


== Screenshots ==

1. Off
2. On

== Changelog ==

= 1.0.1 =
Minor updates.

= 1.0.0 =
* Release.

== Upgrade Notice ==

= 1.0.1 =
Minor updates.

= 1.0.0 =
* Release.