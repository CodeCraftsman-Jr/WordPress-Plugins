=== WooCommerce Payment Gateway with NicePay ===
Contributors: planet8co, massu0310
Donate link: http://planet8.co
Tags: payment gateway, woocommerce payment gateway, woocommerce, planet8, korea, nicepay gateway, nicepay
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WooCommerce Payment Gateway for NicePay.

== Description ==

This is a WooCommerce payment gateway for NicePay.

This gateway supports KRW (Korean Won) for payment.

You can register for a Merchant ID at http://www.planet8.co/nicepay-pg/

Please note that NicePay only gives Merchant IDs to merchants inside South Korea.

<strong>PRO version is coming soon at http://planet8.co soon!</strong>

== Installation ==

1. Just upload and activate the WooCommerce Payment Gateway with NicePay plugin!

== Frequently Asked Questions ==

Coming soon

== Screenshots ==

1. This is the admin options screen. You can change various options here.

== Changelog ==

= 1.0.0 =
* First version