<script type="text/javascript">
jQuery(document).ready(function()
{
	window.__cart.reset();
	
});
</script>