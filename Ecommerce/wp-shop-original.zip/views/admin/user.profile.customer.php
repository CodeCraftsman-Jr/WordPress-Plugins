<table class="form-table">
<tbody>
<tr>
	<th><label for="address">Адрес</label></th>
	<td><textarea name="address" id="address" rows="5" cols="30"></textarea></td>
</tr>
</tbody></table>
