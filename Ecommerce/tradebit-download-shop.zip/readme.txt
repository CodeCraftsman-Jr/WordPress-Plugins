=== Tradebit Download and Affiliate Shop ===
Contributors: tradebit
Tags: widget, admin, links
Requires at least: 2.7.0
Tested up to: 3.0.2
Stable tag: 3.0

Tradebit is the leading platform to publish and sell digital goods like photos
and music. This plugin integrates it into your Wordpress blog!

== Description ==

The ultimate plugin to upload and sell digital goods like photos, MP3 music or
website templates. With this plugin you will get:

* a free Tradebit merchant account (waives the $4.95 activation fee)
* an integrated button in your admin panel to fire up the member area
* a sidebar widget, that links with your ID to tradebit and lists your products

Tradebit.com is the marketplace for digital goods and gives you access to
**millions of legal digital goods** that you may additionally add to your
blog.

This plugin gives you secure storage space of 99 Gigabytes on tradebit to
host your digital inventory and includes the option to integrate affiliate
links to the existing catalog on tradebit.

Read more about the [Tradebit features](http://www.tradebit.com/digital-goods-marketplace.php "Download Shop")
here. The current version provides English accounts and will be enhanced to
other languages down the road.

== Installation ==

The installation of the tradebit download shop is pretty straight forward:

1. Upload the `tradebit-shop` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create your free account by choosing a username
4. Enter the member area and start uploading products
5. DO NOT FORGET: to activate the widget in your sidebar via the admin pages

There is an installation and handling video online on the
[development site](http://www.tradebit.info/downloads/wordpress.php "Plugin").

== Frequently Asked Questions ==

We provide free first level support on our forums on tradebit. Do not be shy
to ask!

== Screenshots ==

1. Create your free Tradebit account from within the plugin. Seamless integration rules!
2. Select the promotion code for your tradebit products. Choose your own or take one of 15 million other files.

== Changelog ==

= 3.0 =
* First public release with affiliate ID integration.
* Included DHTML_goodies floating window with GPLv2 compatible lib.

= 2.8 =
* Internal release for customers only.
