tinyMCE_GZ.init({
	themes : 'advanced',
	disk_cache : true,
	languages:"ru",
	debug : false
});
