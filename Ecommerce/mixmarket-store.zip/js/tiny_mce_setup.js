tinyMCE.init({
	mode : "textareas",
	theme : "advanced",
	language : mm_confirm_settings.editor_language,
    theme_advanced_toolbar_location : "top",
    theme_advanced_buttons1 : "bold,italic,underline,separator,bullist,numlist,separator,outdent,indent,separator,undo,redo,separator,link,unlink,separator,cleanup,code",
    theme_advanced_buttons2 : "",
    theme_advanced_buttons3 : "",
    editor_deselector : "category_fields"
});
