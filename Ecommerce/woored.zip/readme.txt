=== WooRed ===
Contributors: Amir JM
Plugin URI: http://web2webs.com/woored-pasarela-plugin-pago-gratis-wordpress-woocommerce/
Donate link: http://web2webs.com/woored-pasarela-plugin-pago-gratis-wordpress-woocommerce/
Author URI: http://web2webs.com/
Tags: servired, sermpa, redsys, woocomerce
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A�ade la posibilidad de cobrar a trav�s de pasarelas de pago de Servired y RedSys para "WooCommerce".

== Description ==

A&ntilde;ade la posibilidad de cobrar a trav&eacute;s de tarjeta de cr&eacute;dito los pedidos de tus clientes usando la pasarela de pago de Servired, junto con el plugin &quot; WooCommerce&quot; como plataforma de comercio, Servired / Sermepa / Reds&yacute;s / Cyberpack.

El plugin autom&aacute;ticamente marca el pedido como completado si el pago se realiza completo.

== Installation ==

1. Subir `WooRed` a directorio de `/wp-content/plugins/`
2. Activar el plugin y continuar al ajuses del plugin
3. llenar las claves y los campos

== Screenshots ==

1. Ajustes del plugin
2. Pasarela de pago