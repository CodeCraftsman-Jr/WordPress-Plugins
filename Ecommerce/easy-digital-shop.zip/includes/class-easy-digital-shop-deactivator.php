<?php

/**
 * @class       Easy_Digital_Shop_Deactivator
 * @version	1.0.0
 * @package	min-max-quantities-for-woocommerce
 * @category	Class
 * @author      johnny-manziel <jmkaila@gmail.com>
 */

class Easy_Digital_Shop_Deactivator {

	/**
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
