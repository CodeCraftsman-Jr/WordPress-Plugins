=== Contact Details by WooThemes ===
Contributors: jeffikus, woothemes
Tags: retired
Requires at least: 3.9
Tested up to: 3.9.1
Stable tag: 0.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin has been retired. Thanks for using it!

== Description ==

This plugin has been retired. Thanks for using it!

== Changelog ==

= 0.0.0 - 2015-06-01 =
* This plugin has been retired. Thanks for using it!