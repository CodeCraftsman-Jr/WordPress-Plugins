# Order SMS Notification WordPress Plugin - WooCommerce

This is a WooCommerce add-on. By Using this plugin admin and buyer can get notification about their order via sms using different SMS gateways.

The WooCommerce Order SMS Notification plugin for WordPress is very useful, when you want to get notified via SMS after placing an order. Buyer and seller both can get SMS notification after an order is placed. SMS notification options can be customized in the admin panel very easily.


## Key Features

* Very easy to install
* Very easy to customize
* Integrate TalkwithText and Clikcatell SMS Gateways
* Admin can get Order SMS notifications
* Buyer can get order sms notifications
* Available settings for Admin to control SMS settings and gateways
* Customizable SMS text
* Send Order details ( order no, order status ) in SMS text
* Extended Settings Option
* Works with WooCommerce 2.0+
* All version of WordPress 3.0+ supported

This plugin also have a premium version named [WooCommerce Order SMS Notifications](http://codecanyon.net/item/woocommerce-order-sms-notification/8339735) in codecanyon. In premium version there are lots of extended features like 

* Integrated 3 more most popular gateways ( Twillio, Nexmo, SMS Global )
* Sending SMS to any number.
* Sending Order Details ( order no, order status, order items and order amount ) in sms text
* Directly contact with buyer via SMS.
* Admin can force  buyer to get sms notifications.  
