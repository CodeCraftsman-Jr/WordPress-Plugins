=== Plugin Name ===
Contributors: Moeini
Donate link: http://php-press.com/
Tags: MS, MU, ADS, Advertisement
Requires at least: 3
Tested up to: 3.4.1

With This Plugin You Can Add Your Advertisement In Wordpress Network Blogs

== Description ==

This  Is Advanced Persian Plugin To Add Advertisement In Wordpress Network Blogs .
Also You Can Manage Plugin & Banners In Admin Page .

*	Add Unlimited Banner.
*	Manage Number of Banner View.
*	Plugin Themes.

== Installation ==

1. If You are Using Signle User WordPress (No Network) You Can`t Use This Plugin.
2. Extract the downloaded archive into `ms-ads` folder.
3. Upload `advertisement.php`, `options.js`, `ms-ads-themes/`, `ms-ads-languages/` to the `/wp-content/mu-plugins/` directory of your wordpress installation.

== Frequently Asked Questions ==

سوالات خود را در [انجمن وردپرس فارسی](http://forum.wp-persian.com/) مطرح نمایید.

