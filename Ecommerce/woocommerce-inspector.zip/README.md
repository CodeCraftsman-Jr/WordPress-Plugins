WooCommerce Inspector

The WooCommerce Inspector is a WordPress plugin that allows you to click on any element and find out in which WooCommerce template it's located.

 **PHP Requirement**
 
 This plugin requires PHP version 5.3 or higher.

 **Install from GitHub**
 
 If you install this plugin from GitHub you'll need to run ``composer install`` in the plugin root directory.

**License**

GPLv3 or later