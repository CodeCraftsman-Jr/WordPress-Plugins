=== Plugin Name ===
PDF Catalog for Woocommerce
Contributors: (ovologics)
Donate link: http://store.ovologics.com/services/service_tips
Tags: export products to pdf, export catalog to pdf, generate pdf, print catalog, print, generate PDF catalog, products list, export products by criteria, export products by keywords and categories into pdf, generate pdf by keywords and categories
Requires at least: 3.1 or higher
Tested up to: 3.1
Stable tag: /trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Here is a short description of the plugin.  

PDF Catalog for Woocommerce is an easy and powerful tool for creating catalog for online store using different templates

This is the long description.  

PDF Catalog for Woocommerce is an easy and powerful tool for creating catalog for online store using different templates. Our tool can automaticaly load the information of the products online, add catalog cover, index and content from the given templates as you want. After that PDF Catalog for Woocommerce will create beautiful PDF catalog for you. You can burn your packaged PDF Catalog to CD or mail it to your customers directly.

Features: 
Excellent solution for catalog creating, It contained several catalog templates. 
User can create catalog for all products or a part of products which user searching and choosing. 
All categories and products information is usability. 

NOTE: We can create templates according to your needs and using your own design. In case if you need your custom template develpoment feel free to send request to Ovologics team here: ovologics@gmail.com

== Installation ==

Visit 'Plugins > Add New'
Search for 'PDF Catalog'
Activate PDF Catalog from your Plugins page.

== Screenshots ==

1. `/assets/screenshot-1.png`

== Frequently Asked Questions ==

= Do you provide support service =

In case if you need to order additional services or paid customization, we are glad to help you :). Please visit: http://store.ovologics.com/services

= Do you provide custom development =
Yes, Ovologics team is able to develop any custom changes regarding WordPress/WooCommerce etc. Please contact us: ovologics@gmail.com

== Changelog ==

= 1.0.12 =
Fixed issue with predefined 10 products per catalog

= 1.0.4 =
Fixed installation issue and compatibility issues with Advanced PDF Catalog

= 1.0.2 =
* First release

== Upgrade Notice ==

= 1.0.4 =
Feel free to install the module

= 1.0.2 =
Feel free to install the module