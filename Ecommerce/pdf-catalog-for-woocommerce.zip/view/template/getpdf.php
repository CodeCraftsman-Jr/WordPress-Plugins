<div id="content">
    <div class="wrap">
      <div class="box">
        <div class="content">
            <div id="progressbar"><div class="progress-label">Loading...</div></div>
        </div>
      </div>
    </div>
</div>
<script>
var products_id = <?php echo $products_id; ?>;
var post_data = <?php echo $post_data; ?>;
</script>