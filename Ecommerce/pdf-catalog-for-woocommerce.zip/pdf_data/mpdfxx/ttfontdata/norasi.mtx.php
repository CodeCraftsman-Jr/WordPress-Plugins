<?php
$name='Norasi';
$type='TTF';
$desc=array (
  'Ascent' => 1216,
  'Descent' => -488,
  'CapHeight' => 1216,
  'Flags' => 4,
  'FontBBox' => '[-602 -488 1538 1219]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 366,
);
$up=-125;
$ut=50;
$ttffile='Z:/home/pdf2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/Norasi.ttf';
$TTCfontID='0';
$originalsize=103412;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='norasi';
$panose=' 0 0 2 7 5 6 6 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>