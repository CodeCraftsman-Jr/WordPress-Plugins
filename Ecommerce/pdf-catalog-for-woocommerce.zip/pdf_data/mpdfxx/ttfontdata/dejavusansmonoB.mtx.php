<?php
$name='DejaVuSansMono-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 262149,
  'FontBBox' => '[-447 -394 731 1052]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 602,
);
$up=-63;
$ut=44;
$ttffile='Z:/home/testpdf.ru/www/ttfonts/DejaVuSansMono-Bold.ttf';
$TTCfontID='0';
$originalsize=302868;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansmonoB';
$panose=' 0 0 2 b 7 9 3 6 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>