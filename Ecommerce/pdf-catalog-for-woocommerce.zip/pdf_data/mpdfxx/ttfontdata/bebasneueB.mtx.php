<?php
$name='BebasNeueBold';
$type='TTF';
$desc=array (
  'Ascent' => 750,
  'Descent' => -250,
  'CapHeight' => 700,
  'Flags' => 262148,
  'FontBBox' => '[-137 -179 1000 894]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 548,
);
$up=-85;
$ut=50;
$ttffile='Z:/home/advanced-opencart2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/BebasNeueBold.ttf';
$TTCfontID='0';
$originalsize=163180;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='bebasneueB';
$panose=' 0 0 2 b 6 6 2 2 2 5 2 1';
$haskerninfo=false;
$unAGlyphs=false;
?>