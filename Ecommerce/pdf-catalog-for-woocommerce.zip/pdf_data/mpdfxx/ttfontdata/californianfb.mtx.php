<?php
$name='CalifornianFB-Reg';
$type='TTF';
$desc=array (
  'Ascent' => 880,
  'Descent' => -255,
  'CapHeight' => 880,
  'Flags' => 4,
  'FontBBox' => '[-175 -255 1113 880]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-130;
$ut=50;
$ttffile='Z:/home/pdf2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/CalifR.ttf';
$TTCfontID='0';
$originalsize=105300;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='californianfb';
$panose=' 1 3 2 7 4 3 6 8 b 3 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>