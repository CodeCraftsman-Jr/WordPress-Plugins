<?php
$name='Allura-Regular';
$type='TTF';
$desc=array (
  'Ascent' => 800,
  'Descent' => -450,
  'CapHeight' => 497,
  'Flags' => 4,
  'FontBBox' => '[-361 -450 1165 800]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 219,
);
$up=-144;
$ut=24;
$ttffile='Z:/home/advanced-opencart2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/Allura-Regular.ttf';
$TTCfontID='0';
$originalsize=88084;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='allura';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>