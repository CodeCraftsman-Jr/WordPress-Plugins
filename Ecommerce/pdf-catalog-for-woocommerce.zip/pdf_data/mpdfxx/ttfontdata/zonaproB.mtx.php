<?php
$name='ZonaPro-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 825,
  'Descent' => -175,
  'CapHeight' => 705,
  'Flags' => 4,
  'FontBBox' => '[-288 -314 1249 1006]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-123;
$ut=20;
$ttffile='Z:/home/advanced-opencart2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/ZonaPro-Bold.ttf';
$TTCfontID='0';
$originalsize=90108;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='zonaproB';
$panose=' 0 0 2 1 8 3 4 0 2 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>