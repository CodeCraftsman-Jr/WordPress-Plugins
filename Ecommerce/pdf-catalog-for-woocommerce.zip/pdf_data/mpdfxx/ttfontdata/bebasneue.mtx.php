<?php
$name='BebasNeueRegular';
$type='TTF';
$desc=array (
  'Ascent' => 750,
  'Descent' => -250,
  'CapHeight' => 700,
  'Flags' => 4,
  'FontBBox' => '[-79 -179 831 887]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 548,
);
$up=-85;
$ut=50;
$ttffile='Z:/home/advanced-opencart2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/BebasNeueRegular.ttf';
$TTCfontID='0';
$originalsize=125640;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='bebasneue';
$panose=' 0 0 0 0 5 0 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>