<?php
$name='CenturyGothic';
$type='TTF';
$desc=array (
  'Ascent' => 1006,
  'Descent' => -220,
  'CapHeight' => 1006,
  'Flags' => 4,
  'FontBBox' => '[-169 -220 1152 971]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 750,
);
$up=-96;
$ut=58;
$ttffile='S:/home/mishutka.com.ua/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/GOTHIC.ttf';
$TTCfontID='0';
$originalsize=61280;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='centurygothic';
$panose=' 2 4 2 b 5 2 2 2 2 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>