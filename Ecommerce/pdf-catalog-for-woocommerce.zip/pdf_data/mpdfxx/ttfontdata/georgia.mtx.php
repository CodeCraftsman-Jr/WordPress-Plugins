<?php
$name='Georgia';
$type='TTF';
$desc=array (
  'Ascent' => 917,
  'Descent' => -219,
  'CapHeight' => 917,
  'Flags' => 4,
  'FontBBox' => '[-173 -217 1167 912]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$up=-88;
$ut=49;
$ttffile='Z:/home/advanced-opencart2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/Georgia.ttf';
$TTCfontID='0';
$originalsize=174783;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='georgia';
$panose=' 4 3 2 4 5 2 5 4 5 2 3 3';
$haskerninfo=false;
$unAGlyphs=false;
?>