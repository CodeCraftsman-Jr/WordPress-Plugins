<?php
$name='MonotypeCorsiva';
$type='TTF';
$desc=array (
  'Ascent' => 790,
  'Descent' => -303,
  'CapHeight' => 790,
  'Flags' => 68,
  'FontBBox' => '[-240 -307 1159 913]',
  'ItalicAngle' => -14.099990844727,
  'StemV' => 87,
  'MissingWidth' => 750,
);
$up=-120;
$ut=50;
$ttffile='Z:/home/pdf2.com/www/admin/controller/ovologics/advanced_pdf_data/mpdfxx/ttfonts/MonotypeCorsiva.ttf';
$TTCfontID='0';
$originalsize=157360;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='monotypecorsiva';
$panose=' a 6 3 1 1 1 1 2 1 1 1 1';
$haskerninfo=false;
$unAGlyphs=false;
?>