=== Easy Digital Downloads - Frontend Submissions Product Details ===

Author URI: http://astoundify.com
Plugin URI: http://wordpress.org/plugins/edd-fes-product-details
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=contact@appthemer.com&item_name=Donation+for+EDD+FES+Product+Details
Contributors: Astoundify, SpencerFinnell
Tags: easy digital downloads, downloads, product details, widget
Requires at least: 3.6
Tested up to: 4.2.1
Stable Tag: 1.0.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Specify and display frontend submission data as "product details" in a widget.

== Description ==

Specify and display frontend submission data as "product details" in a widget.

== Installation ==

1. Install and Activate.
2. In "FES > FES Forms > Submission Form" check the fields you want to be considered product details.
3. Add the "Easy Digital Downloads - Frontend Product Details" widget to a widget area.

== Frequently Asked Questions ==

== Changelog ==

= 1.0.2: June 26, 2014 =

* Fix: Output taxonomy and featured images properly.

= 1.0.1: May 11, 2014 =

* Fix: FES 2.2 compatibility.

= 1.0: January 8, 2014 =

* First official release!
