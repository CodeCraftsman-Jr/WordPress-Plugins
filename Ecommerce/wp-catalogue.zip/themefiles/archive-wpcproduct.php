<?php get_header(); ?>
   <!--Content-->
    <div id="content" role="main">	
      	<?php echo do_shortcode('[wp-catalogue]'); ?>
        
 <div class="clear"></div>    
    </div>
  <!--/Content-->
  <?php get_footer(); ?>