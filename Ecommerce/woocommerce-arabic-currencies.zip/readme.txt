﻿=== WooCommerce Arabic Currencies ===
Contributors: sa3idho 
Tags: woocommerce,currencies,money,commerce, arabic currencies
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 4.0
License: GPLv2 or later

This plugin is for add all arabic currencies to WooCommerce.

== Description ==

This plugin provides all arabic currencies for woocommerce, you can use and control this currencies in your website by easy use.

For more information visit [the official website of the plugin](http://saidweb2.com/)

توفر هذه الإضافة كل العملات العربية لووكومرس , يمكنك استعمال و التحكم بهذه العملات في موقعك بكل سهولة.

للمزيد من المعلومات المرجو  [زيارة الموقع الرسمي للإضافة](http://saidweb2.com/)

= Features  =

* Twenty-one Arab currency.
* Add all currencies direct to list woocommerce for currencies.
* Supports add more currencies.

= Translations =
* Arabic

== Installation ==

* The first method (the easiest)
1. Click Plugins in the menu
2. Click Add New
3. In search field type "WooCommerce Arabic Currencies" (without quotes)
4. Find WooCommerce Arabic Currencies in the list and click Install Now.

* The second method
1. Click plugins from dashboard 
2. Click Add plugin 
3. Upload "woocommerce-arabic-currencies.zip" and activate directly

* The third method (Manually)
1. Download the plugin to your computer
2. Unzip the file and upload it to the "/wp-content/plugins/" from ftp.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Go to woocommerce currencies settings and enjoy :)


== Screenshots ==
1. the list of Arab currencies in WooCommerce settings.


== Changelog ==
= 1.0.0 =
* First released version.
= 1.1.0 =
* Remove all default currencies and default currencies symbols.
= 1.1.1 =
* Update Arabic translation & the Screenshot.
