<?php
/*
wp_deregister_script( 'my-ajax-handle' );

function register_new_ajax_js() {
	global $active_template_url;
	wp_enqueue_script( 'my-ajax-handle', $active_template_url . 'dv_coupons.js' );
}

add_action( 'wp_enqueue_scripts', 'register_new_ajax_js' );
*/
?>