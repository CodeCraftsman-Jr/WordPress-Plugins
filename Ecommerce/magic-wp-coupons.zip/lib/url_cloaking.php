<?php

//Copied code to index.php because of registeration hook...

?>