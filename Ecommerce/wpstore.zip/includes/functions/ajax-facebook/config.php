<?php
########## app ID and app SECRET (Replace with yours) #############
$appId = '684563038257878'; //Facebook App ID
$appSecret = 'f80c1d4fc87af6173ff089aef17c0ab2'; // Facebook App Secret
$return_url = 'http://localhost/facebook/';  //path to script folder
$fbPermissions = 'email'; // more permissions https://developers.facebook.com/docs/authentication/permissions/

 
?>