Tutorial : http://www.sanwebe.com/2012/05/ajax-facebook-connect-with-jquery-php
Facebook PHP SDK (v.3.2.3) (https://github.com/facebook/facebook-php-sdk)