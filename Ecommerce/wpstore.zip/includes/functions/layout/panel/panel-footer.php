  	
		
		
		
		
		
		
		
		<div class="clear"></div>
		
	</div><!-- .tabControl -->

	
	
	
</div><!-- .opcoes -->

<div class="clear"></div>

</div><!-- #panel -->

</div><!-- .container -->
