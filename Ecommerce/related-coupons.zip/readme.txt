=== Related Coupons ===

Tags: coupons, related
Requires at least: 3.1
Tested up to: 3.2
Stable tag: 1.0.7

Easily align relevant coupons with your individual blog posts based on content, providing consistent revenue opportunities with 
targeted and valuable offers. 

== Description ==

Coupon Network has created the Related Coupons plugin to provide affiliates and bloggers with a new way to present valuable 
coupons to their audiences. Featuring the uniqueand valuabel offers only available from Coupon Network, this plugin matched the 
content of a blog post with the most relevant coupons. If you blog about breakfast, cereal coupons available from Coupon Network
will be featured. 

Three coupons are presented at the end of each blog post-- delivered similarly to the "Related Articles" functionality. Each 
coupon will link to offers on CouponNetwork.com, and allow affiliates to generaterevenue from each individual link.  

Notes:
When no affiliate or account ID is entered, the plugin does work-- just without attribution. 
Bloggers may install and utilize the plugin and opt out of functionality in individual posts. 

== Installation ==

1. Upload `related-coupons.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Adjust settings under "Settings" 

== Frequently Asked Questions ==

TBD

== Changelog ==

== About Coupon Network ==

Coupon Network, powered by Catalina Marketing, is where sophisticated busy moms and dads go to save money and improve their family's quality of life - with the most value and the most brands.

Coupon Network offers savings and coupons that you will not find anywhere else. The coupon savings available to you on Coupon Network are Printable Coupons, YourBucks Offers and digital coupons you can add directly to your savings card (coming soon). 
