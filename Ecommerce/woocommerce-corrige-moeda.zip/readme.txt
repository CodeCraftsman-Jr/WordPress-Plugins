﻿=== WooCommerce corrige moeda ===
Contributors: hostdesigner, John-Henrique<john@midianegocios.com.br>
Donate link: http://vibemidia.com/woocommerce
Tags: WooCommerce, loja WordPress, Real do Brasil, WooThemes, WordPress ecommerce, cart, shop, moeda, Brasil
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: trunk
 

== Description ==
 
Por padrão o WooCommerce exibe a moeda com o símbolo $ (dólar) isto pode fazer os consumidores pensarem que o preço na loja está em Dólar, este plugin corrige a exibição da moeda em toda a loja WooCommerce adicionando o símbolo R$, desta forma $ 20,00 passa a ser R$ 20,00. O simbolo da moeda Brasileira passa a ser exibida na loja WooCommerce ficando correta em toda a loja.

Funciona em todas as versões do WooCommerce, nenhuma alteração na loja precisa ser feita, nada será alterado além da exibição da moeda Real do Brasil.

= Precisa adicionar gateways de pagamento na sua loja? =
Também desenvolvi outros plugins. A exemplo tenho os seguintes plugins para Gateway de pagamento e integração com cálculo de frete dos Correios

* [WooCommerce PagSeguro](http://www.vibemidia.com/woocommerce-pagseguro)
* [WooCommerce MoIP](http://www.vibemidia.com/woocommerce-moip)
* [WooCommerce Pagamento Digital](http://www.vibemidia.com/woocommerce-pagamento-digital)
* [WooCommerce Correios](http://www.vibemidia.com/woocommerce-correios-sedex)
 
== Installation ==
 
Caso você tenha baixado este plugin você pode fazer a instalação diretamente através do seu painel WordPress acessando Plugins -> Adicionar novo -> Fazer upload, 
você também pode pesquisar no diretório de plugins (Plugins -> Adicionar novo -> Pesquisar) pelo nome do plugin "corrige moeda" e clicar em Instalar.

= Instalação manual =
Envie o plugin para a pasta wp-content/plugins/ e acesse a administração do WordPress. Agora basta ativar o plugin, tudo pronto.
 
== License ==
 
This file is part of WooCommerce corrige moeda.
WooCommerce corrige moeda is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published
by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
WooCommerce corrige moeda is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with WooCommerce corrige moeda. If not, see <http://www.gnu.org/licenses/>.
 
== Frequently Asked Questions ==
 
= Este plugin é definitivo? =
Não, este plugin é apenas uma correção rápida, em breve a versão 1.4 do WooCommerce será lançada e este plugin não terá utilidade. O WooCommerce 1.4 já possui a exibição correta da moeda.

= Onde obter ajuda? =
Creio que não seja necessário, mas mesmo assim acesse a página do plugin <a href="http://www.vibemidia.com/woocommerce-plugin-corrige-moeda">WooCommerce Corrige moeda</a> para obter ajuda.

Mais informações na página do plugin [WooCommerce corrige moeda](http://www.vibemidia.com/woocommerce-plugin-corrige-moeda)
 
== Changelog ==
 
= 1.0 =
* Apenas a correção e nada mais =D
 
== Screenshots ==
1. Exemplo de como está a exibição dos preços no WooCommerce 1.3.2.1 (e versões anteriores) e como este plugin deixará.