=== Plugin Name ===
Contributors: ChetanVengurlekar, SarviSolutions
Donate link: 
Tags: bollywood, one liners dialogues, bollywood dialogues, dialogues
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a plugin for the Bollywood fanatics. This plugin displays a list of famous dialogues from Bollywood films over the century.

== Description ==
This is a plugin for the Bollywood fanatics. This plugin displays a list of famous dialogues from Bollywood films over the century.

This plugin was inspired by the Hello Dolly plugin created by Matt. The working is also similar to the original one. Hope everyone, who likes Bollywood movies, like this plugin!

== Installation ==

1. Upload `bollywood-dialogues.zip` via `wp-admin/plugin-install.php?tab=upload` or upload the unzipped content to the `/wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You will see the famous Bollywood dialogues on all your dashboard pages.

== Frequently Asked Questions ==

= How do I turn these dialogues off? =
You can deactivate the plugin if you don't want to see the dialogues again.

== Screenshots ==

1. Plugin output - Screenshot 1.
2. Plugin output - Screenshot 2.
3. Plugin output - Screenshot 3.

== Changelog ==

= 0.1 =
* This is the first version of the plugin.

== Upgrade Notice ==

= 0.1 =
Upgrade immediately.