=== Woo Product Counter ===
Contributors: Johnny Dunhin
Donate link:
Tags:
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 4.2
Tested up to: 4.2
Stable tag: 0.2

Display the amount of all the published products

== Description ==

This is a simple plugin to display the amount of products that is in your store. This is my first plugin and more for personal use than commercial.

Want to see how it goes and then maybe work on it more to make the styling easier in the admin panel.

How to use:
You can use the shortcode [woopcounter] or the widget.

Styling:
Shortcode: no styling
Widget: minimal styling

== Installation ==
How to use:
You can use the shortcode [woopcounter] or the widget.

== Frequently Asked Questions ==


== Screenshots ==
None for now

== Changelog ==

= 0.1 =
- Initial Revision

= 0.2 =
- Make plugin compatible to new Wordpress version
