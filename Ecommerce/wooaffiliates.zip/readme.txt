=== WooAffiliates ===
Contributors: woothemes, mattyza, warrenholmes, hlashbrooke
Donate Link: http://woothemes.com/
Tags: retired
Requires at least: 3.2
Tested up to: 3.3.2
Stable tag: 0.0.0

This plugin has been retired. Thanks for using it!

== Description ==

This plugin has been retired. Thanks for using it!

== Changelog ==

= 0.0.0 - 2015-06-01 = 
* Plugin officially retired and removed from download.