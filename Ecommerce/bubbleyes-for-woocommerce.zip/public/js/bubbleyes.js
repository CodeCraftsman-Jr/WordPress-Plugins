(function( $ ) {
	'use strict';
})( jQuery );
