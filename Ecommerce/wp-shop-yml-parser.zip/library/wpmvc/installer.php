<?php
class wpmvc_installer
{
	public function __construct()
	{
		
	}
}