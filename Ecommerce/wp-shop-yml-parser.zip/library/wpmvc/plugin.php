<?php

class wpmvc_plugin
{
	public function __construct()
	{
		new ImportYml_Bootstrap();
	}
}