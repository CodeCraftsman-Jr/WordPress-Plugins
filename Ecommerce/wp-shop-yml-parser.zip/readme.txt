=== WP Shop YML Parser ===
Contributors: wpshop, shurupp
Donate link: http://wp-shop.ru/donate/
Tags: parser, XML, shop, webmoney, robokassa, wallet one, russian, ukrainian, affiliate, authorize, cart, checkout, commerce, coupons, e-commerce, ecommerce, gifts, online, online shop, online store, paypal, paypal advanced, paypal express, paypal pro, physical, ready!, reports, sales, sell, shipping, shop, shopping, stock, stock control, store, tax, virtual, weights, widgets, wordpress ecommerce, wp e-commerce
Requires at least: 3.7
Tested up to: 4.1
Stable tag: 0.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Удобный парсер интернет-магазинов через Яндекс-XML фид

== Description ==

Плагин позволяет импортировать товары из других магазинов через Yandex XML feed, который используется магазинами для торговли на Яндекс.Маркете.
Товары импортируются в структуру плагина магазина WP Shop. Работает автоматическая синхронизация товаров с источником, которую можно запускать как вручную, так и через крон.
Незаменимый инструмент для:
1. Переноса магазина с любых других движков на WordPress WP-Shop
2. Построения партнерских магазинов, для зарабатывания на партнерской комиссии по модели CPS
[youtube https://www.youtube.com/watch?v=EXQPQZ1SzbA&feature=youtu.be]
== Installation ==

1. Upload plugin "WP Shop YML Parser" to the `/wp-content/plugins/` directory
2. Activate the plugin "WP Shop YML Parser" through the 'Plugins' menu in WordPress
3. See [full userguide](http://wp-shop.ru/yandex-xml-parser/) how to set up your "WP Shop YML Parser"

== Frequently asked questions ==

= A question that someone might have =

Visit the site wp-shop.ru for help.

== Screenshots ==

== Changelog ==

== Upgrade notice ==

== Arbitrary section 1 ==