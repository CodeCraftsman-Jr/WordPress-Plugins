=== French eCommerce for TheCartPress ===
Contributors: thecartpress
Donate link: http://thecartpress.com/collaborate-to-grow-and-support-thecartpress/
Tags: French, ecommerce, e-commerce, shopping cart, cart, store, shop, shopping, ecomerce, products, TheCartPress, CartPress
Requires at least: 3.1
Tested up to: 3.5.2
Stable Tag: 1.3

French setup for TheCartPress, eCommerce Shopping Cart

== Description ==

French setup for TheCartPress adds a button to configure the stores with French currency, etc.

TheCartPress is the Professional WordPress eCommerce Plugin. Use it as shopping cart, catalog or framework.

* [TheCartPress Extend](http://extend.thecartpress.com): plugins, themes and custom development
* [TheCartPress Demo](http://demo.thecartpress.com)
* [TheCartPress Community/Support](http://community.thecartpress.com/activity/)
* [TheCartPress Site](http://thecartpress.com)

= More info and Community =
[TheCartPress Extend](http://extend.thecartpress.com): plugins, themes and custom development
[TheCartPress Demo](http://demo.thecartpress.com)
[TheCartPress Community/Support](http://community.thecartpress.com/activity/)
[TheCartPress Site](http://thecartpress.com)

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload TheCartpress French Setup plugin to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Re-save permalink settings

== Frequently Asked Questions ==

= Requirements =

Up to WodPress 3.1

= What is the plugin license? =

This plugin is released under a GPL license.

== Screenshots ==


== Changelog ==
= 1.3 =
* France as default tax based country
* Removed language support, only locale settings

= 1.2 =
* First public version.
