=== WP woocommerce featured product by category  ===
Contributors: wponlinesupport, anoopranawat 
Tags: woocommerce, Featured product , Featured product by category, shortcode , template code
Requires at least: 3.1
Tested up to: 4.3
Author URI: http://wponlinesupport.com
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A quick, easy way to add an Featured product by category to woocommerce.

== Description ==

This is very simple plugin to display woocommerce Featured product by category

= Installation help and support =
* Please check [installation help](http://wponlinesupport.com/plugin-installation-support/)  on our website. View [Installation help and support](http://wponlinesupport.com/plugin-installation-support/) 
* Get [Free installation and setup](http://wponlinesupport.com/plugin-installation-support/)  on your website.

View [Shortcodes included with WooCommerce](http://docs.woothemes.com/document/woocommerce-shortcodes/) for additional information.

In this plugin we have just changes the Featured product  shortcode.

The default short code is : <code>[featured_products per_page="12" columns="4"] </code>

And change in this shortcode with the help of Featured product by categor plugin is : <code>[featured_product_categories cats="CATEGORY_ID" per_cat="6" columns="3"] </code>

With this plugin you can now display woocommerce best selling products by category.

= Features include: =
* Featured product by category
* Easy to configure
* Smoothly integrates into any woocommerce theme
 
== Installation ==

1. Upload the 'sp-woocommerce-featured-product-by-category' folder to the '/wp-content/plugins/' directory.
2. Activate the sp-woocommerce-featured-product-by-category plugin through the 'Plugins' menu in WordPress.
3. Use the shortcode <code>[featured_product_categories cats="CATEGORY_ID" per_cat="6" columns="3"] </code> to display the best selling products by category

== Frequently Asked Questions ==

== Screenshots ==

1. Featured product by category view
2. How to add shortcode

== Changelog ==

= 1.0 =
* Featured product by category


== Upgrade Notice ==



