===Product Slider Extension===
Contributors: (iwcontribution)
Tags: Woocommerce, Product Slider, Slider
Requires at least: 3.5.1
Tested up to: 4.2.2
Product Slider allows Product to be view as slider.

==Description==
This is Woocommerce Product Slider extension which helps to make product view as a slider.

== Installation ==
1. To run this extension make sure that you have installed woocommerce plugin and activate it.
2. Download the Product Slider plugin zip file and extract to the  `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress Admin.

== Screenshots ==
1. WooCommerce Backend Settings "General" page.
2. This is Front-End Quick View Page. By Clicking on that you can see the quick view of a product.

= 1.0 =
The First Release

