<?php
include dirname(__FILE__) . '/../../faq.html';

