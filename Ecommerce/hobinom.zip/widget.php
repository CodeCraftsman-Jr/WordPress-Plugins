<?php
require_once('include/functions.php'); 

if( !defined( 'ABSPATH' ) ) { exit;}

// register all widget pages
require_once('widgets/domain-search.php');
require_once('widgets/namespinner.php');
?>