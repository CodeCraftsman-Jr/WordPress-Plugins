=== Sell Downloads ===
Contributors: codepeople
Donate link: http://wordpress.dwbooster.com/content-tools/sell-downloads
Tags: downloads,sell downloads,sell,sales,ecommerce,commerce,e-commerce,shop,shopping,paypal,files,digital,checkout,configurable,downloadable,store,wordpress ecommerce,images,books,audio,video,audio player,video player,html5,secure download,security,ip penalization,Post,posts,page,shortcode,plugin,admin,google,facebook,twitter,widget,sidebar,comments,pdf
Requires at least: 3.5.0
Tested up to: 4.3
Stable tag: 1.0.16
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Sell Downloads is an WordPress eCommerce for selling downloadable files: audio, video, documents, pictures all that may be published in Internet. Sell Downloads uses PayPal as payment gateway, making the sales process easy and secure.

== Description ==

Sell Downloads features:

	» Sell Downloads is a WordPress eCommerce
	» Allows selling digital files like audio,video,documents,pictures,etc.
	» Allows to filter products by types of files
	» Includes multiple layouts for the store
	» Allows paging and sorting the results by popularity, price or file name
	» Uses PayPal as payment gateway	
	» Allows sharing products in social networks (Facebook, Twitter, Google+)
	» Allows to associate additional information to the products
	» Allows to protect the files with the inclusion of a file's demo
	» The demo files will be displayed directly on browser, whether are enabled 
	  the corresponding plugins in browser

**Sell Downloads** is an  WordPress eCommerce for selling downloadable files: audio, video, documents, pictures all that may be published in Internet. Sell Downloads uses PayPal as payment gateway, making the sale process easy and secure.

Create an e-commerce for sell digital files never was more easy than with "Sell Downloads", the majority of e-commerce plugins are developed thinking in tangible products and does the sale's process very complex. An ecommerce that pretends to sale only digital files must to coexist with data related to tangible products, configure shipping cost, etc, "Sell Downloads" doesn't need any of previous data. With "Sell Downloads" is required only define the PayPal data and the products to sell.

**More about the Main Features:**

*	Allows selling your digital files via PayPal. PayPal is the payment gateway by excellence, very easy to use and very secure.
*	Allows a custom setup of the ecommerce, with ability to filter products by types of files, paging and sorting the results by popularity, price or file name, making of "Sell Downloads" a very configurable plugin.
*	Allows to associate additional information to the products. For example, if are selling a book and like to associate a link to other books of the same editorial, or a page of reviews from critics, this field would be the option for do it. 
*	Allows to protect the files with the inclusion of a file's demo. Monographies, videos, songs and many other digital files, allow the creation of a version for demo. It is very hard to sell a song if the possible customers never hear at least a part of it, similar happen with videos and its trailers or the monographies and its abstracts.
*	Includes a module to track sales statistics. With the statistics module is possible to know the amount of sales, the discounts applied or coupon used, and check the total of earnings by the ecommerce in a period of time. The statistics module allows to display animated charts with specific reports like: sales by currency, country or products.


The base plugin, available for free from the WordPress Plugin Directory has all the features you need to create a ecommerce for sell downloads on your website.

[youtube http://www.youtube.com/watch?v=Quosrug9pgo]

Inserting and using the basic "Sell Downloads" plugin.

**Premium Features:**

*   Allows to enable a shopping cart. With a shopping cart is possible to sell multiple products in the same purchase action, the customers will appreciate this feature.
*	Allows to insert a specific product in a post or page. The product is available as widget to be inserted in the website's sidebars.
*	Allows to insert a product list in a post or page. The products can be selected between the most rated, the newest, or top selling. The product list is available as widget to be inserted in the website's sidebars.
*   Allows to define sales discounts. It is usual in the e-commerce create sales campaigns, define discounts for products or events (like mothers day, the Christmas,etc.), to promote the sales. The "Sell Downloads" allows to define shop's discounts, and display the previous and new prices of products.
*   Allows to define discount coupons. The coupons are an excellent tool to know where is the origin of sales and create (like in discounts definition) sales campaings, but directed to a specific sector or website. The coupons are applied to all sales from the ecommerce.

[youtube http://www.youtube.com/watch?v=BG1Y2TSlvms]

Inserting and using the premium "Sell Downloads" plugin.

**Demo of Premium Version of Plugin**

[http://demos.net-factor.com/sell-downloads/wp-login.php](http://demos.net-factor.com/sell-downloads/wp-login.php "Click to access the administration area demo")

[http://demos.net-factor.com/sell-downloads/](http://demos.net-factor.com/sell-downloads/ "Click to access the Sell Downloads")

**Are safe the downloads links?**

The security in the access to products files is determined in different ways. 

*	The products files can't be accessed directly. The purchased files are stored in a special directory called sd-downloads, the sd-downloads directory includes a .htaccess file that forbid the access from browser. The files can be accessed only through a server side script that validates the purchase.  
*	The Store determines the validity of  download links based in three options, available in the settings page of plugin.

It is possible define a time period, in days, where a download link is considered valid. If a user tries to download a purchased product, the Store checks the date of purchasing.
The  Store may be configured to request the email address used in the purchasing to check the validity of download link.

It is possible define a limit of downloads by purchase. If a user tries to download a product, the Sell Downloads checks how many downloads have been made.

If you want more information about this plugin don't hesitate in checking the plugin's website:

[http://wordpress.dwbooster.com/content-tools/sell-downloads](http://wordpress.dwbooster.com/content-tools/sell-downloads "Sell Downloads")

[youtube http://www.youtube.com/watch?v=fkkA1-bs430]

Inserting a products list, and products, in pages or sidebars of website (only available in the premium version of plugin).

== Installation ==

**To install Sell Downloads, follow these steps:**

1. Download and unzip the plugin
2. Upload the entire "sell-downloads" directory to the "/wp-content/plugins /" directory
3. Activate the plugin through the 'Plugins' menu in "WordPress"
4. Go to "Sell Downloads > Sell Downloads Settings" and set up your store. 

== Interface ==

**Setting up of shop**

Sell Downloads can be set up via the menu: "Sell Downloads > Sell Downloads Settings". The setup screen offers general settings for the shop, allows entering the PayPal data required to process sales and texts that will be used for the email notifications with the download links of the purchased files.

**Settings Interface**

The setup interface of commerce includes the following fields:

*   URL of store page: Enter the URL of the webpage where the ecommerce was inserted. The URL of the store will be used to return from the product page to the shop page.
*	Allow searching by taxonomies: Modifies the search process of WordPress to allow the products be found by their taxonomies.
*   Allow to filter by type: Inserts a field into the shopping webpage that allows to filter products by type (jpg, mp3, doc,....)
*   Store layout: Allows select one of the multiple layouts available for the store.
*   Allow multiple pages: Allows paging through the shop's products.
*   Items per page: Defines the number of products per page in the commerce's page.

**Payment gateway data (PayPal)**

*   Enable PayPal Payments: Allows the sale of products through PayPal.
*   PayPal email: Enter the email address associated with the PayPal account.
*   Currency: Symbol of the currency in which payments are accepted.
*   PayPal language: Preferred language of the PayPal interface. 
*   PayPal button: Select the PayPal button design. 
*   Increase the download page security: Requests the email used in product's purchase from the download page.
*   Download link valid for: Set an expire time for the download links.

**Discount settings applied to the sales of the ecommerce. In the shopping cart the discount is applied to the total sale cost(premium version)**

*   Percent to discount: Enter the percent to discount to the total sale cost.
*   Valid for sales over than: Apply discount to sales superior to this value.
*   Valid from (dd/mm/yyyy): Apply discount from the entered date.
*   Valid to (dd/mm/yyyy): Apply discount until the entered date.
*   Promotional text: Text to promote the discount.

**Coupon settings applied to all sales of the ecommerce(premium version)**

*   Percent to discount: Enter the percent to discount to the total sale cost.
*   Coupon: Enter the coupon code.
*   Valid from (dd/mm/yyyy): The coupon is valid from the entered date.
*   Valid to (dd/mm/yyyy): The coupon is valid to the entered date.


**Notification Settings**, both for buyers to complete a payment, and the shop manager
 
*   Notification "from" email: E-mail address that will appear as the sender of notifications.
*   Send notification to email: Email address where a notification is sent after each sale.
*   Subject of user confirmation email: Subject of the confirmation email sent to the customer when making the purchase.
*   Email confirmation to user: Body of message sent to the customer when making the purchase. The message should include the tag  %INFORMATION% which will be replaced by the purchase data, like the download link.
*   Subject of email notification to admin: Subject of email notification sent to the administrator when a purchase is made.
*   Email notification to admin: Body of the email message sent to the administrator when a purchase is made. The message text should include the tag  %INFORMATION%, which will be replaced by the purchase data.

**Creating product for commerce**

The shop allows to sell possible digital files (video, audio, documents, etc). To create a product press the menu option "Sell Downloads > Products for Sale". Initially it displays the list of products entered previously and a set of data associated with the product: Product Name, File Type, Downloads, Purchases and Date (screenshot-2)

To enter a new product/file to the shop press "Add New".

The interface for entering data pertaining to a product is described below (screenshot-3):

**Product's data**

*   Enter Title Here: Enter the title-name of the product to display in the shop page and the product page.
*   Description: Description of the product. This field is optional, but offers the opportunity to provide additional information about the product, this information is displayed only in the product page.
*   Sales Price: Retail price of the product.
*   File for sale: URL of the file to sell. The button associated with the field displays the WordPress media gallery making it easy to select the file.
*   File for demo: URL file demo. The file for demo may be accessed from the ecommerce page.The button associated with the field displays the WordPress media gallery making it easy to select the file.
*   File Type: Select a file type from the list or enter a new one if it is not yet on the list. The file type allow filtering the products in the shop page.
*   Image: URL of an image that represents the product, the product image is shown in the ecommerce page and product page. The button associated with the field displays the WordPress media gallery making it easy to select the file.
*   Duration: Enter a value with time format. Useful for Audio and Video files. With other files types the fields may be let empty.
*   Publication Year: Enter a value with year format. Useful for files associated with a date, as the creation or publication date , for example a book or monograph.
*   Additional Information: URL of a webpage with additional information about the product.

**Programming a discount for the specific product(premium version)**

*   New price: The new price to apply to the product. The old and new prices will shown in pages of the ecommerce and the specific product.
*   Valid from (dd/mm/yyyy): Apply discount from the entered date.
*   Valid to (dd/mm/yyyy): Apply discount until the entered date.
*   Promotional text: Text to promote the discount. The promoting text will be shown in the shop page.

**Publishing the "Sell Downloads" ecommerce**

The "Sell Downloads" ecommerce can be posted on a page or post of WordPress. To insert the "Sell Downloads" shop go to the relevant section (page or post) and press the "Sell Downloads" button above the  content editor of post/page(screenshot-4), the action displays a setup screen (screenshot-5)

**Interface for insertion dialog**

*   Filter results by products type: by default, displays only products that belong to a specified type.
*   Columns: Defines the number of columns in the shop page.

The insertion process generates a shortcode which will be replaced by the shop when it is displayed on the website.

Note: After inserting the ecommerce on a page of your WordPress, it is advisable to copy the URL of the relevant page, and enter in the "Sell Downloads" setup section, to allow the users to return to the shop from the product page.

**Shortcode attributes**

Through the shortcode it is possible define some attribute for change the store's settings:

columns: Enter the number of columns to display the products in the store with a grid format. By default the value of "columns" attribute is 1.

        [sell_downloads columns="3"]       

filter_by_type: The values allowed are 1 or 0, and shows or hide the filtering by product's type in the header section of the store's page.

        [sell_downloads columns="3" filter_by_type="1"]        
        
show_order_by: The values allowed are 1 or 0, and shows or hide the "Order by" options in the header section of the store's page.

        [sell_downloads columns="3" show_order_by="1"]        

order_by: The values allowed are: plays, price, post_title, post_date. Allows ordering the products in the store's page by the criteria defined in the attribute.

        [sell_downloads columns="3" order_by="post_title"]        
        
**Interface for insertion dialog of product (the products list is available as widget to be inserted in the website's sidebars)(the option is available only in the premium version of "Sell Downloads" plugin)**

*   Enter the product's ID (screenshot-6)

The insertion process generates a shortcode which will be replaced by the product when it is displayed on the website.

**Interface for insertion dialog of product list (the products list is available as widget to be inserted in the website's sidebars)(the option is available only in the premium version of "Sell Downloads" plugin)**

*   Select the type of list: it is possible insert the list of top rated products, the newest or top selling.
*   Number of products to show: enter the number of products to display in the list.
*   Number of columns: enter the number of columns.
(screenshot-7)

The insertion process generates a shortcode which will be replaced by the list of products when it is displayed on the website.

The products list, and specific products, can be inserted as widgets on sidebars (screenshot-8)

**Sales Statistics**

When a sale takes place, a notification email is sent to the shop manager. However, sales can also be reviewed in Sales Reports. To do this, go to option "Sell Downloads > Sales Reports"(screenshot-9)

The Reports section allows you to filter sales reports over a specific period, by default it shows the current day's sales. It also shows sales' totals for the selected period and the currency of the sales (screenshot-10)

The statistics module allows to display animated charts for specific reports like: sales by currency, sales by country, or by products.

You can delete a sales report from the list of sales. This may be useful in case of a refund granted to a buyer, and allows to keep your sales statistics updated with the actual purchases.

== Frequently Asked Questions ==

= Q: Why the sales button doesn't  appear? =

A: First, go to the settings page of commerce and be sure the PayPal checkbox is checked, and has defined the seller's email. Second, be sure the product has a price defined and a file for sell associated.

= Q: How the discounts are treated by the store? = 

A: If the store has defined a discount and a coupon at the same time, only one is applied to the sale, the biggest of both.

= Q: How to download all purchased products as only one file? =

A: To download all purchased files as  only one file, is required enabling the zip option from the settings page of "Sell Downloads". The zip feature may be disabled in your website because the required extensions are not present in the PHP of the web server.

= Q: Why the sell downloads is not loading on page? =

A: Verify that the theme used in your website, includes the function wp_footer(); in the template file "footer.php" or the template file "index.php"

= Q: What can I do if the sell downloads directory exists and the premium version of plugin cannot be installed? =

A: Go to the plugins section in WordPress, deactivate the free version of Sell Downloads, and delete it ( Don't worry, this process don't modify the products created with the free version of plugin), and finally install and activate the premium version of plugin.

= Q: Does allow the sell downloads a different payment gateway than PayPal? =

A: I'm sorry, but the current version of plugin allows PayPal only.

= Q: Can the customers pay directly with its credit cards? =

A: The restriction is imposed by PayPal. Please, check that your PayPal account allow to charge directly from the credit cards of customers.

= Q: Is possible modify the appearance of sell downloads products? =

A: The design of each section of Sell Downloads, is determined from templates located in "/wp-content/plugins/sell-downloads/sd-templates".

The "sd-templates" directory contains multiple files.

The template files: 

- product.tpl.html is used in the store page.
- product_single.tpl.html is used in particular pages of products.
- product_multiple.tpl.html is used in pages of multiple entries like: archives and search result page.

= Q: Is possible promote a product, or products list? =

A: It is possible promote a product or products list, from the website's sidebars, or directly from the content of pages or posts. 

To promote the products on sidebars, go to the widgets section, and inserts the corresponding widget on sidebar. 

To promote the products from the content of pages and posts, go to the page and press the corresponding icon over the contents editor.

= Q: Are safe the products' downloads? =

A: The security in the access to products files is determined in different ways. 

- The products files can't be accessed directly. The purchased files are stored in a special directory called sd-downloads, the sd-downloads directory includes a .htaccess file that forbid the access from browser. The files can be accessed only through a server side script that validates the purchase.  
- The Store determines the validity of  download links based in three options, available in the settings page of plugin.
-- It is possible define a time period, in days, where a download link is considered valid. If a user tries to download a purchased product, the Store checks the date of purchasing.
-- It is possible define a limit of downloads by purchase. If a user tries to download a product, the Sell Downloads checks how many downloads have been made.
-- The Store may be configured to request the email address used in the purchasing to check the validity of download link.

= Q: Can I customize the store's design? = 

A: The plugin includes some different designs that can be selected through the settings option "Store Layout", but you can create a new once, duplicating an of available store's layouts, and edit its style.css file

= Q: How to configure the IPN on PayPal Sandbox ? =

A: [https://www.paypal.com/cgi-bin/webscr?cmd=p/sell/ipn-test-outside](https://www.paypal.com/cgi-bin/webscr?cmd=p/sell/ipn-test-outside "Configuring the IPN on PayPal Sandbox")

= Q: Is possible to search the products by their types, from the search box of my website? =

A: Yes, that's possible. The products types are taxonomies, and for searching by the products' taxonomies, go to the settings page of the store, and tick the checkbox: "Allow searching by taxonomies", and that's all.

== Screenshots ==
01. Sell Downloads Item
02. Sell Downloads Product Section
03. Product Edition Interface
04. Sell Downloads Insertion Button
05. Sell Downloads Insertion Interface
06. Insertion Interface for Product
07. Insertion Interface for Products List
08. Available Widgets for Products and Products List Insertion
09. Sales Reports
10. Filtering Sales Report
11. Available layouts

== Changelog ==

= 1.0.16 =

* Takes into account the taxes in the IPN script.

= 1.0.15 =

* Reduces the penalization time by IP if the download link is invalid.

= 1.0.14 =

* Allows searching by the taxonomies of the products.
* Includes metatags for including the correct information when the product is shared in Facebook.

= 1.0.13 =

* Allows to enable/disable the PayPal Sandbox in the store's settings for testing the purchases

= 1.0.12 =

* Fixes an issue in the use of friendly URLs in the store's products.

= 1.0.11 =

* Corrects an issue with the use of the predefined layouts in stores protected with Secure Socket Layer (SSL).
* Corrects some messages in the store's settings.

= 1.0.10 =

* Corrects an issue with the pagination in the store's pages.

= 1.0.9 =

* Prevents an error in the installation process, when the user's privileges are not sufficient.

= 1.0.8 =

* Security update to prevent the use of brute force to identify the purchase IDs

= 1.0.7 =

* Corrects a possible vulnerability in the download of purchased files.
* Corrects an issue with files for selling with spaces in their names.

= 1.0.6 =

* Corrects an issue in the store's pagination.
* Selects smaller images as covers of the products to improve the loading speed of the store's page.
* Allows to use friendly URLs, or not, in the products pages.

= 1.0.5 =

* Corrects a conflict in the sales reports with the Music Store plugin.

= 1.0.4 =

* Modifies the styles of Dark layout.

= 1.0.3 =

* Includes the Featured Image as part of products, because some plugins and themes use the featured Images on post types.
* Uses functions included since WordPress 3.5.0, that modifies the requirements.
* Optimize the plugins code.

= 1.0.2 =

* Optimize the plugins code.

= 1.0.1 =

* Improves the plugin documentation.
* Fixes a compatibility issue with the "Music Store" plugin.
* Corrects the decimal digits in the products prices.
* Increases the security of purchased files.
* Removes the "Description" tab from the product's page, if the product has not a description defined.
* Allows ordering the products by date.
* Allows inserting separated stores in different pages of website.
* Corrects an issue displaying free products.
* Optimizes the queries to database.
* Modifies the design of the attribute: product's type, in the store's page.
* Includes the products ID as a column in the list of products.
* Makes a memory checking to avoid errors downloading the purchased files.
* Fixes an issue checking the downloads permissions.
* Allows download large files.
* Improves the store's design in themes with responsive designs.
* Throws the correct content-type header in the download process.
* Includes new filtering options in the sales reports.
* Includes charts in the sales reports to detect the sales trends easily.
* Includes in the currency list, all currencies allowed by PayPal.
* Allows define a limit in the download of purchased products, and the possibility to reset the counter.
* Includes multiple store's layouts.
* Displays a timeout in the download page, if the IPN has not been called, when it is visited.

= 1.0 =

* First version released.

== Upgrade Notice ==

= 1.0.16 =

Important note: If you are using the Professional version don't update via the WP dashboard but using your personal update link. Contact us if you need further information: http://wordpress.dwbooster.com/support