WooCommerce Variable Product Description
===========================================

Adds a description field to each variation of a WooCommerce variable product.

# Description #

The plugin adds a per-variation description that will display underneath the main product variation.
 The definitions will change when variations are chosen similar to how the images change.

