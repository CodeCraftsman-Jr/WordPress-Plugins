=== Donations Widget ===
Contributors: mohanjith
Tags: donations, widget, paypal, moneybookers, alertpay
Requires at least: 2.8
Stable tag: trunk
Tested up to: 3.0.0
Donate link: http://mohanjith.com/c/wordpress

Accept donations from your readers via AlertPay, Moneybookers and/or PayPal.

== Description ==

Accept donations from your readers via AlertPay, Moneybookers or PayPal. Plugin add a widget with payment forms.
You can select which payment options to allow in the widget configuration page.

== Installation ==

1. Upload `donations` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Add the `Donations` widget to your sidebar

== PHP Version ==

PHP 5+

== ChangeLog ==

**Version 1.0.2**

* Add classes to control styling of payment forms

**Version 1.0.1**

* Compatibility with WordPress 3.0.1

**Version 1.0.0**

* Compatibility with WordPress 3.0

**Version 0.1.0**

* Initial release!
