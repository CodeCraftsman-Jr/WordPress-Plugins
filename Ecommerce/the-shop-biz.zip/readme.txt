=== The Shop Biz===
Contributors: NandiniGoel
Donate link: http://educatemygirl.org/support.html
Tags: online, store, theshop.biz, plugin, plugins
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
TheShop.biz provides the Wordpress users with this easy to use Wordpress Plugin which can be used to create a online store in just a matter of few minutes.
All the User needs to do is activate in and after that add a shortcode: <br />
[shop-biz username"your-username"]TheShop Name[/shop-biz]<br />
== Description ==
TheShop.biz provides the WordPress users with this easy to use WordPress Plugin which can be used to create an online store in just a matter of minutes. After the plugin is installed, it is ready to use after the "activate button" has been pressed: <br />
[shop-biz username"your-username"]TheShop Name[/shop-biz]<br><br>

A few notes about the sections above:  <br>
* "NandiniGoel" is a comma delimited list of wp.org/wp-plugins.org usernames  <br>
* "theshop" is a comma delimited list of tags that apply to the plugin <br>
* "3.0.1" is the lowest version that the plugin will work on. <br>
== Installation ==
This section describes how to install the plugin and get it working.
1. Install the Plugin on your Wordpress Site
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create an Account on TheShop.biz
4. Use the Shortcode: <br /> [shop-biz username'your-username']Your Shop Name[/shop-biz]

== Frequently Asked Questions ==
What is the main website? :: Answer- Theshop.biz
== Upgrade Notice ==
None
== Screenshots ==
01. **Store Front Look** - This is how a Store will look on your wordpress site.
02. **TheShop.biz Button in Menu Bar** - TheShop.biz Button will appear like this in the menu bar.
03. **TheShop.biz WP Admin** - This is how theShop.biz Admin Page will look
== Changelog ==
None
