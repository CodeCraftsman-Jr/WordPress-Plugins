<?php
class NamasteLMSStudentModel {
	// this model will first show a page where to select course with dropdown
	// then will show the students in this course in table with lessons, status etc
	// clicking on student name will go to the same page that student sees in their dashboard
	// edit profile is not required because we'll use Wordpress users
	static function manage() {
		 global $wpdb;
		 $_course = new NamasteLMSCourseModel();
		 
		 	$multiuser_access = 'all';
			$multiuser_access = NamasteLMSMultiUser :: check_access('students_access');
		 
		 // select all courses
		 $courses = $_course -> select();
		 $courses = apply_filters('namaste-homeworks-select-courses', $courses);
				 
		 // if course selected, select lessons and enrolled students
		 if(!empty($_GET['course_id'])) {
				do_action('namaste-check-permissions', 'course', $_GET['course_id']);		 	
		 	
				// cleanup student record
				if(!empty($_GET['cleanup'])) {
					 if($multiuser_access  == 'view') wp_die(__('You are not allowed to do this.', 'namaste'));
                self :: cleanup($_GET['course_id'], $_GET['student_id']); 
					 	
					//namaste_redirect("admin.php?page=namaste_students&course_id=$_GET[course_id]&status=$_GET[status]");		
				}		 	
		 	
				// enroll student
				if(!empty($_GET['enroll'])) {
					 if($multiuser_access  == 'view') wp_die(__('You are not allowed to do this.', 'namaste'));
					 	
					 // find the user
					 $error = false;
					 if(strstr($_GET['email'], '@')) $student = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->users} WHERE user_email=%s", $_GET['email']));
					 else $student = get_user_by('login', $_GET['email']);
					 
					 // user exists?
					 if(empty($student->ID)) $error = __('Sorry, I cannot find user with this email or user handle.', 'namaste');
					 
					 // allowed to use Namaste!?
					 if(!$error and !user_can($student->ID, 'administrator') and !user_can($student->ID, 'namaste')) {
					 	$error = __("This user's role does not allow them to use Namaste! LMS. You'll have either to change their role or allow the role work with the LMS from the Settings page", 'namaste');
					 }	
					 
					 // already enrolled?
					 if(!$error) {
						 $is_enrolled = $wpdb->get_var($wpdb->prepare("SELECT id FROM ".NAMASTE_STUDENT_COURSES."
						 	WHERE user_id = %d AND course_id = %d", $student->ID, $_GET['course_id']));
						 if($is_enrolled) $error = __('This user is already enrolled in the course', 'namaste');
					 }
					 
					 // finally, enroll
					 if(empty($error)) {
					 		$wpdb -> query($wpdb -> prepare("INSERT INTO ".NAMASTE_STUDENT_COURSES." SET
					 			course_id = %d, user_id = %d, status = 'enrolled', 
					 			enrollment_date = %s, completion_date = '1900-01-01', enrollment_time=%s, comments=''",
					 			$_GET['course_id'], $student->ID, date("Y-m-d", current_time('timestamp')), current_time('mysql') ));
					 		$success = __('User successfully enrolled in the course', 'namaste');	
					 		
					 		// insert in history
					 		$course = get_post($_GET['course_id']);
					 		$wpdb->query($wpdb->prepare("INSERT INTO ".NAMASTE_HISTORY." SET
								user_id=%d, date=CURDATE(), datetime=NOW(), action='enrolled_course', value=%s, num_value=%d",
								$student->ID, sprintf(__('Enrolled in course %s. Status: %s', 'namaste'), $course->post_title, 'enrolled'), $_GET['course_id']));
					 		
					 		// do_action('namaste_enrolled_course', $student->ID, $_GET['course_id'], true);
					 }	
				}
				
				// change student status
				if(!empty($_GET['change_status'])) {
					if($multiuser_access  == 'view') wp_die(__('You are not allowed to do this.', 'namaste'));
					
					 $wpdb->query($wpdb->prepare("UPDATE ".NAMASTE_STUDENT_COURSES." SET
					 			status=%s, completion_date=%s, completion_time=%s 
					 			WHERE user_id=%d AND course_id=%d", $_GET['status'], 
					 			date("Y-m-d", current_time('timestamp')), current_time('mysql'), $_GET['student_id'], $_GET['course_id']));
					 			
					 $course = get_post($_GET['course_id']);
					 			
					 if($_GET['status'] == 'enrolled') {
					 	do_action('namaste_enrollment_approved', $_GET['student_id'], $_GET['course_id']);
					 	$history_msg = sprintf(__('Enrollment in %s has been approved.','namaste'), $course->post_title);
					 }
					 else {
					 	do_action('namaste_enrollment_rejected', $_GET['student_id'], $_GET['course_id']);
					 	$history_msg = sprintf(__('Enrollment in %s has been rejected.','namaste'), $course->post_title);
					 }	
					 
					 // insert in history
					$wpdb->query($wpdb->prepare("INSERT INTO ".NAMASTE_HISTORY." SET
								user_id=%d, date=CURDATE(), datetime=NOW(), action='enrolled_course', value=%s, num_value=%d",
								$_GET['student_id'], $history_msg, $_GET['course_id']));
					 					
					 namaste_redirect("admin.php?page=namaste_students&course_id=$_GET[course_id]");					 							 	
				}				
				 	
		 		// select lessons
		 		$_lesson = new NamasteLMSLessonModel();
		 		$lessons = $_lesson -> select($_GET['course_id']);
		 		$lids = array(0);
		 		foreach($lessons as $lesson) $lids[] = $lesson->ID;
		 				 		
		 		// select students
		 		$page_limit = 20;
		 		$offset = empty($_GET['offset']) ? 0 : intval($_GET['offset']);
		 		$status_sql = '';
		 		if(!empty($_GET['status']) and $_GET['status']!='any') { 
		 			$status_sql = $wpdb->prepare(" AND tS.status=%s", $_GET['status']);
		 		}
		 		$students = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS tU.*, tS.status as namaste_status 
			 		FROM {$wpdb->users} tU JOIN ".NAMASTE_STUDENT_COURSES." tS 
			 		ON tS.user_id = tU.ID AND tS.course_id=%d $status_sql
			 		ORDER BY user_nicename LIMIT %d, %d", $_GET['course_id'], $offset, $page_limit));	
		 		$count = $wpdb->get_var("SELECT FOUND_ROWS()");	 		
		 		
		 		// select student - to - lesson relations
		 		$completed_lessons = $wpdb->get_results("SELECT * FROM ".NAMASTE_STUDENT_LESSONS."
		 			WHERE lesson_id IN (".implode(',', $lids).")");	
		 				 		
		 		// match to students	
		 		foreach($students	as $cnt=>$student) {
		 			 $student_completed_lessons = $student_incomplete_lessons = array();
		 			 foreach($completed_lessons as $lesson) {
		 			 		if($lesson->student_id == $student->ID) {
		 			 				if($lesson->status) $student_completed_lessons[] = $lesson->lesson_id;
		 			 				else $student_incomplete_lessons[] = $lesson->lesson_id;
		 			 		}
		 			 }	
		 			 
		 			 $students[$cnt]->completed_lessons = $student_completed_lessons;
		 			 $students[$cnt]->incomplete_lessons = $student_incomplete_lessons;
		 		}
		 } // end if course selected
		 
		wp_enqueue_script('thickbox',null,array('jquery'));
	   wp_enqueue_style('thickbox.css', '/'.WPINC.'/js/thickbox/thickbox.css', null, '1.0');
		if(@file_exists(get_stylesheet_directory().'/namaste/manage-students.php')) require get_stylesheet_directory().'/namaste/manage-students.php';
		else require(NAMASTE_PATH."/views/manage-students.php");
	}
	
	// change lesson status - not started (so the record in namatse_student_lessons does not exist),
	// in progress (0 + update with current date), and completed (1 + update with current date)
	static function lesson_status($student_id, $lesson_id, $status) {
		global $wpdb, $user_ID;
		
		// security check
		$multiuser_access = 'all';
		$multiuser_access = NamasteLMSMultiUser :: check_access('students_access');
		if( (!current_user_can('namaste_manage') or $multiuser_access == 'view') 
				and $user_ID != $student_id) {
			wp_die(__("You cannot change someone else's status", 'namaste'));
		}
			
		// if status == -1 we have to remove the existing record if any
		if($status == -1) {
			 $wpdb -> query($wpdb->prepare("DELETE FROM ".NAMASTE_STUDENT_LESSONS." 
			 	WHERE student_id = %d AND lesson_id = %d", $student_id, $lesson_id));	
		}
		
		// complete lesson - don't allow "completed" if there are unsatisfied requirements
	  if($status == 1) {
			if(!NamasteLMSLessonModel :: is_ready($lesson_id, $student_id, true)) return false; 
			
			NamasteLMSLessonModel :: complete($lesson_id, $student_id);
	  }		
		
		// set as 'in progress'
		if($status == 0 ) {
			 // record exists?
			 $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM ".NAMASTE_STUDENT_LESSONS."
			 	WHERE student_id = %d AND lesson_id = %d", $student_id, $lesson_id));
			 
			 if($exists) {
			 		$wpdb->query($wpdb->prepare("UPDATE ".NAMASTE_STUDENT_LESSONS." 
			 			SET status=%d, completion_date = %s, completion_time=%s WHERE id=%d", 
			 			$status, date("Y-m-d", current_time('timestamp')), current_time('mysql'), $exists));
			 } 
			 else {
			 		$wpdb->query($wpdb->prepare("INSERT INTO ".NAMASTE_STUDENT_LESSONS." SET
			 			lesson_id = %d, student_id = %d, status = %d, completion_date = %s, completion_time=%s",
			 			$lesson_id, $student_id, $status, date("Y-m-d", current_time('timestamp')), current_time('mysql')));
			 }	
		}	
		
		return true;
	} // end lesson_status
	
	// is student enrolled in course?
	static function is_enrolled($student_id, $course_id) {
		global $wpdb;
		
		$is_enrolled = $wpdb -> get_var( $wpdb->prepare("SELECT id FROM ".NAMASTE_STUDENT_COURSES."
			WHERE user_id = %d AND course_id = %d", $student_id, $course_id));
			
		return $is_enrolled;	
	}
	
	// cleanup data about student - course relation
	
	static function cleanup($course_id, $student_id) {
		global $wpdb;
		
		$wpdb->query( $wpdb->prepare("DELETE FROM ".NAMASTE_STUDENT_COURSES." 
		 	WHERE course_id = %d AND user_id=%d", $course_id, $student_id) );
		 	
		 $wpdb->query( $wpdb->prepare("DELETE FROM ".NAMASTE_STUDENT_LESSONS." WHERE student_id= %d AND lesson_id IN (SELECT ID FROM {$wpdb->posts} tP JOIN {$wpdb->postmeta} tM ON tM.post_id = tP.ID AND tM.meta_key = 'namaste_course' AND tM.meta_value = %d WHERE post_type = 'namaste_lesson');", $student_id, $course_id) );					
		 
		// delete solutions
		$wpdb->query($wpdb->prepare("DELETE FROM ".NAMASTE_STUDENT_HOMEWORKS." WHERE student_id=%d
			AND homework_id IN (SELECT id FROM ".NAMASTE_HOMEWORKS." WHERE course_id=%d)", $student_id, $course_id)); 					 
		// cleanup exams data? 
		$use_exams = get_option('namaste_use_exams');
		if($use_exams and get_option('namaste_cleanup_exams') == 'yes') {
			// select all exam IDs of related lessons
			$_lesson = new NamasteLMSLessonModel();
			$lessons = $_lesson->select($course_id);
			$exam_ids = array(0);
			foreach($lessons as $lesson) {
				$exam_id = get_post_meta($lesson->ID, 'namaste_required_exam', true);
				if(!empty($exam_id)) $exam_ids[] = $exam_id;
			}
			
			// now delete
			if($use_exams == 'watu') {
				$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}watu_takings WHERE user_id=%d AND exam_id IN (".implode(',', $exam_ids).")", $student_id));
			}
			
			if($use_exams == 'watupro') {
				$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}watupro_taken_exams WHERE user_id=%d AND exam_id IN (".implode(',', $exam_ids).")", $student_id));
				$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}watupro_student_answers WHERE user_id=%d AND exam_id IN (".implode(',', $exam_ids).")", $student_id));
			}
		}  	
	} // end cleanup()  
}