== NganLuong.vn cho Woocommerce ==
Contributors: SonTQ
Tags: woocommerce,vietnamese,nganluong
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 0.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tích hợp cổng thanh toán NganLuong.vn vào Woocommerce.

== Description ==
Tích hợp cổng thanh toán NganLuong.vn vào Woocommerce.

1. Kích hoạt plugin trong khu vực Plugins -> Installed Plugins
2. Vào Woocommerce -> Settings -> Payment Gateways và chọn NganLuongPaygate

== Installation ==
1. Upload thư mục \'nganluongvn-paygate\' vào wp-content/plugins
2. Kích hoạt plugin trong khu vực Plugins -> Installed Plugins
3. Vào Woocommerce -> Settings -> Payment Gateways và chọn NganLuongPaygate

== Change Logs ==
v0.1.0:
	- Xây dựng cơ bản trên plugin của MinhZ
v0.1.1:
	- Cập nhật trạng thái đơn hàng sau khi thanh toán qua ngân lượng.
	- Tạm bỏ chức năng chuyển về custom page.
v0.1.2:
	- Fix lỗi người dùng sửa giá trị input từ bản plugin gốc của MinhZ
