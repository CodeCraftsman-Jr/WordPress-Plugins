<?php
namespace mls;
/**
 * Use as to handle templating for various views on each template
 * */
class Layout_Property{
}
