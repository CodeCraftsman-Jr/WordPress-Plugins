<?php
require plugin_dir_path( __FILE__ ) . 'class-text.php';
require plugin_dir_path( __FILE__ ) . 'class-pagination.php';
require plugin_dir_path( __FILE__ ) . 'class-gmap.php';
require plugin_dir_path( __FILE__ ) . 'class-cookies.php';
require plugin_dir_path( __FILE__ ) . 'class-template.php';
