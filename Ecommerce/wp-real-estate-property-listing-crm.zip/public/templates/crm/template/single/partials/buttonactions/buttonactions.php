<div class="panel panel-default">
  <div class="panel-body">
   <?php \Action_Buttons::get_instance()->display($args_button_action); ?>
  </div>
</div>
