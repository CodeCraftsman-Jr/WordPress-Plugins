<form role="form" class="profile-form" method="POST">
	<h2>Profile</h2>
	<div class="form-group">
		<input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name">
	</div>
	<div class="form-group">
		<input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name">
	</div>
	<div class="form-group">
		<input type="email" class="form-control" id="emailaddress" name="emailaddress" placeholder="Enter email">
	</div>
	<div class="form-group">
		<input type="text" class="form-control" id="phone" name="phone" placeholder="Phone Number">
	</div>
	<button type="submit" class="btn btn-primary registersend">Update</button>
</form>
