<?php
/**
 * Template Name: Full Width List
 *
 */
?>
<p>Test</p>
