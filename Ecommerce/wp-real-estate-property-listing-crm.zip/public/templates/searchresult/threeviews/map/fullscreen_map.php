<?php get_header(); ?>
<?php require $map_content; ?>
<?php wp_footer(); ?>

