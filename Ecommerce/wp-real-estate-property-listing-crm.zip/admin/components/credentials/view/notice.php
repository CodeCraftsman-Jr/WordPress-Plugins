<div class="md-notice">
	<h3>It seems you have no CRM API Key, please <a href="<?php echo MD_PLUGIN_PAGE;?>" target="_blank">click here to get api key</a></h3>
</div>
