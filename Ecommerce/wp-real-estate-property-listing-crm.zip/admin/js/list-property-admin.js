(function( $ ) {
	'use strict';

	$(window).load(function(){

	});
})( jQuery );
