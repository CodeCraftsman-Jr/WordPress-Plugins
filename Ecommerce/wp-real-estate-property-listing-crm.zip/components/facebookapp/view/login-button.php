<fb:login-button scope="public_profile,email" size="large" onlogin="checkLoginState();">
	Facebook
</fb:login-button>
