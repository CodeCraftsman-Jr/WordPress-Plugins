<a class="butonactions btn btn-default btn-xs <?php echo $class;?> print-pdf-action" href="<?php echo $url;?>" role="button"><?php echo $label;?></a>
