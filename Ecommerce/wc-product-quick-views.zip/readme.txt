===Prodcut Quick View===
Contributors: (iwcontribution)

Tags: Woocommerce, Quick View, Woocommerce Extension
Requires at least: 3.5.1
Tested up to: 4.2.2
Quick View allows Product Quick View.

== Description ==
This is Woocommerce Quick View extension which helps to make product quick view.This extension helps to view product details with review.

== Installation ==
1. To run this extension make sure that you have installed woocommerce plugin and activate it.
2. Download the Quick View plugin zip file and extract to the  `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress Admin.

== Screenshots ==
1. WooCommerce Backend Settings "General" page.
2. In General page you have checkbox option called Quick View , make it checked.
3. This is Front-End Quick View Page. By Clicking on that you can see the quick view of a product.

= 1.0 =
The First Release

