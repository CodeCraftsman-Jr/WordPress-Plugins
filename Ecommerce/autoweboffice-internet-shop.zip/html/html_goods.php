<div id="center-panel">
<?php 
if($awo_goods)
{
	echo $awo_goods->awo_description;
}
else
{
	echo 'Запрашиваемой вами страницы не существует на сайте нашей компании.';
} 
?>
</div> <!-- /#center-panel -->
