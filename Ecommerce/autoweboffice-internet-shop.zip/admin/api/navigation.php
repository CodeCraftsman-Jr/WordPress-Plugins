<h2 class="nav-tab-wrapper">
	<a class="nav-tab <?php if($_GET['tab'] == 'api' or !isset($_GET['tab'])) echo 'nav-tab-active';?>" href="admin.php?page=awo-api&tab=api">Настройки подключения к АвтоОфис</a>
</h2>