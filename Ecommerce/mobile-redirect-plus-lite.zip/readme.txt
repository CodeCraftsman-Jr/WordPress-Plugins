=== Plugin Name ===
Contributors: iqbalbary
Plugin Name: WP Mobile Redirect
Plugin URI: http://iqbalbary.com/item/wp-redirect/
Tags: redirect, mobile redirect, tablet redirect, wp mobile, android redirect, iphone redirect, ipad redirect, wordpress mobile
Author URI: http://iqbalbary.com
Author: Iqbal Bary 
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 2.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Detect mobile device and redirect to mobile optimize website. You can also choose whether or not to redirect tablets by enabling or disabling the check-box option. This plugin also gives you the ability to redirect back for viewing full version website. Place a link "http://example.com/?main=true" in your mobile website for that.

== Description ==

Detect mobile device and redirect to mobile optimize website. You can also choose whether or not to redirect tablets by enabling or disabling the check-box option. This plugin also gives you the ability to redirect back for viewing full version website. Place a link "http://example.com/?main=true" in your mobile website for that.

== Installation ==

The quickest method for installing the importer is:

1. Upload the `mobile-redirect-plus-lite` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Settings -> Mobile Redirect+ Lite


== Frequently Asked Questions ==


== Screenshots ==

1. Mobile Redirect Plus Lite Options

== Changelog ==

= 2.5 =
* Bug Fix
= 2.4 =
* Bug Fix
= 2.3 =
* Initial Release

