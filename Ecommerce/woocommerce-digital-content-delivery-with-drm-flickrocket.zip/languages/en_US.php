<?php
// list of field labels
define("SITEUSER_EMAILADDRESS", "Email Address");
define("SITEUSER_USERNAME", "Slideshowname");
define("SITEUSER_PASSWORD", "Password");
define("SITEUSER_CONFIRM_PASSWORD", "Confirm Password");
define("SITEUSER_FIRST_NAME", "First Name");
define("SITEUSER_LAST_NAME", "Last Name");
define("SITEUSER_ADDRESS1", "Address1");
define("SITEUSER_ADDRESS2", "Address2");
define("SITEUSER_CITY", "City");
define("SITEUSER_STATE", "State");
define("SITEUSER_COUNTRY", "Country");
define("SITEUSER_ZIPCODE", "Zipcode");
?>