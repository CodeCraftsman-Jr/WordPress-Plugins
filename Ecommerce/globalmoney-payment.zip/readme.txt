=== GlobalMoney payment ===
Contributors: GlobalMoney, Maxim Rudniy
Tags: cart, shopping cart, WordPress shopping cart, GlobalMoney shopping cart, sell, selling, sell products, online shop, shop, e-commerce, wordpress ecommerce, wordpress store, store, GlobalMoney cart widget, sell digital products, sell service, digital downloads, globalmoney, globalmoney cart, e-shop, compact cart, coupon, discount
Requires at least: 4.1.1
Tested up to: 4.1.1
Stable tag: 4.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

GlobalMoney payment plugin

== Description ==
GlobalMoney payment plugin

== Screenshots ==
1. Plugin settings

== Installation ==
1. Upload the entire GlobalMoney folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the \'Plugins\' menu in WordPress.
You will find \'GlobalMoney\' menu in your WordPress admin panel.
