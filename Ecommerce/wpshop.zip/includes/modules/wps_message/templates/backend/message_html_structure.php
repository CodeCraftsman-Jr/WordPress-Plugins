<div style="font: 11px/1.35em  Arial, Helvetica, sans-serif; color: #000;">
	<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0" bgcolor="#F0F0F0">
		<tbody>
			<tr>
				<td style="padding: 0px;" align="center" valign="top">
					<table style="border: 1px solid #e0e0e0; width: 675px;" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
						<tbody>
							<tr>
								<td valign="top">[your_shop_logo]</td>
							</tr>
							<tr>
							<td valign="top">
								<?php echo $message; ?>
							</td>
							</tr>
							<tr>
							<td></td>
							</tr>
							<tr>
							<td style="background-color: #dcdcdc; text-align: center;" align="center" bgcolor="#F0F0F0">
								<span style="font-size: 12px; line-height: 16px; margin: 0px;"><?php echo get_bloginfo( 'name' ); ?></span>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</div>
