<input type="button" data-id="<?php echo get_the_ID(); ?>" class="button-secondary wpeo-reset-bubble-all-user" value="<?php _e("Reset this bubble for all users", self::$name_i18n); ?>" />
