<div class="wps-boxed">
	<?php echo $attributes_sections_tpl; ?>
	<?php if( !$is_from_admin ) : ?>
	<div><button class="wps-bton-first-mini-rounded" id="wps_modal_account_informations_opener"><?php _e( 'Edit your account informations', 'wpshop')?></button></div>
	<?php endif; ?>
</div>
