<span class="wps-h4"><?php _e( $attributes_section->name, 'wpshop' ); ?></span>
<div><?php echo $attribute_details; ?></div>
