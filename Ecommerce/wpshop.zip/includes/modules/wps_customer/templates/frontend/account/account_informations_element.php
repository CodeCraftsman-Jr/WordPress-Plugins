<div class="wps-form-group">
	<?php echo stripslashes( $attribute_def->frontend_label ); ?> : <?php echo ( !empty($attribute_value) ) ? $attribute_value : ''; ?>
</div>

