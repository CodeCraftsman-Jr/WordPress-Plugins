<div class="wps-modal-overlay"></div>
<div class="wps-modal-wrapper">	
	<div class="wps-modal-container">
		<div class="wps-modal-content-rounded">
			<div class="wps-modal-header">
				<button type="button" class="wps-bton-icon-close-fullrounded  wpsjq-closeModal"></button>
				<h3></h3>
			</div>
			<div class="wps-modal-body">
				
			</div>
			<div class="wps-modal-footer"></div>
		</div><!-- .wps-modal-content -->
	</div><!-- #wps-modal-container -->
</div><!-- .wps-modal-wrapper -->

