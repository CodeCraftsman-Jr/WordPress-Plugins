<div class="wps-table-content wps-table-row">
		<div class="wps-table-cell"><?php echo $coupon_value; ?></div>
		<div class="wps-table-cell"><?php echo $coupon_validity_date; ?></div>
		<div class="wps-table-cell"><?php echo $coupon_code; ?></div>
</div>



