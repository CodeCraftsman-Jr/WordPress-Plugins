<a href="#" class="wps-bton-mini-first-rounded" id="upload_wps_product_media"><?php _e( 'Download media', 'wpshop'); ?></a>
<input type="hidden" value="<?php echo $media_id_data; ?>" name="product_media" id="product_media_indicator" />
<div id="selected_media_container"><?php echo $media; ?></div>