<?php echo do_shortcode('[wps_cart]'); ?>
