<?php
echo $checkout_step_indicator;
echo $checkout_content;