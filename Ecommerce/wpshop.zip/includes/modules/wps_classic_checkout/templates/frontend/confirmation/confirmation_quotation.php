<div><p><?php _e('Thank you ! Your quotation has been sent. We will respond to you as soon as possible.', 'wpshop'); ?></p></div>
<?php wpshop_cart::empty_cart();  ?>
