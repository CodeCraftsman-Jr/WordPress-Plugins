<div class="wps-boxed">
	<p><?php _e('Thank you ! Your quotation has been sent. We will respond to you as soon as possible.', 'wpshop'); ?></p>
</div>
<?php 
// Empty Cart
$wps_cart->empty_cart(); 
?>
