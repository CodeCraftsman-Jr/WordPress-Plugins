<div class="wps-boxed">
	<p><?php _e('Thank you ! Your order as been successfully saved. You will pay your order on delivery. Thank you for your loyalty.', 'wpshop'); ?></p>
</div>
<?php 
// Empty Cart
$wps_cart->empty_cart(); 
?>
