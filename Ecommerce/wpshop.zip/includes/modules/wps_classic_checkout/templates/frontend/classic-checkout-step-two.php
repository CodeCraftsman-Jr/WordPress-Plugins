<?php echo do_shortcode('[wpshop_login]'); ?>
