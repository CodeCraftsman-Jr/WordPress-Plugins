jQuery( document ).ready( function() {
	 jQuery('.wps-color-picker-field').iris({
	        width: 200,
	        hide: true,
	  });
});