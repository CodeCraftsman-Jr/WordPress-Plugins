<div class="wps-cart-resume" id="wps_resume_cart_container" >
	<?php echo $cart_summary_content; ?>
</div>
