jQuery( document ).ready( function() {
	jQuery( "#wps_payment_mode_list_container" ).sortable();
});