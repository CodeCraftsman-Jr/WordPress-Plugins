<script type="text/javascript" >
	var wps_address_loading_picture = "<img src='<?php echo admin_url( "images/loading.gif" ); ?>' />";
</script>