<a href="<?php echo admin_url( 'post.php?post=' . $post_id . '&amp;action=edit' ); ?>" ><?php echo $post_id; ?></a>
<div class="row-actions" >
	<a href="<?php echo admin_url( 'post.php?post=' . $post_id . '&amp;action=edit' ); ?>" ><?php _e( 'Edit' ); ?></a>
</div>