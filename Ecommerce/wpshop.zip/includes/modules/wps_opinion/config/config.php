<?php
DEFINE( 'WPS_OPINION_ID', 'wps_opinion');