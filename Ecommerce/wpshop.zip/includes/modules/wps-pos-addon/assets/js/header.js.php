<script type="text/javascript">
	var wpspos_sure_to_load_element_having_nothing = "<?php _e('It seems that no element exists for this letter, would you like to load the list?', 'wps-pos-i18n'); ?>";
	var wpspos_confirm_product_deletion_from_order = "<?php _e( 'Are you sure you want to delete this product from the order?', 'wps-pos-I18n' ); ?>";
	var wps_pos_product_with_variation_box = "<?php _e( 'Product with variation selection', 'wps-pos-I18n' ); ?>";
</script>