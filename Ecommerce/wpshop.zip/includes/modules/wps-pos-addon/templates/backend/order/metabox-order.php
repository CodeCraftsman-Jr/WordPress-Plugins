<div class="wps-alert wpshopHide" id="wps-pos-order-content-alert" ></div>
<div id="wps_cart_container" class="wps-bloc-loader">
	<?php echo $this->display_wps_pos_order_content(); ?>
</div>