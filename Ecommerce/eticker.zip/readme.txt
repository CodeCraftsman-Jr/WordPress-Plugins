=== eTicker ===
Contributors: Tukker
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=YWL9TNK8KMY3A&lc=NL&item_name=iTukker&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: flash, banner, image, message, ticker 
Requires at least: 2.5 or higher
Tested up to: 2.9.1
Stable tag: 1.0.1

Create a flash ticker like message on your WordPress site.

== Description ==

This plugin creates a ticker like text message on your Wordpress site.
Add a shortcode with your message to your post, thats all you need to do :)   

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the `eticker` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `[itk-eticker]your message[/itk-eticker]` on your pages/posts
1. Or add <?php echo(itk_eticker_show(`your message`)); ?> to your theme

== Frequently Asked Questions ==

An answer is only one question away...

== Screenshots ==

1. eTicker in action.

== Upgrade Notice ==

not applicable

== Changelog ==

= 1.0.0 =
* First release

= 1.0.1 =
* Solved issue in IE