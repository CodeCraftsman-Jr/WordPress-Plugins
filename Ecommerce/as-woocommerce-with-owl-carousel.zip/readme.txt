=== As woocomerce with owl carousel ===
Contributors: anuislam
Tags: carousel, owl carousel, woocomerce carousel slider, jquery carousel, jquery plugin,as login,as,anuislam,branding,custom login,login, login background, login logo, login screen, style login, theme login, wp-login,extra css, theme, theme colors, Theme customization, theme styles, theme tweaking,attack, authentication, block, brute force, challenge, control, credentials, hacker, key, limit, lock, login, prevent, private, protect, reject, response, restrict, security, stop,admin, branding, custom login, custom login pro, customization,customize login ,error,  login error, logo,access, account, admin,custom, e-mail, gravatar, log in, login, redirection, register, registration, sidebar, theme, widget,captcha, editor, form, frontend, honeypot, internationalization, languages, login, lost password, registration, responsive, role, shortcode, wordpress, AJAX, AJAX login, buddypress, multi-site, redirect, registration, sidebar, label,input field,color,Facebook,Twitter,Google,Pin it,manage, modal, password, plugin, redirect, register, username,Auth, authentication, ban, brute, brute force, cookie, force,lock,lockdown,maintenance, password, password strength, passwords, security, strength, strong, strong passwords, timeout, users, Hide ,lost,back to blog, link, links,hover, button,image, photo, form position,form, customizer,error,form style, google plus, html, image, jquery, jquery form, linkedin, log in, login, login error, login form, login form plugin, logo, ogin page, plugin, role, security login, sideshow, social connect, social form, social share, style log in, style login, subscriber, themes, twitter, wordpress admin login, wordpress login, wp login form, wp-login, admin, branding, custom, customisation, customise, customize, dashboard, erident, form, login, logo,border, size ,hide error,own css, own look, page, pages, plugin, Post, posts,html,change ,logo, custom, transparent form
Requires at least: 3.5
Tested up to: 4.2.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

As woocomerce with owl carousel is a jquery carousel plugin for WordPress site. This plugin will create a nice Carousel  for your Woocomerce Theme website.

== Description ==

As woocommerce with owl carousel is a jquery plugin for WordPress site. This plugin will create a nice carousel for your site. After installing and Activating the plugin, go to WordPress Admin Dahsbord and then go to
<pre>
Appearance > As option
</pre>
Here you can create Shortcode and publish a carousel for your site. So create a Shortcode as you choice and see a nice carousel at your site front-end.
<h3>How to use</h3>
Go to Appearance > As option, Here is a Shortcode creator enging. So fill the input field as your choice.
Click get shortcode and copy this shortcode publish this.
Save button is optional if you need save all option you can use it.
Note! Carousel Name must be an unique name. If you not use unique name so carousel not working.


<h3>Features</h3>

1. Shortcode System,
2. woocommerce Prodct slider,
3. WordPress Jquery,
4. Fully responsive,
5. Work With all latest Version WordPress,
6. Mobile Touch,
7. Many more option,
8. 9 Deterrent button,
9. 6 Deterrent carousel icon.

See on <a href="https://github.com/anuislam/as-woocommerce-with-owl-carousel">github.com</a>


All credit goes to Owl Carousel and Woocommerce

== Installation ==

1. Upload ‘as-woocommerce-with-owl-carousel‘ folder to the ‘/wp-content/plugins/’ directory or Install as a regullar WordPress plugin
2. You will see a options page go to Appearance > As option and create short code.

== Screenshots ==

1. Demo 1.
2. Demo 2.
3. installed in test server option demo all shortcode creator option.
4. 9 Deterrent button or 6 Deterrent carousel icon.
5. Shortcode creator enging output.

== Changelog ==

= 1.2 =
*Release Date - 8th August, 2015*
* Include some html, css.

= 1.0 =
* Initial Release 

== Upgrade Notice ==
Upgrade to Version 1.2