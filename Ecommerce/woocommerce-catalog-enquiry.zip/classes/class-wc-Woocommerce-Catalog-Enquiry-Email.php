<?php
class WC_Woocommerce_Catalog_Enquiry_Email extends WC_Email {
  
 
}
