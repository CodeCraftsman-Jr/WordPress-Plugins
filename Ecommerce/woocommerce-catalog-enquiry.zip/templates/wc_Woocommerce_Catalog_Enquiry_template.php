<?php
/**
 * The template for displaying demo plugin content.
 *
 * Override this template by copying it to yourtheme/wc-Woocommerce-Catalog-Enquiry/wc-Woocommerce-Catalog-Enquiry_template.php
 *
 * @author 		dualcube
 * @package 	wc-Woocommerce-Catalog-Enquiry/Templates
 * @version     0.0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
global $post;

echo $demo_value;
?>