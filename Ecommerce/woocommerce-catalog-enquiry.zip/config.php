<?php

define('WC_WOOCOMMERCE_CATALOG_ENQUIRY_PLUGIN_TOKEN', 'wc-Woocommerce-Catalog-Enquiry');

define('WC_WOOCOMMERCE_CATALOG_ENQUIRY_TEXT_DOMAIN', 'Woocommerce_Catalog_Enquiry');

define('WC_WOOCOMMERCE_CATALOG_ENQUIRY_PLUGIN_VERSION', '2.3.0');
?>