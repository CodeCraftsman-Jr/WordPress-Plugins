=== Plugin Name ===
Contributors: shopmylabel
Donate link: http://www.shopmylabel.com/mme
Tags: ecommerce, fashion, media, marketplace, commerce
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.3.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shop My Label Media Marketplace Engine lets you sell items with an onsite cart and checkout.

== Description ==

Shop My Label Media Marketplace Engine lets you sell items with an onsite cart and checkout. Create shop windows at
http://www.shopmylabel.com/create. Use the embed button to get the Wordpress snippet to include in your post.
This plugin expands those snippets to be fully browsable and shoppable shop windows on your sites.

Before installing, you need to get an SSL certificate from your hosting provider. We also recommend use of the
Wordpress HTTPS plugin <http://wordpress.org/extend/plugins/wordpress-https/>. When you can connect to
https://yourblogname.com and not see any errors in the padlock in the URL bar, you are ready to install MME.

This plugin will add a few urls to your blog to handle adding <strong>MME</strong> to your blog. The only link
you may want to add to your template is  <strong>{blogname}/cart</strong>.  This will allow clients to checkout
from your blog using the MME.  The plugin will give clients an option to go to this link after adding an item to
their cart.   This plugin requires permalinks be turned on, mod_rewrite (if hosted locally), and no categories
named in conflict with the newly rewritten URLs.

Support is available at mme@shopmylabel.com

== Frequently Asked Questions ==

= None so far =

But we're ready.


== Changelog ==

= 1.3 =
* First public release.


