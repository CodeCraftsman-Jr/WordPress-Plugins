mme
===

Shop My Label Media Marketplace Engine Wordpress Plugin

To package up plugin use command:

```sh
git archive -o sml_shopkeeper.zip HEAD
```

And upload zip file.