<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<img height="1" width="1" style="position:absolute;top:0;left:0;" src="<?php echo $api->getConfigOption('pixel'); ?>" />