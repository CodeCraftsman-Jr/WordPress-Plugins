jQuery(document).ready(function($){
	$('.fusion-color-picker').wpColorPicker();
});