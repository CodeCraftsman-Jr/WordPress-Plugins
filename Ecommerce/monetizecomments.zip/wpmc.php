<?php

/*
Plugin Name: Monetize Comments
Version: 1.0.0
Plugin URI: http://www.monetizecomments.com
Author: MonetizeComments
Author URI: http://www.monetizecomments.com
Description: The Monetize Comments does just that. It provides a way for publishers to monetize their comments section by using an intellignt form. Find out more at MonetizeComments.com
*/



define( "WPMC_FILE", __FILE__ );

require_once dirname( WPMC_FILE )."/includes/wpmc.php";