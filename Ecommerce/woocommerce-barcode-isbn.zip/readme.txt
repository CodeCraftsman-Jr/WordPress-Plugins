=== WooCommerce Barcode & ISBN ===
Auther: We are AG
Donate link: https://weareag.co.uk/
Tags: WooCommerce, Barcode, ISBN, Product
Requires at least: 4.2.2
Tested up to: 4.2.2
Stable tag: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A super little light plugin to add product barcode and ISBN number to your WooCommerce edit product screen.
The entered values will display just under the meta section of your product page on the front end, just under the SKU information.

= Where can I get support? =

The support can be found at <a href="https://www.weareag.co.uk/contact/">We are AG</a>.

= Where can I find documentation? =

The documentation codex can be found <a href="https://www.weareag.co.uk/add-barcode-meta-box-woocommerce/">here</a>.

= Where can I report a bug? =

Report bugs and participate in development at <a href="https://www.weareag.co.uk/contact/">We are AG</a>.

= Do you do customisation ? =

YES We do theme and plugin development contact us to find out more <a href="https://www.weareag.co.uk/contact/">We are AG</a>.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. All done


== Screenshots ==

1. Product settings
2. Front end

== Changelog ==

= 1.0 =
* launch.



== A brief Markdown Example ==

Ordered list:

Add barcode feild to WooCommerce edit product screen and display on product page

Add ISBN feild to WooCommerce edit product screen and display on product page