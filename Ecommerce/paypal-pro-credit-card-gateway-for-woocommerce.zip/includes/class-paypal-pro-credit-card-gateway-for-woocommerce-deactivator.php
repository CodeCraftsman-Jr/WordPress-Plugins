<?php

/**
 * @class       PayPal_Pro_Credit_Card_Gateway_For_WooCommerce_Deactivator
 * @version	1.0.0
 * @package	paypal-pro-credit-card-gateway-for-woocommerce
 * @category	Class
 * @author      johnny manziel <phpwebcreators@gmail.com>
 */
class PayPal_Pro_Credit_Card_Gateway_For_WooCommerce_Deactivator {

    /**
     *
     * @since    1.0.0
     */
    public static function deactivate() {
        
    }

}
