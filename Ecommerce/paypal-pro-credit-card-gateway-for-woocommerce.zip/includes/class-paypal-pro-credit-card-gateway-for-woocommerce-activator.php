<?php

/**
 * @class       PayPal_Pro_Credit_Card_Gateway_For_WooCommerce_Activator
 * @version	1.0.0
 * @package	paypal-pro-credit-card-gateway-for-woocommerce
 * @category	Class
 * @author      johnny manziel <phpwebcreators@gmail.com>
 */
class PayPal_Pro_Credit_Card_Gateway_For_WooCommerce_Activator {

    /**
     * @since    1.0.0
     */
    public static function activate() {
        
    }

}
