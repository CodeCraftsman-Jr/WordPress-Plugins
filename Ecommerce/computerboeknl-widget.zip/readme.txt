=== Computerboek affiliates widget ===
Contributors: Dennis Lutz, Computerboek.nl
Link: http://www.Computerboek.nl/
Tags: affiliate,boek,boeken,book,books,computerboek,computerboeken,computerbook,computerbooks,partnerprogram,sidebar,widget
Requires at least: 2.3
Tested up to: 3.1.2
Stable tag: 1.0.3

Add a Computerboek.nl widget to your wordpress-site

== Description ==
This plugin adds a customizable widget, which gets computerbooks using the Computerboek.nl xmlfeed.
You can add your own Computerboek.nl affiliate-id and get revenue from this plugin. 

== Installation ==

1. Extract zip in the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

Steps to take after plugin is installed:

- Add the widget to your sidebar.
- Fill out the form.
- Now save changes and you're all done!

== Screenshots ==
1. /tags/1.0.1/screenshot-1.png
2. /tags/1.0.1/screenshot-2.png
3. /tags/1.0.1/screenshot-3.png

== Frequently Asked Questions ==
- Can I use the widget to show a selection of computerbooks?
- Yes, add the ISBN(13)-codes into the "zoek" inputfield, separated by a pipe e.g. 9789055946471|9789077387818

== Changelog ==
= Version 1.0.3 =
changed connection-options
= Version 1.0.0 =
initial version

== Upgrade Notice ==
-