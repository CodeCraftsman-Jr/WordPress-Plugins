=== FFDirect ===
Contributors: Panayotis Vryonis
Donate link: http://vrypan.net/log/ffdirect/
Tags: friendfeed
Requires at least: 2.7.0
Tested up to: 2.8
Stable tag: 0.7.1

FFDirect will submit your posts to your friendfeed.com account the moment they are published.

== Description ==


FFDirect will submit your posts to your friendfeed.com account the moment they are published.
Some reasons to prefer FFDirect instead of using your feed:

* Images included in your posts will also be submited and visible in the corresponding friendfeed entry.
* The same applies to any link to audio (.mp3, .wav, .aac) files.
* Your posts will appear in friendfeed the moment you publish them.
* Google Analytics-friendly URL tagging.
* Pulls number of friendfeed "likes" and comments under your posts.

== Installation ==

1. unzip ff_direct.zip and upload the folder ff_direct in the `/wp-content/plugins/` directory.
2. Enable the plugin.
3. Make sure you go to settings->FFDirect and set your friendfeed nickname and remote key.
4. Once you make sure everything works as expected, it would be better to remove your feed from friendfeed or you will end up with duplicate entries.

