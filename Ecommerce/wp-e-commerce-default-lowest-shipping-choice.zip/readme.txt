=== WP e-Commerce Default Lowest Shipping Choice ===
Contributors: leewillis77
Donate link: http://plugins.leewillis.co.uk/donate/?utm_source=wordpress&utm_medium=www&utm_campaign=wpec-default-shipping
Tags: WP e-Commerce, shipping, default
Requires at least: 3.7
Tested up to: 4.3
Stable tag: 1.2

== Description ==
A straightforward plugin that makes WP e-Commerce checkout default to the lowest available rate when first populating
shipping choices.

The plugin's available for forking and contribution over on [GitHub](https://github.com/leewillis77/WP-e-Commerce-Default-Lowest-Shipping-Choice)

== Installation ==

* Install it as you would any other plugin
* Activate it
* You're done

== Changelog ==

= 1.2 =
Initial release