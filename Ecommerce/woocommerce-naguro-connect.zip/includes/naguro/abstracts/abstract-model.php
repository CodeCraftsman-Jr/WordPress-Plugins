<?php

abstract class Naguro_Model {

}