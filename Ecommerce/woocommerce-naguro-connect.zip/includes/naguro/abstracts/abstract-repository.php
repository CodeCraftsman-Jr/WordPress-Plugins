<?php

abstract class Naguro_Repository {

}