<?php

interface Naguro_Request_Interface {
	public function output();
}