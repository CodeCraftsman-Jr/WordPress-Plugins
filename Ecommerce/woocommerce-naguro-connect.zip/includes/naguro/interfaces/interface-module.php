<?php

interface Naguro_Module {
	public function load();
}