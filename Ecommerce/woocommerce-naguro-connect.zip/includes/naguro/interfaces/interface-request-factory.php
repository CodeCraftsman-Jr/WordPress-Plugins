<?php

interface Naguro_Request_Factory {
	public function get_request_by_method( $method );
}