<?php

class Naguro_Core_Module extends Naguro_Module_Model {
	public function load() {
	}
}