<?php

class Naguro_Shirt_Module extends Naguro_Module_Model {
	public function load() {
	}
}