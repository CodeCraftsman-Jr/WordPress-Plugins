<?php

class WC_Naguro_Checkout {

}