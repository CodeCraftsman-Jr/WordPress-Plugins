=== WooCommerce - Search By SKU ===
Contributors: codenterprise
Donate link: http://www.codenterprise.com/
Tags: search, sku, stock keeping unit, WooCommerce, ecommerce, e-commerce, commerce, woothemes, wordpress ecommerce, search by sku
Requires at least: 3.0.1
Tested up to: 3.9.1
Stable tag: 1.2
License: GPL2

Extend the search functionality of WooCommerce to include searching of sku 

== Description ==

The search functionality in WooCommerce doesn't search by sku by default.  
This simple plugin adds this functionality to both the admin site and regular search.  
Tested with WooCommerce 1.5.6, 2.0.7,2.0.18, 2.1.12

For more info http://www.codenterprise.com/corporate-profile/wordpress-plugins/
Other WooCommerce Plugins at http://www.codenterprise.com/our-services/woocommerce-web-development/
Send your problems to info@codenterprise.com. Dont forget to mention WP and WooCommerce versions.

== Installation ==

1. Upload `WooCommerce-search-by-sku.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Features ==
Extend the search functionality of WooCommerce to include searching of sku in both sections(WooCommerce product/front-end search)

== Screenshots ==
1. This is how plugin looks at back-end

== Changelog ==
= 1.2 = 
* Fixed error in SKU.

= 1.1 = 
* Added WP error reporting

= 1.0 = 
* First version

== Frequently Asked Questions ==
no question