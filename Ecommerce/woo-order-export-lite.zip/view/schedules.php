<?php
if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<div class="tabs-content">We are sorry. We are still working over this part</div>