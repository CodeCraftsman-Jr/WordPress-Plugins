=== WooCommerce Dynamic Handling ===
Contributors: Webskitters Technology Solution Pvt. Ltd wordpress team 
Tags: woocommerce, handling, dynamic handling
Requires at least: 4.2.2
Tested up to: 4.2.2
Stable tag: 3.1.2
License: GPLv2 or later

WooCommerce Dynamic Handling allow you to add handling fee for every product.

== Description ==

WooCommerce Dynamic Handling allow you add handling fee for each product. That handling charge will be added on cart total.

Major features in WooCommerce Dynamic Handling include:

* Add handling fee for each product.
* Add handling fee to cart total .
* Per Item - charge handling fee for each item individually.
* Per Order - charge handling fee for the entire order as whole.
* Per Max Item - Charge handling fee for the entire order as whole(ony Max handling charge) 


== Installation ==

Upload the WooCommerce Dynamic Handling plugin to your wordpress, Activate it.

1, 2, 3: You're done!

== Changelog ==

= 1.0.1 =
* Change generic function name.

== Screenshots ==

1. WooCommerce settings panel.
2. WooCommerce product data panel.
3. Cart page


