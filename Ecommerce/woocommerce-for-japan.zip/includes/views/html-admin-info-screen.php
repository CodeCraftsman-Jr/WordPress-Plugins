<h3><?php echo __( 'Infomation of Japanese Support', 'woocommerce-4jp' );?></h3>
<p><b>Sorry, Japanese Only</b></p>
<div>
こちらでは、WooCommerce For Japanのサポート情報や告知等を定期的に行なわせて頂きます。<br />
<br /><br />
<h3>関連プラグイン情報</h3>
<ul>
<li><a href="https://wordpress.org/plugins/woocommerce-for-paygent-payment-main/" target="_blank">ペイジェント向けクレジット決済プラグイン（WordPress公式プラグイン）</a></li>
<li><a href="https://wordpress.org/plugins/woocommerce-for-gmo-epsilon-credit-card/" target="_blank">GMO イプシロン向けクレジット決済プラグイン（WordPress公式プラグイン）</a></li>
</ul>
その他、現在誠意製作中。
<br /><br />
<h3>セミナー情報</h3>
<p>
Facebookページで順次ご案内中。<br />
<a href="https://www.facebook.com/wcjapan" target="_blank">Woocommerce Japan Facebookページ</a>
</p>
</div>
