<?php
/*
Plugin Name: CoinPay Thai Payment Gateway
Plugin URI: https://coinpay.in.th/
Description: Woocommerce payment module for use with https://coinpay.in.th merchant accounts
Author: David Barnes
Version: 2.1.5
Author URI: https://coinpay.in.th/
*/

// Only Woocommerce right now
include('bitcointhai_woocommerce.php');

?>