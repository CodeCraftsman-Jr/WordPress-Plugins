=== Woocommerce Product Wise Orders Report ===
Contributors: madforstrength
Donate link: N/A
Tags: woocommerce, orders report, product wise orders
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin adds a functionality in woocommerce to see orders specific to a particular product.

== Description ==

This plugin adds a functionality in woocommerce to see orders specific to a particular product. This is very helpful when you want to see how your products are doing.

== Installation ==

1. Upload `woocommerce-product-wise-orders-report` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
N/A

== Screenshots ==
N/A

== Changelog ==
N/A

== Upgrade Notice ==
N/A