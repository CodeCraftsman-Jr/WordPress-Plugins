<?php
//akw-store-locator config file

//Google API key
//Change this to true to use Google maps API key V3
define('USE_GOOGLE_KEY', false);
//Enter the Google Maps API V3 key
define('GOOGLE_API_KEY', 'Enter key here');
?>