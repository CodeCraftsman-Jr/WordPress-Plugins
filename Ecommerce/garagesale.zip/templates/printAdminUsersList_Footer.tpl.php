<div class="wrap">
	<!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
	<form id="garagesale-filter" method="get">
		<!-- For plugins, we also need to ensure that the form posts back to our current page -->
		<input type="hidden" name="page" value="<?php echo htmlspecialchars($_REQUEST['page']); ?>" />
		<!-- Now we can render the completed list table -->
		<?php $gsListTable->display() ?>
	</form>
</div>
