=== Marksale ===
Contributors: weiseundstark
Tags: marksale, tracking,
Requires at least: 3.4
Tested up to: 4.3
Stable tag: 4.3

If you are using Marksale ( <https://marksale.de> ) to track your page this plugin will enable your tracking without any further work.
== Description ==

If you are using Marksale ( <https://marksale.de> ) to track your page this plugin will enable your tracking without any further work.

== Installation ==


1. Upload `marksale` to the `/wp-content/plugins/`  directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enter your Marksale TrackingID under Settings -> Marksale
4. Enjoy =)

== Frequently Asked Questions ==

== Screenshots ==
N/A

== Changelog ==

 = 1.0.0 =
* Initial Version

