=== Plugin Name ===
Contributors: n.uchiumi
Tags: moshimo
Requires at least: 3.5.1
Tested up to: 3.5.1
Stable tag: 1.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plug-in is intended to use "moshimo" of the Japanese drop shipping service company.

== Description ==

This plug-in is intended to use "moshimo" of the Japanese drop shipping service company.
A product is registered automatically in your wordpress when I choose a category in plug-in. In addition, plug-in automatically updates it to a new product regularly. Many people say, "the drop shipping wants to do it, but it is difficult". I produced plug-in to meet the demand. I sell template and expansion widget in our site.If you purchase a product, I will give cooperation to future development.

Attention

1.Registration of "moshimo" is necessary to use this plug-in.
2.This plug-in downloads product data from "moshimo API".moshimo's Certification cord is necessary on this occasion.
3.This plug-in displays news and an advertisement on initial setting and a theme (page).
4.When specifications of "moshimo API" are changed, plug-in may not work normally.

== Installation ==

1. Upload `quickmaker`folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Choose the theme of 'MoshimoQuickMakerTemplate01'.
4. Input initial setting of 'QuickMaker' menu.
5. Choose the suitable category of the "QuickMaker" menu.

(http://www.a-ings.net/user_data/quickmaker.php "Documentation in Japanese")

== Frequently Asked Questions ==

Is not yet.

== Screenshots ==

1.Initial setting of 'QuickMaker'.
2.Category setting of the "QuickMaker".
3.Pages that have been published.

== Changelog ==

= 1.0.7 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

Is not yet.

== Arbitrary section ==


== A brief Markdown Example ==

