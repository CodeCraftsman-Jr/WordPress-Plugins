=== Simple Inventory ===
Contributors: theode
Tags: inventory,goods,management,simple,storage
Requires at least: 3.0
Tested up to: 4.2
Stable: 0.11
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html

You can put in Products you have in your storage. As post type you could easily write theme templates for it.

== Description ==

BE AWARE THAT IS THE VERY FIRST DEVELOPMENT VERSION AND MIGHT BE NOT FITTING YOUR NEEDS RIGHT NOW .

This plugin defines a custom post type which is used for storage management.

You easily could put in products and goods and build templates for it on the front-end

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory of your site

OR

2. Upload the zip file through the `New Plugin` upload functionality

OR

3. Download through the plugin install functionality of WordPress.

4. Activate through the `Plugins` menu in WordPress

== Frequently Asked Questions ==

please send all support inquiries over Twitter to @wpplugindevcom .



== Changelog ==

= 0.1 =
Public release

== Upgrade notice ==
Hey, this is the intial release, install it, it is fun.
