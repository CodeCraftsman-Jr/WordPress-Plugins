jQuery( document ).ready(function( $ ) {
	$("iframe[src*='?bookingSource=widget']").parent().css({"width":"auto","max-width":"621px"});
});