=== WooCommerce - Amazon UK ===
Contributors: AgileSolutionsPK
Donate link: http://agilesolutionspk.com/donate/
Tags: WooCommerce, Payment Gateway
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

It is a WooCommerce payment gateway extension for Amazon Payments UK. Works with Amazon Checkout standard. Developed as Wordpress plugin.

== Description ==

It is a WooCommerce payment gateway extension for Amazon Payments UK. Works with Amazon Checkout standard. Here is the Amazon payments link comparing different integration option. What we have developed is "Standard" option given here. https://payments.amazon.co.uk/business/resources. Developed as Wordpress plugin.

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

Note: You must have WooCommerce Installed to make this plugin work.

== Frequently asked questions ==

Q. What are the dependencies for this plugin.

A. WooCommerce must be installed.

Q.Where i can get more information about this Amazon Payments integration done by this plugin.

A. https://payments.amazon.co.uk/business/resources  Standard check integration has been done.

