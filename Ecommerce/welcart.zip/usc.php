<?php
/*
Plugin Name: Failure
Plugin URI: 
Description: Sorry, I made a mistake.
Version: 0.1.2
Author: nobody
Author URI: 
*/
?>
