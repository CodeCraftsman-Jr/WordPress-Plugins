=== Plugin Name ===
Contributors: nobody
Tags: widgets
Requires at least: 2.8
Tested up to: 2.8.4
Stable tag: 0.1.2

Failure
mistake

== Description ==

Sorry, I made a mistake.
