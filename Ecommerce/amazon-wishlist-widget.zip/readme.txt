=== Amazon Wishlist Widget ===
Contributors: yakiniku48
Tags: amazon, widget, sidebar
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 0.2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This widget plug-in will display your amazon wishlist in your sidebar.

You can set some options:

* Title
* Wishlist ID
* Associate ID
* Market Place

== Installation ==

1. Extract the contents of the zip file into your '/wp-content/plugins/' directory.
1. Activate the plugin.
1. Go to 'Appearance' -> 'Widgets' and add 'Amazon Wishlist Widget' to one of areas.
1. Set some options of the widget (Wishlist ID, Market Place and more).

== Screenshots ==

1. screenshot-1.png

== Changelog ==

= 0.2.1 =
* Bugs fixed.

= 0.1 =
* First release.
