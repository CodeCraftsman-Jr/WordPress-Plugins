<?php
require_once(READY_SHIPPINGCALC_DIR.'mod.php');

class auctioninc_shipcalc_fixed_fee extends auctioninc_shipcalc {
    
	public function init() {
		parent::init();
	}

}