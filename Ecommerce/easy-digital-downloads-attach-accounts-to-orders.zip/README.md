# Easy Digital Downloads Attach Accounts To Orders #

Current Version: 2.0.1

Yet another awesome plugin by [Chris Christoff](http://www.chriscct7.com)

### Description ###

Attach users to orders! Take guest purchases and attach them to existing accounts automatically. Optionally create accounts for users that don't have one automatically.


### Changelog ###
= 2.0.1 =
* Tags release to force updates to 2.0

= 2.0 =
* New UI
* Starts prep work for using the new Customer API in EDD
* New custom user created email function so admins no longer get an email for each account created!

= 1.0 =
* Initial Release