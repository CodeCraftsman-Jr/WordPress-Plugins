License: Dual Licensed

You may choose to use this plugin under either of the following 2 licenses:

Option 1: GPLv2 or later

License URI: [http://www.gnu.org/licenses/gpl-2.0.html](http://www.gnu.org/licenses/gpl-2.0.html)

Option 2: WTFPL (any version)

License URI: [http://www.wtfpl.net/about/](http://www.wtfpl.net/about/)