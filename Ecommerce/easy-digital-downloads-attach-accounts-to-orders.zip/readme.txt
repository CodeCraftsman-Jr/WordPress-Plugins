=== Easy Digital Downloads Attach Accounts to Orders ===
Contributors: chriscct7
Requires at least: 3.9
Tested up to: 4.3
Contributors: chriscct7
Donate link: http://donate.chriscct7.com/
Tags: easy digital downloads, edd, edd accounts, edd orders
Requires at least: 3.9
Stable tag: 2.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Attach users to orders! Take guest purchases and attach them to existing accounts automatically. Optionally create accounts for users that don't have one automatically.

== Installation ==

1. Unzip the archive on your computer
2. Upload `easy-digital-downloads-attach-accounts-to-orders` directory to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

None Yet

== Support And Contributing ==

All support for chriscct7 plugins are done via the forum on wordpress.org.

If you'd like to help, feel free to contribute at the [GitHub Repo](https://github.com/chriscct7/easy-digital-downloads-qr-code) for this plugin.

== Frequently Asked Questions ==

Haven't had any yet

== Changelog ==
= 2.0.2 =
* FIX: XSS vulnerability in query args

= 2.0.1 =
* Tags release to force updates to 2.0

= 2.0 =
* New UI
* Starts prep work for using the new Customer API in EDD
* New custom user created email function so admins no longer get an email for each account created!

= 1.0 =
* Initial Release

== Upgrade Notice ==
= 2.0.1 =
* Tags release to force updates to 2.0

= 2.0 =
* New UI
* Starts prep work for using the new Customer API in EDD
* New custom user created email function so admins no longer get an email for each account created!

= 1.0 =
* Initial Release
