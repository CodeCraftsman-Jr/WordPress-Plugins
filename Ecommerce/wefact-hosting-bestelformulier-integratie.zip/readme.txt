=== Plugin Name ===
Contributors: WeFact
Tags: iframe wrapper, wefact
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Eenvoudige manier om het bestelformulier van WeFact Hosting in de Wordpress website te integreren. 

== Description ==

Zie https://www.wefact.nl/wefact-hosting/help/artikel/87/bestelformulier-integreren-in-een-wordpress-website/ voor meer informatie.

== Installation ==

1. Upload de bestanden naar de `/wp-content/plugins/` map
2. Activeer de plugin vanuit de 'Plugins' sectie in WordPress
3. Gebruik [bestelformulier url=https://www.uwdomein.nl/bestellen/?cart=1] in de betreffende Wordpress pagina


== Changelog ==

= 1.2 =
* Ondersteuning voor meegeven GET-parameters

= 1.1 =
* Bugfix voor classname iframe

= 1.0 =
* Eerste versie WeFact Hosting Bestelformulier plugin
* De hoogte zal zich automatisch aanpassen, indien de instructies van ons helpartikel zijn opgevolgd.