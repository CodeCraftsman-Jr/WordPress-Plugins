<?php

require_once 'EzOffice.php';

class EzOfficePro extends EzOffice {

}
