<?php

require_once 'EZCom.php';

class EZPro extends EZCom {

  static function sendMailEx() {
    return false;
  }

}
