var xparams = {};
var wideCB = true;
var xeditOpenNext = true;
var xeditInline = true;

function getProduct() {
  return "ezpaypal";
}
