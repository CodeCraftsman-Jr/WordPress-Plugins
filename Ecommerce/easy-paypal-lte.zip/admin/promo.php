<div class="clearfix">&nbsp;</div>
<div class="col-md-3 col-sm-6 goPro">
  <a data-toggle="tooltip" title="Get the Pro version for only $19.95. Tons of extra features. Instant download." class="well top-block goPro" href="http://buy.thulasidas.com/ezpaypal">
    <i class="glyphicon glyphicon-shopping-cart red"></i>
    <div>Get EZ PayPal Pro</div>
    <div>$19.95. Instant Download</div>
  </a>
</div>
<div class="col-md-3 col-sm-6">
  <a data-toggle="tooltip" title="See other premium WordPress plugins and PHP programs by the same author." class="well top-block popup-long" href="http://www.thulasidas.com/render" target="_blank">
    <i class="glyphicon glyphicon-star green"></i>
    <div>Other Plugins and Programs</div>
    <div>From the author</div>
  </a>
</div>
<div class="col-md-3 col-sm-6">
  <a data-toggle="tooltip" title="Check out the author credentials in the form of a CV." class="well top-block popup-long" href="http://www.thulasidas.com/col/Manoj-CV.pdf" target="_blank">
    <i class="glyphicon glyphicon-user blue"></i>
    <div>Author Profile</div>
    <div>CV from Author's blog</div>
  </a>
</div>
<div class="col-md-3 col-sm-6">
  <a data-toggle="tooltip" title="If you need customized PHP development for your site, or have some other questions, contact the author." class="well top-block popup-long" href="http://www.thulasidas.com/professional-php-services/" target="_blank">
    <i class="glyphicon glyphicon-envelope yellow"></i>
    <div>Contact</div>
    <div>Enquiries and Support</div>
  </a>
</div>
<div class="clearfix"></div>
