<?php

require_once('../../EZ.php');

EZ::update('categories');
