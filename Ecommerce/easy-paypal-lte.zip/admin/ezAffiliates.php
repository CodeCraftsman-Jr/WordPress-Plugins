<?php require 'header.php'; ?>
<div>
  <ul class="breadcrumb">
    <li>
      <a href="#">Home</a>
    </li>
    <li>
      <a href="#">Optional Module - EZ Affiliates</a>
    </li>
  </ul>
</div>

<?php
openBox("EZ Affiliates", "plus-sign", 12);
?>
<p>The <a href="#" class="goPro">Pro version</a> of EZ PayPal can be enhanced with optional modules. Note that these modules will not work with the lite version of the program.</p>
<p>EZ Affiliates is an affiliate marketing module for EZ PayPal. Using it in conjunction with EZ PayPal, you can turn your satisfied customers into your brand ambassadors, and get one step closer to that Internet dream of going viral. It can be purchased for $4.95. </p>
<p><a href='http://www.thulasidas.com/packages/ezaffiliates/' target='_blank'>Learn more about it</a>.</p>
<?php
closeBox();
require 'promo.php';
require 'footer.php';
