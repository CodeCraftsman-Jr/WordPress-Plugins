<?php require 'header.php'; ?>
<div>
  <ul class="breadcrumb">
    <li>
      <a href="#">Home</a>
    </li>
    <li>
      <a href="#">Optional Module - Easy Text Links</a>
    </li>
  </ul>
</div>

<?php
openBox("EZ Affiliates", "plus-sign", 12);
?>
<p>The <a href="#" class="goPro">Pro version</a> of EZ PayPal can be enhanced with optional modules. Note that these modules will not work with the lite version of the program.</p>
<p>Easy Text Links is a modern plugin to help you make extra revenue from your WordPress blog by selling text links. Text link advertising can be significantly more lucrative than contextual ads. This plugin automates the insertion and expiration of the links, and helps you with quick reminder emails to your advertisers. Easy Text Links can be purchased for $7.95. </p>
<p><a href='http://www.thulasidas.com/plugins/easy-text-links/' target='_blank'>Learn more about it</a>.</p>
<?php
closeBox();
require 'promo.php';
require 'footer.php';
