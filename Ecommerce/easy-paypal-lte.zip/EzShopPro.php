<?php

require_once 'EzShop.php';

class EzShopPro extends EzShop {

}
