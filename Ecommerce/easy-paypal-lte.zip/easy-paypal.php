<?php

/*
  Plugin Name: EZ PayPal
  Plugin URI: http://www.thulasidas.com/plugins/ezpaypal
  Description: Easiest way to start selling your digital goods online. Go to <a href="options-general.php?page=wp-ezpaypal.php">Settings &rarr; EZ PayPal Lite</a> to set it up, or use the "Settings" link on the right.
  Version: 7.02
  Author: Manoj Thulasidas
  Author URI: http://www.thulasidas.com
 */

/*
  Copyright (C) 2008 www.ads-ez.com

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once 'wp-ezpaypal.php';