        </div> <!--/content-->
      </div> <!--/row-->

      <footer class="row">
      </footer>

    </div><!--/ch-container-->

    <!-- external javascript -->

    <script src="admin/js/bootstrap.min.js"></script>
    <script src="admin/js/bootstrap-editable.min.js"></script>
    <script src="admin/js/jquery.dataTables.min.js"></script>
    <script src="admin/js/dataTables.bootstrap.js"></script>
    <script src="admin/js/bootbox.min.js"></script>
    <!-- application specific -->
    <script src="admin/js/ezpaypal.js"></script>
    <!-- application script for Charisma demo -->
    <script src="admin/js/charisma.js"></script>
  </body>
</html>
