=== WooSocio ===
Contributors: qsheeraz
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YNF4H9FJY4HU4
Tags: woo, social, facebook, posts, products, share, auto upload
Requires at least: 3.0.1
Tested up to: 3.8
Stable tag: 0.8.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will upload/post your Woo products to facebook automatically, when published.

== Description ==

This is a simple plugin for your woocommerce site to upload/post your products to social media (currently facebook only) 
automatically. It will do the magic when you publish new product through woocommerce. It will be shared to your facebook friends.

== Installation ==

To work properly, woocommerce should be installed before installing woosocio.

Here are few steps to follow:

1. Upload `woosocio` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Select settings/WooSocio Options page from wordpress menu and login.
4. That's it. You're ready to go!

== Frequently Asked Questions ==

= Can I add a custom message to my product for sharing? =

Yes. You can add a custom message before publishing product. Click on edit link in publish area of the post.

= What if I don't want to share a product? =

If you uncheck the box 'Post to facebook?' in publish area, it will not be shared.

= I am loggedin but products are not uploading =

Make sure you gave proper rights to you application. Disconnect from woosocio logins and connect again.

= Can I allow more than one facebook users to upload products? =

Well, yes! you have to add other users in your facebook application as developer or testers.

== Screenshots ==

1. screenshot-1.jpg

2. screenshot-2.jpg

3. screenshot-3.jpg

== Changelog ==

= 0.0.1 =

== Upgrade Notice ==

= 0.0.1 =

== Arbitrary section ==


== A brief Markdown Example ==

