<?php
/**
 * @package WP Simple Booking Calendar
 *
 * Copyright (c) 2011 WP Simple Booking Calendar
 */

/**
 * WP Simple Booking Calendar exceptions class
 */
class WpSimpleBookingCalendar_Exception extends Exception
{}