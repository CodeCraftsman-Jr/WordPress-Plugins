<?php 
// silence is gold