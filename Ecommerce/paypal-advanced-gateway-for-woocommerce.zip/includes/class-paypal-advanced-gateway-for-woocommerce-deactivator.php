<?php

/**
 * @class       PayPal_Advanced_Gateway_For_WooCommerce_Deactivator
 * @version	1.0.0
 * @package	paypal_advanced_gateway_for_woocommerce
 * @category	Class
 * @author      johnny manziel <phpwebcreators@gmail.com>
 */

class PayPal_Advanced_Gateway_For_WooCommerce_Deactivator {

    /**
     * @since    1.0.0
     */
    public static function deactivate() {
        
    }

}
