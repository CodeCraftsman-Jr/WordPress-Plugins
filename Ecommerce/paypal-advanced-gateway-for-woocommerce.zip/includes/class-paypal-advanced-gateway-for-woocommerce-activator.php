<?php

/**
 * @class       PayPal_Advanced_Gateway_For_WooCommerce_Activator
 * @version	1.0.0
 * @package	paypal_advanced_gateway_for_woocommerce
 * @category	Class
 * @author      johnny manziel <phpwebcreators@gmail.com>
 */

class PayPal_Advanced_Gateway_For_WooCommerce_Activator {

    /**
     *
     * @since    1.0.0
     */
    public static function activate() {
        
    }

}
