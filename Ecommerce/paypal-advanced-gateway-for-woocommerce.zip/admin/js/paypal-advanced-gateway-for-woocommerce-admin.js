jQuery(document).ready(function($){
    $('.paypal-advanced-gateway-for-woocommerce_color_field').wpColorPicker();
});