=== TheCartPress Sales Limits ===
Contributors: thecartpress
Tags: CartPress, ecommerce, e-commerce, store, shop, shopping, shopping cart, cart, custom post type, taxonomy, taxonomies, ecomerce, products, TheCartPress, html5, limits
Requires at least: 3.1
Tested up to: 4.2.2
Stable Tag: 1.9.1

Adds price and weight limits to TheCartPress, the eCommerce plugin for WordPress

== Description ==

Adds price and weight limits to TheCartPress, the eCommerce plugin for WordPress

= More info and Community =

* [TheCartPress Extend](http://extend.thecartpress.com): plugins, themes and custom development
* [TheCartPress Demo](http://demo.thecartpress.com)
* [TheCartPress Community/Support](http://community.thecartpress.com/activity/)
* [TheCartPress Site](http://thecartpress.com)


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload TheCartpress Sales Limits to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Requirements =

Up to WodPress 3.1

= What is the plugin license? =

This plugin is released under a GPL license.

== Screenshots ==
1. Sales Limits admin page
1. Checkot stopped by the sales limits plugin

== Changelog ==
= 1.9.1 =
* Improvment messages...

= 1.9 =
* Adding fee messages to shopping cart (using notices)

= 1.8 =
* TCP 1.3.3+ support

= 1.7 =
* TCP 1.3.3+ support

= 1.6 =
* Language support

= 1.5 =
* Supporting for other plugins

= 1.4 =
* Minor bugs

= 1.3 =
* Minor bugs

= 1.2 =
* Compatible with TheCartPress 1.2.6

= 1.0.5 =
* Widgets Summary and detailed shopping cart compatibility with min fees.

= 1.0.4 =
* Small Price and Weight fees

= 1.0.3 =
* Minor bugs

= 1.0.0 =
* First public version.
