=== WooCommerce Sticky Cart ===
Contributors: Rameez_Iqbal
Tags: woocommerce, woo commerce, cart, sticky cart, product, easy, ajax, products
Donate link: http://webcodingplace.com/contact-us/
Requires at least: 3.0
Tested up to: 4.2.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Sticky Cart button for WooCommerce Shop Page with AJAX based Cart Contents

== Description ==
Sticky Cart button for WooCommerce Shop Page with AJAX based Cart Contents

== Installation ==
1. Go to plugins in your dashboard and select \'add new\'
2. Search for \'WooCommerce Sticky Cart\' and install it
3. Go to Dashboard > WooCommerce Sticky Cart and set your desired settings
5. Now visit Shop

== Screenshots ==
1. admin settings