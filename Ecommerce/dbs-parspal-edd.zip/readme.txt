=== Plugin Name ===
Contributors: dbstheme
Donate link: http://dbstheme.com/
Tags: parspal, edd, iran, persian, tomans, rials
Tested up to: 3.9es/gpl-2.0.html
Requires at least: 3.1

This plugin allows you to add Parspal.com gateway to EDD plugin in a clean way!

== Description ==

As said before this plugin adds a clean ParsPal gate way to easy digital downloads.

I had checked some of the available versions but all of them had some problems even the official version. 

So I made a clean version with my personal php ParsPal class which is included in plugin and you can use it in your projects.

Some of the features:

*   It has both Rial and Toman currencies.
*   It is NOT a edition version! It's a made version!
*   It sends product names to parspal in the right way!
*   It uses payment database record ID for payments ID instead of a random number.
*   It Works :D

== Changelog ==

= 1.0 =
* Just getting started!


= 1.1 =
* Fix some errors.

= 1.2 =
* Remove IRI and IRT decimals.