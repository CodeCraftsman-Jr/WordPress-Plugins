<div id="rwe-gallery">

	<div class="rwe-top-box">

		<ul class="rwe-breadcrumb"><li>[gallery_name]</li></ul>

		<div id="view-wishlist">[view_wishlist][wishlist]</div>

		[search_form]

		<div style="clear:both;"></div>

	</div>

	[error]

	<ul class="rwe-size-[category_thumbnail_size]">[category_list]</ul>

</div>