<div id="rwe-gallery">

	<div class="rwe-top-box">

		<ul class="rwe-breadcrumb"><li><a href="[gallery_url]">[gallery_name]</a></li><li>[search_terms]</li></ul>

		<div id="view-wishlist">[view_wishlist][wishlist]</div>

		[search_form]

		<div style="clear:both;"></div>

	</div>

	[error]

	<ul class="rwe-size-[category_thumbnail_size]">[search_items]</ul>

</div>