<form id="wishlist" style="display: none;">
<div id="wishlist-contents"></div>
</form>