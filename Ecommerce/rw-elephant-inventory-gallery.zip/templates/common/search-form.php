<form id="rwe-search-form" action="[gallery_url]" method="post">
<input type="text" name="rwe-search" id="rwe-search" placeholder="Search [gallery_name]">
<input type="submit" id="rwe-search-submit" value="search"></form>