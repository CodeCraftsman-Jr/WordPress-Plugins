=== Plugin Name ===
Contributors: leewillis77
Donate link: http://www.leewillis.co.uk/wordpress-plugins/?utm_source=wordpress&utm_medium=www&utm_campaign=wpec-show-personalisation
Tags: e-commerce, wp e-commerce, wpec, personalisation, custom, fields
Requires at least: 3.2
Tested up to: 4.3
Stable tag: 1.1
License: GPLv3

== Description ==

A simple plugin that shows the personalisation information entered by users in the cart widget, and during checkout.

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
4. Eat cake

Note: If you're running on WP e-Commerce 3.8.7.5 or below, make the required changes to your theme file - see here for details:

* http://code.google.com/p/wp-e-commerce/source/detail?r=983
* http://code.google.com/p/wp-e-commerce/source/detail?r=818

== Frequently Asked Questions ==

= I've installed it, but nothing is showing up - what gives?? =

If you're running on WP e-Commerce 3.8.7.5 or below, make the required changes to your theme file - see here for details:

* http://code.google.com/p/wp-e-commerce/source/detail?r=983
* http://code.google.com/p/wp-e-commerce/source/detail?r=818

== Screenshots ==

1. Cart widget showing personalisation information
2. Cart widget showing multiple personalised products
3. Personalisation information shown during checkout

== Changelog ==

= 1.1 =
Compatability with recent WP e-Commerce updates. Patch courtesy of Alan Cox

= 1.0 =
Initial release
