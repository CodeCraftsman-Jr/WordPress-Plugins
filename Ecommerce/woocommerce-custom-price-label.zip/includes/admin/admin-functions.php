<?php

if ( ! function_exists( 'wccpl_get_pro_message' ) ) {
	function wccpl_get_pro_message() {
		return __( 'Get <a href="http://coder.fm/items/woocommerce-custom-price-label-plugin/">WooCommerce Custom Price Label Pro</a> plugin to change value.', 'woocommerce-custom-price-label' );
	}
}