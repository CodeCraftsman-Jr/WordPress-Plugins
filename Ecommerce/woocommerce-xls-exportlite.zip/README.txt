=== Woocommerce xls Export(Lite) ===
Contributors: vivacityinfotech.jaipur
Donate link: http://tinyurl.com/owxtkmt
Tags: Woocommerce, woocommerce excelsheet, Export, Product Export, Excel, Excel sheet, Spreadsheet, woocommerce Product XLS, woocommerce Product XLXS, woocommerce All Products XLS, woocommerce XLXS export, woocommerce Category export, woocommerce Category XLS export, woocommerce Category XLXS, Product XLS, Product XLXS, All Products XLS, XLXS export, Category export, Category XLS export, Category XLXS,  XLS Archive download, Archive
Requires at least: 3.5
Tested up to: 4.3
License: GPLv2 or later

== Description ==

This Woocommerce xls Export(Lite) plugin allow you to export all the products in xls format. Export xls will be in Excel2007.  
You can also export the product according the selected category in the plugin. Exported excel sheet will be stored on your server and later can be downloaded from there.
List all the exported archive in the plugin GUI along with the size, category, author and created date of the file. You can also set the archive name according to your data and time format and can set the author name, subject and description of the exported file. Just a single click to get all your products export in excel spreadsheet.


This Woocommerce xls Export(Lite) will allow you this following feature:

* You can download all your woocommerce product in the excel spreadsheet in a single click.
* You can download the woocommerce product on the category basic by selecting the category before export.
* You can view all the listed exported xls archive downloaded till now along with their creater name, size, category and creation date.
* You can download the exported xls files anytime you want and can deleted the old exported files too. 
* You can set the exported xls file name according to your data and time format by setting it in the settings page.
* You can also set the author's name; subject and the description of the exported excel spreadsheet.

Woocommerce xls Export(Pro) version will be coming soon with the following features:

* You will be able to export the products in excel sheet on the basic of selected products and tags too.
* You will be able to download all the orders on the basis of their status in a single click.
* You will be able to download all the information about the coupons in excel sheet.
* You will be able to import the excel sheet to get all the products, categories and tags in your site.
* You will be able to schedule the xls export to keep all your products as a backup and can download it any time.


= Rate Us / Feedback =

Please take the time to let us and others know about your experiences by leaving a review, so that we can improve the plugin for you and other users.

= Want More? =

If You Want more functionality or some modifications, just drop us a line what you want and We will try to add or modify the plugin functions.

If you like the plugin please [Donate here](http://tinyurl.com/owxtkmt). 

== Installation ==


1. Download the Woocommerce xls Export(Lite).
2. Extract it in the '/wp-content/plugins/' directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Customize the plugin in the WooCommerce > XLS Export menu.

Please make note that this plugin will only work if your woocommerce plugin is actived.


Visit our <a href="http://vivacityinfotech.net/">demo page</a> for more information.


== Screenshots ==

1. Woocommerce xls Export(Lite) installed and appears in the WooCommerce option.
2. You can select the categories to export their respective products.
3. List of exported xls archives and can view the information, download the file or can deleted them too.
4. Set the name of the archive in data and time format, and can set other information too for the exported file.


Visit our <a href="http://vivacityinfotech.net/">demo page</a> for more information.

== Changelog ==

= 1.0 =
* Initial Release.
* Compatible with Wordpress 4.3.
