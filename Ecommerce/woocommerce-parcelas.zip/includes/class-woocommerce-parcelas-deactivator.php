<?php 
/**
 * Fired during plugin deactivation
 * This class defines all code necessary to run during the plugin's deactivation
 *
 * @since 	1.2.5
 * @author 	Filipe Seabra <eu@filipecsweb.com.br>
 */

class Woocommerce_Parcelas_Deactivator{
	public static function deactivate(){
		
	}
}

?>