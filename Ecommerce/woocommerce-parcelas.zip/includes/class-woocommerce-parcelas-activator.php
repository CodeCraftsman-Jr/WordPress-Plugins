<?php 
/**
 * Fired during plugin activation
 * This class defines all code necessary to run during the plugin's activation
 *
 * @since 	1.2.5
 * @author 	Filipe Seabra <eu@filipecsweb.com.br>
 */

class Woocommerce_Parcelas_Activator{
	public static function activate(){
		
	}
}

?>