jQuery(document).ready(function(){
	/*jQuery('.settings_page_fswp .section form h3:first-of-type').addClass('fs_active');

	jQuery('.settings_page_fswp .section form h3').click(function(){
		jQuery('.settings_page_fswp .section form h3').removeClass('fs_active');
		jQuery(this).addClass('fs_active');
	});*/  

		
});