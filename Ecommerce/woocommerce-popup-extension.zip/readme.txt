=== Woocommerce Product Pop Up ===
Contributors: (iwcontribution)
Tags: Product Pop Up, Woocommerce Pop Up, Woocommerce Extension
Requires at least: 3.5.2
Tested up to: 4.2.2
WooCommerce Pop-Up allows to show product on pop-up at "Shop" page.

== Description ==
This is Woocommerce Pop-Up extension which helps to show product on a pop-up with two buttons-"Continue Shopping" and "Checkout" at "Shop" page while clicking on "Add to cart" button. "Continue Shopping" button will get you back on shop page and "Checkout" button will redirect you on "Checkout" page.

== Installation ==
1. To run this extension make sure that you have installed woocommerce plugin and activate it.
2. Download the Quick View plugin zip file and extract to the  `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress Admin.

== Screenshots ==
1. This is Front-End Shop page Page. By Clicking on "Add to cart" button you can see the product on Pop-Up.

= 1.0 =
The First Release

