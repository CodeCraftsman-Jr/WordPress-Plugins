<?php
//Just returns the menus