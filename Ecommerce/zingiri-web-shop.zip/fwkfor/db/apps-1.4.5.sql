ALTER TABLE `##faces` AUTO_INCREMENT = 10000;
UPDATE `##faces` SET `ID` = '1021' WHERE `ID`=21 AND `NAME`='form_settings';