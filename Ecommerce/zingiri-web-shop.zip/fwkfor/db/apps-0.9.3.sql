-- Revamped apps access control
update `##faccess` set allowed=1;
