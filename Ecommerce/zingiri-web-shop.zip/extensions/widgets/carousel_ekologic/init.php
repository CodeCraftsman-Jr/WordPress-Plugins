<?php
echo '<script type="text/javascript" src="' . ZING_URL.'extensions/widgets/carousel_ekologic/js/jcarousel.js"></script>';
echo '<link rel="stylesheet" type="text/css" href="'.ZING_URL.'/extensions/widgets/carousel_ekologic/glide.css"media="screen" />';
?>