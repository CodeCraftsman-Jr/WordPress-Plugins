<?php
require(dirname(__FILE__)."/dashboard/index.php");
?>