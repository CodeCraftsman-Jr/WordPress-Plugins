<?php
$gSettings[]= 'MERCHANTID';

// Use TEST/LIVE mode; true=TEST, false=LIVE
$gSettings[]=$aSettings['TEST_MODE'] = 'TESTMODE';

// Basic gateway settings
$aSettings['GATEWAY_NAME'] = 'Worldpay';
$aSettings['GATEWAY_VALIDATION'] = false;
