<?php
$gSettings[]=$aSettings['MERCHANTID'] = 'MERCHANTID';
$gSettings[]=$aSettings['SECRET'] = 'SECRET';

// Use TEST/LIVE mode; true=TEST, false=LIVE
$gSettings[]=$aSettings['TEST_MODE'] = 'TESTMODE';

// Basic gateway settings
$aSettings['GATEWAY_NAME'] = 'Ideal Lite';
$aSettings['GATEWAY_VALIDATION'] = false;
