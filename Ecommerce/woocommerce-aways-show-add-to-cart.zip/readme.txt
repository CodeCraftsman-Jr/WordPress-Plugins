=== WooCommerce Aways Show Add to Cart ===
Contributors: fernandoyada
Tags: add to cart, woocommerce
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.impermad.com.br/

Always display add to cart button.

== Description ==
This simple plugin change div html of single product page to always display add to cart button, even if customer didn't choose some variation option.

== Installation ==
Download and extract woocommerce-always-show-add-to-cart.zip to wp-content/plugins/
Activate the plugin through the 'Plugins' menu in WordPress.


== Changelog ==
= 1.0 =
* Initial release.

