=== Meine CO2 Kampagne ===
Contributors: co2kampagne
Donate link: www.co2kampagne.de
Tags: co2kampagne,widget,HTML,unternehmenzummitmachen, sidebar, post, page, co2, carbon, co2 kampagne
Requires at least: 2.3
Tested up to: 2.6.2
Stable tag: 1.0

"Meine CO2 Kampagne" widget can display the counter of your co2 campaign.

== Description ==
"Meine CO2 Kampagne" widget can display the counter of your co2 campaign.
== Installation ==

1. Download and unzip my-co2-campaign.zip
1. Upload the folder containing `meine-co2-kampagne.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. To add a Counter on a sidebar, browse to Design > Widgets and add the 'Meine CO2 Kampagne" to desired sidebar. Configure the Counter Title and Shop-URL-"Particle" and save your changes.
1. To add your Counter to any post or page just add the markup `[co2kampagne]url[/co2kampagne]`, for instance `[co2kampagne]maxmusterman[/co2kampagne]`.

== Frequently Asked Questions ==

= How do I add a counter to a blog-post =

To add a counter to any post or page just add the markup `[co2kampagne]Shop-Sub-URL[/co2kampagne]`, for instance `[co2kampagne]musterman[/co2kampagne]`. Note that supplying the Shop-URL is mandatory. 

== Screenshots ==
1. Configure your Widget-Counter. 
2. This is how the widget looks like in post after configuration. 

== Changelog ==