=== Educator WooCommerce Integration ===
Contributors: dmytro.d
Donate link: http://educatorplugin.com
Tags: learning management system, lms, learning, online courses
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Connects Educator with WooCommerce.

== Description ==

Makes it possible to sell the <a href="https://wordpress.org/plugins/ibeducator/">Educator plugin's</a> courses using WooCommerce.

== Installation ==

1. Upload `educator-woocommerce` plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =

* Initial release.
