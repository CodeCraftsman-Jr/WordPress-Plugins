=== TR Woocommerce Product Slider ===
Contributors: BestThemeRoad
Author URI: https://profiles.wordpress.org/bestthemeroad
Author: Theme Road
Donate link: 
Tags:  carousel, horizontal posts slider, horizontal product carousel, most selling products, multiple product slider, on sale product carousel, on-sale, posts content slider, posts slider, product, product carousel, product content slider, product contents carousel, product rotator, product slider, products slider, related product carousel, related product slider, responsive product slider, top rated products, up sells, vertical product carousel, woo slider, woocommerce, woocommerce product carousel, woocommerce product slider, WooCommerce Products, woocommerce products slider, woocommerce slider
Requires at least: 3.5
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display Your Clients Feedback or Testimonials in pages,posts,custom-posts,widgets etc.


== Description ==

### TR Woocommerce Product Slider by http://themeroad.net

TR Woocommerce Product Slider is one of the best custom plugin to publish your Latest Product & Features Product

Plugin Features

* Shortcode System.
* Just use this shortcode [tr-latest] where you want show Latest Product.
* Just use this shortcode [tr-feature] where you want show Features Product.

### Installation guide:
[youtube https://www.youtube.com/watch?v=MbTkcr94z5s]

 


* [Our Premium Plugins](http://themeroad.net/154-2/)
 * [TR WP Custom Login](http://themeroad.net/Products/wp-custom-login-page/)
 * [TR Advanced Price Plan Pro](http://themeroad.net/Products/tr-price-plan-pro/)
 * [TR WooCommerce Image Zoom PRO](http://themeroad.net/Products/tr-woocommerce-image-zoom-pro/)
 * [TR Carousel Slider Pro](http://themeroad.net/Products/tr-carousel-slider-pro-4/)
 * [TR Logo Slider Pro](http://themeroad.net/Products/tr-logo-slider-pro/)
 * [TR Filterable Portfolio Pro](http://themeroad.net/Products/204/)
 * [TR Nice Accordion Pro](http://themeroad.net/Products/tr-premium-accordion-pro/)



== Installation ==

Via WordPress -
1. Install as a regular WordPress plugin.
2. Now go to Testimonial Menu to create New testimonial.After create that your testimonial to ready for use.
3.Then go to Your desire post/page/custom post or Text widget and past the short code  [tmrd-testimonial] 
3. you could use for .php file any where `<?php echo do_shortcode('[tmrd-testimonial]'); ?>`


Via FTP -

1. Upload .zip file to your WordPress plugin directory and unzip it.
2. Go your Plugins setting via WordPress Dashboard and activate it.
3. Then Publish some post on by go to'testimonial' and 'Add-new' post type with thumbnail.
4. and use this shortcode anywhere to display  [tmrd-testimonial] 
5. you could use for .php file any where `<?php echo do_shortcode('[tmrd-testimonial] '); ?>`



== Frequently asked questions == 


1. Is it a Responsive Plugin?
 Ans: Yes.
2. Have any options to contact for solve our problem?
 Ans: Ofcourse,why not. Just mail us BestThemeRoad@gmail.com or comments  to solve your problem.


== Screenshots ==

1. This is the view of the admin panel page
2. This is the view of the plugin when you add this in the any page or footer of the post
3. This is the view of the plugin when you add this in the widgets in your sites



== Changelog ==

= 1.0 =
* Initial release

