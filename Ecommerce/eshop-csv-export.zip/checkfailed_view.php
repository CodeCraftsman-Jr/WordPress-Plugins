<h2>Dependency Check Failed</h2>
<p>The eShop plugin must be installed and activated before using eShop CSV Export.  Please install the Eshop plugin, create a product, and then try again.</p>
<br/>
