=== Online Stores ===
Contributors: Blog Traffic Exchange (http://www.blogtrafficexchange.com)
Tags: admin, plugin, SEO, posts, links, administration, blog, traffic, visitors
Requires at least: 2.5
Tested up to: 3.2.1
Stable tag: 1.2.5

Online stores adds related online stores to the bottom of your blog posts.

== Description ==

Online stores adds related online stores to the bottom of your blog posts. Improving the user experience by offering them additional related content. It uses your blog as the seed to find the related online stores.

[Online Stores](http://www.blogtrafficexchange.com/online-stores "Online Stores") by [Blog Traffic Exchange](http://www.blogtrafficexchange.com/ "Blog Traffic Exchange")

Check out my other [Wordpress Plugins](http://www.blogtrafficexchange.com/wordpress-plugins "Wordpress Plugins")

== Installation ==

0. Requires php 5
1. Upload related-sites directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Optionally adjust the options and style to suit
4. Email kevin at blogtrafficexchange dot com requesting inclusion into the Blog Traffic Exchange.  The vetting of new blog can take up to 48 hours, please leave the plugin installed during this period.  Please include your blog url in the email.
5. Add the key when emailed into the options and save.

== Frequently Asked Questions ==

= What is the plugin page?  =

[Online Stores](http://www.blogtrafficexchange.com/online-stores "Online Stores") by [Blog Traffic Exchange](http://www.blogtrafficexchange.com/ "Blog Traffic Exchange")

= Do you have other plugins?  =

[Related Websites](http://www.blogtrafficexchange.com/related-websites "Related Websites")
[Related Tweets](http://www.blogtrafficexchange.com/related-tweets "Related Tweets")
[Blog Post Promoter](http://www.blogtrafficexchange.com/old-post-promoter "Blog Post Promoter")
[Wordpress Backup](http://www.blogtrafficexchange.com/wordpress-backup "Wordpress Backup")
[Blog Copyright](http://www.blogtrafficexchange.com/blogcopyright "Blog Copyright")
[Related Posts](http://www.blogtrafficexchange.com/related-posts "Related Posts")
[Online Stores](http://www.blogtrafficexchange.com/online-stores "Online Stores")
[Click to Call](http://www.blogtrafficexchange.com/click-to-call "Click to Call")

I am working on several others, when released you will find them on my [Wordpress Plugins](http://www.blogtrafficexchange.com/wordpress-plugins "Wordpress Plugins") page.
