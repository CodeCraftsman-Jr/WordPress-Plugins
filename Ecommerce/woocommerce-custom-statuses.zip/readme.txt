=== WooCommerce Custom Statuses ===
Contributors: garmantech, patrickgarman
Donate link: http://www.garmantech.com/wordpress-plugins/
Tags: woocommerce, woo, ecommerce, eshop, status, custom
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 1.0

This plugin allows you have custom order statuses in WooCommerce.

== Description ==

This plugin allows you have custom order statuses in WooCommerce.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

=1.0=

First release, yay!