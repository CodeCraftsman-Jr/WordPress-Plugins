<?php
class core_cartmanager_events_RemoveProductFromCart extends core_common_MessageBase  {
	/** @var String */
	public $productId;

}
?>