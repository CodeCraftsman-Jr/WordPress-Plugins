<?php
class core_cartmanager_events_AddProductToCart extends core_common_MessageBase  {
	/** @var String */
	public $productId;

}
?>