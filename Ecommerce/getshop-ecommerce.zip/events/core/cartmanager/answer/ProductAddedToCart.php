<?php
class core_cartmanager_answer_ProductAddedToCart extends core_common_AnswerMessage  {
	/** @var String */
	public $productId;

	/** @var String */
	public $productCount;

}
?>