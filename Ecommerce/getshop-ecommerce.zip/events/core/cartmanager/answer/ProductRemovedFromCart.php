<?php
class core_cartmanager_answer_ProductRemovedFromCart extends core_common_AnswerMessage  {
	/** @var String */
	public $productId;

}
?>