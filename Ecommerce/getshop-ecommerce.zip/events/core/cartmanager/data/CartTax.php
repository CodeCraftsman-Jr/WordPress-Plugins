<?php
class core_cartmanager_data_CartTax {
	/** @var core_productmanager_data_TaxGroup */
	public $taxGroup;

	/** @var String */
	public $sum;

}
?>