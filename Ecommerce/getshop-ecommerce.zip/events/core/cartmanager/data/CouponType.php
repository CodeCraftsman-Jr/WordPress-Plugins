<?php
class core_cartmanager_data_CouponType {
	/** @var core_cartmanager_data_CouponType */
	public $FIXED;

	/** @var core_cartmanager_data_CouponType */
	public $PERCENTAGE;

	/** @var core_cartmanager_data_CouponType; */
	public $VALUES;

}
?>