<?php
class core_cartmanager_data_CartItem {
	/** @var String */
	public $cartItemId;

	/** @var String */
	public $variations;

	/** @var core_productmanager_data_Product */
	public $product;

	/** @var String */
	public $count;

}
?>