<?php
class core_cartmanager_data_Coupon extends core_common_DataCommon  {
	/** @var String */
	public $code;

	/** @var core_cartmanager_data_CouponType */
	public $type;

	/** @var String */
	public $amount;

	/** @var String */
	public $timesLeft;

}
?>