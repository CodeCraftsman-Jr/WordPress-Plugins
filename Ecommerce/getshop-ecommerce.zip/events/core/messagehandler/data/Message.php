<?php
class core_messagehandler_data_Message extends core_common_DataCommon  {
	/** @var String */
	public $sentDate;

	/** @var String */
	public $to;

	/** @var String */
	public $from;

	/** @var String */
	public $content;

	/** @var String */
	public $toName;

	/** @var String */
	public $title;

	/** @var String */
	public $fromName;

	/** @var String */
	public $type;

}
?>