<?php
class core_messagehandler_answers_MessageSent extends core_common_AnswerMessage  {
}
?>