<?php
class core_messagehandler_events_SendMail extends core_common_MessageBase  {
	/** @var String */
	public $to;

	/** @var String */
	public $toName;

	/** @var String */
	public $title;

	/** @var String */
	public $content;

	/** @var String */
	public $from;

	/** @var String */
	public $fromName;

}
?>