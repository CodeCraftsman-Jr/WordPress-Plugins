<?php
class core_chatmanager_Chatter extends core_common_DataCommon  {
	/** @var String */
	public $lastActive;

	/** @var String */
	public $closed;

	/** @var String */
	public $sessionId;

	/** @var String */
	public $messages;

	/** @var String */
	public $username;

}
?>