<?php
class core_chatmanager_SubscribedToAirgram extends core_common_DataCommon  {
	/** @var String */
	public $accounts;

}
?>