<?php
class core_applicationmanager_ApplicationSettings extends core_common_DataCommon  {
	/** @var String */
	public $appName;

	/** @var String */
	public $description;

	/** @var String */
	public $allowedAreas;

	/** @var String */
	public $isSingleton;

	/** @var String */
	public $renderStandalone;

	/** @var String */
	public $isPublic;

	/** @var String */
	public $price;

	/** @var String */
	public $userId;

}
?>