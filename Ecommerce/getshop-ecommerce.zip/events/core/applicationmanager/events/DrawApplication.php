<?php
class core_applicationmanager_events_DrawApplication extends core_common_MessageBase  {
}
?>