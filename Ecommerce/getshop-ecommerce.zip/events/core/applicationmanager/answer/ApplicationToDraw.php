<?php
class core_applicationmanager_answer_ApplicationToDraw extends core_common_AnswerMessage  {
	/** @var String */
	public $configuration;

	/** @var String */
	public $settings;

}
?>