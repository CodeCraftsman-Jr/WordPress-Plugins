<?php
class core_usermanager_data_UserCounter extends core_common_DataCommon  {
	/** @var String */
	public $counter;

}
?>