<?php
class core_usermanager_data_Comment {
	/** @var String */
	public $dateCreated;

	/** @var String */
	public $commentId;

	/** @var String */
	public $appId;

	/** @var String */
	public $comment;

	/** @var String */
	public $extraInformation;

	/** @var String */
	public $createdByUserId;

}
?>