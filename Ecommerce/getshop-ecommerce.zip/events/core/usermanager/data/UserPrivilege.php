<?php
class core_usermanager_data_UserPrivilege {
	/** @var String */
	public $managerName;

	/** @var String */
	public $managerFunction;

}
?>