<?php
class core_usermanager_data_Address extends core_common_DataCommon  {
	/** @var String */
	public $phone;

	/** @var String */
	public $emailAddress;

	/** @var String */
	public $fullName;

	/** @var String */
	public $postCode;

	/** @var String */
	public $address;

	/** @var String */
	public $city;

	/** @var String */
	public $type;

	/** @var String */
	public $countrycode;

	/** @var String */
	public $countryname;

}
?>