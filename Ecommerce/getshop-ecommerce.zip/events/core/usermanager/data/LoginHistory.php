<?php
class core_usermanager_data_LoginHistory extends core_common_DataCommon  {
	/** @var String */
	public $logins;

	/** @var String */
	public $loginUserList;

}
?>