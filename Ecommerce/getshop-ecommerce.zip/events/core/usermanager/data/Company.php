<?php
class core_usermanager_data_Company extends core_common_DataCommon  {
	/** @var String */
	public $streetAddress;

	/** @var String */
	public $postnumber;

	/** @var String */
	public $vatNumber;

	/** @var String */
	public $country;

	/** @var String */
	public $type;

	/** @var String */
	public $city;

	/** @var String */
	public $name;

}
?>