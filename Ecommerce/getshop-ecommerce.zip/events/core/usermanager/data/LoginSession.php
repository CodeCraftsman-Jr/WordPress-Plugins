<?php
class core_usermanager_data_LoginSession {
	/** @var String */
	public $loginDate;

	/** @var String */
	public $logoffDate;

	/** @var String */
	public $sessionId;

	/** @var String */
	public $userId;

	/** @var String */
	public $editorActionsCount;

	/** @var String */
	public $adminActionsCount;

}
?>