<?php
class core_usermanager_events_DeleteUser extends core_common_MessageBase  {
	/** @var String */
	public $userId;

}
?>