<?php
class core_usermanager_events_GetAllUsers extends core_common_MessageBase  {
}
?>