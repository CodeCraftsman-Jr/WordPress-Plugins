<?php
class core_usermanager_events_SendResetCode extends core_common_MessageBase  {
	/** @var String */
	public $title;

	/** @var String */
	public $text;

	/** @var String */
	public $email;

}
?>