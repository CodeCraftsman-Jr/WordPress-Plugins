<?php
class core_usermanager_events_IsLoggedIn extends core_common_MessageBase  {
}
?>