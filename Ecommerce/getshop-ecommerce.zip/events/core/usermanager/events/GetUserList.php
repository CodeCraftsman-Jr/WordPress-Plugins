<?php
class core_usermanager_events_GetUserList extends core_common_MessageBase  {
	/** @var String */
	public $userIds;

}
?>