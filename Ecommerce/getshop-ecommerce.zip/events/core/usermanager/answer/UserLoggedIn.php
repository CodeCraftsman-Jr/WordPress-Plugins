<?php
class core_usermanager_answer_UserLoggedIn extends core_common_AnswerMessage  {
	/** @var core_usermanager_data_User */
	public $user;

}
?>