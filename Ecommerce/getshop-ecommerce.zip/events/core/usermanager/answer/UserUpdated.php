<?php
class core_usermanager_answer_UserUpdated extends core_common_AnswerMessage  {
	/** @var core_usermanager_data_User */
	public $user;

}
?>