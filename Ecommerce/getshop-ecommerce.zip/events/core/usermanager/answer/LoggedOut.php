<?php
class core_usermanager_answer_LoggedOut extends core_common_AnswerMessage  {
}
?>