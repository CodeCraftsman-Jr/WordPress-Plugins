<?php
class core_usermanager_answer_UsersFound extends core_common_AnswerMessage  {
	/** @var String */
	public $users;

}
?>