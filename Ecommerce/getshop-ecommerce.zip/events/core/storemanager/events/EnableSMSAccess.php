<?php
class core_storemanager_events_EnableSMSAccess extends core_common_MessageBase  {
	/** @var String */
	public $toggle;

	/** @var String */
	public $password;

}
?>