<?php
class core_storemanager_events_RemoveDomainName extends core_common_MessageBase  {
	/** @var String */
	public $domainName;

}
?>