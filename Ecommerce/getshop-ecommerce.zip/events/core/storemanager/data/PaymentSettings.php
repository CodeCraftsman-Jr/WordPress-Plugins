<?php
class core_storemanager_data_PaymentSettings {
	/** @var String */
	public $rows;

}
?>