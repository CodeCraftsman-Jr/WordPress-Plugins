<?php
class core_storemanager_data_StoreCounter extends core_common_DataCommon  {
	/** @var String */
	public $counter;

}
?>