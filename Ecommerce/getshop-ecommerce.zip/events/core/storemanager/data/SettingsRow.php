<?php
class core_storemanager_data_SettingsRow {
	/** @var String */
	public $settingsKey;

	/** @var String */
	public $description;

	/** @var String */
	public $name;

	/** @var String */
	public $type;

}
?>