<?php
class core_storemanager_data_Colors {
	/** @var String */
	public $baseColor;

	/** @var String */
	public $backgroundColor;

	/** @var String */
	public $textColor;

	/** @var String */
	public $buttonBackgroundColor;

	/** @var String */
	public $buttonTextColor;

}
?>