<?php
class core_storemanager_answer_CreateShopAnswer extends core_common_AnswerMessage  {
	/** @var String */
	public $shopId;

	/** @var String */
	public $webAddress;

}
?>