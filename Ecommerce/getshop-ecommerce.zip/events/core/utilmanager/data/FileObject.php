<?php
class core_utilmanager_data_FileObject extends core_common_DataCommon  {
	/** @var String */
	public $filename;

	/** @var String */
	public $dataObject;

	/** @var String */
	public $dataType;

}
?>