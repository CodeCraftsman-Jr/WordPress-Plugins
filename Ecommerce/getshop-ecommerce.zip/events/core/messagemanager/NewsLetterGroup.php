<?php
class core_messagemanager_NewsLetterGroup extends core_common_DataCommon  {
	/** @var String */
	public $userIds;

	/** @var String */
	public $emailBody;

	/** @var String */
	public $title;

	/** @var String */
	public $SentMailTo;

	/** @var String */
	public $attachments;

}
?>