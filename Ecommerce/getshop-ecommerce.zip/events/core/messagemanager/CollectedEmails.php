<?php
class core_messagemanager_CollectedEmails extends core_common_DataCommon  {
	/** @var String */
	public $emails;

}
?>