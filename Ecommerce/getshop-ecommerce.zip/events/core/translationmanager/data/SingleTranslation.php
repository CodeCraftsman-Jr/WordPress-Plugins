<?php
class core_translationmanager_data_SingleTranslation {
	/** @var String */
	public $key;

	/** @var String */
	public $translation;

	/** @var String */
	public $isFramework;

}
?>