<?php
class core_translationmanager_answer_Translation extends core_common_AnswerMessage  {
	/** @var String */
	public $translation;

}
?>