<?php
class core_translationmanager_events_AddTranslationText extends core_common_MessageBase  {
	/** @var String */
	public $text;

	/** @var String */
	public $app;

	/** @var String */
	public $languageCode;

	/** @var String */
	public $key;

}
?>