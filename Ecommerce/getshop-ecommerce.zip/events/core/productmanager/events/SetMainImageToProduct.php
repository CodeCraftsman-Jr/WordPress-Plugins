<?php
class core_productmanager_events_SetMainImageToProduct extends core_common_MessageBase  {
	/** @var String */
	public $imageId;

	/** @var String */
	public $productId;

}
?>