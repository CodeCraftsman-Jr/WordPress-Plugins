<?php
class core_productmanager_events_GetProducts extends core_common_MessageBase  {
	/** @var String */
	public $productIds;

	/** @var String */
	public $categoryId;

	/** @var String */
	public $parentId;

}
?>