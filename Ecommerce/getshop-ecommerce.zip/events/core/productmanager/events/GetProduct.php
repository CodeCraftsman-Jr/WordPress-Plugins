<?php
class core_productmanager_events_GetProduct extends core_common_MessageBase  {
	/** @var String */
	public $productId;

	/** @var String */
	public $pageId;

}
?>