<?php
class core_productmanager_events_AddImageToProduct extends core_common_MessageBase  {
	/** @var String */
	public $imageId;

	/** @var String */
	public $pageId;

	/** @var String */
	public $imageDescription;

}
?>