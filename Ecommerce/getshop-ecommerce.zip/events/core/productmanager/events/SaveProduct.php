<?php
class core_productmanager_events_SaveProduct extends core_common_MessageBase  {
	/** @var core_productmanager_data_Product */
	public $product;

	/** @var String */
	public $parentPageId;

}
?>