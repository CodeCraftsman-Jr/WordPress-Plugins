<?php
class core_productmanager_events_SearchForProduct extends core_common_MessageBase  {
	/** @var String */
	public $toSearchFor;

}
?>