<?php
class core_productmanager_answer_Products extends core_common_AnswerMessage  {
	/** @var String */
	public $products;

}
?>