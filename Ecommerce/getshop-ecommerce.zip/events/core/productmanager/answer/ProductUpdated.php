<?php
class core_productmanager_answer_ProductUpdated extends core_common_AnswerMessage  {
	/** @var String */
	public $productId;

}
?>