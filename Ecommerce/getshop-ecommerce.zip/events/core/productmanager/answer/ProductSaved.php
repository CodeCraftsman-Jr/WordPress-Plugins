<?php
class core_productmanager_answer_ProductSaved extends core_common_AnswerMessage  {
	/** @var core_productmanager_data_Product */
	public $product;

}
?>