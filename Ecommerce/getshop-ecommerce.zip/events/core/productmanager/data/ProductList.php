<?php
class core_productmanager_data_ProductList extends core_common_DataCommon  {
	/** @var String */
	public $listName;

	/** @var String */
	public $productIds;

}
?>