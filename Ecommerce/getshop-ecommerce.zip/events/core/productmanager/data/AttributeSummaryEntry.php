<?php
class core_productmanager_data_AttributeSummaryEntry {
	/** @var core_productmanager_data_AttributeValue */
	public $value;

	/** @var String */
	public $totalCount;

}
?>