<?php
class core_productmanager_data_AttributeValue extends core_common_DataCommon  {
	/** @var String */
	public $value;

	/** @var String */
	public $groupName;

}
?>