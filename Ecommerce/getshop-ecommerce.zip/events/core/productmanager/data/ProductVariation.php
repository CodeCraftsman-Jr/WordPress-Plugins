<?php
class core_productmanager_data_ProductVariation {
	/** @var String */
	public $children;

	/** @var String */
	public $priceDifference;

	/** @var String */
	public $id;

	/** @var String */
	public $title;

}
?>