<?php
class core_productmanager_data_SearchResult {
	/** @var String */
	public $products;

	/** @var String */
	public $pages;

	/** @var String */
	public $pageNumber;

}
?>