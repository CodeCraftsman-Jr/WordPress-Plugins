<?php
class core_productmanager_data_AttributeGroup extends core_common_DataCommon  {
	/** @var String */
	public $groupName;

	/** @var String */
	public $attributes;

}
?>