<?php
class core_productmanager_data_TaxGroup extends core_common_DataCommon  {
	/** @var String */
	public $groupNumber;

	/** @var String */
	public $taxRate;

}
?>