<?php
class core_productmanager_data_ProductDynamicPrice {
	/** @var String */
	public $id;

	/** @var String */
	public $from;

	/** @var String */
	public $to;

	/** @var String */
	public $price;

}
?>