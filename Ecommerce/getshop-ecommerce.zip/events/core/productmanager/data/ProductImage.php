<?php
class core_productmanager_data_ProductImage {
	/** @var String */
	public $type;

	/** @var String */
	public $name;

	/** @var String */
	public $fileId;

	/** @var String */
	public $imageDescription;

}
?>