<?php
class core_productmanager_data_ProductConfiguration extends core_common_DataCommon  {
	/** @var String */
	public $productTabs;

}
?>