<?php
class core_productmanager_data_AttributeSummary {
	/** @var String */
	public $attributeCount;

	/** @var core_productmanager_data_AttributeData */
	public $pool;

}
?>