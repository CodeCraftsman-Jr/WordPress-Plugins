<?php
class core_productmanager_data_AttributeData {
	/** @var String */
	public $values;

}
?>