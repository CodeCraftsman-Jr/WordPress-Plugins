<?php
class core_youtubemanager_data_SearchResult {
	/** @var String */
	public $id;

	/** @var String */
	public $thumbnail;

	/** @var String */
	public $name;

}
?>