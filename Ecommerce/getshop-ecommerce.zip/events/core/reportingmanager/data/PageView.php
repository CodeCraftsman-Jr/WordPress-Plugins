<?php
class core_reportingmanager_data_PageView {
	/** @var String */
	public $pageId;

	/** @var String */
	public $viewedWhen;

	/** @var String */
	public $pageName;

}
?>