<?php
class core_reportingmanager_data_ProductViewed {
	/** @var String */
	public $viewedWhen;

	/** @var String */
	public $productId;

	/** @var String */
	public $productName;

}
?>