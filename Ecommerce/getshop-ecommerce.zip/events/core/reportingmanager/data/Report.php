<?php
class core_reportingmanager_data_Report extends core_common_DataCommon  {
	/** @var String */
	public $timestamp;

	/** @var String */
	public $changed;

	/** @var String */
	public $productsAccess;

	/** @var String */
	public $usersLoggedOn;

	/** @var String */
	public $pagesAccessed;

	/** @var String */
	public $orderCount;

	/** @var String */
	public $userCreated;

}
?>