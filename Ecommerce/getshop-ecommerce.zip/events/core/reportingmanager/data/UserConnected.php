<?php
class core_reportingmanager_data_UserConnected {
	/** @var String */
	public $connectedWhen;

	/** @var String */
	public $sessionId;

	/** @var String */
	public $username;

	/** @var String */
	public $activity;

	/** @var String */
	public $firstPage;

}
?>