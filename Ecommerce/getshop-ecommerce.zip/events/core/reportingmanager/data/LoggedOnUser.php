<?php
class core_reportingmanager_data_LoggedOnUser {
	/** @var String */
	public $loggedOnWhen;

	/** @var String */
	public $email;

}
?>