<?php
class core_reportingmanager_data_EventLog {
	/** @var String */
	public $when;

	/** @var String */
	public $interfaceName;

	/** @var String */
	public $method;

	/** @var String */
	public $additionalText;

}
?>