<?php
class core_reportingmanager_data_ReportFilter {
	/** @var String */
	public $includeOnlyPages;

}
?>