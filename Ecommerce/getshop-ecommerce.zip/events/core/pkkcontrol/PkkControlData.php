<?php
class core_pkkcontrol_PkkControlData extends core_common_DataCommon  {
	/** @var String */
	public $modelAndBrand;

	/** @var String */
	public $licensePlate;

	/** @var String */
	public $vineNumber;

	/** @var String */
	public $registedYear;

	/** @var String */
	public $lastControl;

	/** @var String */
	public $nextControl;

	/** @var String */
	public $cellphone;

	/** @var String */
	public $name;

	/** @var String */
	public $email;

}
?>