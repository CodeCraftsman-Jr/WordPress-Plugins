<?php
class core_informationscreen_FeedMessage {
	/** @var String */
	public $title;

	/** @var String */
	public $description;

	/** @var String */
	public $link;

	/** @var String */
	public $author;

	/** @var String */
	public $guid;

}
?>