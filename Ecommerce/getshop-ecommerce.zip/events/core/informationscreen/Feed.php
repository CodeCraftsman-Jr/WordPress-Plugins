<?php
class core_informationscreen_Feed {
	/** @var String */
	public $title;

	/** @var String */
	public $link;

	/** @var String */
	public $description;

	/** @var String */
	public $language;

	/** @var String */
	public $copyright;

	/** @var String */
	public $pubDate;

	/** @var String */
	public $entries;

}
?>