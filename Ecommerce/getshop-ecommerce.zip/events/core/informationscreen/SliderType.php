<?php
class core_informationscreen_SliderType {
	/** @var String */
	public $name;

}
?>