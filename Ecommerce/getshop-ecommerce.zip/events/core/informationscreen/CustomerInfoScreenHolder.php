<?php
class core_informationscreen_CustomerInfoScreenHolder extends core_common_DataCommon  {
	/** @var String */
	public $customerId;

	/** @var String */
	public $tvCounter;

	/** @var String */
	public $screens;

}
?>