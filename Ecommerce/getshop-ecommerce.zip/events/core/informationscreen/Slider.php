<?php
class core_informationscreen_Slider extends core_common_DataCommon  {
	/** @var String */
	public $customerId;

	/** @var String */
	public $sliderType;

	/** @var String */
	public $name;

	/** @var String */
	public $texts;

	/** @var String */
	public $images;

}
?>