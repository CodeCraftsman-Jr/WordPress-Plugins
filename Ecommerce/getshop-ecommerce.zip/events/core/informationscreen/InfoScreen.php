<?php
class core_informationscreen_InfoScreen {
	/** @var String */
	public $backgroundImage;

	/** @var String */
	public $sliders;

	/** @var String */
	public $infoScreenId;

	/** @var String */
	public $showNewsFeed;

	/** @var String */
	public $name;

}
?>