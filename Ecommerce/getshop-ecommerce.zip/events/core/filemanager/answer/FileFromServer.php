<?php
class core_filemanager_answer_FileFromServer extends core_common_AnswerMessage  {
	/** @var String */
	public $dataFile;

	/** @var String */
	public $contentType;

}
?>