<?php
class core_filemanager_answer_ImagesFromServer extends core_common_AnswerMessage  {
	/** @var String */
	public $images;

}
?>