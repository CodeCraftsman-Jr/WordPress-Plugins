<?php
class core_ordermanager_data_Statistic {
	/** @var String */
	public $month;

	/** @var String */
	public $year;

	/** @var String */
	public $count;

	/** @var String */
	public $id;

}
?>