<?php
class core_ordermanager_events_GetOrders extends core_common_MessageBase  {
	/** @var String */
	public $orderIds;

	/** @var String */
	public $page;

	/** @var String */
	public $pageSize;

}
?>