<?php
class core_ordermanager_events_UpdateOrder extends core_common_MessageBase  {
	/** @var core_ordermanager_data_Order */
	public $order;

}
?>