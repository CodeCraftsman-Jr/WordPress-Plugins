<?php
class core_ordermanager_answer_OrderUpdated extends core_common_AnswerMessage  {
	/** @var core_ordermanager_data_Order */
	public $order;

}
?>