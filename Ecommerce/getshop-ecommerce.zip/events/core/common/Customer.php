<?php
class core_common_Customer {
}
?>