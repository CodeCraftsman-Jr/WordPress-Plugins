<?php
class core_common_events_SetEditorMode extends core_common_MessageBase  {
	/** @var String */
	public $editorMode;

}
?>