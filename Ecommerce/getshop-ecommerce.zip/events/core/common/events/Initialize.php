<?php
class core_common_events_Initialize extends core_common_MessageBase  {
	/** @var String */
	public $webAddress;

}
?>