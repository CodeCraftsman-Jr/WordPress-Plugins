<?php
class core_common_events_Reset extends core_common_MessageBase  {
}
?>