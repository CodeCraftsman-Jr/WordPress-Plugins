<?php
class core_common_AnswerMessage {
	/** @var String */
	public $className;

	/** @var core_common_MessageBase */
	public $originalMessage;

}
?>