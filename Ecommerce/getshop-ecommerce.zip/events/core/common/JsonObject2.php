<?php
class core_common_JsonObject2 {
	/** @var String */
	public $method;

	/** @var String */
	public $interfaceName;

	/** @var String */
	public $sessionId;

	/** @var String */
	public $args;

	/** @var String */
	public $addr;

	/** @var String */
	public $messageId;

}
?>