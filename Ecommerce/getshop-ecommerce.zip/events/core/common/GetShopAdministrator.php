<?php
class core_common_GetShopAdministrator {
}
?>