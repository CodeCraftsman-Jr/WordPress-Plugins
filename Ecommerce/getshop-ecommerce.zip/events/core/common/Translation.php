<?php
class core_common_Translation {
}
?>