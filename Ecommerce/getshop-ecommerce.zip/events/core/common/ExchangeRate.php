<?php
class core_common_ExchangeRate {
	/** @var String */
	public $to;

	/** @var String */
	public $from;

	/** @var String */
	public $rate;

	/** @var String */
	public $lastUpdated;

}
?>