<?php
class core_common_CartCompositeKey {
	/** @var String */
	public $productId;

	/** @var String */
	public $variations;

}
?>