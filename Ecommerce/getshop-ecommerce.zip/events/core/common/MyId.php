<?php
class core_common_MyId {
	/** @var String */
	public $_id;

}
?>