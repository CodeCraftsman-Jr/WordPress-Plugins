<?php
class core_common_Editor {
}
?>