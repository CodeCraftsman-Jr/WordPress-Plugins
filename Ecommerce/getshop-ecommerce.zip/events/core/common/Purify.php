<?php
class core_common_Purify {
}
?>