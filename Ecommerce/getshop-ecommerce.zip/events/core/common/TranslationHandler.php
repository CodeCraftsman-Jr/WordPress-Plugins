<?php
class core_common_TranslationHandler {
	/** @var String */
	public $translationStrings;

	/** @var String */
	public $translationMaps;

	/** @var String */
	public $debug;

}
?>