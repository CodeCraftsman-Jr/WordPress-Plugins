<?php
class core_common_Internal {
}
?>