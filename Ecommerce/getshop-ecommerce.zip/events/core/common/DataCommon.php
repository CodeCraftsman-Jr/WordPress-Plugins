<?php
class core_common_DataCommon extends core_common_TranslationHandler  {
	/** @var String */
	public $id;

	/** @var String */
	public $storeId;

	/** @var String */
	public $deleted;

	/** @var String */
	public $className;

	/** @var String */
	public $rowCreatedDate;

	/** @var String */
	public $lastModified;

}
?>