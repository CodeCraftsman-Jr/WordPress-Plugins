<?php
class core_common_WebSocketReturnMessage {
	/** @var String */
	public $messageId;

	/** @var String */
	public $object;

}
?>