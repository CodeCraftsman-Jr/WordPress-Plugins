<?php
class core_common_ExchangeConvert {
	/** @var String */
	public $rates;

}
?>