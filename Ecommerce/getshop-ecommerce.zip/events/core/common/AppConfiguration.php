<?php
class core_common_AppConfiguration extends core_common_DataCommon  {
	/** @var String */
	public $settings;

	/** @var String */
	public $sticky;

	/** @var String */
	public $sequence;

	/** @var String */
	public $appName;

	/** @var String */
	public $inheritate;

	/** @var String */
	public $originalPageId;

	/** @var String */
	public $appSettingsId;

}
?>