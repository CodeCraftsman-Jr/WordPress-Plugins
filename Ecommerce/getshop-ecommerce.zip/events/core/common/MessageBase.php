<?php
class core_common_MessageBase {
	/** @var String */
	public $sessionId;

	/** @var String */
	public $guid;

	/** @var core_common_ApplicationInstance */
	public $conf;

	/** @var String */
	public $sentFrom;

}
?>