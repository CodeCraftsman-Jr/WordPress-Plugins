<?php
class core_common_ManagerSetting extends core_common_DataCommon  {
	/** @var String */
	public $keys;

}
?>