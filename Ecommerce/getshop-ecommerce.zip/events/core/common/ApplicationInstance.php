<?php
class core_common_ApplicationInstance extends core_common_DataCommon  {
	/** @var String */
	public $settings;

	/** @var String */
	public $appSettingsId;

}
?>