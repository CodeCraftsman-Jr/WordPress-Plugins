<?php
class core_common_ErrorException {
	/** @var String */
	public $additionalInformation;

	/** @var String */
	public $code;

}
?>