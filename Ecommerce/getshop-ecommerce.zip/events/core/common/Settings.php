<?php
class core_common_Settings {
	/** @var String */
	public $appId;

	/** @var String */
	public $settings;

}
?>