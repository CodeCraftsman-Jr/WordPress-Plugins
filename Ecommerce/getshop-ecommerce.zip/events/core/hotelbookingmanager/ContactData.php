<?php
class core_hotelbookingmanager_ContactData {
	/** @var String */
	public $names;

	/** @var String */
	public $phones;

}
?>