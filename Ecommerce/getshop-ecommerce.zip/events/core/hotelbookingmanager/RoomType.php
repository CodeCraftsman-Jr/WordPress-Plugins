<?php
class core_hotelbookingmanager_RoomType extends core_common_DataCommon  {
	/** @var String */
	public $description_no;

	/** @var String */
	public $type;

	/** @var String */
	public $description_en;

	/** @var String */
	public $name;

}
?>