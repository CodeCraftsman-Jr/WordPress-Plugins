<?php
class core_hotelbookingmanager_BookingSettings extends core_common_DataCommon  {
	/** @var String */
	public $referenceCount;

}
?>