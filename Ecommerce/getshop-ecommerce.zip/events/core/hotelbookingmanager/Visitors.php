<?php
class core_hotelbookingmanager_Visitors {
	/** @var String */
	public $name;

	/** @var String */
	public $phone;

	/** @var String */
	public $email;

}
?>