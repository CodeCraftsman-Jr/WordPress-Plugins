<?php
class core_hotelbookingmanager_AdditionalBookingInformation extends core_common_DataCommon  {
	/** @var String */
	public $numberOfParkingLots;

	/** @var String */
	public $needHandicap;

}
?>