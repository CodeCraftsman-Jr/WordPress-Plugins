<?php
class core_hotelbookingmanager_RoomInformation {
	/** @var String */
	public $roomId;

	/** @var String */
	public $cartItemId;

	/** @var String */
	public $visitors;

	/** @var String */
	public $roomState;

}
?>