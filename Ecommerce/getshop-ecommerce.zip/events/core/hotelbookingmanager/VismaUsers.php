<?php
class core_hotelbookingmanager_VismaUsers extends core_common_DataCommon  {
	/** @var String */
	public $transfereddUserIds;

}
?>