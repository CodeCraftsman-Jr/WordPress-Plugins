<?php
class core_hotelbookingmanager_VismaSettings extends core_common_DataCommon  {
	/** @var String */
	public $address;

	/** @var String */
	public $username;

	/** @var String */
	public $password;

	/** @var String */
	public $port;

	/** @var String */
	public $sqlUsername;

	/** @var String */
	public $sqlPassword;

	/** @var String */
	public $database;

}
?>