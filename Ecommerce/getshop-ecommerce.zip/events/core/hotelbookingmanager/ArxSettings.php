<?php
class core_hotelbookingmanager_ArxSettings extends core_common_DataCommon  {
	/** @var String */
	public $address;

	/** @var String */
	public $username;

	/** @var String */
	public $password;

	/** @var String */
	public $smsFrom;

	/** @var String */
	public $smsWelcome;

	/** @var String */
	public $smsReady;

	/** @var String */
	public $smsWelcomeNO;

	/** @var String */
	public $smsReadyNO;

	/** @var String */
	public $emailWelcome;

	/** @var String */
	public $emailWelcomeNO;

	/** @var String */
	public $emailWelcomeTitle;

	/** @var String */
	public $emailWelcomeTitleNO;

}
?>