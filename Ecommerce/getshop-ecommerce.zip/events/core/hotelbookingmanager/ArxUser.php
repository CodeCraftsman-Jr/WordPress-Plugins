<?php
class core_hotelbookingmanager_ArxUser extends core_common_DataCommon  {
	/** @var String */
	public $userId;

	/** @var String */
	public $firstName;

	/** @var String */
	public $lastName;

	/** @var String */
	public $startDate;

	/** @var String */
	public $endDate;

	/** @var String */
	public $code;

	/** @var String */
	public $needUpdate;

	/** @var String */
	public $doorsToAccess;

	/** @var String */
	public $reference;

}
?>