<?php
class core_hotelbookingmanager_MSQLActors {
	/** @var String */
	public $Nm;

	/** @var String */
	public $Ad1;

	/** @var String */
	public $PNo;

	/** @var String */
	public $PArea;

	/** @var String */
	public $MailAd;

	/** @var String */
	public $MobPh;

	/** @var String */
	public $customerId;

}
?>