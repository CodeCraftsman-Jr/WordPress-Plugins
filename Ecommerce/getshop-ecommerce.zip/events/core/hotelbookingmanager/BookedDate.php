<?php
class core_hotelbookingmanager_BookedDate {
	/** @var String */
	public $code;

	/** @var String */
	public $date;

	/** @var String */
	public $bookingReference;

}
?>