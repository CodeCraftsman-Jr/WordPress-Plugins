<?php
class core_hotelbookingmanager_ArxLogEntry extends core_common_DataCommon  {
	/** @var core_hotelbookingmanager_ArxUser */
	public $user;

	/** @var String */
	public $message;

}
?>