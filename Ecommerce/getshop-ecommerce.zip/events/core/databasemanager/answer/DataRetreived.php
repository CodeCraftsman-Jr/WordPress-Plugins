<?php
class core_databasemanager_answer_DataRetreived extends core_common_AnswerMessage  {
	/** @var String */
	public $data;

}
?>