<?php
class core_databasemanager_events_DeleteData extends core_common_MessageBase  {
	/** @var core_common_DataCommon */
	public $dataObject;

	/** @var core_databasemanager_data_Credentials */
	public $credentials;

}
?>