<?php
class core_databasemanager_data_DataRetreived {
	/** @var String */
	public $data;

}
?>