<?php
class core_appmanager_data_SavedApplicationSettings extends core_common_DataCommon  {
	/** @var String */
	public $settings;

	/** @var String */
	public $applicationId;

}
?>