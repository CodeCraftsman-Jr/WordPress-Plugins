<?php
class core_appmanager_data_ApplicationModule {
	/** @var String */
	public $needToShowInMenu;

	/** @var String */
	public $moduleName;

	/** @var String */
	public $id;

	/** @var String */
	public $description;

	/** @var String */
	public $faIcon;

}
?>