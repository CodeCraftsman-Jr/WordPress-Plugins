<?php
class core_appmanager_data_ApiCallsInUse {
	/** @var String */
	public $manager;

	/** @var String */
	public $method;

}
?>