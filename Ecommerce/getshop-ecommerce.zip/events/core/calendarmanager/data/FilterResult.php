<?php
class core_calendarmanager_data_FilterResult {
	/** @var String */
	public $pageId;

	/** @var String */
	public $entries;

}
?>