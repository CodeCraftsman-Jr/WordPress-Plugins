<?php
class core_calendarmanager_data_Day {
	/** @var String */
	public $entries;

	/** @var String */
	public $day;

}
?>