<?php
class core_calendarmanager_data_Location extends core_common_DataCommon  {
	/** @var String */
	public $comments;

	/** @var String */
	public $location;

	/** @var String */
	public $locationExtra;

}
?>