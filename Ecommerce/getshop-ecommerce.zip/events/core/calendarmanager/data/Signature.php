<?php
class core_calendarmanager_data_Signature extends core_common_DataCommon  {
	/** @var String */
	public $userid;

	/** @var String */
	public $signature;

}
?>