<?php
class core_calendarmanager_data_EventPartitipated extends core_common_DataCommon  {
	/** @var String */
	public $title;

	/** @var String */
	public $title2;

	/** @var String */
	public $heading;

	/** @var String */
	public $body;

	/** @var String */
	public $pageId;

}
?>