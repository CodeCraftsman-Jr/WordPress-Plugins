<?php
class core_calendarmanager_data_ReminderHistory extends core_common_DataCommon  {
	/** @var String */
	public $users;

	/** @var String */
	public $byEmail;

	/** @var String */
	public $text;

	/** @var String */
	public $date;

	/** @var String */
	public $subject;

	/** @var String */
	public $eventId;

}
?>