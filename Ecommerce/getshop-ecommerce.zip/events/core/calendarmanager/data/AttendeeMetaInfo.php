<?php
class core_calendarmanager_data_AttendeeMetaInfo {
	/** @var String */
	public $userId;

	/** @var String */
	public $source;

}
?>