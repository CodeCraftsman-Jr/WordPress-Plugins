<?php
class core_calendarmanager_data_EntryComment {
	/** @var String */
	public $id;

	/** @var String */
	public $addedWhen;

	/** @var String */
	public $text;

	/** @var String */
	public $userId;

}
?>