<?php
class core_loggermanager_data_LoggerData extends core_common_DataCommon  {
	/** @var String */
	public $type;

	/** @var String */
	public $data;

	/** @var String */
	public $additionalMessage;

	/** @var String */
	public $userId;

}
?>