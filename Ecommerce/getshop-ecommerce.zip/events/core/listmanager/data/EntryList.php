<?php
class core_listmanager_data_EntryList extends core_common_DataCommon  {
	/** @var String */
	public $entries;

	/** @var String */
	public $appId;

	/** @var String */
	public $name;

	/** @var core_listmanager_data_ListType */
	public $type;

	/** @var String */
	public $extendedLists;

}
?>