<?php
class core_listmanager_data_Entry extends core_common_TranslationHandler  {
	/** @var String */
	public $navigateByPages;

	/** @var String */
	public $name;

	/** @var String */
	public $parentId;

	/** @var String */
	public $pageId;

	/** @var String */
	public $imageId;

	/** @var String */
	public $hardLink;

	/** @var String */
	public $userLevel;

	/** @var String */
	public $id;

	/** @var String */
	public $productId;

	/** @var String */
	public $fontAwsomeIcon;

	/** @var String */
	public $counter;

	/** @var String */
	public $subentries;

	/** @var String */
	public $pageType;

	/** @var String */
	public $uniqueId;

}
?>