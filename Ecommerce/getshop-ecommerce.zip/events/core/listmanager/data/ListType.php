<?php
class core_listmanager_data_ListType {
	/** @var core_listmanager_data_ListType */
	public $PRODUCT;

	/** @var core_listmanager_data_ListType */
	public $MENU;

	/** @var core_listmanager_data_ListType; */
	public $VALUES;

}
?>