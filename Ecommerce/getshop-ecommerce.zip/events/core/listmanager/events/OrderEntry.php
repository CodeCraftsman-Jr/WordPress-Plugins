<?php
class core_listmanager_events_OrderEntry extends core_common_MessageBase  {
	/** @var String */
	public $id;

	/** @var String */
	public $after;

	/** @var String */
	public $parentId;

}
?>