<?php
class core_listmanager_events_GetList extends core_common_MessageBase  {
}
?>