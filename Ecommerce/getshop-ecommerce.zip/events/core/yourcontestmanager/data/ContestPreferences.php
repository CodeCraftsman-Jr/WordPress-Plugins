<?php
class core_yourcontestmanager_data_ContestPreferences {
	/** @var String */
	public $contestId;

	/** @var String */
	public $entered;

	/** @var String */
	public $notInterested;

	/** @var String */
	public $favourite;

	/** @var String */
	public $enteredDate;

}
?>