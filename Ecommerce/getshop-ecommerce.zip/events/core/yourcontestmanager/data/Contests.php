<?php
class core_yourcontestmanager_data_Contests extends core_common_DataCommon  {
	/** @var String */
	public $title;

	/** @var String */
	public $description;

	/** @var String */
	public $longdesc;

	/** @var String */
	public $contestlink;

	/** @var String */
	public $imageLink;

	/** @var String */
	public $rulesLink;

	/** @var String */
	public $startDate;

	/** @var String */
	public $endDate;

	/** @var String */
	public $addedDate;

	/** @var String */
	public $featured;

	/** @var String */
	public $type;

	/** @var String */
	public $tags;

	/** @var String */
	public $country_code;

	/** @var String */
	public $provinces;

	/** @var String */
	public $rating;

	/** @var String */
	public $numraters;

	/** @var String */
	public $totalrating;

}
?>