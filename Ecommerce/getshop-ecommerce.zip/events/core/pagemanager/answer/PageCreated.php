<?php
class core_pagemanager_answer_PageCreated extends core_common_AnswerMessage  {
	/** @var core_pagemanager_data_Page */
	public $page;

}
?>