<?php
class core_pagemanager_answer_SettingsSaved extends core_common_AnswerMessage  {
	/** @var core_common_AppConfiguration */
	public $application;

}
?>