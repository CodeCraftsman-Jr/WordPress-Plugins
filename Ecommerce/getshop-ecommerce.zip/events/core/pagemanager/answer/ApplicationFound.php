<?php
class core_pagemanager_answer_ApplicationFound extends core_common_AnswerMessage  {
	/** @var core_common_AppConfiguration */
	public $application;

}
?>