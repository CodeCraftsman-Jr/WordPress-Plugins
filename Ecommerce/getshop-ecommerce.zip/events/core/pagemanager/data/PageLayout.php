<?php
class core_pagemanager_data_PageLayout {
	/** @var String */
	public $areas;

	/** @var String */
	public $mobileList;

	/** @var String */
	public $mobileTmpList;

}
?>