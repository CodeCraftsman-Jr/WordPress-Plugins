<?php
class core_pagemanager_data_CarouselConfig {
	/** @var String */
	public $height;

	/** @var String */
	public $heightMobile;

	/** @var String */
	public $time;

	/** @var String */
	public $type;

	/** @var String */
	public $displayNumbersOnDots;

	/** @var String */
	public $avoidRotate;

	/** @var String */
	public $navigateOnMouseOver;

}
?>