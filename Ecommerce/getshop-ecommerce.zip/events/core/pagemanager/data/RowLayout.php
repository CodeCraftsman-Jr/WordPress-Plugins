<?php
class core_pagemanager_data_RowLayout {
	/** @var String */
	public $numberOfCells;

	/** @var String */
	public $areas;

	/** @var String */
	public $marginBottom;

	/** @var String */
	public $marginTop;

	/** @var String */
	public $rowWidth;

	/** @var String */
	public $rowId;

	/** @var String */
	public $outercss;

	/** @var String */
	public $innercss;

}
?>