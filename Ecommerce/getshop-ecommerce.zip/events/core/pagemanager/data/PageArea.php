<?php
class core_pagemanager_data_PageArea {
	/** @var String */
	public $applications;

	/** @var String */
	public $applicationsSequenceList;

	/** @var String */
	public $extraApplicationList;

	/** @var String */
	public $applicationsList;

	/** @var String */
	public $bottomApplications;

	/** @var String */
	public $bottomLeftApplicationId;

	/** @var String */
	public $bottomMiddleApplicationId;

	/** @var String */
	public $bottomRightApplicationId;

	/** @var String */
	public $type;

	/** @var String */
	public $pageId;

	/** @var String */
	public $bottomAreaActivated;

}
?>