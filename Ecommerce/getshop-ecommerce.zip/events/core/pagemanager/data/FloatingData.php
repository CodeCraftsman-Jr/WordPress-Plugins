<?php
class core_pagemanager_data_FloatingData {
	/** @var String */
	public $top;

	/** @var String */
	public $left;

	/** @var String */
	public $width;

	/** @var String */
	public $height;

	/** @var String */
	public $pinned;

}
?>