<?php
class core_pagemanager_data_CommonPageData extends core_common_DataCommon  {
	/** @var String */
	public $header;

	/** @var String */
	public $footer;

}
?>