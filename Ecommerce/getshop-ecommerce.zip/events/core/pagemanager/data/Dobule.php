<?php
class core_pagemanager_data_Dobule {
}
?>