<?php
class core_pagemanager_events_SetPageUserLevel extends core_common_MessageBase  {
	/** @var String */
	public $pageId;

	/** @var String */
	public $userLevel;

}
?>