<?php
class core_pagemanager_events_CreateNewPage extends core_common_MessageBase  {
	/** @var String */
	public $type;

	/** @var String */
	public $parentid;

}
?>