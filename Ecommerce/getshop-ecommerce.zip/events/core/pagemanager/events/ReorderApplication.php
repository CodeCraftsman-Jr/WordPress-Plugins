<?php
class core_pagemanager_events_ReorderApplication extends core_common_MessageBase  {
	/** @var String */
	public $appid;

	/** @var String */
	public $pageId;

	/** @var String */
	public $moveApplicationUp;

}
?>