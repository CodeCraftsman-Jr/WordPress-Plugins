<?php
class core_pagemanager_events_UpdateParentPage extends core_common_MessageBase  {
	/** @var String */
	public $parentPageId;

	/** @var String */
	public $pageId;

}
?>