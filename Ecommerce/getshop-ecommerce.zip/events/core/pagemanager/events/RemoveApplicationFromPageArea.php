<?php
class core_pagemanager_events_RemoveApplicationFromPageArea extends core_common_MessageBase  {
	/** @var core_common_AppConfiguration */
	public $configToDelete;

}
?>