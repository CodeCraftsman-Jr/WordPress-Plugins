<?php
class core_pdf_data_AccountingDetails {
	/** @var String */
	public $accountNumber;

	/** @var String */
	public $vatNumber;

	/** @var String */
	public $address;

	/** @var String */
	public $companyName;

	/** @var String */
	public $postCode;

	/** @var String */
	public $city;

	/** @var String */
	public $contactEmail;

	/** @var String */
	public $webAddress;

	/** @var String */
	public $dueDays;

}
?>