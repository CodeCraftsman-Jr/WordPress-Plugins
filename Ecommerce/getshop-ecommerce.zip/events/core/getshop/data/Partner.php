<?php
class core_getshop_data_Partner extends core_common_DataCommon  {
	/** @var String */
	public $partnerId;

	/** @var String */
	public $userId;

	/** @var String */
	public $availableApplications;

}
?>