<?php
class core_getshop_data_StoreCreatedData {
	/** @var core_usermanager_data_User */
	public $user;

	/** @var core_storemanager_data_Store */
	public $store;

}
?>