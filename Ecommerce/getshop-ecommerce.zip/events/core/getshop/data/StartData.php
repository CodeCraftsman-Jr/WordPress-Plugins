<?php
class core_getshop_data_StartData {
	/** @var String */
	public $name;

	/** @var String */
	public $email;

	/** @var String */
	public $storeId;

	/** @var String */
	public $shopName;

	/** @var String */
	public $phoneNumber;

	/** @var String */
	public $password;

	/** @var String */
	public $color;

	/** @var String */
	public $language;

}
?>