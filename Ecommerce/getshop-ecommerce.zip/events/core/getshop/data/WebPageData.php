<?php
class core_getshop_data_WebPageData {
	/** @var String */
	public $fullName;

	/** @var String */
	public $emailAddress;

	/** @var String */
	public $password;

	/** @var String */
	public $hostname;

}
?>