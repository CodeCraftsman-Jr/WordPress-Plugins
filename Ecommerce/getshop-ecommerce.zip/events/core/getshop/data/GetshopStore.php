<?php
class core_getshop_data_GetshopStore {
	/** @var String */
	public $webaddress;

	/** @var String */
	public $lastLoggedIn;

	/** @var String */
	public $created;

	/** @var String */
	public $email;

	/** @var String */
	public $username;

	/** @var String */
	public $configEmail;

	/** @var String */
	public $hasChrome;

	/** @var String */
	public $userAgents;

}
?>