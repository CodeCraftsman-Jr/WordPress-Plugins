<?php
class core_getshop_data_PartnerData extends core_common_DataCommon  {
	/** @var String */
	public $partnerId;

	/** @var String */
	public $applications;

}
?>