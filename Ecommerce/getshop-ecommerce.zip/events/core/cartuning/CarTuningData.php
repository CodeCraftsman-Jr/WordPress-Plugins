<?php
class core_cartuning_CarTuningData {
	/** @var String */
	public $id;

	/** @var String */
	public $subEntries;

	/** @var String */
	public $name;

	/** @var String */
	public $originalHp;

	/** @var String */
	public $originalNm;

	/** @var String */
	public $maxHp;

	/** @var String */
	public $maxNw;

	/** @var String */
	public $normalHp;

	/** @var String */
	public $normalNw;

}
?>