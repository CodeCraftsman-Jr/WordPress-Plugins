<?php
class core_cartuning_CarTuningCollection extends core_common_DataCommon  {
	/** @var String */
	public $entries;

}
?>