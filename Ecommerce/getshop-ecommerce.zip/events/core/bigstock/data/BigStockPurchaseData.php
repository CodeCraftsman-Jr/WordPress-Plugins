<?php
class core_bigstock_data_BigStockPurchaseData {
	/** @var String */
	public $currency_amount;

	/** @var String */
	public $currency_code;

	/** @var String */
	public $download_id;

}
?>