<?php
class core_bigstock_data_BigStockPurchaseResponse {
	/** @var String */
	public $response_code;

	/** @var String */
	public $message;

	/** @var core_bigstock_data_BigStockPurchaseData */
	public $data;

}
?>