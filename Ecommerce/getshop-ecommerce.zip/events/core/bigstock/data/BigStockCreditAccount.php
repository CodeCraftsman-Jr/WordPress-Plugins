<?php
class core_bigstock_data_BigStockCreditAccount extends core_common_DataCommon  {
	/** @var String */
	public $purchasedImages;

	/** @var String */
	public $creditAccount;

}
?>