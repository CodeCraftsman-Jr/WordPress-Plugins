<?php
class core_sedox_SedoxSearch {
	/** @var String */
	public $page;

	/** @var String */
	public $searchCriteria;

}
?>