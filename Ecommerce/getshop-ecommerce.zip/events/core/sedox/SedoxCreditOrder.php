<?php
class core_sedox_SedoxCreditOrder {
	/** @var String */
	public $magentoOrderId;

	/** @var String */
	public $amount;

}
?>