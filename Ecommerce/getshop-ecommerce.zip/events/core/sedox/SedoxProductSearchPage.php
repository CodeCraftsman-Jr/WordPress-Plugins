<?php
class core_sedox_SedoxProductSearchPage {
	/** @var String */
	public $pageNumber;

	/** @var String */
	public $products;

	/** @var String */
	public $totalPages;

}
?>