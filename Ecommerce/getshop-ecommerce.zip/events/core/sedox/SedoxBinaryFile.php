<?php
class core_sedox_SedoxBinaryFile {
	/** @var String */
	public $id;

	/** @var String */
	public $md5sum;

	/** @var String */
	public $fileType;

	/** @var String */
	public $checksumCorrected;

	/** @var String */
	public $orgFilename;

	/** @var String */
	public $extraInformation;

	/** @var String */
	public $additionalInformation;

	/** @var String */
	public $cmdFileType;

}
?>