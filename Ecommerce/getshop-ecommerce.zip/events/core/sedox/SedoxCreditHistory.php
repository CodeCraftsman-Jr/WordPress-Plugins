<?php
class core_sedox_SedoxCreditHistory {
	/** @var String */
	public $transactionReference;

	/** @var String */
	public $description;

	/** @var String */
	public $amount;

	/** @var String */
	public $dateCreated;

}
?>