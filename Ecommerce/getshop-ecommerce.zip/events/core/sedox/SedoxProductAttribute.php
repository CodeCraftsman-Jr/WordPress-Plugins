<?php
class core_sedox_SedoxProductAttribute {
	/** @var String */
	public $id;

	/** @var String */
	public $value;

}
?>