<?php
class core_sedox_SedoxOrder {
	/** @var String */
	public $productId;

	/** @var String */
	public $creditAmount;

}
?>