<?php
class core_sedox_SedoxProductHistory {
	/** @var String */
	public $description;

	/** @var String */
	public $userId;

	/** @var String */
	public $dateCreated;

}
?>