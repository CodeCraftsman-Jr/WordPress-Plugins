<?php
class core_sedox_SedoxCreditAccount {
	/** @var String */
	public $history;

	/** @var String */
	public $allowNegativeCredit;

	/** @var String */
	public $balance;

}
?>