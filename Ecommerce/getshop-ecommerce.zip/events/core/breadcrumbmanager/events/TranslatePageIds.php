<?php
class core_breadcrumbmanager_events_TranslatePageIds extends core_common_MessageBase  {
	/** @var String */
	public $addresses;

}
?>