<?php
class core_breadcrumbmanager_answer_TranslatedAddresses extends core_common_AnswerMessage  {
	/** @var String */
	public $addresses;

}
?>