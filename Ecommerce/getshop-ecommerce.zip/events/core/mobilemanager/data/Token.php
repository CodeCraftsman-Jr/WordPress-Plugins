<?php
class core_mobilemanager_data_Token extends core_common_DataCommon  {
	/** @var String */
	public $tokenId;

	/** @var core_mobilemanager_data_TokenType */
	public $type;

	/** @var String */
	public $appName;

	/** @var String */
	public $testMode;

}
?>