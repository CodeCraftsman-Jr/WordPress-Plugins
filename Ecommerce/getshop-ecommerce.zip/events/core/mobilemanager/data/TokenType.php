<?php
class core_mobilemanager_data_TokenType {
	/** @var core_mobilemanager_data_TokenType */
	public $IOS;

	/** @var core_mobilemanager_data_TokenType */
	public $ANDROID;

	/** @var core_mobilemanager_data_TokenType; */
	public $VALUES;

}
?>