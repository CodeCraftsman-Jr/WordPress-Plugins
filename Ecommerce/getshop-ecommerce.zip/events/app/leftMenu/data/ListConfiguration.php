<?php
class app_leftMenu_data_ListConfiguration extends core_common_DataCommon  {
	/** @var String */
	public $entries;

	/** @var String */
	public $appId;

	/** @var String */
	public $entriesList;

	/** @var String */
	public $orderedList;

	/** @var String */
	public $editorMode;

	/** @var String */
	public $autoExpand;

}
?>