<?php
class app_categoryList_data_Settings extends core_common_DataCommon  {
	/** @var String */
	public $displayBreadCrumb;

	/** @var String */
	public $displayProductList;

	/** @var String */
	public $displayProductNavigation;

	/** @var String */
	public $title;

	/** @var String */
	public $appConfId;

}
?>