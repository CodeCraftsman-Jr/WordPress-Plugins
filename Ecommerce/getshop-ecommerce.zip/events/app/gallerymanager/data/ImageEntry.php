<?php
class app_gallerymanager_data_ImageEntry extends core_common_DataCommon  {
	/** @var String */
	public $imageId;

	/** @var String */
	public $description;

	/** @var String */
	public $appId;

	/** @var String */
	public $title;

}
?>