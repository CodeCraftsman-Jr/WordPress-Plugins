<?php
class app_logomanager_data_SavedLogo extends core_common_DataCommon  {
	/** @var String */
	public $LogoId;

}
?>