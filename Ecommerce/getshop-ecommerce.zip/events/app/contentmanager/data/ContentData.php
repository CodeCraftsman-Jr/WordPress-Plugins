<?php
class app_contentmanager_data_ContentData extends core_common_DataCommon  {
	/** @var String */
	public $content;

	/** @var String */
	public $appId;

}
?>