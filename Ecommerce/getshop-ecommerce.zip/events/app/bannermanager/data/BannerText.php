<?php
class app_bannermanager_data_BannerText {
	/** @var String */
	public $x;

	/** @var String */
	public $y;

	/** @var String */
	public $text;

	/** @var String */
	public $size;

	/** @var String */
	public $colour;

}
?>