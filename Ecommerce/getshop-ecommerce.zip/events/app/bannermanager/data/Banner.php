<?php
class app_bannermanager_data_Banner {
	/** @var String */
	public $imageId;

	/** @var String */
	public $productId;

	/** @var String */
	public $link;

	/** @var String */
	public $rotation;

	/** @var String */
	public $crop_cordinates;

	/** @var String */
	public $imagetext;

}
?>