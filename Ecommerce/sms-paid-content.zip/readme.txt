=== SMS paid content ===
Contributors: smscoin.com
Donate link: http://smscoin.com/
Tags:plugin, sms, content, post, donate, payment, billing
Requires at least: 2.0.2
Tested up to: 3.5
Stable tag: 0.2

This Plugin allows you to hide any content on your blog, that will be visible only after user sends sms message.

== Description ==

This Plugin allows you to hide any content on your blog, that will be visible only after user sends sms message.

The sms:key is, from the implementational point of view, just a way of restricting user's ability to visit certain web-resources.
In order to allow a user to review the restricted content, individual access passwords are generated; 
each one of these passwords can have a time and/or visit count limit, up to you.
The access for the certain password is denied when the time is up OR when the visit count limit is hit, whichever comes first.
Be careful while adjusting the options thought: note that when you change your sms:key options,
only those users that signed up after the change are affected.

For using this module you have to be registered at sms billing site:
       English:	http://smscoin.com/account/register/
       Russian: http://smscoin.com/ru/account/register/

USING: [sms] Hidden text [/sms]

== Installation ==

1. Upload contents of the ZIP file to your wp-content/plugins folder.
2. Activate the "SMS paid content" plugin.
3. You'll see a "SMS paid content Options" sub-page in the Plugins page.
4. Configure the plugin.

== Frequently Asked Questions ==

= How a can to use this plugin ? =

USING: [sms] Hidden text [/sms]

== Arbitrary section ==

For using this module you have to be registered at sms billing site:

       English:	http://smscoin.com/account/register/
       Russian: http://smscoin.com/ru/account/register/
       
== Screenshots ==

1. Options screen.       
