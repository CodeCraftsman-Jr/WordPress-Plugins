<div id="kc_ad_css">
	<p class="note">Enter the raw CSS for this ad.</p>
	<textarea name="kc_ad_css" id="kc_ad_css_field" rows="10"><?php if (!empty($kc_ad_css)){ echo $kc_ad_css; } ?></textarea>
</div>