﻿=== Ket Qua Xo So ===

Contributors: baby2j
Donate link: http://www.xoso.com
Tags: ket qua, xo so, vietnam
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.xoso.com
Plugin giúp bạn chèn kết quả Xổ Số vào trang web cực kỳ dễ dàng!

== Description ==

Plugin giúp bạn chèn kết quả Xổ Số từ xoso.com vào trang web cực kỳ dễ dàng.
Kết quả xổ số tự động cập nhật theo ngày nhanh nhất, chính xác nhất!

== Installation ==

1. Unzip the xoso.zip
2. Copy "xoso" folder to wp-content/plugins
3. Go to Plugins/Installed Plugins, find Kết Quả Xổ Số and click Active
4. Go to Appearance/Widgets to add Kết Quả Xổ Số widget
5. Enjoy!