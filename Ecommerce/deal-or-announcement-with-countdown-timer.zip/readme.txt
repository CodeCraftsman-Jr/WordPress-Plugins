=== deal or announcement with countdown timer ===
Contributors: www.gopiplus.com, gopiplus 
Donate link: http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/
Author URI: http://www.gopiplus.com/
Tags: deal, announcement, countdown, timer, widget, Offers
Requires at least: 3.4
Tested up to: 4.3
Stable tag: 8.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This plugin will display your announcement with countdown timer.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/](http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/)

*   [Live Demo](http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/)  
*   [About Author](http://www.gopiplus.com/)  
*   [More Info](http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/)  
*   [Comments/Suggestion](http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/)

Deal or announcement with countdown WordPress plugin will display the announcement, deal, offers with countdown timer. admin can add N number of deal at dashboard, only one active deal will display at website front end with countdown timer. this plugin is best suitable to show promotional offers to the user with countdown time.  

**Feature :**  

*   Simple.	
*   We can display our deal or offers or announcement with countdown.  	
*   Style override system.  	
*   Countdown timer.  	
  
[http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/](http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/)

== Installation ==

[See Installation Instruction and Configuration information and Demo](http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/)

== Frequently Asked Questions ==

1. Can I display more Deal at same time?

2. Can I customize the color and align style?

3. why it show 'No data available in announcement!' on front end?

4. why it show 'Time Out!' on timer area?

[Answer](http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/)

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/

2. Admin Screen. http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/

3. Widget Screen. http://www.gopiplus.com/work/2010/07/18/deal-or-announcement-with-countdown-timer/

== Upgrade Notice ==

= 8.8 =
1. Tested up to 4.3

= 8.7 =
1. Tested up to 4.2.2

= 8.6 =
1. Tested up to 4.1

= 8.5 =
1. Tested up to 4.0

= 8.4 =
Plugin version 8.3 bug fixed

= 8.3 =
1. Tested up to 3.9
2. Restricted direct page access.

= 8.2 =
1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (deal-with-countdown.po) available in the languages folder.

= 8.1 =
New admin layout.
Added some security feature.

= 8.0 =
Tested up to 3.6

= 7.1 =
Tested up to 3.5

= 7.0 =
New demo link, www.gopiplus.com

= 6.0 =
Tested up to 3.4

= 5.0 =
Tested up to 3.3.1

= 4.0 =
Tested up to 3.2, Hereafter Only Admin user can access this plugin in the dashboard.

= 3.0 =
Tested up to 3.0, and new live demo link added.

= 2.0 =
Date option enabled

= 1.0 =
First version

== Changelog ==

= 8.8 =
1. Tested up to 4.3

= 8.7 =
1. Tested up to 4.2.2

= 8.6 =
1. Tested up to 4.1

= 8.5 =
1. Tested up to 4.0

= 8.4 =
Plugin version 8.3 bug fixed

= 8.3 =
1. Tested up to 3.9
2. Restricted direct page access.

= 8.2 =
1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (deal-with-countdown.po) available in the languages folder.

= 8.1 =
New admin layout.
Added some security feature.

= 8.0 =
Tested up to 3.6

= 7.1 =
Tested up to 3.5

= 7.0 =
New demo link, www.gopiplus.com

= 6.0 =
Tested up to 3.4

= 5.0 =
Tested up to 3.3.1

= 4.0 =
Tested up to 3.2, Hereafter Only Admin user can access this plugin in the dashboard.

= 3.0 =
Tested up to 3.0, and new live demo link added.

= 2.0 =
Date option enabled

= 1.0 =
First version