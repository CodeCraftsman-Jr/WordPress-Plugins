=== PRyC WooCommerce: Product search in any search ===
Contributors: PRyCpl
Tags: WooCommerce, search, search field, ecommerce
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Search WooCommerce product at default theme search field or any other...

== Description ==
Search WooCommerce product at default theme search field or any other...

== Installation ==
1. Upload `pryc-woocommerce-product-search-in-any-search` dir to the `/wp-content/plugins/` directory
2. Activate the plugin through the \'Plugins\' menu in WordPress

== Screenshots ==
1. Default search before
2. Default search after

== Changelog ==
1.0.1: First public ver.