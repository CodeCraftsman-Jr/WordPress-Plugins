jQuery(function ($) {

/*fancybox*/
	jQuery('.dpsc_image_section .fancybox').fancybox();


});