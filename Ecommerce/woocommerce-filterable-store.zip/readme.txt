=== WooCommerce Filterable Store ===
Contributors: Rameez_Iqbal
Donate link: https://www.2checkout.com/checkout/purchase?sid=202485641&quantity=1&product_id=1
Tags: woocommerce, wordpress, shortcode, animation, slider, shop, product, cart, store, pages, widget, fullpage
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An amazing new look for WooCommerce Shop, with click to filter and product gallery slider.

== Description ==

An amazing new look for WooCommerce Shop, with click to filter and product gallery slider.

<h3>Features</h3>
<ol>
	<li>Responsive Grid</li>
	<li>Product Ratings</li>
	<li>Click to filter</li>
	<li>Add to Cart directly</li>
	<li>Product gallery + Feature Image Slider</li>
	<li>Animating Filtering</li>
	<li>Change Color Schemes</li>
</ol>


== Installation ==

1. Go to plugins in your dashboard and select 'add new'
2. Search for 'woocommerce filterable store' and install it
4. Use builtin shortcode generator to generate shortcode
5. Now use that shortcode and visit that page
6. Enjoy :)



== Screenshots ==

1. Shortcode generator.