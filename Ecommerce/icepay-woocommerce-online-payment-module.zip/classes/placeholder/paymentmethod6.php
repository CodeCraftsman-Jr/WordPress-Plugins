<?php

class ICEPAY_PaymentMethod_6 extends ICEPAY_Paymentmethod_Core {
    protected $pmCode = 6;
}
