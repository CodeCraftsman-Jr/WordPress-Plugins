<?php

class ICEPAY_PaymentMethod_2 extends ICEPAY_Paymentmethod_Core {
    protected $pmCode = 2;
}
