<div style="background-image: url('{image}');" id="icepay-header">
    <div id="icepay-header-info">
        <a href="http://www.icepay.com/downloads/pdf/manuals/wordpress-woocommerce/manual-wordpress-woocommerce.pdf" target="_BLANK">{manual}</a> | <a href="http://www.icepay.com"  target="_BLANK">{website}</a>
    </div>
</div>

<br class="clear">

<table class="form-table">
    {settings}
</table>