<h3>Sorry to see you go!</h3>
<p>This account has been canceled:</p>
<p>
Email : _payer_email_<BR/>
</p>

<p>Please reply to this email message and let us know why you decided to cancel your subscription.
If I can work to make this service any better, I will!</p>

<p>Visit us anytime, <a href="http://www.jonathonbyrd.com/">http://www.jonathonbyrd.com/</a></p>