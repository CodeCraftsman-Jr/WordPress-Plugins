<h3>Oh No! You let your account expire.</h3>
<p>The following account has been restricted:</p>
<p>
Email : _payer_email_<BR/>
</p>

<p>We will never remove your data from our database, however, when you let your account expire we'll no longer
be keeping your reports up to date. If this was an accident, hurry and reinstate your account so that we can begin recording 
data for you again.</p>

<p>If you have any questions or concerns, please reply to this email or visit <a href="http://www.jonathonbyrd.com/">http://www.jonathonbyrd.com/</a></p>