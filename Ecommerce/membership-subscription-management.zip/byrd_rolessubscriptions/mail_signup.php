<h3>Thank you for your Subscription to Jonathonbyrd.com</h3>
<p>We've created this account for you:</p>
<p>
Username : _user_name_<BR/>
Password : _password_<BR/>
Email : _payer_email_<BR/>
</p>

<p>You may change all these credentials once you log into the system, except the email address.
The email is used to tie your account to your paypal subscription.</p>

<p>Here's the link to login to the Members Only area, just scroll to the bottom of any page and use the login form.
Once you've completed this step, the login will be hidden and your Members Directory will be showing. <a href="http://www.jonathonbyrd.com/">http://www.jonathonbyrd.com/</a></p>