<tr>
	<td colspan="2">
		<br />
		<hr />
		<br />
	</td>
</tr>