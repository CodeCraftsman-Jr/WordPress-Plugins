﻿=== Free Quotation ===
Contributors: kris_IV
Donate link: http://my-motivator.pl/free-quotation-kris_iv/
Tags: quotation, quotations, quotes, random, random quotes, wikiquote, wiki, quote, quot., citation, cytaty, widget, display,widgets
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 3.1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Do you need display quotes or tips on your page? Free Quotation give you posibility to use CSV files with quotation, Wiciquotes or add quote manually one by one.

== Description ==

If you need a quotation or tips extension (plugin) to your WordPress site you find the best idea! This plugin give you full customization to display a lot of important information. You can use Free Quotation not only to display quotes, but also tips or something else. Open your imagination. If you need something additional what can extend this widget - write to me, and give me few hours :-)

The general idea give you possibility to use widgets (not only one - you can use a lot of widgets). Every one widget can display different group of information, and every one is customizable. It is your choice which information you display.

If you think about quotation - this plugin is perfect for it :-) You can add many quotes and decide how often they should be change. For example - you can display tips by day, by weeks, by weekday or use static quotation.

If you don't have enough time to prepare your own quotation database, you can use Wikiquote (Wikicytaty or other supported version of free quotation systems). The algorithm will display quotation for you. If you need algorithm for specific quotation website in your language which is not supported by this plugin - write to me ;-)

What is the best in this plugin? You can use your own quotation list from CSV or add it manually. The first system is automatic, but the second is very easy and intuitive. The calendar and table help you to edit your quotation, or change the day to display.

Finally - the last advantage of this plugin: IS FREE and it will be free for the end of World :-)

The list of supported quotation systems (if you need more, pleas write to me):

* Wikiquote EN (http://en.wikiquote.org/wiki/Main_Page - Quote of the day)
* Wikiquote ES (http://es.wikiquote.org/wiki/Portada - Cita del día)
* Wikiquote DE (http://de.wikiquote.org/wiki/Hauptseite - Zitat der Woche)
* Wikicytaty PL (http://pl.wikiquote.org/wiki/Strona_g%C5%82%C3%B3wna - Cytat dnia)
* Викицитатник RU (http://ru.wikiquote.org/wiki/Заглавная_страница - Избранная цитата)

If you want use all time your motto, you can use option "Use one standard quotation" and define this Motto in your 'FQ settings' page.

Now display quotations and tips is very easy. If you like this project - pleas give me stars. It's very nice to see this grades :)

== Installation ==

To install it automaticly:

1. Click 'Install Now'.
2. Click Activate the plugin

To install it part-manually:

1. Download "Free-Quotation-by-KRIS_IV.zip" from WordPress repository.
2. Go to 'Plugins'.
3. Go to 'Add new'.
4. Chose 'Upload'.
5. Find "Free-Quotation-by-KRIS_IV.zip" on your computer and click 'Install Now'.

To install it manually: 

1. Download "Free-Quotation-by-KRIS_IV.zip" from WordPress repository.
2. Unpack it.
3. Upload "Free-Quotation-by-KRIS_IV" folder to the `/wp-content/plugins/` directory by FTP client (f.ex. FileZilla).
4. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= After updating I can't add new quotation, and I see empty filed. What can I do? =
Pleas deactivate and activate this plugin. Everything should work OK after this operation. It's necessary to do it one times after updating process.

= How can I upload CSV file and how prepare it? =
Whole instruction is available in plugin "Add CSV" page. You have there some examples that help you prepare good CSV file for this plugin.

= How can I change display style? =
The style you can change exactly in style.css in your them. The name of style that this plugin use to display information is: .Free_Quotation_quotation{} and .Free_Quotation_author {}.

= My quotation doesn't appear on my page. Why? =
You should add widget to display quotation. Go to 'Appearance' -> 'Widgets' and drag the 'Free Quotation widget' in right place.

= Can I use Free Quotation in few place on my website? =
Of course you can. You should only locate few widgets in your them, how I instruct you.

= Which language is support in automatic quotation system? =
In automatic quotation systems this plugin support: English, Spanish, German, Polish and Russian language. I will support more language in next update.

= Can I use automatic quotation systems only when I don't have my quotation on this day? =
Of course. This plugin is highly customizable. You can use it in the way that you want. You should only chose right settings in 'FQ settings' page.

= Can I suggest an feature for the plugin? =
Next time: Of course:) Visit <a href="http://my-motivator.pl/free-quotation-kris_iv/">Free Quotation Home Page</a> and leave coments.

== Screenshots ==

1. Plugin settings page
2. Free Quotation widget should be located in widget area
3. This panel help you add new quotation manually (you can use also CSV and add it by special page on the left bar)

== Changelog ==

= 3.1.6 =
* Compatible with WordPress 4.1.1 

= 3.1.5 =
* Compatible with WordPress 4.1.0 

= 3.1.4 =
* CSS editor - now you can declare class or header value instead prepare own CSS style

= 3.1.3 =
* CSS editor - add new option for header, body and signature

= 3.1.2 =
* CSS quotation editor (improve)

= 3.1.1 =
* BETA Ajax tag selector widget - protect empty db
* BETA Ajax tag selector widget - add visual editor
* FIX - remove quotation, remove tag for this quotes

= 3.1.0 =
* Add BETA Ajax widget - user can choose quotation by tag
* Rebuild displayer option
* Add Signature line height option

= 3.0.2 =
* Fix small bug (problem with AddPage on some WP instance)
* Add margin-bottom to Quotation Displayer

= 3.0.1 =
* Fix small bug (db)

= 3.0.0 =
* Add tag support
* Reorganization of widget customization
* Add new filed - birth date, death date, additional notes
* Finally improve database (100% in accordance with WordPress regulation)
* Rebuild import/export CSV mechanism
* Rebuild add new quotation area<

= 2.3.3 =
* Fix a bug

= 2.3.2 =
* Compatible with php 5.5
* Fix - problem with stripslashes();

= 2.3.1 =
* Compatible with WordPress 4.0

= 2.3.0 =
* Fix internal problem (crash with Official StatCounter Plugin) - all settings will be restore to default 

= 2.2.3 =
* Fix bug with random quotation display

= 2.2.2 =
* New text align option for: title, quotation and signature (left/center/right)
* You can use other sign for quotation (for example &ldquo; or &rdquo; sign)

= 2.2.1 =
* New random display option

= 2.2.0 =
* Now you get a dashboard widget to better control your Free Quotation

= 2.1.4 =
* Add information about lack of settings after installation

= 2.1.3 =
* Rebuild code to WordPress standards
* Rebuild CSV import/export function
* Change in installation file (build new database)
* Now it's possible to use two times the same quotation
* Quotation size is now 800 characters

= 2.1.2 =
* UX improvement in FQ settings area (label are clickable)
* Table of quotes in admin menu is now default sortable by date of display
* Now you can display all quotation in table (admin menu)

= 2.1.1 =
* Compatible with wordpress 3.9.1

= 2.1.0 =
* Add export to CSV file function to backup or edit your quotation collection
* Redesign CSV import structure
* Changed CSV file construction
* Fix error with Wikiquote when it's impossible to find author or quotation
* Correct english Wikiquote (problem with author after last week update)
* Improve polish Wikicytaty algorithm

= 2.0.10 =
* Fix problem with quotation mark

= 2.0.9 =
* Compatible with WordPress 3.9

= 2.0.8 =
* Fix Wikiquote

= 2.0.7 =
* Fix Wikiquote

= 2.0.6 =
* Now FreeQuotation remember last use settings tab (General or Visual)
* Put into memory your preferences to CSV instruction

= 2.0.5 =
* Settings menu redesign (visual and funkcional)

= 2.0.4 =
* Now you can style your widget quotation (global to all widgets)

= 2.0.3 =
* Add new quotation to the group from selected box

= 2.0.2 =
* Widget configuration is easier (now you can choose the category instead of writing it)

= 2.0.1 =
* Small funcional improvements

= 2.0.0 =
* Add group for quotation
* Now you can add title to widget (Free Quotation use headers &lt;h3&gt; to display it)
* Rebuild widget area
* Possibility to use many widgets with different value
* Hidden week number if you doesn't use this option
* Now you can display quotation for specific day of week
* Improve data selection (now first day of week is Monday)

= 1.5.1-1.5.5 =
* Fix database update bug

= 1.5.0 =
* Now you can display quotation by number of week
* Rebuild a database

= 1.4.2 =
* Add option: select all to delete
* Improve in CSS

= 1.4.1 =
* Improve option start/end quotation with special characters

= 1.4.0 =
* Add posibility to delete more than one quotation per one times

= 1.3.3 =
* Now it's demand to accept edit data (for safety)

= 1.3.2 =
* Now it's demand to accept delete data (for safety)

= 1.3.1 =
* Fix data problem !IMPORTANT!

= 1.3.0 =
* Now is available edition for all of quotes. You can change display date, quotation text or author of quotation

= 1.2.2 =
* Fix CSS in table
* Reorganization of code in few places

= 1.2.1 =
* Fix many small issue and improve stable

= 1.2.0 =
* Improve navigation (on plugin list)
* Better organisation in code

= 1.1.1 =
* Compability with WordPress 3.8.0
* Make plugin lighter

= 1.1.0 =
* Add new quotation change location (go to Free Quotation)
* Table have now new feature. Now:
* Table is sortable
* Table is filterable
* Table have pagination
* User can choose how many rows is display
* Some small improvement (Wikiquotes mechanism, layout)

= 1.0 =
* This is initial relase of this plugin.