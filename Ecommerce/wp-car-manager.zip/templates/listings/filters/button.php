<div class="wpcm-filter wpcm-filter-button">
	<input type="submit" value="<?php _e( 'Show Results', 'wp-car-manager' ); ?>"/>
</div>