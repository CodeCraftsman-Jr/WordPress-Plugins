<?php

date_default_timezone_set("CET");

require_once dirname(__FILE__) . "/../src/Mollie/API/Autoloader.php";
