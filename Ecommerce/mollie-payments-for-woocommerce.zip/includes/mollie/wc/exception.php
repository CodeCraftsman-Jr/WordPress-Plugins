<?php
class Mollie_WC_Exception extends Exception {}
