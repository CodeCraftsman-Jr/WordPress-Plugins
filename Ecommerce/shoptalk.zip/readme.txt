=== Shop Talk ===
Contributors: Dhanu Gupta
Tags: shopping stories,shopping expert advice,money-saving insite,shopping tips, aol shopping,shopping topics
Requires at least: 3.0
Tested up to: 3.1
Stable tag: 1.0

== Description ==

A customizable widget that displays the latest topics in shopping. Stories include: expert advice, money-saving insight and helpful shopping tips from AOL Shopping. It can be integrated anywhere on the blog. This widget shows the three latest stories published with the same topical tag on AOL's Shopping network: http://shopping.aol.com/articles. 
This is a quick and easy solution for all those wanting to keep up with and to share the latest, most relevant topics in the world of shopping today.

*Feature List*

* customizable widget
* displays a user-defined number of links
* title shortening

== Screenshots ==

1. This screen shot description corresponds to screenshot.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `screenshot.png` (or jpg, jpeg, gif)

== Installation ==

*Could not be simpler*
1. Extract `shoptalk.zip`.
2. Upload the `shoptalk`-folder to your `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.
