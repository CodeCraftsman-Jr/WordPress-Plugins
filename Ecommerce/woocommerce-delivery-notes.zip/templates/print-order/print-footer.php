<?php
/**
 * Print order footer
 *
 * @package WooCommerce Print Invoice & Delivery Note/Templates
 */

if ( !defined( 'ABSPATH' ) ) exit;
?>

		</div><!-- #page -->
		
		<?php
			// wcdn_head hook
			do_action( 'wcdn_after_page' );
		?>
		
	</div><!-- #container -->

</body>

</html>