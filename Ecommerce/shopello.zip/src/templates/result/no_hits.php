<h3><em><?php _e('We did not find any results for this search.', 'shopello'); ?></em></h3>
