<?php

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    MBJ_Paypal_Digital_Goods_Payment_Gateway_For_WooCommerce
 * @subpackage MBJ_Paypal_Digital_Goods_Payment_Gateway_For_WooCommerce/includes
 * @author     Your Name <email@example.com>
 */
class MBJ_Paypal_Digital_Goods_Payment_Gateway_For_WooCommerce_Deactivator {

    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since    1.0.0
     */
    public static function deactivate() {
        
    }

}
