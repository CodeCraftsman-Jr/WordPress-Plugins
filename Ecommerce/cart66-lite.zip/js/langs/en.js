// US lang variables
tinyMCE.addI18n('en.cart66',{
cart66_desc : "Add Cart66 Product",
cart66_title : "Cart66",
cart66_button_desc: "Add Cart66 Product"
});
