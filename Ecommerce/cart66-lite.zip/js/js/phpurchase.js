    function Cancel_Button_onclick()
    {
    	    tinyMCEPopup.close();
    	    return false;
    }