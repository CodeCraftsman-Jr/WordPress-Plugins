=== WooCommerce No Order Alert ===
Plugin Name: WooCommerce No Order Alert
Plugin URI: http://multidots.com/
Description: User will set custom time duration to send the emails related to last placed order to admin.
Author: Multidots
Author URI: http://multidots.com/
Contributors: dots
Version: 1.0.0
Stable tag: 1.0
Tags: no order notification email, woocommerce no order alert,woocommerce,order alert
Requires at least: 3.9
Tested up to: 4.1
Donate link: 
Copyright: (c) 2014-2015 Multidots Solutions PVT LTD (info@multidots.com)
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Plugin is used to get no order alert as email to your administrator email or any other added email accounts.

== Description ==

Plugin is used to get no order alert as email to your administrator email or any other added email accounts by regular intervals.

== Installation ==

1. Upload the entire `no-order-alert` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How to set the notification cron? =

It is very simple to configure the plugin. just activate the plugin and go to admin side and go to settings column and select the Order Reports menu and then you can see a url in the first table, now copy that url and add the url in your servers cron job.

= Is this plugin competible to newest version of the WooCommerce? =

Yes, this version of the plugin is supported and tested upto WooCommerce 2.2. We are ready to give you regular updates on regular WooCommerce update.

== Screenshots ==

1. This screen shot describe the admin side interface.

== Changelog ==

= 1.0 =
* This is the first version of the plugin.

== Upgrade Notice ==

= 1.0 =
This is the first version of the plugin so you don't need any information about upgrade.
