=== Kostenlose Kreditkarten-Anbieter ===
Contributors: Michael Mueller
Tags: post, posts, page, plugin, creditcard, free
Requires at least: 2.9
Tested up to: 3.1.2
Stable tag: 1.01

Kostenlose Kreditkarten-Anbieter

== Description ==

Mit diesem Plugin koennen Sie einfach eine Tabelle mit den besten kostenlosen Kreditkarten-Anbietern in Seiten oder Artikeln des Blogs anzeigen lassen.

Support: [http://www.kreditkarten-1a.de/](http://www.kreditkarten-1a.de/)

== Installation ==

1. Extract the zip-file.
2. Upload the folder 'kostenlose-kreditkarten-anbieter' to the directory '/wp-content/plugins/' in your blog.
3. Activate the plugin within the  'Plugins' menu in yout Blog.
4. Add this shortcode to your post or page: <!-- kostenlosekreditkarten -->

== Changelog ==

= 1.0 =
Initial release 2011-04-27

= 1.01 =
Minor Updates
