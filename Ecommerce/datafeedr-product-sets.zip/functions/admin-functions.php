<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Load HTML functions.
 */
require_once( DFRPS_PATH . 'functions/html.php' );

/**
 * Load AJAX related functions.
 */
require_once( DFRPS_PATH . 'functions/ajax.php' );