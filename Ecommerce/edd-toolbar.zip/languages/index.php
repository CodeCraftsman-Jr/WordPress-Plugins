<?php
/**
 * Do not put custom translations here. They will be deleted on 'Easy Digital Downloads Toolbar' updates!
 *
 * Keep custom 'Easy Digital Downloads Toolbar' translations in '/wp-content/languages/edd-toolbar/'
 */
