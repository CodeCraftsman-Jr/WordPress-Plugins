<?php

define('WC_SEQUENTIAL_ORDER_NUMBERS_PLUGIN_TOKEN', 'wc-Sequential-Order-Numbers');

define('WC_SEQUENTIAL_ORDER_NUMBERS_TEXT_DOMAIN', 'Sequential_Order_Numbers');

define('WC_SEQUENTIAL_ORDER_NUMBERS_PLUGIN_VERSION', '1.0.0');
?>