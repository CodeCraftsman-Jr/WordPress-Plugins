<?php
class AmazonAutoLinks_ListExtensions extends AmazonAutoLinks_ListExtensions_{}