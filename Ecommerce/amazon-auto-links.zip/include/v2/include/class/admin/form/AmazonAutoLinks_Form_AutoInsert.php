<?php
class AmazonAutoLinks_Form_AutoInsert extends AmazonAutoLinks_Form_AutoInsert_ {}