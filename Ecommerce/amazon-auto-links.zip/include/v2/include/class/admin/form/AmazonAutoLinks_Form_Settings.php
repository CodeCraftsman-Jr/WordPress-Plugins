<?php
class AmazonAutoLinks_Form_Settings extends AmazonAutoLinks_Form_Settings_ {}