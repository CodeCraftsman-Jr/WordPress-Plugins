<?php
/**
 * Provides the definitions of form fields.
 * 
 * @since           3  
 */
class AmazonAutoLinks_FormFields_SimilarityLookupUnit_Advanced extends AmazonAutoLinks_FormFields_ItemLookupUnit_Advanced {}