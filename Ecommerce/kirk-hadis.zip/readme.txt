=== Plugin Name ===
Tags: kırk, 40, hadis, islam, din, diyanet, müslüman

Bu eklenti, Türkiye Cumhuriyeti Diyanet İşleri Başkanlığı resmi internet sitesinden alınan 40 hadisi, rastgele bir şekilde ziyaretçilerinize göstermektedir.

== Description ==

Peygamber Efendimiz Hz. Muhammed Mustafa (S.A.V.) farklı rivayetlerde bizlere şöyle buyuruyor;
Kırk hadis bırakarak vefat eden Cennette arkadaşımdır. (Deylemi),
Allahü teâlânın rızası için, helâli ve haramı açıklayan, kırk hadisi ümmetime bildiren, âlim olarak haşr olur. (Ebu Nuaym),
Ümmetimin din işlerinde faydalı kırk hadis ezberleyen, âlimlerle haşr olur. (Taberani),
Allahü teâlânın kendisine mağfiret etmesi ümidi ile, benden kırk hadis yazana, Allahü teâlâ rahmet edip şehid mertebesi verir. (İbni Cevzi),
Ümmetime iletmek üzere kırk hadis ezberleyene şefaat ederim. (İbni Adiy).

Bu eklenti, Türkiye Cumhuriyeti Diyanet İşleri Başkanlığı resmi internet sitesinden alınan 40 hadisi, rastgele bir şekilde ziyaretçilerinize göstermektedir.

== Installation ==

1. kirk-hadis klasörünü wp-content/plugins klasörüne yükleyiniz.
2. Eklentiler sayfasından eklentiyi etkinleştiriniz.
3. Görünüm/Bileşenler sayfasından Kırk Hadis bileşenini istediğiniz bir alana sürükleyip bırakın.

== Screenshots ==

1. Bileşen, Görünüm/Bileşenler sayfasına yerleşiyor.
2. Bileşenin sitede görünümü.

== Changelog ==

= 1.0 - 15.08.2010 =
* Kırk Hadis yayınlandı.