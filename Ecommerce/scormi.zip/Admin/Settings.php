<?php 
namespace Scormi\Admin;

class Settings extends SettingsHtml{};
