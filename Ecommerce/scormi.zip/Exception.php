<?php
namespace Scormi;

class Exception extends \Exception{};
