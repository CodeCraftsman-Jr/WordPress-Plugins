=== WooCommerce Duplicate Billing Address ===
Contributors: tabboy
Donate link: http://eversionsystems.com
Tags: woocommerce,billing,shipping,address,copy,duplicate
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.12
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a checkbox to the user profile edit screen in the dashboard to enable the duplicating of the WooCommerce billing address to shipping address.

== Description ==

Add a checkbox to the user profile edit screen in the dashboard to enable the duplicating of the WooCommere billing address to shipping address.


== Installation ==

1. Upload the entire `woocommerce-duplicate-billing-address` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

None

== Screenshots ==

1. This is where the checkbox for duplicating the address is located

== Changelog ==

= 1.0 =
* Initial build

= 1.1 =
* Added support for the new predictive text combobox for country and state selection

= 1.11 =
* Added a check to only display duplicate combobox is WooCommerce plugin is active

= 1.12 =
* Missing include to enable call to function is_plugin_active in dashboard