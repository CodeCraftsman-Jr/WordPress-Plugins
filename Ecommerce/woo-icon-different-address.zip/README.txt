=== Woo icon different address ===

Contributors: Agence Best Of Site
Tags: icon order, woocommerce, products, themes, e-commerce, shop, icon view order
Requires at least: 3.8.1
Tested up to: 4.1.1
Tested with Woocommerce : 2.3.5
Stable tag: 2.2.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ajoute une icône dans le backoffice des commandes woocommerce.

== Description ==

Woo Icon different address, ajoute une icône dans le backoffice des commandes woocommerce. Voyez en un coup d'oeil si l'adresse de livraison est différente !
Woo Icon different address, add an icon in the backoffice of WooCommerce orders. See with this icon if the delivery address is different !

== Installation ==
Installez le plugin et cliquez sur activer. 

1. Dezipez le fichier
2. Envoyez le fichier dans wp-content/plugins/
3. Activez le plugin sur la page des extensions

== Screenshots ==

1. Adresse de livraison différente

== Changelog ==

= Version 1 =
* Mise en ligne
