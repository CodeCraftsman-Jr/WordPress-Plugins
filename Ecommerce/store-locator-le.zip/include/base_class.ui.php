<?php
// TODO: remove this file once all add-ons have been updated to reference base_class.userinterface.php instead. (ELM,PRO,SME,UML)
if (! class_exists('SLP_BaseClass_UI')) {
    require_once('base_class.userinterface.php');
}