=== Shopp Wholesale ===
Contributors: tysonlt
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=BJQ6ZNN4JVAZL
Tags: shopp,wholesale
Requires at least: 3.0.0
Tested up to: 3.0.5
Stable tag: 0.7

Comprehensive Wholesale System for Shopp (BETA RELEASE).

== Description ==

This is a BETA release of the Shopp Wholesale system.

Shopp Wholesale is a comprehensive wholesale management system for Shopp. It allows the administrator 
to enable wholesale prices for individual items and variations, and updates all prices to wholesale 
prices when a wholesale customer is logged in. 

Currently this plugin is in BETA. All of the functionality is stable, but product add-ons are not currently
supported. Attempts to apply wholesale pricing to add-ons will product incorrect prices.

== Installation ==

1. Upload the contents of this zip file to your `/wp-content/plugins/' folder, or use the built-in Plugin upload tool.
1. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= How do I make a product wholesale? =

Each product priceline has a wholesale price field, next to the normal price field.  

== Changelog ==

= 0.7 =
* BETA release