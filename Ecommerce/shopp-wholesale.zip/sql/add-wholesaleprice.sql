alter table {prefix}shopp_price add wholesaleprice float(20,6) default 0
