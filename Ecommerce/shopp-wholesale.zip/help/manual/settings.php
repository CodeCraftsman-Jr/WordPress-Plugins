<h1>Shopp Wholesale Manual</h1>

<h3>General Settings</h3>