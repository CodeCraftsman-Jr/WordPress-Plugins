Two files are required for each admin screen:

* quick-help-<menu_slug>.php
This is the help text that appears when the user drops down the 'help' tab on the admin screen.

* manual-page-<menu_slug>.php
This is a full manual page. It can be in any layout. A link to this page is automatically
included after the quick help text.