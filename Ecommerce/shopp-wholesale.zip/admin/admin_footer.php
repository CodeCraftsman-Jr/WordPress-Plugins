<?php
		$Controller->printFormButtons();
?>

	</form>
</div>