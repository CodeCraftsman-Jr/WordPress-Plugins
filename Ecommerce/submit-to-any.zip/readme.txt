=== Submit to Any ===
Contributors: Ronnie268
Donate link: http://www.jjtcomputing.co.uk/blog/donate/
Tags: bookmark, social bookmarking, stumble, technorati, delicious, digg, rss, traffic
Requires at least: 2.0
Tested up to: 2.7.1
Stable tag: 3.1

This plugin is for bookmarking your posts into many popular bookmarking sites and giving readers the chance to subscribe to your feed.

== Description ==

This plugin is for bookmarking your posts into StumbleUpon, Slahdot, Technorati, Digg and Del.icio.us. You have to do nothing but just activate the plugin. It automatically add the bookmarking options just below to your posts.
It also has a stylish button for subscribing to your RSS feed. Pretty visual interface also included!

* Traffic : This plugin increses your website traffic
* Looks: Transparent plugin will give your blog a nice look
* Large, Friendly Icons: Since the bookmarking is implemented with huge images, the chances for bookmarking are very high

**For Example and Details Visit :** [http://www.jjtcomputing.co.uk/blog/](http://www.jjtcomputing.co.uk/blog/ "Examples and Details")

**My Technical Blog is :** [http://www.jjtcomputing.co.uk/blog](http://www.jjtcomputing.co.uk/blog/ "My Technical Blog")

== Installation ==

1. Unzip the files 
1. Upload submit-to-any directory (containing submit-to-any.php file with image files) to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

OR

1. Locate it using the Plugin browser function
1. Click Install
1. On the "Success!" screen, click Activate.

== Frequently Asked Questions ==

= Should i edit any files? =

No, just activate the plugin.

= Images are not displaying? =

Make sure the path to main plugin file is  /wp-content/plugins/submit-to-any/submit-to-any.php.

== Screenshots ==

1. The plugin in use at jonathanellse.co.cc.

== Other Notes ==

If you have any queires / complaints regarding this plugin, please feel free to mail me at webmaster@jjtcomputing.co.uk. Thank you

See my blog for  updates [http://www.jjtcomputing.co.uk/blog/](http://www.jjtcomputing.co.uk/blog/ "Blog") .

For general support, please consider posting on [http://www.jjtforum.co.cc/](http://www.jjtforum.co.cc/ "Blog"), so everyone can benefit from your answer.