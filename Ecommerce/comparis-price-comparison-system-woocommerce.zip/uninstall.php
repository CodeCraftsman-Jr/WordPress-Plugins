<?php
/**
 * Comparis Uninstall
 *
 * Uninstalling Comparis plugin
 *
 * @author 		UouApps
 * @category 	Core
 * @package 	Comparis/Uninstaller
 * @version     1.0.0
 */
if( ! defined( 'WP_UNINSTALL_PLUGIN' ) )
	exit();