=== Gratisfaction- Social Contests Referral Loyalty  Rewards Program for WooCommerce===
Contributors: Apps Mav
Tags: Loyalty program, facebook, twitter, instagram, pinterest, youtube, twitter contest, twitter competition,twitter marketing, twitter promotion, increase twitter followers,get twitter followers, gain twitter followers,more twitter followers, build twitter followers, attract twitter followers, twitter referrals, twitter business, instagram contest, twitter competition,twitter marketing, twitter promotion, increase twitter followers,get twitter followers, gain twitter followers,more twitter followers, build twitter followers, attract twitter followers, twitter referrals, twitter business, instagram contest, instagram competition, instagram marketing, instagram promotion, increase instagram followers,get instagram followers, gain instagram followers, more instagram followers, build instagram followers, attract instagram followers, instagram referrals, instagram business, youtube contest, youtube competition, youtube marketing, youtube promotion, increase youtube followers,get youtube followers, gain youtube followers, more youtube followers, build youtube followers, attract youtube followers, youtube referrals, youtube business, pinterest contest,  pinterest competition, pinterest marketing,  pinterest promotion, increase pinterest followers,get pinterest followers, gain pinterest followers, more pinterest followers, build pinterest followers, attract pinterest followers, pinterest referrals, pinterest business, facebook contest,  facebook competition, facebook marketing,  facebook promotion, increase facebook followers,get facebook followers, gain facebook followers, more facebook followers, build facebook followers, attract facebook followers, facebook referrals, facebook business, facebook likes, facebook fans, facebook sweepstakes, facebook giveaways, promotion, promotions, social contests, contest, contests, campaigns, campaign, social, social campaigns, social campaign, social promotion, social promotions, photo, photos, deal, offer, sale, sales, deals, promote, marketing, sweepstakes, social, pinterest, ecommerce, e-commerce, facebook promotion, facebook contest, facebook campaign, facebook store, store stores facebook stores, facebook offer, embed, facebook social offer, facebook deals, facebook deal, photo contests, group deals, group, offers, social offers, instagram contests, photo contests, Video Contest, video contests, admin, dashboard, widget, widgets, plugins, music contest, music contests, sweepstake, sweepstakes, sidebar, sidebars referrals, bonus, manage, simple, integration, multiple platforms, easy, quick, loyalty, rewards, woocommerce, engagement, gamification, gratisfaction, reward, reward program, referrals, referral, referral marketing, referral platform,grow sales, subscriptions, leads, sales, grow sales, increase sales, traffic, increase traffic, get leads, get more leads, commerce, e-commerce, ecommerce, sell, shop, shopping, store, widgets, woothemes, woo themes, wordpress ecommerce, woo, woo commerce, woo extensions, woo themes, woo commerce themes, woo commerce extensions, woo commerce plugins, woo plugins, woo developers, woocommerce themes, woocommerce plugins, woocommerce, extensions, woocommerce developers, embed youtube, embedding youtube, plugin, responsive, video, video plugin, wordpress youtube embed, youtube, YouTube API, Youtube channel, youtube embed, youtube galleries, youtube gallery, youtube impressions, youtube player, youtube plugin, email newsletter, floating social media, newsletter, sharing, social media, social media button, social media buttons, social media icon, Social Media Icons, Social Media Pop-Up, social media sharing, Social Media Widget, socialmedia, subscription icons, social marketing, free, free plugin, free extension, wp, traffic, Visit, visitor, visitors, visits,  
Donate link: https://appsmav.com
Requires at least: 3.0.1
Tested up to:  4.3.0
Stable tag: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

All-in-One Loyalty+Social Contests+Referral Marketing WooCommerce

== Description ==
### Use Gratisfaction to:

*   Get Traffic, Leads & Sales
*   Increase Engagement
*   Get Repeat Purchases & Increase Customer Lifetime Value
*   Get Referrals

### Gratisfaction combines gamification & social media actions to help you:

*   Run Viral Social Contests, Sweepstakes & Giveaways
*   Reward Customers for Social Sharing
*   Create Loyalty Programs to encourage Repeat Purchases & Increase Lifetime Value

Get **FREE FOREVER** Version now [https://appsmav.com/gratisfaction.php](https://appsmav.com/gratisfaction.php
)

** *The free forever version includes all features.* **

*   Easy to setup & manage
*   No contract. Cancel anytime
*   Setup unlimited campaigns
*   Create beautiful contests, referral & loyalty campaigns
*   All plans come with full range of features included

### Frequently Asked Questions

*   Is Gratisfaction free?

Gratisfaction is absolutely free for upto 200 customers. This means that you can use all features, run any number of campaigns and it will show you upto 200 leads/customers absolutely free.

*   What features are available in the free version?

The short answer is all features. You can run any number of campaigns, get unrestricted use to all features, run loyalty programs, contests, etc.

Gratsifaction is free for upto 200 customers. You can learn more about our plans & pricing at https://www.appsmav.com/gratisfaction.php

*   What kind of support do I get?

Gratisfaction is very easy and fast to set up. If you ever need assistance, we are here to support you. For any pre-sales or product inquiries, send us an email to sales@appsmav.com . Existing customers, please send email to support@appsmav.com

*   I have another question, what do I do?

Contact us Anytime! For any pre-sales or product inquiries, send us an email to sales@appsmav.com .


== Installation ==
1. Upload "gratisfaction-all-in-one-loyalty-contests-referral-program-for-woocommerce" to the "/wp-content/plugins/" directory.
1. Activate the plugin through the "Plugins" menu in WordPress.


== Frequently Asked Questions ==
= How can I connect to Gratisfaction with WooCommerce ?
Signup for the Gratisfaction app from https://appsmav.com, to obtain your GR App-ID and the SECRET-KEY. 


= Is Gratisfaction free?
Gratisfaction is aboslutely free for upto 200 customers. This means that you can use all features, run any number of campaigns and it will show you upto 200 leads/customers absolutely free.


= What features are available in the free version?
Short answer is all features. you can run any number of campaigns, get unrestricted use to all features, run loyalty programs, etc. 


= How much does it cost?
Gratsifaction is free for upto 200 customers. You can learn more about our pricing at https://www.appsmav.com/gratisfaction.php

= What kind of support do I get?
Gratisfaction is very easy and fast to set up. If you ever need assistance, we are here to support you. For any pre-sales or product inquiries, send us an email to sales@appsmav.com . Existing customers, please send email to support@appsmav.com 

= I have another question, what do I do?
Contact us Anytime! For any pre-sales or product inquiries, send us an email to sales@appsmav.com . Customers, please send email to support@appsmav.com 



== Screenshots ==
1. The screenshot description corresponds to screenshot-1.(png|jpg|jpeg|gif).


== Changelog ==
= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.2 =
This version have register shop feature with GR site.

== Upgrade Notice ==
= 0.3 =
This version have auto register shop, campaign and free 0-200 package setup.

== Upgrade Notice ==
= 0.4 =
This version have auto register shop, with iframe version and new api.

== Upgrade Notice ==
= 0.5 =
This version have issue fixed while registration validations in new api.