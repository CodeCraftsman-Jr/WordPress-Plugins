=== ASSURINTYglobal for WooCommerce ===
Contributors: ASSURINTYglobal
Donate link: http://assurintyglobal.com/
Tags: woocommerce, ecommerce, warranty, protection plan, extended warranty
Requires at least: 3.6
Tested up to: 4.1.1
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Upsell fully insured extended warranties and service plans with ASSURINTYglobal for WP/WooCommerce.

== Description ==

The largest retailers including Apple, Amazon, eBay, Best Buy, Costco, Sears, Home Depot etc. generate significant high margin revenue from upselling extended warranties and provide a low cost value add for their customers.  ASSURINTYglobal is leveling the playing field for independent merchants with their fully integrated solution for eCommerce.  Generate 30% margins with no upfront or inventory expense by offering your customers a fully insured plan with their warrantyable purchase.  Ideal for ELECTRONICS, APPLIANCES, GADGETS, POWER TOOLS, FURNITURE, JEWELRY, WATCHES and EYEWEAR.

The offer will appear only in the cart so it’s a soft sell and you collect the revenue from the customer as part of the transaction – its absolutely seamless.  The plans will automatically be registered and you will be billed at the end of the month only for warranties sold.

All of our plans are individually and fully insured by insurers rated EXCELLENT by AM BEST so there is no risk of us falling down on a customer claim.  Feel free to contact us – info@assurintyglobal.com for more information or download the extension today to capture high margin incremental revenue on existing sales.


Please note this service is currently available only in the USA.


== Installation ==

1. Upload the folder `assurinty-global-woocommerce` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Visit WooCommerce > Warranty to apply for the ASSURINTYglobal service

== Frequently Asked Questions ==

None.

== Upgrade Notice ==

None.

== Screenshots ==

1. Keep the look and feel of you shopping cart without additional programming.
2. Automatically offer extended service plans in your customers’ shipping carts.
3. Customers can choose to add warranties to their cart on the cart page.

== Changelog ==

= 1.0.0 =
* Initial release
