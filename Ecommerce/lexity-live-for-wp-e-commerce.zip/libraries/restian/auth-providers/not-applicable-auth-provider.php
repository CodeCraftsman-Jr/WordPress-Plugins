<?php

/**
 * Inherits everything from the base class
 */
class RESTian_Not_Applicable_Provider extends RESTian_Auth_Provider_Base {
}
