RESTian
=======

RESTian is a base class library to simplify building RESTful/Web API clients in PHP.  RESTian's design is optimized for use in WordPress but is designed to in PHP standalone.
