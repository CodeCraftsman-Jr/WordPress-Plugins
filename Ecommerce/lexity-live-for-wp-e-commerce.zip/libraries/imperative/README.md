imperative
==========

The Missing require_library() for Embedded Libraries within WordPress Plugins and Themes.
