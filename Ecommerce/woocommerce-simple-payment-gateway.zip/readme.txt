﻿=== WooCommerce Simple Payment Gateway ===
Contributors: gfxser
Donate link: http://webdarom.ru/
Tags: woocommerce, payment, gateway, shipping,  method, cash
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A WooCommerce Extension that adds the payment gateway "Simple Payment Gateway"

== Description ==

This extension will add payment gateway "Simple Payment Gateway" in your WooCommerce store.
Option for selecting shipping methods

= Installation =

1. Upload `Simple Payment Gateway` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Screenshots ==

1. Simple Payment Gateway settings page

== Changelog ==

= 1.0.3 =
* Compability with Wordpress v4.2.2

= 1.0.2 =
* Compability with Wordpress v4.1

= 1.0.1 =
* Links fixed

= 1.0.0 =
* Initial release
