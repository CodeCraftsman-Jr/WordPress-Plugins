=== Hallo Destra ===
Contributors: papadestra
Donate link: http://papadestra.wordpress.com/
Tags: Papa Destra, comments, Yahoo, RSS, seo, plugin, wordpress, blogger, buzz, del.icio.us, deviantart, Digg, digital tunes, email, Etsy, Facebook, flickr, follow, follow me, foursquare, friendfeed, hyves, icons, iTunes, lastfm, linkedin, links, live365, meetup, merchant circle, myspace, orkut, picasa, ping, plancast, Reddit, rss, skype, slideshare, social, social media, soundcloud, stumbleupon, subscribe, tumblr, tungle, twitter, vimeo, wordpress, yelp, youtube, 3d, autoplay, buttons, effects, free carousel, free flash, menu, mirror, navigation, rotate, scroll, scroller, tooltip
Requires at least: 3.0.3
Tested up to: 3.0.3
Stable tag: 1.1

Hallo Destra add social media icons in the theme wherever you want to display. Simple and looks luxurious.

== Description ==
Simple code entered in the theme you are using, will feature some beautiful icon of social media for publicizing your website / blog. 
Carousel builds an animated images.Add shortcode to display animated images on a post / page.<br>

shortcode = <code>[gambar_carousel]</code> display animated images on a post / page

<b>For information and questions please: <br><br>
Papa Destra - **[http://papadestra.com/](http://papadestra.com/)**<br>
Facebook - **[http://id-id.facebook.com/people/Papa-Destra/1668887139](http://id-id.facebook.com/people/Papa-Destra/1668887139)**<br>
BEST Scripts - **[http://papa-destra.blogspot.com/](http://papa-destra.blogspot.com/)**<br>


== Installation ==

1. Upload Directory `hallo-destra` to the `/wp-content/plugins/` directory

2. Activate the plugin through the 'Plugins' menu in WordPress

3. A new menu will appear! hallo-destra

4. Enter the code in your theme: <br><code> <?php if ( function_exists('social_media_tampil') )  { social_media_tampil(); } ?> </code>

PERFECT!

== Screenshots ==
1. Scripts add.
2. Icon Previews.
3. Admin Views.
4. Previews Animated images.
5. Setting.
6. Verification Setting

== Changelog ==

= 1.1 =
Carousel builds an animated images. Social Media Icon with a blur animation (More special & light).Add shortcode to display animated images on a post / page. Support the shortcode on the widget. Site Verification Setting (Yahoo,google)


== CREDIT ==

* This plugin was developed by Papa Destra - http://papadestra.com/


== SUPPORT PROJECT ==

* Writers Of Remarkably Distinctive Stories - http://www.enoughmoney.com.au/
* COCAKIJO - http://cocakijo.wordpress.com/