TODO
----

* Add WP_UnitTestCase for the payment gateway
