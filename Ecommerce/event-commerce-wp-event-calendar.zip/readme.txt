=== EventCommerce WP Event Calendar ===
Contributors: wpproducts
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=solvercircle@gmail.com&item_name=Donation+for+wordpress_event_commerce
Tags: booking, event, event management, event ticket booking, event booking, ticket booking, doctors event, admin, administration, AJAX, event, availability, availability calendar, lawer event scheduling booking, Book, Booking calendar, booking form, booking system, booking engine, booking module, booking plugin, calendar, contact form, parties event registration,ticketing,event ticket booking,conference booking,online event registration booking calendar, online reservation, Reservation, reservation calendar, reservations, reservation plugin, event scheduling, event management, event planner, date blocker, jquery, management, meeting, Meeting event scheduling, Organizer, rent, Rental, reservation system, event calendar, event system, sponsor, to book, tutors event booking, summits event booking, singer event scheduling booking, php event booking system, php mysql event booking calendar, wordpress online event registration booking, wordpress event schedule reservation, Wordpress event ticket booking, wordpress event ticket booking script, gatherings event booking,appointment ticketing,photographer event scheduling booking registration, wp event calendar booking manager, wp  event calendar ticket reservation system, wp reservation script
Requires at least: 3.3.0
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


Provides an easy way to manage your event calendar booking and check availability in custom Calendar.

== Description ==

"EventCommerce WP Event Calendar" plugin will enable online Event Ticket Booking services for your site.
you can show and manage your event ticket Booking/any event(or something else).
You can manage the bookings (availability) on an ourly/custom time basis. event booking calendar page will be created automatically and to generate
calendar in frontend shortcode will be automatically copied. you can add/edit sponsors/venues/organizers or any event or delete bookings from admin to manage the full system.

> **Get more features for a small fee**
> [EventCommerce WP Responsive Event Calendar Pro](http://codecanyon.net/item/eventcommerce-wp-responsive-event-calendar-pro/10716644?ref=wpproducts) also comes with a premium paid version. Upgrade to [EventCommerce WP Responsive Event Calendar Pro](http://codecanyon.net/item/eventcommerce-wp-responsive-event-calendar-pro/10716644?ref=wpproducts) for exceptional features, including a detailed Integrated Payment Gateway, Customized Calendar view, Free Technical support and much more. [Checkout all the awesome pro features](http://codecanyon.net/item/eventcommerce-wp-responsive-event-calendar-pro/10716644?ref=wpproducts).
>


Your Customers will be able to:

	
= KEY BENEFITS: =
- very easy to install and configure. 
- Very flexible functionality. Fit to very wide range of business.
- All bookings and settings are stored in your DB. You don't need third party account(s).
- An easy to use Event Booking Admin Panel that displays Event bookings in Calendar Overview and lets you manage bookings.
- Built with jQuery, Ajax and other technologies.
- Easy to install and integrate into your site. because necessary post or page will be automatically created and shortcodes will be automatically copied to page.
	
= FEATURES: =
- PLUG-N-PLAY. Just activate it and start using. Post/page creation and shortcode insertion in post/page is automatic. And all necessary database table creation is automatic.
- Make event Registration ticket bookings in friendly booking interface - select the date(s) and time and fill form fields.
- Prevent of booking for already reserved event (no of ticket booking for a event which is exactly equal to total no of seat).
- RESPONSIVE event booking and availability Calendar to fit any device
- Add/Edit/Manage Event Booking from Admin Interface.
- Let users submit events from the frontend.
- Limit the number of bookings in an event.
- Filter Events by event Category.
- Cross Browser Support.
- Can set event image.
- Responsive Calendar Shortcode.
- Sandbox integration.  
- Insert Event Ticket Booking Calendar into any Post/Page using ShortCode [evntgen_sccalendar].
- Pretty modern administration interface.
- Pagination of the booking listing.
- You can fix any UI related issue by writing your custom css from admin option.
- Supports both am/pm time.
- Allows inserting the organizer, sponsors and venues for an event.
- Allows defining the product name at PayPal, the currency, tax,administrator email and the PayPal language in pro version.
- any kind of event, event registration and ticketing can be managed by this plugin.
- Colors customization - Event-Calendar Wordpress event commerce plugin lets you brand the event color so it would perfectly fit your website's colors and theme.
- Unlimited number of event, unlimited number of clients.
- venue, organizer, sponsor are unlimited and fully dynamic. so you can set according to your need.
- Multiple-currency support.
- Show events in the daily, weekly or monthly view.
- Easily add, edit or delete event in WP Admin.
- automatically page created and shortcode copied to page to generate calendar and payment process related pages. so its really easy to install and configure.
- event ticket registration from events calendar by a easily accessible popup.
- and much more coming soon...

= Additional Features Available with the Pro (paid) version only =
- Free Installation Service
- Unlimited Events Entries
- Integrated Payment Gateways
- Built in Shopping Cart Enabled
- Personalized Calendar User Interface
- Manage Booking Straight From the Custom Made Calendar
- Unlimited Background Color setting for Schedule Event
- Email Support
- Booker receives an email
- Owner (admin) receives email of booking
- Event Calendar month, week and day view
- Full Technical Support From Us

[Upgrade to the Pro version](http://codecanyon.net/item/eventcommerce-wp-responsive-event-calendar-pro/10716644?ref=wpproducts) for all the pro features, and read more in [depth details](http://codecanyon.net/item/eventcommerce-wp-responsive-event-calendar-pro/10716644?ref=wpproducts) about the plugin.


= Manage your Bookings in Admin Panel: =
- Comfortable Admin Panel for Event schedule booking management. View Event bookings in Calendar Overview Panel (Timeline) with possibility to set Day/Week/Month view 
	or in Booking Listing Table with pagination.
- In manage booking Search the booking(s) by different parameters, using the Filter in Admin Panel.
- Pagination of the booking listing.
- Administrator can edit or Delete specific bookings.
- View the Event bookings in booking calendar of any month of any year.

= Desired Businesses / You can use this Event booking calendar plugin as: =
- parties ticket booking.
- tech conferences.
- Summits.
- Weddings
- Seminars
- gatherings.
- appointments.
- charities.
- masses.
- Meetings
- Team Building Events
- Trade Shows
- Business Dinners
- Golf Events
- Press Conferences
- Networking Events
- Incentive Travel
- Opening Ceremonies
- Product Launches
- Theme Party Theme Parties
- VIP Event VIP Events
- Trade Fairs
- Shareholder Meetings
- Award Ceremonies
- Incentive Events
- Executie Retreat Executive Retreats
- Birthdays
- Family Events
- Any events
- Whatever you like!
	 

<p>Some of our popular extensions include the followings:</p> 

 <p><a rel="nofollow" href="http://codecanyon.net/item/wordpress-appointment-schedule-booking-system-pro/10275446?ref=wpproducts">wordpress-appointment-schedule-booking-system-pro</a></p> 
  	
 <p><a rel="nofollow" href="http://codecanyon.net/item/wp-quick-booking-manager-pro/9775460?ref=wpproducts">wp-quick-booking-manager-pro</a></p>
 
 <p><a rel="nofollow" href="http://wordpress-expert.codeinterest.com/wordpress/icontact-wordpress">iContact Wordpress Plugin</a></p>

 <p><a rel="nofollow" href="http://wordpress-expert.codeinterest.com/wordpress/get-response-wordpress">GetResponse Wordpress Plugin</a></p>
 
 <p><a rel="nofollow" href="http://wordpress-expert.codeinterest.com/woo-commerce/woocommerce-eway-payment-gateway">woocommerce eway payment gateway</a></p>

 <p><a rel="nofollow" href="http://wordpress-expert.codeinterest.com/woo-commerce/personalize-mobile-case-design-for-woocommerce">Personalize Mobile Case Design for WooCommerce</a></p>

 <p><a rel="nofollow" href="http://codecanyon.net/item/woocommerce-business-card-flyer-design/8771618?ref=wpproducts">WooCommerce Business Card & Flyer Design</a></p>

 <p><a rel="nofollow" href="http://codecanyon.net/item/custom-product-and-tshirt-design-for-prestashop/8593926?ref=wpproducts">Custom Product and T-shirt Design for Prestashop</a></p>

 <p><a rel="nofollow" href="http://codecanyon.net/item/woocommerce-custom-tshirt-designer/5185471?ref=wpproducts">WooCommerce Custom T-Shirt Designer</a></p>


Check http://www.codeinterest.com/ for more Plugins.


== Screenshots ==

1. Front - Event Booking Calendar

2. Admin - event category

3. Admin - manage venue

4. Admin - add new venue

5. Admin - add event booking

6. Admin - event booking managememnt

7. Admin - event calendar

8. Admin - event color setting

9. Admin - frontend css fix

== Changelog ==

= 1.0 =
This is the initial version of the plugin.

== Installation ==

1) Copy/Upload 'evntgen-scbooking' folder to the '/wp-content/plugins/' directory
2) Activate 'EventCommerce WP Event Calendar' form wp plugin option in admin area
3) Plugin will appear in the menu bar of WP Dashboard
4) create venue/sponsors/organizer/events for booking.
5) please save primary menu if no rooms gallery or booking calendar is showing.

== FAQ ==

= 1.1 =
First version of EventCommerce WP Event Calendar. No errors known.