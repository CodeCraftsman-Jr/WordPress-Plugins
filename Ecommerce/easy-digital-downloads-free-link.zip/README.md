# Easy Digital Downloads Free Link #

replace EDD add-to-cart button with download link when product is free

* [Home](http://shop.webaware.com.au/easy-digital-downloads-free-link/)
* [GitHub](https://github.com/webaware/easy-digital-downloads-free-link)
* [Readme](https://github.com/webaware/easy-digital-downloads-free-link/blob/master/readme.txt)
* [Download](http://wordpress.org/plugins/easy-digital-downloads-free-link/)
* [Documentation](http://wordpress.org/plugins/easy-digital-downloads-free-link/faq/)
* [Support](http://wordpress.org/support/plugin/easy-digital-downloads-free-link)
* [Translate](http://translate.webaware.com.au/projects/edd-free-link)
* [Donate](http://shop.webaware.com.au/easy-digital-downloads-free-link/)
