<?php
/*
 * Title   : Conekta Payment extension for WooCommerce
 * Author  : Cristina Randall
 * Url     : http://cristinarandall.com/
 * License : http://cristinarandall.com/
 */
?>


<span class='payment-errors required'></span>
Por favor realiza el pago en el OXXO más cercano utilizando la ficha de pago. Dale clic para generar la ficha de pago con codigo de barra.