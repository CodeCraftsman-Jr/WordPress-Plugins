<?php
class Conekta_Payment_Method extends Conekta_Resource
{
}
?>
