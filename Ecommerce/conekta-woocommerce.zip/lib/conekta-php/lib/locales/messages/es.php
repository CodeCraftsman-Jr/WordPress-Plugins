<?php

return array(
	'error' => array(
		'resource' => array(
			'id' => 'No se pudo obtener el id de la instancia de RESOURCE.',
			'id_purchaser' => 'Hubo un error. Favor de contactar al administrador del sistema.'
		),
		'requestor' => array(
        	'connection' => 'No se pudo conectar a BASE.',
        	'connection_purchaser' => 'No se pudo conectar al sistema de pagos.'
        )
	)
);