=== qTranslate loves WPEC ===
Contributors: stereohero
Donate link: http://stereohero.com/
Tags: wp e-commerce, qtranslate, translation, wpec
Requires at least: 3.0.1
Tested up to: 3.8.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds translatable form fields for wp e-commerce taxonomies (product categories, variations and product tags).

== Description ==

This is a simple and tiny plug-in which add translatable form fields for wp e-commerce taxonomies (product categores, variations and product tags).

Just activate it and you're good to go.

Requires qTranslate and WP e-commerce.

== Installation ==

1. Upload `qtloveswpec` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What does it do? =

Adds translatable form fields for wp e-commerce taxonomies (product categories, variations and product tags).

== Screenshots ==

1. The Product Variations edit screen with qTranslate loves WPEC. In this case with both Swedish and English alternatives.
2. The Product Categories edit screen with qTranslate loves WPEC. In this case with both Swedish and English alternatives.

== Changelog ==

= 1.0 =
* Initial public release.