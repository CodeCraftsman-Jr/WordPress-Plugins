=== Jigoshop CSV Importer ===
Contributors: mag_oberon
Donate link: http://www.wpthorp.com/
Tags: jigoshop,jigoshop product import, product import, import jigoshop csv, jigoshop csv loader, jigoshop csv, jigoshop csv import, csv, import, plugin, csv import, products, shop
Requires at least: 3.8+
Tested up to: 4.2.2
Stable tag:trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Import CSV products into Jigoshop.

== Description ==

Import Products into your Jigoshop store with the Jigoshop CSV Importer. CSV Importer lets you import all types of products, even product variations!

Support Blog & Pro Installation: http://www.wpthorp.com/jigoshop-csv-importer-plugin/

<strong>Features Included:<strong>

* A simple, user friendly CSV product importer for Jigoshop.
* Import hundreds or thousands of products at once. (The only limit is your patience!)
* Import images via URL or local file path. (Now detects and skips duplicate images!)
* Import hierarchical category structures. 
* Import Tags
* Import Description
* Import Price
* Import SKU
* Import Thumbnail

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. admin area
== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==

