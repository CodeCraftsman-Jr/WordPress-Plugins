<?php
/*******************************************************************************
 * Copyright 2009-2013 Amazon Services. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 *
 * You may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 * This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 *******************************************************************************
 * PHP Version 5
 * @category Amazon
 * @package  MWS Subscriptions Service
 * @version  2013-07-01
 * Library Version: 2013-09-26
 * Generated: Thu Sep 26 17:22:27 GMT 2013
 */

/**
 *  @see MWSSubscriptionsService_Model
 */

require_once (dirname(__FILE__) . '/../Model.php');


/**
 * MWSSubscriptionsService_Model_SubscriptionList
 * 
 * Properties:
 * <ul>
 * 
 * <li>member: array</li>
 *
 * </ul>
 */

 class MWSSubscriptionsService_Model_SubscriptionList extends MWSSubscriptionsService_Model {

    public function __construct($data = null)
    {
        $this->_fields = array (
            'member' => array('FieldValue' => array(), 'FieldType' => array('MWSSubscriptionsService_Model_Subscription')),
        );
	    parent::__construct($data);
    }

    /**
     * Get the value of the member property.
     *
     * @return List<Subscription> member.
     */
    public function getmember()
	{
        if ($this->_fields['member']['FieldValue'] == null)
		{
            $this->_fields['member']['FieldValue'] = array();
        }
	    return $this->_fields['member']['FieldValue'];
    }

    /**
     * Set the value of the member property.
     *
     * @param array member
     * @return this instance
     */
    public function setmember($value)
	{
        if (!$this->_isNumericArray($value)) {
            $value = array ($value);
        }
	    $this->_fields['member']['FieldValue'] = $value;
        return $this;
    }

    /**
     * Clear member.
     */
    public function unsetmember()
	{
        $this->_fields['member']['FieldValue'] = array();
    }

    /**
     * Check to see if member is set.
     *
     * @return true if member is set.
     */
    public function isSetmember()
	{
	            return !empty($this->_fields['member']['FieldValue']);
		    }

    /**
     * Add values for member, return this.
     *
     * @param member
     *             New values to add.
     *
     * @return This instance.
     */
    public function withmember()
	{
        foreach (func_get_args() as $member)
		{
            $this->_fields['member']['FieldValue'][] = $member;
        }
        return $this;
    }

}
