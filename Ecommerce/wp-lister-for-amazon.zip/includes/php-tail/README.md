php-tail
========

Tail -f functionality implemented in PHP.
Fork from http://code.google.com/p/php-tail/
