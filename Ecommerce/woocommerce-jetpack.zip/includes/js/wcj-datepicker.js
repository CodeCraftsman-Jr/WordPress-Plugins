jQuery(document).ready(function() {
	jQuery("input[display='date']").datepicker({
		dateFormat : 'yy/mm/dd'
	});
});