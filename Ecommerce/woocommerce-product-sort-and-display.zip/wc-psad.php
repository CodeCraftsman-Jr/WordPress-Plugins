<?php
/*
Plugin Name: WooCommerce Product Sort and Display LITE
Description: Take control of your WooCommerce Shop random product display with WooCommerce Show Products by Category. Sort and show products on Shop page by category with 'On Sale' or 'Featured' products showing first. Products showing and total products per category count for intelligent viewing.
Version: 1.4.0
Author: A3 Revolution
Author URI: http://www.a3rev.com/
License: This software is under commercial license and copyright to A3 Revolution Software Development team

	WooCommerce Show Products By Categories. Plugin for the WooCommerce shopping Cart.
	Copyright© 2011 A3 Revolution Software Development team

	A3 Revolution Software Development team
	admin@a3rev.com
	PO Box 1170
	Gympie 4570
	QLD Australia
*/
?>
<?php
define('WC_PSAD_FILE_PATH', dirname(__FILE__));
define('WC_PSAD_DIR_NAME', basename(WC_PSAD_FILE_PATH));
define('WC_PSAD_FOLDER', dirname(plugin_basename(__FILE__)));
define('WC_PSAD_URL', untrailingslashit(plugins_url('/', __FILE__)));
define('WC_PSAD_DIR', WP_PLUGIN_DIR . '/' . WC_PSAD_FOLDER);
define('WC_PSAD_NAME', plugin_basename(__FILE__));
define('WC_PSAD_TEMPLATE_PATH', WC_PSAD_FILE_PATH . '/templates');
define('WC_PSAD_IMAGES_URL', WC_PSAD_URL . '/assets/images');
define('WC_PSAD_JS_URL', WC_PSAD_URL . '/assets/js');
define('WC_PSAD_CSS_URL', WC_PSAD_URL . '/assets/css');
if (!defined("WC_PSAD_AUTHOR_URI")) define("WC_PSAD_AUTHOR_URI", "http://a3rev.com/shop/woocommerce-product-sort-and-display/");

include ('admin/admin-ui.php');
include ('admin/admin-interface.php');

include ('admin/admin-pages/admin-sort-display-page.php');

include ('admin/admin-init.php');
include ('admin/less/sass.php');

include 'classes/class-wc-psad.php';
include 'classes/class-wc-psad-functions.php';
include 'classes/class-wc-psad-admin-hook.php';

include 'admin/wc-psad-init.php';

/**
 * Call when the plugin is activated and deactivated
 */
register_activation_hook(__FILE__, 'wc_psad_install');


?>