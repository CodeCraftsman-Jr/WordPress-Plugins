=== WooCommerce Email Verification===
Contributors: subhansanjaya
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=subhansanjaya%40gmail%2ecom&lc=GB&item_name=WooCommerce%20Email%20Verification&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: woocommerce account verification, email validation, woocommerce email verification, account activation, woocommerce, email, checkout, woocommerce register, email verification
Requires at least: 3.0
Tested up to: 3.8
Stable tag: 2.3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin enables email verification on user registration.

== Description ==

WooCommerce email verification plugin sends a verification link on users email to activate their account on user registration. 

= Help Keep This Plugin Free =

If you find this plugin useful to you, please consider [__making a small donation__](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=subhansanjaya%40gmail%2ecom&lc=GB&item_name=WooCommerce%20Email%20Verification&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest) to help contribute to my time invested and to further development. Your contribution (whatever the amount) would be greatly appreciated.

== Installation ==	

**Installation Instruction & Configuration**  	

1. In the admin panel plugins page click Add New. Then click on "upload" link. Select the downloaded zip file and install it OR
Download the zip file and extract it. Upload "woocommerce email verification" folder  to your plugins directory (wp-content/plugins/).

2. Activate the plugin through the 'Plugins' menu in WordPress. 	

3. Create a page with name "activate". (URL should be yourwebsitedomain.com/activate) and put the following short code and save it.
[woocommerce-email-verification]

== Screenshots ==

1. 
2. 



