=== Real Estate Finder ===
Contributors: allis741 
Donate link: http://www.onlinerel.com/wordpress-plugins/
Tags: real estate,  promote, feed, rss, popular, google maps, real estate listings, listings, properties, property,widget, sidebar
Requires at least: 2.5
Tested up to: 3.3.1
Stable tag: trunk

Plugin "Real Estate Finder" gives visitors the opportunity to use a large database of real estate.
Real estate search for U.S., UK,Canada,  Australia
 
== Description ==

Plugin "Real Estate Finder" gives visitors the opportunity to use a large database of real estate.
Real estate search for U.S., Canada, UK, Australia 
Real Estate Finder are saved on our database, so you don't need to have space for all that information. 

== Installation ==

1. Upload the folder real-estate-finder to the /wp-content/plugins/ directory                                  
2. Activate the plugin Real Estate Finder through the 'Plugins' menu in WordPress                                                
3. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.                 

== Screenshots ==

1. Real Estate Finder Widget

== Changelog ==

= 2.4 =

* Tested up to 3.3.1 WP     
* Updated script

= 2.3 =
* Tested upto 3.1.2 WP and fix bugs

= 2.0 =
* Updated script

= 1.9. =
* Tested upto 3.1 WP and fix bugs

= 1.8 =
* Updated script.        

= 1.7 =
* Updated feed.                                                                                                        

= 1.6 =
* Updated feed address.  

= 1.5 =
* Tested upto 3.1 WP 

= 1.4 =
* Changed works upto 3.0.3 WP 

= 1.2 =
* Fix bugs.

= 1.0 =
* First stable version.