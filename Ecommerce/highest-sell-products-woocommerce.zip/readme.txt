=== Highest Sell Products Woocommerce ===
Contributors: swadeshswain
Tags:Heighest Sell Product Woocommerce , woocommerce,Dashboard Widget,Order,status ,Heighest Sell Product,Sell,Product,Heighest 
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later

This plugin show the Highest  sell product on your Site dashboard section

== Description ==

1 . This plugin is a woocommerce addon.

2 . If woocommerce plugin installed in your site ,then this plugin works.

3 . This plugin show the Highest  sell product on your Site dashboard section.

4 . You can customize No of Product to dispaly on Dashboard.

you can 

== Installation ==

1. Upload Highest Sell Products Woocommerce  to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Check your Dashboard ,Enjoy.





== Screenshots ==

1. Highest Sell Products Dashboard Widget 1

2. Highest Sell Products Dashboard Widget 2

== Changelog ==
= 1.0 =
* New Plugin release


