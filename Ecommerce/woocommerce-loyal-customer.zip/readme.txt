=== Woocommerce Loyal Customer ===
Contributors: codenterprise
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=EUNNQUBB23JZ6
Tags: Woo-commerce, wordpress, commerce, e-commerce, ecommerce, wordpress ecommerce, order, Woocommerce order, order count, order sum, total order, filter order, number of order, add column to order gird
Requires at least: 3.9.1
Tested up to: 4.1
Stable tag: 1.4.1
License: GPLv2

View your most loyal customers with order history.

== Description ==
Woo Commerce Loyal Customer provides wp-admin a way to view the total number of orders received per registered customer in a very user friendly manner with the help of color codes. It also gives a functionality to search registered customers by name and email. Beside this, wp-admin can also sort the order count by ascending and descending order. Please note that if a registered customer posted a single order, which has status of failed or in process, It will not be accounted in our plugin. In short, order count will work fine in case of those registered customers who have posted one successful order in the past.  

Tested for WooCommerce : 2.1.12, 2.2.6, 2.3.7, 2.3.8, 2.4.3

For more info http://www.codenterprise.com/corporate-profile/wordpress-plugins/
Other WooCommerce Plugins at http://www.codenterprise.com/our-services/woocommerce-web-development/
Send your problems to info@codenterprise.com. Dont forget to mention WP and WooCommerce versions.

*Features:*

1. Counting total orders per registered customer
2. Searching by name and email 
3. Sorting on order count and client id
4. Color codes 
5. Pagination

*Future Updates:*

1. Multilingual support
2. Discount offers to loyal customer
3. Email template


== Installation ==
1. Upload (Woocommerce Loyal customer)folder to the `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress

== Features ==
* Counting total orders per registered customer
* Searching by Name and Email 
* Sorting on Order Count, Client ID
* Colors Codes 
* Pagination

== Upgrade Notice ==
Multilingual support
Discount offers to loyal customer
Email template 

== Screenshots ==
1. This is how plugin looks at back-end

== Changelog ==

= 1.4.1 =
* Fixed for WC 2.4.3

= 1.3.1 =
* Added WP error reporting

= 1.2.2 =
* Increased memory limit for larger websites.

= 1.2.1 =
* Sorting by Client ID added. Pagination.

= 1.2 =
* Fixed Asc/Desc bug. Color codes updated. Added more versions for compatibility.

= 1.1 = 
* Updated to work with WooCommerce 2.3.7 and Wordpress 4.1

= 1.0 =
* Initial release

== Frequently Asked Questions ==
no question

== Support ==

Visit http://www.codenterprise.com/ for details and enquiries about WLC.