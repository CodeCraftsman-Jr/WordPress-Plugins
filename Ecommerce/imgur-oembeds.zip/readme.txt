=== Imgur oEmbeds ===
Contributors: bradparbs
Donate link: http://bradparbs.com/
Tags: imgur, oembeds, picture, embed
Requires at least: 3.2
Tested up to: 3.3.2
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simply paste in an Imgur URL to a page or post, and it will display the image. 

== Description ==

Simply paste in an Imgur URL to a page or post, and it will display the image.  


== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Paste an Imgur URL into a page or post.

== Changelog ==

= 1.0 =

* initial release