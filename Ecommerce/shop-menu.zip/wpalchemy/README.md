[WPAlchemy WordPress MetaBox PHP Class][wpalchemy]
=========================

Please read the [extended documentation][wpalchemy] for full details.

Some of these files are for demonstration purposes, be careful not to overwrite your existing `functions.php` file, you may want to create a backup.

[wpalchemy]: http://farinspace.com/wpalchemy-metabox/ "WPAlchemy MetaBox PHP Class"
