=== CBX Currency Converter ===
Contributors: manchumahara, codeboxr
Donate link: http://codeboxr.com
Tags: widget,shortcode, currency, currency converter, exchange rate, exchange rate display
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

CBX  Currency Converter for wordpress

== Description ==

Codeboxr Currency Converter for wordpress

Titles Shows all. This plugins shows a currency converter box in wordpress. The display can be done via widget or shortcode. Developer can show using custom function call as need.


Features:

*   Display a awesome from to convert currency in any content with shortcode [codeboxrcurrencyconverter] or any widget 	position
*   Has four layout ,only calculator,only list ,calculator with list at top and calculator with list at bottom
*   Translation Support

See more details and usages guide here http://codeboxr.com/product/universal-currency-converter-and-live-exchange-rate-display-for-wordpress

Pro Version:
* Optional integration in woocommerce and wp-ecommerce product page if product is in stock,takes product price as default amount and product currency as default from currency
* Can give every widgets and shortcodes different look
* Widgets can take its own setting or global settings
* Shortcode Params

[codeboxrcurrencyconverter]

For extra params use the following:

use_global           - Set  'on' if you want to use global settings,

layout               - Use any cbcurrencyconverter_defaultlayout (used as default),cbcurrencyconverter_list , cbcurrencyconverter_calwithlistbottom, cbcurrencyconverter_calwithlisttop

calc_title           - Title for calculator,

calc_to_currency     - Default currency to which you want to convert, example: USD

calc_from_currency   - Default currency from which you want to convert,example: BDT

for total currency list please check here https://gist.github.com/manchumahara/7e46191815961038dfb1

calc_default_amount  - Default amount of from currency, example: 10

list_title           - Title for list

list_from_currency   - Default currency from which you want to convert,, example: USD

list_to_currency     - Default currencys (can select multiple ,comma separate ) to which you want to convert, ,example: BDT

list_default_amount  - Default amount of from currency for list view, example: 20



== Installation ==

How to install the plugin and get it working.


1. Upload `cbcurrencyconverter` folder  to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. From 'Setting' menu see sub menu 'Currrency Convert', save setting
4. Select view ,default amount,currency and css colors  from the plugin setting


== Frequently Asked Questions ==

= Can anyone show it in a specific post only ? =

yes, using shortcode it can be displayed in any post or page

= Does this can show any costom text as title ? =

yes , can give different title for calculator view and list view

= Does this can show as many country currency as anyone wants in list view ? =

yes , there is a multi select box to select as many currency as you want for list view

= Is the possible to show it in widget and shortcode at a time ? =

Yes and it will work in both place at a time nicely, just try it.

== Screenshots ==
1. General Setting
2. Calculator Setting
3. Calculator Setting-2
4. List Setting
5. Tools Setting
6. 3rd Party Plugin Integration
7. Frontend Widget Display
8. Shortcode placement in editor
9. Frontend Shortcode Display
10. Woocommerce Integration (Pro addon)
11. Wp-Ecommerce Integration (Pro addon)


== Changelog ==
= 1.1.0 =
* Minor bug fix release
= 1.0.10 =
* First Public Release

== Upgrade Notice ==
* None at this moment
