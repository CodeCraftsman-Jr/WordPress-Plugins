[ItemPress](http://wordpress.org/plugins/itempress/) is a robust custom post type that will allow you to create new content with the freedom of ambiguity.

# Getting Involved

If you use VVV, you can use [itempres-vvv](https://github.com/aubreypwd/itempress-vvv) to get started. Or, fork, hack, and submit a pull request.

## IRC

**#itempress** is an official channel on freenode. Join there to get help, discuss new features, or just say Hi. I am usually there Mon-Fri 10am - 4pm MST. Ping @aubreypwd to get my attention. Some official meetings will happen there in the future.

## aubreypwdev on Trello

Development stuff also happens on Trello at my [public board](https://trello.com/b/uk3hdBiF).

# Documentation

I am currently working on ItemPress's documentation on the [ItemPress Codex](http://codex.wordpress.org/index.php?title=User:Aubreypwd/itempress)