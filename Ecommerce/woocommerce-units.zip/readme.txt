=== WooCommerce Units ===
Contributors: Mladjo
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=QXZZJ83F6PBDQ&lc=SE&item_name=WP%20Social%20Networks%20Plugin&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: woocommerce, measurement, area, units, measure, plugin, admin, calculator, stock
Requires at least: 3.8
Tested up to: 4.2
Stable tag: 0.1.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

WooCommerce Units allows you to sell WooCommerce Products by square measurement per Unit.

== Description ==

WooCommerce Units allows you to sell WooCommerce Products by square measurement per Unit.

= Features =

*Products are declared in square units of area.
*Sell products "by the measurement".
*Adds a calculator to your product pages to calculate the product quantity based on unit area.
*Shows price per Dimension Unit.
*Manage stock for products based on units

== Installation ==

Standard WordPress installation; either:

- Go to the Plugins -> Add New screen in your dashboard and search for this plugin; then install and activate it.

Or

- Upload this plugin's zip file into Plugins -> Add New -> Upload in your dashboard; then activate it.

== Screenshots ==

1. Frontend.
2. Product data.

== Changelog ==

= 0.1.0 =
* Initial release

= 0.1.1 =
* Danish and Swedish translations