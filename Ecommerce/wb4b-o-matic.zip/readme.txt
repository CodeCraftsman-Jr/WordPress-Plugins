=== WB4B-o-Matic ===
Contributors: WB4B
Tags: autoblogging, feeds, rss, atom, aggregation, content, syndication, posts, post, writing, bot, admin
Requires at least: 2.2.1
Tested up to: 2.6
Stable tag: trunk

Its a modification of WP-o-Matic, a plugin that makes autoblogging a snap by automatically creating posts from the RSS/Atom feeds you choose, which are organized into campaigns. 

== Description ==

Its a modification of WP-o-Matic, a plugin that makes autoblogging a snap by automatically creating posts from the RSS/Atom feeds you choose, which are organized into campaigns. 

== Installation ==

1. Extract wb4bomatic.zip in the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Follow the on-screen instructions.s

== Frequently Asked Questions ==

== Screenshots ==

1. Dashboard
