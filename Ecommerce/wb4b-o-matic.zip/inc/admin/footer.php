  </div>
</div>

<div id="wpofooter">
  <p>WB4B-o-Matic <?php echo $this->version ?> &mdash; Copyright &copy;2010 <a href="http://wb4b.com.br">Daniel Oliveira </a> - Modification of:</p>
  <!-- Remove me not! -->
  <p>WP-o-Matic <?php echo $this->version ?> &mdash; Copyright &copy;2008 <a href="http://devthought.com">Guillermo Rauch</a></p>
</div>    
