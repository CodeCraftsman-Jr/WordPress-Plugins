<?php
/**
 * Add Helper Functions
 *
 * @package     EDD\StoreHours\Functions
 * @since       1.0.0
 */


// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;


