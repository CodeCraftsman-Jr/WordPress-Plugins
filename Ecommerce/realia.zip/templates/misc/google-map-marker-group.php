<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="marker multiple">
	<div class="marker-inner">
		<span><?php echo count( $group ); ?></span>
	</div><!-- /.marker-inner -->
</div>
