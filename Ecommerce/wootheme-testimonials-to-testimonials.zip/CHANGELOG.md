# CHANGELOG WooTheme Testimonials to Testimonials Widget

## master

## 1.2.1
* Update store branding

## 1.2.0
* Change branding from Aihrus to Axelerant
* Update copyright text
* Update plugin name
* Update PHPCS to WordPress Core

## 1.1.2
* Require Aihrus 1.1.0
* Require Testimonials 2.19.0
* Update Aihrus integration
* Update copyright year

## 1.1.1
* Coding standards update
* Require Testimonials 2.18.1
* Revise Plugin Name: Testimonials – WooTheme Testimonials Migrator

## 1.1.0
* Move ci to tests
* Move CSS to assets
* Move files to assets
* Move lib to includes/libraries
* Move main class to own class file
* Revise required file paths
* Revise required_once for Aihrus Framework
* Specify a “Text Domain” and “Domain Path”
* Use $plugin_assets than $plugin_path

## 1.0.0
* Initial code release 