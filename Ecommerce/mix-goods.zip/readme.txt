=== Mix-Goods (Микс-Товары)===
Contributors: Mixmarket
Tags: adv, ad, ads, affiliate, mixmarket
Requires at least: 2.5
Tested up to: 3.1
Stable tag: trunk
License: GPLv2 or later

Плагин для быстрой и простой установки рекламных кодов Микс-Товары

== Description ==
Quick and easy installation of advertising Mix-Goods

Плагин для быстрой и простой установки рекламных кодов Микс-Товары

== Installation ==

Upload the Mix-Goods plugin to your blog, Activate it.

Для блока "Где купить" нужно указать [gdekupit gk_id="номер товарной группы" brand="бренд" model="модель"] а также при необходимости другие параметры: type="vert или hor" - тип показа; pagesize="количество ссылок на одну страницу". 

Для блока "Контекстный товар" нужно указать [kt kt_id="номер товарной групп"], а можно указать ID нужной категории (cat_id="XXX"). 

Все настройки нужно производить в <a href=http://www.mixmarket.biz/doc/partners/goods/programs/?from=wordpress>кабинете партнера</a>

== Changelog ==

= 1.0 = 
* First version

