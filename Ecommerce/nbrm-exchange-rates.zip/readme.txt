﻿=== NBRM Exchange Rates ===
Donate link: http://iok.mk/darko
Tags: nbrm, exchange rates, нбрм, курсна листа
Requires at least: 2.5
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Приказ на курсна листа според податоците на НБРМ.

== Description ==

Приказ на курсна листа според податоците на Народна банка на Република Македонија.

== Frequently Asked Questions ==
-

== Installation ==

1. Upload `nbrm` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. /assets/screenshot-1.png
2. /assets/screenshot-2.png

== Changelog ==

= 1.0 =
* First version

== Upgrade Notice ==
-


== Arbitrary section ==

You may provide arbitrary sections, in the same format as the ones above.  This may be of use for extremely complicated
plugins where more information needs to be conveyed that doesn't fit into the categories of "description" or
"installation."  Arbitrary sections will be shown below the built-in sections outlined above.