=== Jigoshop Order Locator ===
Contributors: Carlos Sanz García
Tags: jigosghop, locator, id, e-commerce, unique id
Requires at least: Wordpress 3.2 + Jigoshop 1.3
Tested up to: 3.4.1
Version: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extends JigoShop adding an unique locator per order + product

== Changelog ==

= 1.0 =

* First Release