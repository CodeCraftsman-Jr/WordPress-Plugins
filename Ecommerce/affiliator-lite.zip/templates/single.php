<?php get_header()?>
<?php global $affiliator; $affiliator->get_single_template()?>
<?php get_footer()?>