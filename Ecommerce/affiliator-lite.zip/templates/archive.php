<?php get_header()?>

<?php global $affiliator; $affiliator->get_archive_template()?>
<?php get_footer()?>