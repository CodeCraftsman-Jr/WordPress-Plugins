=== Affiliator ===
Contributors: basdog22
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=QR2JP5U2RMQNC
Tags: affiliate,linkwise,forestview
Requires at least: 4.2.2
Tested up to: 4.2.2
Stable tag: 4.2.2


Affiliate plugin that allows you to create a fully powered affiliate site.

== Description ==

Affiliate plugin that allows you to create a fully powered affiliate site. The plugin aims to users from Greece and allows them to import and showcase offers from [Linkwise](http://mikk.ro/EuH) and [Forestview](http://forestvieweu.go2cloud.org/SH1Mc).

== Installation ==

1. Upload the plugin from the plugins installation screen in WordPress
1. Activate the plugin through the 'Plugins' menu in WordPress

Depending on your products slug the link to the products listing will be:

www.example.com/{slug} (eg: www.example.com/products If your slug is products)

== Screenshots ==

1. Screenshot 1
2. Screenshot 2
3. Screenshot 3
4. Screenshot 4
5. Screenshot 5
6. Screenshot 6
7. Screenshot 7
8. Screenshot 8
9. Screenshot 9
10. Screenshot 10
11. Screenshot 11
12. Screenshot 12

