<div class="options-intro">
    <h2><?php _e('Google Places Reviews Plugin Options', 'gpr'); ?></h2>
    <p><?php _e('The following options set plugin defaults and options on a global level.', 'gpr'); ?> </p>
</div>