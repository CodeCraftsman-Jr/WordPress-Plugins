=== Woocommerce Extra Registration Fields ===
Tags: woocommerce, wordpress, extra, fields
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allow the users to add extra fields in registration ( My Account ) page, so you can now add more fields than firstname and lastname fields ..

== Description ==

Woocommrece extra registration allow the user to add extra fields to woocommerce my account page. you can add various fields like :

*   Text
*   Textarea
*   Select
*   Radio
*   Checkbox
*   Datepicker

For each extra field you can choose :

*   if the fields is required field
*   change the default style for woocommerce ( wide, first, last)



== Installation ==

1. Upload the plugin zip file to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. You will find the admin panel for adding extra fields under Woocommerce --> extra account

== Frequently Asked Questions ==

= No questions for now =

No answer.

== Screenshots ==

1. Woocommerce extra plugin from admin panel
2. Woocommerce extra plugin from front end
3. Another view for the admin fields 
4. Showing the available types 
5. Showing the plugin from the front-end after adding the extra fields  

== Changelog ==

= 1.0 =
* Uploading the plugin


== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

