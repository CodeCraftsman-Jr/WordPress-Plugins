// add the pickup date for jquery
jQuery('document' ).ready(function() {
    jQuery('#reg_date_picker' ).datepicker({
        changeMonth: true,
        changeYear: true
    });
});
