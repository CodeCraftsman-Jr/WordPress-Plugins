<?php
/*
Template Name: Junxter Ads
*/
?>

<?php get_header();?>

<?php
$Pub_id = "ee4045890fd0b0ebce52d4cf45393ab0-6";

echo <<<emo

    <div id=junxter-adStation>
    <table width=95% style='margin:0 auto;background:#fff'><td>
    <link rel="stylesheet" type="text/css"
      href="http://r.junxter.com/css/style.css" />
    <script language="javascript"
      src="http://r.junxter.com/$Pub_id">
    </script>
    </td></table></div>

emo;
?>



<?php get_footer(); ?>
