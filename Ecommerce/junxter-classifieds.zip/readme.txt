=== Plugin Name ===
Contributors: Junxter Media
Tags: manage,ads,adsense,classifieds
Demo: Http://demo.junxter.com/wordpress/2.1
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 0.1

== Description ==

Use this plugin to run Junxter Classifieds on your website. Your website will be able to display and post classified listings, allowing you to sell classified ad space on your website.  Users can find and post classified ads right from your website. 

== Installation ==

1:Upload JunxterAds.php to your plugins file(eg: ..\wordpress\wp-
content\plugins).

2:Upload wp-junxter.php to your themes file(eg: ..\wordress\wp-
content\themes\default),change default to your themes file here.
Both JunxterAds.php and wp-junxter.php require you to insert your
own Junxter Classifieds Publisher Key.
You can get this key from http://www.junxter.com

3:Login in as admin.Go to Plugins, activate plugin JunxterAds

4:Go to Manage->Pages->Create New Page. Use Junxter Ads template to
create a main page for your own classified advertisement management.

5:Go to index. Click the page your have just created. You can activate
your own advertisement management now!

6:We have provided a plugin function Junxter_main() for you. In order 
to show the ads blocks in your site, go to Presentation->Theme Editor.
add <?php Junxter_main(); ?> in your siderbar.

== Frequently Asked Questions ==
Where can I get my Junxter Publisher Key?
:Just get this key from www.junxter.com

For more informations about Junxter Classifieds. Please visite http://
www.junxter.com

== Screenshots ==
This is the screen shot  

