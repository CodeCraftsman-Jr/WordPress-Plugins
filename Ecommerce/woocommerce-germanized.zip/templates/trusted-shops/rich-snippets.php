<?php
/**
 * Trusted Shops Rich Snippets HTML
 *
 * @author 		Vendidero
 * @package 	WooCommerceGermanized/Templates
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<?php echo WC_germanized()->trusted_shops->get_average_rating_html(); ?>