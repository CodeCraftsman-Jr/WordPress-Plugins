<!-- header -->
<div class="navbar">
		
	<div class="navbar-inner" id="nav1">
		<a href="#"><img src="<?php echo self::$inc_url . 'img/bxp.png'; ?>" height="70"></a>
		<p class="pull-right" id="name"></p>
	</div>
	
	<div class="navbar-inner" id="nav2">
		<ul class="nav">
			<li><a href="<?php echo BxpMenus::$dashboard_link; ?>"><i class="icon-dashboard"></i> &nbsp;<?php _e('bizXpress Dashboard',$this->domain);?></a></li>
		</ul>
	</div>
</div>
<!-- end header -->