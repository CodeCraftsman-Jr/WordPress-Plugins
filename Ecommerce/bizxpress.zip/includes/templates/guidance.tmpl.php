<div class="wp-bxp">
		
		<?php $this->load_template('header'); ?>

		<div class="container">

			<div class="row">

				<div class="col-lg-10 col-lg-offset-1 main">
					<h1>
					More Guidance 
					</h1>
					
				<div class="row">
				
				<div class="col-lg-6 col-md-6 col-sm-6">
 
					<div class="panel panel-info">
						<div class="panel-heading">
							<h2>
								<i class="icon-location-arrow big-icon"></i> SiteSell Professionals
							</h2>
							<p>
							Too busy to research keywords or build your site? Prefer to be mentored through some of the process? Hire a pro!
							</p>
							<p>
							SiteSell Professional packages are affordable and highly effective. Get one-to-one help with research, design, and more.
							</p>
							<p class="golink">
								<a href="http://coaching.sitesell.com" target="_blank">Go to the SiteSell Pros HQ</a> 
							</p>
						</div>
					</div>
				</div>
					
					<div class="col-lg-6 col-md-6 col-sm-6">
						
						<div class="panel panel-info">
							<div class="panel-heading">
								<h2>
									<i class="icon-question big-icon"></i> Guidance &amp; Support 
								</h2>
								<p>
								Need a little help? The bizXpress Guidance &amp; Support page has just what you need. Online FAQ's, the Forums, Consulting, Coaching and of course Support!
								</p>
								<p>
								Contact our support team 24/7 and get assistance. 
								</p>
								<p class="golink">
								<a href="<?php echo $env->link_url('bxp_contact_support'); ?>" target="_blank">Go to Guidance &amp; Support</a>
								</p>
							</div>
						</div>
					</div>
			
				</div><!-- row -->

				<div class="clearer">&nbsp;</div>

				<p>&nbsp;</p>
				<p>&nbsp;</p>

				</div>

		</div>
	</div><!-- wp-bxp -->
		<?php $this->load_template('footer'); ?>
</div>
