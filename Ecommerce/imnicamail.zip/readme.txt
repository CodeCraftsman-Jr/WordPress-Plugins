=== ImnicaMail ===
Contributors: ImnicaMail   
Donate link: http://www.imnicamail.com/
Tags: mail, autoresponder
Requires at least: 3.1
Tested up to: 3.1
Stable tag: 0.2.4

This plugin adds a subsciption form to your blog, so that your viewers can subscribe easily to your mail list.   
Note: Shortcode management added. Use [im-form] to show form in posts, pages, etc.

== Description ==

This plugin adds a subsciption form to your blog, so that your viewers can subscribe easily to your mail list.
Note: Shortcode management added. Use [im-form] to show form in posts, pages, etc.

== Frequently Asked Questions ==

== Upgrade Notice ==

== Installation ==

== Screenshots ==

== Changelog ==

= 0.1 =
* First Release

= 0.2 =
* New Features

= 0.2.1 =
* Minor Fixes

= 0.2.2 =
* Minor Fixes

= 0.2.3 = 
* Shortcode Support
* Script Enhancements

= 0.2.4 = 
* Minor Fixes

== Arbitrary section ==

== A brief Markdown Example ==
