=== WooCommerce Teams ===
Tags: woocommerce, teams, free, fundraising, competition, non-profit, 
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: trunk
Contributors: robkorobkin
License: GPLv2

== Description ==
This plugin enables shop administrators to create teams that buyers can associate their orders with in order to stage fundraising competitions.

== Installation ==
This plugin requires WooCommerce.

== Screenshots ==
1. The WooCommerce Teams Configuration Interface
2. These fields are added at checkout for customers to select their team.
3. Use the short-code [wooteams-scoreboard] to render a bar graph comparing the different teams.