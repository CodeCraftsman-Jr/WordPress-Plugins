The visual captcha library is functionally: 4.2.0.

We did need to modify the path resolutions to get it to work in the plugins ... changes are commented //3BA