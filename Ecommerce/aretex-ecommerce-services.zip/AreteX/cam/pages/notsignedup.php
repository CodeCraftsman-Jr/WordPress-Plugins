<div class="ui-widget-header ui-corner-top" >
<h2 style="text-align: center; margin-top: 5px; margin-bottom: 5px;">Temporarily Out of Service</h2>
</div>
<div class="ui-widget ui-widget-content  ui-corner-bottom container" >
<p>Your customer account panel is temporarily out of service.  If you continue to recieve this message, please contact the site owner.</p>
</div>