<strong>Deliverable Code For Manifest</strong>
<p>
Insert this Paid Membership Deliverable Code in your manifest.  
</p>
<p>
<em>Note:</em>  Do not use this in a shortcode!
</p>
