<strong>Availability</strong>

<p><strong>Start Date/Time</strong> - If you have a specific date and time you wish the membership or subscription to begin, insert it here in the format given.
</p>
<p><em>Note: </em>If you leave this field blank, it will be considered for delivery  immediately upon payment.  If you insert a date but not a time, the default time will be midnight +1 second on the date of delivery.  
</p>

<p><strong>Number of Days to Wait</strong> - If you wish to have "wait" days before delivering (most useful when no start date is specified) insert them here.  Otherwise leave at 0 for immediate delivery according to the Start Date.
</p>