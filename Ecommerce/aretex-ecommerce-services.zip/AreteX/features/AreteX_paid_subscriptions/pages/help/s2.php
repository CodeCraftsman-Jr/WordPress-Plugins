<strong>Roles and Registration</strong>
<p><strong>Registration or Role Only?</strong>  - If you chooose <em>"Register with Role"</em> the selected role is assigned when authorization (usually payment) has been confirmed. With <em>"Role Only"</em> a member who is already registered may pay to have his or her role changed (usually an upgrade).
</p>
<p><strong>Select Delivered Role</strong> - Next choose from the dropdown menu the Role you are selling.
</p>
<p><strong>Role at Expiration</strong> - If and when authorization expires for this Role, choose the Role your customer will revert to at expiration.
</p>