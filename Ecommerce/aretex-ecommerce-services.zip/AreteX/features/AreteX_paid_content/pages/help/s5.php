<strong>Shortcodes</strong>
<p>The shortcodes displayed here are probably the most appropriate for 
this deliverable based on your choices.
</p>
<p>They do not directly refer to any "buy" buttons.</p>
<p>For more advanced uses of shortcodes for Paid Content deliverables see: 
<em>WP Integration / Shortcodes &amp; Product Presentation / Paid Content</em>.
 </p>