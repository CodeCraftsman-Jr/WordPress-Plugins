<strong>Total Number of Re-Authorization Cycles</strong>
<p>Total Number of Re-Authorization Cycles - If you chose a Re-Authorization Cycle, you may enter how many re-authorizations you want AreteX&trade; to perform.  (This would be most userful for a single pay subscription of limited duration.)</p>
  