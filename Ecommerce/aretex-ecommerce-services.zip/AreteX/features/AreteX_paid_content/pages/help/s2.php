<strong>Availability</strong>

<p><strong>Start Date/Time </strong>- Fill in the date and time you will be offering your content.  If there is no specific start date, leave blank.
</p>
<p><em>Note:</em> If you leave this field blank, it will be considered for delivery  immediately upon payment.  If you insert a date but not a time, the default time will be midnight +1 second on the date of delivery.  
</p><p><strong>Number of Days to Wait Before Delivery</strong> - Enter the number of days to wait before access is authorized for the Deliverable.  Enter "0" for immediate delivery.  Do not leave this box blank.
</p>