<h2>Your AreteX&trade; Account</h2>

The information on these screens concerns your AreteX&trade; Account.

<p><strong>Contact</strong> - This is information you have provided which identifies the holder of the AreteX&trade; License, as well as providing contact information.  Please be sure to keep your contact information up-to-date.
</p>
<p><strong>License Management</strong> - This is information about your currently installed AreteX&trade; License.  This tab contains buttons to help you update or change your payment method, as well as to cancel your current license.
</p>
<p><strong>Payments</strong> - This screen gives you a full report on past and pending payments you have made on your AreteX&trade; Account.</p>