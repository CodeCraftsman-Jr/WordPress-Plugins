
<h2>Sales Report</h2>

<div id="detail_screen" style="margin-bottom: 10px;">

</div>
<script>
load_screen('sales_report');
</script>


