<div class="section group"> <!-- ROW -->
    <div class="col span_12_of_12"> <!-- Column -->
    
    <nav>
    <div class="ui-widget ui-widget-header ui-corner-all" style=" padding: 5px;">
    
    
    
    
    <div class="button-set">
        <button id="overview" class="menu_button icon_left_button ui-button"><span class="ui-icon ui-icon-image"></span>Overview</button>
        
        <button id="diagrams" class="menu_button icon_left_button ui-button"><span class="ui-icon ui-icon-script"></span>CSS Diagrams</button>
        
        <button id="welcome_instructions" class="menu_button icon_left_button ui-button"><span class="ui-icon ui-icon-mail-closed"></span>Welcome/Account</button>
 
    
        <button id="samples" class="menu_button icon_left_button ui-button"><span class="ui-icon ui-icon-document"></span>Notification Samples</button>    
    
        <button id="reference" class="menu_button icon_left_button ui-button"><span class="ui-icon ui-icon-note"></span>Dynamic Content Reference</button>
       
        
    </div>
    
    
    
    
    </div>
    </nav>

    </div> <!-- END Column -->
</div> <!-- END ROW -->