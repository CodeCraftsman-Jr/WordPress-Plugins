<h2>No Forte ACH Merchant Account on File</h2>
AreteX&trade; does not have Forte ACH Merchant Account on File for this license.
<p>You may add Forte automatic payments later if you wish.  
        You can sign up now for this automated payout service. (<a target="_blank" href="https://aretexhome.com/AreteX/authorize/add_forte?license_key=<?php echo get_option('aretex_license_key'); ?>">click here</a> ).  This opens a new window.</li>
        </p>
