<? $icon_path = plugins_url('../../../icons/',__FILE__);?>
<div class="section group"> <!-- ROW -->
    <div class="col span_11_of_12"> <!-- Column -->
    
    <nav>
    <div class="ui-widget ui-widget-header ui-corner-all" style=" padding: 5px;">
    
    <div class="button-set">
        <button id="overview" class="menu_button icon_left_button ui-button"><img class="icon_left" src="<?php echo $icon_path.'eye_open_16.png' ?>"/>Overview</button>
        <button id="payee_management" class="menu_button icon_left_button ui-button"><img class="icon_left" src="<?php echo $icon_path.'wire_transfer_16.png' ?>"/>Payee Management</button>    
        
    </div>
    

    
    
    </div>
    </nav>

    </div> <!-- END Column -->
</div> <!-- END ROW -->
