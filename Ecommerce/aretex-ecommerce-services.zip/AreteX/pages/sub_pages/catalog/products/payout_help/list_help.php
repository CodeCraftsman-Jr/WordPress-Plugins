<strong>Actual Contributor Payouts</strong>
<p>This is the list of people who will be paid (and how much they will be paid) each time a product is sold or paid for with re-bill.</p>
<p>Select <strong>Add</strong> (near the top left of the list) to add a payee to the contributor list.</p>
<p>Use the <em>Edit <strong>(pencil)</strong></em> icon to make changes to the <em>Actual Contributor Payout</em> record for this product.</p>
<p>Use the <em>Delete <strong>(trashcan)</strong></em> icon to remove the <em>Actual Contributor Payout</em> record from this product.</p>