<strong>Single Price</strong><br />
<strong>Price:</strong> Enter the price of the product.