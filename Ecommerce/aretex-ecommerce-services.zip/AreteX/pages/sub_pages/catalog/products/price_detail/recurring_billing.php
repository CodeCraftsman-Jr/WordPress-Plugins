<strong>Recurring Billing</strong><br />
<div style="padding: 8px;">
<strong>Immediate Payment:</strong> Amount charged at checkout - enter 0.00 for Free Trial<br />
<strong>Days Until Billing Starts:</strong> Number of days after checkout to begin billing on cycle<br />
<strong>Billing Cycle:</strong> How often card is charged<br />
<strong>$ Billed per Cycle:</strong> How much the card is changed each cycle.<br />
<strong>Total # of Payments:</strong> Leave blank for "Until Canceled"  - <span style="font-size: 11px;">(<em>Note:</em> these payments are in <em><strong>addition to</strong></em> the initial payment.)</span>
</div>