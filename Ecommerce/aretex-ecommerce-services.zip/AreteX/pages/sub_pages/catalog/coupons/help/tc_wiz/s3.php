<strong>Offer Limits</strong>
<p>A subset of the Tracking Code is the Offer Code.  This component is made up of the Offer Adjustment, the Offer 
Time, and the Offer ID.  This screen deals with the Offer Time.</p>

<p>In addtion to limiting the offer by date, you may limit offers to particular "Commission Groups". 
To do this, see <em>Setup/Payouts/Commission Structures</em> for more details. </p>

<p>You may also limit the offer by Product in the <em>Offer Codes</em> menu tab.</p>