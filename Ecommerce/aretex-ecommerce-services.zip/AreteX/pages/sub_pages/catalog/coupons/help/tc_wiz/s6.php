<strong>Referrer Code</strong>
<p>Tracking Codes are always built "on the fly" from components you have previously 
defined or created.  This screen addresses the Referrer Component.</p>  

<p>This wizard only creates a tracking code for you to use if you will not be paying 
commissioned sales or if you simply wish to track marketing efforts.</p>
   
<p>If you have Referrers see <em>Setup/Payouts/Commission Structures</em> for more information about setting up commissioned 
referrers.</p>