<strong>Offer Codes</strong>
<p>Current Listed Offer Codes ... </p>
<script>
jQuery('#offer_code_main_box').removeClass('span_8_of_12');
jQuery('#offer_code_main_box').addClass('span_12_of_12');
jQuery('#offer_code_help_box').hide();
</script>