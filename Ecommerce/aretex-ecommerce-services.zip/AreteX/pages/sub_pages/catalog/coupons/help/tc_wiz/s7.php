<strong>Example</strong>
<p>This code does not track commissions. (Notice the 5 "0"s in the payee component of the code.) </p>
<p>You may copy and paste the URL tracking code into your on-line or social media advertisements. Sales will be 
tracked by Offer and Media Source.</p>
