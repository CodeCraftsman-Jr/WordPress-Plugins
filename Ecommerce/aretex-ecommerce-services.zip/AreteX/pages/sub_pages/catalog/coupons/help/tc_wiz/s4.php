<strong>Offer Identity</strong>
<p>A subset of the Tracking Code is the Offer Code.  This component is made up of the Offer Adjustment, the Offer 
Time, and the Offer ID.  This screen deals with the Offer Identity.</p>
<p><strong>Description </strong> - The default description is generated from your prior choices.  It may be changed if you wish.</p>
<p><strong>Offer Code</strong> - This is a unqiue short identifier. It is used to help build the Tracking Code, as well as 
appearing on reports. 
</p>