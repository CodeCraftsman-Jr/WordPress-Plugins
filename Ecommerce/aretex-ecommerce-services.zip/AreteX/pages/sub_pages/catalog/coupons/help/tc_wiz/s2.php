<strong>Offer Pricing Adjustment</strong>

<p>A subset of the Tracking Code is the Offer Code.  This component is made up of the Offer Adjustment, the Offer 
Time, and the Offer ID.  This screen deals with the Offer Adjustment.</p>

<p><strong>Standard</strong> - No discount is offered. 
You might want to use this to generate a generic tracking code.</p>
<p><strong>Special Discount</strong> - You might use this type to offer discounts or generate incentive coupons.</p>