<strong>Media Source</strong>
<p>In this wizard the pulldown shows you all of your Media Source choices.  You may add/create a new one
by selecting "New Media Source."</p>
<p>The Media Source Code needs to be unique and is limited to a 7 letters and/or numbers combination.
You can choose to let AreteX create the code for you.</p>
<p>The Description needs to be something you can readily understand.  It can be used to help you know
which marketing efforts are producing sales.</p>
