<strong>Single Price</strong> 
<p>
<strong>Price</strong> - Type in the price you will charge on your web site.  The price given must be a real number in US dollars.  Too many decimal places will result in rounding. 
</p>
<p>
Click "Next" to proceed tot he next step.
</p>