<strong>Donation</strong>
<p>
<strong>Days of Availability</strong> - Althought not required, it is common practice to limit access to memberships and subscriptions.  With this wizard you may limit the number of days your benefactor may access the content provided (like 45 days).  If you wish to apply more complex access rules, edit the deliverable of this product later.
</p>
<p>
<strong>Role at Expiration</strong> - Be sure to specify the role your benefactor reverts to when their membership or subscription expires.
</p>
<p>
Click "Next" to see the generated shortcodes.  This action will also save your work onto the AreteX database.
<p></p>