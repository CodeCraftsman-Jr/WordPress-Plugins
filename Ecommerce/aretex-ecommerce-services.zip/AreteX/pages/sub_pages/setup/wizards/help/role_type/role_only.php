<p><strong>Role Only</strong></p>
<p>This is the shortcode you can copy and paste for a "Buy Button" for an existing member to upgrade or change roles.</p>
<p>Be sure to replace &quot;<strong>---YOUR BUTTON TEXT---</strong> &quot;. You may also replace all button html with image html, if that is better for your theme. </p>