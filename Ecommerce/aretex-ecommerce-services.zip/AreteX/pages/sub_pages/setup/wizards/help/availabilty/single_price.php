<strong>Single Price</strong> 
<p>
Althought not required, it is common practice to limit access to paid content.  With this wizard you may limit the number of days your customer may access the product they have paid for (like 45 days).  If you wish to apply more complex access rules, edit the deliverable of this product later.
</p>
<p>
Click "Next" to see the generated short codes.  This action will also save your work onto the AreteX database.
</p>