<strong>Recurring Billing</strong>
<p>
Authorization with this wizard matches the billing cycle you have chosen for this product.  To apply more complex access rules, edit the deliverable of this product later.
</p>
<p>
Click "Next" to see the generated short codes.  This action will also save your work onto the AreteX database.
</p>  