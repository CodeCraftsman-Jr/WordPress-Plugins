<strong>Recurring Billing</strong>
<p>
<strong>Days of Availability </strong>- Authorization with this wizard matches the billing cycle you have chosen for this product.  To apply more complex access rules, edit the deliverable of this product later.</p>
<p>
<p>
<strong>Role at Expiration</strong>- Be sure to specify the role your customer reverts to when the paid access expires.
</p>
Click "Next" to see the generated shortcodes.  This action will also save your work onto the AreteX database.
</p>  