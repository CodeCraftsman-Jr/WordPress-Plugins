<strong>Availablity</strong>
<br /><br />
<div id="detail_help"></div>
<script>
var detail_model_help = jQuery('#pricing_model').val();
load_div_screen('setup/wizards/help/availabilty_mem/'+detail_model_help,'#detail_help');
</script>
