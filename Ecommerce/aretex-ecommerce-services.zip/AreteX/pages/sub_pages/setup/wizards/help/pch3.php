<strong>Price Detail</strong>
<br /><br />
<div id="detail_help"></div>
<script>
var detail_model_help = jQuery('#pricing_model').val();
//jQuery('#detail_help').html(detail_model_help);
load_div_screen('setup/wizards/help/'+detail_model_help,'#detail_help');
</script>