<strong>Donation</strong>
<p>
Althought not required, it is common practice to limit access to content that goes with a donation.  With this wizard you may limit the number of days your benefactor may access the content provided (like 45 days).  If you wish to apply more complex access rules, edit the deliverable of this product later.
</p>

<p>
Click "Next" to see the generated short codes.  This action will also save your work onto the AreteX database.
<p></p>