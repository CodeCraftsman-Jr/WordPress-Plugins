<strong>Single Price</strong> 
<p>
<strong>Days of Availability</strong> - Althought not required, it is common practice to limit access to memberships and subscriptions.  With this wizard you may limit the number of days your customers may access your site/products they have paid for.  If you wish to apply more complex access rules, you may edit the deliverable of this product later.
</p>
<p>
<strong>Role at Expiration</strong> - Be sure to specify the role your customer reverts to when the paid access expires.
</p>
<p>
Click "Next" to see the generated shortcodes.  This action will also save your work onto the AreteX database.
</p>