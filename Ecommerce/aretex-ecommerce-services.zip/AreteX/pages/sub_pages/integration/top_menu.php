<?php $icon_path = plugins_url('../../../icons/',__FILE__);?>
<div class="section group"> <!-- ROW -->
    <div class="col span_12_of_12"> <!-- Column -->
    
    <nav>
    <div class="ui-widget ui-widget-header ui-corner-all" style=" padding: 5px;">
    
    
    
    
    <div class="button-set">
        <button id="overview" class="menu_button icon_left_button ui-button"><img class="icon_left" src="<?php echo $icon_path.'eye_open_16.png' ?>"/>Overview</button>
        
        <button id="short_codes" class="menu_button icon_left_button ui-button"><img class="icon_left" src="<?php echo $icon_path.'add_row_16.png' ?>"/>Shortcodes &amp; Widget</button>
        <button id="roles" class="menu_button icon_left_button ui-button"><img class="icon_left" src="<?php echo $icon_path.'administrator_16.png' ?>"/>Roles &amp; Capablities</button>

        <button id="form_customize" class="menu_button icon_left_button ui-button"><img class="icon_left" src="<?php echo $icon_path.'header_and_footer_16.png' ?>"/>Form Customization</button>    
        <button id="ptr_integration" class="menu_button icon_left_button ui-button"><img class="icon_left" src="<?php echo $icon_path.'payment_16.png' ?>"/>PTR Integration</button>    

  
        
        
    </div>
    

    
    
    </div>
    </nav>

    </div> <!-- END Column -->
</div> <!-- END ROW -->
