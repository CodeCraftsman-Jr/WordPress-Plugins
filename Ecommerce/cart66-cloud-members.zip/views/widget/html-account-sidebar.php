<div class="cm-account-widget-wrapper">
  <?php echo $before_widget; ?>
  
  <?php echo $before_title; ?>
  <span class="cm-account-widget-title"><?php echo $title; ?></span>
  <?php echo $after_title; ?>

  <div class="cm-account-widget"></div>

  <?php echo $after_widget; ?>
</div>
