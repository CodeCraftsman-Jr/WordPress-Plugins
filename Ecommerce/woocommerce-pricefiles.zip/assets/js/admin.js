// Administration-specific JavaScripts for WC-Pricefiles
(function ($) {
	"use strict";
	$(function () {
                
            
                
	});
}(jQuery));


