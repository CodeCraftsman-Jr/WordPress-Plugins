(function ($) {
	"use strict";
	$(function () {
		// Public-facing JavaScript
	});
}(jQuery));