=== WooCommerce Payment Reminder ===
Contributors: nipoto
Donate link: http://ideyeno.ir
Tags: woocommerce, Payment Reminder, Reminder, Payment, wordpress, یادآور, پرداخت, ووکامرس
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0.5
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

افزونه ارسال ایمیل یادآور برای سفارشات در انتظار پرداخت ...

== Description ==

Remind Customers who have Unpaid Order by Sending them Email Reminder Directly from the Woocommerce Order Listing Page ...

* Send Reminder button in the Order Listing Page for on-hold Orders


= Languages =
* فارسی (fa_IR)
* English (en_US)


= از ما حمایت کنید : =
[ * * * * * ](https://wordpress.org/support/view/plugin-reviews/woocommerce-payment-reminder?rate=5#postform/)


`Nima Saberi
* wordpress@ideyeno.ir`

== Installation ==

1. Visit 'Plugins > Add New'
2. Search for 'Woocommerce Payment Reminder'
3. Activate Woocommerce Payment Reminder from your Plugins page.

== Screenshots ==

1. اضافه شدن گزینه یادآور به لیست سفارشات پرداخت نشده
2. نمونه ایمیل ارسال شده به زبان فارسی
3. نمونه ایمیل ارسال شده به زبان انگلیسی
4. نمایی از پنل مدیریتی برای پیوست تصویر
5. نمونه ایمیل ارسال شده به همراه پیوست

== Changelog ==

= 0.8 =
* اضافه کردن پنل مدیریتی
* فراهم کردن امکان پیوست تصویر به ایمیل

= 0.7 =
* افزودن پیام توصیه نصب پلاگین سفارشات در انتظار تحویل
* فراهم کردن امکان بستن پیام و جلوگیری از نمایش مجدد

= 0.5 =
* فراهم کردن امکان ترجمه به زبان های دیگر
* اضافه شدن زبان انگلیسی (en_US)

= 0.3 =
* Initial commit.