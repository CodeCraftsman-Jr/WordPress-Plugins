<div id="footer">

	<p class="postmetadata alt" style="border-top: none;">
		Powered by <a href="http://dotSpiral.com/">Kommiku</a> &copy; <?php echo date('Y');?>
		<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
	</p>

</div>
</div>
</body>
</html>
