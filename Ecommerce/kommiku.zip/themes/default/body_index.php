<?php kommiku_header(); ?>	
<div id="content" class="narrowcolumn home">	
	<div id="directory">			
		<div>				
			<div class="postbox">					
				<h3 style="cursor: default;"><span>Directory</span></h3>					
				<?php kommiku_sidebar_category_list(); ?>					
				<?php kommiku_series_table_list(); ?>				
			</div>			
		</div>											
	</div>
</div>
<?php kommiku_footer(); ?>