=== lane66.com affiliate PRO ===
Contributors: pete scheepens
Donate link: http://lane66.com
Tags: pepperjam,affiliate,productfeed,datafeed,google,gan,daisycon,pj,monster,feedmonster,product,tradetracker,shareasale,m4n,commission,commissionjunction,cj,commissionjunction,webgains,affili.net,affilinet,portaljumper.com,owagu.com,owagu,datafeed,productfeed,parser,loader,affiliate,network,widget,data,feed,clickbank,adsense,help,revenue,advertising
Requires at least: 3.0
Tested up to: 3.1
Stable tag: 1.5.6

Create unlimited affiliate datafeed posts or create shopping pages with hundreds of products. Built in csv feed uploader with manual override too. All-in-one affiliate toolbox.

== Description ==

While there are dozens of affiliate products out there, lane66 has taken free affiliate marketing plugins to the next level.
With true dynamically built product-pages, unlimited layouts, API connectors and post converters this plugin is worthy of the tag "PRO", while still being offered completely free of strings.

* convert datafeed products to "all on a page" shops
* converts datafeed products to valid wordpress posts
* Built in SEO features
* unlimited layouts for your shops - download extra's or build your own
* automatic updates for your product base
* mix and match affiliate networks
* convert database products to posts, pages or widgets
* built in csv loader with manual override on each field (unique in the industry)
* select from multiple layouts
* integrate 3rd party add-ons and content
* many more pro-features inside
* visit a live demo at http://weddings.lane66.com/
* or visit a live demo at http://periodicals.lane66.com/

..."I've tried a lot of csv loaders, but this one actually works ! Awesome plugin"...
..."just moved up from feed-monster and the lane66 plugin kicks ass tooooo"...
..."received a couple more Euro's today. I hadn't even spent 2 minutes on the plugin"...
..."I have a new favorite plugin ! Saved me a ton of time and already generated income"...

Lane66.com affiliate PRO is a cooperative project between team portaljumper that brought you wordpress plugins like feed-monster (awarded) and team owagu that brought you plugins and widgets like clickbank, shareasale and many more. The combined 40+ years of professional affiliate experience has led to the ultimate in free wordpress based affiliate tools. With both teams at the wheel and Pete Scheepens as project leader you will get unmatched customer service and high graded tools. It's all public, check for yourself !

[youtube http://www.youtube.com/watch?v=iVMKelEETyQ]


*news*

* includes the linksalt.com ad-builder (the affiliate alternative to google's Adsense)
* complete GAN support for long links
* new layouts for wordpress pages
* more intelligence to automate csv parsing

== Frequently Asked Questions ==

= Do you have a demo ? =

Yes ! You can visit a simplified live demonstration of a potential resulting affiliate shop at: http://weddings.lane66.com/ or go to http://periodicals.lane66.com/


= Who's built it ? =

lane66.com is an initiative by the combined teams of http://linksalt.com and http://portaljumper.com. Both are known in the WordPress community for their top-ranking affiliate tools and products. lane66.com is led by project-leader Pete Scheepens and is a response to the sub-par affiliate tools that are currently available in the free marketplace.

= What can it do ? =

- create wordpress posts from datafeeds
- contact affiliate networks and pull products in directly
- create wordpress pages with many affiliate products on 1 page
- earn you a ton of money
- improve your site SEO
- upload any csv file from any source
- automatically detect columns from a lot of major networks
- manually override any field found in any csv feed


== Further Information ==

visit the affiliate ad-builder at : http://linksalt.com 

visit a demo-shop at : http://weddings.lane66.com/

visit a demo-shop at : http://periodicals.lane66.com/

visit the forum at : http://portaljumper.com/discuss


== Screenshots ==

1. More info can be found at http://lane66.com
2. admin panel view
3. admin panel view
4. admin panel view
5. admin panel view
6. demo shop http://weddings.lane66.com

== Upgrade Notice ==

= 1.5.0 =
includes improved search options and freebie-throttling.

