<style type="text/css">			
			.round {
			width:98%;
			-moz-border-radius: 10px;
			border-radius: 10px;
			border: 4px solid #ccc;
			padding: 3px;
			}
			.titlebox{
			float:left;
			padding:0 5px;
			margin:-10px 0 0 30px;
			background:#ccc;
			color:white;
			font-weight:900;
			}
			</style>
	<br>
	<div class="round">
	<div class="titlebox">Use our free ad-builder to complement your earnings</div>
	<br>
<div style="text-align:center;font-size:11px;">
	linksalt is a stand-alone product from linksalt.com. It is provided in this plugin as a courtesy feature to help you increase your affiliate earnings.<br>
	There are no related tracking, monitoring, data-sharing, or member features links between linksalt and this plugin.
	</div>
	<iframe src="http://linksalt.com" width="100%" height="1400" scrolling="no"></iframe>
	
</div>