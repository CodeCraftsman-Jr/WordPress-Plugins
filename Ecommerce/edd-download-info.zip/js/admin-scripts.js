jQuery(document).ready(function ($) {
	
	// date picker
	//var dateFormat = 'mm/dd/yy';
	$('.edd_download_info_datepicker').datepicker({
		dateFormat: datepicker_settings_vars.dateformat
	});
});