=== Plugin Name ===
Contributors: Thomas Michalak
Donate link: http://fuck-dance-lets-art.com
Tags: ebay, easy, simple, fast, quick
Requires at least: 2.6
Tested up to: 2.9.1
Stable tag: 0.2.1

Very fast plugin that cache shop's content for a quicker user experience. Easy and clever. Displays your eBay shop listings with all infos.

== Description ==

**THIS ALPHA VERSION IS BROKEN, EBAY CHANGED THEIR API. A NEW VERSION WILL COME. SORRY FOR THE INCONVENIENT**

Very fast plugin that cache your shop's content for a quicker and smoother user experience. Easy to set up, with some clever functionalities,  including retrieving your shop categories, excluding categories, renaming categories (only in wordpress), set a "refresh temp file" time. Displays your ebay shop listing, items infos (pictures, bids, price, etc� ...) with links to your listing and shop.

Driving quality traffic using real-time eBay listing information. Providing eBay members with unique shopping experience. This plugin use eBay API.

== Installation ==

My own little ebay shop is also simple to install, like most wordpress plugin:

   1. From your dashboard, go to puglins -> add new.
   2. Search for My own little ebay shop.
   3. Click Install.
   4. Create a page that will be used for the gallery.
   5. Set your settings under Settings -> My own little ebay shop.
   6. Enjoy


== Frequently Asked Questions ==

Please tell me if something isn't working or if you have suggestions.

== Upgrade Notice ==

none

== Screenshots ==

none

== To Do ==

* work on the css (options, items, listings).
* shop search.
* use shop description for welcome message 
* When retrieving, ask if you want to: replace all categories, add/remove new/deleted categories. Keep user's nice names.
* Pagination for shop.
* Item ending time/date: Need Time Spamp from wordpress.
* check if new changes have been made to the shop before recreating the temp file.
 

== Change log ==
v0.3:
* Cooler loading for retrieving.
* Temp files life length option.

v0.2:

* alpha version
* Exclude and rename categories
* Auto retrieve shop's categories
* Select a welcome message or default category

v0.1:

* alpha version, not ready for users to download and install


== View online examples ==

soon at [Anna Chocola syntax][annachocola.com]
[Anna Chocola syntax] : http://annachocola.com