<div class="wrap">
	<h2>Plugin Eduzz WP Connect</h2>
	<p>Com o Plugin Eduzz WP Connect o produtor diminui seu Suporte e os clientes têm uma maneira mais fácil de acessar seus Conteúdos.</p>
	<p>Para mais informações e conhecer todas as ferramentas da Eduzz, visite nosso site: <a href="http://www.eduzz.com" target="_blank">www.eduzz.com</a>.</p>
	<br />&nbsp;<br />
</div>
<p style="padding-bottom: 19px; width: 100%; color: #777;">
	<span style="float: left;">Copyright (c) 2015 - Eduzz</span>
	<span style="float: right; padding-right: 20px;">Versão: <?php echo $this->version; ?></span>
</p>