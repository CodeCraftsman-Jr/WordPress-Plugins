﻿=== Eduzz WP Connect ===
Contributors: Eduzz.com
Tags: Eduzz, Eduzz WP Connect, Connect, Produtor
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: trunk

Esse plugin é útil para quem é produtor na Eduzz. Ele permite o cliente logar na área de membros através da Eduzz.

== Description ==

**Visão Geral**

Esse plugin é útil para quem é produtor na Eduzz. Ele permite o cliente logar na área de membros através da Eduzz.

Veja detalhes completos de como usar o Eduzz WP Connect.


**Recursos**

* Faz login automático no seu site WordPress após o comprador fazer login pela Eduzz através de um link pelo e-mail.

* Permite que o usuário entre na Eduzz e se logar na área de membros disponibilizado no painel de minhas compras

**Sobre**

O Plugin foi desenvolvido por [Eduzz.com](http://eduzz.com)

== Installation ==

** Para instalar o Eduzz WP Connect siga os passos:**

1. Faça o download do plugin e o descompacte.
2. Suba os arquivos descompactados na pasta "/wp-content/plugins/" de seu WordPress.
3. Ative o Plugin Eduzz WP Connect na pagina de plugin de seu WordPress.

== License ==

Este programa é um software livre; você pode redistribuí-lo e/ou modificá-lo dentro dos termos da Licença Pública Geral GNU como publicada pela Fundação do Software Livre (FSF); na versão 3 da Licença, ou (na sua opinião) qualquer versão.

Este programa é distribuído na esperança de que possa ser útil, mas SEM NENHUMA GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU para maiores detalhes.

Você deve ter recebido uma cópia da Licença Pública Geral GNU junto com este programa. Se não, veja <http://www.gnu.org/licenses/>.

== Changelog ==

= 1.0.0 =
* Primeira versão lançada.