<?php if(!$from_ajax): ?>
<!-- Pull in our JS -->
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<div id="online_payment_form_wrapper" class="online_payment_form_wrapper">
<?php endif; ?>