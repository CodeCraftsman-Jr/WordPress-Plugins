Alter Inventory - Woocommerce Plugin
===============

First Release 0.7

Manage inventory of products and synchronized with wordpress woocommerce 

The ultimate goal of the project of this plugin is to provide front-end user experience completely free to manage products, variants, stock, images and all they need a store manager. The latter would be fantastic activate the barcode reader. 

Apologyze for my bad english
