=== Woocommerce Lightbox ===
Contributors: wpbean
Tags: Woocommerce Lightbox, Woocommerce Quick view, woocommerce quickview, wp lightbox plugin, lightbox plugin, plugin lightbox, WooCommerce Products Quick View, quick-view, woocommerce, WooCommerce Products Quick View., WooCommerce Quick View, call to action, ecommerce, fancybox, modal, product lightbox, product modal, quick buy, quickbuy, quickview, woo, woocommerce, ecommerce, inline, popup, product popup, product slideshow, product view, quick view, quickview, woocommerce, woocommerce popup, woocommerce quick view, woocommerce quickview, woocommerce view
Requires at least: 3.6
Tested up to: 4.2.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will add a quick view light box popup in your Woocommerce products.

== Description ==

### Woocommerce Lightbox by http://wpbean.com

This plugin will add a quick view light box popup in your Woocommerce products. No need any setting just install, active and enjoy.

*   [View a live demo &raquo;](http://23.227.167.145/wpbean/demo1/woocommerce-lightbox/)
*   [Support &raquo;](http://wpbean.com/support/)

Plugin Features

* Responsive Product quick view popup.
* Product image , title, price, quantity and add to cart button will be shown on popup .
* No need any settings.
* Work with all Wordpress theme.
* Easy to use.
* Developer friendly & easy to customize.
* Powered by Magnific Popup


== Installation ==

* Install it as a regular WordPress plugin

* Active the plugin.



== Frequently asked questions ==

= How can use this quick view lightbox plugin? =
Install it as a regular plugin, then hover any product, you will see a button called QuickView. Click it and a popup window will be shown with product image, title, price, quantity and Add to cart button.


== Screenshots ==

1. Woocommerce Lightbox in action.
2. Woocommerce Lightbox in action.


== Changelog ==

= version 1.0 =
* Initial release


== Upgrade notice ==
