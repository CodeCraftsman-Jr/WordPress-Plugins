Bitcoin Payments by Yellow (for woocommerce)
==========================================

Contributors: YellowPay, Mahmoud200m, piechota <br />
Tags: woocommerce, yellow, yellowpay, bitcoin, payment <br />
Stable tag: 1.0.1 <br />

Description
=====================

This is a Wordpress WooCommerce Yellow plugin, This plugin allows you to add bitcoin payment option to your wordpress woocommerce website

Installation
=====================

0. clone the plugin or download it as zip
1. Upload the entire folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

Changelog
=====================

= 1.0.1 =
* Edit error message
= 1.0.0 =
* Initial Release