=== Plugin Name ===
Contributors: Yes We Work
Requires at least: 4.0
Tags: libro, libros, biblioteca, librería, lector, lectores, español
Tested up to: 4.2.1
License: GPLv3
License URI: https://www.gnu.org/copyleft/gpl.html

Mi librería te permite añadir automáticamente a los artículos de tu blog una selección de los mejores libros sobre el tema de tu artículo

== Description ==

Mi librería te permite añadir automáticamente a los artículos de tu blog o página web una selección de los mejores libros sobre el tema de tu artículo y otros similares y aportar así más contenidos y utilidad a tus lectores. Una vez activado y configurado, tus usuarios verán un pequeño estante de libros recomendados justo después del contenido de cada artículo.

El plugin te ofrece una lista de categorías generales para mejorar la relevancia de las sugerencias, y una lista de tiendas internacionales y nacionales para enlazarlas. Si estás dado de alta en el programa de afiliados de la tienda elegida, el plugin te permite especificar tu código personal.

== Installation ==

Para instalar y activar el plugin:

1. Instala el plugin directamente desde el Codex de WordPress
1. Activa el plugin en el menú de Plugins de tu blog o página web
1. Sigue las instrucciones para configurarlo, eligiendo una categoría principal y una tienda preferida.

Las recomendaciones se verán automáticamente debajo de cada artículo, pero puedes afinar las palabras clave y los resultados en los ajustes de cada post o página.

También puedes inserter las recomendaciones con el widget (en Apariencia > Widgets) o mediante el shortcode `[mi-libreria]`.

== Screenshots ==

1. Visualización del plugin dentro de un artículo
1. Ajustes de artículo
1. Ajustes globales

== Support ==

Si tienes alguna duda o pregunta sobre este plugin, contacta con webmaster@penguinrandomhouse.com

== Changelog ==

= 1.2 =
Pequeñas correcciones de HTML

= 1.1 =
Correcciones para cumplir con normativa del Codex

= 1.0 =
Primera versión