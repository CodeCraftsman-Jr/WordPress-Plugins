<?php
   $widget_html = '<div class="wrapper-mietshop-widget-content-iframe '.$widget_style.'">'.
                   '<iframe src="'.$script.$parameter.'" class="mietshop-widget-artikelvorschau '.$widget_class.'" id="mietshop-widget-artikelvorschau_'.$widget_id.'">'.
                    '<p>Ihr Browser kann leider keine eingebetteten Frames anzeigen</p>'.
                   '</iframe>'.
                  '</div>';
?>
