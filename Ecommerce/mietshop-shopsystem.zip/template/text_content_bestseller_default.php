<?php
   $widget_html = '<div class="wrapper-mietshop-widget-content '.$widget_style.'"><div class="mietshop-widget-bestseller '.$widget_class.'">'.$shop_widget_html.'</div></div>';
?>



