<?php
   $widget_html = '<div class="wrapper-mietshop-widget-widget '.$widget_style.'"><div class="mietshop-widget-bestseller">'.$shop_widget_html.'</div></div>';
?>
