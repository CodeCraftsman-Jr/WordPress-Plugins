<?php
   $widget_html = '<div class="wrapper-mietshop-widget-widget '.$widget_style.'"><div class="mietshop-widget-artikelvorschau">'.$shop_widget_html.'</div></div>';
?>
