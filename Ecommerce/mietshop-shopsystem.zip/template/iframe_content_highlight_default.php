<?php
   $widget_html = '<div class="wrapper-mietshop-widget-content-iframe '.$widget_style.'">'.
                   '<iframe src="'.$script.$parameter.'" class="mietshop-widget-highlight '.$widget_class.'" id="mietshop-widget-highlight_'.$widget_id.'">'.
                    '<p>Ihr Browser kann leider keine eingebetteten Frames anzeigen</p>'.
                   '</iframe>'.
                  '</div>';
?>
