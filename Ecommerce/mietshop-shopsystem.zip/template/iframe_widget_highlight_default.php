<?php
   $widget_html = '<div class="wrapper-mietshop-widget-widget-iframe '.$widget_style.'">'.
                   '<iframe src="'.$script.$parameter.'" class="mietshop-widget-highlight" id="mietshop-widget-highlight_'.$widget_id.'">'.
                    '<p>Ihr Browser kann leider keine eingebetteten Frames anzeigen</p>'.
                   '</iframe>'.
                  '</div>';
?>
