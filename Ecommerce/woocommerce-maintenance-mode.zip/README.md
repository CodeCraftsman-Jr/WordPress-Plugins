WooCommerce Maintenance Mode
=========================

Add a message or redirect on Woocommerce pages only, not affecting any other parts of your website. Logged in admins will not see anything.

## This plugin was just what I needed, How can I thank you?

If you want to keep my espresso machine running so I can continue developing useful little plugins, any contributions would be awesome. [donate here](http://mattroyal.co.za/donate/).
