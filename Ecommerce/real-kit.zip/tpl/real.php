<style>
  .donate {
    display: inline-block;
    padding: 10px 30px;
    text-decoration: none;
    background: #88DBF7;
    border: 1px solid silver;
    -webkit-border-radius: 5px;
       -moz-border-radius: 5px;
            border-radius: 5px;
  }
</style>
<h1><?= __('Donation', 'realkit'); ?></h1>
<p><?= __('I would be very grateful for any support!', 'realkit'); ?></p>
<a target="_blank" href="https://funding.webmoney.ru/realplugins-for-wordpress/donate" class="button button-primary">
  <?= __('Donate', ''); ?>
</a>