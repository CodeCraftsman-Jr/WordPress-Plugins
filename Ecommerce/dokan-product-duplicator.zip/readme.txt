===  Dokan Product Duplicator ===
Contributors: sk.shaikat, tareq1988
Tags: duplicate, copy, product, woocommerce, dokan, frontend, WooCommerce, WooCommerce product, WooCommerce product duplicator, Dokan product duplicator, product, new product
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=XWBPHY6KV8SPW&lc=US&item_name=Dokan%20Product%20Duplicator&item_number=dpd&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Requires at least: 3.1
Tested up to: 4.2.2
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Duplicate other sellers product to your store on Dokan marketplace.

== Description ==

> #### Product Duplicator for **Dokan** plugin.

> You can install [**Dokan Lite**](https://wordpress.org/plugins/dokan-lite/) plugin or you can get the [**Pro Version**](http://wedevs.com/theme/dokan/?utm_source=wporg&utm_medium=cta&utm_campaign=dokan-product-duplicator) of Dokan which includes lots of features than the free one.




= Features =


Make your marketplace more user friendly for sellers by providing them the feature to duplicate product from other sellers.


== Installation ==


Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.


== Screenshots ==

1. Front end product duplicate button
2. Back end settings for set button text

== Upgrade Notice ==

This plugin will upgrade with your requirements  

== Changelog ==

= 1.0 =
* Initial release

== Frequently Asked Questions ==

Q: What is the initial requirement to use this plugin?
A: You need to install Dokan WooCommerce multivendor plugin in your site.

Q: Does it supports all product type?
A: Yes.

Q: Does this plugin support all theme?
Y: Yes.