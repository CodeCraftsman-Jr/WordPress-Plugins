=== WooCommerce product variation sorting ===
Contributors: JohnDave_666
License: GPLv3

WooCommerce product variation sorting - Fixed!

== Description ==
BlackCrowValley - Freelance Creative Collective present a simple free plugin to automatically sort product variations in both ascending and descending order as well as the graphically defined option that is the only option available with a clean install of WooCommerce.