<?php
$skPluginInfo = get_plugin_data(LN_FILE, $markup = true, $translate = true );
?>
<div class="skBannerSpace"></div>
<div id="mmBanner">
	<div id="mmLogo"></div>	
	<div class="mmpluginInfo">Version <?php echo $skPluginInfo['Version']?></div>
	<div class="clear-admin"></div>
</div>