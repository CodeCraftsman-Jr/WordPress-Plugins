=== Lunar - Sell photos online ===
Contributors: sakurapixel
Donate link: http://sakuraplugins.com/donate/
Tags: exif, exif data, gallery, album, photos to WooCommerce, WooCommerce, sell photos, photography
Requires at least: 3.9
Tested up to: 4.3
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Lunar – A WordPress plugin, that automatically converts images to WooCommerce products.

== Description ==

Lunar – A WordPress plugin, that automatically converts images to WooCommerce products. 

Features: 

1. Automatically convert images to WooCommerce products (on my machine there were over 100 products created within one minute)
1. Quick edit product title, price, description. 
1. The product description is made out of image size, image file size, description and EXIF data.



[PREVIEW](http://www.sakuraplugins.com/products-list/lunar-sell-photos-online-wordpress-photography-plugin/)

[SUPPORT](http://www.sakuraplugins.com/products-list/lunar-sell-photos-online-wordpress-photography-plugin/) 

[VIDEO SHOWCASE](https://www.youtube.com/watch?v=zJMfZHRu9IA) 

Please note that there is also a Pro version of this plugin. This plugin's main purpose is to automatically convert images to WooCommerce products, you can use the default WooCommerce shop page to display the products, however, for the Pro version I've added functionality that helps display the products in a more fancy way.


== Installation ==

1. Upload the plugin: Plugins > Add new > Upload.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to main menu "Lunar" > New Album (add images).
4. Go to main menu "Lunar" > Choose Album (click "Convert images to Products").
5. Go to main menu "Lunar" > "Options" (edit settings).


== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. Screenshot 1
2. Screenshot 2
3. Screenshot 3
4. Screenshot 4


== Changelog ==
= 1.0 =
* First release.

== Upgrade notice ==



== Arbitrary section 1 ==

