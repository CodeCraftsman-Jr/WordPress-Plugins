woocommerce-gateway-paytpv
==========================

##Módulo de pago por tarjeta de crédito para WooCommerce a través de la pasarela de PayTpv

#####Instalación
----------------
Se instala como cualquier otro plugin de wordpress

#####Configuración
------------------
Una vez instalado y activado el plugin, accediendo a Woocommerce -> Ajustes (settings) -> Pagos (Payment Gateways) y pulsando el enalce a "Paytpv" se pude rellenar la información de la cuenta de PayTpv.

Las funcionalidedes para pagos recurrentes requierend del plugin [WooCommerce Suscriptions](http://www.woothemes.com/products/woocommerce-subscriptions/) y de un teminal el paytpv.com de tipo XML BANKSTORE.

Para ventas normales bastan con WooCommerce y un terminal de tipo TPV-WEB



