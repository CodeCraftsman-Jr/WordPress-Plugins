=== Plugin Name ===
Contributors: Mazgalici
Tags: ecards, greeting cards, images
Requires at least: 2.3
Tested up to: 2.9
Stable tag: 1.3

Any image from your blog can be sent as an ecard with this plugin. 
If you want you can enable the plugin only for certain categories, tags or posts.

Every ecard sent from your site will also contain a message that you can configure to advertise your blog.

Examples of sites who are using this plugin:
http://www.stickycomics.com, http://www.animalol.com, http://www.animalici.ro

I can make this plugin avaliable on your language if you provide the translation.

== Description ==
Any image from your blog can be sent as an ecard with this plugin. 
If you want you can enable the plugin only for certain categories, tags or posts.

Every ecard sent from your site will also contain a message that you can configure to advertise your blog.

Examples of sites who are using this plugin:
http://www.stickycomics.com, http://www.animalol.com, http://www.animalici.ro

I can make this plugin avaliable on your language if you provide the translation.