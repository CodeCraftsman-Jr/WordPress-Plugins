<?php

$linkToEcardDefaultText='<center><table><tr><td valign="middle"><img src="http://messengerinvisible.com/ecard.gif" border="0"></td><td valign="middle">Send this picture as an ecard</td></table></center>';
$linkToEcardTextEmail='Check this site [url]!';
$linkToEcardLang='en';
	$linkToEcardCategories=0;

$linkToEcardLanguages=array(
'English'=>'en',
'German'=>'de',
'Romanian'=>'ro',
'Spanish'=>'es',
);


?>