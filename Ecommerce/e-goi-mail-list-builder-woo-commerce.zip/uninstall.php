<?php
/**
 * Uninstall functionality
**/
delete_option('EgoiMailListBuilderWooCommerceObject');
?>