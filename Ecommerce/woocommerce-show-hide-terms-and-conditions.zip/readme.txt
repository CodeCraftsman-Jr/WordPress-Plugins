=== Plugin Name ===
Contributors: skomfare2
Tags: woocommerce,woocommerce show terms,woocommerce products, woocommerce hide terms , woocommerce terms , woocommerce term
Requires at least: 3.8.1
Tested up to: 4.1.1
Stable tag: 1.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show or hide the Woocommerce "Terms and Conditions" on checkout page if a specific product is on cart

== Description ==

Show or hide the checkbox "Terms and Conditions" on woocommerce checkout page if a given product is on cart.
You have the option to select for each product if the "terms and condition" should be shown or hidden.

== Installation ==

Go to the wordpress administration area then on PLUGINS , ADD NEW , UPLOAD and browse to  the zip file you downloaded  and click INSTALL.

Activate  through the 'Plugins' menu in WordPress

Configure the plugin options on the WordPress admin dashboard


== Frequently Asked Questions ==

= How can I enable or disable for a specific product =

Change the option on the product edit page

== Screenshots ==

1. Admin options page

== Changelog ==

= 1.0 =
* First release.