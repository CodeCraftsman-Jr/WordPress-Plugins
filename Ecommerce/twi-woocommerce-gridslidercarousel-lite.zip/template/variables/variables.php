<?php
$twi_woo_style = vp_metabox('twi_woo_mb_main.twi_woo_g_c_style');
$twi_woo_cats = vp_metabox('twi_woo_mb_main.cat');
$twi_temp_style = vp_metabox('twi_woo_mb_main.twi_temp_style');
$twi_woo_filter_main = vp_metabox('twi_woo_mb_main.twi_woo_filter_main');
$twi_woo_per_page = vp_metabox('twi_woo_mb_main.per_page');
$xlarge = vp_metabox('twi_woo_mb_main.twi_woo_grid_group.0.twi_woo_grid_desktop_big');
$large = vp_metabox('twi_woo_mb_main.twi_woo_grid_group.0.twi_woo_grid_desktop');
$medium = vp_metabox('twi_woo_mb_main.twi_woo_grid_group.0.twi_woo_grid_tablet');
$small = vp_metabox('twi_woo_mb_main.twi_woo_grid_group.0.twi_woo_grid_phone_big');
$default = vp_metabox('twi_woo_mb_main.twi_woo_grid_group.0.twi_woo_grid_phone');
$gap = vp_metabox('twi_woo_mb_main.twi_woo_grid_group.0.twi_woo_grid_gap');
$sales_pos = vp_metabox('twi_woo_mb_main.twi_woo_rib_main.0.twi_sales_rib_pos');
$out_pos = vp_metabox('twi_woo_mb_main.twi_woo_rib_main.0.twi_out_lab_pos');
$fe_pos = vp_metabox('twi_woo_mb_main.twi_woo_rib_main.0.twi_fe_lab_pos');
$rib_dis = vp_metabox('twi_woo_mb_main.twi_woo_rib_main.0.twi_rib_dis');
$autoplay = vp_metabox('twi_woo_mb_main.twi_carousel_group.0.autoplay');
?>