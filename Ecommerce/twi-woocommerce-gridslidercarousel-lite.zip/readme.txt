=== TWI Woocommerce Grid/Slider/Carousel Lite ===
Contributors: khairulalamruet
Donate link: http://codecanyon.net/item/woocommerce-product-slidercarouselgrid/7928428?ref=twibd
Tags: woocommerce slider, woocommerce carousel, woocommerce grids, slider, carousel, grid ,woocoomerce, vafpress
Requires at least: 3.0
Tested up to: 4.3
Stable tag: 1.0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Simple, easy and super flexible Awesome Woocommerce Grid/Slider/Carousel plugin for wordpress by TWI.

== Description ==

TWI Woocommerce Grid/Slider/Carousel Lite is super flexible responsive Woocommerce plugin.By this plugin you can make your Woocommerce products category wise smart grid,carousel,slider anywhere with Post, Custom Posts, Page, Widget as well as into your theme code by Shortcode/Widget with the powerful admin builder.You can define your grid with devices wise like Large Desktops(1200px and larger),Desktops & tablets landscape(960px to 1199px),Tablets portrait(768px to 959px), Phones landscape (480px to 767px), Phones portrait (up to 479px) etc. 

See [demo](http://twibd.com/codecanyon/woo/) for more information.

The lite version contains the following features:

* Woocommerce Category wise Slider/Carousel/Gird
* Easy shortcode builder.
* Device wise Slider/Carousel/Gird items define.
* Per page items define 
* Sales/Out of Stock/Featured Ribbon management
* Price Hide/show options
* Rating Hide/show options
* Cart Hide/show options
* Slider/Carousel Autoplay Control.
* Ready template.
* WPML Supported.
* Flexible Gird system.
* 100% responsive.

[DEMO](http://twibd.com/codecanyon/woo/)


= HINT: = 
>There is also a [pro version](http://codecanyon.net/item/woocommerce-product-slidercarouselgrid/7928428?ref=twibd) available with direct support and ton of features like more modes, Visual Composer support, setting an inital value, linking images and more...
>
>[View pro version](http://codecanyon.net/item/woocommerce-product-slidercarouselgrid/7928428?ref=twibd)


== Installation ==

You can install the plugin in two ways:

= From within WordPress plugin installation (recommended) =

1. Search for "TWI Woocommerce Grid/Slider/Carousel Lite"
1. Download it and then active it.

or

1. Upload and activate the file "twi-awesome-woocommerce-slider-carousel-free.zip" manually.

= From the WordPress plugins page =

1. Download the plugin, extract the zip file.
1. Upload the "twi-awesome-woocommerce-slider-carousel-free" folder to your /wp-content/plugins/ directory.
1. Active the plugin in the plugin menu panel in your administration area.

= Upgrade Notice =

Always upgrade to the newest release to profit from bugfixes and new features.

== Screenshots ==

1. Pro Version Shortcode Builder
2. Lite Version Shortcode Builder
3. Shortcode Button

== Changelog ==

= 1.0.0 =
* Intial public release


