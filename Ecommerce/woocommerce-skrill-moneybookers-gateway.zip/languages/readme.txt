Put localisation files (.po and .mo) in this folder.
