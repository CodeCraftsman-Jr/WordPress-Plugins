jQuery(document).ready(function($) {
	$('#skrill_redirect_message').show();
	$('#skrill_submit').hide();
	$('#skrill_form').submit();
});
