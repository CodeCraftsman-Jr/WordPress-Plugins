<html>
<head>

<link media="all" href="<?=$site->path?>/header.css" type="text/css" rel="stylesheet">
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="<?=$site->path?>/header_ie.css" />
<![endif]-->

<title>Terms and Conditions</title>
</head>
<body>
	
<div id="terms_popup">
	<h1>Terms and Conditions</h1>

	<?=$site->getTerms()?>
</div>

</body>
</html>