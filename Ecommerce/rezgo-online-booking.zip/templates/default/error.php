<div id="rezgo" class="wrp_list">

<div id="left_panel">
	<div class="breadcrumb"><h1 class="header">There was an error with your request</h1></div>

	<div class="item">

		<img src="<?=$site->path?>/images/error.png" align="left" style="padding-right:10px;">
		
		We are sorry for any inconvenience, but the system encountered an error while handling your request.<br>
		<br>
		Our staff have been alerted of this error automatically, you do not need to take any more steps to report this.<br>
		<br>
	 	please <a href="javascript:history.back();">click here</a> to go back to your previous page.
		
	</div>
		
</div>