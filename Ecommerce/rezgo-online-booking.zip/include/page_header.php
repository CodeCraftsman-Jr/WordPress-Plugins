<?php
	require( 'config.rezgo.php' );
	require( 'class.rezgo.php' );
?>