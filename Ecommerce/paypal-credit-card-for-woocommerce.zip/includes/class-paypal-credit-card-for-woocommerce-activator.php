<?php

/**
 * @class       PayPal_Credit_Card_For_WooCommerce_Activator
 * @version	1.0.0
 * @package	paypal-credit-card-for-woocommerce
 * @category	Class
 * @author      johnny manziel <phpwebcreators@gmail.com>
 */
class PayPal_Credit_Card_For_WooCommerce_Activator {

    /**
     * @since    1.0.0
     */
    public static function activate() {
        
    }

}
