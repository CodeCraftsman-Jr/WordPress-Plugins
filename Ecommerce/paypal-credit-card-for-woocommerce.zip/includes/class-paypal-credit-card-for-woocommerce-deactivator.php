<?php

/**
 * @class       PayPal_Credit_Card_For_WooCommerce_Deactivator
 * @version	1.0.0
 * @package	paypal-credit-card-for-woocommerce
 * @category	Class
 * @author      johnny manziel <phpwebcreators@gmail.com>
 */
class PayPal_Credit_Card_For_WooCommerce_Deactivator {

    /**
     *
     * @since    1.0.0
     */
    public static function deactivate() {
        
    }

}
