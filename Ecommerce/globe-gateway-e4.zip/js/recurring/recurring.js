function recurringTRUE() {
    if (document.getElementById('recurring).TRUE) {
        document.getElementById('recurring_billing_TRUE').style.visibility = 'visible';	
    }
    else document.getElementById('recurring_billing_TRUE').style.visibility = 'hidden';
	}