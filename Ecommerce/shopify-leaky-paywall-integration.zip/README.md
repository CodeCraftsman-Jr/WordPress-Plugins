Shopify->Leaky Paywall Integration Wordpress Plugin
==================================================

A really basic plugin that allows to import the emails of recent customers (last 6 hours) who bought and paid for particular product (see "Product ID" in Shopify admin panel) in your Shopify Store and gives them one-year subscription.
