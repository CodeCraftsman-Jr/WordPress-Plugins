=== WooCommerce Frontend Shop Manager - Free Version ===
Contributors: dzeriho
Tags: e-commerce, ecommerce, frontend, ipad woocommerce, iphone woocommerce, live editor, live product editor, live shop manager, product, product editor, shop manager, tabled product editor, woocommerce, woocommerce live manager
Donate link: http://www.mihajlovicnenad.com
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0.3
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The ultimate tool for managing WooCommerce shops, right at the frontend, featuring live product editing and full vendor support! - Mihajlovicnenad.com

== Description ==
The ultimate tool for managing WooCommerce shops, right at the frontend, featuring live product editing! It has never been this easy to manage a professional online store! WooCommerce Frontend Shop Manager integrates itself all over your shops frontend and adds the live editing product functionality. It supports product archives, single products, and even the shortcodes! All Wordpress templates are supported by default. This tool will improve your shop, and will save you a lot of time spent on managing your products. Well, WooCommerce just got better! Get up to 50% more time for you life! Check the demo at this link http://mihajlovicnenad.com/frontend-shop-manager/

GET PREMIUM VERSION HERE http://bit.ly/1EaU8Y5

Now you can easily edit your products from your shops frontend thanks to the WooCommerce Frontend Shop Manager plugin. Change prices, manage stock, even add taxonomy terms, categories and attributes or just add some new images to the product gallery. All live editing, directly from the site archives, single product pages, or even shortcodes. Works with EVERY template! Guaranteed!

* PRODUCT EDITING FOR TABLETS, HANDHELD, PHONE AND SMALL SCREEN DEVICES!

Editing products from the backend using a tablet or a phone is complicated. WooCommerce Frontend Shop Manager improves the product editing experience on these devices dramatically. The easiest product managing on the iPhone and iPad. Full support and quick controls right at your fingertips!

* EASY WOOCOMMERCE INTEGRATION

Plugin has no settings! It integrates itself in your shop automatically. Every user that has a role to manage the store will have the access to it just like he has to the product editing screen, only now on the frontend. The WooCommerce Frontend Shop Manager icons will appear on all possible products. On click the manager starts and the editing can start! Quickly and easily!

* MULTI VENDOR SUPPORT

Ignite WooCommerce Vendor Stores, WC Vendors, WooThemes Product Vendors all other vendor plugins are supported! Store vendors will only be able to edit their products.

* SUPPORTED WOOCOMMERCE PRODUCT SETTINGS

These options are already integrated. WooCommerce Frontend Shop Manager updates and bug fixes are free for a lifetime! New options will be added in the updates.

- Creating Simple, Grouped, External/Affiliate Products from the Frontend! v2.0
- Cloning and Deleting Products v2.0
- Managing Variations, Creating, Deleting v2.0
- Full Vendor Support! Vendor Editing Restriction Groups v2.0
- Product Content and Description v2.0
- Simple, Variable, External/Affiliate and Grouped Products Support!
- Product Name
- Product Slug
- Product Featured Image
- Product Gallery
- Prices, Sale Prices
- Schedule Sales
- Stock Management
- Product Grouping
- Product Categories, Tags
- Categories, Tags New Term Creation
- Product Attributes
- New Attribute and New Attribute Term Creation
- Variable Products
- Variable Attributes
- Variable Featured Images
- Variable Prices, Sale Prices
- Variable Schedule Sale
- Variable Stock Management
- External/Affiliate Product Links


* COMPATIBLE WITH ANY THEME!

Plugin is compatible with any theme. WooCommerce just got better!

A QUICK VIDEO GUIDE IS AVAILABLE HERE @ https://www.youtube.com/watch?v=8b4cLdiYqiE

GET PREMIUM VERSION HERE http://bit.ly/1EaU8Y5

== Installation ==
1. Navigate to Plugins>Add New and choose upload
2. Choose the woocommerce-frontend-shop-manager-free-version.zip archive and click upload
3. Navigate to Appearance>Plugins and activate
4. ..and the WFSM icons will appear all over your shop!


== Frequently Asked Questions ==
* Where can I get the WooCommerce Frontend Shop Manager premium version?

You can get the Premium version at this link http://bit.ly/1EaU8Y5

== Screenshots ==
1. WooCommerce Frontend Shop Manager Promo
2. WooCommerce Frontend Shop Manager Live Manager UI