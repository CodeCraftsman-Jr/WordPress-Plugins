<table class="foot">
    <tbody>
	    <tr>
	        <td class="company-details" style="border-top: 4px solid <?php echo $this->template_options['bewpi_color_theme']; ?>;"><p><?php echo nl2br( $this->template_options['bewpi_company_details'] ); ?></p></td>
		    <td class="payment" style="border-top: 4px solid <?php echo $this->template_options['bewpi_color_theme']; ?>;"><p><?php echo $this->template_options['bewpi_terms']; ?></p></td>
	    </tr>
    </tbody>
</table>