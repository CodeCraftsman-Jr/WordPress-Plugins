<?php
$name='SimSun';
$type='TTF';
$desc=array (
  'CapHeight' => 684,
  'XHeight' => 453,
  'FontBBox' => '[0 -141 996 855]',
  'Flags' => 4,
  'Ascent' => 855,
  'Descent' => -141,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$unitsPerEm=256;
$up=-86;
$ut=47;
$strp=254;
$strs=47;
$ttffile='C:/wamp/www/wordpress/wp-content/plugins/woocommerce-pdf-invoices/lib/mpdf/ttfonts/SimSun.ttf';
$TTCfontID='0';
$originalsize=10518797;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='simsun';
$panose=' 0 0 2 1 6 0 3 1 1 1 1 1';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 859, -141, 141
// usWinAscent/usWinDescent = 859, -141
// hhea Ascent/Descent/LineGap = 859, -141, 141
$useOTL=0x0000;
$rtlPUAstr='';
?>