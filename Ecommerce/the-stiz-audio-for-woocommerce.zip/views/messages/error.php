<div id="message" class="error" style="padding:10px;"><?php echo $message; ?></div>
