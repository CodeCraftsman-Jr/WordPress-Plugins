    <div class="wcjd-categories">
        <span>Categories: </span>
        <span><?php echo $categories; ?></span>
    </div>
<?php /* wcjd-product-meta div opened in views/product/author.php */ ?>
</div>
