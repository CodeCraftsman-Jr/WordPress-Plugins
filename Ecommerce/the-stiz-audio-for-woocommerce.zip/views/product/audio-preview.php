<audio src="<?php echo WCJDServeAudio::encode($previewUrl); ?>" class="<?php echo $className; ?>" type="audio/mpeg"></audio>
