<?php /* wcjd-product-meta div closed in views/product/categories.php */ ?>
<div class="wcjd-product-meta">
    <div class="wcjd-produced-by">
        <span>Produced by: </span>
        <span><?php echo $authorName; ?></span>
    </div>
