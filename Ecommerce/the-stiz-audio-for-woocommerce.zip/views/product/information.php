<a href="<?php echo $productUrl; ?>" rel="nofollow" class="button wcjd-information">i</a>
