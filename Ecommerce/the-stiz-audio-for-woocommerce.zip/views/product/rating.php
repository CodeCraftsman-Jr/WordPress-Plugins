<?php echo $rating; ?>
