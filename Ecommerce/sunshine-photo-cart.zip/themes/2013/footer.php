</div>

<?php do_action('sunshine_after_content'); ?>
<?php wp_footer(); ?>

</body>
</html>