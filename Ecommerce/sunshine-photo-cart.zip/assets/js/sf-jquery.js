jQuery(document).ready(function() {
	jQuery(".sf-tips").tooltip();
});