<p><strong>[status]</strong>: [status_description]</p>
[message]
<p><a href="[order_url]"><?php _e('Click here to view your order details','sunshine'); ?></a></p>
[signature]
