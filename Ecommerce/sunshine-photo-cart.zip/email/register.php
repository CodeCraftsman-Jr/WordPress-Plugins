		[message]
		<p><?php _e('Username','sunshine'); ?>: [username]<br />
		<?php _e('Password','sunshine'); ?>: [password]</p>
		[signature]
