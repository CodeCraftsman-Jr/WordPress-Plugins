<p><?php _e('Comment from','sunshine'); ?> [customer_name]</p>
<p>[comment]</p>
<p><a href="[siteurl]/wp-admin/post.php?post=[order_id]&action=edit">See order details</a></p>
