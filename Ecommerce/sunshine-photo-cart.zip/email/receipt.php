<p>[message]</p>
<h3 style="font-size: 14px;"><?php _e('Cart Items','sunshine'); ?></h3>
[items]
<h3 style="font-size: 14px;"><?php _e('Ship To','sunshine'); ?></h3>
[shipping_address]
<p><?php _e('If you have any questions or concerns about this order, simply reply to this email','sunshine'); ?></p>
[signature]
