<html>
<head>
	<title>[title]</title>
</head>
<body>

<table border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #EFEFEF; padding: 20px;">
	<tr>
		<td align="center" style="padding: 20px; font-size: 28px; color: #000; font-weight: bold;">[logo]</td>
	</tr>
	<tr>
		<td align="center">
			<table cellspacing="0" cellpadding="0" style="background-color: #FFF; padding: 30px; border-radius: 10px; max-width: 600px;" align="center">
			<tr>
				<td>
					<h1 style="font-size: 18px;">[title]</h1>
					[content]
				</td>
			</tr>
			</table>				
		</td>
	</tr>
</table>

</body>
</html>