		[message_content]
		[signature]
