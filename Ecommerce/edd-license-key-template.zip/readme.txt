=== EDD License Key Template ===
Contributors: Desertsnowman
Donate link: https://CalderaWP.com
Tags: edd, license, calderawp, license template, software license template
Requires at least: 3.9
Tested up to: 4.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a meta box to define a template for an Easy Digital Downloads Software License key

== Description ==

Allows you to define the structure of an Easy Digital Downloads Software License key.

example: `CWP-####-********-**##-**` would generate `CWP-2827-HS982KSI-A281-09`

A free plugin by [CalderaWP](https://CalderaWP.com).

== Installation ==

Install the plugin through the WordPress Plugins Installer or upload extracted folder to the plugins directory of your content directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Does It Got To Eleven? =

Of course it does.

== Screenshots ==

1. Metabox with a set template

== Changelog ==

= 0.1.0 =
Initial Version

== Upgrade Notice ==
Nothing to report
