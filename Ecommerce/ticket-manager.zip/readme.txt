=== Ticket Manager ===
Contributors: Brizgo Technology Solutions 
Tags: Widget, Tickets, Events
Requires at least: 1
Tested up to: 3.5.1
Stable tag: 1.3.3

The Ticket Manager helps you compare tickets found on sites like Stubhub, Ebay.



== Description ==

The Ticket Manager helps you compare tickets found on sites like Stubhub, Ebay, etc.  in order to find the best prices and deals from the secondary ticket market. The search bar is easy to use, and has a user-friendly interface, designed to get you the best ticket deals on the web.  Each ticket is graded out of 100, and you can sort the results by price and seat location. 
There is a venue map and a 3D view for the larger venues.
 

== Installation ==

1. Download and extract the zip archive    
2. Upload \`ticket-manager\` folder to `/wp-content/plugins/`    
3. Activate the plugin through the  Plugins menu in WordPress    
4. Add the widget to a sidebar and configure the options as desired.


== Frequently Asked Questions ==

Nothing right now.
