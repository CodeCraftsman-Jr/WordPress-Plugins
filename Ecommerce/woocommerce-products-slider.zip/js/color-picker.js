	jQuery(document).ready(function(jQuery)
		{	


			jQuery('#wcps_cart_bg, #wcps_items_title_color, #wcps_items_price_color, #wcps_cart_text_color, #wcps_slider_pagination_bg, #wcps_slider_pagination_text_color').wpColorPicker();
					
					


		});