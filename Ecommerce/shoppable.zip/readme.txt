=== Shoppable ===
Contributors:
Donate link:
Tags: ecommerce, shop, shoppable
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 4.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shoppable's universal checkout plugin allows you to host a single multi-retailer shopping bag and checkout on your website. Our technology transforms your content into Shoppable content. This full-service e-commerce technology is used by everyone from bloggers to internationally known digital media companies. Now you can monetize your site through e-commerce without every having to forward your reader to a retailers website. Sign up for a free account now at http://publishers.shoppable.com/signup and install this plugin to get started.
