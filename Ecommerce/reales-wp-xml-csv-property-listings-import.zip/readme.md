#Reales Add-On

## Add-On Issues

* Show in slideshow not supported. Image attachments have a custom field (show-in-slideshow) that when set to 'on' will display that field in the site's slideshow.