=== Gutscheinfeed.com ===
Contributors: Bastian Schneider
Donate link: http://gutscheinfeed.com/
Tags: Gutscheine, Coupons, Gutscheinblog, Gutscheinfeed
Requires at least: 2.0.2
Tested up to: 4.1.1
Stable tag: trunk

Aktuelle Gutscheine in Ihrem WordPress-Blog - Gutscheinfeed.com Plugin coupons for your website (currently only german online shops).

== Description ==

English version below

Betreiber eines Gutscheinblogs kennen das Problem - die Aktualisierung der Gutscheinseite mit aktuellen Gutscheinen nimmt viel Zeit in Anspruch. Das Gutscheinfeed.com Plugin nimmt Ihnen diese Arbeit an und blogt auf Wunsch vollautomatisch immer neue Gutscheine.

Gutscheine werden wahlweise als publizierter Blogpost oder als Entwurf zur weiteren Bearbeitung gespeichert. Auch ein Sidebar-Plugin mit neuen Gutscheinen ist Teil des Plugins.

Mit dem Gutscheinfeed.com Plugin verdienen Sie Geld mit Ihrer Webseite, hinterlegen Sie einfach Affiliate Links zum entsprechenden Anbieter (20 Prozent der Klicks sowie Links zu Anbietern bei denen Sie keinen Link hinterlegt haben werden ueber Gutscheinfeed.com weitergeleitet).

Alternativ können Sie <a href="http://bee5.de/bee3i2pPMJI" target="_blank">Bee5.de</a> nutzen, damit werden Links automatisch durch entsprechende Affiliate-Links ersetzt und Sie müssen sich um nichts mehr kümmern, einfach Bee5.de Nutzungs-ID im Plugin hinterlegen.

Das Gutscheinfeed.com Plugin listet im Moment nur deutsche Online-Shops, weitere Laender werden aber folgen.


--English version--

If you run an Coupon Blog or Gutscheinblog you know how hard it is to always keep it up to date. This Plugin offers you a possibility to always have new coupons listed on your blog.

You can have new coupons published as blogpost or as draft for later editing. Gutscheinfeed.com plugin also features a sidebar widget with latest coupons you can use on a widgetized WordPress Theme.

Earn money with Gutscheinfeed.com plugin by using your own affiliate links for shops (20 percent of clicks and clicks to shop where you have no affiliate link are redirected through Gutscheinfeed.com)

You may also use <a href="http://bee5.de/bee3i2pPMJI" target="_blank">Bee5.de</a> which automatically ads redirects to many coupons.

Gutscheinfeed.com Plugin currently only supports german Online Shops but will be extended to other countries.

== Installation ==

Simply install the plugin and adjust settings on the Gutscheinfeed Settings Page.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 2.5 =
* fixed a php warning

= 2.4 =
* fixed a bug custom logos

= 2.3 =
* fixed a bug in bee5 redirect

= 2.2 =
* fixed a bug with redirecting

= 2.1 =
* Integration of <a href="http://bee5.de/bee3i2pPMJI" target="_blank">Bee5.de</a> API which automatically inserts redirects for many coupons

= 2.0 =
* smaller enhancements
* affiliate networks are shown for links

= 1.5 =
* import can be triggered by cronjob now

= 1.4 =
* easier start
* Bugfixes
* Links to affiliate networks

= 1.3 =
* Bugfix

= 1.2 =
* Bugfixes

= 1.1 =
* change affiliate links
* logo is now available
* manual import
* smaller improvements

= 1.0 =
* first public release
