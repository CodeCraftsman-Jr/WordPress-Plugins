=== Exchange === 

Contributors: Naira Jorge
Donate link: http://www.naira-wp.com/donation/ 
Tags: money, currency, currencies, converter, cotation, exchange;
Plugin URI: http://www.naira-wp.com
Requires at least: 2.0.2 
Tested up to: 3.4.1
Author: Naira Jorge
Author URI: http://www.naira-wp.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Copyright 2012 Naira  (email : nairawordpress@gmail.com)
Stable tag: 1.0.8

Here is a short description.  THIS WIDGET DOES NOT FUNCTION ANY MORE. It needs to be paid directly to the Exchange API.

= Description ==





== Installation ==

1. Download and extract winzip archives;
2. Upload `Exchange` to the `/wp-content/plugins/` directory;
3. Activate the plugin through the 'Plugins' menu in WordPress;
4. Go to Appearance/Widgets area and drag-and-drop the widget in the sidebar of your preference;
5. Settings (choose title and author's credit or not);

== Frequent Asked Questions ==

Which version of PHP does this plugin work with?

PHP 5.2 is the minimum current requirement for WordPress. 
This plugin requires at least PHP version 5.2.1 due to having to decode JSON responses from the Open Source Exchange Rates API.

== Screenshots ==

1. The basic layout;
2. The Exchange API;



== Changelog ==

= 1.0.8 =




== Upgrade Notice ==

Manage option page; 

== Arbitrary section ==


== A brief Markdown Example ==

