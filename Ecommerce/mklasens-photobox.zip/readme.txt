=== mklasen's Photobox ===
Contributors: mklasen
Tags: mklasens, mklasen, photobox, photo, box, lightbox, prettyphoto, pop-up, popop, photo, image, display
Donate link: http://plugins.mklasen.com/donate/
Requires at least: 3.5
Tested up to: 4.1
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Make direct image links open in prettyphoto

== Description ==
prettyPhoto is a great jQuery lightbox clone that i often use in projects. Again, a plugin to make it easier. :-)
This plugins search to every image that is inside a link and adds prettyPhoto parameters to the link.

Works for Gallery and single images, make sure to choose for media file instead of media attachment when you place an image.

== Installation ==
I recommend to install plugins via your WordPress Dashboard.

For manual installation:
Download mklasen's Photobox Plugin (http://wordpress.org/extend/plugins/mklasens-photobox/).

To install mklasen's Photobox follow these steps:

- Upload the folder \"mklasens-photobox\" to your WordPress plugin folder (/wp-content/plugins/)
- Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
No Questions yet!
Ask one via the support forums, send an e-mail.. You'll find your way.. :-)

== Changelog ==
- First Release


== Screenshots ==

1. Front view of mklasen's Photobox. It's prettyPhoto displaying the image. Thank you prettyPhoto!
2. Yeah, that's the plugin screen, i know. That's the only thing you'll find from this plugin in WP admin.