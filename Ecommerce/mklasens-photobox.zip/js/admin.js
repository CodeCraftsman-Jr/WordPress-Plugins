jQuery(document).ready(function ($) {
	
});