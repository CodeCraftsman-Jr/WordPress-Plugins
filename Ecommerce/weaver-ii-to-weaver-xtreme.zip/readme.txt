=== Weaver II to Weaver Xtreme ===
Tags: Aspen Plugins
Contributors: Bruce Wampler
Requires at least: 3.9
Tested up to: 4.1
Stable tag: 1.0

Weaver II to Weaver Xtreme Settings Converter

== Description ==

This plugin will non-destructiely convert your Weaver II Themes settings to Weaver Xtreme Theme settings.

Please read instructions on the Help tab.


== Installation ==

Please use the Plugin Add Plugin page to install this plugin.

Read the instructions on the Help tab.

== Copyrights ==

* Weaver II to Weaver Xtreme is Copyright (c) 2015 by Bruce E. Wampler. It is licensed under GPL Version 2.

== Changelog ==
= 1.0 =
* Added: Weaver II Pro to Weaver Xtreme shortcode settings
* Added: a couple of new setting conversons

= 0.1 =

* Initial release
