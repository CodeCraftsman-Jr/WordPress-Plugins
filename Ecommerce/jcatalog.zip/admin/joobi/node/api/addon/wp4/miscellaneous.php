<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');










class Api_Wp4_Miscellaneous_addon {





	public function getAllWidgetsIDforFeatured(){

		$allWidgetsA=get_option( JOOBI_PREFIX . '_site_widgets' );

		

		
		return array();

	}
}