<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');




 class Api_Netcom_Content_addon {








	public function processContent(&$content){
	}






	public function replaceThemeTag($theme){
		return $theme;
	}

}