<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');






class Address_Mapservice_type extends WTypes {





var $mapservice = array(

		1 => 'Google',

		2 => 'Yahoo'

	);


}