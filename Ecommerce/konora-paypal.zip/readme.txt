=== Konora paypal ===
Contributors: DM Konora, wowdinamica, DMK-RC
Requires at least: 3.4
Tags: konora,paypal,payment,integration
Tested up to: 3.9.1
Stable tag: 1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy way to create a php file to redirect to paypal payment system 

== Description ==
Just fill the form in admin page and click \"crea\" button to create a file php whit inside a form with the information to send a paypal payment requeset. Don\'t need have a paypal account, of course i hope for you to put an email that can take the money :) (this first version is in italian only)

== Installation ==
1) Decomprimi il pacchetto contenente il plugin della giusta directory di WordPress
2) Attiva il plugin dal menu \'Plugins\' in WordPress
3) Apri la pagina \'KPP\' dal menu a destra

== Screenshots ==
1. Lista file generati
2. Pagina per creazione dei file

== Changelog ==

= 1.6 =
* Aggiunto Copy to Clipboard
* Migliorata pagina delle informazioni

= 1.5 =
* Aggiunto FontAwesome Icon
* Aggiornato Logo e Social Media
* Corretto Bug link in elenco dei file
* Aggiornate icone con FontAwesone Icon

= 1.4 =
* Controllo su file se già esistente
* Cambio directory dove salvare i files
* Aggiunto sanitize input
* Corretti PHP short tags


= 1.3 =
* Risolto visualizzazione campi non allineata
* Inserito coming soon... nella tabella 
* Rinominata cartella images ed aggiunto logo konora
* Aggiunto logo icona konora in alto a destra
* Aggiornato tab con Informazioni

= 1.2 =
* Inseriti tab per una migliore visualizzazione divisa
* Creata tabella per migliore visualizzazione della lista dei file
* Aggiunti campi azione alla tabella
* Risolto radio button visualizzazione scelta tipo di pagamento


= 1.1 =
* Migliorata grafica admin
* Corretto bug nella scelta dei prezzi
* Aggiunti controlli sulle caselle obbligatorie