<?php

/**
 * @link       http://shopitpress.com
 * @since      1.0.4
 *
 * @package    Sip_Reviews_Shortcode_Woocommerce
 */
