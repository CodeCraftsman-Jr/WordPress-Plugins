<div class="error">
	<p><?php _e('"WooCommerce - Reviews Shortcode" Error! WooCoomerce plugin not active.'); ?></p>
</div>