<?php
/**
 * Do not put custom translations here. They will be deleted on mp_easy_icons updates.
 *
 * Keep custom mp_easy_icons translations in /wp-content/languages/mp_easy_icons/
 */