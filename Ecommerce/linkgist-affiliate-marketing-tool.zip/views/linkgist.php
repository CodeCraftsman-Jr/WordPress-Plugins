<script type="text/javascript">
var lg_settings = {<?php echo $settings; ?>};
(function(){
var lg = document.createElement('script'); lg.type = 'text/javascript'; lg.async = true;
lg.src = '//cdn.linkgist.com/linkgist.js';
var fs = document.getElementsByTagName('script')[0]; fs.parentNode.insertBefore(lg, fs);
})();
</script>
