=== Lifestream.fm ===
Contributors: buzink
Donate link: http://robertbuzink.com/contact/
Tags: lifestream, lifestream.fm, widget
Requires at least: 2.6.2
Tested up to: 2.6.2
Stable tag: trunk

Provides a sidebar widget for your Lifestream.fm lifestream.

== Description ==

Provides a sidebar widget for your Lifestream.fm lifestream.

Lifestream.fm is a free media and social aggregator that will keep you and your friends informed about what you're doing online at a glance and in realtime. With Lifestream.fm you can put all your profiles and activity from your favorite web services all on one page, making it easy for your friends to see your newest bookmarks, your favorite videos, your tweets, your wikipedia edits, photos you've uploaded, your newest blog posts, and more.

Any questions, requests, praises go to http://robertbuzink.com/2008/lifestreamfm-wordpress-plugin/ .

== Installation ==

Upload the Lifestream fm plugin to your blog, Activate it, then insert the badge code you got from http://lifestream.fm/badges under settings/lifestreamfm. Add the Lifestream fm widget to a sidebar under design/widgets.

1, 2, 3, 4: You're done!

== Frequently Asked Questions ==

= Give me a quick reason to choose this plugin over other lifestream plugins? =

This is the only lifestream plugin that can stream your wikipedia edits.

= What are other reasons to choose this plugin over other lifestream plugins? =

This plugin uses lifestream.fm to stream your online life to your blog. Lifestream is better than other free online services I tried, like friendfeed. Because the hard thinking is done by lifestream.fm, the lifestream doesn't drain your wordpress resources. Lifestream.fm adds new possible streams all the time.

= Where can I say that I like your plugin? =

http://robertbuzink.com/2008/lifestreamfm-wordpress-plugin/

Also let me know if you hate it. And tell me why :-). 

== Screenshots ==

1. You'll get something like you see in the sidebar on the right.
