<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://www.xolluteon.com/
 * @since      1.0.0
 *
 * @package    Xox_Woo_Carousel
 * @subpackage Xox_Woo_Carousel/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
