<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

include WC_Boleto::get_plugin_path() . 'includes/banks/cef/layout.php';
