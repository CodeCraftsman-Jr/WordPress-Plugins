=== BannerWoo ===
Contributors: pasqualebucci
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=PKMBP2CF3M8SQ
Tags: WooCommerce, banner, sell banner, advertising, adv, banner ads, sell, multilingual
Requires at least: 3.9
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Sell banner ads on autopilot with WooCommerce. Simple, clean and lightweight.

== Description ==

= Create the product/banner. =
Set the price per time unit (day, week, month, year). Choose the size.

= Decide where to insert. =
You can place your banner just created in the code, in any page (with a shortcode) or in a widget in any sidebar.

= The banner is ready now! =
The banner is ready to be purchased as a WooCommerce product!

Full documentation is available [here](http://www.bannerwoo.com/).

[youtube https://www.youtube.com/watch?v=50J2eRDMFqo]


= BannerWoo Needs Your Support =

If you enjoy using BannerWoo and find it useful, please consider [__making a donation__](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=PKMBP2CF3M8SQ). Your donation will help encourage and support the plugin's continued development and better user support.


== Installation ==

This section describes how to install the plugin and get it working.

1. Download and install the Plugin
1. Upload the plugin folder to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

None.  Yet. :)


== Screenshots ==



== Changelog ==

= 1.0 =
* First release.

== Upgrade Notice ==

= 1.0 =
* First release.