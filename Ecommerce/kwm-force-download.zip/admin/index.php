<?php 

//include functions admin
require_once('functions.php');

?>