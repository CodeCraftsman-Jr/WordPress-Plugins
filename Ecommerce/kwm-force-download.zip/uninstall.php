<?php 

//Garantindo que é o wordpress que chama este ficheiro e que realmente está a desinstalar o plugin

if(! defined('WP_UNINSTALL_PLUGIN')){

	die();

}
//if single site

if(!is_multisite()){

    delete_option('kwm_force_download');

}



?>