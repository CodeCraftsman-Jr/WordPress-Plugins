// JavaScript Document
jQuery(window).load(function(){
	var container_image = jQuery('.single_product_display .imagecol');
	container_image.children('a').remove();
	//container_image.children('a').remove();
	//container_image.children('img').remove();
});
