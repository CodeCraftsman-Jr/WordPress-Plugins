<div style="min-height:400px;">
	<div id="csmtp_test_result"></div>
	<button id="csmtp_test_init_button" class="button button wp-baldrick" data-action="csmtp_send_test" data-before="csmtp_prepare_test" data-callback="csmtp_end_test" data-load-element="#caldera-smtp-mailer-save-indicator" data-active-class="none" data-target="#csmtp_test_result"><?php _e( 'Send a Test Email', 'caldera-smtp-mailer' ); ?></button>

</div>