=== Caldera SMTP Mailer ===
Contributors: Desertsnowman
Tags: SMTP, wp_mail, mailer, email, mandrillapp, sendgrid
Requires at least: 3.9
Tested up to: 4.0
Stable tag: 1.0.1
License: GPLv2

Send system emails through SMTP server

== Description ==
Caldera SMTP Mailer is not groundbreaking in any way. There are many SMTP plugins around some good some not so good. This is just to take away all the mystery with a to-the-point solution for configuring wp_mail ( and in turn phpmailer ) to send through SMTP over standard phpmail.


== Installation ==

Upload the searchd-actions folder to /wp-content/plugins/
Activate the plugin through the 'Plugins' menu in WordPress
Navigate to 'Settings -> Caldera SMTP' in wp-admin.
Enter Your SMTP Details.

== Frequently Asked Questions ==
none yet.

== Screenshots ==
1. Main Admin.
2. Extra settings to set the from name and from email.
2. Manually set the hook priority in case another plugin is trying to overriding the settings.


== Changelog ==

= 1.0.1 =

Fixed a bug with saving when Caldera Forms is installed.


= 1.0.0 =
Initial Release

== Upgrade Notice ==
None.