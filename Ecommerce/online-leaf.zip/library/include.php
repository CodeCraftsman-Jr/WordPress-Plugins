<?php

require_once 'functions.php';
require_once 'class.php';

?>