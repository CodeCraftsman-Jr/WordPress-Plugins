<?

header("HTTP/1.1 404 Not Found");
header("Location: http://www.onlineleaf.com/");
exit();

?>