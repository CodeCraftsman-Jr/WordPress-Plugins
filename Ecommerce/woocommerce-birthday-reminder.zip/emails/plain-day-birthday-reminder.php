<?php
/**
 * E-mail Lembrete Aniversário
 *
 * @author Carlos Cardoso Dias
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<?php echo $email_heading; ?>

<?php echo $message; ?>
