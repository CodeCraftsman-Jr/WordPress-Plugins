(function($) {
  // Refresh the page without resending POST
  setTimeout(function(){ window.location = window.location.href; }, 3000);
})(jQuery);
