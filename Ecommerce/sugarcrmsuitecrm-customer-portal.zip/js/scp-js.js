jQuery(document).ready(function() {
	jQuery('#demo').DataTable();    
} );