<div class="review-stars-rated">
    <ul class="review-stars">
        <li><span class="dashicons dashicons-star-empty"></span> </li>
        <li><span class="dashicons dashicons-star-empty"></span> </li>
        <li><span class="dashicons dashicons-star-empty"></span> </li>
        <li><span class="dashicons dashicons-star-empty"></span> </li>
        <li><span class="dashicons dashicons-star-empty"></span> </li>
    </ul>
    <ul class="review-stars filled"  style="width:<?php echo $rated*20; ?>%;">
        <li><span class="dashicons dashicons-star-filled"></span> </li>
        <li><span class="dashicons dashicons-star-filled"></span> </li>
        <li><span class="dashicons dashicons-star-filled"></span> </li>
        <li><span class="dashicons dashicons-star-filled"></span> </li>
        <li><span class="dashicons dashicons-star-filled"></span> </li>
    </ul>
</div>