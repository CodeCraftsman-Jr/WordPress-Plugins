=== Nextclick Page Recommendations ===
Contributors: LeadBullet S.A
Donate link: http://www.leadbullet.pl/
Tags: widget, nextclick, leadbullet, seo
Requires at least: 2.8
Tested up to: 4.1.1
Stable tag: 2.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Comfortable way of serving page recommendations using Nextclick widget at any of your WP sites.

== Description ==

Comfortable way of serving page recommendations using Nextclick widget at any of your WP sites.

== Installation ==

Remember: You should already have your Nextclick widget configured via your http://www.nextclick.pl publisher account.

1. Upload `Nextclick Page Recommendations` widget to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Put the widget in a post/page sidebar and fill the widget key (required) as well as its type according to your Nextclick widget configuration.

== Frequently Asked Questions ==

== Screenshots ==

1. Nextclick widget
2. Widget code
3. Plugin inserted in left column

== Changelog ==

= 1.0.0 =

First launch of official Nextclick Page Recommendations widget (by LeadBullet S.A)

= 1.1.0 =

Overload of neatest_trim function which occasionally happens to be missing in some WordPress instances

= 1.2.0 =

Strip html tags in page title and page description

= 1.3.0 =

Do not collect category and archive pages

= 1.4.0 =

Do not collect gallery pages, unnecessary forum pages & shortcode descriptions

= 1.5.0 =

Updated page type classification requirements + serving https sites

= 1.6.0 =

Added field for custom domain

= 1.7.0 =

Strip html comment tags from collected post content

= 1.8.0 =

Allow for not collecting data directly from WordPress available info (let widget collect data from page og & meta tags).
Domain and widget collecting type options moved to hidden advanved options.

= 1.9.0 =

Pass post tags to widget

= 2.0.0 =

Support for new markets

= 2.0.1 =

New widget type (carousel)

== Upgrade Notice ==
