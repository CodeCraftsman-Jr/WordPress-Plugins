	jQuery(document).ready(function($)
		{	


			//$('.sticker-text-font-color').wpColorPicker();
					
					


		});