=== Linkflora Affiliate===
Contributors: Linkflora
Tags: affiliate program,make money,widget,plugin,sidebar
Requires at least: 2.8
Tested up to: 2.9.1
Stable tag: 1.7.9.3

Widget for the Linkflora affiliate program - Fresh cut flowers with free delivery anywhere in the world.

== Description ==

= English =
The module is for people who own a website based on WordPress CMS and would like to gain additional profits. 
We welcome you to join our affiliate system and earn 15% commission from every sale made by a customer 
that is transferred to us from your website. This enables you to earn high profits by helping us sell flowers 
with free delivery to any country in the world!

You can see the working demo here [Linkflora Affiliate Program Widget](http://forex.home.pl/wordpress/ "Flower Delivery Widget") 

== Installation ==

* Download 'wp_linkflora_affiliate_en.zip' to your computer and unzip it.
* Upload `wp_linkflora_affiliate_en` folder to the `/wp-content/plugins/` directory
* Once you upload the plugin activate it through the 'Plugins' menu in WordPress
* Finally, add the widget to your sidebar through the 'Appearance > Wigdets' menu

or simply download 'wp_linkflora_affiliate_en.zip' to your computer and use the 
upload plugin functionality of the WordPress CMS package.

== Registration ==

Please note that you first need to register. 
This will enable us to identify and track orders placed via your website and provide you 
with statistics and your earnings within our program after you login to our backoffice system.  
Affiliate registration can be done via a simple application form available at:

[Linkflora Affiliate Program registration](http://www.linkflora.com/index.php?action=program_afiliacyjny&lang=en)

