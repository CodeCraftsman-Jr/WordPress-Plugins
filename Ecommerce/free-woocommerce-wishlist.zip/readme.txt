=== Free WooCommerce Wishlist ===
Contributors: alancf
Tags: woocommerce, free, wishlist
Requires at least: 4.0
Tested up to: 4.2.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple and free wishlist plugin to use with WooCommerce.

== Description ==

A simple and free wishlist plugin to use with WooCommerce.

== Installation ==

1. Upload free-woocommerce-wishlist to the `/wp-content/plugins/` directory
2. Go to the plugins page and activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

== Upgrade Notice ==
