=== Plugin Name ===
Contributors: dbkdev
Donate link: http://dbk.nl/
Tags: booking, hotels, reservations, holiday
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 3.5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin makes bookings available through Simpel Reserveren.

== Description ==

This plugin makes bookings available through the Simpel Reserveren Booking API.

== Installation ==


1. Upload `simpelreserveren-3.0/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Give 2 of your pages the correct template (search and booking)
4. Place widgets in the new sidebar areas


== Screenshots ==



== Changelog ==

= 1.0 =
* Initial release.