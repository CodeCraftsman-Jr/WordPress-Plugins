<?php
/**
 * 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} ?>

<div id="message" class="updated" style="padding: 10px">
	<div>
		<div><strong><?php echo $message; ?></strong></div>
	</div>
</div>