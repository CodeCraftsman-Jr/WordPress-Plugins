<?php
/**
 * 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} ?>

<div id="message-check-email-error" class="error" style="padding: 10px; display: none;">
	<div>
		<div><strong class="text"></strong></div>
	</div>
</div>

<div id="message-check-email-succeeded" class="updated" style="padding: 10px; display: none;">
	<div>
		<div><strong class="text"></strong></div>
	</div>
</div>