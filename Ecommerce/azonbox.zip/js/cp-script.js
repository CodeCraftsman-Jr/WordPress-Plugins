jQuery(document).ready(function($){
    $('.azonbox-color-field').wpColorPicker();
});