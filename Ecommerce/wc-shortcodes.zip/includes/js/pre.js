( function( $ ) {
	"use strict";

	$(document).ready(function(){
		prettyPrint();
	});
} )( jQuery );
