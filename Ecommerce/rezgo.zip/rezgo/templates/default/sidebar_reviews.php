  
  <div class="rezgo-review">
    <h3 class="text-center">
      <i class="fa fa-thumbs-up"></i>&nbsp;<i class="fa fa-thumbs-up"></i>&nbsp;<i class="fa fa-thumbs-up"></i>
      &nbsp;Reviews&nbsp;
      <i class="fa fa-thumbs-down"></i>&nbsp;<i class="fa fa-thumbs-down"></i>&nbsp;<i class="fa fa-thumbs-down"></i>
    </h3>
    <dl class="dl-horizontal">
      <dt><span class="rezgo-star-rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i></span></dt>
      <dd>really enjoy this beautiful part of island and atmosphere. Enjoy the lesson.</dd>
      <dt><span class="rezgo-star-rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i></span></dt>
      <dd>Enjoy the lesson.</dd>
      <dt><span class="rezgo-star-rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i></span></dt>
      <dd>It's OK.</dd>
      <dt><span class="rezgo-star-rating"><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i></span></dt>
      <dd>Awfful!</dd>
    </dl>
  </div><!-- // .rezgo-review -->
