<div class="container-fluid">

  <div class="jumbotron">
    <h2 id="rezgo-terms-head">Booking Terms</h2>
    
    <div class="row">
    	<div class="rezgo-cart-wrapper"><?=$site->getPageContent('terms')?></div>
    </div>
    
  </div>

</div>	

