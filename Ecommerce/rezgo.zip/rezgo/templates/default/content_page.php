<div class="container-fluid">

  <div class="row">
  
    <h1 id="rezgo-about-head"><?=$title?></h1>
    <div id="rezgo-about-content"><?=$site->getPageContent($page)?></div>
  
  </div>
		
</div>