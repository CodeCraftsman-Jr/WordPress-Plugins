<?php
$rezgoPage = $_REQUEST['mode'];
include_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . $rezgoPage . '.php');