<?php
/**
 * Forms.
 *
 * Copyright: © 2012 (coded in the USA)
 * {@link http://www.websharks-inc.com XDaRk}
 *
 * @author  JasWSInc
 * @package XDaRk\Core
 * @since   120318
 */
namespace xd_v141226_dev {
    if (!defined('WPINC')) {
        exit('Do NOT access this file directly: '.basename(__FILE__));
    }

    /**
     * Forms.
     *
     * @package XDaRk\Core
     * @since   120318
     *
     * @assert ($GLOBALS[__NAMESPACE__])
     */
    class forms extends framework
    {
    }
}
