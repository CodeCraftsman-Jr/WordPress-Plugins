=== Plugin Name ===
Plugin Name: FAKE About Me

 

Description: Create a Fake identities or just create your own about me description, creates a new widget that allow you to choose your diferent identities.



Author: Brlocky

Author URI: http://www.gabyweb.com/

Plugin URI: http://wordpress.org/extend/plugins/fake-about-me-fake/



Contributors: Brlocky



Version: 2.0.2



Tags: widget, fake about me, fake identity, fast about me, easy about me


Requires at least: 3.0.1

Tested up to: 3.3.2

Stable tag: 2.0.2



== Description ==

 

Create a Fake identities or just create your own about me description, creates a new widget that allow you to choose your diferent identities.

 

== Installation ==



This section describes how to install the plugin and get it working.



e.g.



1. Upload "fake-about-me-fake" directory to "/wp-content/plugins/"

2. Activate the plugin through the "Plugins" menu in WordPress

3. Create a new Identity

4. Add the Widget in your templates and configure




== Frequently Asked Questions ==

= A question that someone might have =
An answer to that question.




== Screenshots ==


****soon***

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, "/tags/4.3/screenshot-1.png" (or jpg, jpeg, gif)

2. This is the second screen shot



== Upgrade Notice ==
Fix Uri to Plugin inside readme.txt
Fix path to plugin
I18n system is now fully working




== Changelog ==

= 2.0.2 =
* fix version again :)

= 2.0.1 =
* fix tag version in readme.txt

= 2.0 =
* fix uri to plugin in readme.txt

= 1.0.2 =

* fix path to plugin ( fake-about-me to fake-about-me-fake )

= 1.0.1 =

* add language system, and PT Language


= 1.0 =

* Just Created.