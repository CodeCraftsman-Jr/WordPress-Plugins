<div style="margin: 10px;text-align: center;"><img  src="<?php echo plugins_url("/assets/images/footer.png" , dirname(__FILE__));?>"/></div>
