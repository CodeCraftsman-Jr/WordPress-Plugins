<?php

/**
 * Fired during plugin activation.
 *
 * @package    AllClients
 * @subpackage AllClients/core
 */
class AllClients_Core_Activator {

	/**
	 * Fires on activation.
	 */
	public static function activate() {
	}

}
