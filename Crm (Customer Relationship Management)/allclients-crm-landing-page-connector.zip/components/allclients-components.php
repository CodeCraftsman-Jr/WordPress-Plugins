<?php
return array(
  array (
  'name' => 'landing-pages',
  'namespace' => 'Landing_Pages',
  'options' => 
  array (
    'title' => 'Landing Pages',
    'post_type' => 
    array (
      'type' => 'ac_landing_page',
      'name' => 'Landing Pages',
      'singular_name' => 'Landing Page',
      'menu_icon' => 'dashicons-megaphone',
    ),
  ),
  'enabled' => true,
),
);
