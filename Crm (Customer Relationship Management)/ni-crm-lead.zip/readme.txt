=== Ni CRM Lead ===
Contributors: Anzar Ahmed
Tags: Lead, CRM, Follow Up, CRM Lead,CRM Follow Up, Lead Follow Up, Follow Up History, Vendor, Customer, User, Customer services, Customer information, wordpress crm, wordpress lead, crm plugin, lead plugin,customer inquiry form, inquiry follow, inquiry followup, Customer inquiry  
Requires at least: 4.1.1
Tested up to: 4.1.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ni CRM Lead  is a plugin for wordpress that allows you to store the cutomer inquiry for different services and products.

== Description ==

Simple lead create plugin for wordpress. Its help to main tain the customer or vendor information with follow up history. Ni CRM Lead  is a plugin for wordpress that allows you to store the cutomer inquiry for different services and products.

Some Features.

* Fast And Easy Install
* Add New Customer
* Add New Inquiry 
* Add Update, Delete Follow Up
* Add new Follow up
* Add, Delete, Service, Product and status 



== Installation ==

1. Use the WordPress plugin installer or upload files to WordPress plugin directory.
1. Activate plugin from admin panel.
1. Refer image for more detail. 

== Frequently Asked Questions ==

= Where i can get help? =

Click on support tab or email : i.anzar14@gmail.com

= Do you customize this plugin? =

Yes, as per requirement we can customize this plugin.

== Screenshots ==

1. Add New Lead
2. Lead List.
3. How to add Follow up.
4. Add Follow Up. 

== Changelog ==

1.0 - Initial relese

== Upgrade Notice ==

New Features add upgrade please.