<?php
/*
Plugin Name: Ni CRM Lead
Plugin URI: http://mywebdesire.com/
Description: Simple lead create plugin for wordpress. Its help to main tain the customer or vendor information with follow up history.
Version: 1.0
Author: Anzar Ahmed
Author URI: http://mywebdesire.com/
License: GPLv2
*/

include_once("include/ni-lead.php");
$obj =new  Ni_Lead();

?>
