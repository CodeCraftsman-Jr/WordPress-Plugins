=== Malaria No More Plugin ===
Contributors: Guy
Tags: news, widget, sidebar, links, plugin, malaria, rss feed, newsticker, malaria no more
Requires at least: 2.3
Tested up to: 3.0
Stable tag: 1.0

The Malaria No More Plugin adds a customizable widget which displays the latest posts and updates from MalariaNoMore.org. It can be integrated anywhere in the blog. This Newsticker shows up the last five or more posts and is a great solution to help spread the word about Malaria and what people can do to help, as well as what others are doing about it.

== Description ==

The Malaria No More Plugin adds a customizable widget which displays the latest posts and updates from MalariaNoMore.org. It can be integrated anywhere in the blog. This Newsticker shows up the last five or more posts and is a great solution to help spread the word about Malaria and what people can do to help, as well as what others are doing about it.

*Feature List*

* customizable widget
* displays a user-defined number of links
* title shortening

== Installation ==

*Could not be simpler*
1. Extract `malaria-no-more-plugin.zip`.
2. Upload the `malaria-no-more-plugin`-folder to your `/wp-content/plugins/` directory.
3. Activate the plugin through the �Plugins� menu in WordPress.
4. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.

That's it, it'll take you all of 30 seconds to download the plugin, upload it and activate it, 30 seconds.... think about it, around 30 children die of Malaria every 30 minutes, if not less. In fact, about 3000 die every day. Malaria is the greatest killer of children in the world, our world, and we have the means to prevent these deaths.

Millions of bloggers around the world can make a difference, blog about malaria, add this plugin, link people to malarianomore.org....just do something!