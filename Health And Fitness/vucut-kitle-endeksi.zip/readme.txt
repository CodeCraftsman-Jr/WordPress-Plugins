=== Plugin Name ===
Tags: vücut, kitle, endeksi, body, mass, index, vki, vke, bmi, dünya, sağlık, ötgütü, world, health, organization, who, dsö, kilo, boy, cinsiyet, ideal, weighs, height, sex

Cinsiyet, boy ve kilo girilerek; Vücut Yüzey Alanı, Yağsız Vücut Ağırlığı, İdeal Vücut Ağırlığı, Vücut Kitle Endeksi değerlerini hesaplayan bir eklenti.

== Description ==

Hesaplanan değerlerin sonuçları, Dünya Sağlık Örgütü verilerine göre yorumlanarak gösterilmektedir.

== Installation ==

1. vucut-kitle-endeksi klasörünü wp-content/plugins klasörüne yükleyiniz.
2. Eklentiler sayfasından eklentiyi etkinleştiriniz.
3. Görünüm/Bileşenler sayfasından Vücut Kitle Endeksi bileşenini bileşen gösterim alanına sürükleyiniz.

== Screenshots ==

1. Bileşen listesinde Vücut Kitle Endeksi'nin görünümü.
2. Hesaplama formunun sayfada görünümü.
3. Hesaplama sonuçlarının sayfada görünümü.

== Changelog ==

= 1.0 - 30.08.2010 =
* Vücut Kitle Endeksi yayınlandı