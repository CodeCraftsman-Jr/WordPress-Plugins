=== Plugin Name ===
Contributors: Lucian Apostol
Donate link: http://www.baseter.com
Tags: bmi calculator, bmi, body mass index, calculate bmi, bmi index
Requires at least: 2.0.2
Tested up to: 4.1.1
Stable tag: 0.3

Provide your visitors the ability to calculate their body mass index to determine wheter their bmi in normal, they are underweight or they are overweight

== Description ==

Baseter body mass index ( bmi ) calculator is a widget that can be installed on your blog and provide your visitors the option to calculate their BMI.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `baseter.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'Appearance' section on your admin panel, and select 'Widgets' submenu
4. Drag "Baseter" widget and paste it to your active sidebar, in the place you want it to appear

== Frequently Asked Questions ==

= Do i have to change my theme to make the plugin work? =

No theme changes are needed for this plugin. 

= I don't want the plugin to appear in the sidebar, can i add it elsewhere ? =

The current version of plugin is designed to be placed on the sidebar, in the future versions there will exist the option to be tagged directly from theme files.

= How it will affect my design and blog functionality =

The blog functionality will not be affected in any way

== Changelog ==

= 0.3 =
* Adapted to work with Wordpress 4.1.1

= 0.2 =
* Checked and tested for wordpress 4.0

= 0.1 =
* This is the first version of the plugin