=== mind-body ===
Contributors: vimes1984
Tags: wordpress, mindbody, plugin
Requires at least: 3.5.1
Tested up to: 4.1
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Mind body API integration

== Description ==

THIS PLUGIN IS INTENTED FOR DEVELOPERS ONLY.
ALL ISSUES TO BE TRACKED VIA GITHUB
https://github.com/vimes1984/mindbody-api-wordpress


You will need at the very least Types: 

https://wordpress.org/plugins/types/

( with a few custom fields, see the plugin files for more info...)


And Woocomerce: 
https://wordpress.org/plugins/woocommerce/


Mind body API integration, this is a mind body api intergation kit for wordpress.
it's intention is to try and import the mindbody api lesson's, classes and staff over to wordpress/woocommerce.
If any further help is required drop me a line on here or contact http://accruemarketing.com/

you have a few shortcodes: 

[mindbodyeventscal]

and 

[mindbodyeventscalwid] 
There are also a few factories in the public.js file that pertain to the shop page loop and require a custom shop page loop using isotope if anybodies interested I can upload that aswell...



== Installation ==

1. Upload `` to the `/wp-content/plugins/` directory
1. Activate the plugin through the "Plugins" menu in WordPress
1. Place `<?php do_action("mind-body_hook"); ?>` in your templates

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==
= 1.0.3 =
README update
= 1.0.2 =
README update
= 1.0.1 =
README update
= 1.0.0 =
* Initial Commit