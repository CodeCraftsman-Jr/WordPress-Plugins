							       	<?php $this->options = get_option( 'mind_body_options' ); ?>
							        <form method="post" action="options.php">
								            <?php
								                // This prints out all hidden setting fields
								                settings_fields( 'mind_body_group' );   
								                do_settings_sections( 'mind-body-admin' );
								                submit_button(); 
								            ?>
							         </form>  