=== Antibiotic ===
Contributors: rasmuskjellberg
Tags: antivirus, hack protection, firewall
Keywords: antivirus, hack protection, firewall
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress Antivirus and Hack protection.

== Description ==

Antibiotic helps you protect your WordPress site and checks your plugin and folders for vulnerabilities. This is just a BETA version. More functions are planned and will be launched soon. Look for an update :)

Major features in Antibiotic include:

* Hide version numbers in your front-end source code for WordPress-core and all of your plugins. 
* Completely turn off trackbacks & pingbacks to your site

== Installation ==

Upload the Antibitoic plugin to your blog, Activate it thats it.

This plugin does nothing by default, and that's because we want you to know whats happening behind the scenes. With that said, please choose wich modules you want to use with Antibiotic. Even if nothing is loaded by default, we recommend you to use activate them all for best protection. Cheers =)

== Changelog ==

Nothing yet.