<?php ANTIBIOTIC\Controller::header(); ?>

<p>Nam dictum felis vel lectus eleifend pretium. Sed vulputate, neque et vestibulum condimentum, erat orci interdum quam, eget feugiat massa dolor at nisl. Suspendisse at neque vel quam rutrum pharetra. Vivamus mattis justo a elit gravida, eu vestibulum odio commodo. Vivamus vitae facilisis risus, quis pretium dui. Nam libero lorem, varius eu dictum nec, rutrum sed mi. Nulla facilisi.</p>

<?php ANTIBIOTIC\Controller::footer(); ?>