=== Mahjong ===
Contributors: Hirofumi Ohta
Tags: mahjong, game
Requires at least: 3.4
Tested up to: 3.4.2
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Mahjong hai plugin. 

== Description ==

"Mahjong" provides shortcode to construct mahjong hai images.

* [Docs](http://wordpress.1000sei.com/mahjong/)
* [Support](http://wordpress.1000sei.com/mahjong/)

== Installation ==

1. Upload the entire `mahjong` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

== Screenshots ==

1. screenshot-1.png 
1. screenshot-2.png 

== Changelog ==
= 1.4 =
* attached language file.


= 1.3 =
* Fixed some bugs.

= 1.2 =
* Internationalized. made pot, po and mo.
* Fixed some bugs in css.

= 1.1 =

* Fixed some bugs.
