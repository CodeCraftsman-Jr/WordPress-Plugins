== For Translators ==

If you have created your own translation, or have an update of an existing one, please send it to Hirofumi Ohta <kirisuke@tiltir.sakura.ne.jp> so that I can bundle it into the next release of Mahjong.

Thank you.