=== Snack Game ===
Contributors: Ashutosh Kumar
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=awesomeworks1%40gmail%2ecom&lc=US&item_name=developer%20fund&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHostedGuest
Tags: Snack Game, Html Snack Game, HTML5 Snack Game, html5 Snack Game, HTML Snack Game, canvas Snack Game,web Snack Game
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
HTML5 Snack Game and canvas Snack Game



== Description==
This plugin is used for canvas snack game for HTML5 Browser
Very Lightweight- Only 2KB

Installation very easy, just install & enjoy.

Any problem, Please Check FAQ Tab.

Created By: https://www.facebook.com/ashutosh.kr.upadhyay


== Installation ==

= Automatic =

* In the admin panel under plugins page, click Add New
* go to Upload tab
* browse "SnackGame" and click install now
* Click Active plugin
* After that you can use the shortcode  [SnackGame]
* Enjoy!

= Manual =

* Extract zip file to your wp-content/plugins directory.
* In the admin panel under plugins, activate "SnackGame".
* Enjoy!


== Frequently Asked Questions ==

This plugin is used for canvas snack game for HTML5 Browser


Any problem, just mail us. email- looklikeme05@gmail.com  ,ashutosh2432@gmail.com