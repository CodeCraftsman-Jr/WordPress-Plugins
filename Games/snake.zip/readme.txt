=== Snake ===
Contributors: camilstaps
Tags: snake, game
Donate link: http://wordpress.camilstaps.nl/donate
Requires at least: 2.5
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Let your users play snake on your website!

== Description ==

Let your users play snake on your website!

Just add `[snake]` to your post and there you go!

== Installation ==

1. Upload folder `snake` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0 =
Yay, first version!
