=== Google Pac-Man ===
Contributors: bradvin 
Donate link:http://themergency.com/donate/
Tags: games,pacman,pac-man,google,pac man
Requires at least: 2.9.2
Tested up to: 3.0.1
Stable tag: trunk

Embed a Pac-Man mini game into your blog post with the shortcode [pacman]

== Description ==

Google celebrated Pac-Man's 30th anniversary by showing the Pac-Man doodle on its front page for 48 hours. Now you can embed the mini game into your blog with a simple shortcode.

Simply use the shortcode **[pacman]** to insert the game into any post or page.

Read more about it here : http://themergency.com/google-pac-man-wordpress-plugin/

== Installation ==

1. Upload the plugin folder 'google-pac-man' to your `/wp-content/plugins/` folder
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Insert the pacman shortcode [pacman] into your page or post

== Screenshots ==
1. This is what it looks like in action

== Changelog ==

= 0.1 =
* Initial Relase. First version.

== Frequently Asked Questions ==

= How do I use this plugin? =
You insert a shortcode [pacman] into your blog post or page