=== Shoot the zombie ===

Contributors: axelmolokini

Requires at least: 3.0

Tested up to: 4.1

License: GPLv2 or later



Using the shortcode this plugin generates you can add a fun button that when clicked a zombie appears you to need to shoot. Just for laughs.



== Description ==

Using the shortcode this plugin generates you can add a fun button that when clicked a zombie appears you to need to shoot. Just for laughs.



== Installation ==

Install and activate the plugin. Add the shortcode [shoot-the-zombie] anywhere on your site.