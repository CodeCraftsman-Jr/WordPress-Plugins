Chess images from http://ixian.com/chess/jin-piece-sets/ by Eric De Mund.
Licensed under a Creative Commons Attribution-Share Alike 3.0 Unported License.
http://creativecommons.org/licenses/by-sa/3.0/