The figurine fonts are derived from the Liberation Sans font (released under
GNU General Public License, see https://fedorahosted.org/liberation-fonts/)
with the addition of chess pieces from freeware fonts: the alpha2 font (Peter
Strickland), the good companion font (David L. Brown), the merida font (Armando
H. Marroquin), the pirate font (Klaus Wolf) and the chess usual font (Armando
H. Marroquin). The original chess fonts and more details are available at
http://www.enpassant.dk/chess/fonteng.htm
The chess informant symbols font is used with permission from the Chess
Informant publishing company (http://www.chessinformant.rs). The chess ole
figurin font is from the ChessOLE project (http://www.chessole.de, David Frank).
