Placeholder folder to hold localization files for the plugin settings page.

Actual localization files are not provided within the plugin packages;
localization files can be easily generated using a tool like:
http://wordpress.org/extend/plugins/codestyling-localization/

Please note that only the localization of the plugin settings page is supported;
localization of the chessboard itself and its help file is not supported.

