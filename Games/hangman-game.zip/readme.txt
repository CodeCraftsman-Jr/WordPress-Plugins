=== Plugin Name ===
Contributors: Marcel Hollerbach
Donate link: http://www.farbundstil.de/games/1036-wordpress-game-plugin.php
Tags: game, hangman, gaming
Requires at least: 2.0.2
Tested up to: 2.6
Stable tag: 1.1

== Description ==

The hangman plugin allows you to put a simple and fun game on your wordpress blog. Simply upload the plugin, activate it and add the [HANGMAN] - tag to a new post.

== Installation ==

The plugin requires at least Wordpress: 2.1.3

1. Upload the hangman folder to your wordpress plugins directory (./wp-content/plugins)
2. Login to the Wordpress admin panel and activate the plugin hangman game
3. Create a new post or page and enter the tag [HANGMAN]

That's it, have fun!

== Screenshots ==

1. Screenshot of the game


== Frequently Asked Questions ==

There are no questions yet.
