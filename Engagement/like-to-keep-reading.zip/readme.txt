=== Like To Keep Reading ===
Contributors: soflyy
Tags: facebook, google, twitter, force, like, force, plusone, tweet, protect, content, locker
Requires at least: 3.0
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Like To Keep Reading gets you more Facebook Likes, Google +1s, and Tweets by forcing users to perform a social action before accessing the rest of your content.

== Description ==

= Market your content virally on social networks by forcing uesrs to perform a social action before accessing your protected content. =

Here's how it works:

Choose which content you wish to protect. The plugin will hide the content until the user Likes, +1s, or Tweets.

== Changelog ==

= 1.0 =
* Initial release on WordPress.org.

== Installation ==

Either: -
	* Upload the plugin from the Plugins page in WordPress
	* Unzip like-to-keep-reading.zip and upload the contents to /wp-content/plugins/like-to-keep-reading, and then activate the plugin from the Plugins page in WordPress
	

