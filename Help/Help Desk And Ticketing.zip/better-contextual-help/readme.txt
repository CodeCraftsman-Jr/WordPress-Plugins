=== Better Contextual Help ===
Contributors: potreb
Tags: contextual help, help, user help, documentation, docs
Tested up to: 4.1
Stable tag: 1.0
Requires at least: 3.8

Extend your Dahsboard Help. Display help for multiple screens and user roles.

== Description ==
Extend your dashboard help by adding new tabs or replacing old ones. You can add tab for the specific roles and screens.

You can export and import content help.

Go to the settings to be able to post for help.

== Changelog ==
= 0.1 =
* Make plugin

== Installation ==
To do a new installation of the plugin, please follow these steps

1. Download file to your computer.
2. Unzip the file to the /wp-content/plugins/ directory
3. Activate the plugin through the 'Plugins' menu in WordPress
