function fillSpaces(string){
	string = string.replace(" ", "%20");
	return string;
}