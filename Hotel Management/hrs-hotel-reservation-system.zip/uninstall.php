<?php
if( ! defined( 'WP_UNINSTALL_PLUGIN' ) ){
	exit();
}

/* here onwards do the stuff to run on uninstalling the plugin */