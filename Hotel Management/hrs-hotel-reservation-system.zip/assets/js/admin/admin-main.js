jQuery(document).ready(function($){
	/* admin_main_js_obj can be used to retrieve dynamic server side values */
	//alert('admin end js');
});
