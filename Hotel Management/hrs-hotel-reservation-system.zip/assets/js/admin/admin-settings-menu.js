jQuery(document).ready(function($){
	/* admin_settings_menu_js_obj can be used to retrieve dynamic server side values */
	$( "#tabs" ).tabs();
});
