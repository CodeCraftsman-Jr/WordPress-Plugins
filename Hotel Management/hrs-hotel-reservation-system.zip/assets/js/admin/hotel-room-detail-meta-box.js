jQuery(document).ready(function($){
	$("#hotel_room_hotel").select2({
		placeholder: "— Select Hotel —",
		allowClear: true
	});
});
