﻿=== Hotel Management System ===

Contributors: MozakDesign

Tags: Hotel Management System, Hotel reservation System, Hotel Plugin, Hotel website Plugin navigation, Hotel Room Booking, hotel system

Donate link: http://mozakdesign.com

Requires at least: 4.0.0

Tested up to: 4.3

Stable tag: 1.0.0

License: GPLv2 or later



A fantastic plugin for hotel reservation management. It makes the reservation and booking system so easy to manage that you're gonna love it!



== Description ==

<h4>About Hotel Management System</h4>

Hotel Management System is a WordPress Plugin developed by MozakDesign,  WordPress Developers to help you with the reservation management of your hotels.<br>



<h3>Hotel Management System Features</h3>

> <strong>Easy to manage</strong><br>

> <strong>Keep records of the booking and checkouts</strong><br>

<h4>Need more Help?</h4>

For more information about Hotel Management System upgrades, ultimate features, tutorials and in-depth details on all versions of this WordPress Plugin, namely;


Hotel Management System


Please visit http://hotelreservationwp.com



== Installation ==

<h3>Installation within WordPress Admin</h3>



1. Search and Install Hotel Management System from Add New Plugin.



2. Activate Hotel Management System Plugin.



<h3>Manual Installation</h3>

  

1.	Download the Hotel Management System archive in zip format and

	extract the files on your computer. 



2.	Create a new directory named Hotel Management System in the wp-content/plugins `

	directory of your WordPress installation. Use an FTP or SFTP client to 

	upload the contents of your Hotel Management System archive to the new directory

	that you just created on your web host.



3.	Log in to the WordPress Dashboard and activate the Hotel Management System plugin.



4.	You are ready to start customizing WP-Admin using Hotel Management System.



<h3>Need more Help?</h3>



For more information about Hotel Management System upgrades, ultimate features, tutorials and in-depth details on all versions of this WordPress Plugin, namely;



Hotel Management System



Please visit http://hotelreservationwp.com/



== Frequently Asked Questions ==



<h3>Need more Help?</h3>



For more information about Hotel Management System upgrades, ultimate features, tutorials and in-depth details on all versions of this WordPress Plugin, namely;



Hotel Management System



Please visit http://hotelreservationwp.com/



== Screenshots ==

<h4>What does Hotel Management System do?</h4>



Watch the video tutorial below to learn how Hotel Management System WordPress Plugin helps you organize your hotel system.<br>



<h3>Video Explainer</h3>

 

https://vimeo.com/134272744



<h3>Need more Help?</h3>



For more information about Hotel Management System upgrades, ultimate features, tutorials and in-depth details on all versions of this WordPress Plugin, namely;



Hotel Management System 



Please visit http://hotelreservationwp.com/



== Changelog ==

None


= 1.0.0 =

Added wordpress standard menus rearrange.



== Upgrade Notice ==

None