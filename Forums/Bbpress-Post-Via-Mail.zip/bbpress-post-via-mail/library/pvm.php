<?php

class pvm extends pvm_Autohooker {
	protected static $handler = null;

	protected static $connectors = array();

	public static function bootstrap() {
		// Kill the defaults
		remove_action( 'bbp_new_reply', 'bbp_notify_subscribers', 11 );

		if (is_admin()) {
			pvm_Admin::bootstrap();
		}

		try {
			// Check for a handler first
			self::$handler = self::get_handler();

			// Then add our own hooks!
			self::register_hooks();
		}
		catch (Exception $e) {
			add_action('all_admin_notices', function () use ($e) {
				printf('<div class="error"><p>' . __('Problem setting up bbPress Post Via Mail! %s', 'bbsub') . '</p></div>', $e->getMessage());
			});

		}

		foreach ( self::get_available_connectors() as $key => $connector ) {
			self::$connectors[ $key ] = new $connector( self::$handler );
		}
	}

	/**
	 * Get all available handlers
	 *
	 * @return array Associative array of identifier => handler class
	 */
	public static function get_handlers() {
		$default = array(
			'postmark' => 'pvm_Handler_Postmark',
			// 'mandrill' => 'pvm_Handler_Mandrill',
		);
		return apply_filters('bb_pvm_handlers', $default);
	}

	/**
	 * Get the registered handler class for a certain type
	 *
	 * @param string|null $type Type to get, defaults to the option
	 */
	public static function get_handler_class($type = null) {
		if (!$type) {
			$type = self::get_option('bb_pvm_handler_type', false);
		}

		$handlers = self::get_handlers();

		if (empty($type)) {
			throw new Exception(__('No handler set in the options', 'bbsub'));
		}
		if (!isset($handlers[$type])) {
			throw new Exception(__('Handler could not be found.', 'bbsub'));
		}
		return $handlers[$type];
	}

	/**
	 * Get a mail handler based on the config
	 *
	 * @return bbSubscriptions_Handler
	 */
	protected static function get_handler() {
		$type = self::get_option('bb_pvm_handler_type', 'postmark');
		$options = self::get_option('bb_pvm_handler_options', array());

		// Get the appropriate handler
		$handler = self::get_handler_class($type);
		$handler = apply_filters('bb_pvm_handler_' . $type, new $handler($options), $options);

		return $handler;
	}

	/**
	 * Get available connectors
	 *
	 * @return array
	 */
	protected static function get_available_connectors() {
		$connectors = array(
			'wordpress' => 'pvm_Connector_WordPress',
		);

		if (is_plugin_active('bbpress/bbpress.php')) {
			$connectors['bbpress'] = 'pvm_Connector_bbPress';
		}

		return apply_filters( 'pvm_connectors', $connectors );
	}

	public static function get_connectors() {
		return self::$connectors;
	}

	/**
	 * Get the reply-to address for a post and user
	 *
	 * @param int $post_id Post ID
	 * @param WP_User $user User object
	 * @return string Full email address
	 */
	public static function get_reply_address($post_id, $user, $site_id = null) {
		if ( ! $site_id ) {
			$site_id = get_current_blog_id();
		}

		$address = self::get_option('bb_pvm_replyto', false);
		if (empty($address)) {
			throw new Exception(__('Invalid reply-to address', 'bbsub'));
		}

		// Append the plus address if it's not already there
		if ( strpos( $address, '+' ) !== false) {
			throw new Exception(__('Invalid reply-to address', 'bbsub'));
		}

		list( $user_part, $host_part ) = explode( '@', $address );
		$user_part .= '+%1$s-%2$d-%3$d-%4$s';
		$address = $user_part . '@' . $host_part;

		return sprintf($address, $post_id, $site_id, $user->ID, self::get_hash($post_id, $user, $site_id));
	}

	/**
	 * Get the verification hash for a post and user
	 *
	 * Uses a HMAC rather than a straight hash to avoid vulnerabilities.
	 * @see http://benlog.com/articles/2008/06/19/dont-hash-secrets/
	 * @see http://blog.jcoglan.com/2012/06/09/why-you-should-never-use-hash-functions-for-message-authentication/
	 *
	 * @param int $post_id Post ID
	 * @param WP_User $user User object
	 * @return string Verification hash (10 characters long)
	 */
	public static function get_hash($post_id, $user, $site_id) {
		return hash_hmac('sha1', $post_id . '|' . $site_id . '|' . $user->ID, 'bb_pvm_reply_by_email');
	}

	/**
	 * Get the From address
	 *
	 * Defaults to the same default email as wp_mail(), including filters
	 * @return string Full email address
	 */
	public static function get_from_address() {
		$address = self::get_option('bb_pvm_from_email', false);
		if (empty($address)) {
			// Get the site domain and get rid of www.
			$sitename = strtolower( $_SERVER['SERVER_NAME'] );
			if ( substr( $sitename, 0, 4 ) == 'www.' ) {
				$sitename = substr( $sitename, 4 );
			}

			$address = 'wordpress@' . $sitename;
			$address = apply_filters('wp_mail_from', $address);
		}

		return $address;
	}
	public static function get_new_topic_subj() {
        return self::get_option('bb_pvm_new_topic_subj', false);
    }

	public static function get_new_topic_msg() {
        return self::get_option('bb_pvm_new_topic_msg', false);
    }

    public static function get_new_reply_subj() {
        return self::get_option('bb_pvm_new_reply_subj', false);
    }

    public static function get_new_reply_msg() {
        return self::get_option('bb_pvm_new_reply_msg', false);
    }

	/**
	 * Notify the user of an invalid reply
	 *
	 * @param WP_User $user User that supposedly sent the email
	 * @param int $topic_id Topic ID
	 */
	public static function notify_invalid($user, $from, $link, $title, $error='') {
		// Build email
		$notify = self::get_option('bb_pvm_send_bad_reply', false);
		if (!$notify) return;
                $site=get_option('blogname');
                $subject=get_option('bb_pvm_bad_reply_subj', false);
		$text = self::get_option('bb_pvm_bad_reply_msg', false);
                $text = str_replace('{user}',$user->display_name,$text);
		$text = str_replace('{from}',$from,$text);
		$subject = str_replace('{user}',$user->display_name,$subject);
		$text = str_replace('{site}',$site,$text);
		$text = str_replace('{link}',$link,$text);
                $subject = str_replace('{site}',$site,$subject);
		$text = str_replace('{title}',$title,$text);
        $text = str_replace('{error}',$error,$text);
		$text = str_replace('{link}',get_site_url(),$text);
                $subject = str_replace('{title}',$title,$subject);
                
		$text = apply_filters( 'bb_pvm_email_message_invalid', $text, $user->ID );
                wp_mail($user->user_email, $subject, $text);
	}

	/**
	 * Add a more frequent cron schedule
	 *
	 * We need to check the inbox much more regularly than hourly, so here we
	 * do it every minute instead.
	 *
	 * @wp-filter cron_schedules
	 */
	public static function add_schedule($schedules) {
		$schedules['pvm_minutely'] = array('interval' => 60, 'display' => 'Once Every Minute');
		return $schedules;
	}

	/**
	 * @wp-action bb_pvm_check_inbox
	 */
	public static function check_inbox() {
		if (self::$handler === null) {
			return false;
		}

		self::$handler->check_inbox();
	}

	/**
	 * @wp-action admin_post_nopriv_bbsub
	 * @wp-action admin_post_bbsub
	 */
	public static function post_callback() {
		if (self::$handler === null) {
			return false;
		}

		self::$handler->handle_post();
	}

	/**
	 * Convert the post content to text
	 *
	 * @wp-filter bb_pvm_html_to_text
	 * @param string $html HTML to convert
	 * @return string Text version of the content
	 */
	public static function convert_html_to_text($html) {
		$converter = new pvm_Converter($html);
		return $converter->convert();
	}

	/**
	 * Is pvm in network mode?
	 *
	 * Network mode is used when pvm is network-activated, and moves some
	 * of the settings to the network admin for super admins instead. It also
	 * adds UI to allow enabling per-site.
	 *
	 * @return boolean
	 */
	public static function is_network_mode() {
		require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		return is_multisite() && is_plugin_active_for_network( PVM_PLUGIN );
	}

	public static function get_option( $key, $default = false ) {
		if ( self::is_network_mode() ) {
			return get_site_option( $key, $default );
		}

		return get_option( $key, $default );
	}

	/**
	 * Is pvm enabled for this site?
	 *
	 * When pvm is used in network mode, it can be toggled per-site.
	 *
	 * Avoid using this to determine whether to hook in, instead use it inside
	 * your hook callbacks to determine whether to run.
	 *
	 * @param int $site_id Site to check. Default is current site.
	 * @return boolean
	 */
	public static function is_enabled_for_site( $site_id = null ) {
		if ( ! self::is_network_mode() ) {
			return true;
		}

		if ( empty( $site_id ) ) {
			$site_id = get_current_blog_id();
		}

		$sites = pvm::get_option( 'pvm_enabled_sites', array() );
		return in_array( $site_id, $sites );
	}
}
