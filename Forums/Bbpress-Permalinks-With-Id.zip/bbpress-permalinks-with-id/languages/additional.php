<?php
defined ('ABSPATH') OR exit;
// Additional translates for plugin :)

__ ('bbPress Permalinks', 'bbpress_permalinks');
__ ('Change bbPress permalinks. ID number instead of topic slug. This links better than default if you have Cyrilic or other non english charackters in forum\'s and topic\'s slugs. forums/forum/FORUM_SLUG/ &rarr; forums/forum/ID/. forums/topic/TOPIC_SLUG/&rarr;forums/topic/ID/', 'bbpress_permalinks');
__ ('Kolya Korobochkin', 'bbpress_permalinks');
// __ ('', 'bbpress_permalinks');
// __ ('', 'bbpress_permalinks');
// __ ('', 'bbpress_permalinks');
// __ ('', 'bbpress_permalinks');
// __ ('', 'bbpress_permalinks');
// __ ('', 'bbpress_permalinks');
// __ ('', 'bbpress_permalinks');

?>