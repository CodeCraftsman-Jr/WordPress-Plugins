bbpress-live-topic-suggestion
==========================

Automatically suggests related topics based on new topic title. 

Also available on the WordPress SVN: http://wordpress.org/plugins/bbpress-auto-suggest-topics-based-on-new-topic-title/

Please, if you make improvements commit them back to this repo for review. 




