=== Feed 2 Post ===
Contributors: olivM
Donate link: http://miracles.heaven.fr/
Tags: post, feed, auto
Requires at least: 2.1
Tested up to: 2.3
Stable Tag: 0.2

This plugin allows you to transform items from a feed to wordpress's posts.

== Description ==

This plugin allows you to transform items from a feed to wordpress's posts..

