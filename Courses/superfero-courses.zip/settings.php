<?php
define( 'SUPERFERO_URL', 'http://www.superfero.com/' );
define( 'SUPERFERO_NAMESPACE', 'www' );
define( 'SUPERFERO_TITLE', 'Superfero Courses' );
define( 'SUPERFERO_DESCRIPTION', 'The lastest online courses from superfero.com' );
define( 'SUPERFERO_FORM_TITLE', 'Superfero Online Courses' );
define( 'SUPERFERO_FORM_NUMBER_COURSES', '5' ); // Default is 5, option values: 5, 7, 10
define( 'SUPERFERO_FORM_LANGUAGE_COURSE', 'EN' ); // Default is EN - English, option values: EN - English, DA - Denish, ALL - All languages
$option_number = array( '3', '5', '7', '10' );
$option_language = array( 'EN' => 'English', 'DA' => 'Danish' );
?>