=== DeMomentSomTres Export ===
Contributors: marcqueralt
Tags: export, attachments
Requires at least: 3.4
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later

DeMomentSomTres Export to help exporting filtered WordPress data with required attachment files that usually get lost.

== Description ==

DeMomentSomTres Export was build because [DeMomentSomTres](http://demomentsomtres.com) had a customer with a very big blog that had to be imported with all attachments.

This plugin is a modified version of the export procedure.

Standard export procedure can be recovered unistalling or deactivating this plugin.

More information: http://demomentsomtres.com/english/wordpress-plugins/demomentsomtres-wordpress-export-post-with-images/

== Frequently Asked Questions ==

= I have activated the plugin and NOTHING happens =

This pluguin ONLY modifies some elements in the internal processes of WordPress Export so no apparent changes will be seen by the users.

Go to Tools > Export and use it.

== Installation ==

Upload the plugin.

== Screenshots ==

N/A

== Changelog ==

= 1.1 =

* compatibility updates
* posts are not allwais parent for a featured image -> thanks to megamurmulis

=1.0.1=

* 3.9.1 Compatibility 

=1.0=

* First release

== Next Steps ==

TBD