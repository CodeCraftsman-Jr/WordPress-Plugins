=== Export Categories ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: export,export categories,export-categories
Requires at least: 2.9
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

export you wordpress categories only to another wordpress site

== Description ==

export you wordpress categories only to another wordpress site.WordPress export not provide export only category this plugin provide only categories without any post data or pages.

= Features =
1. Export you blog categories only.
2. Easy  and fast without any post or page data.

More Detail : http://socialcms.wordpress.com/


== Installation ==


1. Upload the export-categories folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go Tools => **Export Categories**

== Frequently Asked Questions ==

N/A

== Screenshots ==

1. screenshot-1.png  : screen shot admin Tools section.


== Changelog ==

N/A

== Upgrade Notice ==

N/A
