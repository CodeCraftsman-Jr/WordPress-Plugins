=== Arabic Font ===
Contributors: darto
Tags: arabic, font, arabic text, shortcode
Tested up to: 4.0
Stable tag: 1.2
Requires at least: 3.0

An easy way to stylish your Arabic font

== Description ==
I'm just newbie for programming but I love a lot of WordPress.

My friend is lot write with Arabic language and I tried to find plugins that will easily to help him to write in his website which support for display with specific Arabic fonts, but I find none. So here I am. I tried to googling and combine all the code to make this plugin. And also the font that I included in this plugin is open source or legally to download from their website.

Here font that I use in this plugin:

<ul>
<li>JF Flat Jozzor => http://fonts.jozoor.com/flat-font/</li>
<li>Ara Jozoor => http://fonts.jozoor.com/jozoor-font/</li>
<li>KFGQPC Uthman Taha Naskh => http://fonts.qurancomplex.gov.sa/?page_id=42</li>
<li>PDMS Saleem QuranFont => http://pakdata.com/products/arabicfont</li>
<li>Amiri => homepage: http://www.amirifont.org/  download: http://sourceforge.net/projects/amiri/files/</li>
<li>Droid Arabic Naskh => http://openfontlibrary.org/en/font/droid-arabic-naskh</li>
<li>Thabit => http://openfontlibrary.org/en/font/thabit</li>
<li>Scheherazade => http://openfontlibrary.org/en/font/scheherazade</li>
</ul>

The plugin is just simple which we can transform the Arabic text to specific font that we want by click the icon in text editor of posts or pages. And also I create option pages in case that no need all customize configuration in shortcode.

If you want to add Islamic date (Hijr) in your blog, you can try <a href="https://wordpress.org/plugins/penanggalan-hijriyah-masehi/">Penanggalan Hijriyah &amp Masehi</a>.

== Installation ==
Arabic Font plugin support to place your Arabic text in <code><span></code> or <code><div></code> and here complete configuration:

[arabic-font font_family="JF Flat Jozoor" font_size="36" line_height="65" text_align="center" span="no"]???? ????? ?????[/arabic-font]

If attributes span yes then it will put the Arabic text with span but if the span attributes no then Arabic text will put in div.

== Frequently Asked Questions ==

= How I use the plugin? =
All you have to do is highlight the Arabic text that you want to change the font and then you click button Arabic Font Style that show in Posts or Pages editor.

== Screenshots ==

1. **Button Shortcode** - You simply select the Arabic text in WordPress posts or pages and then click the button
2. **Default Shortcode** - Simple how to apply the shortcode that will occur based on the option
3. **More Setting for Shortcode** - Choose your Arabic text to <code><span></code> that will not change the Arabic text position in the paragraph and <code><div></code> if you want make Arabic text as new paragraph, and of cpurse you can choose font for Arabic text. 
4. **Display Result** - This is how the different between <code><span></code> and <code><div></code> and different font in same posts or pages
5. **Panel** - Panel for more easy to apply for simple shortcode

== Changelog ==

= 1.2 =
Release date: January 5, 2015

*Add option for default class and custom css*