=== Disqus Language ===
Contributors: nabil_kadimi
Tags: disqus,language
Requires at least: 3.1
Tested up to: 4.1.1
Stable tag: 0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tell the plugin "Disqus Comment System" to use the site language.

== Description ==

**Disqus Language** tells the **Disqus Comment System** plugin to use the site language instead of the default English. This is a very simple plugin, no configuration required.

== Installation ==

1. Put the plugin folder into [wordpress_dir]/wp-content/plugins/
2. Go into the WordPress admin interface and activate the plugin

