=== month name translation benaceur ===
Contributors: Benaceur 
Tags: names months, name month, months names, month name, change name month, change name of month, change names of months, change name of month, translation names of the months, translation name of the month 
Requires at least: 3.0
Tested up to: 4.2.3
Stable tag: 2.0
License: GPLv2 or later

This plugin allows you to edit and translate the names of the months ...

== Description ==

You can translate or modify the names of the months by this plugin from the administration panel without changing the translation file ...

= TRANSLATED IN FOLLOWING LANGUAGES: =
* Arabic
* English

== Installation ==

1. Upload news ticker benaceur to the "/wp-content/plugins/"
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Activate the plugin again in the control panel (the plugin page)
4. Enter the names of months as currently in your site (in order)
5. Enter the new names of the months of your choice (in order).

== Screenshots ==

1. Options page admin panel-1
2. Options page admin panel-2
3. Options page admin panel-3

== Changelog ==

= 2.0 =
* Some adjustments.
= 1.0 =
* First released version.
