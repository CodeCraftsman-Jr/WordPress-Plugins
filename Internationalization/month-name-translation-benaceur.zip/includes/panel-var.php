<?php

$mntb_enable_plug = get_option( 'month_name_translation_benaceur_enable_plug' );

$mntb_jan = get_option( 'month_name_translation_benaceur_jan' );
$mntb_t_jan = get_option( 'month_name_translation_benaceur_t_jan' );
$mntb_Fev = get_option( 'month_name_translation_benaceur_Fev' );
$mntb_t_Fev = get_option( 'month_name_translation_benaceur_t_Fev' );
$mntb_Mar = get_option( 'month_name_translation_benaceur_Mar' );
$mntb_t_Mar = get_option( 'month_name_translation_benaceur_t_Mar' );
$mntb_Avr = get_option( 'month_name_translation_benaceur_Avr' );
$mntb_t_Avr = get_option( 'month_name_translation_benaceur_t_Avr' );
$mntb_Mai = get_option( 'month_name_translation_benaceur_Mai' );
$mntb_t_Mai = get_option( 'month_name_translation_benaceur_t_Mai' );
$mntb_Juin = get_option( 'monthnametranslationbenaceurjuin' );
$mntb_t_Juin = get_option( 'monthnametranslationbenaceurtjuin' );
$mntb_Juil = get_option( 'monthnametranslationbenaceurjuil' );
$mntb_t_Juil = get_option( 'monthnametranslationbenaceurtjuil' );
$mntb_Aou = get_option( 'month_name_translation_benaceur_Aou' );
$mntb_t_Aou = get_option( 'month_name_translation_benaceur_t_Aou' );
$mntb_Sep = get_option( 'month_name_translation_benaceur_Sep' );
$mntb_t_Sep = get_option( 'month_name_translation_benaceur_t_Sep' );
$mntb_Oct = get_option( 'month_name_translation_benaceur_Oct' );
$mntb_t_Oct = get_option( 'month_name_translation_benaceur_t_Oct' );
$mntb_Nov = get_option( 'month_name_translation_benaceur_Nov' );
$mntb_t_Nov = get_option( 'month_name_translation_benaceur_t_Nov' );
$mntb_Dec = get_option( 'month_name_translation_benaceur_Dec' );
$mntb_t_Dec = get_option( 'month_name_translation_benaceur_t_Dec' );

$mntb_hide_icon_evol_plug = get_option( 'month_name_translation_benaceur_hide_icon_evol_plug' );
$mntb_disable_input = get_option( 'month_name_translation_benaceur_dis_input' );
$mntb_all_reset = get_option( 'mntb_all_reset' );
$mntb_delete_all_options = get_option( 'month_name_translation_benaceur_delete_all_options' );
