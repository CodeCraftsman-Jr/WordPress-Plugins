=== Displaying Countries with their Capital and currencies===
Contributors: YO YO SETHI'S
Tags: Countries,Capitals,Currencies
Requires upto least: 3.4.1
Tested up to: 3.4.1
Stable tag: 1.0.1

== Description ==

This plugin lets you show all countries with their Capitals and Currencies on whichever page you like just use shortcode[countries_list]. It has also been widgetized for drag-and-drop use on your sidebar.

The listing can be styled to match your site there is no  CSS box so its follow your current style,easy to fit your current layout .

== Installation ==

1. Upload the `All Countries` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu
3. Navigate to 'Countries' menu from admin panel 
4. You can either drag the `Countries list` widget straight onto your sidebar, or you can place shortcode [countries_list] into your page where you'd like the events to appear

= How do I uninstall the plugin? =

Simply delete the old `All Countries` folder, and remove the shortcode [countries_list] line from your page file.

== Screenshots ==
1. This screenshot-1.png shows table of all countries with their respectives capitals and currencies.
