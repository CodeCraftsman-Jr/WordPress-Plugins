if (typeof QTags != 'undefined') {
  QTags.addButton('scss3b', 'CSS3 Button', '[standout-css3-button href=""]', '[/standout-css3-button]', '', 'Standout CSS3 Button', '');
}