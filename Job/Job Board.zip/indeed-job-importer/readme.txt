=== Indeed Job Importer ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: indeed job importer,indeed rss,import indeed,indeed,makes autoblogging,autoblogging,job board,auto job import,indeed api,indeed importer
Requires at least: 2.9
Tested up to: 4.2
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Indeed Job Importer Plugin Import job from indeed according to your given parameter.

== Description ==

Indeed Job Importer Plugin Import job from indeed according to your given parameter.

= Features =
1. Import job from indeed.
2. Custom import according to your parameter.
3. makes autoblogging.
4. Support WPMU.
5. Custom template option.
6. Set cron option.
7. Multiple Indeed account data import

More detail : http://socialcms.wordpress.com/


== Installation ==


1. Upload the **indeed-job-importer** folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go **Indeed Importer** in admin menu and add new importer search parameter click save button.
4. In importer list click **Featch Now** link.

== Frequently Asked Questions ==

* **Where to get Publisher Id?**

 go to https://ads.indeed.com/jobroll/ in XML Feed tab section

* **How to stop  auto fetch (cron)?**

 In importer list set status to inactive.

* **How to Set default post status?**

 In importe list click campaign name then see **WordPress Setting** section set **New Post Status** draft

* **How to Add some addtinal default content?**

 In importe list click campaign name then see **WordPress Setting** section in **Display Template**.

== Screenshots ==

1. screenshot-1.png  : screen shot admin indeed job importer add section
2. screenshot-2.png  : screen shot admin indeed job importer list.


== Changelog ==

= 1.0.2 =
* Fix WPMU cron error
* improve duplicate job check

= 1.0.1 =
* Add html tag support in Display Template

= 1.0 =
* Initial release

== Upgrade Notice ==

N/A