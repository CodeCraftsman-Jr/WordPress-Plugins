<?php

/*
* @Author 		ParaTheme
* @Folder	 	job-board-manager\themes\joblist

* Copyright: 	2015 ParaTheme
*/

if ( ! defined('ABSPATH')) exit;  // if direct access

				
	
	$html .= '<div class="company-list">Hello';		
				
			
	$html .= '</div>'; // .company-list	



	

