	jQuery(document).ready(function($)
		{	


			$('').wpColorPicker();
					
					


		});