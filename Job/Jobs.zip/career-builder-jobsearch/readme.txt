=== career builder job search plugin ===

Contributors: phpmentors

Author URI: http://www.phpmentors.in

Plugin URL:http://www.phpmentors.in/downloads/download-career-builder-job-search-widget/

Requires at Least: 3.0

Tested Up To: 4.2.1

Tags:job search, job search listing, widget, wordpress, wordpress.org,

Stable tag: 1.2
Simple widget which fetch jobs from careerbuilder.com api .

== 



Description ==

career builder job search plugin  is a simple widget which fetch jobs from careerbuilder.com api.


steps required:-

1.get Developer Key from career builder website for using its api.
its url is http://developer.careerbuilder.com


2.put your  title, keyword(ex. php),country code(ex. IN), and number of jobs(ex. 5),number of days back to look(b/w 1-30) that's you want to show in widget. 
3.Developer Key is required field without it it's api will not work.

