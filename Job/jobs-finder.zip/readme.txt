=== Jobs Finder ===
Contributors: allis741 
Donate link: http://www.onlinerel.com/wordpress-plugins/
Tags: job vacancies, employment, jobs, job, career, work from home, promote, feed, rss, widget, sidebar
Requires at least: 2.5
Tested up to: 3.3.1
Stable tag: trunk

Plugin "Jobs Finder" gives visitors the opportunity to more than 1 million offer of employment. Jobs search for USA, UK, Canada, Australia
 
== Description ==

Plugin "Jobs Finder" gives visitors the opportunity to more than 1 million offer of employment.
Jobs search for USA, UK,  Canada, Australia. 
Jobs Finder are saved on our database, so you don't need to have space for all that information. 
 
 == Installation ==

1. Upload the folder jobs-finder to the /wp-content/plugins/ directory
2. Activate the plugin Jobs Finder through the 'Plugins' menu in WordPress
3. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.

== Screenshots ==

1. Jobs Finder Widget on a website
2. Jobs Finder Widget in Admin panel
 
== Changelog ==
   
= 2.1 =

* Updated script
* Add more Screenshots

= 2.0 =

* Tested up to 3.3.1 WP     
* Updated script

= 1.9 =

* Fixed bugs in widget
* Tested up to 3.1.3 version WP

= 1.8 =

* Updated   system 
* Tested up to 3.1.1 version WP

= 1.7 =

 * Fix bugs.
 * Add more Screenshots

 = 1.6 =

 * Tested upto 3.1 WP and fix bugs

 = 1.5 =

* Updated feed system.                                                                                                                                     

 = 1.4 =
            
* Updated feed address.  

 = 1.2 =

* Fix bugs.

= 1.1 =  

* Fix bugs

= 1.0 =  

 * First stable version.
 