	jQuery(document).ready(function($)
		{	


			$('.job-bm-color, .featured_bg_color input').wpColorPicker();
					
					


		});