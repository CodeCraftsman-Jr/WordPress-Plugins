foliopress-wysiwyg
==================

WYSIWYG FCKEditor with custom Image Management and nice skin.