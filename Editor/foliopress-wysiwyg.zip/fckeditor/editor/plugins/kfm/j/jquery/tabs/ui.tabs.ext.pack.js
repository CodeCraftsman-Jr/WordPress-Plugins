/*
 * Tabs 3 extensions
 *
 * Copyright (c) 2007 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/TabsExtensions
 */
eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(2($){$.v($.l.5.q,{6:i,u:2(c,a){a=a||n;k b=1,t=1.4.g;2 8(){b.6=r(2(){t=++t<b.$5.p?t:0;b.m(t)},c)}2 3(e){7(!e||e.j){o(b.6)}}7(c){8();7(!a)1.$5.d(1.4.9,3);f 1.$5.d(1.4.9,2(){3();t=b.4.g;8()})}f{3();1.$5.h(1.4.9,3)}}})})(s);',32,32,'|this|function|stop|options|tabs|rotation|if|start|event||||bind||else|selected|unbind|null|clientX|var|ui|select|false|clearInterval|length|prototype|setInterval|jQuery||rotate|extend'.split('|'),0,{}))