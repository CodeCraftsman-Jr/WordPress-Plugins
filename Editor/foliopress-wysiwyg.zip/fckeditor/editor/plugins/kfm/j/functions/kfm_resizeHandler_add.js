window.kfm_resizeHandler_add=function(name){
	kfm_resizeHandler_addMaxWidth(name);
	kfm_resizeHandler_addMaxHeight(name);
}
