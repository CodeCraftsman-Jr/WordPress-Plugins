window.kfm_resizeHandler_addMaxWidth=function(name){
	if(kfm_resizeHandler_maxWidths.indexOf(name)==-1)kfm_resizeHandler_maxWidths.push(name);
}
