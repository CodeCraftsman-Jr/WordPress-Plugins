// see ../license.txt for licensing
llStubs.push('kfm_createEmptyFile');
llStubs.push('kfm_leftColumn_disable');
llStubs.push('kfm_leftColumn_enable');
llStubs.push('kfm_textfile_attachKeyBinding');
llStubs.push('kfm_textfile_close');
llStubs.push('kfm_textfile_createEditor');
llStubs.push('kfm_textfile_initEditor');
llStubs.push('kfm_textfile_keybinding');
