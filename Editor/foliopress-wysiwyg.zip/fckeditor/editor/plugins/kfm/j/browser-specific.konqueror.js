// see license.txt for licensing
function clearSelections(e){
// not possible yet
}
