<?php
$p=new kfmPlugin('codepress');
$kfm->addPlugin($p);
?>
