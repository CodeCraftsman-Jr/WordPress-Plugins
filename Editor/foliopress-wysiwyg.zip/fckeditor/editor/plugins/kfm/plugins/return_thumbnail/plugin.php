<?php
$p=new kfmPlugin('return_thumbnail');
$kfm->addPlugin($p);
?>
