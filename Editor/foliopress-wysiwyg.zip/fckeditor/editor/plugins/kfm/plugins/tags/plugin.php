<?php
$p=new kfmPlugin('tags');
$kfm->addPlugin($p);
?>
