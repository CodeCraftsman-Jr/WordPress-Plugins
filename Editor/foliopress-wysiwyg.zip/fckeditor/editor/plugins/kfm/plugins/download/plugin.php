<?php
$p = new kfmPlugin('download');
$kfm->addPlugin($p);
?>
