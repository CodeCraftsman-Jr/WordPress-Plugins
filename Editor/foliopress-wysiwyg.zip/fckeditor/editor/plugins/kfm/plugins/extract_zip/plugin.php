<?php
$p=new kfmPlugin('extract_zip');
$kfm->addPlugin($p);
?>
