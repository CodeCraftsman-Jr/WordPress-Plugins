<?php
$p=new kfmPlugin('return_file_id');
$kfm->addPlugin($p);
?>
