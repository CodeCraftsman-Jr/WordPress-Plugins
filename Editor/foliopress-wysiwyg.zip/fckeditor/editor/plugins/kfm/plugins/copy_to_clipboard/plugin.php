<?php
$p=new kfmPlugin('copy_to_clipboard');
$kfm->addPlugin($p);
?>
