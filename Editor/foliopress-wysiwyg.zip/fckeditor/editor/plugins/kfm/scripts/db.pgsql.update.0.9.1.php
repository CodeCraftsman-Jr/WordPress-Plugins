<?php
	$kfmdb->query("ALTER TABLE ".KFM_DB_PREFIX."directories DROP physical_address");
?>
