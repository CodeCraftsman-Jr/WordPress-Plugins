<?php
require_once('../initialise.php');
$kfm->adminPage();
?>
