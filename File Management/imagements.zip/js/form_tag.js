jQuery(document).ready(function($){
        $('#commentform').attr('enctype','multipart/form-data');
});