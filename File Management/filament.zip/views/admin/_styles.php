<style type="text/css">
  #adminmenu .toplevel_page_filament .wp-menu-image img {
    max-width: 16px;
    max-height: 16px;
  }
</style>