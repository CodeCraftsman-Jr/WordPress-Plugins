=== upload-rapidshare ===
Contributors : jessai, corimanon, youte , peggy
Tags : upload , file , rapidshare, fichier
Requires at least :
You can upload your files on rapidshare.

== Description ==

Just upload your files on rapidshare.

== Installation ==

Download the "upload rapidshare plugin's" on your blog, Activate it.

upadate ver 1.3.2 : just click on link to put it in post.



