=== simpleAdPlacement ===
Contributors: hkothari 
Donate link: http://www.hydronitrogen.com/
Tags: advertising, ads, placement, adsense
Requires at least: 2.0.2
Tested up to: 3.0.1
Stable tag: 0.95

simpleAdPlacement aims to be just what its name says. It allows you to easily place your
advertisements in specified locations of pages.
Currently it supports placement of advertisements at the bottom of single posts, at the bottom
of pages, above the footer, and the use of shortcodes.

== Description ==

simpleAdPlacement aims to be just what its name says. It allows you to easily place your
advertisements in specified locations of pages.

* Single Posts - This refers to the area after the post on the single post page. Usually before the tags and comments, etc.
* Above the footer - This refers to the area right above your footer div.
* Bottom of Page - This is the area at the very bottom of the page. After the footer.
* Shortcodes - This allows you to use shortcodes to place ads wherever you want. Just insert [simpleAdPlacement]

== Frequently Asked Questions ==

= Where do I find the settings for the plugin? =
In the admin backend, look under Settings -> SimpleAdPlacement

= Why is the ad for "Above Footer" not showing up above the footer? =
Your footer div is probably not id'd as "footer" try to look in the source of your site to find the id of the footer and change it in the configuration tab.

== ChangeLog ==

= 0.95 =
* Custom footer div ID in settings.

= 0.92 =
* Added jQuery tabs to the administration interface to make it a little nicer to look at.

= 0.91 =
* Added forcing of shortcodes on widgets, just in case they're not enabled.
* Fixed the tested up to tag.

= 0.90 =
* Added placement before the footer.
* Note, prefooter placement might not work if your theme's footer is not id'd as "footer"

= 0.81 =
* Fixed minor admin bug.

= 0.80 =
* Added shortcode support.

= 0.75 =
* Added the ability to add advertisements to the bottom of pages as well.

= 0.5 =
* This is the first released version, you can add things to the bottom of post pages.
