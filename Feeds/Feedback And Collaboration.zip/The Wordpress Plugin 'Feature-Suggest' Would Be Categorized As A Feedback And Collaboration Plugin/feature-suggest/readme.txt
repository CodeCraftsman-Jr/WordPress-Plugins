=== Feature Suggest ===
Contributors: ethanshaw 
Tags: community, content, News, submission, post
Requires at least: 3.0
Tested up to: 3.0.1
Stable tag: /trunk/

Engage your site's community by allowing your site's visitors to suggest and vote on new features from a page or post of your choice.

== Description ==

Engage your site's community by allowing your site's visitors to suggest and vote on new features from a page or post of your choice.

Read more or explore the demo on the [Feature Suggest plugin][1] page.

 [1]: http://sailbirdmedia.com/feature-suggest-plugin
== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

Alternatively you can also automagically this plugin via the [WordPress Plugin Installer][1] tool.

 [1]: http://coveredwebservices.com/wp-plugin-install/?plugin=feature-suggest
== Frequently Asked Questions ==

Q) How do I display the Feature Suggest plugin?

A) Place the shortcode [featuresuggest] in any post or page.
== Screenshots ==
1. Front end display of the Feature Suggest submit box and voting section.

== Changelog ==
1.0 Public release of pugin.