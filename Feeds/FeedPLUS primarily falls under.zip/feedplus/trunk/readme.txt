=== Feed Plus ===
  Contributors: Eric-Oliver Maechler
  Donate link: http://www.1grad.ch
  Tags: feed, editor, banner, code
  Version: 2.1
  Requires at least: 2.7+
  Tested up to: 3.1
  Stable tag: 1.2
  License: GPLv2 or later
  License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
  Mit Feed Plus ist man in der Lage Werbung, Infos und andere wichtige Dinge direkt im Feed zu publizieren.
  
  [Created by Eric-Oliver M&auml;chler](http://www.1grad.ch "www.1grad.ch")
  

  
== Installation ==
  1. Upload des Plugins in den Plugin-Ordner /wp-content/plugins/
  2. In der Plugin-Administration ihres Blogs kann nun Feed Plus aktiviert werden.
  3. Feed Plus nun in der Feed Plus Administration konfigurieren.
  4. Ein Beitrag schreiben und ver&ouml;ffentlichen und dann das Ergebniss bewundern.

= Licence =
  Good news, this plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal. If you will using this Plugin on a commercial blog - its also free of charge but please send me an email (plugins@annu.biz) and inform me.

== Screenshots ==
No Screenshots aviable yet
  
  
  
== Frequently Asked Questions ==
  = Wie merke ich, ob es eine neue Version des Plugins gibt? =
  Dann wird man im Plugin Ordner deiner WP Installation auf die Upgrade-M&ouml;glichkeit aufmerksam gemacht.
  = Was muss ich tun, wenn ich ein Bug bemerke? =
  Man schickt dem Entwickler eine eMail an plugins@annu.biz und meldet den Bug und wie man ihn nachvollziehen kann.
  
== Upgrade Notice ==

== Changelog ==
  = v2.0 (12/30/2013) =
  * upgrade to v2.0 a stable version
  = v1.6 (04/17/2011) =
  * upgrade to v1.6 a stable version
  * debug of reset-button
  * update social media section
  = v1.2 (02/05/2011) =
  * upgrade to v1.2 a stable version
  * correction of misspellings
  = v1.1 (02/05/2011) =
  * upgrade to v1.1.1
  = v1.0 (02/05/2011) =
  * upgrade to v1.0
  * add in the official wordpress plugin download sektion
= v0.9 (12/26/2008) =
  * first releasing
  