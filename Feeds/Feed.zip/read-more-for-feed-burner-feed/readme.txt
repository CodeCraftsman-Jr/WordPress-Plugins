=== read-more-for-feed-burner-feed ===
Contributors: Vinay PN
Donate link: http://www.vinaypn.com/
Tags: Read More Feed Burner, Feed Burner
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows adding Read More link to WordPress feeds deliverd through Feed Burner 

== Description ==

Provides an interface in the dashboard, where you can add custom read more link to your wordpress feeds diverted through feed burner as feed burner dont have option to add read more link.


== Installation ==

1. Click on Add new in Plugin section of wordpress dashboard
2. Upload read-more-for-feed-burner-feed plugin
3. Click activate
4. For Changing default Read More Link go to settings click Read More Feed Burner then Enter text you require and hit Save button
   Thats it Enjoy!


== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets 
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png` 
(or jpg, jpeg, gif).
2. This is the second screen shot

