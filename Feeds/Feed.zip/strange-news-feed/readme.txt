=== Strange News Feed ===
Contributors: EddieJ
Tags: weird, strange, bizarre, news, stories, rss, feed, widget, shortcode
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 1.0

The Strange News Feed plugin has been replaced. Please search for the Entertainment News plugin.

== Description ==

~~The Strange News Feed plugin will pull strange news stories and odd products from gloomwire.com. The content can be displayed in a widget or on a post/page using short code.~~

This plugin is outdated and may not work anymore, please see our newer version by searching Entertainment News on WordPress. If you want to see the page or manual install see the <a href="http://wordpress.org/extend/plugins/entertainment-news/">Entertainment Plugin Page</a>

== Changelog ==

= 1.0 =
* Stable release

= 1.1 =
* deprecated plugin and updated readme to reflect replacement plugin

