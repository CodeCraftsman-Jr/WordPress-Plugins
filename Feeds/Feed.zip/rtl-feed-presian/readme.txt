=== Plugin Name ===
Contributors: behrouzpc
Donate link: http://www.iflashlord.com/
Tags: rtl, feed , persian , farsi , iflashlord
Requires at least: 2.0.2
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

  Make Wordpress Feed RTL and Tahoma Font 
== Description ==

 Writing and view correct font (Tahoma) problem RTL, the Persian language, for WordPress feeds. 

== Installation ==

1. Upload `rtlFeedPersian.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =
Initial version.

= 1.1 =
Add content to a P tag.