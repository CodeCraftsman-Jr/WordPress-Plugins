=== Voting - Feelbacks plugin by Vicomi (Better than Rating-Widget & Star Rating System)  ===
Contributors: Vicomi
Donate link: http://www.vicomi.com
Tags: rate, rating, voting, vote, rates, votes, star, stars, multi-rating, post rating, like, facebook like, Rating-Widget, Star Rating, star rating, thumb rating, rating platform, rating system, feelbacks, post rating, comment rating, feel backs, feelback, feelbacks, buzzfeed, buzz, buzz feed, playbuzz, play buzz, URL Shortener, bitly, tinyurl, Goo.gl, Google+1, Google Analytics, comments, comment, commenting, comment form, widget, moderation, comments spam, vicomi, add comments, comments SEO, website comments, disqus, livefyre, facebook comments, emotions, emoticons, spam, anti spam, engagement, sexybookmarks, shareaholic, shareholic, facebook, twitter, linkedin,  Google Plus, Google, Instapaper, Wish List, Digg, Gmail, Google Bookmarks, Translate, Tumblr, AIM, Yahoo Messenger, Delicious, StumbleUpon, mister wong, evernote, add this, addtoany, share this, sharethis, share and follow, share and enjoy, sharing is sexy, sharing is caring, yahoo, reddit, hackernews, houzz, yummly, tweet button, twitter button, fark, buffer, myspace, orkut, netlog, hubspot, weheartit, printfriendly, yammer, wanelo, pinterest, google translate, bookmarks, social, email button, social share, socialize, sociable, sharebar, bookmark button, share button, social bookmarking, bookmarks menu, bookmarking, share, seo, analytics, stats, sharing, facebook like, facebook recommend, WPMU, mutisite, sumome, shortcode, yaarp, yarpp, nrelate, outbrain, linkwithin, related content, related posts, related, popular posts, popular, thumbnails, recommendations, recommendation widget, avatars, visual comments, community, email, notification, profile, threaded, widget, tools 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires at least: 2.8 or higher
Tested up to: 4.0
Tested up to: 4.0
Stable tag: 1.08

Star Rating System? voting? so 90's! Say hello to the new Feelbacks vote system! A new emotional rating widget and votes tool 

== Description ==


Rating: At the end of an article, readers can evaluate the content according to five emotions.  
Feelbacks rating system includes related content recommendations and social analytics dashboard. This votes plugin allow any website to engage and grow their traffic, market their content (both internally and externally via facebook share),  gain insights, and monetize their traffic.
Vicomi Feelbacks is a FREE voting platform. Voting with a new cool, Stylish graphic interface with the best voting analytics tools(not only stars) You can choose your own design. The platform presents web-based voting in a visual, 
interactive and personalized manner for the first time; helping your website to increase session time, engagement, retention, stickiness and page views amount 
(internal site circulation) while giving readers the benefit of a more meaningful and relevant voting experience (better voting platform, better from stars).
Add Feelbacks voting platform in minutes!

** Feelbacks Demo: ** [vicomi.com/products/feelbacks/demo](http://www.vicomi.com/products/feelbacks/demo) 

= Vicomi for WordPress =

1. Star Rating System doesn't really gives you anything. Star system is so 90's! Get a free voting system that allow your users to vote and express their feelings. 
1. A FREE Rating-widget - allow your users to rate with more than stars or a simple rating system. 
1. Allowing stylish emotional voting and rating. Choose your own look and feel, not only stars or a simple Star Rating System.
1. Choose your Rating-widget and Voting design! When you register - choose your Feelbacks platform design for your own needs.
1. Don't like the design? Contact us and we will make you your own rating-widget design.
1. Not only is it free, it increases user engagement to your website. Rating results are shown immediately.
1. Rating-Widget got better and emotional - Install our emotional Rating-Widget and use it to increase your traffic. More then just voting - more then Upvote & Downvote.
1. Increased page views amount by 3%-12% (more traffic!) thanks to the recommendation widget that recommends other content within your website based on user's emotional rating.
1. Easy to install, 5 minute installation! Add this Feelbacks rating platform for free.
1. Uses the Vicomi API. Gives you free admin and the best analytics web tools.
1. Customize and optimize Feelbacks rating system and design in WordPress with a cool visual platform. 
1. More then Multi Rating - allow your users to vote with an emotional voting and rating system.
1. New option to block specific URLs/Web sections from having the Feelbacks Voting platform within this section only

= Vicomi Features =

1.  Fast integration to wordpress.
1.  Gives you much more than a Star Rating System.
1.  Increase user's engagement within your site. Allow your users to rate with their emotions and not a stars rating system.
1.  Choose your own look and feel.
1.  Recommendation content widget for increasing page-views and engagement. 
1.  Emotional stylish voting platform - better then stars and rating systems.
1.  Free analytics and admin tools.
1.  Option to remove specific sections from displaying the Feelbacks voting platform


== Installation ==

Installation

1. Download Vicomi Feelbacks plugin file to add Feelbacks to your website. 
1. In your WP Admin panel click on Plugins (Admin menu on the left). 
1. Add the new Feelbacks plugin from the Plugins menu. 
1. Upload the file (choose the vicomi-Feelbacks.zip plugin file) to the 'wp-content/plugins/' directory inside of WordPress and then click Install Now. 
1. After the Feelbacks plugin installation has completed, click Activate Feelbacks Plugin. 
1. Add your Vicomi Feelbacks account details, or create a new account (from vicomi.com website) if needed. 

Via wordpress Feelbacks plugin page - Login to wordpress Feelbacks plugin page, search for vicomi Feelbacks plugin, install it, activate it, enter your Vicomi Feelbacks account details and your done.

More documentation

Go to http://www.vicomi.com

== Frequently Asked Questions ==

= Do I have to register? = 

Yes, you need to creat a Vicomi rating-widget account at Vicomi.com website.

= Where do I register? =

Please go to http://www.vicomi.com

= Can I sign up for free? = 

Yes, you can sign up for free and get your free account and free Feelbacks platform.

= Is the Rating-widget a responsive Rating? Ready for mobile?

Yes it is! 

= How many votes - ratings per article/page can my users vote? = 

You have unlimited votes - rating per page.

= Is the rating-widget FREE? will it stay FREE?

The rating-widget is free and the rating will stay free

= How do I get to the Feelbacks rating-widget analytics page after I register? = 

You will get an email with all the information. Or, go to the moderation Feelbacks page at: http://dashboard.vicomi.com/

= How long till I see the recommendation widget working? = 

The recommendation box has 3 articles to recommend. You need at least 3 articles with Feelbacks votes inside your website till you see the recommendations. 

= Can I change the emoticons (icons) to what I choose? = 

Yes you can, in your registration page you may change the icons and design.

= Do you have a SSL dashboard login ? = 

Yes we do have SSL dashboard login (Secure login). Please login to: https://dashboard.vicomi.com/

= What is the difference Rating-widget or a Star Rating System to this one?

A Rating-widget or a Star Rating System gives your users only one way to express what they feel: With a star or a Rating-widget. Feelbacks allow your users to vote and say how they feel.


== Screenshots ==

1. This screen shot shows Vicomi Feelbacks system and recommendations system.
2. Choose your own design. Buttons or emoticons.
3. Choose your own color.
4. If you choose emoticons, this is an example for how it would look like.
5. Mobile look and feel - for responsive websites.
6. Mobile responsive design - a button at the left side.
7. Mobile responsive design - emoticons design.


== Changelog ==

= 1.0 =
* First Version released

= 1.01 =
* Adding plugin info

= 1.02 =
* Adding more design options

= 1.03 =
* Bug fix 

= 1.04 =
* Minor changes

= 1.05 =
* Adding analytics dashboard options

= 1.06 =
* Adding voting design options

= 1.07 =
* Bug fix

= 1.08 =
* Added an option to block specific URLs/Web sections from displaying the Feelbacks Voting platform within this section only


== Upgrade Notice ==

= 1.0 =
First version is available

= 1.01 =
* Adding plugin info

= 1.02 =
* Adding more design options

= 1.03 =
* Bug fix 

= 1.04 =
* Minor changes

= 1.05 =
* Adding analytics dashboard options 

= 1.06 =
* Adding voting design options

= 1.07 =
* Bug fix

= 1.08 =
* Added an option to block specific URLs/Web sections from displaying the Feelbacks Voting platform within this section only

== A brief Markdown Example ==

Here's a link to [Vicomi](http://www.vicomi.com/ "Vicomi Feelbacks Platform") and one to [Vicomi Tech Blog][Vicomi Tech Blog].
Visit Vicomi webstie and tech blog for updates. Follow us in twitter for the wordpress plugin updates as well.

[Vicomi Tech Blog]: http://blog.vicomi.com/
            "Read Vicomi Tech blog for updates of the Wordpress Plugin"


`
