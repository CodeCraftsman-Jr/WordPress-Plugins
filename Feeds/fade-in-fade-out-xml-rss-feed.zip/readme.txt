=== Fade in fade out xml rss feed ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/
Author URI: http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/
Plugin URI: http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/
Tags:  wordpress, plugin, widget, fade in, fade out, rss, xml, feed
Requires at least: 3.5
Tested up to: 4.3.1
Stable tag: 7.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This plugin directly retrieve title from RSS XML feed and create the fade in fade out effect in the wordpress website.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/](http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/)

* <a href="http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/">Live demo</a>
* <a href="http://www.gopiplus.com/work/">Plugin Homepage</a>	
* <a href="http://www.gopiplus.com/work/plugin-list/">All plugin list</a>
* <a href="http://www.gopiplus.com/work/about/">About author</a>

Now a day's everyone use fade in fade out text in some portion of the website to attract the user. So i have created new plug-in to do this. This plug-in directly retrieve title from RSS feed and create the fade in fade out effect in the word press website.

By default, the script fades from black-to-white upon enter, and white-to-black upon exit.

Do you want to create the fade in fade out effect for your own content? Then use <a href="http://www.gopiplus.com/work/2011/04/22/wordpress-plugin-wp-fadein-text-news/">WP fade in text news</a> plugin.
			
*	Free.
*	Easy to customize.
*	Support all browser.
*	Read title from RSS feed.
*	Short code available for pages and posts.

= Translators =

* Tamil (ta) - [Gopi Ramasamy](http://www.gopiplus.com/)
* Polish (pl_PL) - [Abdul Sattar](https://www.couponmachine.in/)

== Installation ==	

**Method 1**	

[File upload using ftp](http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/)	 
 
**Method 2**	
			
[Direct upload from website admin](http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/)	 

**Method 3**

[Upload from website admin with ZIP file](http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/)	 	

== Frequently Asked Questions ==

Q1. How to arrange the plugin fade-in setting?

Q2. Is possible to add more short code in the same page or posts?

Q3. I cant find the short code?
		
Answer : [Answer](http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/)		

== Screenshots ==

1. Front Page. http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/

2. Admin Page. http://www.gopiplus.com/work/2011/04/29/wordpress-plugin-fade-in-fade-out-xml-rss-feed/

== Upgrade Notice ==

= Version 1.0 =			
					
First version

= Version 3.0 =

Tested up to 3.3.1

= Version 5.0 =

Tested up to 3.4.1
Slight change in the short code, Please find the new short code for your gallery

= Version 6.0 =

New demo link, www.gopiplus.com

= Version 6.1 =

Tested up to 3.4.2

= Version 6.2 =

Tested up to 3.5

= Version 7.0 =

Tested up to 3.6
Added some security feature.

= Version 7.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (fade-in-fade-out.po) available in the languages folder. Translators Welcome.

= Version 7.2 =

1. Tested up to 3.9
2. Added some security feature.
3. Now it using fetch_feed() wordpress method to load rss feed. (fetch_feed() uses the SimplePie and FeedCache functionality for retrieval and parsing and automatic caching)

= Version 7.3 =

1. Tested up to 4.0

= Version 7.4 =

1. Tested up to 4.1

= Version 7.5 =

1. Tested up to 4.2.2

= Version 7.6 =

1. Tested up to 4.3

= Version 7.7 =

1. Tested up to 4.3.1
2. Text Domain slug has been added for Language Packs.

== Changelog ==

= Version 1.0 =			
					
First version

= Version 3.0 =

Tested up to 3.3.1

= Version 5.0 =

Tested up to 3.4.1
Slight change in the short code, Please find the new short code for your gallery

= Version 6.0 =

New demo link, http://www.gopiplus.com

= Version 6.1 =

Tested up to 3.4.2

= Version 6.2 =

Tested up to 3.5

= Version 7.0 =

Tested up to 3.6
Added some security feature.

= Version 7.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (fade-in-fade-out.po) available in the languages folder. Translators Welcome.

= Version 7.2 =

1. Tested up to 3.9
2. Added some security feature.
3. Now it using fetch_feed() wordpress method to load rss feed. (fetch_feed() uses the SimplePie and FeedCache functionality for retrieval and parsing and automatic caching)

= Version 7.3 =

1. Tested up to 4.0

= Version 7.4 =

1. Tested up to 4.1

= Version 7.5 =

1. Tested up to 4.2.2

= Version 7.6 =

1. Tested up to 4.3

= Version 7.7 =

1. Tested up to 4.3.1
2. Text Domain slug has been added for Language Packs.