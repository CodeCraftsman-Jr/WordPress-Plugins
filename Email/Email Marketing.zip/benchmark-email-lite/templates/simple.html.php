<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>TITLE_HERE</title>
<table border="0" width="100%" style="background-color: #ffffff;">
	<tr>
		<td align="center">
			<table border="0" width="650" style="background-color: #ffffff;">
				<tr>
					<td align="left" style="border-bottom: 1px solid #000000;">
						<h1 class="alignleft" style="font-family: 'Open Sans', sans-serif; font-size: 23px;">TITLE_HERE</h1>
						<img class="alignright" src="http://www.gravatar.com/avatar/EMAIL_MD5_HERE?s=40" />
					</td>
				</tr>
				<tr>
					<td align="left" style="font-family: Georgia, 'Times New Roman', 'Bitstream Charter', Times, serif; font-size: 14px;">
						BODY_HERE
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
