=== Adrotater Email Add-on ===
Contributors: xylus, karangadhavi
Donate link: http://xylusthemes.com/
Tags: ad,ads,email,adrotate,adrotate add-on,banner, commercial, admin, advertise, adrotator, 2014, plugin,rotator,advertiser, publisher, adsense,automatic email,statistics, stats, report, advert, adverts,javascript, jquery, tracking, clicks, impressions, rotate,add-on,addon,best,great,mail
Requires at least: 3.8, PHP5.3
Tested up to: 4.3
Stable tag: 1.0.3
License: GPLv2 or later

Adrotater Email add-on is an add-on plugin for AdRotate plugin. This plugin adds Email functionality to Adrotate Plugin

== Description ==
Adrotater Email add-on is an add-on plugin for AdRotate plugin. This plugin adds functionality to send emails to your advertisers with monthly ad reports.

Adrotater Email add-on also provide functionality to edit email template and u can set as per your Requirement and send ad reports to your advertisers.

== Installation ==
1. Install and Activate [AdRotate](https://wordpress.org/plugins/adrotate/) Plugin if it is not activated.
2. Install Adrotater Email Add-on either via the WordPress.org plugin directory, or by uploading the files to your server
3. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

= What is basic need to activate this plugin? =

You need to install and activate [AdRotate](https://wordpress.org/plugins/adrotate/) plugin to active this plugin.

= I can active this plugin without Adrotate plugin? =

No, You must need a [AdRotate](https://wordpress.org/plugins/adrotate/) plugin to active this plugin.

== Screenshots ==

1. Screenshot 1
2. Screenshot 2
3. Screenshot 3

== Changelog ==

= 1.0.0 =
* initial release

= 1.0.1 =
* Added: From Name option.
* Added: From Email option.
* Added: Cc option.
* Added: Reply To option.


= 1.0.2 =
* Added: Add Advertiser Functionality

= 1.0.3 =
* Fix: Fixed Some Bugs Generated due to adrotate plugin update.

