<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Plugin_Name
 * @subpackage Plugin_Name/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
PHONE

 * @package    Ad_Rotate_Email_Addon
 * @subpackage Ad_Rotate_Email_Addon/includes
 * @author     Dharmesh Patel <dharmesh@xylusinfo.com>
 */
class Ad_Rotate_Email_Addon_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function deactivate() {

	}
}
