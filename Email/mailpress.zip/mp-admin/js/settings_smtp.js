// settings_smtp

jQuery(document).ready( function(){ 
		jQuery('#smtp-auth').change( function() {
			jQuery('#POP3').toggle();
		});
});
