<?php

/* Capability Groups */

$capability_groups = array(
					'admin' => __('Admin', MP_TXTDOM), 
					'mails' => __('Mails', MP_TXTDOM), 
					'users' => __('Users', MP_TXTDOM),
);
