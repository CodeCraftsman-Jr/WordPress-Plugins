<?php
class MP_AdminPage extends MP_adminpage_
{
	const screen 		= MailPress_page_subscriptions;
	const capability 	= 'MailPress_manage_subscriptions';
	const help_url		= false;
	const file        	= __FILE__;
}