<?php
abstract class MP_tracking_recipient_ extends MP_tracking_xml_
{
	public $folder = 'recipients';
}