<?php
class MP_Autoresponder_events_comment extends MP_options_
{
	var $path = 'autoresponder/events_comment';
}