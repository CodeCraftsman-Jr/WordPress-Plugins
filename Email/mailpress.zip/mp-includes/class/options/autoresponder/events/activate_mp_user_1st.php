<?php
class MP_Autoresponder_event_activate_mp_user_1st extends MP_autoresponder_event_
{
	var $id    = 5;
	var $event = 'MailPress_activate_user_1st';
}
new MP_Autoresponder_event_activate_mp_user_1st(__('Subscription 1st activation', MP_TXTDOM));