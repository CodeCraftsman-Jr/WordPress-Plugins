<?php
class MP_oEmbed_providers extends MP_options_
{
	var $path = 'oembed/providers';
}