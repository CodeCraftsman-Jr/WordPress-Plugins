<?php
class MP_Dashboard_widgets_comment extends MP_options_
{
	var $path = 'dashboard/widgets_comment';
}