<?php
class MP_Autoresponder_events_mailinglist extends MP_options_
{
	var $path = 'autoresponder/events_mailinglist';
}