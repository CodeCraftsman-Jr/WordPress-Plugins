<?php
/*
Template Name: monthly
*/

$this->get_template_part('_post');