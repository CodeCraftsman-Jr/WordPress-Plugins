<?php
/*
Template Name: form_visitor
Subject: [<?php bloginfo('name');?>] Copy of your submission
*/

$this->build->_the_title = 'Copy of your submission';

$this->get_template_part('_mail');