<?php
/*
Template Name: single
*/

$this->get_template_part('_post');