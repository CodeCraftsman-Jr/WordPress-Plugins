<?php /* _template */
$_classes = array(


'nopmb' 		=> "	border:none;
				border-spacing: 0px;
				border-collapse: collapse;
				margin:0;
				padding:0;",

'button'		=> "	border-radius: 11px;
				-moz-border-radius: 11px;
				-webkit-border-radius: 11px;
				-khtml-border-radius: 11px;
				border-style:solid;
				border-width:1px;
				color:#000;
				cursor:pointer;
				font-weight:bold;
				line-height:15px;
				margin:0;
				outline-color:-moz-use-text-color;
				outline-style:none;
				outline-width:0;
				padding:3px 10px;
				text-decoration:none;
				white-space:nowrap;
				-moz-box-sizing:content-box;",

'mail_link'		=> "  background:none repeat scroll 0 0 transparent;
				border:0 none;
				clear:both;
				color:#666;
				font-family:Verdana,Arial,sans-serif;
				font-size:10px;
				font-style:italic;
				line-height:5px;
				margin:0;
				padding:5px 0;
				text-align:center;
				vertical-align:baseline;",

'mail_link_a'	=> "  color:#666;",

'w100'		=> "	width:100%;",

'wauto'		=> "	width:auto;",

);
?>