<?php if (!class_exists('MP_theme_html_template_')) require_once('MP_theme_html_template_.class.php');

