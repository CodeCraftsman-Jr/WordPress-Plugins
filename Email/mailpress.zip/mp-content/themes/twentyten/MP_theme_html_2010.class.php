<?php
class MP_theme_html_2010 extends MP_theme_html_
{
	const HEADER_IMAGE_WIDTH = 700;
	const HEADER_IMAGE_HEIGHT = 147;

	var $style = 'style="color:#888;"';
}
new MP_theme_html_2010();