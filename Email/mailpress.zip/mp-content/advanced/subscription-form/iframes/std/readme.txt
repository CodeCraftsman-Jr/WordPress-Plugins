How to get a MailPress subscription form in an external site :

<iframe src='http://(mydomain.com)/wp-content/plugins/mailpress/mp-includes/action.php?action=get_form&iframe=std' />