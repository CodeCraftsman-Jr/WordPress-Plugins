=== Mail Getter ===

Contributors: tomascot
Tags: Mail, comments, get comments
Requires at least: ...
Tested up to: 3.2.1
Stable tag: 0.9


This plugin is intended to manage emails from post comments

== Description ==

Mail Getter provides a comma separated list of emails from users which commented
in one post.

You enter the Post ID and the plugin will retrieve the emails.

You can choose to get approved, pending or ALL comments

Also in the next version I will try to improve the method to get the Post ID.

== Installation ==

1- Upload the plugin folder to your WP plugin folder (typically /wp-content/plugins)

2- Go to the Administrator >> Plugin and activate Mail Getter.

== FAQ ==

�How can I get the Post ID?

When you are in the administrator, go to Posts (english version) and the Edit option
will have an anchor that looks like this http://www.example.com/wp-admin/post.php?post=220&action=edit
there you can see that says post=200, that the Post ID.

== Screenshot ==

1- Mail Getter UI, this is how it looks as it loads

2- Mail Getter UI, with a list of mails

== Changelog ==

==0.9==

In this version you can select between approved, pending or all comments.