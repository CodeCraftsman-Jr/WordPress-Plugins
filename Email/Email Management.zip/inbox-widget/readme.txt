=== Plugin Name ===
Contributors:      davidtcarson
Plugin Name:       Inbox Widget
Plugin URI:        http://buddypress.org
Tags:              buddypress, inbox, widget, messages
Author URI:        http://davidtcarson.com
Author:            David Carson
Requires at least: WP 3.2.1, BP 1.5
Tested up to:      WP 3.2.1, BP 1.5
Version:           1.5.01

Adds a widget option showing the three most recent private messages to logged in users of a BuddyPress powered website. 


== Installation ==

Install automtically from dashboard or upload manually to `/wp-content/plugins/` directory. Activate the plugin and look for the "Inbox" widget on your widget dashboard. Add widget to any widgetized area.   

== Screenshots ==

1. Preview of widget

== Change log ==
* 1.5.01 - Update for BuddyPress 1.5 
* .01 - Initial release.

