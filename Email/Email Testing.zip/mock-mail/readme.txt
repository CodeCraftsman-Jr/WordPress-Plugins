=== Mock Mail ===
Contributors: ampt
Tags: email, mail, mock, test, wp_mail
Requires at least: 3.3
Tested up to: 3.3.2
Stable tag: trunk

Email testing for WordPress.

== Description ==

Mock Mail lets you customise the configuration of PHPMailer during development for email testing.

See the [instructions](https://github.com/ampt/mock-mail/blob/master/README.md) for configuration examples.

== Installation ==

Use automatic installer

== Changelog ==

= 0.0.1 =

Initial release
