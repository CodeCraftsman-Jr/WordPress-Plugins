=== Plugin Name ===

a2zVideoAPI Wordpress Plugin: http://blog.svnlabs.com/a2zVideoAPI.zip

Plugin Name: a2zVideoAPI widget
Plugin URI: http://svnlabs.com/a2zvideoapi/
Description: a2zVideoAPI allows you to adds a sidebar widget to show video from various sites including youtube, dailymotion, google, vimeo, metacafe, blip.tv, hulu, 5min, myspace, ehow, break, flickr etc.
Author: Sandeep Verma
Contributors: Sandeep Verma
Donate link: http://svnlabs.com/a2zvideoapi/ 
Version: 0.7
Tags: a2zVideoAPI
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 4.3
Author URI: http://blog.svnlabs.com
Other: Curl must be on your server to use this plugin. This widget tested to latest version of wordpress.

== Description ==

Some API supported URL:
http://www.youtube.com/watch?v=mXMf9GOzzOA
http://www.dailymotion.com/video/x5z91e_lets-play-holi_music
http://video.google.com/videoplay?docid=-7577046582869136330&hl=en
http://www.vimeo.com/9573920
http://www.metacafe.com/watch/4230785/ghetto_star_weekly_randy_radermacher/
http://blip.tv/file/3272712?utm_source=featured_ep&utm_medium=featured_ep
http://www.hulu.com/watch/131066/saturday-night-live-we-are-the-world-cold-open
http://www.viddler.com/explore/coop/videos/54/
http://www.5min.com/Video/How-to-Organize-Your-Life-219728873
http://vids.myspace.com/index.cfm?fuseaction=vids.individual&videoid=51722257
http://vodpod.com/watch/2492783-reactos-install-screencast-tutorial
http://www.ehow.com/video_4983481_change-ip-address-windows-vista.html
http://www.break.com/usercontent/2009/4/How-to-Run-Linux-on-Windows-Ubuntu-699185.html
http://www.atom.com/funny_videos/sw_gangsta_rap_chronicles/
http://www.funnyordie.com/videos/4d47a07835/danny-mendlow-the-solution-to-racism-and-the-biggest-issue-in-the-world
http://www.flickr.com/photos/traceytilson/3033319841/

== Installation ==

1. Download a2zVideoAPI.zip
2. Extract and upload a2zVideoAPI.php to the plugins/ directory
3. Enable a2zVideoAPI Widget in the Plugin admin panel
4. Place a2zVideoAPI in the sidebar, and edit it to enter the Video URL

== Arbitrary section ==

Other Links:
http://code.google.com/p/a2zvideoapi/
http://github.com/svnlabs

Download API: http://www.svnlabs.com/a2zvideoapi/a2zVideoAPI.zip
Download Plugin: http://blog.svnlabs.com/a2zVideoAPI.zip

Follow me:

Facebook: http://www.facebook.com/svnlabs
Twitter: http://www.twitter.com/svnlabs

Subscribe me:
Youtube: http://www.youtube.com/user/svnlabs
Feeds: http://blog.svnlabs.com/feed/
