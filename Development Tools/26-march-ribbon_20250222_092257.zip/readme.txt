=== 26 March Ribbon ===
Contributors: Bub Rupam JCB
Tags: Bangladesh , boxtwobox , 26 march , Bangladesh Liberation War ,bangladesh independence day ribbon ,
Requires at Least: 2.6.0
Tested Up To: 3.3.1
Stable tag: 2.0

Bangladesh independence day ribbon

== Description ==
This is a wordpress ribbon plugin for **Bangladesh independence day** ,it's link with (http://en.wikipedia.org/wiki/Bangladeshi_Independence_Day ) .
If like this plugin just share with your friends .

For more update GO [Boxtwobox](http://facebook.com/boxtwobox)

**Creadits :**

* Graphic : [saif Rasel] (https://www.facebook.com/RSL13)

* Inspired By : [Tasfiq Hossain Khan] (http://www.facebook.com/3mc33.taz)

* Dedicate : [All wordpress group members](https://www.facebook.com/groups/Wordpress2Smashing/)

== Installation ==

1. Download the plugin zip archive.
2. Extract it in your `wp-content/plugins` folder or upload via admin panel.
3. Browse to your plugins section and active the plugin.

== Screenshots ==
1. Here's how the ribbon will appear on your website. 

== Changelog ==

= 2.0 =

*Add new icon