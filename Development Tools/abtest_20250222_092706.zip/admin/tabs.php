<div class="wrap">
  <h2 class="nav-tab-wrapper">
    <a class="nav-tab<?php if ($tab == 'experiments') echo ' nav-tab-active' ?>" href="?page=abtest">Experiments</a><a class="nav-tab<?php if ($tab == 'settings') echo ' nav-tab-active' ?>" href="?page=abtest&amp;action=settings">Settings</a><a class="nav-tab<?php if ($tab == 'debug') echo ' nav-tab-active' ?>" href="?page=abtest&amp;action=debug">Debug</a><a class="nav-tab<?php if ($tab == 'help') echo ' nav-tab-active' ?>" href="?page=abtest&amp;action=help">Help</a>
  </h2>
</div>
