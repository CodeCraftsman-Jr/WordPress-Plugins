<?php
add_option('abtest_show_dashboard_widget', 0);
redirect_to('index.php');
?>