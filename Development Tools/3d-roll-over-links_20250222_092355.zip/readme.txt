=== 3D Roll Over Links ===
Contributors: Richzendy
Tags: 3d roll over, roll, over, links, content, content post, 3D roll over, 3D roll over link
Donate link: http://www.richzendy.org/en/donaciones
Requires at least: 3.0
Tested up to: 3.9.1
Stable tag: 0.1.2
License: GPL3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin provides a cool 3D roll over efect to your links in all your post.

== Description ==

This plugin provides a cool 3D roll over efect to your links in all your post like this demo: http://antocas.com/demos/link-creativo-3d/ But in your wordpress without need change CSS tags or your html/PHP, all work (magic) it's done with javascript and them you don't need change any code in your wordpress installation.

== Installation ==

Just unzip in your wordpress instalation in wp-conten/plugins directory or use the main feature in your wordpress admin to install plugins from wordpress.org.

== Frequently Asked Questions ==

1. Can work in pages?
For this moment, no, only work to posts, but can be in plans to the future
1. Your plugin don't work for me
It is my first plugin, works for me, but in your enviroment can't work, if you can give me information to reproduce your enviroment maybe i can fix your problem and improvement my plugin (patchs can be accepted also)

== Screenshots ==

1. The frontend 
1. The plugin's settings

== Changelog ==

= 0.1.2 =
* Avoid do roll over on images - thank you bradkgriffin for report that
= 0.1.1 =
* Use jquery provided by WordPress core and all unused javascripts are removed.
= 0.1 = 
* First version
