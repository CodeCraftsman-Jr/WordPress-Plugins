=== 3D Snow ===
Author: vanMeerdervoort
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: snow, effect, winter, christmas
Requires at least: 3.0
Tested up to: 4.0.1
Stable tag: trunk

Add an Awesome 3D snow effect to your WordPress website! Just install and activate to make it snow!

== Description ==

This plugin creates an awesome 3D snow effect on the background of your WordPress website. It's based on the wonderful jQuery scripts by [Emil Maran](http://maran-emil.de/experiments/demo3/)

== Installation ==

1. Upload the plugin to your blog
2. Activate it


== Frequently Asked Questions ==

=Who are you?=

I'm a musician - check my band [Harmony Glen](http://www.harmonyglen.com) and designer.

=So you provide support?=

Yes. But please note: I'm fairly busy so it might take a while for me to answer.


== Changelog ==

=0.3=
* bugfixes
* compatibility with 4.0.1

= 0.2 =
* Fix - error in SVN update removed javascripts


= 0.1 =
* initial release
