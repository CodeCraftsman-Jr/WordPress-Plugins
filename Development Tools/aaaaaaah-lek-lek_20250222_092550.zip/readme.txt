=== Lek Lek ===
Contributors: valeriosza
Donate link: http://valeriosouza.com.br
Tags: frases, leklek
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Coloque o LekLek em seu WordPress facilmente

== Description ==

Coloque a frase da musica LekLek em seu WordPress, dentro do painel administrativo.

== Installation ==

Siga para Instalar

1. Fa�a Upload `aaaaaaah-lek-lek` para a pasta `/wp-content/plugins/`
1. Ative no menu 'Plugins' no seu WordPress


== Frequently Asked Questions ==



= What about foo bar? =



== Screenshots ==


== Changelog ==

= 1.0 =
* Lancada Vers�o 1.

== Upgrade Notice ==


== Arbitrary section ==

