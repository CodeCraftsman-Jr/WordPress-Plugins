﻿=== 24liveblog - live blogging tool ===
Contributors: 24liveblog
Donate link: http://www.24liveblog.com/
Tags: liveblog, live blogging, live blog, blog, ream time, live coverage, blogging, liveblogging, broadcast, live, streaming
Requires at least: 3.0
Stable tag: 1.1
Tested up to: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

24liveblog is a live blogging tool. No Ads. No Overages. No Viewer Limits. Free and easy to use for live blog.

== Description ==

24liveblog is a simple, functional, powerful and FREE live blogging tool. 24liveblog is the easiest way to live blogging. It is free to use and works with any type of website.<br>
Website : http://www.24liveblog.com

1. Real-time Live Blogging.
2. Unlimited SEO friendly Embedding.
3. Unlimited Events
4. Unlimited Page Views
5. Unlimited live blogs
6. Real-time statistics
7. Content Sharing/ Syndication
8. Mobile ready
9. Multi-editor supported
10. Live Comments

= Features =
1. Live Blogging<br>
24liveblog is designed to be easy for both blogger and readers. A new way for real time contents delivery.

2. Mobile Ready<br>
You can access the live contents from any major OS, mobile device, browser.

3. SEO Optimized<br> 
Our technology make you contents embed in your page. which help you get the best search engine optimization.

4. Self-Adapted UI Look<br>
Adapts to your site’s look and feel, No custom CSS.

5. Reliable and Powerful<br>
Cloud-base technology gives high-reliability. Help you handle the heavy traffic of breaking news.

6. Easy to Install<br>
Easily integrates with any major type of website platform. It will only take minutes to add live blog to your website.

7. NO Ads<br> 
We will not place any Ads or big brand logo in your contents page to give a perfect user experience.

8. Social Share<br>
To share the real-time contents to other social platform easily.

9. Multi-Langagues Support<br>
Multi editors can work together to live blogging.

= Contact US = 
> If you have any question, please feel free to contact http://www.24liveblog.com/contact  <br>
> Email : 24@24liveblog.com<br>
> Twitter : http://twitter.com/24liveblog<br>
> Facebook : http://www.facebook.com/24liveblog

== Installation ==
= Online installation: =
1. Please search "24liveblog" in wordpress.org and download the plugin.
2. You need to create a 24liveblog account when you first sigh up.

= Download installation: =
1. Please download the plugin via http://24liveblog.com/plugin/wp/24liveblog.zip and Upload the 24liveblog folder to  the `/wp-content/plugins/` directory.
2. Log in the wordpress dashboard, install the plugin. Activate the plugin through the 'Plugins' menu in WordPress
3. You need to create a 24liveblog account when you first sigh up.

== Frequently Asked Questions ==

How to use : http://www.24liveblog.com/how-to-wp/

= 1. Is 24liveblog free？ =
Yes, 24liveblog is free for any type of business.

= 2. Do you have customer support？ =
You can go to our website to get your help. 24liveblog.com/contact.

= 3. How long can you keep our data? =

We will not delete any user data. The data will be stored forever in our server. 

== Screenshots ==

1. Online Demo
2. Overview
3. Dashboard
4. Add News
5. Event Management
6. Real-time Statistics


== Changelog ==
= 1.1 =
1. Mobile UI Optimizated
2. Live Comments
3. Mulit-Contributors
4. Performance Improvement

= 1.0 =
First Release

== Upgrade Notice == 
Welcome to 24liveblog --- We are working on make a better live blogging experience for you.
