<?php 
define('WS_3721UP_ROOT',dirname(dirname(__FILE__)));
define('WS_3721up_ROOT_URL',plugins_url().'/1000eb/loader.php');


?>