=== Plugin Name ===
Contributors: waisir 
Donate link: http://www.waisir.com/donate
Tags: 千易,qianyi,1000eb,3721,3721up,disk,upload,file,post,网盘
Requires at least: 2.7.0
Tested up to: 3.3
Stable tag: 3.3.1

该插件可以快速的上传文件到网盘中并返回文件的链接到编辑器中以及储存文件链接等

== Description ==

= 相关网站 = 
* [歪世界](http://www.waisir.com/ "作者主页")
* [插件主页](http://www.waisir.com/1000eb "插件主页")
* [千易官网主页](http://1000eb.net/ "千易官网主页")
* [千易API开发者页面](http://1000eb.com/ "千易API开发者页面")

= 新版本特性 = 
* 在可视化编辑器中新增快速上传按钮
* 在HTML代码编辑器中新增快速上传按钮

= 新版本修复 = 
* 对3721UP更新为千易对API的更改做了相应更改


= 重要提示 =

* There should be a permission for you to use this plugin's api.
You can goto register an account on page <a href="http://1000eb.net/Reg.aspx" target="_blank">http://1000eb.net/Reg.aspx</a>
Then add you domain to the authority list.

* (在使用该插件之前,你需要去千易的官方网站注册一个账号,并添加你的网站域名到允许列表中.3721up会给你一个随即txt文件让你上传到你的网站根目录以验证你是网站的所有者.)

== Installation ==

1. Download and install it.

(下载此插件并安装到wordpress中.)

2. Register an account form the page (<a href="http://1000eb.net/Reg.aspx"  target="_blank">http://1000eb.net/Reg.aspx</a>) for the permission the 3721up for you.

(到此页面注册一个账号才能有使用该插件API的权限.)

3. login on this page http://1000eb.net/ and add your domain to the authority list

(到 <a href="http://1000eb.net/" target="_blank">http://1000eb.net/</a> 登录并添加你的网站域名到允许列表中.)

4. paste the code in the 3721up plugin setting page

(到3721up后台设置面板中添加你的API代码)

5. Now you can use this plugin!

(到此你能正常使用这个插件了.)

== Frequently Asked Questions ==

= 当我点击上传时出现这个错误:API变量无效 =

出现这个问题的原因是你未设置API信息或者API信息已经过期.
解决方法是:到千易官方网站获取最新的API粘贴到插件设置面板相应位置.

= 怎么注册千易账号? =

* 该页面即注册页面<a href="http://1000eb.net/Reg.aspx"  target="_blank">http://1000eb.net/Reg.aspx</a>

= 已经有千易的账号了,怎么添加允许域名? =

* 登录到千易的后台<a href="http://1000eb.net/m/"  target="_blank">http://1000eb.net/</a>

* 点击添加域名<a href="http://1000eb.net/manage/AuthDomain.aspx"  target="_blank">http://1000eb.net/manage/AuthDomain.aspx</a>

* 输入你的网站域名后,千易会让你上传一个txt文本验证文件到你的网站根目录

* 当你上传好了后点击验证,验证成功表明你有使用该插件的权限了.

= 二级域名可以添加吗? =

* 可以的,比如你要添加blog.example.com,你需要在添加域名的时候添加example.com就行了.


== Screenshots ==

1. Visual Editor
screenshot-1.png

2. Html Editor
screenshot-2.png

3. POST PAGE
screenshot-3.png

== Changelog ==

= Version 3.3.1 (2011-12-14) = 

= Version 3.3 (2011-12-13) = 

= Version 2.0 (2011-12-11) =

= Version 1.0 (2011-09-27) =


== Upgrade Notice ==
千易网盘WP插件最新版3.3.1发布啦!

