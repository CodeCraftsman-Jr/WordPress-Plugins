<div id="ws_3721up_admin_body">
    <div id="ws_3721up_main_wrap">
     		<h1>设置面板</h1>
            <h3>请输入官方提供的代码</h3>
    	<div id="ws_3721up_main_wrap_l">	
           
            <textarea id="ws_3721up_textarea_main" /><?php echo stripslashes(get_option('ws_3721up_api_setting_ori'));?></textarea>
            <input type="button" id="ws_3721up_setting_update" class="button-primary ws_3721up_button" value="更     新"/>
            
            
            <div id="ws_3721up_ajax_loading">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
          <!--  <input type="button" id="ws_3721up_diy_ctl" class="button-secondary ws_3721up_button" value="自定义操作"/>-->
          
          
        </div>
        <div id="ws_3721up_main_wrap_r">
		<textarea id="ws_3721up_textarea_main_r" readonly="readonly" disabled="disabled" />
<script src="http://static.1000eb.com/api/apiload-main.js?v=2.1"></script>

<script>
var com1000ebVar212 = {
    applyTo : "wordpress",
    receiveType : "html",
    getUploadConfigUrl : "http://1000eb.net/apiloader.aspx?id=212&k=jUdYQhpxL%2bTSGyQH7EarVA%3d%3d&t=1323543376",
    globalVarName : "com1000ebVar212"
};
</script>
//这仅是一个范例,勿抄袭!请自行到官方网站获取正确的API代码并贴入左侧文本框中

        </textarea>
            <div id="plugin_info">
                 <a href="http://1000eb.net/" target="_blank">获取API</a> 
                 <a href="http://www.waisir.com/1000eb" target="_blank">关于插件的更多信息</a>
                 <a href="http://www.waisir.com/wp_donate" target="_blank" style=""><img id="ws_3721up_donate" src="../wp-content/plugins/1000eb/styles/images/donate.gif"/></a>
            </div>
        </div>
        <div class="ws_3721up_clear"></div>
    </div>
</div>
