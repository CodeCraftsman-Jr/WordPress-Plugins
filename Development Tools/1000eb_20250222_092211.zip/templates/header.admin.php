<link href="<?php echo plugins_url();?>/1000eb/styles/admin.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="<?php echo plugins_url();?>/1000eb/javascripts/admin.js"></script>
