<link href="<?php echo plugins_url();?>/1000eb/styles/main.css" type="text/css" rel="stylesheet" />
<!--<script src="<?//php //echo plugins_url();?>/1000eb/javascripts/3721up.main.js"></script>-->
<!--<script src="<?//php echo stripslashes(get_option('ws_3721up_api_setting_api_src'));?>"></script>-->
	
