<!--<script src="http://static.1000eb.com/api/apiload-main.js?v=2.1"></script>-->



<!--<div id="ws_3721up" class="meta-box-sortables ui-sortable localhost" style="position: relative;">-->
<!--        <div class="postbox">
        <div class="handlediv" title="点击以切换"><br /></div>
       
            <h3 class="hndle">3721UP</h3>
            <div class="inside">-->
              <div id="ws_3721up_uploader"><a href="javascript:com1000ebUpload('<?php echo get_option('ws_3721up_api_setting_global_name');?>');" class="button-secondary">点击上传</a>
              <span>Powered by 千易 & <a href="http://www.waisir.com" target="_blank">歪世界</a></span>
              </div>
              <hr class="ws_3721up_hr"/>
              <textarea id="ws_3721up_callback_code" class="ws_3721up_textarea"></textarea>

              <!--<a onclick="ws_test();">click me!</a>-->
<!--              <input id="ws_3721up_file_add" type="button" value="添加"/>
              <input id="ws_3721up_diy_act" type="button" value="自定义操作"/>-->
              <div id="ws_3721up_filelist">
              
                 <div class="ws_3721up_ctl">
                    <select id="ws_3721up_ctl_select">
                        <option value='0'>选择操作</option>
                        <option value='1'>批量删除</option>
                    </select>
                    <input id="ws_3721up_ctl_apply" type="button" value="应用"/>
                    <input id="ws_3721up_ctl_manage" type="button" value="管理"/>
                    <input id="ws_3721up_ctl_update" type="button" value="更新"/>
                    <div id="ws_3721up_ajax_loading">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                    <div id="ws_3721up_ajax_msg"></div>
         		 </div>
          	
                  <div id="ws_3721up_file_h" class="widefat">
                        <input class="ws_3721up_fileselect_h" type="checkbox" />
                        <div class="ws_3721up_filename_h">文件名</div>
                        <div class="ws_3721up_fileurl_h">下载链接</div>
                        <div class="ws_3721up_filehtml_h">HTML代码</div>
                        <div class="ws_3721up_clear"></div>
                  </div> 
                  
                  
          <ul id="ws_3721up_filelist_ul_hide">
             
             	
          	<li>
           		<input id="ws_3721up_post_id" type="hidden" value="<?php echo the_id();?>"/>
          	    <input class="ws_3721up_filecode" type="hidden" value=""/>
                <input class="ws_3721up_filesize" type="hidden" value=""/>
                <input class="ws_3721up_fileselect" type="checkbox" />
                <input class="ws_3721up_filename" type="text" value=""/>
                <input class="ws_3721up_fileurl" type="text" value=""/>
                <input class="ws_3721up_filehtml" type="text" value=""/>
				<!--<input class="ws_3721up_file_save" type="button" value="更新"/>-->
                <input class="ws_3721up_file_delete" type="button" value="删除"/>
                <input class="ws_3721up_file_goto" type="button" value="查看"/>
            	
            </li>

          </ul> 
          <ul id="ws_3721up_filelist_ul"></ul> 
       
<!--		 <div class="updated">
         <p>+++<?php echo the_id(); ?>++++</p>
         <p><?php echo bloginfo('name')?></p>
         <p><?php echo plugins_url();?></p>
         
         </div>-->
              
          </div>
    <!--        </div>
        </div>-->
<!--    </div>-->
