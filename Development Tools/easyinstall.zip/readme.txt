﻿=== EasyInstall ===
Contributors: ejner69
Donate link: http://ejner69.net/donar/
Tags: install plugins, install themes, plugins, themes, admin
Requires at least: 3.2
Tested up to: 3.3
Stable tag: 0.1.1

Install plugins and themes from WordPress Extend without enter to dashboard. ¡Easy!

== Description ==

EasyInstall facilita la tarea de instalar nuevos plugins y themes desde el repositorio oficial de WordPress. Al instalar el plugin, se generará un "bookmark" (en JS) que deberá arrastrar a la barra de marcadores de WordPress. Luego, cada vez que desee instalar un plugin o theme desde el repositorio oficial de WordPress, deberá presionar ese marcador y el plugin/theme será instalado automáticamente en su instalación de WordPress.

[vimeo http://vimeo.com/34592288]

== Installation ==

1. Suba la carpeta del plugin al directorio `wp-content/plugins`
2. Actívelo desde el menú `Plugins` de WordPress.
3. Vaya a `Herramientas > EasyInstall`
4. Guarde en su barra de marcadores el enlace que se le proporcionará.
5. ¡Listo! Cada vez que desee instalar un plugin/theme desde el repositorio, haga click en el marcador.

== Changelog ==

= 0.1.1 =
* Correcciones a la documentación
* Implementación de Internacionalización
* Corrección del error que imposibilitaba instalar plugins/themes desde otra subpágina de este (por ejemplo `http://wordpress.org/extend/plugins/bbpress/stats/` generaba un error)
* Mejoras en la detección de privilegios de usuario y del sitio de referencia.

= 0.1 =
* Primera versión