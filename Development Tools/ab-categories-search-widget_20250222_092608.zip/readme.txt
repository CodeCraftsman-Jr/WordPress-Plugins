=== AB Categories Search Widget ===
Contributors: Agustin Berasategui
Donate link: http://ajberasategui.com.ar/donate/
Tags: widget, sidebar, search, form, categories, multiple
Requires at least: 3.5
Tested up to: 3.7
Stable tag: 0.2.5
License: GPLv2

Insert a search form widget that allows visitors to add category filters to the search query.

== Description ==

This plugin provides a Search Widget similar to the default WordPress one but with the abilty of adding category select 
lists to restrict the search query to only those categories.

Any comments, reviews, support questions are very much welcome!!! 

== Changelog ==

= 0.2.5 =

* 2014.02.04

Option added to display search result posts in random order.

= 0.2.4 = 
* 2014.01.06

Option added to hide mode connector (and, or).
Id added to search label for styling.

= 0.2.3 = 
* 2013.12.03

Added classes to category labels.

= 0.2.2 = 
* 2013.11.22

Fixed bug for themes not containing search.php template file.

= 0.2.1 = 
* 2013.11.22

Added the feature that when searching for empty string (just to filter by categories) it will use the search template.
Some bug fixes.


= 0.2 = 
* 2013.11.21

The widget has been modified so you can choose the search login between categories. Now you can choose to search 
posts that belongs to every category select or posts that belongs to one of the selected categories at least.

= 0.1.1 = 

Modified to search by default in top parent categories.

= 0.1 =
* 2013.09.19 first release.

== Installation ==

1. Upload this plugin to your Wordpress plugin directory( generally wp-content/plugins/ ).
2. Activate it in admin area.
3. Insert the AB Search Widget and choose the parent categories to add to form.

== Screenshots ==

1. Widget configuration options.
2. Default widget appearance inserted on a theme.

== Frequently Asked Questions ==

None right now.

= Known problems =

== Upgrade Notice == 

None
