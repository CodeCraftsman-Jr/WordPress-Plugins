<?php
/**
* @version FILE_VERSION
* Localization file for jquery.block.js script.
*/

/**
* Localization for Javascript  variable.
* 
* Localization text for backups script.
*/
return array(
	'activationFormTitle' => cssJSToolbox::getText('CJT Extension License Activation Form'),
);