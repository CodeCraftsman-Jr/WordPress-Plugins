<?php
/**
* @version FILE_VERSION
* Localization file for jquery.block.js script.
*/

/**
* Localization for Javascript  variable.
* 
* Localization text for backups script.
*/
return array(
	'confirmationMessage'  => cssJSToolbox::getText('The notice message wont displayed again! You still can install/upgrade the Plugin by going to the manage blocks page.  Would you really like to dismis this notice?'),
);