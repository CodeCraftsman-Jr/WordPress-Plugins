<?php
/**
* @version FILE_VERSION
* Localization file for jquery.block.js script.
*/

/**
* Localization for Javascript cjtJQueryBlockI18N variable.
* 
* Localization text for backups script.
*/
return array(
	'confirmUnlinkAll' => cssJSToolbox::getText('This operation is permanent and cannot be reverted!') .
																								"\n" .
																							 	cssJSToolbox::getText('Would you like to UNLINK all linked templates?'),
	'allTemplatesHasBeenUnlinkedSuccessful' => cssJSToolbox::getText('All Templates has been unlinked sucessfully!'),
	'editTemplateFormTitle' => cssJSToolbox::getText('Lookup Quick Template Edit Form'),
);