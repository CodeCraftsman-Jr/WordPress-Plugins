<?php
/**
* @version FILE_VERSION
* Localization file for jquery.block.js script.
*/

/**
* Localization for Javascript CJT_METABOX_BLOCKJqueryBlockI18N variable.
* 
*/
return array(
	'previewLinkTitle' => cssJSToolbox::getText('Preview Post/Page in a new window'),
);