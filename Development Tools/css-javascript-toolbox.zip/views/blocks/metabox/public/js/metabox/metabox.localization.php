<?php
/**
* @version FILE_VERSION
* Localization file for backups.js script.
*/

/**
* Localization for Javascript cjtMetaboxI18N variable.
* 
* Localization text for backups script.
*/
return array(
	'notifySaveChanges' => cssJSToolbox::getText('You\'ve changed CJT block content but you didn\' save this changes yet!')."\n".cssJSToolbox::getText('Would you really like to leave the page without saving this chnages'),
);