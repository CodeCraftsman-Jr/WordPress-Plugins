<?php
/**
* @version FILE_VERSION
* Localization file for backups.js script.
*/

/**
* Localization for Javascript cjtMetaboxI18N variable.
* 
* Localization text for backups script.
*/
return array(
	'confirmCreateBlockMetabox' => cssJSToolbox::getText('Would you like to create CJT block Metabox for this post?'),
);