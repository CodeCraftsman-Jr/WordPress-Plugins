<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Package_Package_Template_Folders_Folder
extends CJT_Models_Package_Xml_Definition_Frag_Frag_Template_Folders_Folder {} // End class