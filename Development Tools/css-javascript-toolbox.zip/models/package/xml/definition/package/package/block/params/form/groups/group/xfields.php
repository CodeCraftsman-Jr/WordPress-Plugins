<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Package_Package_Block_Params_Form_Groups_Group_xFields
extends CJT_Models_Package_Xml_Definition_Frag_Frag_Block_Params_Form_Groups_Group_xFields {} // End class