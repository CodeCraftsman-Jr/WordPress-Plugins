<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Frag_Frag
extends CJT_Models_Package_Xml_Definition_Abstract {} // End class.