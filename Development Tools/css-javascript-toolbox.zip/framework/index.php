<?php
/**
*  index.php just to prevent indexing of plugin folder
* 
* This directory used to hold the core/framework that might
* be used across this version and all feature versions.
* 
*/
