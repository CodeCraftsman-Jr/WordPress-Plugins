<?php
/**
* 
*/

/**
* 
*/
interface CJTIHookable {}
