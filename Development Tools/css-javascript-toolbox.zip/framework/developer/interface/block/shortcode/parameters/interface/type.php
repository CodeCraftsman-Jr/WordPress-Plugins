<?php
/**
* 
*/

/**
* 
*/
interface CJT_Framework_Developer_Interface_Block_Shortcode_Parameters_Interface_Type {
	
	/**
	* put your comment there...
	* 
	*/
	public function shortcode();
	
} // End class.