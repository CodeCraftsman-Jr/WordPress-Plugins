aalogwp
=======

aaLog PHP logging class as a WordPress plugin.

The docs for this plugin are at http://www.notoriouswebmaster.com/aalogwp-documentation/.

The docs for the aaLog class are at http://www.notoriouswebmaster.com/2013/07/01/aalog-a-logging-class-for-php/.

