<?php
$inc_plugins = array('stats-counter', 'dropbox-backup', 'database-backup-amazon-s3', 'amazon-s3-backup');