<?php

namespace Guzzle\Plugin\Cache;

\Guzzle\Common\Version::warn('Guzzle\Plugin\Cache\CacheKeyProviderInterface is no longer used');

/**
 * @deprecated This is no longer used
 * @codeCoverageIgnore
 */
interface CacheKeyProviderInterface {}
