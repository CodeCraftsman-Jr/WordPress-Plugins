debug-bar-pretty-output
=======================

Helper class for WordPress Debug Bar plugins - pretty prints variables.
