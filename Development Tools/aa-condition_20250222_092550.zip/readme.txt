=== AA Condition Plugin ===
	Contributors: aaextention
	Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ashik685%40gmail%2ecom&lc=US&item_name=Donate%20AA%20Extension%20%21&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
	Tags: aaextention,aaextension, conditon, login, shortcode, aa-condition
	Requires at least: 3.8
	Tested up to: 4.0
	Stable tag: 1.0
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	It is a simple condition based plugin, which is made with user logged and not logged in condition.

== Description ==


This plugin is specially made for people who wants to put some condition according to user logged or guest position , I mean not logged in position. I hope you can easily change aacondition.php file condition and can use the plugin with shortcode and here is the shortcode for you [aa_condition_button]. Very simple to use. If you need to know anything then contact to us via email (contact2us.aa@gmail.com) . We are happily help you.


### AA Condition Plugin by http://webdesigncr3ator.com

<br />


<strong>Plugin Features</strong><br />

* Coming soon




== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>AA Condition Plugin</strong>" activate it.<br />

<br />

and shortcode for you </strong> `[aa_condition_button]`<br />

then paste this shortcode anywhere in your page to display your custom condition<br />



== Screenshots ==

1. screenshot-1


== Changelog ==

	
	= 1.0 =
    * 2/11/2014 Initial release.