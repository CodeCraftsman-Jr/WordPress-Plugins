=== 3D Slider Slice Box ===
Contributors:ezhil
Author URI: http://profiles.wordpress.org/ezhil/
Plugin URL: http://wordpress.org/extend/plugins/3d-slider-slicebox/
Requires at Least: 3.0
Tested Up To: 3.5.1
Tags: content, featured, gallery, image, images, javascript, jquery, mobile, responsive, slider, slides, slideshow,3D slider, 3d slideshow, flash 3d slideshow
Stable tag: trunk
License:GPLv2 or later

3D Slider Slice Box is responsive 3d slider which enables you to create 3d slider without the use of flash.

== Description ==

3D Slider Slice Box is responsive 3d slider which enables you to create 3d slider without the use of flash. Has plenty of options like orientation, perspective and other cuboid option which would add glitz to your site. 

activate the plugin and just add the template tag `<?php if(sb_slides_display()){sb_slides_display();} ?>` 

This plugin was based on the tutorial from codrops  
<a href="http://tympanus.net/codrops/2011/09/05/slicebox-3d-image-slider/">http://tympanus.net/codrops/2011/09/05/slicebox-3d-image-slider/</a>

See <a href="http://tympanus.net/Development/Slicebox/">Demo</a>

<h4>Main features </h4>

* choose posts or enter images manually
* change perspective to have a great view
* orientation to change from horizontal to vertical and also random 
* you can display posts from a category
* excerpt words limitation
* responsive(auto compatible in all devices)

Note: if anyone wants any more features kindly add a topic in support.

<h4>My other plugins</h4>
<a href="http://wordpress.org/extend/plugins/custom-right-click-menu/">Custom right click menu</a> : define your own right click context menu for copyright and other issues 

<a href="http://wordpress.org/extend/plugins/custom-right-click-menu/">Gamma Gallery</a> : a stylish responsive image gallery for wordpress. It comes with a great full screen view and options for slideshow play/pause and automatically enhances itself to any resolution.


== Installation and usage ==

 - Add and activate the plugin, add the template tag `<?php if(sb_slides_display()){sb_slides_display();} ?>` 
 - Enter the no of slides required
 - Select the category
 - Select other slider properties for extensive usage.
 - The width and height of the images should be even for the slider to work properly.

== Changelog ==
 
 = 1.1 =
 * options for manually adding images rather than from posts
 * fixed xss vulnerablities

 = 1.2 =
 * fixed notices generated in debug mode
 
 = 1.3 =
 * fixed notices for empty fields
 * works in debug mode
 
 == Screenshots ==

1. 3d slider slice box
2. horizontal orientation
3. vertical orientation
4. slider options