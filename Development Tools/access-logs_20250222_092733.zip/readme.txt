=== Access Logs ===
Tags: logs
Requires at least: 2.1
Tested up to: 2.3.3
Stable tag: 1.0
Donate link: http://www.satollo.com/english/donate
Contributors: none

Access Logs generate a access log file in Apache combined format rotated monthly.

== Description ==

Access Logs generate an access log file (rotated monthly) with access data in the
folder wp-content/logs. Those files can be processed with common logs analyzers, like
Webalizer.

More on: http://www.satollo.com/english/wordpress/access-logs

== Installation ==

Upload the plugin folder into your "wp-content/plugins"
Log in to Wordpress Administration area, choose "Plugins" from the main menu, find "Access Logs", 
and click the "Activate" button.

No option are available by now. 

To stop the logs, simple deactivate the plugin. The data collected will not be loosed.

== Frequently Asked Questions ==

No questions have been asked.

== Screenshots ==

No screenshots are available.