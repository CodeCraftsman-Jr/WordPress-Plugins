=== 1 Decembrie 1918 ===
Contributors: olarmarius
Donate link: http://olarmarius.tk/
Tags: ribbon, panglica, 1 decembrie, 1-decembrie-1918, 1 decembrie 1918, decembrie, december, december 1, december-1, olar, romania, national-day, ziua nationala a romaniei
Requires at least: 3.0.1
Tested up to: 3.4.2
Stable tag: 1.dec.2012
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

1 Decembrie 1918 - Ziua cea mare a tuturor romanilor!

== Description ==

Activati acest plugin si veti avea in partea dreapta, sus, o panglica tricolora care va va trimite catre pagina http://1decembrie.ro/. Daca doriti sa schimbati URL-ul atunci puteti face acest lucru in pagina de `Optiuni` a modulului.

Aveti de asemenea si optiuni precum:
* modificare link imagine;

* modificare title imagine;

* afisare/ascundere efect de neon;

* afisare/ascundere text;


== Installation ==

1. Extrageti si incarcati arhiva `1-decembrie-1918.zip` in directorul `/wp-content/plugins/`;
2. Activatati modulul prin meniul `Plugins` din WordPress.


== Screenshots ==

1. 1 Decembrie 1918 - Asa va arata panglica tricolora in site-ul dvs.

2. 1 Decembrie 1918 - Pagina de optiuni.


== Changelog ==

= 1.dec.2012 =
* Modificari in CSS, pentru afisarea corecta in coltul dreapta-sus.

= 1.dec.1918 =
* Versiune de start.


== Upgrade Notice ==

= 1.dec.2012 =
Modificari in CSS, pentru afisarea corecta in coltul dreapta-sus.

= 1.dec.1918 =
Versiune de start.

