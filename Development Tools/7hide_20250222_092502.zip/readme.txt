=== 7hide ===
Contributors: Neschkudla Patrick
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=1597957
Tags: hide, tags, tag, extension
Requires at least: 2.*
Tested up to: 2.7 RC1
Version: 2.1
Stable Tag: trunk

Adds a [hide]xxx[/hide] tag to your wordpress blog! Use it if you want to hide text until the user presses the button. You can edit the style via the 7hide Admin Section
== Description ==

Latest Version available @ www.7-layers.at

Adds a [hide]xxx[/hide] tag to your wordpress blog! Use it if you want to hide text until the user presses the button.
If you want another text on the button than the standard one make [hide title="your buttontext"]
You can easily set the styling of this via the 7hide admin section in wordpress, which is automatically added when activating the plugin


== Installation ==

1. Upload "7hide.php" to your Wordpress plugin directory
2. Activate the plugin `7hide` through the 'Plugins' menu in WordPress
3. Consider donation ;)

== Frequently Asked Questions ==

= Will the be an version with admin cp ? =
A: Yes, very soon.

= What shall I do if it won't work? =

Contact me - flipace@thn.at (MSN) || 412 133 173 (ICQ) || support@7-layers.at (MAIL) || http://www.7-layers.at

== Screenshots ==

1. The Standard Look of the hidden thing.
2. The Admin CP of 7hide