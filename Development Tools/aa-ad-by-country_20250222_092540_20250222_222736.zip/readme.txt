=== AA Ad by country ===
Contributors: aaextention
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ashik685%40gmail%2ecom&lc=US&item_name=Donate%20AA%20Extension%20%21&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags:aaextention, aaextension,extension,ad by country ,ip,ads
Requires at least:4.0
Tested up to:4.0
Stable tag:1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
It's unique plugin from AA Production House and it is created to show your ads according to your country.


==Description==
It's unique plugin from AA Production House and it is created to show your ads via shortcode like like [AD for="BD"]Your ads here[/AD]

<strong>Plugin Features</strong>

* Shortcode Enabled

More features are coming soon ..

<strong> How to use this plugin</strong>

Insert anywhere the <strong>[sitemap]</strong> shortcode

== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>AA Ad by country</strong>" activate it.<br />


	