=== 3rd Party Authentication ===
Contributors: jamesdlow
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=donate%40jameslow%2ecom&item_name=Donation%20to%20jameslow%2ecom&currency_code=USD&bn=PP%2dDonationsBF&charset=UTF%2d8
Tags: authentication, permissions, email, google, apps, gmail, 3rd, party
Requires at least: 2.7.0
Tested up to: 3.0.1
Stable tag: 0.2.3

3rd Party Authentication is a wordpress plugin that allows wordpress to authenticate against other authentication systems.

== Description ==

3rd Party Authentication is a wordpress plugin that allows wordpress to authenticate against other authentication systems. These include:
# Gmail / Google Apps
# Any generic POP/IMAP email service

== Installation ==

1. Download 3rd-party-authentication.php and place in wp-content/plugins
2. Log into your WordPress admin panel
3. Go to Plugins and "Activate" the plugin

== Frequently Asked Questions ==

1. Some of the code looks familiar

It is a heavily modified version of the HTTP Authentication plugin: http://dev.webadmin.ufl.edu/~dwc/2008/04/16/http-authentication-20/
with some help from WP Google Apps: http://serow.jp/labs/wpgoogleapps/

== Screenshots ==
