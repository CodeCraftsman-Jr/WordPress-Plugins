=== AB Human Time ===
Contributors: endrix.develop
Tags: display, posts, time
Donate link: http://www.abidubi.altervista.org/ab-human-time
Requires at least: 3.8.1
Tested up to: 3.8.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin shows the time elapsed since a post was published in a human readable format.

== Description ==
This plugin appends a text block at the bottom of single articles showing the time elapsed since a post was published in a human readable format using the wordpress function human_time_diff whit styling css included. Supports i18n and works well with theme providing genericons support.

== Installation ==
1. Upload ab-human-time directory to the "/wp-content/plugins/" directory.
1. Activate the plugin through the "Plugins" menu in WordPress.


== Frequently Asked Questions ==
= How can I contribute to language translations? =
email the author at endrix.develop@gmail.com.


== Screenshots ==
1. The screenshot description corresponds to screenshot-1.png

== Changelog ==
= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.1 =
Internationaliztion of output text.
