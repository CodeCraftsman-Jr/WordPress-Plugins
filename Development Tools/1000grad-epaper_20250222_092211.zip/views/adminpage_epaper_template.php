<div id="tg_menupage" class="tg_box">
    <div class="tg_header_box">
        <div class="tg_header_box_title">
            <h1>%TITLE%</h1>
        </div>
        <div class="tg_header_box_logo">
            <img align=right alt=1000grad-logo hspace=20 src='<?php echo plugin_dir_url(""). "1000grad-epaper/img/1000grad_logo.png" ?>'>    
        </div>
        <div class="clear"></div>
    </div>
    
    <div class="tg_content_box">
    %CONTENT%
    </div>    
    <div class="clear"></div>
</div>