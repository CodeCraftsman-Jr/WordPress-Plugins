<div id='message' class='updated epaper_info'>
    %MESSAGE%
</div>