<div class="tg_epaper_shortcode_box <?php echo $this->oView->class ?>">
    <?php echo $this->oView->link ?>
</div>