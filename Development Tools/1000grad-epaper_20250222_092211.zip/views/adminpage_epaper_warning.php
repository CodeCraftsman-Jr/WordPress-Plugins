<div id='message' class='error epaper_error'>
    %MESSAGE%
</div>