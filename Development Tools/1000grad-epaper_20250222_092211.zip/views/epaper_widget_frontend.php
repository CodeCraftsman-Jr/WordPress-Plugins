<?php echo $this->oView->before_widget ?>
<?php echo $this->oView->before_title ?>
<?php echo $this->oView->title ?>
<?php echo $this->oView->after_title ?>
<?php echo $this->oView->link ?>
<?php echo $this->oView->after_widget ?>