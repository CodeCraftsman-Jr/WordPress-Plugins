jQuery(document).ready(function(){
        $tgd(".ePaper").color1000box({iframe:true, width:"80%", height:"90%"});
});