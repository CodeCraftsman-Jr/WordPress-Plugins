tinyMCE.addI18n({en:{
tdPix:{	
desc : 'Insert a Phereo 3D Photo'
}}});
