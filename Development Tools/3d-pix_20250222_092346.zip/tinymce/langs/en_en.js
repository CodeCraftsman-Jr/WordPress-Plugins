tinyMCE.addI18n({en_US:{
tdPix:{	
desc : 'Insert a Phereo 3D Photo'
}}});