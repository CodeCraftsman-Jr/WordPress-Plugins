=== 0mk Shortener ===

Contributors: Kuzmanov
Tags: 0mk, 0.mk, short url, share, kratac, кратач, boris kuzmanov, shortener
Requirest at least: 3.0
Tested up to: 3.2.1
Stable tag: 0.1

== Description ==

0.mk Shortener генерира краток линк за Вашите написи користејќи го македонскиот кратач на линкови - Нула[точка]мк. 

== Installation ==

1. Прикачете го  "0mk-shortener" ви "/wp-content/plugins" директориумот;
2. Активирајте го додатокот.
3. Користете го менито „0.mk Поставувања“ за да поставите сопствено корисничко име и API клуч.
