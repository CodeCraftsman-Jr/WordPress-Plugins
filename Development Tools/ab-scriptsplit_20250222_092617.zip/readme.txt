=== A-B Script Split ===
Contributors: Randy Hunt
Tags: javascript, split testing, A-B test
Requires at least: 2.7
Tested up to: 3.0
Stable tag: 1.0

A-B Split Tester for Javascripts

== Description ==

This plugin was designed as a simple mechanism by which you can do A-B split testing of Javascript in the header of your site.


== Installation ==

1. If you are upgrading, it is recommended that you deactivate the plugin from the Plugins page, and delete the plugin folder from your server.
2. Upload the unzipped contents to your /wp-content/plugins/ directory.
3. Active the plugin from the Plugins page.
4. Go to settings page to configure AB-SplitScript


== Configuration == 

Simply add the two different versions of the script code in the settings page and click save!


== Planned features == 

* Configurable bias for non-50/50 splitting.
* Reset button for counts


== Changelog ==

= 1.0 =
* Initial version

