<doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width">
		<title>Page Not Found | <?php echo bloginfo('name') ?></title>
	</head>
	<body>
		<style type="text/css">
			body {
				margin: 0;
				padding: 0;
				background-color: #f0f0f0;
			}
			iframe
			{
				overflow: auto;
			}
		</style>

		<iframe src="http://404gotten.org/foundframe/?referer=133842" width="100%" height="900" frameborder="0" scrolling="no"></iframe>

		<!--
		ASCII ART NECESSARY SO THAT IT APPEARS IN IE.
		                (((       ,,
                ( *)======/\====
                 )(      /  \ 
      __________/  )    /    \
      \___EJM96    /   / ""   \ 
        \____    _/   / (**)   \
           / \__/    (----------)
          /____|__//_ (  it's   )
               |      (   a    )
               |       ( boy! )
               |        (____)
              _|__
               \
         -->

	</body>
</html>