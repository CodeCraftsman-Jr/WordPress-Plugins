=== Plugin Name ===
AA Dynamic Content Restriction Pro

Tags:aapaypal , aaextension ,Restriction ,Dynamic  , Pro
Requires at least:4.0
Tested up to:4.0
Stable tag:aapaypal
License: GPL
Author :A. Roy / A. Mahmud
==Description==
[protect]sample content[/protect]