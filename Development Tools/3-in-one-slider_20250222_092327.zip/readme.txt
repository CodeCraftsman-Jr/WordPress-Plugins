=== 3 in One Slider ===
Contributors: cyberkishor 
#Donate link: http://kishorkumarmahato.com.np/donate/
Tags: Slide, slide show, slider, multiple slider, more slider
Requires at least: 3.0.1
Tested up to: 3.8.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


A plugins that uses the slider with users choice, you can select your post type to slide with multiple options like cycle slider, marque slider and click slider.. There is more optoion to show the link on slider or not and number of slider too. 


== Description ==
3 in one Slider that uses the slider with users choice, you can select your post type to slide with multiple options like cycle slider, marque slider and click slider.. There is more optoion to show the link on slider or not and number of slider too. 
**.



== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-name` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress or extract file and place file in plugins directory 

3. Go to widget area and place the 3 in one slide show widget where you want to display your slider
4. Chose slider type like cycle, marque or click


5. Chose post type which you want to slide 



== Screenshots ==
1. Settings Screen

== Upgrade Notice ==
* initial
== Changelog ==

= 1.0 =
* First version of 3 in one Slider
