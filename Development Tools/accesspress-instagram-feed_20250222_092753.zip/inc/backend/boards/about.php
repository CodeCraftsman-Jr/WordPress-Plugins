<div class="apsc-boards-tabs" id="apsc-board-about-settings" style="display: none;">
	<div class="apsc-tab-wrapper">
		<p><strong>AccessPress Instagram Feed </strong> - is a FREE WordPress Plugin by AccessPress Themes. </p>

		<p>AccessPress Themes is a venture of Access Keys - who has developed hundreds of Custom WordPress themes and plugins for its clients over the years. </p>

		<p><strong>AccessPress Instagram Feed</strong> is a <strong>Free WordPress plugin</strong> to display your instagram post image in mosaic view.
A perfect plugin to show your instagram feed and encourage more to join your network.

You can enter details of your instagram and select one of the designs from beautifully designed 3 design layouts. 

All you have to do is either use a widget or shortcode to display your instagram feed right on your website in your chosen location.
</p>
<div class="halfseperator"></div>
			
		<h3>Other products by AccessPress themes </h3>
		<div class="product">
		<div class="logo-product"><img src="<?php echo APIF_IMAGE_DIR;?>/aplite.png" alt="<?php esc_attr_e('AccessPress Social Counter','if-feed'); ?>" /></div>
		<div class="productext"><p><strong>AccessPress Lite</strong> - A very popular Free WordPress theme, available in WordPress.org<br />
			<a href="http://accesspressthemes.com/wordpress-themes/accesspress-lite/" target="_blank">http://accesspressthemes.com/wordpress-themes/accesspress-lite/</a></p>
		</div>
		</div>

		<div class="product">
		<div class="logo-product"><img src="<?php echo APIF_IMAGE_DIR;?>/appro.png" alt="<?php esc_attr_e('AccessPress Social Counter','if-feed'); ?>" /></div>
		<div class="productext"><p><strong>AccessPress Pro</strong> - Premium version of AccessPress lite<br />
			<a href="http://accesspressthemes.com/wordpress-themes/accesspress-lite/" target="_blank">http://accesspressthemes.com/wordpress-themes/accesspress-pro/</a></p>
		</div>
		</div>

		<div class="seperator"></div><div class="dottedline"></div><div class="seperator"></div>

		<h3>Get in touch</h3>
		<p>If you’ve any question/feedback, please get in touch: <br />
			<strong>General enquiries:</strong> <a href="mailto:info@accesspressthemes.com">info@accesspressthemes.com</a><br />
			<strong>Support:</strong> <a href="mailto:support@accesspressthemes.com">support@accesspressthemes.com</a><br />
			<strong>Sales:</strong> <a href="mailto:sales@accesspressthemes.com">sales@accesspressthemes.com</a>
		</p>
		<div class="seperator"></div><div class="dottedline"></div><div class="seperator"></div>
		
		</div>
	</div>