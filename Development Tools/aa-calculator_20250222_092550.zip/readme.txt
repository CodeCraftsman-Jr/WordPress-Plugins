=== AA Cash Calculator ===
Contributors: aaextention
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ashik685%40gmail%2ecom&lc=US&item_name=Donate%20AA%20Extension%20%21&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: aaextension, conditon, cash calculator, calculation
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

	It is a Custom Cash Calculator Made By AA Extension.

== Description ==


It is a Custom Cash Calculator Made By AA Extension . You can use your shortcode like it [view_calculator page_id="your_page_id"]. Very simple to use. If you need to know anything then contact to us via email (contact2us.aa@gmail.com) . We are very happy to help you.


### AA Cash Calculator Plugin by http://webdesigncr3ator.com

<br />


<strong>Plugin Features</strong><br />

* Coming soon

<strong>From this plugin you will get :</strong><br />

* Invoice Total
* Maximum Fee 
* Invoice discount amount
* Your advanced upfront
* Paid to you on settlement
* YOUR RECEIVED MONEY

<strong>Conditions:</strong><br />

Here we use a custom rules . We can upgrade this plugin rules for you with a little cost so you can contact with us anytime.






== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>AA Cash Calculator Plugin</strong>" activate it.<br />

<br />

and shortcode for you </strong> `[view_calculator page_id="your_page_id"] 
`<br />

then paste this shortcode anywhere in your page to display this cash calculator.



== Screenshots ==

1. screenshot-1
1. screenshot-2

== Changelog ==

	
	= 1.0 =
    * 2/11/2014 Initial release.