=== Plugin Name ===
Contributors: mebius0
Donate link:
Tags: dashboard,profile
Requires at least: 3.8
Tested up to: 3.8
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

It is a plug-in for 「17 sai kyou」


== Description ==
Show to the dashboard of your age. (To 17saikyou Style)

== Installation ==
1. Upload `17sai-kyou` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Set the date of birth in the profile editing page.

== Changelog ==

= 1.0 =
Plugin Release

== Arbitrary section ==
「17歳教」のためのプラグインです。プロフィールページで生年月日を設定することで、「17歳と◯◯日」というのをダッシュボードに表示します。