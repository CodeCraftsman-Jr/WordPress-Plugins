=== 7 football ligue ===
Contributors: FutNik.ru
Donate link: 
Tags: football, soccer, tables
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Displays several football tables in the widget

== Description ==

The widget can be placed 7 tables leagues: English, Russian Premier League, First Division, German, Spanish, Italian and Ukrainian.

== Installation ==

1. Upload `footleagues.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. layout 1
2. layout 2

== Changelog ==

1.1.2 - Added the FNL
1.1.1 - Added 1 league
1.1 - added 2 League
1.0 - to create a plugin

== Upgrade notice ==



== Arbitrary section 1 ==

