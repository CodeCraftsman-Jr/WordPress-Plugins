=== 3dady real-time web stats ===
Contributors: 3dady
Tags: stats, real-time, web, Hit Counter, Counter, private,  widget, sidebar, visitors, statistics, stats, views, widgets, analytics, plugin
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: 1.0
License: OpenSource under GPL2

Hit Counter Sidebar widget/real-time web stats 


== Description ==
know the number of visitors of your own website in real-time, 3dady is a perfect free counter and web stats which indicates the exact number of visitors of your website easily with amazing statistics.

For more information, check out [3dady.com](http://www.3dady.com/).

= Live Demos =

* [DEMO 1](http://www.3dady.com/statistic/demo)
* [DEMO 2](http://www.3dady.com/demo1.php)
* [DEMO 3](http://www.3dady.com/demo2.php)

= How to Use this? =

1. Simply goto the admin panel
2. Straight down to "Settings" Menu
3. Get the key and Position in the browser from 3dady Stats http://www.3dady.com/getcounter You must choose Sidebar Widget
4. after finishing successfully,Counter code will be ready to use and you have to Click on "Add To WordPress"
5. Copy the key and position in the browser then put them in the fields at the top and Save
6. Check the box to enable Sidebar widget.

= Notes* =
 
 1. this Plugin only works with Sidebar widget
 2. Get the key and Position in the browser from [3dady Stats](http://www.3dady.com/)

== Installation ==

1. Download the zip file and extract the contents.
2. Upload the folder 3dady-real-time-web-stats to the /wp-content/plugins/ directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Go to the 3dady Stats menu,  Get the key and Position in the browser from 3dady Stats http://www.3dady.com/getcounter
5. Check the box to enable Sidebar widget.

or

1. Go to your WordPress dashboard and click on 'Plugins' then the 'Add New' menu item.
2. On the install plugin screen search for the 3dady plugin and then click on the 'search plugins' button to initiate the search
3. The search results are then shown "3dady real-time web stats" Clicking on 'install now' will automatically Activate Plugin
4. Go to the 3dady Stats menu,  Get the key and Position in the browser from 3dady Stats
5. Check the box to enable Sidebar widget.

== Frequently Asked Questions ==

= Where can I signup for 3dady stats? =
Get your free account at http://www.3dady.com

= Can I get a key without registration? =
YES, but less features

= Can I use a Other widget? =
No, this Plugin only works with Sidebar widget.

= How to create a private Hit Counter Sidebar widget? =
1. Signup 3dady Stats to use extended features, and private widget http://www.3dady.com/signup
2. Sign In and Create a new project
3. Fill out the form and add your website URL in field "URL of your project"
4. choose Statistics >> access Access only for me
5. choose Position in the browser >> private bottom and submit form
6. Enjoy

== Screenshots ==
1. Administration interface
2. Stats chart.
3. sidebar widget.

== Upgrade Notice ==

= 1.0 =
Version 1.0 needs Wordpress 3.0 and up to work.

== Changelog ==

= 1.0 =
* Initial release on WordPress.org
