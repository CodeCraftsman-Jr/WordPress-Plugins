=== Plugin Name ===
Contributors: daanzk
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=TL4JJ3KHQCC6A&lc=NL&currency_code=EUR
Tags: 112, p2000, c2000, brandweer, ambulance, politie, knrm, kmar, alarmering, uituk, hulpdiensten, alarmeringen
Requires at least: 3.0.1
Tested up to: 3.8.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Deze plugin laat specifieke 112 meldingen zien in een widget. Meldingen o.a. Brandweer, politie, ambulance, KNRM etc. 

== Description ==

Deze plugin laat specifieke 112 meldingen zien in een widget. Meldingen o.a. Brandweer, politie, ambulance, KNRM etc. Met behulp van de juiste capcode (<a href="http://www.hulpverleningsforum.nl/index.php?topic=51987.0" target="_blank">zie het Hulpverleningsforum voor een lijst</a>) worden meldingen aan de betreffende dienst weergegeven in een widget.

De meldingen worden door mijn server met een scanner ontvangen en ontsloten naar de plugin.

== Screenshots ==

1. De instellingen.
2. De weergave.

== Changelog ==

= 1.0 =
* Initial release.