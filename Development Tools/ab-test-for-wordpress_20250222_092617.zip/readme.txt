=== A/B Test for WordPress ===
Contributors: lassebunk
Stable tag: 1.0.3

A/B split testing for WordPress made easy.

== Description ==

Project has moved to [A/B Test for WordPress](http://wordpress.org/extend/plugins/abtest/).