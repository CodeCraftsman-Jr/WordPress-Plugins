jQuery(function() {
	jQuery(' #da-thumbs > li ').each( function() { jQuery(this).hoverdir(); } );
});