=== 1r.hu Rövidítő ===
Contributors: webdewhu
Donate link: http://webdew.hu/
Tags: 1r, 1r.hu, hivatkozás, rövidítő
Requires at least: 2.0.2
Tested up to: 3.1
Stable tag: trunk


1r.hu Widget for your Wordpress blog.

== Description ==

http://1r.hu - Egy rövidítő.

With the help of the plugin you can help anyone create a short link using the services of 1r.hu. The plugin creates a widget, which can be placed in 
any sidebar. 

Someone enters a long URL in to the input box, hits enter, and the short link will appear. This can be copied and pasted anywhere.

*IMPORTANT: 

1. You need to have CURL installed on your hosting for this to work.
2. Currently only Hungarian language is supported. We'll have more languages soon.

== Installation ==

1. Lookup "1r.hu Widget" under Plugins - Add New.
2. Install and Activate.
3. Place it wherever you wish.
4. Visit your page.
5. Drink a beer.

== Requierments ==

You need to have CURL installed. Talk to your hosting company if they provide such a feature.

== Changelog ==

= 0.2 =
Updated javascript error.
