﻿=== About The Autor ===
Contributors: ppfeufer
Donate link: http://flattr.com/thing/601539/WordPress-Plugin-About-The-Author
Tags: blog, author, sidebar, widget
Requires at least: 3.2
Tested up to: 3.8-alpha
Stable tag: 1.2

Provides a sidebarwidget with some information about the author of a blogarticle.

== Description ==

Provides a sidebarwidget with some information about the author of a blogarticle. Add a new field to your profile-page where you can upload a photo which will be used for the widget.

**Features**

* simple installation.
* new field in "your profile" for your own photo.

**Translations**

* English
* German

== Installation ==

**Installation via Wordpress**

1. Menu 'Plugins' -> 'Install' and search for 'About The Author'
1. click 'install'

**Manuelle Installation**

1. download and unzip the plugin.
1. upload the directory `about-the-author` to your `/wp-content/plugins/`-directory.
1. activate the plugin.

== Screenshots ==

1. The sidebarwidget.
2. The widgetsettings.
3. The new field in "your profile".

== Changelog ==
= 1.2 =
* (02. 11. 2013)
* Tested up to WordPress 3.8-alpha

= 1.1 =
* (02. 01. 2013)
* Ready for WordPress 3.5

= 1.0.1 =
* (10. 05. 2012)
* Fixed a little bug when neither a userphoto nor a userdescription is entered.

= 1.0 =
* (28. 03. 2012)
* Finally I think were out of beta-state and can release a 1.x Version :-)

= 0.4 =
* (09. 03. 2012)
* Fixed a bug where the own author image was overwritten when editing another authors profile. Thanks to <a href="http://privat48.de/">Roland</a> for reporting.

= 0.3 =
* (27. 01. 2012)
* fixed update user profile

= 0.2 =
* (27. 01. 2012)
* Changed the name of the userphoto thumbnail
* Changed also the size

= 0.1 =
* (27. 01. 2012)
* Initial Release

== Frequently Asked Questions ==

If you have any questios, feel free to lkeave a comment [http://blog.ppfeufer.de/wordpress-plugin-about-the-author/](http://blog.ppfeufer.de/wordpress-plugin-about-the-author/).

== Upgrade Notice ==
