<?php
/*	Legacy placeholder */
?>