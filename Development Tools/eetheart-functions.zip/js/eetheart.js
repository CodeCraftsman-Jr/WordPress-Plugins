/* Eetheart Functions Plugin */


jQuery(document).ready(function(){

	/* Your function here */
});