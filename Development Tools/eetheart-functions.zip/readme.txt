=== Eetheart Functions ===
Contributors: Eetheart
Tags: js, developer
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: "trunk"
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin for developers.

== Description ==

Use this plugin for developing and/or editing your theme. You can access the .js file to add your custom JavaScript.

== Installation ==

1. Upload `eetheart-functions` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit the plugin as desired in the editor.
4. That's it! Don't forget to test if it works.

== Frequently Asked Questions ==

Will there ever be an interface?
 - No.

Are you planning on updating this plugin?
 - Unless there is a major bug or security-breach found, no, as it is compatible with all previous and all upcoming Wordpress versions.

== Screenshots ==

1. screenshot-1.png

== Changelog ==

= 1.0 =
* Launch

`<?php code(); // goes in backticks ?>`