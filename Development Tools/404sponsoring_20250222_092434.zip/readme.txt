=== 404sponsoring ===
Contributors: jeroensmeets
Tags: plugin, 404
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 1.3.2

Support your favorite charity!

== Description ==

= Nederlands =

Fijn dat je overweegt de 404SPONSORING plugin te installeren. Hiermee kan je een goed doel sponsoren met je 404 pagina. Voorlopig zijn dat de Nierstichting, de Bart de Graaff Foundation, Ik Kom In Actie, Books 4 Life en Villa Ticca.

= English =

Glad you're considering installing the 404SPONSORING plugin. This allows you to sponsor a charity with your 404 page. At this moment, the charity organisations that are available are the Dutch Kidney Foundation (Nierstichting), the Bart de Graaff Foundation, Ik Kom In Actie, Books 4 Life and Villa Ticca.


== Installation ==

= Nederlands =

"Na activering van deze plugin vind je onder `Instellingen` >> `404 sponsoring` de mogelijkheid een goed doel te kiezen. Sla deze keuze op en de plugin doet al het zware werk."

= English =

There's little to configure for this plugin. After installation, you will find a Settings page under `Settings` >> `404 sponsoring`. Select a charity from the list, click submit and that's it!"


== Changelog ==

= 1.3.2 =

bug fixed in version 1.3.1 wasn't fixed, now it is.

= 1.3.1 =

updated this changelog for this and the previous version ;-)
fixed a bug where an error was shown after activation of the plugin
plugin tested up to WordPress 3.2.1

= 1.3 =

made the screenshots in the settings screen smaller in size
added two new 404 screens
fixed some small bugs

= 1.2 =

screenshot.png preview of 404 page is now complete screen
coupl'a small php warnings fixed

= 1.1 =  

new settings screen in admin
added link to settings under plugin name in wp-admin "Plugins" screen
added two charities

= 1.0 =  

initial version