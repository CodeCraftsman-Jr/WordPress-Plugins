<?php

class EPaper_config
{

    public static $db_table_name = "epaper";

    public static $ep_standard_width = 80;

    public static $ep_standard_height = 200;

    public static $ep_standard_link_text = "Starte ePaper ";

}