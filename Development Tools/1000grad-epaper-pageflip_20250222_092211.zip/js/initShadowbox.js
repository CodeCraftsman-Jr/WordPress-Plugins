// initialite Shadowbox
Shadowbox.init({
    language: 'de-DE',
    players: ['html', 'iframe']
});

