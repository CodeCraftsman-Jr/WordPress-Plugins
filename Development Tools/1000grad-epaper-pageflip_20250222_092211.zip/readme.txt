=== Plugin Name ===
Contributors: 1000grad
Tags: 
Requires at least: 3.0.0
Tested up to: 3.4
Stable tag: trunk

This Plugin is deprecated! Please install our new one: edelpaper!

== Description ==

This Plugin is deprecated! Please install our new one: edelpaper!

Dieses Plugin ist veraltet! Bitte installieren sie unser neues: edelpaper!

For more information please visit <a href="http://wordpress.org/extend/plugins/1000grad-epaper/">edelpaper Plugin</a> or <a href="http://support.edelpaper.com/hc/en-us/articles/202133892">www.edelpaper.com</a>.

== Installation ==

This Plugin is deprecated! Please install our new one: edelpaper!

Dieses Plugin ist veraltet! Bitte installieren sie unser neues: edelpaper!

For more information please visit <a href="http://wordpress.org/extend/plugins/1000grad-epaper/">edelpaper Plugin</a> or <a href="http://support.edelpaper.com/hc/en-us/articles/202133892">www.edelpaper.com</a>.

== Frequently Asked Questions ==

= How do I get started? =

This Plugin is deprecated! Please install our new one: edelpaper!

Dieses Plugin ist veraltet! Bitte installieren sie unser neues: edelpaper!

for more information please visit <a href="http://wordpress.org/extend/plugins/1000grad-epaper/">edelpaper Plugin</a> or <a href="http://support.edelpaper.com/hc/en-us/articles/202133892">www.edelpaper.com</a>.


== Screenshots ==

This Plugin is deprecated! Please install our new one: edelpaper!

Dieses Plugin ist veraltet! Bitte installieren sie unser neues: edelpaper!

for more information please visit <a href="http://wordpress.org/extend/plugins/1000grad-epaper/">edelpaper Plugin</a> or <a href="http://support.edelpaper.com/hc/en-us/articles/202133892">www.edelpaper.com</a>.

== Changelog ==

This Plugin is deprecated! Please install our new one: edelpaper!

Dieses Plugin ist veraltet! Bitte installieren sie unser neues: edelpaper!

for more information please visit <a href="http://wordpress.org/extend/plugins/1000grad-epaper/">edelpaper Plugin</a> or <a href="http://support.edelpaper.com/hc/en-us/articles/202133892">www.edelpaper.com</a>.


== License ==

This Plugin is deprecated! Please install our new one: edelpaper!

Dieses Plugin ist veraltet! Bitte installieren sie unser neues: edelpaper!

for more information please visit <a href="http://wordpress.org/extend/plugins/1000grad-epaper/">edelpaper Plugin</a> or <a href="http://support.edelpaper.com/hc/en-us/articles/202133892">www.edelpaper.com</a>.