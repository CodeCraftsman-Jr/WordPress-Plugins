tinyMCE.addI18n('en.accessibility-abbreviation',{
button:"Abbreviation",
remove:"Remove",
label_lang:"HTML Language",
label_xmllang:"XHTML Language",
label_title:"Title",
title:"Add Abbreviation"
});