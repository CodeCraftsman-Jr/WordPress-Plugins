﻿=== Plugin Name ===
Plugin Name: 99dl DoanloandMangager
Plugin URI: http://www.iesay.com/99dl-Lightbox-doanloandmanager
Description: wordpress popup dowload.
Author: 99839
Author URI: http://www.iesay.com/
Version: 1.0
Contributors:99839
Donate link: https://me.alipay.com/jeray
Tags: facebox, download, jquery
Requires at least: 2.7
Tested up to: 3.2
Stable tag:facebox, download, jquery



== Description ==

This plugin make shortcodes to use in your post or pages. Use it to open downland link or imges using the lightbox effect.

== Installation ==


1.Upload `99-DoanloandMangager.zip` to the `/wp-content/plugins/` directory
2.Activate the plugin through the 'Plugins' menu in WordPress
3.enjoy it.

how to use

<code>[idl id="code" t="text"] links [/idl]</code>.


== How to use ==

Development by <a href="http://www.iesay.com">99dl DoanloandMangager</a> and based on http://famspam.com/facebox

== Screenshots ==

`/screenshot-1.jpg`

== Frequently Asked Questions ==

This plugin don't have admin setting!if you want to modify the content.open the"99-DoanloandMangager" and edit it!

== Changelog ==

none

== Upgrade Notice ==

none