﻿<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-2380187281506044";
/* 468x60, 创建于 11-7-18 */
google_ad_slot = "6835146458";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>