=== Plugin Name ===
Contributors: lioman
Donate link: http://flattr.com/thing/1093328/2012-Summary

Tags: word count, summary, 2012, stats, statistics
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 0.1.1


== Description ==
I've adapted this Plugin from "[2010 Summary](http://wordpress.org/extend/plugins/2010-summary/) by Tomasz Topa"

This plugin generates a brief summary of your blog for year 2012.

See how many posts you wrote during the ending year, which were the most popular, who was the most active commenter etc.

And then share the stats with your readers - copy the data to a new draft with a single click.
More on [www.lioman.de](http://www.lioman.de/plugins-scripte/2012-summary "WordPress-Plugin: 2012 Summary")

== Installation ==

= Within Wordpress: =
1. Login to your weblog
1. Go to Plugins
1. Select Add New
1. Search for "2012 Summary"
1. Select Install
1. Select Install Now
1. Select Activate Plugin

= Manual: =
1. Upload `Files` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Changelog ==
= 0.1.1 =
* Change of plugin url to wordpress directory
= 0.1 =
* Initial Release

== Screenshots ==

1. Summary for 2012
