=== 3D Facebook Button ===
Contributors: jolamar
Donate link: http://liljosh.com
Tags: CSS3, Facebook, button, like, likes, like button, post, posts, buttons, link, hyperlink
Requires at least: 2.5.0
Tested up to: 3.9
Stable Tag: 1.1

The Wordpress Plugin 3D FACEBOOK BUTTON is a simple and easy to configure plugin to create a button that shows how many likes your URL has. 
== Description ==

The Wordpress Plugin *3D FACEBOOK BUTTON* is a simple and easy to configure Wordpress plugin which allows you to create CSS3 based Facebook Buttons inside your blog posts.Hovering your mouse over the logo will cause it to fall open in 3D, revealing how many likes your site has.

**usage** = [FACEBOOKBUTTON]http://liljosh.com[/FACEBOOKBUTTON]

== Installation ==

This section describes how to install the plugin and get it working

1. Upload the plugin folder folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What's the shortcode =

[FACEBOOKBUTTON]http://liljosh.com[/FACEBOOKBUTTON]

== Screenshots ==

1. This is how the button reacts when you hover over it, revealing the amount of likes your URL has.

== Changelog ==

= 1.0 =
* Initial release. Future plans will allow you to click the button to like the site
