=== Plugin Name ===
Contributors: Samrat Khan
Tags: bangla date, banglay dekhao date, date to bangla
Requires at least: 3.4.1
Tested up to: 3.4.1
Stable tag: 1.4

Active the plugin, it will work itself.

== Description ==

A Bangla Plugin which will conert the wordpress theme to Bangla.

What will happen if you installed and active this plugin-

"Posted on October 17, 2012" to "Posted on অক্টোবর ১৭, ২০১২"
"Mr WordPress on October 17, 2012 at 2:49 PM Said:" to "Mr WordPress on অক্টোবর ১৭, ২০১২ at ২:৪৯ দুপুর said:"

= Banglay Dekhao Date's Homepage =

[Visit this plugin's homepage](http://www.facebook.com/saamraatkhaan)

== Installation ==

1. Upload the **bn-plugin** folder to your **/wp-content/plugins/** directory or go to Plugins
2. Activate the plugin through the Plugins menu in WordPress

= Configure BDD =
* Later *


== Frequently Asked Questions ==
* Later *
== Screenshots ==

* Later *

== Changelog ==

* Later *

== Upgrade Notice ==
* Later *