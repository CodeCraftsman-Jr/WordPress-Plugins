=== ab-in-den-urlaub.de Content 4 Partners ===
Contributors: ab-in-den-urlaub
Donate link: http://content-partner.ab-in-den-urlaub.de
Tags: hotels, seo, affiliate, reviews, Booking, "hotel search", hostels, Reservation, rooms, "Ab in den Urlaub", ab-in-den-urlaub
Requires at least: 2.8
Tested up to: 3.3.1
License: GPLv2
Stable tag: 1.7

Ab-in-den-urlaub.de stellt Ihnen optimierte Seiten zu Ihrer Destination mit Hotelbewertungen und -angeboten bereit.

== Description ==

Ab-in-den-urlaub.de stellt ihnen einen Satz Seiten zur Verfuegung. Diese Seiten sind suchmaschinenoptimiert und 
enthalten einen uniquen Satz von Hotelbewertungen und -angeboten.

Zur Nutzung des Plugins benoetigen Sie einen Account bei content-partner.ab-in-den-urlaub.de. Sie koennen sich 
in der Einstellungsseite des Plugins registrieren. Für die Teilnahme am Affiliate-Programm benötigen Sie
einen Zanox-Account.
Hinweis: Merken Sie sich bitte Login und Passwort vom Registrieren. Passwoerter werden bei ab-in-den-urlaub.de
nur verschluesselt abgelegt, es ist nicht reproduzierbar. Fuer den Fall, dass Sie Ihr Passwort vergessen haben,
koennen Sie sich auf http://content-partner.ab-in-den-urlaub.de ein neues Passwort zuschicken lassen.

== Installation ==

1. Laden Sie die .zip-Datei auf der Seite Plugins -> Installieren -> Hochladen hoch.
2. Aktivieren Sie das Plugin.
3. Im Menue unter "Plugins" erscheint die Einstellungsseite fuer "Content 4 Partners".
4. Klicken Sie dort auf "Registrierung", um sich bei ab-in-den-urlaub.de anzumelden. 
   Merken Sie sich bitte Ihr Login und Passwort.
5. Sie bekommen von ab-in-de-urlaub.de eine E-Mail mit Ihren Daten. 
6. Tragen Sie diese in die entsprechenden Felder auf der Einstellungsseite ein.
7. Wenn Sie am Affiliate-Programm teilnehmen wollen, tragen Sie bitte 
   auf http://content-partner.ab-in-den-urlaub.de/seiten Ihre Zanox-PID ein.
8. Auf http://content-partner.ab-in-den-urlaub.de/seiten können Sie für jede der Seiten einen eigenen Text 
   hinterlegen, der dann in Ihrem Blog mit angezeigt wird. Außerdem können Sie hier auswählen, ob für Ihre
   Region Permalinks verwendet werden sollen. 

== Registrierung ==

In den Plugin-Einstellungen finden Sie einen Button "Registrierung". Tragen Sie auf dieser Seite Ihre Daten 
ein. Wir werden Ihre Registrierung pruefen und Sie erhalten von uns eine E-Mail mit Ihren Zugangsdaten.
Tragen Sie diese Daten auf der Einstellungsseite des Plugins ein. 
Jetzt sollte die Seite in Ihrem Blog erscheinen.

== Upgrade Notice ==
= 1.7 =
Seitentitel beachtet Einstellungen des Themes
  ..:: Danke an Felix Kern von www.studium-ausland.eu/ ::..

= 1.6 =
Bugfix: Cacheeinstellung

= 1.5 =
Bugfix: Kompatibilität mit WP 2.8 wieder hergestellt

= 1.4 =
Bugfix: Probleme mit Zeilenumbrüchen behoben
Test mit Wordpress 3.2.1
Test mit Wordpress 3.2
Test mit Wordpress 3.1.3

= 1.3 =
Permalinks für die Content-4-Partners-Seiten können verwendet werden. Dazu ist eine zusätzliche Einstellung 
für die Region notwendig.
Bugs bei fehlgeschlagenem Login und beim Zusammenspiel mit anderen Plugins wurden behoben. 
Getestet mit Wordpress 3.1.1.

= 1.2 =
wpSeo-Unterstützung: mit wpSeo lässt sich das Verhalten des Content-4-Partners-Plugins steuern.
Weitere Informationen finden Sie auf http://content-partner.ab-in-den-urlaub.de/download/wpSeo.pdf .

= 1.1 =
Mit diesem Update wird die Zusammenarbeit mit anderen SEO-Plugins verbessert. Spezielle Features für wpSeo
kommen im nächsten Upgrade.

= 1.0 =
Nehmen Sie am Affiliate-programm von Ab-in-den-Urlaub.de teil.

== Changelog ==
= 1.5 = 
* WP 3 - spezifische Funktionen entfernt

= 1.4 =
* Test WP 3.2 und 3.2.1
* Bugfix bei Zeilenumbrüchen

= 1.3 =
* Unterstützung für Permalinks
* Test mit WP 3.1.1

= 1.2 =
* Unterstützung für wpSeo

= 1.1 =
* getestet mit Wordpress 3.0.4
* Seitentitel kommt trotz Funktionen anderer Plugins

= 1.0 = 
* Sicherheitsanpassungen
* initial