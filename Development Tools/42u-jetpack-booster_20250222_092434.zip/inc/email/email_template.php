<body>
    <div id="email_container">
        <div style="width:550px; padding:0 20px 20px 20px; background:#fff; margin:0 auto; border:3px #000 solid;
            moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; color:#454545;line-height:1.5em; " id="email_content">
            
            <h1 style="padding:5px 0 0 0; font-family:georgia;font-weight:500;font-size:24px;color:#000;">
                !!!EMAIL_SUBJECT!!!
            </h1>
            
            !!!EMAIL_BODY!!!
                    
            <div style="text-align:center; border-top:1px solid #eee;padding:5px 0 0 0;" id="email_footer"> 
                <small style="font-size:11px; color:#999; line-height:14px;">
                    !!!EMAIL_FOOTER_LINKS!!!
                </small>
            </div>
            
        </div>
    </div>
</body>