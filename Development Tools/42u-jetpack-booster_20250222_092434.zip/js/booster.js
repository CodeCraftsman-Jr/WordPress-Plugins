jQuery(document).ready( function() {

    jQuery(".contact-form input[id$='redirect']").parent().hide();

});