jQuery( document ).ready( function( $ ) {
	$('.toolbar-color-field').wpColorPicker();
	$('.notice-color-field').wpColorPicker();
	$('.toolbar-text-color-field').wpColorPicker();
	$('.notice-text-color-field').wpColorPicker();
});