DX-localhost
============

Display a notice when working on a localhost site clone.

Activate the plugin and see a yellow notice bar that you're working on localhost.

Super helpful whenever you're cloning a production website with virtual hosts using the same domain name, and are not sure which site are you editing.

![](https://github.com/mpeshev/DX-localhost/blob/master/screenshot-1.png)
