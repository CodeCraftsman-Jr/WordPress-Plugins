=== eShortcodes ===
Contributors: Rich Pedley
Donate link: http://quirm.net/download/
Tags: short, code, shortcode, gallery, caption, eshortcode
Requires at least: 2.9
Tested up to: 3.0
Stable tag: 1.4

A framework to ease the end users experience with shortcodes. 2 are included by default - gallery and caption.

== Description ==

eShortcodes is a framework to ease the end users experience with shortcodes. 
An extra meta box is added to the post/page edit screens with available shortcodes, and a form with the possible attributes.
Hooks have been added for plugin developers to use. 
2 examples have been included, gallery and content.

== Screenshots ==

Not currently available.

== Changelog == 

= Version 1.3 =

*fixed* should now work !

= Version 1.0 =

Initial Release

== Installation ==

Download the plugin, upload to your Wordpress plugins directory and activate. An extra meta box will appear on the page/post edit screen enabling users to choose a shortcode, and enter any necessary atributes.

== Frequently Asked Questions ==

= Translatable? =

Yes the po file is included.

= Support =

Available via the WordPress forums (please tag the post eshortcodes) 

== Upgrade Notice ==

= 1.0 =
Initial release