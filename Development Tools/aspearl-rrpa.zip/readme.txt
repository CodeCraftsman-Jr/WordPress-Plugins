=== aspearl_rrpa ===

Contributors: aspearlsoft
Donate link: 
Tags: Recent Posts, Recent Comments on post , Popular post, All kind of post in tab, combind view of post by status
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

 Aspearl rrpa widget to show Recent Posts, Recent Comments on post , Popular post by view and Acrhives post month wise. It can be said all in one widget which willl show different data in tabing format. It saves space on your website as well as provide most useful feature in block.

You can cofigure design according to your theme it is being placed in plugin-dir/aspearl-rrpa/css/aspearl-rrpa.css

== Screenshots ==

screenshot-1.png

==  Features ==
 
1. You can configure required tab in widget setting.
2. You can specify no. of records to show.
3. Very simple to configure.


== Installation ==

1. Upload apearl-rrpa.zip to the /wp-content/plugins/ directory
2. Unzip apearl-rrpa.zip
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Visit Appearance -> Widget you will Aspearl RRPA Widget in Available widget list
5. Drag and drop to desired side bar or widget area
6. Configure basic setting

== Frequently Asked Questions ==

My widget is messed up ?
It may be due to some comflict in your design and tabing css. So go to plugin-dir/aspearl-rrpa/css/aspearl-rrpa.css and make changes according to your theme

== Changelog ==
= 1.0 =
* First version, here goes nothing!

== Upgrade Notice ==
= 1.0 =
None as of yet.

