=== 7uploads ===
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=1597957
Author: Neschkudla Patrick
Contributors: Neschkudla Patrick,Prueger Larissa, Mario Heindl
Tags: uploads, entries, linksave.in, crypt, links, save
Requires at least: 2.*
Tested up to: 2.7
Version: 2.0
Stable tag: trunk

The ultimate Upload entry plugin for Wordpress based websites!

== Description ==

visit www.7-layers.at

The 7uploads Wordpress Plugin adds an Upload Entry functionality for your users to your Wordpress blog!
After you activated this plugin a new page called "Upload Eintragen" will be created with some Standard Fields where your users can enter
things like the title of their upload, the language and so on.

The Plugin automatically encrypts the links given by the user with either linksave.in or linkcrypt.ws.

YOU! can choose if they are able to decide which one to use or not ;) You can define if they can enter their exchange id or not...
YOU! can decide that only .dlc and .ccf or only .rsdf containers should be created with the linksave.in encryption.
YOU! can style the final look of the posts created by the user!
YOU! can define your own fields (why not add a field for the meaning of the user?!)
YOU! can choose wheter the posts should be published immediately, be saved as drafts or pending for review!

All these things you can configure with the brand new 7uploads Administration Panel within Wordpress!
There is no need to edit the php file anymore!

== Installation ==

1. Upload the folder `7uploads` and `exec-php` to the `/wp-content/plugins/` directory
2. Activate the plugin `7uploads` and `exec-php` through the 'Plugins' menu in WordPress
3. Freak around with the `7uploads` CP!

== Frequently Asked Questions ==

= What if I deleted the preset post? =

Don't worry, since version 1.3 it'll be generated automatically again =)

= I get an error like "call to undefined function curl_init()" =

Go and get yourself Webspace with curl^^ Only version 1.5.1 has a non curl function implemented

= What shall I do if it just won't work? =

Contact me - flipace@thn.at (MSN) || 412 133 173 (ICQ) || support@7-layers.at (MAIL) || http://www.7-layers.at

== Screenshots ==

1. General Config
2. Preset Config
3. Define Custom Fields
4. Standard Look
