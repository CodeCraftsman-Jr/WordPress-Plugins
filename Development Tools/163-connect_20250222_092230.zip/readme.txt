﻿=== 网易连接 ===
Contributors: yangmu
Tags: 163,connect
Requires at least: 3.0
Tested up to: 3.1
Stable tag: 1.0

使用网易微博账号登陆 WordPress 博客，并且留言使用网易微博的头像。

== Description ==

安装插件后，用户可以使用网易微博账号登陆 WordPress 博客，并且留言使用网易微博的头像。

详细介绍： http://appletemple.com/163-connect.html

插件官网： http://appletemple.com

作者官网： http://yang.mu

== Installation ==

上传激活即可。

详细安装请点击： http://appletemple.com/163-connect.html


== Changelog ==

1.0 - 初始版本