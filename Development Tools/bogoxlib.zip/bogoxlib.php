<?php
/*
Plugin Name: BogoXLib
Description: Library of Bogo extensions for Bogo based translation plugins
Plugin URI: http://wordpress.org/extend/plugins/bogoxlib/
Author: Markus Echterhoff
Author URI: http://www.markusechterhoff.com
Version: 1.1
License: GPLv3 or later
*/

require_once( 'includes/email.php' );
require_once( 'includes/functions.php' );
require_once( 'includes/filters.php' );

?>
