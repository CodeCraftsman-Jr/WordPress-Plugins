=== Easy GitHub Gist Shortcodes ===
Author URI: http://remicorson.com
Author: Remi Corson
Contributors: corsonr
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UAQZDW8V6HJUL
Tags: shortcodes, Gist, GitHub, GitHub Gist, code, content
Requires at least 3.0
Tested up to 3.3.1
Stable tag: 1.0

This plugin allows using shortcodes to insert <a href="http://gist.github.com">GitHub Gists</a> in any content, use [gist id="xxxxxx"]

== Description ==

This plugin allows using shortcodes to insert <a href="http://gist.github.com">GitHub Gists</a> in any content, use [gist id="xxxxxx"]

= Special Features =

With this plugin you can easily embebed GitHub Gist in any type of content: page, post, or custom post type. All You have to is to insert a shortcode!

[Developer Website](http://remicorson.com) - [Plugin Page](http://remicorson.com/easy-github-gist-shortcodes/)

== Installation ==

1. Upload the entire 'easy-github-gist-shortcodes' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add Gist on GitHub
4. Start inserting shortcodes this way [gist id="xxxxxx"], where "xxxxxx" is the Gist ID

== Changelog ==

= 1.0 =

* Initial release.