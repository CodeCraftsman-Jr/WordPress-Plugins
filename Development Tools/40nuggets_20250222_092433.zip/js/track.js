  (function() {
      var nm = document.createElement('script'); nm.type = 'text/javascript'; nm.async = true;
      nm.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 
      '40nuggets.com/widget/js/track/track-'+_40nmcid+'.js';
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(nm,s);
  })();
