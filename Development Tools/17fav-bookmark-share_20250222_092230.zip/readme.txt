﻿=== Plugin Name ===
Contributors: Buzzinate
Tags: Share,Bookmark,分享,书签,收藏
Requires at least: 2.5
Tested up to: 3.1.0
Stable tag: 4.2.0

数以万计的分享，源自一个简单的按钮， <a href="http://www.bshare.cn/">bShare 分享</a> 是一个强大的网页分享插件工具，您的读者可以将您网站上精采的内容快速分享、转贴到社群网络上。

== Description ==

<p>数以万计的分享，源自一个简单的按钮， <a href="http://www.bshare.cn/">bShare 分享</a> 是一个强大的网页分享插件工具，您的读者可以将您网站上精采的内容快速分享、转贴到社群网络上。</p>

== Installation ==

1. 上传bshare文件夹（包括一个.php文件及一个.txt文件）到'/wp-content/plugins/'目录下，然后在WordPress后台插件菜单下激活。
1. 该插件自动在在日志和静态页面正文后添加 bShare 按钮，如果你想在其他页面添加按钮，你可以使用Widget来添加。
1. 如果你想要对bShare按钮和插件进行自定义或者查看数据，请到http://www.bshare.cn/wordpressRegister注册并获取你的嵌入JavaScript代码，然后在Wordpress后台的setting->bShare分享中将你的代码填入文本框中并提交。