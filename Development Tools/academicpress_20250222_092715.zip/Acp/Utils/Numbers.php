<?php

class Acp_Utils_Numbers {
	public static function formatAs($int, $format) {
		return $int;
	}
}