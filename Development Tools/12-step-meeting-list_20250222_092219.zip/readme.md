12 Step Meeting List
====================

This plugin is designed to help 12 step programs list their meetings and locations. It standardizes addresses, and displays in a list or map.

The best way to install this plugin is via [its home page](https://wordpress.org/plugins/12-step-meeting-list/) in the WordPress Plugin Directory.