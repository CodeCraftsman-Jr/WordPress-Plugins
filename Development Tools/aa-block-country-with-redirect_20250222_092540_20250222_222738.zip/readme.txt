
=== AA Block country with redirect ===
Contributors: aaextention
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ashik685%40gmail%2ecom&lc=US&item_name=Donate%20AA%20Extension%20%21&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: aaextention , aa extension,extension,block country,redirect , ip,aa-extension
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

	It's a nice plugin with which you can redirect your visitor according to their country.

== Description ==


We know many times , people have to redirect their visitor to their respective pages according to their country. In this plugin we keep this option. So that you can easily redirect your visitor to their respective country.


### AA Block country with redirect Plugin by http://webdesigncr3ator.com

<br />


<strong>Plugin Features</strong><br />

* Coming soon

<strong>From this plugin you will get :</strong><br />

* redirect users according to country.

<strong>Conditions:</strong><br />

Here we use a custom rules . We can upgrade this plugin rules for you with a little cost so you can contact with us anytime.






== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>AA Block country with redirect</strong>" activate it.<br />

<br />

3. Setup country code via settings. It's like for bangladesh it will be BD, for canada it will be ca



== Screenshots ==

coming soon

== Changelog ==

	
	= 1.0 =
    * 17/11/2014 Initial release.

