=== A Broad Hint ===
  Contributors: Annubis
  Donate link: http://www.maechler.me/blog/2011/03/25/wordpress-plugin-a-broad-hint/
  Tags: editor, posting, post, notice, advertising,
  Version: 2.5
  Requires at least: 2.7+
  Tested up to: 3.4
  Stable tag: 1.0

== Description ==
  Mit diesem Plugin bindet man vor oder nach jedem Beitrag ein kleinen Text/Banner ein um so auf etwas Aufmerksam zu machen.
  
  [Created by Eric-Oliver M&auml;chler](http://www.chefblogger.me "chefblogger.me")
  
== Installation ==
  1. Upload des Plugins in den Plugin-Ordner /wp-content/plugins/
  2. In der Plugin-Administration ihres Blogs kann nun A Broad Hint aktiviert werden.
  3. A Broad Hint nun in der  Administration konfigurieren.
  4. Ein Beitrag schreiben und ver&ouml;ffentlichen und dann das Ergebnis bewundern.

= Licence =
  Copyright 2010-2013, Eric-Oliver M&auml;chler  (email : eric@chefblogger.me)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

== Screenshots ==
  No Screenshots aviable yet
  
== Frequently Asked Questions ==
  = Wie merke ich, ob es eine neue Version des Plugins gibt? =
  Dann wird man im Plugin Ordner deiner WP Installation auf die Upgrade-M&ouml;glichkeit aufmerksam gemacht.
  = Was muss ich tun, wenn ich ein Bug bemerke? =
  Man schickt dem Entwickler eine eMail an eric@maechler.me und meldet den Bug und wie man ihn nachvollziehen kann.
  = Twitterst du auch? =
  Wer mir gerne bei Twitter folgen möchte, darf das natürlich sehr gerne tun. Mich findet man unter @eric_maechler
  
== Upgrade Notice ==

== Changelog ==
  = v1.0 (02/06/2011) =
  * first releasing
  
   = v2.0 (10/04/2012) =
  * Code Update
  
     = v2.5 (22/08/2015) =
  * Code Update
  