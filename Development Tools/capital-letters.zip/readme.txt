=== Plugin Name ===
Contributors: thecellarroom
Author : TheCellarRoom
Donate link: http://gumroad.com/TheCellarRoom
License: GPL
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 1.0.3
Tags: content,case,grammar

Simply auto uppercases the first letter of the first word after finding a full stop in your post content.

== Description ==

Simply auto uppercases the first letter of the first word after finding a full stop in your post content.
No options or settings, works out of the box, simply just activate.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `tcr_plugin.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

= Ask a question first =

And we'll answer


== Screenshots ==

none

== Changelog ==

= 1.0.3 =
* version bump 4.2

= 1.0.2 =
* version bump 4.0

= 1.0.1 =
* version bump

= 1.0 =
* first submission