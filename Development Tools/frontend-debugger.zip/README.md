# Frontend Debugger WordPress plugin

![The Loop](https://github.com/szepeviktor/frontend-debugger/raw/assets/screenshot-1.jpg)
<hr/>
![The Header](https://github.com/szepeviktor/frontend-debugger/raw/assets/screenshot-2.jpg)
<hr/>
![Included files](https://github.com/szepeviktor/frontend-debugger/raw/assets/screenshot-3.jpg)
