<div id="linkitnotification" class="error">
<h2>Thanks for using 123LinkIt!</h2>

<p><b>To make this message go away:</b> You must <a href="admin.php?page=linkit_plugin&step=signup">create an account</a> and configure your <a href="admin.php?page=linkit_options">settings</a>
		and select your blog category before using the 123Linkit plugin!</p>

<p><b>Note: You only need to synchronize your posts once.</b> Our plugin will 
	automatically update new and edited posts.</p>

</div>
