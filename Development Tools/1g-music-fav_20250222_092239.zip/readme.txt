﻿=== 1g-music-fav ===
Contributors: 1g1g.info, 1g1g.com
Tags: 1g1g, music, fav
Requires at least: 3.0
Tested up to: 3.2.1
Stable Tag: 1.1

This plugin gives you a widget that you can share your 1g1g.com music fav data to your visitor.

== Description ==

This plugin gives you a widget that you can share your 1g1g.com music fav data to your visitor.
这个插件提供了一个小工具，您可以用它来向您的访客展现您在亦歌的音乐收藏数据。

== Installation ==

* Install directly from WordPress (just go to *Plugins* -> *Add New*) and activate.
Or
* Manually install to your WP plugins directory
	1. Unzip`*1g-music-fav.zip*`in the `*/wp-content/plugins/* directory.
	2. Activate the plugin through the *Plugins* menu in WordPress.
	3. All Done!
	
[安装方法]

* 在管理面板中选择“插件”->“添加新插件”，搜索“1g-music-fav”，看到“1g-music-fav”，点击“安装”。在弹出页面的右上角点击“现在安装”。安装完成后点击“激活插件”。

* 在“插件”->“插件”中，找到“1g-music-fav”，点击启用.

* All Done!

== Changelog ==
= 1.0 =
* Plugin Release.

== Upgrade Notice ==
= 1.0 =
才刚发布呢，哪来的更新提示啊..
