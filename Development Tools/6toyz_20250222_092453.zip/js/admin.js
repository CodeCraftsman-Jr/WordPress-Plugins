jQuery(document).ready(function() {
	jQuery("#toplevel_page_sixtoyz-config").find(".wp-submenu").append('<li><a href="http://affiliation.6toyz.fr/" target="_blank">Espace affilié</a>');
});