=== 6toyz ===
Contributors: 6toyz
Plugin URI: http://www.6toyz.fr/
Tags:
Requires at least: 3.3
Tested up to: 3.7
Stable tag: 1.1.2

Affiliation 6toyz

== Description ==

Cr&eacute;ez votre boutique sexy sur votre WordPress !

6toyz.fr est l'affiliation sexshop de r&eacute;f&eacute;rence sur le march&eacute; francais. Soci&eacute;t&eacute; pr&eacute;sente depuis 2007 avec la boutique http://www.coquin-malin.com, nous comptons d&eacute;j&agrave; plus de 900 affili&eacute;s partenaires et quelques 150 000 clients sur nos diff&eacute;rentes boutiques.

D&eacute;couvrez nos nombreux outils dynamiques et customisables en vous rendant sur notre site http://www.6toyz.fr
De nombreuses boutiques sexy &agrave; promouvoir: lingerie homme et femme, sextoys, massage, bien-&ecirc;tre, DVD...

Plus de 3900 produits disponibles en stock, nous g&eacute;rons vos achats, le service apr&egrave;s-vente et la logistique, vous n'avez rien &agrave; faire !

Venez vous inscrire sur la plateforme 6toyz : http://www.6toyz.fr

== Installation ==

Extraire le fichier zip et d&eacute;posez simplement le contenu dans le r&eacute;pertoire wp-content/plugins/ de votre installation de WordPress, puis activez le plugin depuis la page Plugins.

== Screenshots ==

1. Gestion des articles.

== Changelog ==

1.0.1 : Correction des accents
1.0.2 : Fix bugs version
1.0.3 : Description du plugin
1.0.4 : Re-correction des accents
1.0.5 : Fix bugs importation
1.0.6 : WP 3.6 OK
1.1.0 : WP 3.6
1.1.1 : WP 3.7 + Correction bug cat�gorie & champs customs posts
1.1.2 : Fix bugs