=== Accept Signups ===
Contributors: clearcrest
Tags: 
Requires at least: 3.0	
Tested up to: 4.0
Stable tag: 0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Accept signups by email. Data available from admin panel. Intended for use with external subscription services or your own email client.

== Description ==

Accept signups by email. Logs email, IP and timestamp. 

Data available in real-time from admin panel in these formats:

* HTML table 
* Comma separated email list for copy-and past operations
* XML
* CSV 

Intended for use with external subscription services, including email clients.

== Installation ==

Upload the Accept Signups plugin to your blog. Activate it. 

Update options as required on the Accepts Signups panel under Settings.

== Frequently Asked Questions ==

== Changelog ==

= 0.4 =
* Updated to work with WP version 3.9.1

= 0.3 =
* Confirmed on WP version 3.8

= 0.2 =
* Fixed potential security issues

= 0.1 =
* First incarnation

== Upgrade Notice == 

== Screenshots ==
