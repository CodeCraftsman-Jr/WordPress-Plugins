=== Easy Invitation Codes ===
Contributors: juliobox
Tags: code, invitation, guest, register
Requires at least: 3.6
Tested up to: 4.3
Stable tag: trunk
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RB7646G6NVPWU
License: GPLv2

Visitors have to enter an invitation code to register on your blog. The easy way! 

== Description ==
You want people can register on your blog, but you want to filter them? Create codes, share them, track the codes, track the users. Just easy as it seems! Don't let everyone register ;)
Check the BuddyPress version in "Developer" tab, made by "mediatricks.com", thanks to you.

== Installation ==

1. Extract the plugin folder from the downloaded ZIP file.
2. Upload BAW Easy Invitations Codes folder to your /wp-content/plugins/ directory.
3. Activate the plugin from the "Plugins" page in your Dashboard.
4. Go to settings !

== Frequently Asked Questions ==
To know: There is a BuddyPress version created by http://mediatricks.com based on my plugin.
http://wordpress.org/extend/plugins/baw-invitation-codes/developers/ 

== Screenshots ==
1. The (cool) menu
1. Registration form
1. Code list
1. Code generation
1. Code addition
1. Settings
1. Raw codes list

== Upgrade Notice ==
1.1+ requires 3.6
<1.1 requires 3.1

== Changelog ==

= 1.1 =
* 11 aug 2015
* 4.3 support
* Code imp
* Use sanitize_key on codes now
* Fix notices

= 1.0.4bp =
* 15 oct 2012
* Main plugin is still the same, i added a BuddyPress version in "Developer" tab.

= 1.0.4 =
* 28 sep 2012
* Fix tranlations problems, thanks to Jacek Wu ( mechlab )

= 1.0.3 =
* 11 aug 2012
* Add translation
* Fix notice

= 1.0.2 =
* 22 jul 2012
* Bug fix : when a registration was not correct, the code was used! Thanks to davito18 pointing me that!

= 1.0.1 =
* 29 jun 2012
* Fix a link bug for front end side, thanks to mborin (wp member)

= 1.0 =
* 11 jun 2012
* First Release
