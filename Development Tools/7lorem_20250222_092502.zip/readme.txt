=== Plugin Name ===
Contributors: alabdrezvan
Donate link: http://www.7learn.com/payment/?price=1000
Tags: widget,content,lorem ipsum,persian,farsi,فارسی,لورم اپیسوم
Requires at least: 3.0.1
Tested up to: 4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.7learn.com/

This plugin help you and your user to make easy lorem ipsum.
== Description ==

ابزارک ساخت ساده ی لورم اپیسوم به کاربران این امکان رو می دهد که به راحتی بتوانند متن ساختگی معنی دار و بی معنی بسازند.

== Installation ==


1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add it in your widgets

== Frequently Asked Questions ==

= آیا استفاده از افزونه رایگان است ؟ =

بله
== Screenshots ==
1. Screen shot (screenshot-1.png) in preview
== Changelog ==

= 1.0 =
*این اولین نسخه ی از این قالب می باشد.

== Upgrade Notice ==

= 1.0 =
انشالله به زودی با تغییرات جدید نمایان خواهد شد...