=== A Very Simple Captcha ===
Contributors: vinoth06
Tags: comment captcha, captcha, secure captcha, random captcha, text captcha, antispam, comment security
Requires at least: 3.0
Tested up to: 4.2.4
Stable tag: 3.0
License: GPLv2 or later

This Plugin provides very simple and powerful captcha for your blog with wide variety of captcha methods and models.

== Description ==
This Plugin provides very simple and powerful captcha for your blog with wide variety of logical methods and models. By displaying different logical captcha with random manner may provide high level of security.

1. User can select wide variety of different logical captcha methods like
 * Biggest Number
 * Smallest Number
 * Increasing Order
 * Decreasing Order
 * Subtraction of Two Numbers
 * Addition of Two Numbers
 * Alphabets [Case Sensitive]
 * Pick the Position of the Character 
 * Combo Box 
 * Multiplication 
 * Characters to Numbers
  Or you can make random by using "Random" option to make any of the one above logics with each time page loads.

  2. User can change the captcha background and font color which is suitable for their theme

  3. Random font styles and different image backgrounds for captcha.

For More Information ==> http://buffercode.com/project/a-very-simple-captcha-for-wordpress/

v3.0

* Added Wide variety of new captcha models

v2.4.2

* Support 3.9.1 version

v2.4.1.1

* Updated to 3.8.1

v2.4.1

* Spanish Language Added - Thanks to Andrew Kurtis <andrewk@webhostinghub.com>

v2.4

* Font updated
* Security added

v2.3 

*  Selecting  Am Not Spammer using check box
*  Removed Random selection and security key from admin dashboard

v2.2

* Now user can choose random option to display all logical captcha in random manner

v 1.4

* Random Alphabets, font style added

v 1.3

* Added Random Captcha background images

v 1.2

* Added New to show biggest or smallest number

v 1.1

* Added New Combo Box to verify Human or Bot

v 1.0

* Public release

* User can able to add the captcha in post or page comment

* User can able to select the captcha models like displaying in increasing, decreasing or random order

* No captcha in admin dashboard comment reply

For More Information ==> http://buffercode.com/project/a-very-simple-captcha-for-wordpress/

== Installation ==

1. Upload the "a-very-simple-captcha" directory to the plugins directory.
2. Go to the plugins setting page and activate "A Very Simple Captcha". 

For More Information ==> http://buffercode.com/project/a-very-simple-captcha-for-wordpress/

== Changelog ==
= 3.0 =

* Added Wide variety of new captcha models

= 2.4.2 =

* Support 3.9.1 version

= 2.4.1.1 =

* Updated to 3.8.1

= 2.4.1 =

* Spanish Language Added - Thanks to Andrew Kurtis <andrewk@webhostinghub.com>

= 2.4 =

* Font updated
* Security added

= 2.3 =

*  Selecting  Am Not Spammer using check box
*  Removed Random selection and security key from admin dashboard

= 2.2 =

* Now user can choose random option to display all logical captcha in random manner

= 1.4 =
* Random Alphabets, font style added

= 1.3 =
* Added Random Captcha background images

= 1.2 =
* Added New to show biggest or smallest number

= 1.1 =
* Added New Combo Box to verify Human or Bot

= 1.0 =
* Public release
* User can able to add the captcha in post or page comment
* User can able to select the captcha models like displaying in increasing, decreasing or random order
* No captcha in admin dashboard comment reply

For More Information ==> http://buffercode.com/project/a-very-simple-captcha-for-wordpress/

== Screenshots ==
1. Sort Numbers in Decreasing Order
2. Sort Numbers in Increasing Order
3. Add Number
4. Enter Smallest Number
5. Subtract Number
6. Alphabets with different font styles
7. A very simple Captcha admin panel
8. Checkbox captcha

For More Information ==> http://buffercode.com/project/a-very-simple-captcha-for-wordpress/