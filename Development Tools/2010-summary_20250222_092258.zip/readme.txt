=== Plugin Name ===
Contributors: tomasztopa
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=XYX6TEWN8ZUVU
Tags: summary, statistics, stats, year
Requires at least: 3.0.0
Tested up to: 3.0.3
Stable tag: 0.3

Generate a brief summary of 2010 on your blog. See how many posts were written durig the year, who was the most active commenter etc.

== Description ==

This plugin generates a brief summary of your blog for year 2010.

See how many posts you wrote durig the ending year,  which were the most popular, who was the most active commenter etc. 

And then share the stats with your readers - copy the data to a new draft with a single click.

== Installation ==

1. Upload `2010summary.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Are the stats published automatically? =

After generating the summary in the admin panel, you are able to create a draft with all the data placed automatically. You can then edit it and publish when you choose to.

= Are you planning to do some translations? =

I'll try to prepare some simple translations in the next release.


= I've got a suggestion / idea! = 

Please send it to wpsummary [at] topa.pl :)

== Screenshots ==

1. Part of the summary: number of posts in each month and day of the week
2. Welcome screen

== Changelog ==

= 0.3 = 
* Added Polish translation

= 0.2 =
* Added simple charts to the summary
* Added more data to the summary
* Excluded drafts from the summary

= 0.1 =
* Initial release
