=== AAM Online Bangla Radio ===

Contributors: Md. Abdullah Al Mahim

Donate link: http://aamahin.me

Tags: widget, plugin, sidebar, online bangla radio, online bangla radio plugin, bangla radio wordpress plugin, wordpress bangla radio plugin

Requires at least: 3.0

Tested up to: 3.8.1

Stable tag: 1.15

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

A Radio Player For All Online Bangla Radio Station. Can Be Used in widget and Sortcode.

== Description ==

- AAM Online Bangla Radio is a Simple Player Which will play All Bangla Radio Station.

- You Can Use/Put This Player Any Post/Page of Your Website by Using Sortcode.

- After Install A New Widget will Added Named 'AAM Online Bangla Radio', You can use this widget to your website sidebar or any widget area.

- Just Use This Sortcode to Display The Radio Player  [aambanglaradio]


- Here is Live Demo: http://plugins.aamahin.me/aam-online-bangla-radio-player/

== Installation ==

- Install from WordPress admin panel >> Plugins >> Add new plugin >> Search for `AAM Online Bangla Radio' plugin. After you install, activate the plug-in. 

- After Successfully Install & Active This Plugin You Need to Use Sortcode for display the player. use [aambanglaradio] sortcode for display the player anywhere in your website. (E,g: Post/Page or Widget Area)

== Frequently Asked Questions ==

= Can I use my existing WordPress theme? =
Of course! its works with nearly every WordPress theme.
= How To Update Radio Station? =
You Dont Need To update anything, we will autometic update the station when new station are available or remove dead station from the list
= How Can i Display The Player? =
You Can DIsplay This Player by Sortcode or Widget. For sortcode use this [aambanglaradio].

== Screenshots ==
1. Have a Look The Player

== Support ==
For Any Type of Support Submit your Query Here:
  http://plugins.aamahin.me/aam-online-bangla-radio-player/

== Changelog ==
= 1.0 =
* Initial release

== Upgrade Notice == 
1.00