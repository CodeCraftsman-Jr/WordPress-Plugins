===EagleEye Analyst===
Contributors: letsfx
Donate link: http://letsfx.com/wpanal
Tags: forex, market,analysis,daily,alerts,widget,signals,english,arabic,russian
Plugin URI: http://lets4x.com/
Requires at least: 2.8
Tested up to: 3.4.1
Stable tag: trunk,

EagleEye is FOREX, market trading tool designed to cover daily and hourly market analysis and trade signals.

== Description ==

Auto publish `Forex Analysis reports` posts on daily bases, to your blog. EagleEye is FOREX, market trading tool designed to cover daily trader`s needs. EagleEye is trader`s sharp eye on the FOREX market short term technical outlook, which, also, alert users with any changes on current market outlook. English, Russian and Arabic interfaces. Try this code on your posts to see full live report &lt;script type = &quot;text/javascript&quot; language = &quot;javascript&quot; src = &quot;http://www.letsfx.com/dailyreport/&quot; &gt;&lt;/script&gt;


== Installation ==

Follow the steps below to install the widget.

1. Upload the 'WP-EagleEye-Analyst' Widget directory to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enable and configure "EagleEye Analyst"  as usual on the Settings page.
4. Optional: you can have full hourly updated report inside your posts or pages. Just put this code on your posts to see full report &lt;script type = &quot;text/javascript&quot; language = &quot;javascript&quot; src = &quot;http://www.letsfx.com/dailyreport/&quot; &gt;&lt;/script&gt;


== Frequently Asked Questions ==

= What pairs covered? =

Analysis covers EURUSD, GBPUSD, USDCHF, USDJPY.


== Screenshots ==

== Changelog ==

= 1.0 =
* First published version.

== Upgrade Notice ==

= 1.0 =
Any minor versions below 1.0 should be upgraded.




