jQuery(function($) {
    $(document).ready(function(){
    	// here comes code ... 
    });
});