=== 404Editor ===
Contributors: nanoKhrome
Donate link: http://khromov-wm.ru
Tags: 404, error, seo
Requires at least: 2.0.2
Tested up to: 3.1
Stable tag: 4.3

This plugin add new option in you blog for use in 404 page. This is 

== Description ==

If you often change the template to your blog - then this plugin is for you.
Sometimes it is very important to keep the text error page.
Since some of these texts are large and change them do not feel like every time - you can save the text in the database. And only then retrieve it from there. And I will help you with this ...

== Installation ==

1. Upload `fzf-editor` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php get_option('err404'); ?>` in your 404.php file.

== Frequently Asked Questions ==

= How do I find the configuration page for the plugin? =

It is located at the bottom of the section "Settings"

== What code needs plugin? ==

You must insert the code. About it read official plugin page.

== Screenshots ==

1. Header. Description in Russian(English i'am add in version 1.1)
2. Edit page contents
3. For newbies: Find and click here and edit plugin!

== Changelog ==

= 1.0 =
* New plugin is created!

== Upgrade Notice ==
The new version of the plugin can be obtained from the official page or SVN
