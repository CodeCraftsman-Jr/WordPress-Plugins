=== 1silex4wp ===
Contributors: lexa
Donate link: http://projects.silexlabs.com/pluginwp/
Tags: Flash, ActionScript, theme, template, front office, front end, flog
Requires at least: 2.8.1
Tested up to: 2.8.1


Provide your visitors a Flash equivalent of your website / Convert your WordPress blog into a Flash application.

== Description ==

**THE PROJECT NAME HAS CHANGED TO FLOG SINCE IT IS NOW PART OF A LARGER PROJECT**

  * [flog/flash blog WordPress plugin is at this adress](http://wordpress.org/extend/plugins/flog/ "flog/flash blog WordPress plugin is at this adress")
  * [flog/flash blog plugins for several bloging systems and CMS are at this adress](http://flog.sourceforge.net "flog/flash blog plugins for several bloging systems and CMS are at this adress")