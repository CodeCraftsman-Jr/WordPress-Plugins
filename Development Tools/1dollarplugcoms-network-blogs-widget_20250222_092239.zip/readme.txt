=== 1dollarplug.com's network blogs widget ===
Contributors: pete scheepens
Donate link: http://1dollarplug.com
Tags: blog,multisite,network,count,posts,dollarplug
Requires at least: 1.0.2
Tested up to: 3.x
Stable tag: 1.1

Shows all blogs in a WordPress Network environment

== Description ==

This clean and lightweight plugin will show all the active blogs inside your network. Blogs are shown as linked blognames in a two-column layout to save space and keep things compact. Optionally you can check the box to automatically show the number of posts in each blog too.


== Frequently Asked Questions ==

Not a single person has had a frequently asked question so whatever it is that this plugin does, it must be self-explanatory and working darn good !! :-)
If you do have a question, don't hesitate to visit http://1dollarplug.com/discussions and ask for help.


== Screenshots ==

1. shot1
2. shot2
3. 1 dollar version

== Further Information ==

Simply activate this plugin and visit the widget section in your wordpress admin panel.
More information, the latest updates and related info can be found at: http://1dollarplug.com