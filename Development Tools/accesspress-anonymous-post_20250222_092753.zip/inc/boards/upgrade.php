<div class="ap-tabs-board" id="board-upgrade-settings" style="display: none;">
<h2><?php _e('Upgrade','accesspress-anonymous-post');?></h2>
	<div class="ap-tab-wrapper">
		<p><strong>For more features upgrade to PRO version. </strong><br />
		<strong>Regular Licence:</strong> Use, by you or one client, in a single end product which end users are not charged for. The total price includes the item price and a buyer fee. <br />
		<strong>Price:</strong> $25<br /><br />
        <strong>Extended Licence:</strong> Use, by you or one client, in a single end product which end users can be charged for. The total price includes the item price and a buyer fee.  <br />
		<strong>Price:</strong> $125<br /><br />
        Upgrades: <strong>Free lifetime upgrades</strong> </p>
		<div class="upgrade"><a href="http://codecanyon.net/item/accesspress-anonymous-post-pro/9160446?ref=AccessKeys" target="_blank">Upgrade now! </a></div>
	
		<h3 class="feature-title">Pro features </h3>
        <div class="ap-promo-img">
            <img src="<?php echo AP_IMAGE_DIR.'/sales-image-1.jpg';?>" style="text-align: center;"/>
            <img src="<?php echo AP_IMAGE_DIR.'/sales-image-2.jpg';?>" style="text-align: center;"/>
        </div>
		

	</div>
</div>