=== About Me Page ===
Contributors: Rameez_Iqbal
Tags: about, page, post, shortcode, profile, easy, about-me, simple, aboutus, bootstrap
Donate link: http://webcodingplace.com/contact-us/
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create your about me page in seconds, with different themes.

== Description ==
In these days it takes a long time to express yourself, or sometimes it is very difficult to choose design. I have made different ready to use designs for about me page. Just place shortcode [about-me] in page and change settings from admin. 

== Installation ==
1. Go to plugins in your dashboard and select \'add new\'
2. Search for \'About Me Page\' and install it
3. Go to Dashboard > About Me and set your desired settings
4. Use this shortcode [about-me] in any page
5. Now visit that page

== Screenshots ==
1. admin
2. Page with theme 1
3. Page with theme 2