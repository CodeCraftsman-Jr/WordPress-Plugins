=== 27coupons ===
Contributors: diffion
Tags: 27coupons, discount coupons, shopping deals, india shopping, shopping deals, coupons, coupon code
Requires at least: 2.8.2
Tested up to: 3.9.1

This plugin will create a widget which will display latest discount coupons of Indian shopping websites from 27coupons.com.

== Description ==

This plugin will create a widget which will display latest discount coupons of Indian shopping websites from 27coupons.com. 
You can customize the plugin to change the title and number of deals to be displayed. 
You can modify the css style to customize the look and feel to match yout template.
You can also monetize this widget. Please visit our webiste to know more.
For any customizations of this plugin, please contact us at http://www.27coupons.com/wp-widget/
If you are interested in creating your own plugin using our coupons data check http://www.27coupons.com/api/.

== Installation ==

1. Download the plugin zip file (27coupons.zip) from http://cdn.27coupons.com/widgets/27coupons.zip
2. Unzip and Upload contents of folder '27coupons' to the '/wp-content/plugins/' directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Go to 'Appearance-->Widgets' and add the widget 'Latest Coupons' to the sidebar.
5. You can change the title and number of deals to be displayed.
6. Enter your API Key to monetize this widget. Please visit our website to get your API key.

== Frequently Asked Questions ==

= I am unable to install, what should I do? =

Please contact us at http://www.27coupons.com/wp-widget/ and we will help you in every possible way to install the plugin and make it working.

== Screenshots ==

1. widget_sample.png.
2. widget_settings.png.