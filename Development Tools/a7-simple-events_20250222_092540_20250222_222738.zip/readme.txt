=== Plugin Name ===
Contributors: Tyrun
Donate link: http://aaronjholbrook.com/
Tags: events, custom post types
Requires at least: 3.3
Tested up to: 3.3
Stable tag: 1.0

Adds event post types to your site. Easy to use interface for adding and managing events.

== Description ==
Adds event post types to your site. Easy to use interface for adding and managing events.

== Installation ==

1. Upload `a7-simple-events` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Link will automatically show up in the comment box.

== Frequently Asked Questions ==

= None so far! =

== Changelog ==

= 1.0 = 

Initial release

== Roadmap ==

* add custom post type icon
* add options to allow date formatting
* add language support
* add listing layout (if possible, replaces archive-events.php?)
* add support for single layout?
