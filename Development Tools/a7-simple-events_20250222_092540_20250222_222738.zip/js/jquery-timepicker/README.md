
Timepicker Plugin for jQuery
========================

[<img src="http://jonthornton.github.com/jquery-timepicker/datepair-screenshot.png" alt="timepicker screenshot" />](http://jonthornton.github.com/jquery-timepicker)

[See a demo here](http://jonthornton.github.com/jquery-timepicker)

jquery.timepicker is a timepicker plugin for jQuery inspired by Google Calendar. It supports both mouse and keyboard navigation.

- - -

This software is made available under the open source MIT License. &copy; 2011 [Jon Thornton](http://www.jonthornton.com)
