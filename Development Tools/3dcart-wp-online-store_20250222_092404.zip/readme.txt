=== 3dcart: WordPress Online Store ===
Contributors: 3dcart
Donate link: http://www.3dcart.com/
Tags: e-commerce, ecommerce, online store, shopping 

cart, 3dcart, 3dcart wordpress, 3dcart for 

WordPress, 3dcart online products
Requires at least: 2.8
Tested up to: 3.8
Stable tag: 1

This wordpress plugin is created for merchants who want to sell products from their 3dcart Online Store within their Wordpress blog .


== Description ==

3dcart's wordpress online store plugin allows you to integrate 3dcart into an existing Wordpress website. (released under GNU/GPL by 3dcart)

Turn your Wordpress Blog in an Online Store and start selling online with the 3dcart WordPress ecommerce shopping cart plugin.


3dcart is an all-in-one ecommerce solution that integrates seamlessly with WordPress.

* VISA PCI Certified Shopping Cart Solution
* 24x7 Premium Technical Support
* No Transaction Fees
* Sell Products, Services and Digital Downloads
* Automatic Email Notifications, Abandoned Cart Emails, Autoresponders and more.
* Subscribe and Save with 3dcart Autoship
* Ship via UPS, USP, Fedex, Canada Post and AuPost.
* Over 160 Payment Gateways supported.
* Facebook Store included.
* Mobile Store included.

Plugin Features:

* Adds any number of dynamic widget in your blog's sidebar or widget ready areas.
* Online Store Home Special Products
* Products On Sale
* Products from a Specific Category 


[youtube http://www.youtube.com/watch?feature=player_embedded&v=O-vtCU7xEuo]

More About  3dcart for WordPress, click below http://www.3dcart.com


== Installation ==
1.     Download the plugin.
1.     Upload 3dcart-wp-online-store directory to the /wp-content/plugins/ directory.
1.     Activate the plugin through the 'Plugins' menu in WordPress.
1.     Setup the plugin on the 'Appearance > Widgets' page.

For complete instructions visit,
https://support.3dcart.com/3dcart/Knowledgebase/Article/View/483/0/how-do-i-install-the-3dcart-wordpress-plugin
 

== Frequently Asked Questions ==

= Do I need a 3dcart account to use the Wordpress Plugin? =
 Yes, you need an active 3dcart account or a Free Trial.
= How do I sign up for 3dcart? =
 Visit, http://www.3dcart.com/freetrial.htm

* For questions about the 3dcart solution,
* 3dcart Knowledge Base: http://support.3dcart.com
* For 24x7 Support Contact,
* Email: support@3dcart.com
* Phone: 1-800-828-6650 



for Installation guide and Live Demo.

== Screenshots ==
1. Admin Side Screenshot
2. Sample Front-end