<?php
/**
 * Plugin Name: Gigaom Copy Active Plugins
 * Plugin URI: http://gigaom.com
 * Description: Export/Import activated plugins
 * Version: 2.0
 * Author: Gigaom
 * Author URI: http://gigaom.com
 * License: GPL2
 */

require_once __DIR__ . '/components/class-go-copy-active-plugins.php';

go_copy_active_plugins();
