=== Gigaom Copy Active Plugins ===
Contributors: borkweb, zbtirrell
Tags: plugins, admin
Requires at least: 3.6
Tested up to: 3.8.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Utility WP plugin for importing/exporting active plugins

== Description ==

Get an easy list of all the active plugins and copy/paste that from one
WordPress instance to another to keep your active plugins in sync.

=== Links ===

* [WordPress plugin page](http://wordpress.org/plugins/go-copy-active-plugins/)
* [GitHub repo](https://github.com/GigaOM/go-copy-active-plugins)

== Installation ==

1. Upload `go-copy-active-plugins` to the `/wp-content/plugins/` directory
1. Activate 'Gigaom Copy Active Plugins' through the 'Plugins' menu in WordPress

== Contributing ==

This plugin is developed and [available on GitHub](https://github.com/GigaOM/go-copy-active-plugins). Contributions and questions are welcome!
