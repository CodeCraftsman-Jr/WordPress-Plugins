=== EPT Empty Plugin Template ===
Contributors: 1manfactory.com
Donate link: http://1manfactory.com/donate
Tags: wordpress plugin, plugin, development, template, emtpy plugin template, workshop, wordpress plugin workshop
Requires at least: 2.8
Tested up to: 3.1
Stable tag: "0.1.1.2"

An empty plugin template to start with, including the most basic necessary stuff. Take this as some kind of workshop.

== Description ==

STILL BETA Use this emtpy wordpress plugin template to build your own.

Considering all the advices given in http://codex.wordpress.org/Writing_a_Plugin, http://codex.wordpress.org/Creating_Options_Pages and http://planetozh.com/blog/2009/09/top-10-most-common-coding-mistakes-in-wordpress-plugins/

Every important point will have it's own page to explain.

= Including: =
* multi language ability
* uninstall routine
* data delete routine (avoid orphaned data)
* coding advices
* security aspects (validating user inputs, nonces)
* external third party stuff (Ajax, CSS, Javascript)
* shortcode
* Wordpress scheduler ("cronjob")
* logfiles
* capabilities

== Installation ==

ONLY USE THIS FOR LOCAL DEVELOPMENT
1. Upload EPT Empty Plugin Template  to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Adjust settings

== Remove plugin ==

1. Deactivate plugin through the 'Plugins' menu in WordPress
2. Delete plugin through the 'Plugins' menu in WordPress

It's best to use the build in delete function of wordpress. That way all the stored data will be removed and no orphaned data will stay.

== Screenshots ==

soon

== Frequently Asked Questions ==

soon

= How can I support you? =

Post a comment on [EPT Empty Plugin Template ](http://1manfactory.com/ept)

= What is the plugin page?  =

[EPT Empty Plugin Template ](http://1manfactory.com/ept)

= Do you have other plugins?  =

Check out my other [Wordpress Plugins](http://wordpress.org/extend/plugins/profile/1manfactory)

= Where do I post my feedback? =

Post it at the plugin page: [EPT Empty Plugin Template ](http://1manfactory.com/ept)

== Upgrade Notice ==

Just do a normal upgrade.

== Changelog ==

= 0.1.1.2 (03.03.2011) =
* adding submenus

= 0.1.1.1 (24.02.2011) =
* small bugfix
* testing on Wordpress 3.1

= 0.1.1 (22.02.2011) =
* logfile handling

= 0.1 (17.02.2011) =
* first version

== Upgrade Notice ==

Just do a normal upgrade.

== To do ==

More translations. Does someone wants to help?