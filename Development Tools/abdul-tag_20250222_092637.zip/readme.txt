=== NSTDA Widget ===
Contributors: nstda,information,call center,faq
Tags:  widget, nstda,information,call center,faq, WordPress.com
Stable tag: trunk
Requires at least: 2.8
Tested up to: 3.0

== Description ==
for any users who want to know everything about NSTDA, 
they can search for information and able to install this plugin to their website

== Installation ==
1. download the file
2. install to your system
3. enable this plugin

== Frequently Asked Questions ==
coming soon

== Changelog ==
-simple request to abdul server for every questions

== Upgrade Notice ==
coming sooon

== Screenshots ==
nothing now