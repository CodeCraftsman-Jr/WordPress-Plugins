=== ABC Test ===
Contributors: webfaster
Donate link: http://www.webfaster.it/cms/wordpress/plugins/abctest
Tags: quiz, test
Requires at least: 3.2.1
Tested up to: 3.2.1
Stable tag: 0.3

ABC Test lets to present quizzes with three options for each question.
 
== Description ==

ABC Test lets to present quizzes with three options for each question.
At the end of the quiz the user has a response based on the prevalence of answers A, B or C.

No limit for questions in each quiz.

Each quiz must contains four questions at least.


== Installation ==

1. Upload unzipped folder `abctest to` the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Put a shortcode in page or post editor: [abctest id="1"]

Note: make sure the plugin folder is named 'abctest', not 'abc-test' or similar.


== Frequently Asked Questions ==

= Can I customize the look and feel of the quiz? =
Yes, please refer to the folder 'templates / default'. Create a new folder with the same structure and a different name.
You can edit html and css files as you wish. Then set the new theme from the admin panel: Configuration> Select the graphic theme.

== Screenshots ==

== Changelog ==

= 0.1 =

== Upgrade Notice ==

= 0.3 =
Security patch