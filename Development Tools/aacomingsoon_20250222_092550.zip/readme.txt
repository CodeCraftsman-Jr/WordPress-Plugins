=== AA Coming Soon ===
Contributors: aaextention
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ashik685%40gmail%2ecom&lc=US&item_name=Donate%20AA%20Extension%20%21&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: aaextension, coming soon, welcome , maintenance
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

It's a simple coming soon extension by AA Extension. But it is still in development.

== Description ==


This plugin is created for making sure that, a coming soon page for your website. It is still in development phase. We try to make it most simple as we do same thing for our other plugins.


### AA Coming Soon Plugin by http://webdesigncr3ator.com

<br />


<strong>Plugin Features</strong><br />

* Coming soon


<strong>Version </strong><br />

1.0.0




== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>AA Coming Soon</strong>" activate it.<br />

<br />



== Screenshots ==

Coming Soon ..

== Changelog ==

	
	= 1.0 =
    * 2/11/2014 Initial release.

