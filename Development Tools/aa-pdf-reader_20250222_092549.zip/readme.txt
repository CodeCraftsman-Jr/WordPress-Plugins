=== Plugin Name ===
AA Pdf reader

Tags:aapdf , aaextention
Requires at least:4.0
Tested up to:4.0
Stable tag:aapdfreader
License: GPL
Contributors :A and A
==Description==
A free pdf reader
[pdf link="http://example.../pdffile.pdf"]