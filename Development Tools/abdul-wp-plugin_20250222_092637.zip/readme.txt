=== ABDUL Widget ===
Contributors: Guangming Sangkeettrakarn
Tags:  widget, abdul,information,information broker,chatter bot, WordPress.com
Stable tag: 0.1.3.4
Requires at least: 2.8
Tested up to: 3.0

== Description ==
ABDUL is Thai Chatter Bot providing any information from internet. 
He works as an information broker.
To ask him for everything you want to know
--------
อับดุลเป็นระบบบริการข้อมูลเชิงสนทนา ผ่านช่องทางต่างๆ 
ให้บริการข้อมูลมากมาย ที่ผู้ใช้งานอินเทอร์เน็ตสนใจ

โดยบริการที่เปิดใช้งานปัจจุบันมีดังนี้

- สืบค้นข่าว
- แปลศัพท์ 
- แปลข้อความ
- รายงานสภาพอากาศ
- รายงานสภาพจราจร
- คิดเลข
- ตรวจผลสลากกินแบ่งฯ
- ราคาน้ำมัน
- ราคาทอง
- ดัชนีตลาดหลักทรัพย์ ( realtime )
- อัตราแลกเปลี่ยน +  แปลงค่า
- รอบหนัง
- QR Encoder


== Installation ==
1. download the file
2. install to your system
3. enable this plugin

== Frequently Asked Questions ==
ตัวอย่างการใช้งาน

- สืบค้นข่าว
> ข่าว

- แปลศัพท์ 
> dict dog, ดิก ต้นไม้

- แปลข้อความ
>trans i love you

- รายงานสภาพอากาศ
> อากาศปทุมธานี

- รายงานสภาพจราจร
> จราจร พญาไท

- คิดเลข
> 123*4^2

- ตรวจผลสลากกินแบ่งฯ
>หวย, ตรวจหวย 123456

- ราคาน้ำมัน

- ราคาทอง

- ดัชนีตลาดหลักทรัพย์ ( realtime )
>หุ้น,
หุ้น กสิกร,
หุ้น PTT

- อัตราแลกเปลี่ยน
> ค่าเงิน, ค่าเงินบาท

- แปลงค่าอัตราแลกเปลี่ยน
> 1000 eur (*), 1000 usd jpy  (**)

*เทียบกับเงินบาท, ** สกุลเงิน
>THB = ไทย ( บาท ),
RUB,
SEK = สวีเดน,
KES,
BND,
PHP = ฟิลิปปินส์ ( เปโซ ),
NZD,
KWD,
IDR,
PKR,
LAK,
GBP  = สหราชอาณาจักร (ปอนด์สเตอร์ลิง),
KHR = กัมพูชา (เรียล),
CZK,
JPY  = ญี่ปุ่น,
BDT,
PLN,
SGD  = สิงคโปร์ (ดอลลาร์),
AUD = ออสเตรเลีย (ดอลลาร์),
KRW = เกาหลี (วอน),
CNY = จีน (หยวน),
EGP,
INR  = อินเดีย,
VND = เวียดนาม (ด็อง),
ZAR,
MMK = พม่า ,
NOK = นอร์เวย์,
USD = สหรัฐอเมริกา (ดอลลาร์),
MYR = มาเลเซีย (ริงกิต),
CAD = แคนาดา,
DKK  = เดนมาร์ก
SAR,
MXN,
EUR  = ยูโร,
HKD = ฮ่องกง (ดอลลาร์),
CHF,
TWD,
AED,

- รอบหนัง
> รอบหนัง [ชื่อเรื่อง/ชื่อสถานที่]

- สร้าง QR Code
> qr  [ข้อความ]

== Changelog ==
0.1
-simple request to abdul server for every questions

0.1.3.1
add example 


== Upgrade Notice ==
coming sooon

== Screenshots ==
nothing now