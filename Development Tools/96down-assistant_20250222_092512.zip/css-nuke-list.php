/** CSS Nuke List Start **/

<!-- WPMU Dashboard Installer -->
#wpmu-install-dashboard {
    display: block;
}
#the-list .wpmu-update-row {
    background-color: #031F34;
    border: medium none;
    color: #C0D7EB;
    background-size: 100px auto;
    display: none;
}
<!-- WP-filebase key notice -->
display: none;
div#wpfilebase-warning.update.fade {
  display: none;
}

/** CSS Nuke List End **/
