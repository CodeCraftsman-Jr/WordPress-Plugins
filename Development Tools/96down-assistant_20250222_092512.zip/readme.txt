=== 96down Assistant ===
Contributors: ModManMatt
Donate link: http://calicotek.com/donate/
Tags: dashboard, feed, widget, admin, rss, 96down, assistant, 96down assistant, calicotek
Requires at least: 3.7
Tested up to: 4.0
Stable tag: 1.0.4
License: GPLv2 or later

Plugin to remove update notifications and registration notifications for nulled pugins and themes from 96down, also adds a news rss feed widget to the admin dashboard.

== Description ==

Plugin to remove update notifications and registration notifications for nulled pugins and themes from 96down, also adds a news rss feed widget to the admin dashboard.

Please visit us at http://96down.com for access to up-to-date Premium nulled plugins, themes, scripts and more...

We also have a development community for anyone with skills that wants to get involved in our development projects.
http://dev96down.pw

The default settings are:

* the standard title of the widget box is "Recent Updates"
* default link addy for all new releases use: http://www.96down.com/private/rss/forums/4-96downcom-updates/
* the default number of RSS items is 5
* yellow background color of the widget (`#FFFF99`)

== Installation ==

= Wordpress =

Search for "96Down Assistant plugin" and install with the **Plugins > Add New** back-end page.

 &hellip; OR &hellip;

Follow these steps:

1. Download zip file.
2. Upload the zip file via the Plugins > Add New > Upload page &hellip; OR &hellip; unpack and upload with your favorite FTP client to the /plugins/ folder.
3. Activate the plugin on the Plugins page.

Done!

On the Settings page you can change the widget title, the feed URL, the number of feed items and the background color of the widget. You will also see a checkbox that resets the settings back to the default settings when deactivating and then reactivating the plugin again.

After saving the settings, you can see the results in the main WordPress Dashboard.

== Frequently Asked Questions ==

=  is this plugin under Heavy development or is it Stable? =  this plugin is under very heavy active development but it is stable with no errors reported so far.

== Screenshots ==

1. pre install.
2. after install.
3. settings page.
4. dashboard widget.

== Changelog ==
= Version 1.0.4 = 
* Added CSS-Nuke-List.php file to add list of display;none elements.
* Addwpmudev blocker
* Fixed call to incorrect css files.
* fixed 2 image links to use wp-codex file location shortcodes.
* updated read me details and description.

= Version 1.0.3 = 
* Fixed rss feed combined into 1
* added more usage rss links to change the output of the rss widget.
* Updated Links and donate buttons.
* Updated Icons and images.
* added visit 96down link to top right of dashboard widget

= Version 1.0.2 = 
* added notification blocker for IgniteWoo Updater.
* Added Rss News Dashboard Widget
* Added Setting Configuration Page with Link under settings of dashboard and link to config from plugins page.
* Added About Author Area to plugin settings page
* Added config options for widget (background color, post amount 2 show, change title text, change feed url.)

= Version 1.0.1 = 
* initial plugin release, added block update notifications for woothemes and wpmudev.

