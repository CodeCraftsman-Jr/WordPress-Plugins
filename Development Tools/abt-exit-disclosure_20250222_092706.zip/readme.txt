=== ABT Exit Disclosure ===
Contributors: Will Haley with AtlanticBT @ www.atlanticbt.com
Tags: disclosures, leaving, redirect
Requires at least: 3.0
Tested up to: 3.4
Stable tag: 1.0.0
License: GPLv3 or later

== Description ==
This creates a short tag that will allow you to display a custom message with a link at the bottom of it.  It was originally developed to provide a simple way to disclose that users are leaving the current website when a link is clicked.  

== Installation ==
Upload the plugin to your blog, Activate it. 
	1. Set up your disclosure in the Setting Sub-menu, "Exit Message"
	2. Use the short code, which is on shown on the "Exit Message" settings page.  
	3. Place the short code on a page, and set the attribute link to where the Continue link should be set to.
You should be good to go.

== Changelog ==
1.0 - Initial Release