=== AB Google Map Travel (AB-MAP) ===
Contributors: Aboobacker P Ummer
Donate link: http://wp.aboobacker.com/
Tags: Google Maps, Distance Calculator, Google Maps, Calculate Distance, Driving Directions, Google Travel, AB Google Map Travel, Abooze Map Plugin
Requires at least: 4.0
Tested up to: 4.2.1
Stable tag: 4.0
This plugin will display the distance & driving direction between two points on earth.
== Description ==
If you are a taxi provider, make your customers allow to calculate their travel distance from source to destination, fare with different charges for day and night travels.
You can get the results of the plugin in any language supported by the google direction.
<strong>Usage</strong>
Add the following shortcode in the page:
<code>[AB-MAP]</code>
<p>Created By: Aboobacker P Ummer</p>
<p>Email : mail@aboobacker.com</p>
<p>Demo: http://wp.aboobacker.com/</p>
== Installation ==
1. Upload the plugin to your /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. In the Wordpress admin panel, you can see the menu named "Google Map Travel". Go to this page and set the parameters according to your requirements.
4. Now place the [AB-MAP] shortcode on the post/page where you want the AB Google Map Travel to appear.
== Frequently Asked Questions ==
= What is the shortcode for inserting the plugin to Post/Page? =
 You can use [AB-MAP]
== Screenshots ==
Coming soon.
== Changelog ==
= 1.0 =
Released on 17/01/2012 
<ul>
 <li>Initial release</li>
</ul>
= 1.1
Released on 20/01/2012 
<ul>
 <li>Added option to set different currency formats.</li>
</ul>
= 1.2=
Released on 23/01/2012 
<ul>
 <li>Fixed compatibility with IE versions.</li>
</ul>
= 2.1=
Released on 15/08/2012 
<ul>
 <li>Quick Fix</li>
</ul>
= 3.1=
Released on 25/09/2012 
<ul>
 <li>Added option for setting different charges for day and night travels.</li>
 <li>Display the distance in both Kms and Miles.</li>
</ul>
= 3.2=
Released on 09/07/2013
<ul>
 <li>Minor edit to display error message in red color.</li>
 <li>Demo URL updated.</li>
</ul>
= 3.3=
Released on 06/08/2013
<ul>
 <li>Fixed a floating problem on most of the themes.</li>
</ul>
= 3.4=
Released on 02/04/2014
<ul>
 <li>Fixed a small bug.</li>
</ul>

= 4.0=
Released on 12/03/2015
<ul>
 <li>Fixed a major vulnerability.</li>
</ul>