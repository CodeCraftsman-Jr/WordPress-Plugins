=== AbsoluteRSS ===

Contributors: raccettura
Tags: rss, url, posts
Requires at least: 3.2.1
Tested up to: 3.2.1
Stable tag: 1.1.3

Adjusts your links in RSS to use absolute links so that they work correctly in all feed readers (and validate). GPL Licensed.


== Description ==

Adjusts your links in RSS to use absolute links so that they work correctly in all feed readers (and validate). GPL Licensed.


== Installation ==

1. Upload 'absoluteRSS.php' to '/wp-content/plugins/' directory in your WordPress install.
2. Login to WordPress and go to the 'Plugins' page.
3. Find  'AbsoluteRSS' in the list of installed plugins and press 'Activate'.
4. Your done.
