=== About Me ===

Contributors: nolith
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5570803

Tags: widget,sidebar,Social network, profile page,social link,icon links,about me, XFN, Amazon, Wishlist, Bitbucket, Blogs, BlogMarks, Dapx, Delicious, Digg, Facebook, Flickr, FriendFeed, Github, Identi.ca, Jeqq, Last FM, Linked In, My Space, Picasa Web Albums, Plurk, Pownce, Sixent, Stumble Upon, Technorati, Twitter, YouTube, Xing, Hellotxt, Hyves.nl, Hyves.net, Disqus, redgage, GoodReads, Google Plus, Google Profile, Google Reader, Qype, Orkut, ebay, Qik, Anobii, DeviantART, LibraryThing, Songza

Requires at least: 2.6
Tested up to: 3.3.1
Stable tag: 1.0.12

About me is a sidebar widget that displays icon links to your profile pages on other social networking sites. Based on Social Links.

== Description ==

About me is a sidebar widget that displays icon links to your profile pages on other social networking sites. All the icons has `rel="me"` tag. ([XFN compliant](http://www.gmpg.org/xfn/ "XFN compliant")).
This plugin is forked from [SocialLinks](http://blog.maybe5.com/?page_id=94 "Social Links page")

**What's new**
Pinterest and Google Plus support.


**Supported Networks:**


* Amazon Wishlist
* Anobii
* Bitbucket
* Blogs
* BlogMarks
* Dapx
* Delicious
* DeviantART
* Digg
* Disqus
* Ebay
* Facebook
* Flickr
* FriendFeed
* Github
* GoodReads
* Google Plus
* Google Profile
* Google Reader
* Hellotxt
* Hyves.nl
* Identi.ca
* Jeqq
* Last FM
* LibraryThing
* Linked In
* My Space
* Orkut
* Picasa Web Albums
* Pinterest
* Plurk
* Pownce
* Qik
* Qype
* RedGage
* Sixent
* Songza
* Stumble Upon
* Technorati
* Twitter
* YouTube
* Xing


== Installation ==

1. Download the installation zip file and unzip leaving the directory structure in tact.
1. Upload the newly unzipped 'about-me' folder to the `/wp-content/plugins/` folder
1. Activate the About Me plugin from the 'Plugins' menu.

1. Add the widget to your sidebar from the 'Widgets' design page.

1. Add your social links from the 'About Me' page under the 'Tools' page.

== Frequently Asked Questions ==

= How do I get another website supported? =

Just post a comment to [my blog](http://abisso.org/projects/about-me/) or [open a ticket](http://code.l0g.in/about-me/issues/new/) with a link to any user page on that site.

I will add suggested sites in upcoming releases.

= When I hit 'Add' nothing happens =
The 'add' button is linked to an ajax function provided by prototype lib. Some other plugins inject their own version of prototype, instead of using the one provided by WP, this result in a broken 'add' button.

If you are using **Use Google Libraries** plugins read [this](http://code.l0g.in/about-me/issue/7/wp-28-final-add-button-is-disabled)

= I've updated from 1.0.0 to 1.0.1 and my widget disappered =

From version 1.0.0 to 1.0.1 About Me widget has been renamed to 'About Me - Social Link', so you have simply to add it from the widgets page.

== Screenshots ==

1. About Me sidebar widget

== Change Log ==
* 1.0.12 FIX: Official Pinterest image
* 1.0.11 NEW: Pinterest support.
* 1.0.10 FIX: FAQ fix
* 1.0.9 FIX: Fixed the plugin home page
* 1.0.8 NEW: Google Plus support.
* 1.0.7 FIX: conflict with find-me-on plugin. Tested with WP 2.9.2
* 1.0.6 NEW: Anobii, DeviantART, LibraryThing, Qik and Songza support.
* 1.0.5 NEW:works on subpath installation. goodreads.com, orkut, google profile, google reader, qype, ebay support
* 1.0.4 NEW:redgage.com support
* 1.0.3 NEW:Disqus.com support
* 1.0.2 NEW:Hyves.nl support; MINOR: title tag added to images
* 1.0.1 NEW:Hellotxt support; Minor changes in widget option layout; Widget renamed to 'About Me - Social Links'; Management page renamed to 'About Me'
* 1.0.0 NEW:Bitbucket, Identi.ca, GitHub support FIX:now works with Lightbox2/Slimbox plugins
