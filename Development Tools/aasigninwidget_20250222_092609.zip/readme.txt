=== AA Signin Widget ===
Contributors: aaextention
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ashik685%40gmail%2ecom&lc=US&item_name=Donate%20AA%20Extension%20%21&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: aaextension,aaextention, signin , signup , login , signin widget
Requires at least: 3.5
Tested up to: 4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Stable tag: 1.0

It's signin extension from AA Production House.

== Description ==

This is a simple sign in widget . Go to Widget and drag the Sign in widget to sidebar. Or you can use [signin] shortcode .   
Just use this shortcode and see the result yourself. If you like it please don\\\'t forget to give a review. Thanks

== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>AA Signin Widget</strong>" activate it.<br />

<br />

 
== Frequently Asked Questions ==

How i use this plugin ?

  Add this shortcode ( [signin] ) to post  or page and publish .

  or

  Go to Widget and drag the Sign in widget to sidebar.

== Screenshots ==
1. screenshot-1
2. screenshot-2
