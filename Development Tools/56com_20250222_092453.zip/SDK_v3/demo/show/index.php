<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>56视频无广告播放方法</title>
<meta name="keywords" content="本站主要为了生成56视频无广告播放视频地址,为方便大家调用56视频同时生成视频代码,视频地址,FLASH地址,网页代码等方式.">
<meta name="description" content="56视频,无广告视频,免广告,播放方法,视频,视频代码,视频地址,FLASH地址,网页代码">
<style>
    .player {position: relative;text-align: left;width: 680px;padding-left:350px;margin-top: 35px;}
    #bottom {position: relative;padding-left:350px; margin-top: 15px;padding-top:5px;}
    .navlist{position: relative;text-align: left;width: 680px;margin:0 auto;}
</style>
</head>
<body>
<?php require_once 'nav.php'; ?> 
<div class="navlist">
    <h2>平台导航</h2>
    <ul>
        <li><a target="_blank" href="http://dev.56.com/">开放平台首页</a></li>
        <li><a target="_blank" href="http://dev.56.com/developers.html">开发者手册</a></li>
        <li><a target="_blank" href="http://dev.56.com/wiki/basic-addapp.html">创建我的应用</a></li>
        <li><a target="_blank" href="http://dev.56.com/wiki/">开放平台wiki</a></li>
    </ul>
    <h2>平台概述</h2>
    <p><span>56网开放平台是一个基于56网视频系统的开放的视频技术及运营平台。</span></p>
    <p><span>56网开放平台为您的网站提供了全面的视频上传、转码、播放、分发、管理等服务，并通过开放接口（Open API）共享海量的视频数据，快速高效的搭建自己的视频平台，共享巨大流量带来的利益。您可以登录平台并创建应用，使用平台提供的接口，创建个性化的应用或者使用应用组件让您的网站拥有强大的视频功能。</span></p>
</div>
</body>
</html>
