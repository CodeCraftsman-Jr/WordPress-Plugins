<?php
return array(
    'is_developer'=>false,
    'print_request_params'=>false,
    'appkey'      =>'3000000133',
    'secret'      =>'4d85413677701809',
    'domain'      =>'http://oapi.56.com',
    'token'       =>'1341546967|9dc94c8f796c49c63de99cdf7260361b',
    'test_user_id'=>'louislizixing',
    );
