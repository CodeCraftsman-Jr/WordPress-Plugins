=== 56.com video upload plugin（56.com视频上传插件） ===
Contributors: 56.com(jiancheng.mai@renren-inc.com)
Donate link: 
Tags: 56,video
Requires at least: 3.3
Tested up to: 3.7.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

56 网开放平台为您的网站提供了全面的视频上传、转码、播放、分发、管理等服务，并通过开放接口（Open API）共享海量的视频数据，快速高效的搭建自己的视频平台，共享巨大流量带来的利益。您可以登录平台并创建应用，使用平台提供的接口，创建个性化的应用或者使用应用组件让您的网站拥有强大的视频功能。  

== Installation ==

1. Upload `56com` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
如您在使用该SDK上遇到任何问题，请联系Louis email:jianchen.mai@renren-inc.com QQ:837522080
56网开放平台QQ群 233921452
开放平台首页 http://dev.56.com/
开发者手册 http://dev.56.com/developers.html
创建我的应用 http://dev.56.com/wiki/basic-addapp.html
开放平台wiki http://dev.56.com/wiki/





== Frequently asked questions ==

= A question that someone might have =

An answer to that question.
http://tieba.56.com/v/bn-56%E7%BD%91%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0

== Screenshots ==

1. http://dev.56.com

== Changelog ==

= 1.1 =
*1.修复的对新版本wordpress的不兼容问题，目前的兼容版本:3.3~3.7.1。
*2.增加的视频列表，不过，视频列表有缓存。所以，用户上传视频或者删除视频之后，请10分钟之后再刷新视频列表查看。
*3.增加视频删除功能。
*4.在文章编辑的时候，可以在视频列表中直接插入视频，不用每次要上传才能插入。

== Upgrade notice ==

not yet

== Arbitrary section 1 ==


