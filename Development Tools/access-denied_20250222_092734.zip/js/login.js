
jQuery(document).ready(function($)
	{
		
		//$("#loginform").hide();
		

		
		$("#user_login").attr('disabled','disabled');		
		$("#user_pass").attr('disabled','disabled');
		$("#rememberme").attr('disabled','disabled');
		$("#wp-submit").attr('disabled','disabled');				
		$("#user_email").attr('disabled','disabled');			
	});	







