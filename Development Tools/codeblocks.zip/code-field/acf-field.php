<?php
add_action('acf/register_fields', function(){
	include_once 'acf-field-v4.php';
});
?>