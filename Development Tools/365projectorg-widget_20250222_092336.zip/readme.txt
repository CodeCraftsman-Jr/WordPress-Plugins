=== 365Project.org Widget ===
Contributors: trepmal
Donate link: kaileylampert.com/donate/
Tags: widget
Requires at least: 3.3
Tested up to: 3.5
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show photos from a 365project.org feed

== Description ==

Show photos from a 365project.org feed

== Installation ==

1. Upload `365project-widget` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Look for 365Project.org Widget on the Widgets page

== Frequently asked questions ==

Not yet!

== Screenshots ==

1. Widget options
2. Widget display

== Other Notes ==

**Title:** Widget title

**Hide Title:** Show or hide the widget title

**Feed:** URL of 365project.org feed

**Timeout:** How long, in seconds (600 = 10 minutes), to cache the widget.

**Limit:** How many images to show. Max 10 for user feeds, 24 for "Latest" feed


== Changelog ==
= 1.0 =
* First release

== Upgrade notice ==
= 1.0 =
First release
