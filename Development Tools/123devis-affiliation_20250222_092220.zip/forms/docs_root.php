<h2><?php _e( 'Documentation', 'sm_translate' );?></h2>
<h3><?php _e( 'Learn how to use the Servicemagic API tool here', 'sm_translate' );?></h3>
<p><a href="?page=sm_admin_docs_quickstart">Go</a></p>
<p>First set the correct api location</p>
<p>Then set your credentials</p>
<p>Next, Embedeable Forms</p>

<h3></h3>