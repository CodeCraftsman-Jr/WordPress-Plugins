<h3><?php _e('"Basic" Service Request', 'sm_translate');?></h3>
<p><?php _e('This presentation has the whole form on one page.', 'sm_translate');?></p>
<a href="?page=sm_admin_sr_forms_form&id=0&view=basic"><?php _e('Choose', 'sm_translate');?></a>