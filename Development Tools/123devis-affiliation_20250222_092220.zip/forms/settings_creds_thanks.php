<div class="wrap">
<?php 
	print "<h2>" . __('Settings', 'sm_translate' ) . "</h2>";
	print "<h3>" . __('Login details') . "</h3>";
	print "<div class=\"sm_msg\">" . __('Successful save','sm_translate') . "</div>";
	print '<p><a href="?page=sm_admin_forms">' . __('Create a new Embeddable form?','sm_translate') . "</a><p>";
	print '</div>';