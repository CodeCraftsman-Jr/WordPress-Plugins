<?php
	$saveable_data['parameters']['next_string'] = stripslashes_deep($_REQUEST['next_string']);
	$saveable_data['parameters']['submit_string'] = stripslashes_deep($_REQUEST['submit_string']);
  $saveable_data['parameters']['form_config'] = $form_config;
