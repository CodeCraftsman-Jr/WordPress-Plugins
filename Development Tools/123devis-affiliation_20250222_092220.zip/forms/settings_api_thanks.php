<div class="wrap">
<h2><?php _e('API url management', 'sm_translate' );?></h2>
<div class="sm_msg"><?php _e('Successful save','sm_translate');?></div>
</div>