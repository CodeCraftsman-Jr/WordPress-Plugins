<h3><?php _e('"2 Step" Service Request', 'sm_translate');?></h3>
<p><?php _e("This presentation breaks the form into two steps. The first step includes the job description and the second step is for the customer's contact details.", "sm_translate")?></p>
<a href="?page=sm_admin_sr_forms_form&id=0&view=2page"><?php _e("Choose", "sm_translate");?></a>