<div class="wrap">
<h2><?php _e('Embeddable Forms', 'sm_translate' );?></h2>

<?php sm_show_messages($messages);?>

<p><a href="?page=sm_admin_forms"><?php _e("Back to previous list",'sm_translate');?></a></p>
<p><a href="?page=sm_admin_forms_form&id=0"><?php _e("Create new form",'sm_translate');?></a></p>
</div>