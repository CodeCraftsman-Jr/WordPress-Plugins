<h3><?php _e('Form Options', "sm_translate");?></h3>
<div class="sm_msg"><?php _e('Update Successful','sm_translate');?></div>