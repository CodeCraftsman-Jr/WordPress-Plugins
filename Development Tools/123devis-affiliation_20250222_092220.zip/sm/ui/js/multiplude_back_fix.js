if (location.href.indexOf("#_") > 0){
	location.href = location.href.replace(/#.+/, "");
}