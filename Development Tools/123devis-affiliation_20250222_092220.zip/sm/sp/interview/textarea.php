<?php
	class sm_sp_interview_textarea extends sm_formlib_textarea {
				
	}