<?php
	class sm_sp_interview_checkbox extends sm_formlib_checkbox {
				
	}