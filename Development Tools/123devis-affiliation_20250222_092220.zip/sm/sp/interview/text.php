<?php
	class sm_sp_interview_text extends sm_formlib_text {
				
	}