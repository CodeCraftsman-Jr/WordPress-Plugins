<?php
	class sm_sp_interview_select extends sm_formlib_select {
				
	}