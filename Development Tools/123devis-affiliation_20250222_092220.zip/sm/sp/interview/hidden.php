<?php
	class sm_sp_interview_hidden extends sm_formlib_hidden {
				
	}