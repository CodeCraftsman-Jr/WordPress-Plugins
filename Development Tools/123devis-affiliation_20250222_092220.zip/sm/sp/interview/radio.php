<?php
	class sm_sp_interview_radio extends sm_formlib_radio {
				
	}