<?php
	class sm_sr_activity_interview_text extends sm_formlib_text {
				
	}