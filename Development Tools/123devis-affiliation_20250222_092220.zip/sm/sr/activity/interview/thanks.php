<?php
	class sm_sr_activity_interview_thanks extends sm_renderable  {
		function render($data){
			return "Thanks for using SM";
		}
	}