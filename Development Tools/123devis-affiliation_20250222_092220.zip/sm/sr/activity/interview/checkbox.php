<?php
	class sm_sr_activity_interview_checkbox extends sm_formlib_checkbox {
				
	}