<?php
	class sm_sr_activity_interview_select extends sm_formlib_select {
				
	}