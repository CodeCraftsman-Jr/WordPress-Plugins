<?php
	class sm_sr_activity_interview_hidden extends sm_formlib_hidden {
				
	}