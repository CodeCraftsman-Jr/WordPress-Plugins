<?php
	class sm_sr_activity_interview_radio extends sm_formlib_radio {
				
	}