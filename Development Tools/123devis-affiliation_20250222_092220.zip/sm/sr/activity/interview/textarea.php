<?php
	class sm_sr_activity_interview_textarea extends sm_formlib_textarea {
				
	}