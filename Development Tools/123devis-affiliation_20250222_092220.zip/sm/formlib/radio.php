<?php 
	class sm_formlib_radio extends sm_formlib_list {
		protected $form_type = "radio";		
	}