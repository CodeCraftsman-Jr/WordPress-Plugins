<?php 
	class sm_formlib_checkbox extends sm_formlib_list {
		protected $form_type = "checkbox";		
	}