<?php
	class sm_exception_httperror extends sm_exception_general {
		
	}