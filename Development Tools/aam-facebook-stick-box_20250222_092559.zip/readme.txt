=== VainCode Facebook Stick Box ===

Contributors: Md. Abdullah Al Mahim
Donate link: http://fb.com/a.a.mahim
Tags: widget, plugin, sidebar, facebook, facebook fan page, fb fanpage, facebook stickey box, facebook fanpage wordpress plugin, facebook stickey wordpress plugin
Requires at least: 3.0
Tested up to: 3.8.1
Stable tag: 1.15
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A Fixed Stick Box For Facebook Fan Page with awesome jquery. 

== Description ==

- VainCode Facebook Stick Box is a simple facebook fan page plugin for wordpress. after install this plugin a facebook logo will be apper to right side of website, when visitor mosue move of the logo then a box will be show which have contain a facebook fan page, visitor can like facebook page from the website.

- After install this plugin a new menu added into admin panel named AAM Fb Box. Where you can change/set your facebook fan page url.  

- Here is Live Demo: http://demo.vaincode.com/fb-stick-box

== Installation ==

- Install from WordPress admin panel >> Plugins >> Add new plugin >> Search for `VainCode Facebook Stick Box' plugin. After you install, activate the plug-in. 

- After Successfully Install You can See A New Menu Named AAM FB Box. From Where you can set/change Facebook Fan page URL. 

== Frequently Asked Questions ==
= Can I use my existing WordPress theme? =

Of course! its works with nearly every WordPress theme.

== Screenshots ==
1. Take a Look.

== Support ==

http://support.vaincode.com/

== Changelog ==

== Upgrade Notice == 

1.01

[Minor Bug Fixed]