=== AA Audio Player ===
Contributors: aaextention
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ashik685%40gmail%2ecom&lc=US&item_name=Donate%20AA%20Extension%20%21&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: aaextension, player , mp3 , music player, cross browser player. 
Requires at least:3.0
Tested up to:4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a cross browser supported audio player with playlist and shortcode enriched. 

==Description==
This plugin is created for using audio's to your website.

<h2> How to use </h2>

<h5>To add the music player</h5>

Here is the shortcode for you <strong>[aplayer src='defealt mp3 src']</strong>

<h5>To build a playlist :</h5>

<strong>[startaap]</strong>

<h5>To Add music to playlist :</h5>

<strong>[addpl src='http://.../example.mp3' name='Example Song 1']<br />
[addpl src='http://.../example2.mp3' name='Example Song 2']<br /></strong>

<h5>End of a playlist :</h5>

<strong>[stopaap]</strong>



<strong>An example code </strong><br />

Player <br />

[aplayer src='http://.../example.mp3']<br />

Playlist <br />
[startaap]<br />
[addpl src='http://.../example.mp3' name='Example Song 1']<br />
[addpl src='http://.../example2.mp3' name='Example Song 2']<br />
[stopaap]<br />


<strong>Version </strong><br />

1.0.0


== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>AA Audio Player</strong>" activate it.<br />

<br />

== Screenshots ==

1. screenshot-1


