=== A Better Planet ===
Contributors: themefurnace
Tags: wordpress, news, dashboard, widget
Requires at least: 3.2
Tested up to: 3.6
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

A Better Planet is a widget for your dashboard which will show up to date news, tutorials and resources from over 30 contributing sites.
For more information about the project visit the official site: http://abetterplanetwp.com

You may also follow the feed via RSS : http://abetterplanetwp.com/masterfeed

And on Twitter : https://twitter.com/abetterplanetwp

If you would like to submit your site, please do so at WPlift http://wplift.com/contact

Thanks to WPtips for the code for the widget : http://wpti.ps/functions/make-latest-news-dashboard-widget

== Installation ==

1. Place the 'A-Better-Planet' folder in your '/wp-content/plugins/' directory.
2. Activate A Better Planet
3. Visit your dashboard and you will see the widget, just drag it to the desired position.

== Changelog ==
