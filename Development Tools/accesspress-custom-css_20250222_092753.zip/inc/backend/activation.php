<?php
defined('ABSPATH') or die('No script kiddies please!');
$apccss_settings = array();
$apccss_settings['css'] = '';
update_option( APCCSS_SETTINGS, $apccss_settings);
?>