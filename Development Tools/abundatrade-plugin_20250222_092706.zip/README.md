AbundaTrade Wordpress Plugin
======

Allows calculating the value of books, cds, and dvds.
