=== Aladdin ===
Contributors: tsiger
Tags: launcher, dashboard, quick launcher, keyboard launcher, quick dashboard launcher
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Aladdin is a keyboard quick launcher for your WordPress Admin Dashboard. 

== Description ==
If you are into quick launchers, you\'ll just love Aladdin. Your whole WordPress Dashboard menu accessible through your keyboard. 

Usage:
1. Install and activate the plugin
2. Press the Shift key twice. 
3. Start typing.
4. Select your option and press Enter.

Nice, eh?

== Installation ==
Just install and active. The launcher will show up by pressing the Shift key twice.

== Screenshots ==
1. Just start typing and the first available option will be selected by default.
2. You can navigate to other options with the keyboard arrow keys.
3. For unique options, you don\'t have to type the whole term. Just type a few characters, press enter and you will be redirected to this option.

== Changelog ==
1.0
Initial release.