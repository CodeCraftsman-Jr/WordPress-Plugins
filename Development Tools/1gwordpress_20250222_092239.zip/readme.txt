=== 1gWordpress ===
Contributors: 1g1g.info
Tags: 1g1g, music, player, wordpress
Requires at least: 2.5
Tested up to: 3.0.1
Stable Tag: /trunk

Change Name to 1g-music-share, please search it.（更换名字为1g-music-share，请更换。）

== Description ==

Change Name to 1g-music-share, please search it.
更换名字为1g-music-share，请更换。
http://www.wordpress.org/extend/plugins/1g-music-share/