=== Plugin Name ===
Contributors: markwheeler
Tags: audio, mp3, music, sound, preview, player, flash, post
Requires at least: 2.0.2
Tested up to: 2.5
Stable tag: 1.4

1 Bit Audio Player is a simple Flash MP3 player with automatic JavaScript insertion. It acts as an in-page preview for linked audio files.

== Description ==

1 Bit Audio Player is a very simple and lightweight Adobe Flash MP3 player with automatic JavaScript insertion. It's main purpose is to act as a quick in-page preview for audio files you link to from your blog.

Once installed as a WordPress plugin, small audio players will than automatically appear next to any MP3s you link to.

== Installation ==

To install, simple extract the '1bit' folder into your 'wp-content/plugins/' directory. Once extracted, you must activate the plugin within the WordPress Site Admin 'Plugins' section. The 1 Bit Audio Player options will then appear within 'Settings'.

You should make sure your MP3 links are always to absolute paths.

== Further Information ==

More information, the latest updates and non-WordPress versions of 1 Bit can be found at
http://1bit.markwheeler.net