=== 3b Meteo ===
Contributors: andreapernici
Tags: meteo, meteo italia, previsioni del tempo, meteo sul sito, previsioni meteo, 3b meteo
Requires at least: 2.6
Tested up to: 4.0
stable tag: 1.0.8

Permette di aggiungere i widget meteo per le previsioni del tempo sul tuo sito in vari formati.


== Description ==
Permette di aggiungere i widget meteo per le previsioni del tempo sul tuo sito in vari formati. I widget sono personalizzabili nei colori e possono essere inseriti nei post, nelle pagine e nelle sidebar.

Maggiori informazioni:

* Piu' informazioni sul [Plugin 3b Meteo](http://www.andreapernici.com/wordpress/3bmeteo/), dove e' possibile vedere l'evoluzione del plugin e lo sviluppo.
* Dati [meteo italia](http://www.3bmeteo.com/) forniti da 3b Meteo.

**Changelog**

= 1.0.8 =
* WP 4 compatibility check

= 1.0.7 =
* Corretto piccolo bug iframe

= 1.0.6 =
* Corretto Bug iframe pannello admin

= 1.0.5 =
* Corretto Bug e testato su 3.1

= 1.0.4 =
* Corretto Bug URL su widget regioni

= 1.0.3 = 
* Corretto Bug su widget 1

= 1.0.2 = 
* Corretto Bug su altezza e larghezza widget

= 1.0.1 = 
* Bug fix

= 1.0.0 = 
* Shortcodes e Widget
* Localita' Compatti 1 giorno
* Localita' Compatti 6 giorno
* Localita' Compatti 7 giorno
* Localita' Dati in Diretta
* Tutte le Localita'
* Localita' estese 7 giorni
* Localita' estese orario
* Regionali compatto
* Regionali 7 giorni
* Localita' Marine 1 giorno
* Localita' Marine 7 giorno
* Regionali Marine 7 giorni
* Neve 1 giorno
* Neve 7 giorni


== Installazione ==

Download, Aggiornamento, Installazione:

**Aggiornamento**

1. Automaticamente dal pannello wordpress
2. Inviando i file sovrascrivendo i precedenti

**Installazione**

1. Decomprimere il file `3bmeteo.zip`. 
2. Inviare la cartella `3bmeteo` (non solo i file in essa) nella cartella `wp-contents/plugins`.

**Attivazione**

1. Nel pannello di amministrazione WordPress andare nella pagina dei Plugin
2. Attivare 3b Meteo plugin e apparir� una sottopagina nel menu impostazioni oltre ad un widget nella sezioni Widget.

Se trovate dei bug o avete qualche idea, scriveteci.

**Utenti Avanzati**

Per un uso avanzato del plugin potete visitare la pagina del [plugin 3bmeteo](http://www.andreapernici.com/wordpress/3bmeteo/) sul sito di [Andrea](http://www.andreapernici.com/)
