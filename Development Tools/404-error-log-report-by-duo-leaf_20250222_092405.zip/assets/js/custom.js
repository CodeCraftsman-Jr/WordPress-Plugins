jQuery(function () {
  jQuery('[data-toggle="tooltip"]').tooltip();
});