<?php

class dl_elr_Log {

    /**
     * Properties
     */
    public $id = 0;
    public $url = '';
    public $date = '';
    public $useragent = '';
    
}

