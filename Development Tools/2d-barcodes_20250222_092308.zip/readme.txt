=== 2D Barcodes ===
Contributors: Christian Doerfel
Tags: tags, images, post
Requires at least: 1.5.2
Tested up to: 2.6.1
Stable tag: 1.0.1

The Wordpress Plugin 2D Barcodes creates automatically a 2D-Barcode to every post you have produced.



== Description ==
The Wordpress Plugin 2D Barcodes creates automatically a 2D-Barcode to every post you have produced.
It will use the TagSOLUTE (http://www.tagsolute.de) API to create the 2D Barcodes.
All you need is a DevKey or an API Key which can be created at http://www.tagsolute.de/profil

Now it is very easy to see your Wordpress Blog on a mobile device. Just scan the code with your mobile phone, an view the post on your mobile device.
In each post you can set a <!--no2dbarcode--> Code and the 2D Barcode picture will not be displayed in this post.
Have fun!
If you are browsing the Wordpress Blog with a mobile device, the 2D Barcodes will not appear.

If you need a mobil Plugin for Wordpress we suggest the plugin "Wordpress PDA & iPhone". http://wordpress.org/extend/plugins/wp-pda/

== Installation ==

To do a new installation of the plugin, please follow these steps

1. Download the 2d-barcodes.zip file to your local machine.
2. Unzip the file 
3. Upload `2d-barcodes` folder to the `/wp-content/plugins/` directory
4. Activate the plugin through the 'Plugins' menu in WordPress
5. Register at http://www.tagsolute.de/profil to get a DevKey (Api Key)
6. Login and get the Devkey in the Main Menu under: Tagserver->Deveky
6. Wordpress Administration: Enter the 2D Barcode Menu, under the Plugins Menu
7. Insert the DevKey in the appropriate field

If you have already installed the plugin

1. De-activate the plugin
2. Delete the old `barcodes` directory in `/wp-content/plugins/`
2. Make a fresh install as above described


== Screenshots ==
1. Administration Interface

