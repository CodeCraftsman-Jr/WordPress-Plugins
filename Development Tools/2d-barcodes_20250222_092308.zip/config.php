<?php

	define("TAGSOLUTE_API_URL", "http://www.tagsolute.de/cgi-bin/api.cgi");

?>