=== Accessibility Language ===
Contributors: Hailstorm
Tags: accessibility, lang, language, wcag
Requires at least: 3.0
Tested up to: 3.2
Stable tag: 1.0

Add language-tags via TinyMCE to comply with the Web Content Accessibility Guidelines.

== Description ==

WCAG 1.0 Guideline 4: Clarify natural language usage. Use markup that facilitates pronunciation or interpretation of abbreviated or foreign text.

== Installation ==

1. Unpack and upload the folder to the /wp-content/plugins/ directory of your WordPress installation.
2. Activate the plugin through the 'Plugins' menu in WordPress