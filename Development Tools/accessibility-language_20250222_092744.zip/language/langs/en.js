tinyMCE.addI18n('en.accessibility-language',{
button:"Language",
remove:"Remove",
label_lang:"HTML Language",
label_xmllang:"XHTML Language",
title:"Change Language"
});