=== AB Last Viewed ===
Contributors: endrix.develop
Tags: posts, chronology
Donate link: http://abidubi.altervista.org/ab-last-viewed
Requires at least: 3.8.1
Tested up to: 3.8.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Widget showing last five posts read.

== Description ==
This plugin adds a widget to display the last five posts user read.
Supports i18n.

== Installation ==
1. Upload plugin to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Place the widget from the "Widget" panel back-end.

== Frequently Asked Questions ==
= Can I change the number of post listed? =
Yes, but you must hack the code in this version.

== Screenshots ==
1. Appereance in the right side-bar of Twentyfourteen theme

== Changelog ==
= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.1 =
This version is the initial release.
