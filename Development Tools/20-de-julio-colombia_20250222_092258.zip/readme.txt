=== 20 de Julio Colombia ===
Contributors: Jodacame (Jose Daniel Canchila)
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=10644953
Tags: independencia, 20 de Julio, julio, colombia, pasion
Requires at least: 1.0
Tested up to: 3.0
Stable tag: trunk


== Description ==
20 de Julio día de la Independencia de Colombia, agrega la bandera de nuestro país.


== Installation ==

- Sube y descomprime el plugin en tu carpeta wp-content/plugins/ 
- Activa el plugin en el panel de control opcion Plugins > 20 de Julio Colombia
-- Agrega el widget desde Apariencia > Widgets 

== Screenshots ==
DEMO
`http://nexxuz.com`


== Changelog ==

= 0.1 =
Lanzamiento inicial.






