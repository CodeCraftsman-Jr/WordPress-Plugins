<?php
/**
 * Generates Confing File for 360deg product rotation based on images in given path
 */

include_once "Rotate_Tool.php";
Rotate_Tool::generate_config_file();

