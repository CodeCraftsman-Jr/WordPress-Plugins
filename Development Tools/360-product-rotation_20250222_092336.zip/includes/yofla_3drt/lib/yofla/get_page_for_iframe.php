<?php

include_once "Rotate_Tool.php";
Rotate_Tool::serve_page_for_iframe();


