/**
 * Code to initialize the nivo-lightbox-enabled a href links
 *
 */

if(jQuery){
	jQuery(document).ready(function(){
		jQuery('a.yofla_360_popup').nivoLightbox();
	});
}
