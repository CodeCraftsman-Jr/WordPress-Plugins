=== Plugin Name ===
Contributors: Asif Ahmmad 
Donate link: 
Tags: scroll to top, scroll up
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will automaticaly add a scroll up on bottom right.

== Description ==

This plugin will automaticaly add a scroll up on bottom right.

Features
1.Unlimited icon color
2.Unlimited background color

== Installation ==

1. Install as a regular WordPress plugin
2. You will see a scroll up on bottom right when you are scrolling. 

== Frequently Asked Questions ==

1. Ask me any question if you need any help.

== Screenshots ==

1. Scroll up arrow on bottom right.
2. Go to setting page.
3. Set up your icon color and icon background.

== Changelog ==

= 1.0 =
* Initial release

= 1.1 =
* Added Screenshot

