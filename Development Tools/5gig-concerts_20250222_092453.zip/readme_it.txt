installazione

1. aggiungere plugin tags5gig alla cartella:
wp-content/plugins/5gigconcerts

2. consentire l'azione di scrittura chmod 775 nella cratella
wp-content/plugins/5gigconcerts/cache

3. attivare il plugin

4. tra le opzioni del plugin aggiungere api key 5gig.it
http://api.5gig.com/signup

5. se desideri che tra gli eventi si mostrino le googlemaps introduci la api key che fornisce google
http://code.google.com/intl/es-ES/apis/maps/signup.html
