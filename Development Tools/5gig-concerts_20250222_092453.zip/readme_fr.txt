Installation

1.  Poster plugin tags5gig au fichier:
wp-content/plugins/5gigconcerts

2. Autoriser l'acc�s d'�criture chmod 775 au fichier:
wp-content/plugins/5gigconcerts/cache

3. Activer plugin

4. Dans les options du plugin mettre api key 5gig.fr
http://api.5gig.com/signup

5. Si vous voulez que les signup de google maps apparaissent sur l'�v�nement, il faut introduire la api key transmise par google http://code.google.com/intl/es-ES/apis/maps/signup.html
