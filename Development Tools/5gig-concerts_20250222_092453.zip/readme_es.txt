instalacion
1.subir plugin tags5gig a la carpeta:
wp-content/plugins/5gigconcerts

2. dar permisos de escritura chmod 775 a la carpeta:
wp-content/plugins/5gigconcerts/cache

3. activar plugin

4. en las opciones del plugin poner api key nvivo.es
http://api.5gig.com/plans

5. si quieres que en los eventos se muestren mapas de google maps introduce la api key que te facilita google
http://code.google.com/intl/es-ES/apis/maps/signup.html