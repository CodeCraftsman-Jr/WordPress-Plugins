<div class="apsc-boards-tabs" id="apsc-board-how_to_use-settings" style="display:none">
    <div class="apsc-tab-wrapper">
        <p>To display the social profiles with counter, you can either use [aps-counter] <strong>Shortcode</strong> or you can use <strong>AccessPress Social Counter Widget</strong> from Appearance's widget section.</p>
        <p>For the complete documentation please visit:<br/> <a href="https://accesspressthemes.com/documentation/documentation-plugin-instruction-accesspress-social-counter/" target="_blank">https://accesspressthemes.com/documentation/documentation-plugin-instruction-accesspress-social-counter/</a></p>
        <p>To get the individual count, please use below shortcode</p><br /><br />
        [aps-get-count social_media="facebook/twitter/googlePlus/instagram/youtube/soundcloud/dribbble/posts/comments" count_format="default/comma/short"]
        <p><strong>Note</strong>: Use any value separated by "/" . For example [aps-get-count social_media="facebook" count_format="short"]</p>
        
    </div>
</div>