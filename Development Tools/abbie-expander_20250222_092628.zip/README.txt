=== Abbie Expander ===
Contributors: ryan.burnette
Donate link: http://bit.ly/abbie-expander-donate
Tags: bourbon, refills, expander
Requires at least: 4.0
Tested up to: 4.0
Stable tag: 1.0.1
License: Apache2
License URI: http://www.apache.org/licenses/LICENSE-2.0

Abbie Expander is a super simple implementation of Bourbon Refill's Expander in
the form of a WordPress shortcode. Create expanders lickity split.

== Description ==

Abbie Expander is a super simple implementation of Bourbon Refill's Expander in
the form of a WordPress shortcode. Create expanders lickity split.

== Installation ==

1. Upload the `abbie-expander` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How do I create an expander? =

Use a shortcode like this: [abbie_expander id="foo" title="Foo"] Foo text [/abbie_expander]

== Changelog ==

= 1.0.1 =
* Expander should content content, not lorem ipsum text

= 1.0.0 =
* Initial release
