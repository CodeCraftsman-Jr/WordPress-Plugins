<div style="z-index:100; top:95px; right:10px; position:absolute;">
	<iframe id="f2cf7a9ba" 
			name="fe9e0cbe" 
			scrolling="no" 
			style="	border: none; 
					overflow: hidden; 
					height: 133px; 
					width: 450px; 
					left: 0px;" 
			title="Like this content on Facebook." 
			class="fb_ltr" 
			src="http://www.facebook.com/plugins/like.php?api_key=&amp;locale=en_US&amp;sdk=joey&amp;channel_url=http%3A%2F%2Fstatic.ak.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D18%23cb%3Df1e8c6cfa%26origin%3Dhttp%253A%252F%252Fwww-igprev-opensocial.googleusercontent.com%252Ff73d43908%26domain%3Dwww-igprev-opensocial.googleusercontent.com%26relation%3Dparent.parent&amp;href=https%3A%2F%2Fwww.facebook.com%2Fpages%2F40Nuggets%2F160465214075732&amp;node_type=link&amp;width=450&amp;layout=standard&amp;colorscheme=light&amp;show_faces=true&amp;extended_social_context=false">
	</iframe>
</div>

