﻿=== Boilerplate Statement Register ===
Contributors: Teruo Morimoto
Tags: 定型文、挨拶文、fixed phrases、a greeting
Requires at least: 3.3
Tested up to: 4.1.1
Stable tag: 1.0.0
License: GPLv2

You have to register the frequently used words and sentences as boilerplate, it is available in the HTML editor on, easy-to-use plug-in very simple.

== Description ==

You have to register the frequently used words and sentences as boilerplate, it is available in the HTML editor on, easy-to-use plug-in very simple.


== Screenshots ==

1. Clicking this button, open the main windows.
2. Boilerplate statements list is drawing
3. Clicking a statement,it is written to the html editor.
4. Clicking a trash on a statement, it is deleted.
5. Create a new statement. Writing a statement in the textbox, and Clicking the button that is set under the textbox.
6. Create a new statement. Selecting a statement in html editor and Open the main window .
7. Since a selected statement is copied to the textbox, click the  botton for regist.


== Installation ==

1. Upload the entire `fixed-phrases-editor` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Changelog ==

= 1.0.0
first version


