=== VainCode Animate Scroll Wordpress ===

Contributors: Md. Abdullah Al Mahim

Donate link: http://fb.com/a.a.mahim

Tags: widget, plugin, sidebar, scroll to top plugins, back to to, wordpress plugin back to top

Requires at least: 3.0

Tested up to: 3.8.1

Stable tag: 1.15

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will add a scroll to top button with different Animation and speed. 

== Description ==
- VainCode Animate Scroll To Top is a Scroll Plugin for Wordpress. This Plugin will be enable to user back to top of website with a nice scroll animation.

- You can Select Scroll Animation Style, Change Scroll Text, background color, Scroll position etc by using the option of this plugin. In this documentation, we'll cover enough areas of the option panel for you to control the plugin effectively


1. Scroll Section

- Enter The name of section for scroll. you can set any section of your webpage, just put the section class or id name here. (E.G: #main or .wraper) . by default it set as body section for scroll.

2. Display Text

- Enter A Text Which one is display when user scroll Down

3. Animation Speed

- Enter A Value For Scroll Animation, by Default its 2000

4. Scroll Icon

- Select an icon for scroll bar which will be display top of the scroll text

5. Scroll Icon Size

- Select Scroll Icon Size to Display, here is 5 different size, 1x is smallest and 5x is the biggest size.

6.Animation Style

- Here is a list of Scroll Animation. 5 Different type Animation are available you can Select Scroll Animaion Style from this option

7.Scroll Position

- This option for change the position of scroll. by default its position is Bottom Right. You can change the position to Bottom Left from here.

8.Scroll Background Color

- This option for change scroll background color change, you can set any Color from here.

9.Scroll Font Color

- You can change scroll text color from here. any type of color can be select from this option for scroll text.

10.Custom CSS

- This option for custom css. if you want to add some additional CSS code just put here. The ID #aam-scroll-div .you can set your customize css value in this id which will be set on the scroll.

 - After all change Click on The Save Changes for save your setting. 


- Here is Live Demo: http://demo.vaincode.com/animate-scroll-to-top

== Installation ==

- Install from WordPress admin panel >> Plugins >> Add new plugin >> Search for `AAM Animate Scroll Wordpress' plugin. After you install, activate the plug-in. 

- After Successfully Install You can See A New Menu Named AAM Scroll. From Where you can change your settings.  

== Frequently Asked Questions ==
- For more Details Please See: http://market.vaincode.com/product/animate-scroll-wordpress/

== Screenshots ==
1. Main Site Example
2. Admin Panel Setting Page

== Support ==
http://support.vaincode.com/

== Changelog ==

== Upgrade Notice == 

1.01