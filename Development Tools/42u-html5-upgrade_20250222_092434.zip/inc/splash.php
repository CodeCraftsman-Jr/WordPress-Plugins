<div class="wrap">
    <div id="FTU" class="icon32 icon32-posts-42-Umbrellas"></div>
    <h2>42 Umbrellas</h2>
    <p>
    Thank you for choosing 42 Umbrellas WordPress plugins. If you find our plugins useful, please send us a bit of encouragement!
    </p>
    
    <div class="postbox ">
    <div class="inside">
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="RX3CW9PNAD4EA">
        <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
        <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
    </form>
    </div>
    </div>
    <div class="credits">
    <p><a href="http://www.42umbrellas.com/author/rick/" target="_blank">Rick Bush</a> | <a href="http://www.42umbrellas.com/" target="_blank">42 Umbrellas</a></p>
    </div>
</div>