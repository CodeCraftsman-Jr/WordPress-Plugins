=== Development Notice ===

Tags: development, dev, help, tools, tool
Requires at least: 2.8, probably backward compatible with most versions.
Stable tag: 0.2
Tested up to: 2.8
Donate Link: http://www.sambowler.com/

Adds a simple bar at the bottom of the site indicating that you're working on a development version, so you don't accidentally break the live site.

== Description ==

Adds a simple bar at the bottom of the site indicating that you're working on a development version, so you don't accidentally break the live site (as we've all done countless times).

This plugin uses James Padolsey's wonderful [jQuery Pulse](http://enhance.qd-creative.co.uk/demos/pulse/) plugin.

== Installation ==

As easy as pie:

1. Upload folder to 'wp-content/plugins/'
2. Activate the plugin at {your_site_domain}/wp-admin/plugins.php
3. Have yourself a cold one.

== Screenshots ==

1. The bar that will be added to the bottom of your site.