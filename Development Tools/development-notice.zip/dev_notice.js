$(document).ready(function() {
	$('#dev-notice').pulse({
		backgroundColors: ['#FF0000', '#A50000'],
		speed: 5000,
	});
});