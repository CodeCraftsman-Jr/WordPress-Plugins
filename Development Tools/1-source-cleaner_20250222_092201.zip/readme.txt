=== 1 Source Cleaner ===
Contributors: momizibafu
Tags: html, performance
Requires at least: 3.0
Tested up to: 3.3
Stable tag: 1.1.1

Reduce the size of the source code by removing the line blake and white space.

== Description ==

Reduce size of the source code by removing  line blake and white space.;Note: Don't use html tag `<pre>` , please use `<div>` and `<code>` and CSS.Include Escape HTML function,if the tag does not appear,try to re-update the entry.

== Installation ==

1. Upload `1-source-cleaner`folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Required `<?php wp_footer()?>`in your templates

== Screenshots ==

1. 
2. 

== Changelog ==
= 1.1.1 =
* For Google Adsense
= 1.0 =
* Plugin release.Thanks to  Escape HTML Satya Prakash.