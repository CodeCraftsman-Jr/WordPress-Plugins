=== A/B Tests Site Section ===
Contributors: theode
Donate link: http://www.wp-plugin-dev.com/donate
Tags: A/B Testing, Testing, AB, Site, Section
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

You want one specific section of your site sometimes redirected? Thats your plugin.

== Description ==

We created a plugin which is counting requests and in a given interval it replaces one link with another. Then you can test one section of the WordPress page against another. 

== Installation ==

1. Upload 'AB-Test-Site-Sections' folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Log out and log in again and it starts tracking your time.

== Frequently asked questions ==

Where can I get support?
Contact us at http://www.wp-plugin-dev.com/support-contact/ or by Twitter @wpplugindevcom


== Screenshots ==

1. Admin Screen

== Changelog ==

= 0.1 =  Initial release
