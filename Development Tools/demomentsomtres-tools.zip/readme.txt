=== DeMomentSomTres Tools ===
Contributors: marcqueralt
Tags: functions, library, framework
Donate link: http://DeMomentSomTres.com
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: head

== Description ==

DeMomentSomTres is just a function libary used by the most of DeMomentSomTres plugins.

= History & Raison d’être =

Many of our plugins use the same functions. In order to ease maintenance we opted to group all of them under a plugin that is a requirement of many of them.

== Installation ==

This tools plugin can be installed as any other WordPress plugin. 

No configuration required.

= Requirements =

* If mailchimp is used, curl must be installed as MailChimp api by Drew McLellan that requires Curl. Your must have it installed in your server. The plugin itself checks if the curl extension is installed.

== Frequently Asked Questions ==

TBD

== Screenshots ==

TBD

== Changelog ==
= 2.4 =
* date input type included

= 2.3.1 =
* size attribute added to adminHelper_input_array

= 2.2 =
* Administration options disabled

= 2.1 =
* Administration options
* Optional plugins_url filter

= 2.0 =
* Mailchimp functions added
* Catalan translation

= 1.0 =
* Functions adminHelper_esc_attr, adminHelper_input, adminHelper_get_option
* Initial version translation ready