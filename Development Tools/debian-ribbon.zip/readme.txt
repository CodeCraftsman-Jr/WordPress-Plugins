=== Debian ribbon ===
Contributors: zpop
Donate link: http://zeljko.popivoda.com/donacije
Tags: linux, debian, ribbon
Requires at least: 2.6.0
Tested up to: 3.9.2
Stable tag: 0.1
License: GPLv2

Help spread Debian by putting a ribbon on your WordPress site.

== Description ==

Debian ribbon is made to promote Debian.

A Debian ribbon will be put on in the top right corner of your website, linking to the [Debian](http://www.debian.org/) website.

This is a fork of [Stop censorship plugin](http://wordpress.org/plugins/stop-censorship-ribbon/).

In serbian at [Željko Popivoda](http://zeljko.popivoda.com/debian-ribbon-wordpress-plugin) blog plugin page.

My other plugins:

* [Debian sidebar](http://wordpress.org/plugins/debian-sidebar/)
* [Debian sidebar lite](http://wordpress.org/plugins/debian-sidebar-lite/)
* [Ubuntu ribbon](http://wordpress.org/plugins/ubuntu-ribbon/)
* [Ubuntu sidebar](http://wordpress.org/plugins/ubuntu-sidebar/)
* [Ubuntu sidebar lite](http://wordpress.org/plugins/ubuntu-sidebar-lite/)
* [Lubuntu ribbon](http://wordpress.org/plugins/lubuntu-ribbon/)
* [Lubuntu sidebar lite](http://wordpress.org/plugins/lubuntu-sidebar-lite/)


== Installation ==

1. Upload folder `debian-ribbon` in Wordpress plugin directory `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Your done!

== Frequently Asked Questions ==

If you have any questions, ask them on [Željko Popivoda](http://zeljko.popivoda.com/debian-ribbon-wordpress-plugin) blog plugin page.

== Screenshots ==

1. Here's how the ribbon will appear on your website.

== Changelog ==

= 0.1 =
* First version.

== Upgrade Notice ==


