=== AB Background Slideshow ===
Contributors: Aboobacker P Ummer
Donate link: http://wp.aboobacker.com/
Tags: slideshow, background slideshow, AB BG slideshow, AB background slideshow
Requires at least: 4.0
Tested up to: 4.2.1
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A beautiful slideshow on your website background.

== Description ==

This plugin allows you to make your website background a beautiful slideshow.

You can manage the background images from the Wordpress admin panel easily.

== Installation ==

1. Upload `ab-bg-slideshow` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Settings-> AB BG Slideshow, and upload the background images
1. Voila, refresh the site, and see the magic :)

== Frequently Asked Questions ==

= Question =

Answer.

== Screenshots ==

1. AB BG Slideshow admin panel.

== Changelog ==

= 1.0 =
* Initial Release

= 1.1 =
* Fixed critical issue

= 1.2 =
* Fixed minor bug

= 1.3 =
* Fixed minor style issue on admin panel.

Any questions [mail@aboobacker.com](mailto:mail@aboobacker.com "mail@aboobacker.com").
