=== Plugin Name ===
Tags: amazon, drop ship, manager, drop ship, amazon drop ship manager
Requires at least: 4.0
Tested up to: 4.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Amazon DropShip Manager helps drop ship sellers to manager their products more easily. This plugin will help you keep track of quantity and price. It will send you reports for product changes by email.

== Description ==

Features

*   Import amazon products
*   Keep track of price and quantity changes
*   Email notifications

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `2kb-amazon-dropship-manager` folder to the `/wp-content/plugins/` directory
1. Activate 2kb Amazon DropShip Manager plugin through the 'Plugins' menu in WordPress
1. Open 2kb Amazon DropShip Manager from admin menu or go to link YOUR_BLOG.COM/wp-admin/admin.php?page=kbAmzDropShipManager and follow the instructions.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==
= 1.0.0 =
Initial realise version.
