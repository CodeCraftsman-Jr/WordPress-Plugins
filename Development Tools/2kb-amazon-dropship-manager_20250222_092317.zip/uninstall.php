<?php
//if uninstall not called from WordPress exit
if (!defined('WP_UNINSTALL_PLUGIN'))
    exit();

/**
 * This is subplugin so, no need of uninstall.
 */