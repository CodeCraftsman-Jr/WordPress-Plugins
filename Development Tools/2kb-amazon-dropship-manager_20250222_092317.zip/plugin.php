<?php
/**
 * Plugin Name: 2kb Amazon DropShip Manager
 * Plugin URI: http://www.2kblater.com/
 * Description: Amazon DropShip Manager helps drop ship sellers to manage their products more easily. This plugin will help you keep track of quantity and price. It will send you reports for product changes by email.
 * Version: DISCONTINUED
 * Author: 2kblater.com
 * Author URI: http://www.2kblater.com
 * License: GPL2
 */

!defined('ABSPATH') and exit;