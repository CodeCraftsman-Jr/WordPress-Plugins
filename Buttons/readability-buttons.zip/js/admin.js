(function($) {
	$(function() {
		// Place your administration-specific JavaScript here
	});
})(jQuery);