=== My App Button === 
Contributors: g.vieri
Tags: button, simple, simple button
Tested up to: 3.1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

there 3 fields name descripition and button code. name can be blank so the others. In button code put the js code for the button... 


== Description ==

I need of a simple way to insert js button/s to my wordpress sites. So i write this plugin. You have to insert in wp-content/plugin and decompress it. After go in admin mode then enable it and look for widget in your theme. (i use atahualpa theme) . After that you can configure: 
name is about the "area" name i normally leave it blank or use some simple '-' ... 
description is about a brief description of the button
button code: here you can insert the code that show the button 


=== warning ===
i had tested only on 3.1.4 
use the plugin can make you bald and other terrible side effect. 
Really: for me it is alpha code, use at your own risk. 

