=== Frontier Set Featured ===
Contributors: finnj
Donate link: 
Tags: Featured Image, Featured, Thumbnail, Frontier, Frontier Post  
Requires at least: 3.4.0
Tested up to: 4.2
Stable tag: 1.0.6
License: GPL v3 or later
 
Frontier Set Featured will set featured image from images in the post if no featured image is set by the user. 
  
== Description ==

Frontier Set Featured will set featured image from images in the post if no featured image is set by the user.

= Main Features =
* If no Featured Images is set on save, the plugin will:
 * Select the first image that is uploaded to the post, and set it as Featured Image
 * If still no Featured Image, select the first image from the post content, and set it as Featured Image
* The will work both from admin interface & frontend.

Note: Only images from the media library can be used as featured images (as per Wordpress standard).
 
Related plugins: [Frontier Post](http://wordpress.org/plugins/frontier-post/) , [Frontier Buttons](http://wordpress.org/plugins/frontier-buttons/) 
 
== Installation ==

1. Upload the plugin to the `/wp-content/plugins/`  directory or install it from plugin install on your site
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

None

== Screenshots ==

none - Plugin works on activation and has no user interface.

== Changelog ==

= 1.0.6 =
* Tested up to: 4.1.1.

= 1.0.5 =
* Tested and works with Wordpres version 4.1

= 1.0.4 =
* Tested with 4.0.1

= 1.0.1 =
* Updated Readme

= 1.0.0 =
* Initial release


== Upgrade Notice ==
None