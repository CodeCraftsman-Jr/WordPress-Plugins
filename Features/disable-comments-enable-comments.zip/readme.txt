=== Disable Comments Enable Comments ===
Contributors: seo101
Donate link: 
Tags: comments, disable comments, enable comments, pingbacks, disable pingbacks, enable pingbacks
Requires at least: 3.1
Tested up to: 4.1
Stable tag: 1.02
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily disable or enable comments for all posts and pages on your blog.

== Description ==

Easily disable or enable comments for all posts and pages on your blog with the DISABLE COMMENTS ENABLE COMMENTS plugin.

Besides the ability to disable all comments or enable all comments you can also disable all pingbacks and enable all pingbacks. The settings screen of the plugin is easy to figure out and with a click of the mouse your action is processed.

More information: <a href="http://www.seo101.net/enable-comments-disable-comments/">http://www.seo101.net/enable-comments-disable-comments/</a>

Features: Comments, Disable all Comments, Enable all Comments, Disable all Pingbacks, Enable all Pingbacks, Bulk comment changes, Bulk Comment Updates, Bulk updates, Simple No Comments

== Installation ==

1. Upload the zip file to the `/wp-content/plugins/` directory and unzip
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the plugin from the settings menu

== Frequently asked questions ==

None yet

== Screenshots ==

1. 
2. 
3. 
4. 

== Changelog ==
1.01 Update readme
1.00 Release


== Upgrade notice ==



== Arbitrary section 1 ==
