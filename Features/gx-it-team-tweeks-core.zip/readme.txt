This plugin was created by Eucimar Raposo for getgx.com. 
We develop websites in wordpress and for every website we do we install this plugin, we now have over 50 websites.
It is still in development stage.
As this moment, it hides the wordpress version and it also changes the login page.
