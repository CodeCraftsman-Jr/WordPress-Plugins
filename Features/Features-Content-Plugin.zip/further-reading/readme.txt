=== Further Reading ===
Contributors: artplastika
Tags: further reading, related content, related posts, similar posts, read further, read next, next post, navigation, references, featured, bounce rate
Donate link: http://artplastika.github.io/wp-further-reading/index.html
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 15.1.29
License: MIT
License URI: http://opensource.org/licenses/MIT

Display related content for further reading in most common ways to lower bounce rate of your site or blog

== Description ==

Supported behaviour:

* Slide box with custom HTML content
* *Slide box with similar post (in development)*
* *Slide box with specified post (in development)*
* *Slide boxes with previous and next posts (in development)*
* *Links to previous and next posts (in development)*
* *List of specified posts at the end  (in development)*
* *List of similar posts at the end  (in development)*
* *Widget with similar posts (in development)*

Future plans: 

* UTM link tagging
* Live preview on settings page
* Localization


== Installation ==
1. Upload 'plugin-name.php' to the '/wp-content/plugins/' directory,
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 15.1.29 = 
* Slide box with custom HTML content