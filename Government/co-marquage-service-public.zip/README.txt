=== Co-Marquage Service-public.fr by emendo.fr ===
Contributors: emendo.fr
Donate link: http://www.emendo.fr/
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: comarquage, co-marquage, service public, service,public, gov, emendo, demarche, guide
Requires at least: 3.9
Tested up to: 4.2
Stable tag : 0.3.7

Link to french gov service : service-public.fr.

== Description ==
Link to a french gov service : service-public.fr
This plugin copy, update and display comarquage guide in your wordpress website.
It display with a shortcode all the administrative information (How to do a ID Card, ...) in France.
This plugin is interesting for french city website. Given informations to citizens.


== Installation ==

Explications en français ;)

- Copiez ce plugin dans votre dossier de plugins (wp-content/plugins/)
- Activez le depuis l'interface d'administration de wordpress : sous le menu "Extensions"
- Aller ensuite dans les réglages pour préciser les informations sur votre commune (Département, code INSEE, ...)
- Il vous faut ensuite ajouter le shortcode dans la page qui affichera le guide. ex : [comarquage category="part"]. (ou pro ou asso)
Pour des questions graphique et de visibilité, nous conseillons l'affichage dans un template de page sans colonne latérale.

Les coordonnées et horaires d'ouverture de votre commune sont issus de l'annuaire : http://lannuaire.service-public.fr/
Si les informations ne sont pas correctes, allez sur la page correspondant à votre commune puis cliquer sur le lien "Faire une remarque sur cette page" en bas de la page de l'annuaire.


Un BUG ?
Pour signaler un bug, rien de plus simple :
https://bitbucket.org/emendo-fr/emendo-comarquage/issues?status=new&status=open


== Changelog ==

= 0.3.7 =
First release publish on wordpress repository
We yet use this plugins.


== Screenshots ==

1. Sommaire d’accueil
2. Exemple d’une page de guide pour une démarche
3. Exemple de localisation
4. Page de réglages dans l'admin
