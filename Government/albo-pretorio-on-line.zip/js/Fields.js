jQuery(document).ready(function($){
    $('#color').wpColorPicker();
	$('#colorp').wpColorPicker();
    $('#colord').wpColorPicker();
	$( "#Calendario1" ).datepicker();
	$( "#Calendario2" ).datepicker();
	$( "#Calendario3" ).datepicker();
});