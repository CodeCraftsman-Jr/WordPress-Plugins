=== Plugin Name ===
Contributors: lonalore
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=PQYDBAMQ3D2UG
Tags: website, screenshot, full-page screenshot
Requires at least: 3.5
Tested up to: 4.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin creates a website screenshot using only a website URL and save into your own wordpress media library.

== Description ==

This plugin creates a website screenshot using only a website URL and save into your own wordpress media library.

After creating the image, wordpress will prompt you either to "insert into post" or "change attributes" just like after you upload an image. Renaming is available.

The plugin requires a free or paid account from CaptureMyPage (http://capturemypage.com), who is the service provider.

== Installation ==

1. Simpy install from your wordpress plugin page and activate it.
2. Get your Service Key by signing up at: http://capturemypage.com
3. Set your Service Key for plugin at the "CMP Settings" page on admin area.
4. Open your media library and select "Website Screenshot" menu option.

== Screenshots ==

1. Just put in the URL and click "Create Screenshot".
2. The image is saved to your media library. You may customize the image and insert to your post.

== Changelog ==

= 1.0.0 =
* Initial release.
