=== distance-avtodispetcher.ru ===
Contributors: iGuk 
Tags: widget, route, routing, geo, map, transportation, logistics
Requires at least: 3.0
Tested up to: 3.8
Stable tag: trunk

The plugin is designed for laying road route between the cities of Russia and major European cities. Russian language only.


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

There are two work modes:

Simple mode (this is default): calculation results are shown on Avtodispetcher.Ru after form submit. Field's autocomplete does not work.

Advanced mode: calculation results are displayed on your site. Field's autocomplete does work. Stylized link "powered by" is displayed in widget sidebar.

You can switch this modes on Settings > Distance Calculator Settings page.