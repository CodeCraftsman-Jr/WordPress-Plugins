=== Top Commenters Widget For Disqus ===
Plugin URI: http://www.trickspanda.com
Description: Add a Disqus top commenters widget to your WordPress blog's sidebar.
Version: 1.2
Requires at least: 2.5
Tested up to: 4.1
Contributors: hardeepasrani
Author URI: http://www.hardeepasrani.com
Tags: disqus, comments, widgets, recent comments
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Add Disqus top commenters widget to your WordPress with our user-friendly plugin. Just install the plugin to your WordPress and visit Widget settings in Appearance menu to add our widget to your blog.

== Installation ==

1. Upload the plugin to your 'wp-content/plugins' directory, or download and install automatically through your admin panel.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= How you created this? =

We used Disqus' original top commenters script for the widget.

== Screenshots ==

1. Disqus Top Commenters Widget On Back-end.

== Changelog ==

= 1.1 =
* Added an option to change widget title.

= 1.2 =
* Fixed all the debugging errors.