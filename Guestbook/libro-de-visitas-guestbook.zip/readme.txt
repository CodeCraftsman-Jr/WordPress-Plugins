=== LIBRO DE VISITAS - GUESTBOOK ===
Contributors: jarim
Donate link: http://www.sos-childrensvillages.org/
Tags: libro de visitas, visitas, guestbook, guest book, comments, feedback, antispam, review
Requires at least: ?
Tested up to: 4.1
Stable tag: 1.2
License: GPLv2
LIBRO DE VISITAS- GUESTBOOK is the WordPress  guestbook you've just been looking for. Beautiful, responsive,easy and multi-language.


== Description ==
<a href="http://www.jarimos.dk/websjarim/libro-de-visitas/libro-de-visitas" >For live example click here!!!</a><br><br>
<a href="http://www.sos-childrensvillages.org/" >Donate and help children her!!!</a><br><br>
LIBRO DE VISITAS- GUESTBOOK is the WordPress guestbook you've just been looking for. Beautiful, responsive,easy and multi-language.
Creates its own table for messages so you can easily control all your messages.



Current features include:

* Easy to use guestbook frontend with a simple form for visitors of your website.
* Responsive.
* You can change the labels (Message,name,button-send) to any language you like from admin menu.
* Simple and clean admin interface that integrates seamlessly into WordPress admin.
* Easy uninstall not harming your wordpress installation in anyway.

... and all that integrated in the stylish WordPress look.


= Languages =

* ALL


You can change the labels of the form (Message, name, button-send) to any language from the admin menu


== Installation ==

= Installation =

* Install the plugin through the admin page "Plugins".
* Alternatively, unpack and upload the contents of the zipfile to your '/wp-content/plugins/' directory.
* Activate the plugin through the 'Plugins' menu in WordPress.
* A new page should be automatically created in your main menu with the name Libro de visitas


= Updating from an old version =



= Licence =

The plugin itself is released under the GNU General Public License; 


= API, add an entry =


== Frequently Asked Questions ==

= Where is the plugin in the admin menu? =

Is in MENU SETTINGS-> LIBRO DE VISITAS<br>
and also in<br>
MENU PLUGINS->LIBRO DE VISITAS(where you see all plugins)->SETTINGS<br> (a small menu under the name of the plugin, just beside Activate and Deactivate).

== Screenshots ==

1. Frontend view of the list of guestbook entries.
4. Settings panel, showing the labels you can change.



== Changelog ==

= 1.2 =
* 2015-04-09
* Release stable and updated version 1.2 to the public.
* Go on holiday, have a few beers, and watch the girls do the hoolahoop().

= 1.1 =
* 2015-04-09
* Release stable and updated version 1.1 to the public.
* Go on holiday, have a few beers, and watch the girls do the hoolahoop().

= 1.0 =
* 2015-04-01
* Release stable and updated version 1.0 to the public.
* Go on holiday, have a few beers, and watch the girls do the hoolahoop().

== Upgrade Notice ==

= 1.2 =
This version is better.  Recommended Upgrade :).

= 1.1 =
This version is better.  Recommended Upgrade :).
