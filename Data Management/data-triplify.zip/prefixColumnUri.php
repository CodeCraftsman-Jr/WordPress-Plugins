<?php
	class dt_prefixColumnUri{
		
		public $prefix = null;
		public $column = null;
		public $uri = null;
		public $fullProperty = null;

	}
?>
