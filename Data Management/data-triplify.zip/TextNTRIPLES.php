<?php

include_once( "arc2/ARC2.php" );
require_once( "functions.php" );

class dt_TextNTRIPLES {
	
	function __construct($posts) {
			
		echo "format not supported yet.";
	}
	
}

?>
