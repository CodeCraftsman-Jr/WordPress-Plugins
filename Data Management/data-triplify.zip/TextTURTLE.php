<?php

include_once( "arc2/ARC2.php" );
require_once( "functions.php" );

class dt_TextTURTLE {
	
	function __construct($posts) {
		
		/*$parser = ARC2::getTurtleParser();
			$JSON = json_encode($posts);
			$parser->parse($JSON);
			print_r($parser);*/
			
		echo "format not suported yet.";
	}
	
}

?>
