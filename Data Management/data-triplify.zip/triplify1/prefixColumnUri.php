<?php
	class prefixColumnUri{
		
		public $prefix = null;
		public $column = null;
		public $uri = null;
		
		/*function __construct($a, $b, $c){
			$this -> $prefix = $a;
			$this -> $column = $b;
			$this -> $uri = $c;
		}*/

	}
?>
