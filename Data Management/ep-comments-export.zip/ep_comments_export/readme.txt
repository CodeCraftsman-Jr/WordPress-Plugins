=== EP Comments Export ===
Contributors: Earth People, darkwhispering, wineblade
Tags: comments, commentmeta, export, migrate, csv, csv export
Requires at least: 3.3.0
Tested up to: 3.4.1
Stable tag: 0.1.0

Simple plugin to export comments and the comment meta data from your blog to a csv file that can be save on your local computer.

== Description ==

The plugin add an extra table columns for posts, pages and custom posts types with an clickable icon for download and export a posts/pages comments and the comments meta data. The data will be saved in an csv file for easy use in other applications. The csv file will also be saved on the server at `uploads/epce/`

This is a first release and there are more functionality planed to be added in the future.

== Installation ==

1. Upload the zipped file to yoursite/wp-content/plugins
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 0.1.0 =
* Initial release