/**
 * general settings page accordion
 */
jQuery(document).ready(function($) {
    $("#settings_accordion").accordion({
        heightStyle: "content"
    });
});