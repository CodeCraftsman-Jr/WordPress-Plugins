<h4>Where can I configure the plugin?</h4>
<p>Open the Forums menu, and you will see Tools item there. This will open a panel with global plugin settings.</p>

<h4>Will this plugin work with standalone bbPress instalation?</h4>
<p>No. This plugin requires the plugin versions of bbPress 2.0 or higher.</p>

<h4>Will this plugin work with bbPress that is part of BuddyPress plugin?</h4>
<p>No. Plugin requires bbPress 2.0 or higher plugin.</p>
