=== Simple FAQ ===
Contributors: slav123
Donate link: http://www.spidersoft.com.au/2010/simple-faq/
Tags: faq, question, answer, simple
Requires at least: 2.7
Tested up to: 3.2.1
Stable tag: 1.0

Simple FAQ gives you ability to create very simple FAQ on your site (questions and answers)

== Description ==

Simple FAQ gives you ability to create very simple FAQ on your site (questions and answers). You can add question and answer using Wordpress panel.

== Installation ==

1. Unzip the package and upload the Simple FAQ directory into your wp-content/plugins directory of your WordPress installation.
2. Activate the plugin at the plugin from plugins page.
3. Put the short code `[display_faq]` in your page.

== Frequently Asked Questions ==

= How I can change styles of it? =

Currently Simple FAQ uses only two classes: `simple-faq` for `<ol>` element and `sf-answer` for `<span>` element with answer.

= Why plugin is so simple? =

Because that is general idea. If you want more functions - put post on forum and I'll consider code improvement.

= Can you extend this plugin? =

If you have any ideas - just let me know.

== Screenshots ==

1. admin panel
2. post editing

== Changelog ==

= future =
* pagination,
* authors,
* sorting

= 1.0 =
* 08/09/2011
* completly redisgned - new look and feel closer to WP 3.2 family
* new option - status (published / draft)
* bulk operations

= 0.6 =
* 19/04/2011
* removed as shortcodes
* extra slashes in quries

= 0.5 =
* 10/02/2010
* small bug fixing (slashes)
* change width of text input
* more columns displayed on admin page

= 0.4 =
* 09/12/2010
* brand change
* possibility to css styles
* more description

= 0.3 =
* 30/08/2010
* wordpress 3.x compatibility
* bug fixing

= 0.2 =
* 20/05/2009
* fixed bug with bad url to icons
* fixed encoding
* updated queries for current_user

= 0.1 =
* 13/05/2009
* first release v 0.1
