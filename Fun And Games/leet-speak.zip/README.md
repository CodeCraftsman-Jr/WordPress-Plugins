# LeetSpeak WordPress Plugin

## Purpose

A semi-useless WordPress plugin that translates targeted portions or the entirety of posts into Leet Speak.

## Usage

Translation of a post's text into leet speak can be accomplished by using one of the following methods.

* With the first approach one can target specific parts of their post and translate them using the [leet] and [/leet] tags.

* The second method allows for the translation of an entire post into leet speak by setting a custom field of leet =  1.

## Website

http://dan.doezema.com/2010/04/leet-speak-plugin/

## License

DDLeetSpeak is released under the New BSD license.
http://dan.doezema.com/licenses/new-bsd/