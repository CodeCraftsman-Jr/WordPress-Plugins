=== Magic 8 ball ===
Contributors: renon
Donate link: http://8ball.com/
Tags: Magic 8 ball
Requires at least: 2.0.2
Tested up to: 2.8.4
Stable tag: trunk

the allmighty Magic 8 ball make your users have fun :)
== Description ==
the allmighty Magic 8 ball make your users have fun :)

there is over 500 responses in the database



== Installation ==

You can use the built in installer and upgrader, or you can install the plugin
manually.

1. Upload `magic8ball.php` to the `/wp-content/plugins/` directory or to `/wp-content/plugins/magic8ball/`
2. Activate the plugin through the 'Plugins' menu in WordPress
1. Place widget `magic 8 ball` to Sidebar and configure it.

1. You can either use the automatic plugin installer or your FTP program to upload it to your /wp-content/plugins/magic8ball/ directory
if streamnewslive is not there just make one
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Configure any options as desired (you dont need to this), and then enable the plugin
1. That's it!

If you have to upgrade manually simply repeat the installation steps and re-enable the plugin.

== Screenshots ==

1. photo of the plugin



== Changelog ==


= 1.0 =
* Start version


