=== Thaana Date ===
Contributors: Fayax
Donate linl: http://www.fayax.net/thaana-date
Tags: date, pages, post
Requires at least: 2.0.0
Stable tag: trunk

== Description ==

This plugin replaces the english format of month and days in Wordpress to Thaana (Maldivian language) format.
This plugin uses Unicode character to display date and month. You are required to use Unicode Thaana font and set the direction to rtl.

== Installation ==

1. Upload the `thaana_date` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
That's it! The plugin will replace the Wordpress date format to Thaana.
