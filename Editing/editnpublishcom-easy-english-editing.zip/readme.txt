=== editnpublish.com Easy English Editing ===

Contributors: Editnpublish

Tags: copy-editing, editing, proofreading, editnpublish, english editing, grammer, spelling, copy-editors, copyeditors, copyediting, editor, editors, ESL editing, proof reading, page, pages, post, posts

Requires at least: 3.6

Tested up to: 4.0



Editnpublish can help all non-native writers write clear and grammatically correct English.



== Description ==

**[Editnpublish.com](http://www.editnpublish.com/)**: Add professional Easy English Editing to your WordPress blog publishing process.



This is a plugin which can help all non-native writers write clear and grammatically correct English. Get easy quote for editing your post by installing the plugin.



== Installation ==

1. Use your FTP-program to upload the enplugin to your wp-content/plugins directory

2. Activate the plugin through the 'Plugins' menu in WordPress

3. Publish your posts and get quote thorugh this plugin after simple registration process.



== Frequently Asked Questions ==

n/a



== Upgrade Notice ==

n/a

 

== Screenshots ==

n/a



== Changelog ==

= 1.0.01 =

* First official release