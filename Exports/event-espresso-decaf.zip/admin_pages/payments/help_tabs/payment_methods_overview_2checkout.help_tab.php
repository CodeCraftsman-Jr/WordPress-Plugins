<h3><?php _e('2Checkout', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>
<h3><?php _e('2Checkout Settings', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>