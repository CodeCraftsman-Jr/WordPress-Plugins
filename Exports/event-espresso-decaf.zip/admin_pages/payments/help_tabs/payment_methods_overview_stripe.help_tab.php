<h3><?php _e('Stripe', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>
<h3><?php _e('Stripe Settings', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>