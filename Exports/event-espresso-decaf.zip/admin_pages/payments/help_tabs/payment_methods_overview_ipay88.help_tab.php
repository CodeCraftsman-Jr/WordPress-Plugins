<h3><?php _e('iPay88', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>
<h3><?php _e('iPay88 Settings', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>