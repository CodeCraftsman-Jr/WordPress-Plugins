<h3><?php _e('Authorize.net SIM', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>
<h3><?php _e('Authorize.net SIM Settings', 'event_espresso'); ?></h3>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>