jQuery(document).ready(function($) {

	$( '.datepicker' ).datepicker({
		defaultDate: "-1m",
		numberOfMonths: 2
	});/**/
});