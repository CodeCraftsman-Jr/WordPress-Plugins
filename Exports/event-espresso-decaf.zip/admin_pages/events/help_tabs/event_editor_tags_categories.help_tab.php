<h3><?php _e('Event Tags', 'event_espresso'); ?></h3>
<p>
<?php _e('You can setup tags for your event. This is optional. To add a tag, enter it into the tag field and click on the Add button.', 'event_espresso'); ?>
</p>
<h3><?php _e('Event Categories', 'event_espresso'); ?></h3>
<p>
<?php _e('You can setup event categories for your event. This is also optional. To add a event category, select one from the tabs or click on the Add New Category link and enter a name for your event category and click on the Add New Category button.', 'event_espresso'); ?>
</p>