<h3><?php _e('Event Categories Views', 'event_espresso'); ?></h3>
<p>
<?php _e('Views allow you to limit what you see in the categories overview table. The following views are available: All. The number in parentheses next to each view represents the number of events that will be displayed with that view.', 'event_espresso'); ?>
</p>
<p>
<ul>
<li>
<strong><?php _e('All', 'event_espresso'); ?></strong><br />
<?php _e('Shows all event categories.', 'event_espresso'); ?>
</li>
</ul>
</p>