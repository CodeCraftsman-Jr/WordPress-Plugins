<h3><?php _e('Event Venue Details', 'event_espresso'); ?></h3>
<p>
<?php _e('A venue is the place or location that is hosting your event. This setting is optional which means that you are not required to select a venue for your event.', 'event_espresso'); ?>
</p>
<p>
<?php echo sprintf(__('Venues can be managed through the %sVenues page%s. This feature is only available in the caffeinated version of Event Espresso.', 'event_espresso'),'<a href="admin.php?page=espresso_venues">','</a>'); ?>
</p>