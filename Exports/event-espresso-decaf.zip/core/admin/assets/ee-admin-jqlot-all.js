/**
 * This file is just a holder file used to group jqplot scripts in one registration so we can call it really easy where needed.
 */