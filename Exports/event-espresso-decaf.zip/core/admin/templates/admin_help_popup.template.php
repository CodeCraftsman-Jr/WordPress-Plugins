<div id="<?php echo $help_popup_id; ?>" class="ee-pop-help" style="display:none">
	<h2><?php echo $help_popup_title ?></h2>
	<p><?php echo $help_popup_content ?></p>
 </div>
<!-- .ee-help-container -->