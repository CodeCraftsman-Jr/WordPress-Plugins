<div id="ee-admin-caf-preview-container">
	<div class="ee-admin-caf-preview-img"><?php echo $preview_img; ?></div>
	<div class="ee-admin-caf-preview-contents">
		
		<div class="ee-caf-preview-text">
			<p><?php echo $preview_text; ?></p>
		</div>
		<div class="ee-caf-preview-action-box">
			<?php echo $preview_action_button; ?>
		</div>
		<div style="clear:both"></div>
	</div>
</div>