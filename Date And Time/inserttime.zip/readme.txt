=== insertTime ===
Contributors: Shereefz
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=N226HQRRTNX3U&lc=US&item_name=insertTime&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: time, date, datetime, short codes, shortcodes, short code, shortcode
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.0
License: MIT
License URI: http://opensource.org/licenses/MIT

A simple wordpress plugin that adds a shorcode [time] tp insert your local time at page loading in a post.

== Description ==

A simple wordpress plugin that adds a shorcode [time] tp insert your local time at page loading in a post, just write [time], [datetime] or [date] in your post after activating this..

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `insertTime.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Just write [time], [datetime] or [date] in your post
1. Enjoy.

== Frequently Asked Questions ==

= Can I change the format ? =

Not currently.

== Screenshots ==

1. A simple usage example

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
Because you want to use the plugin :)