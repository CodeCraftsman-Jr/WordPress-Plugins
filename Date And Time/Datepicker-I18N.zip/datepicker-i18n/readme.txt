=== Datepicker i18n ===
Contributors: dancoulter
Tags: calendar, jquery, javascript, translation, i18n, l10n
Requires at least: 2.6
Tested up to: 2.7
Stable tag: 0.1

Globally translate your jQuery UI Datepicker instances.

== Description ==

Once activated, this plugin will translate every instance of the jQuery UI 
Datepicker plugin on your blog.  It even comes with the latest version of
the jQuery plugin, so that you can add it to pages on your blog.  

This will only work with version of the Datepicker plugin that come with 
jQuery UI versions 1.5 or higher.