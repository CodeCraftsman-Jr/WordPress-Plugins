=== BH FAQ ===
Contributors: masumbd
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=TAXUBBKCANHLA&lc=US&item_name=bograhost&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: getmasum, frequently asked questions, wordpress,wordpress faq, WordPress Plugin, faq, accordion, accordion plugin, jquery accordion, jQuery UI accordion
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will be added Faq Option into your site. Very easy and nice plugin.If you had any problem to use this plugin. Please contact us. Thank you. Have a nice day

== Description ==

This is BH FAQ plugin. It will be enable faq option on your website. Unlimited Colors For Active and Hover options.

== Installation ==

1. Upload `bh-faq` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `[BH-FAQ]` in your page or post

== Frequently asked questions ==

= How i can use it =

Active it and place shortcode.

= Can i use my color =

yes, you can use your desire from under Settings called "BH FAQ Setting".

== Screenshots ==

1. screenshot-1.jpg
1. screenshot-2.jpg
1. screenshot-3.jpg

== Changelog ==

Change color, BH FAQ Settings option and many more. enjoy

== Upgrade notice ==

We have changed colors , active and default images and added BH FAQ Settings . 

== Arbitrary section 1 ==

