<?php
//$post_types = get_post_types( '', 'names' ); 
?>

<div class="wrap t201plugin">
    <h2>
        FAQs - Settings
    </h2>
</div>
