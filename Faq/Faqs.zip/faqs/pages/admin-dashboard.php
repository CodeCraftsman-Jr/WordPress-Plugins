<div class="wrap t201plugin">
	<h2>
		Dashboard
		<a href="<?php print admin_url('admin.php?page=faqs-all-faqs'); ?>" class="add-new-h2">All FAQs</a>
	</h2>
	
	<div class="tbox">
		<div class="tbox-heading">
			<h3>Quick Overview</h3>
			<a href="http://labs.think201.com/faqs" target="_blank" class="pull-right">Need help?</a>
		</div>
		<div class="tbox-body">


		</div>
		<div class="tbox-footer">
			
		</div>
	</div>
</div>