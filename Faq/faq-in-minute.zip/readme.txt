=== Faq in minute ===
Contributors: jitenit
Tags: faq,acoordation,faq questions,faq in wordpress,bootstrap faq,awesome faq
Donate link: https://twitter.com/jitendra_popat
Requires at least: 3.0
Tested up to: 4.2.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plug-in is useful for creating faq in any website with latest design pattern. 
create and display your Faq in Just minute for Free.

== Description ==
FAQ in minute is plugin for displaying your FAQ(frequently asked questions) in website. Active Plugin and create all faq with admin panel. just user our short codes to display faq in website pages or in post. 

use <code>[showallfaq]</code> Or <code>[faq-in-minute]</code> for displaying all FAQ in pages/post.

You can also display Faq with Category for that follow below short codes
[faq-in-minute category ="categoryname"]
for ex if your category name is news then assign news to any faq. and then display news faq on website using [faq-in-minute category="news"] .

Our Main Functionality is Unique Design for FAQ (frequently asked questions) . Best design for faq. Display faq via our plugin and make your website more attractive. 

For any type of query or suggestions you can contact us any time. this 

We also added limit faq functionality in our plugin. 

Display limit faq in your website. using this short code  [faq-in-minute limit="1"]

So overall all usefull short-codes are below for Frequetly Asked questions For Your Wordpress website 

For all faq -  <code>[faq-in-minute]</code>

display faq of test category - <code>[faq-in-minute category="test"]</code>

display latest 3 faq only - <code>[faq-in-minute limit="3"]</code>

display Faq order by ASC and default order is DESC - <code>[faq-in-minute order="ASC"]</code>

display general category faq with order by asc and limit is 3 <code>[faq-in-minute category="general" limit="3" order="ASC"]</code>

display faq of mycategory faqcategory - <code>[faq-in-minute faqcategory="mycategory"]</code>

so for latest version we have added faqcategory . so using this you can create personal faqcategory and display faq from faqcategory wise too.


== Installation ==
This section describes how to install the plugin and get it working.

1. upload zip folder or install it from wordpress directory 
2. Activate the plugin through the \'Plugins\' menu in WordPress
3. after actication of plugin simple use our given short codes to display Faq


== Frequently Asked Questions ==
How to Create FAQ -> 
Simple active plugin. go to admin panel. => faq in minute=> add/edit/delte new Faq

how to dispaly FAQ in website 
=> just use [showallfaq] or <code>[faq-in-minute]</code> to display list of all FAQ. 

is this plugin is free 
=> yes this plugin is totally free. 

Display Faq with category 
category base [showallfaq category="categoryname"] 

Display Faq with limitation 
set faq with limit base. ex if you want to show only 1 faq then [showallfaq limit=\"1\"] 

== Screenshots ==
1. Add Faq From admin panel
2. Display all Faq in website
3. Display Faq with Category wise

== Changelog ==

= 1.3 =
* now admin can give shortcode of faqcategory.
* fix number of faq issue in page and now category and faqcategory both working. 

= 1.2 =
* Now easy to set order of Faq ASC/DESC. Default is DESC.

= 1.1 =
* Fixed js Conflict issue in page.
* Minor updates to Plugins details.

= 1.0 =
initial release 
display all Faq in page/post
faq with category base structure
set limit in faq

== Upgrade Notice ==
Faq with category wise and limit wise
Display Faq with Modern Design 
