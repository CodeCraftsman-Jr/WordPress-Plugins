<div  class="wpscp-sidebar">
<a target="_blank" href="https://wpdeveloper.net"><img src="<?php echo WPSCP_PLUGIN_URL."/images/wpdeveloper-logo-2.png" ?>" /></a>
<a class='wpscp-button2' style="margin-bottom:3px; display:block;" href="https://wpdeveloper.net/go/WPSP-Main" target="_blank">Plugin Homepage &rarr;</a>
<a  class='wpscp-button3'  style="margin-bottom:3px; display:block;" href="https://wpdeveloper.net/go/WPSP-Review" target="_blank">&hearts; &nbsp; Rate This Plugin</a>
<a class='wpscp-button2' style="margin-bottom:3px; display:block;" href="https://wpdeveloper.net/go/WPSP-PDS" target="_blank">Vote For Feature!!</a>
<table class="widefat">
	<thead>
		<tr><th>WPDeveloper's Plugin<th></tr>
	</thead>
	<tbody>
		<td>
		<ul>
		<li><a href="https://wpdeveloper.net/go/TCM" target="_blank">Twitter Cards Meta</a></li>
		<li><a href="https://wpdeveloper.net/go/FSMProDetails" target="_blank">Facebook Secret Meta</a></li>
        <li><a href="https://wpdeveloper.net/go/analytify-home" target="_blank">Analytify - Best Google Analytics</a></li>
		<li><a href="https://wpdeveloper.net/go/WPAR-Pro" target="_blank">WP Author Report</a></li>
		<li><a href="https://wpdeveloper.net/support/" target="_blank">Plugin Support</a></li>
		</ul>	
		</td>
	</tbody>
</table>

<div style="height:10px;"></div>
<table class="widefat">
	<thead>
		<tr><th>Free Email Update<th></tr>
	</thead>
	<tbody>
		<td>
			

			<form action="//WPDeveloper.us10.list-manage.com/subscribe/post?u=a427328bc9fc2657270f66f87&amp;id=97fd2b28ff" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
			<input type="text" class="newsletter-subscription" name="EMAIL" id="mce-EMAIL" value="Enter your email address" onclick="javascript: if(this.value=='Enter your email address') {this.value='';}"/>
			<input type="hidden" value="WPDeveloper" name="uri"/>
			<input type="hidden" name="loc" value="en_US"/>
			<input class="subscribe-button" type="submit" name="subscribe" id="mc-embedded-subscribe" value="Subscribe"/>
			</form>		
		</td>
	</tbody>
</table>
<div style="height:10px;"></div>

<table class="widefat">
	<thead>
		<tr><th>Stay Connected<th></tr>
	</thead>
	<tbody>
		<td>
		<ul class="social-icons">
		<li><a href="https://www.facebook.com/WPDeveloperNet" target="_blank"><img src="<?php echo WPSCP_PLUGIN_URL."/images/fb.png" ?>" alt="Facebook" ></a></li>
		<li><a href="https://twitter.com/WPDevTeam" target="_blank"><img src="<?php echo WPSCP_PLUGIN_URL."/images/twitter.png" ?>" alt="Twitter"></a></li>
		<li><a href="https://www.google.com/+WPDeveloperNet" target="_blank"><img src="<?php echo WPSCP_PLUGIN_URL."/images/google-plus.png" ?>" alt="Google+"></a></li>
		</ul>	
		</td>
	</tbody>
</table>

<div style="height:10px;"></div>
<table class="widefat">
	<thead>
		<tr><th>WPDeveloper.net Feed<th></tr>
	</thead>
	<tbody>
		<td>
			<?php wpdev_dashboard_widget_function();?>	
		</td>
	</tbody>
</table>

</div>
