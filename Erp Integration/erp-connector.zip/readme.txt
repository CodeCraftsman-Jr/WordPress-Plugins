=== ERP CONNECTOR by AC SOFTWARE SP. Z O.O.===
Contributors: acsoftware
Donate link: http://www.acsoftware.pl/
Tags: wf-mag, wfmag,cdn optima,cdn xl,subiektgt,sage symfonia,hermes sqll,corax,navireo,enova,pcbiznes,polpress.pl,paktury express,elisoft faktury,raks sql,odl,polkasql,fin7
Requires at least: 4.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Umożliwia wymianę danych z systemami ERP. 
Aktualnie obsługiwane Systemy:
1. CDN Opt!ma 
2. CDN XL 
3. Enova
4. Hermes SQL
5. Corax
6. SubiektGT
7. Navireo
8. Symfonia Forte
9. Symfonia Premium
10. Symfonia Btrieve
11. Wf-Mag dla Windows
12. Elisoft Faktury
13. Faktury Express
14. RAKS SQL
15. PCBiznes
16. ODL PolkaSQL

Plugin wymaga zainstalowania bezpłatnego oprogramowania serwerowego, które wraz z instrukcją instalacji dostępne jest pod adresem:
http://www.acsoftware.pl/download?file=erpcserver


Enables the exchange of data with ERP systems.
Currently supported systems: 
1. CDN Opt!ma 
2. CDN XL 
3. Enova
4. Hermes SQL
5. Corax
6. SubiektGT
7. Navireo
8. Symfonia Forte
9. Symfonia Premium
10. Symfonia Btrieve
11. Wf-Mag dla Windows
12. Elisoft Faktury
13. Faktury Express
14. RAKS SQL
15. PCBiznes
16. ODL PolkaSQL

This plugin requires installation of a free of charge server software, followed with an installation manual available at: 
http://www.acsoftware.pl/download?file=erpcserver

== Screenshots ==
1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets 
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/1.0/screenshot-1.png` 
(or jpg, jpeg, gif).


== Installation ==

1. Install ERP CONNECTOR either via the WordPress.org plugin directory, or by uploading the files to your server
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the ERP CONNECTOR settings and set your options.