<?php
/**
 * ERP CONNECTOR Woocommerce extensions
 *
 *
 * @version		1.0
 * @package		ERPC/Extensions
 * @category	Extensions
 * @author 		AC SOFTWARE SP. Z O.O. (p.zygmunt@acsoftware.pl)
 */
 
/*
#add_filter('woocommerce_my_account_my_orders_actions', 'erpc_my_account_my_orders_actions', 10, 2);
/*
function erpc_my_account_my_orders_actions($actions, $order ) {

   $actions['erpc_invoice'] = array(
                             'url'  => 'none_exists',
                             'name' => __( 'Faktura', 'erpc' )
                           );

   return $actions;
}
*/

#../../plugins/woocommerce/includes/admin/settings/class-wc-settings-accounts.php
#../../plugins/woocommerce/includes/admin/views/html-notice-install.php
?>