=== Advance Guest Post ===
Contributors: Corlax Technologies
Tags: front-end, Membership, posting, WordPress
Requires at least: 3.9
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
This plugin help your visitor to publish post and from frontend anywhere on your site. this plugin have so many feature like guest posting, captcha, upload image, any custom post-type, taxonomy etc.
Features:-
Let visitors submit posts from anywhere on your site
Easy integration shortcode to display the submission form
captcha support protect from spam
Post submissions may include title, category, author, post and image(s)
Customize label In front End
Enable/disable option for hide any option title, category, author, post and image(s)

Extra Features:-
Post Type and taxnomy Support
Publish post or Pending post
Enable/disable Captcha
Enable/disable Guest Posting
Success Message
Image size

==Installation==
1. Upload the /advance-guest-post/ directory to your plugins folder and activate
2. Go to the �Guest Post� Settings Page and customize your options
3. Display the submission form on your page(s) using shortcode [advance_guest_post]