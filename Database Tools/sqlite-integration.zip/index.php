<?php
/* Silence is golden */