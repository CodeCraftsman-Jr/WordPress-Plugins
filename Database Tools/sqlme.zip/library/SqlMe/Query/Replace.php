<?php


class SqlMe_Query_Replace extends SqlMe_Query_Insert {


}