<?php


class SqlMe_Query_Set extends SqlMe_Query_Show {


}