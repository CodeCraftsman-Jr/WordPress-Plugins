<?php


class SqlMe_Query_Update extends SqlMe_Query_Insert {


}