<?php


class SqlMe_Query_Delete extends SqlMe_Query_Select {


}