<?php

function wp_tinywebdb_api_install() {

}

?>
