=== Font BLOKK Integration ===

Contributors: mcostales84
Donate Link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=VWWTUHZWRS4DG
Tags: font blokk, mockup
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin integrate the font BLOKK with your wordpress installation.

== Description ==

This plugin add the font BLOKK (http://blokkfont.com) to your wordpress site, and add the feature to create a mockup to show to your clients without to worry about the dummy text you enter.
This plugin integrate two fonts: BLOKK Regular and BLOKK Neue-Regular, to use them you only have to add the class blokk-regular and blokk-neue respectively.

== Installation ==

To install this plugin just follow the standard procedure.

or

1. Upload `font-blokk-integration.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Any question? =

Send me an email at mcostales@jumptoweb.com and I will answer you as soon as I can.

== Changelog ==

= 1.0 =
- Just launch the plugin!
