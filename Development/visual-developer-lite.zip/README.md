# Wordpress Visual Developer Lite Version
Lite Version of Visual Developer for Wordpress.

Learn more : http://visual-developer.net/
