# FAQs Shortcode

FAQs Shortcode, is a shortcode generator which adds a neat frequently asked questions section to any of your pages. The functionality is built using native WordPress functions, which makes adding questions and answers as simple as adding a post or page.

Want to contribute? You are at the right place :) For support please visit the [Support forum].

#### Installation

1. Upload the folder `faqs-shortcode` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in your WordPress dashboard

#### Got an idea, or a fix?

You can contact me with any ideas or suggestions you have here. Also, like any other repo, you can report issues as you get them. Be nice!

#### Donate

You can say thanks by buying me [Nespresso Capsules] :)

[Support forum]:http://wordpress.org/support/plugin/faqs-shortcode
[Nespresso Capsules]:https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=yusrimathews%40gmail%2ecom&lc=ZA&item_name=Yusri%20Mathews&item_number=faqs%2dshortcode&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted