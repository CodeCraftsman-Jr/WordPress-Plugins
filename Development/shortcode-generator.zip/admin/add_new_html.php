<?php
$action = 'new'; //default
$type = 'html';
require(dirname(__FILE__).'/edit.php'); 
?>