<?php
$action = 'new'; //default
$type = 'wysiwyg';
require(dirname(__FILE__).'/edit.php'); 
?>