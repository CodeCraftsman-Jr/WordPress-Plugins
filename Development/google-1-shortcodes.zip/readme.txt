=== Google +1 Shortcodes ===
Contributors: Christopher Su
Donate link: http://christophersu.org/wp-donate/
Tags: google, plus, google plus, shortcode, embed, button, buttons, share, social
Requires at least: 2.7
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shortcodes for embedding Google +1 buttons.

== Description ==

Shortcodes for embedding Google +1 buttons. Currently, the plugin supports embedding +1 buttons using the following shortcodes: [gplusone], [plusone], [google+1], [g+1], [+1].

This plugin has been tested to work up to 3.4.2. Please [contact me](http://christophersu.org/contact/) if you experience any problems with this plugin or have any questions.

== Installation ==

1. Upload the php file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==



== Screenshots ==



== Changelog ==



== Upgrade notice ==

