=== sxss Shortcode Creator ===
Contributors: sxss
Donate link: http://sxss.nw.am
Tags: shortcode, shortcode-ui, content, snippets
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 0.1.1

Creating your own shortcodes was never so easy!

== Description ==

With the sxss Shortcode Creator you can easily create custom shortcodes for important content, disclaimers, or ads to your WordPress blog. Just save your content in the well known wordpress editor and copy & paste the newly created shortcode! To add your shortcodes easily to your posts and pages, there is a listing of your shortcodes under the WordPress editor. Just click on the shortcode you want to insert and it will be pasted to the editor.

Languages: English, German (later). More informations on the official plugin page: [http://sxss.nw.am](http://sxss.nw.am "sxss.nw.am")

== Installation ==

Upload the sxss Shortcode Creator plugin to your blog, activate it.

Thanks for using one of my plugins. Check out [my other plugins](http://profiles.wordpress.org/sxss/ "http://profiles.wordpress.org/sxss/") in the Wordpress repository!

== Frequently Asked Questions ==

= Questions? =

All contact details will be published at [sxss.nw.am](http://sxss.nw.am "sxss.nw.am")

== Screenshots ==

1. List of your shortcodes
2. Shortcode Creator
3. Add a shortcode with a click

== Changelog ==

= 0.1.1 =
Fixed a compatibility problem with Contact Form 7

= 0.1 =
First Upload


== Upgrade Notice ==

= 0.1 =
First upload