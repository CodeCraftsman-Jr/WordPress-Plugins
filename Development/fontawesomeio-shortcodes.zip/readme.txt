=== FontAwesome.io ShortCodes ===
Contributors: aweleczka
Tags: shortcode, post, font, fontawesome, icon, page
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 4.2
License: gpl-2.0
License URI: http://choosealicense.com/licenses/gpl-2.0/

This plugin allows the easy use of the entire Font Awesome Icon-Set through ShortCodes anywhere on your site.

== Description ==
This plugin allows the easy use of the entire Font Awesome Icon-Set through ShortCodes anywhere on your site.

**This plugin is in no way associated with Font Awesome**

== Installation ==
1. Install and activate the plugin in your WordPress-Install
2. Use the [fa icon=""] shotcode to add an icon

The possible values of "icon" can be found on [http://fontawesome.io/icons/](http://fontawesome.io/icons/)

== Changelog ==
= 1.0 =
* Initial release

== Upgrade Notice ==
= 1.0 =
Initial release, no upgrade-information available