=== Dummy Text Shortcode ===
Contributors: norcross
Website Link: http://andrewnorcross.com/plugins/dummy-text-shortcode/
Donate link: http://andrewnorcross.com/donate
Tags: dummy text, shortcodes, markup content, dummy content, lorem ipsum
Requires at least: 2.5
Tested up to: 3.3.1
Stable tag: 1.01

Allows for dummy text to be placed in a post / page with the [dummy] shortcode.

== Description ==
Allows for dummy text to be placed in a post / page with the [dummy] shortcode. Can easily be removed when no longer needed.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the 'dummy-text-shortcode' folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. That's it.

== Frequently Asked Questions ==

= What does this do? =

Allows you to add 'dummy text' with HTML markup into a post or page. Great for testing a new layout or design. Simply place the [dummy] shortcode on the HTML tab.


== Screenshots ==

1. Text displayed on a post

== Changelog ==

= 1.01 =
* Added banner image and WP version number

= 1.0 =
* Initial release

== Upgrade Notice ==
* Should not affect any existing plugins / frameworks.

== Potential Enhancements ==
* Got a bug? Something look off? Hit me up.
