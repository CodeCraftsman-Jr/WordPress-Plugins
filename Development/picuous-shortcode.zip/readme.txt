Copy the "picuous-shortcode" into Wordpress Plugins folder and install it from Admin panel. 

Enjoy!!!

Shorcode Example in post:

[picuous source="c4a0229ec6fc188f9ca0+refferrer_id" width="500" height="364"]