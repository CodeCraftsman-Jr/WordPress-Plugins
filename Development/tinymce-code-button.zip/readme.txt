=== TinyMCE Code Button ===
Contributors: Potsky
Donate link: https://www.potsky.com/donate/
Tags: tinymce, code, button, rich, editor
Requires at least: 3.2
Tested up to: 3.5
Stable tag: 0.0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin simply adds a <code> button in the rich TinyMCE editor of Wordpress to put selection between <code></code> tag.

== Description ==
This plugin simply adds a <code> button in the rich TinyMCE editor of Wordpress to put selection between <code></code> tag.

Don't hesitate to ask me new features or report bugs on [potsky.com](https://www.potsky.com/code/wordpress-plugins/wordpresscodebutton/ "Plugin page") !  
You can join me on [GitHub](https://github.com/potsky/WordPressCodeButton "GitHub") to add feature, fix bugs,... !  


== Installation ==

**TinyMCE Code Button** is very easy to install (instructions) :  
* Upload the `/tinymce-code-button` folder to your `/wp-content/plugins/` directory.  
* Activate the plugin through the Plugins menu in WordPress®.  

== Frequently asked questions ==

== Screenshots ==

1. Code button in action

== Changelog ==

= 0.0.1 =
* First release

== Upgrade Notice ==




