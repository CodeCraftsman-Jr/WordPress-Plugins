=== Gunner Technology Shortcodes ===
Contributors: codyswann, gunnertech
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=S6HYHZA546HLW&lc=US&item_name=Gunner%20Technology&item_number=google%2dreferrer%2dchecker&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: shortcodes
Requires at least: 3.0
Tested up to: 3.3
Stable tag: 0.0.1

This plugin adds some nifty shortcodes, including the ability to add a widget anywhere via a shortcode.

== Description ==

The Gunner Technology Shortcodes plugin gives you the ability to add a widget anywhere you want.

When you add a widget in the widget panel, you'll see it has a shortcode at the bottom. You can take that shortcode and copy and paste it into a page, post or even another widget.

For questions, comments, and feedback, please go to our blog post: [Shortcodes WordPress Plugin](http://gunnertech.com/2012/02/shortcodes-wordpress-plugin/)

Requires WordPress 3.0 and PHP 5. 


== Installation ==

1. Upload the files to the `/wp-content/plugins/gunner-technology-shortcodes/` directory
1. Activate the "Gunner Technology Shortcodes" plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.0.1 =
* Initial release