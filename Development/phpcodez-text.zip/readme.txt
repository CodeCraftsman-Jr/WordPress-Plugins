=== PHPCodez Text ===

Contributors: Pramod T P
Tags: Archives
Tested up to: 3.4.1
Requires at least: 2.0
Stable tag: 2.0

It displays content on specified pages

== Description ==

PHPCodez Text displays content on specified pages . Here you must enter the page urls in a textarea given in the widget option area from the admin panel .You can either display or 
block content based the given page url.

It is similar to the “Text” wordpress widget except that you can decide the pages on which the content is to be printed

Page urls should be entered line by line in the text area (No separation needed). With the help of exclude option you can display or block the content .

== Installation ==

1. Upload the plugin folder to your /wp-content/plugins/ folder.

2. Go to the *Plugins* page and activate the plugin.

3. Go to appearance->widget page and drag the widget “PHPCodez Text” to the wiget area to have this on the sidebar .

== Screenshots ==

1) Widget admin panel options








