edButtons[edButtons.length] = new edButton( 'lms', 'Let\'s Mix', '[letsmix][/letsmix]', '', '' );

if (typeof jQuery !== 'undefined') {
    jQuery(document).ready(function(){
         jQuery("#lms").attr('title', 'Insert Let\'s Mix Shortcode');
    })
};