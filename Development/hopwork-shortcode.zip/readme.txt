=== Hopwork Shortcode===
Contributors: Matthieu Solente
Tags: plugin, shortcode, customize, sitemap, page,posts, categories.
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=43XMASQSUE4YE
Requires at least: 3.5
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily lets you add your hopwork profile on your website

== Description ==
WordPress Hopwork Shortcode is a plugin that easily lets you add your hopwork profile on your website, as a Shortcode
* Display a hopwork profile with a simple Shortcode(with options as color, size, recommandations)



== Installation ==
1. Download archive and unzip in wp-content/plugins or install via Plugins / Add New.
2. Activate the plugin through the Plugins menu in WordPress.
3. get all your profile informations on https://www.hopwork.com/ 
4. use these informations to fill the shortcode params
5. use the shortcode on any page or widget

= Translators =
* French (fr_FR) - Matthieu Solente

== Changelog ==
For more information, see [Releases](http://copier-coller.com/hopwork-shortcode/).

= 1.0 =
* Initial release.

== Upgrade Notice ==
To have information on new release, follow http://copier-coller.com/hopwork-shortcode/

== Frequently Asked Questions ==
Do you have questions or issues with hopwork-shortcode? Use these support channels appropriately.
1. [Docs](http://copier-coller.com/hopwork-shortcode/)
2. [Support Forum](http://wordpress.org/support/plugin/hopwork-shortcode)
3-How do i create my shortcode?
Here are the two shortcode : (you have fo fill the blank fields with your own values)
for the widget :
[profil_widget dataid="" recos="" picture=""  tags="" height="" width="" style=""]
for the button :
[profil_button  dataid=""  datarecos="" datacolor="" datawidth="" datalayout=" " ]
== Screenshots ==
1. Hopwork Shortcode

