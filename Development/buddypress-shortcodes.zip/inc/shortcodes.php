<?php

/* ================================================================================ */
/* Buddypress Shortcodes
/* ================================================================================ */

require_once ( plugin_dir_path( __FILE__ ) . '/shortcodes/activity.php');
require_once ( plugin_dir_path( __FILE__ ) . '/shortcodes/activity-carousel.php');
require_once ( plugin_dir_path( __FILE__ ) . '/shortcodes/members-carousel.php');
require_once ( plugin_dir_path( __FILE__ ) . '/shortcodes/members-grid.php');
require_once ( plugin_dir_path( __FILE__ ) . '/shortcodes/groups-carousel.php');
require_once ( plugin_dir_path( __FILE__ ) . '/shortcodes/groups-grid.php');