tinyMCE.addI18n("en.hanacodeinsert",{
	hcinsert : "Hana Code Insert"
});