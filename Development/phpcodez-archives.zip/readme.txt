=== PHPCodez Archives ===

Contributors: Pramod T P
Tags: Archives
Tested up to: 3.4.1
Requires at least: 2.0
Stable tag: 2.0

It can be used to list archives 

== Description ==

PHPCodez lists the archives. The output can be managed from the back end 

Features

1) We can restrict the number of archives

2) We can list the post count along with the archive name .

== Installation ==

1. Upload the plugin folder to your /wp-content/plugins/ folder.

2. Go to the *Plugins* page and activate the plugin.

3. Go to appearance->widget page and drag the widget “PHPCodez Archives” to the wiget area to have this on the sidebar .


== Screenshots ==

1) Widget admin panel options





