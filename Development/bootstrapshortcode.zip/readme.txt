=== BootStrapShortCode ===
Contributors: abr4xas
Donate link: http://donate.abr4xas.org/
Tags: shortcode, bootstrap
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Contextual backgrounds. Similar to the contextual text color classes, easily set the background of an element to any contextual class.

== Description ==

Contextual backgrounds. Similar to the contextual text color classes, easily set the background of an element to any contextual class.

== Installation ==

* Upload `Bootstrap-ShortCode.php` to the `/wp-content/plugins/` directory
* Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= It can cause some kind of problem in my blog? =

It has been tested and has not caused problems. To avoid any inconvenience disable any other plugin to do what is listed in the changelog as it can cause some kind of system error.

= How to use? =
* [infobox] Nullam id dolor id nibh ultricies vehicula ut id elit. [/infobox]
* [warningbox] Etiam porta sem malesuada magna mollis euismod. [/warningbox]
* [dangerbox] Donec ullamcorper nulla non metus auctor fringilla. [/dangerbox]

== Screenshots ==

1. /assets/screenshot-1.png
2. /assets/screenshot-2.png
3. /assets/screenshot-3.png

== Changelog ==

= 0.1 =
First release