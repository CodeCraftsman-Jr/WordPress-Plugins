<p>For any question, help, support and feature request about the plugin. Please see followings:</p>

<ul>
	<li><a href="https://wordpress.org/support/plugin/shortcode-factory" target="_blank">Plugin Support on WordPress</a></li>
	<li><a href="http://wpscf.com/contact/" target="_blank">Direct Contact (Official Website)</a></li>
	<li><a href="https://www.facebook.com/pages/WPMadeasy/785993324849159" target="_blank">Find us on Facebook</a></li>
</ul>

<p>Other useful support stuff:</p>

<ul>
	<li><a href="https://wordpress.org/plugins/shortcode-factory/changelog/" target="_blank">Change Log</a></li>
	<li><a href="https://wordpress.org/plugins/shortcode-factory/faq/" target="_blank">Frequently Asked Questions (FAQs)</a></li>
	<li><a href="https://wordpress.org/plugins/shortcode-factory/developers/" target="_blank">Dev and Previous Versions</a></li>
</ul>