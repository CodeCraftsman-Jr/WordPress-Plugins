;(function ($) {
    jQuery(function ($) {
        //
        $('.widgets-holder-wrap').on( 'focus', '.cbxcntdatepicker', function(e) {
            $( this ).datepicker();
        });
    });
})(jQuery);