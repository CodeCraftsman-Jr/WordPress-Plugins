;(function ( $ ) {
	"use strict";
    // Place your administration-specific JavaScript here

    $( function() {
        $('.datepicker').datepicker();
        $('.color-field').wpColorPicker();
    } );
})(jQuery);