<?php
/**
Component Name: OTW Validator
Plugin URI: http://OTWthemes.com
Description:  OTW Validator
Author: OTWthemes.com
Version: 1.1
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Validator';
$otw_component['version']    = '1000.2';
$otw_component['class_name'] = 'OTW_Validator';
?>