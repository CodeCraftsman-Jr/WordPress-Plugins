<?php
/**
Component Name: OTW Form
Plugin URI: http://OTWthemes.com
Description:  OTW Form
Author: OTWthemes.com
Version: 1.1
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Form';
$otw_component['version']    = '1000.1';
$otw_component['class_name'] = 'OTW_Form';
?>