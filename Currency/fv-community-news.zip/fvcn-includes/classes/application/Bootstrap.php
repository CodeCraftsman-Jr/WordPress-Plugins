<?php

/**
 * FvCommunityNews_Bootstrap
 *
 * @author Frank Verhoeven <info@frank-verhoeven.com>
 */
class FvCommunityNews_Bootstrap extends FV_Bootstrap
{

}
