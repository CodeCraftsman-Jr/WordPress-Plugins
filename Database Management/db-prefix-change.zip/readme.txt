=== Change DB Prefix ===
Contributors: softy.5454
Donate link: http://creativedev.in/wordpress-plugins/
Tags: Prefix,database prefix,wp_
Requires at least: 3.0
Tested up to: 3.9.1
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This Plugin is basically for changing the database default prefix(wp_) to other one. 

== Description ==

This plugin is mainly useful if you have not changed the database default prefix(wp_) at installation time and want to change aftrewards so its possible by this plugin. With use of this plugin,you can easily replace your database default prefix or prefix to other keyword and you don't need to change manually.

== Installation ==

1. Upload `db_prefix` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3.Configure the new prefix in Settings -> change DB Prefix 

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. Settings in Admin panel 
2. Database changes

== Changelog ==

Version 1.1
1. Update layout of admin.
2. Solved user table prefix change issue.

Version 1.2
1. Resolved issues of previous version.
2. Added Messages to provide information.

== Upgrade notice ==



== Arbitrary section 1 ==

