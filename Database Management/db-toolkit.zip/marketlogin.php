<?php
/* 
 * marketplace login panel
 */

?>
<div id="loginStatus"></div>
Username: <input name="dbt_user" type="textfield" id="dbt_user" /><br />
Password: <input name="dbt_pass" type="password" id="dbt_pass" /><br />
<input type="button" onclick="dbtMarketLogin();" value="Login" />
