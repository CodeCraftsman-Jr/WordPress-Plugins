<?php
	declare_ajax_functions('di_sourceSetup', 'di_referenceSetup', 'di_showItem');
?>