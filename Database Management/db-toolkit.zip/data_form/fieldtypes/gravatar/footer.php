<?php 
//<script type="text/javascript" src="system/dais/plugins/data_form/fieldtypes/text/jwysiwyg/jquery.wysiwyg.js"></script>
?>
