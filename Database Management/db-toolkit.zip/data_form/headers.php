<?php
$themeDir = get_bloginfo('template_directory');
$themeURL = get_bloginfo('template_url');
?>