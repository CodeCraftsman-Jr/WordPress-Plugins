<?php
/* 
 * wordpress register form processor
 * processess the form as a wordpress user registration form.
 */
    $Title = 'Wordpress Registration';
    $Desc = 'Processess form as a Wordpress User Registeration. [BETA]';


?>
