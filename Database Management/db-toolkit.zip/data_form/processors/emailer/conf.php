<?php
/* 
 * emailer form processor
 * sends out the form data as an email
 */
    $Title = 'Form Emailer';
    $Desc = 'Sends the submitted data to a designated email address.';


?>
