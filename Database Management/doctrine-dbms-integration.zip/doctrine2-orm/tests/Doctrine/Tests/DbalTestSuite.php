<?php

namespace Doctrine\Tests;

/**
 * The outermost test suite for all dbal related testcases & suites.
 */
class DbalTestSuite extends DoctrineTestSuite
{  
}