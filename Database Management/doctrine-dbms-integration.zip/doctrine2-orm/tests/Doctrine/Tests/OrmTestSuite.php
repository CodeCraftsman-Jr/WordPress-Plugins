<?php

namespace Doctrine\Tests;

/**
 * The outermost test suite for all orm related testcases & suites.
 */
class OrmTestSuite extends DoctrineTestSuite
{
}