<?php

namespace Doctrine\Tests;

/**
 * Doctrine's basic test suite implementation. Provides functionality needed by all
 * test suites.
 */
class DoctrineTestSuite extends \PHPUnit_Framework_TestSuite
{ 
}