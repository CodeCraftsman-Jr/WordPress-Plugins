<?php

/**
 * @entity
 */
class DoctrineOrmTestEntity
{
    /**
     * @column(type="integer")
     * @id
     */
    public $id;
}