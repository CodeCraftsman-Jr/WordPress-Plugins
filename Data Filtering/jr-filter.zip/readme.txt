=== Plugin Name ===
Contributors: Jake Ruston
Donate link: http://www.jakeruston.co.uk
Tags: security, javascript, content, plugin, page, filter, profanity, block, word, words, swearing
Requires at least: 2.0.2
Tested up to: 3.0.0
Stable tag: 1.1.3

This filter plugin allows you to block certain words from being shown on your website - In your content and comments!

== Description ==

This filter plugin allows you to block certain words from being shown on your website - In your content and comments!

In the administration panel, you have the option to choose the words you want to block as well as the words which will replace them.

== Installation ==

1. Upload `/jr-filter.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit the JR Filter Settings in your Administration Panel
4. Done!

== Frequently Asked Questions ==

= Does this work?

Yes.

== Changelog ==

= 1.0.0 =
* Initial Release
