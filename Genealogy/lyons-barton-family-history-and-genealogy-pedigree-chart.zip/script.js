function refreshPage(){
	document.location.reload(true);
	
}