=== Identity Verification USA SSN ===
Contributors: identity-verification-services
Donate link: https://identityverification.com/
authentication, security
Requires at least: 3.9
Tested up to: 4.2-alpha
Stable tag: 2.0

== Description ==

VERIFY A USER WITH A SOCIAL SECURITY NUMBER

1.With this API you can verify a valid user address as well as the identity

2.The verification requires the user to complete the total information that uniquely matches the Social Security Number in order to be verified.



== Installation ==

Upload the zip folder of plugin through Admin Panel 

		(OR)

Unzip the folder and place plugin files in /wp-content/plugins/

Enable CURL Extension on Your Server to run this Plugin


== Screenshots ==
1. Here you can configure your API Credentials
2. Place the Short Code in any of the page or create a new page and paste it.
3. Provide Your Details to Verify
4. Response Page

== Short Codes ==

Until API Credentials i.e Client Id and Client Secret Provided you will not get the Short Code.
Short COde : [IVS_IDENTITYVERIFICATION_USASSN] 