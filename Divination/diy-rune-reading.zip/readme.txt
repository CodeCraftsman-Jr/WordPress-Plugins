=== Diy Runes Widget ===

Donate link: http://diydiscovery.com/donate
Tags: runes,games,rune readings,fun,entertainment,cards,magic, mystic,interactive,self help,card games,psychology,psychic,entertaining,tarot
Requires at least: 2.0.2
Tested up to: 3.1
Contributors: akaalvin
Stable tag: trunk


A complete flash runes reading widget representing the past, present, and future.

== Description ==

A complete Runes Reading (past, present, future) providing random rune throws (inverted as well as upright) and utilizing the full rune library and their interpretations. It 300px wide and fits well into most sidebars. The widget includes a push button drop runes function to provide a visual aspect to the random function of the rune reading. The user chooses from dropped runes to reveal small thumbs of chosen runes. Once clicked, the small thumbs then reveal larger runes with scrollable definitions. For entertainment purposes only.




== Installation ==


1. Upload the `diyrunes` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
3. Use like any other widget in your sidebar.

== Frequently Asked Questions ==

1. Why doesn't my widget work?

If it doesn't work then there's an issue on our end as this is a flash file hosted by our servers. So, effectiveness is pretty straight forward. Do let us know though if you have issues and we'll try to help if we have time.

2. I've clicked a rune but can't get back to my other runes?

Click the red "x" to exit out of selected cards.

3. Do I have to keep the link underneath the widget back to diydiscovery.com?

Yes, as long as you use the widget it is required.


== Screenshots ==

1. a look at the widget before the runes are displayed and dropped.
2. a look at the widget after.
3. A look at a Rune Interpretation after it has been clicked.

 == Changelog ==

== Upgrade Notice ==
