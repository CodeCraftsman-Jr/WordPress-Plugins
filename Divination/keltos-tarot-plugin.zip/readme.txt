=== Plugin Name ===
Keltos
Plugin URI: http://mark.indigoblues.ca
Description: 
Author: Mark W. Law
Author URI: http://mark.indigoblues.ca
License: GPL2
Requires at least: 2.8
Tested up to: 2.9

== Description ==

A Celtic Cross Reading plugin using the Rider-Waite Deck that invokes the Tarot reader at Spirit Speaks! in a new tab / window.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload 'keltos' directory to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the widget to your sidebar at Appearance >> Widgets.
4. Thats all...

== License ==

Copyright 2010  Mark W. Law  (email : mark.w.law@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

== Changelog ==

= 1.0 =
* First version.
