=== Plugin Name ===
Contributors: Genkisan
Tags: feedburner, site stats
Requires at least: 2.0.0
Tested up to: 2.7.0
Stable tag: 1.0.0

Insert Feedburner SiteStats code (without Feeds Flare) for a speed boost

== Description ==

- insert the Feedburner SiteStats code into footer
- will work even when you change theme

**Demo:**

[Plugin Details & Demo](http://ericulous.com/2007/05/10/wp-plugin-genki-feedburner-sitestats/)

== Installation ==

1. Upload and activate plugin
2. Go to Admin Panel > Options > Feedburner SiteStats.
3. Enter your Feedburner Feed ID e.g ericulous. Not http://feeds.feedburner.com/ericulous