=== Clean Surpluss (junk database data)===
contributors: selnomeria
Tags: clean, surplus, disable auto-draft,revision, database
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 1.1
License: GPLv2

Safely clean up junk data. 

== Description ==
Safely cleans & prevents unnecessary, needless data from Wordpress.  Removes AUTO-SAVES and AUTO-DRAFTED revisions,useless posts from database. VERY lightweight plugin,see description under Settings. 


>  (P.S. Note! This is a <a href="http://codesphpjs.blogspot.com/2014/10/nsp-non-slowing-plugins-for-wordpress.html" target="_blank">Non-Slowing</a> Plugin.  See OTHER MUST-HAVE PLUGINS FOR EVERYONE: http://bitly.com/MWPLUGINS  )



= Usage =


Related Links:

* <a href="http://boliquan.com/wp-clean-up/">WP Clean Up (FAQ)</a> | <a href="http://wordpress.org/extend/plugins/wp-clean-up/">Download</a>

== Installation ==

1. Download and extract archive to `wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. You will have menu under "Dashboard"->"Settings"

== Changelog ==

= 1.1.0 =

* First release.


== Screenshots ==


== Frequently Asked Questions ==

Nothing


== Upgrade Notice ==

nothing