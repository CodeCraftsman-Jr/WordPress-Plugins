table-data-wp
=============

This plugin helps to display Database table data into admin View Page
