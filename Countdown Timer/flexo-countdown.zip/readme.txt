﻿=== flexo-countdown===

Plugin Name: flexo-countdown
Contributors: flexostudio
Tags: countdown, clock, timer
Author: Grigor Grigorov, Mariela Stefanova, Flexo Studio Team
Plugin URI: http://www.flexostudio.com/wordpress-plugins-flexo-utils.html
Description:
Version: 1.0001 
Stable tag:1.0001
Requires at least:3.0
Tested up to: 3.0
Donate link: http://flexostudio.com/

Countdown Clock

== Description ==

Countdown Clock
see: http://www.flexostudio.com/
== Installation ==

1.	Download.
2.	Unzip.
3.	Upload to the plugins directory.
4.	Activate the plugin.
5.	Have a nice work.

== How to use ==
1.Going by the settings in the administration and data entry required to start the clock. Generate code and copy it and put the desired location and you're done.
or
2. paste the following code to the desired location in the code of your page:
example:
	$con='[flexocounter endDate="30.09.2011 10:30" url="http://google.com" header="text" footer="text"]';
	flexoCounter::the_content($con);
$con generate in the administration too

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==
1. screenshot-1.jpg
2. screenshot-2.jpg

== Changelog ==

= 1.0001 =

== Upgrade Notice ==

= 1.0 =