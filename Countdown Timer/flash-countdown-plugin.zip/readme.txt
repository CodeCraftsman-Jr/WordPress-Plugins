=== Plugin Name ===
Contributors: Arjan Nieuwenhuizen, Roelof Albers
Donate link: http://www.flex-blog.com/components/flash-countdown-plugin/
Tags: count down, counter, flash, counting down
Requires at least: 2.8
Tested up to: 2.9.1
Stable tag: 0.1

A count down plugin made in Adobe Flash and Flex.

== Description ==

With the count down plugin you are able to count down for your visitors to a certain Date. When this date is reached, a custom image will be shown (which can be defined by yourself).

This plugin is Widget enabled, so you are able to add it to your sidebar just by drag and drop and your counter is ready!

== Installation ==

Use the following steps to install the Flash CountDown Plugin

1. Upload the flash-countdown-plugin folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Fill the options page 'Settings -> Flash CountDown Options'
1. Place `[fcdp]` on the page and the Flash CountDown Plugin will appear.
1. Or the Flash Countdown Plugin as a widget to your sidebar.

== Frequently Asked Questions ==

= Do i need Flash Player for this CountDown Plugin? =

Yes you do.

= How do I add the Flash CountDown Plugin form to a post/page? =

You need to add the `[fcdp]` to the body of the post/page in the editors HTML mode.

= What is the size of the plugin? =

280x170 (widthxheight in pixels)

= Do you have other sizes? =

Yes, please go to http://www.flex-blog.com/components/flash-countdown-plugin/ for more information.


== Screenshots ==

1. This shows an example of the Flash CountDown Plugin.
2. This shows the Flash CountDown options page.
3. This shows a finished Countdown of the Flash Countdown Plugin.

== Changelog ==

= 0.1 =
* We are live! A cool countdown plugin in Adobe Flash!
