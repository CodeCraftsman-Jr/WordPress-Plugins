=== Funifier ===
Plugin Name: Funifier
Plugin URI: http://www.funifier.com
Description: The Funifier plugin is designed for integration with enterprise gamification system.
Contributors: jeffersonassilva, caioflucena
Tags: admin, javascript, gamification, funifier
Version: 1.0
Requires at least: 2.7
Tested up to: 3.0.1
Stable tag: trunk

The Funifier plugin was created to integrate with gamification system of the company.

== Description ==

To learn more about how gamification your site, visit www.funifier.com!

== Installation ==

1. Upload the funifer.zip file in Plugins menu -> Add new;
2. Activate the plugin after installation;
3. Edit the HTML content in Settings -> Funifier.

== Frequently Asked Questions ==

== Changelog ==

= 1.0 =
Release inicial
