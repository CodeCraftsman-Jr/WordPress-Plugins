=== Live Chat Online ===
Plugin Name: Live Chat Online
Version: 1.1.1
Donate link: http://www.realtime-chat.com/donate
URI: www.realtime-chat.com
Tags: chat, Online, Live, Online chat, Live Chat, widget chat, online live chat, web chat, tools
Requires at least: 3.9
Tested up to: 4.2.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Author: realtime-chat.com
Contributors: realtime-chat.com

Live Chat & Online Chat - simple Communication with Customers.

== Description ==

Live Chat & Online Chat - simple Communication with Customers.

For using Live Chat Online service, you will need to add your website to an account at www.realtime-chat.com

Live Chat Online plugin work across major browsers, such as Firefox, Google Chrome, Opera, Safari, Internet Explorer.
Install it for free today and chat with website users!

== Installation ==

= Quickly simple installation =

1. Add your domain at www.realtime-chat.com
2. Install the plugin through `Plugins` menu in WordPress or just Upload the plugin folder `live-chat-online` to the `/wp-content/plugins/` directory of your WordPress installation.
3. Activate the plugin through the `Plugins` menu in WordPress


== Frequently Asked Questions ==

Is the multilingual users interface for this chat widget supported?

This chat plugin (chat widget) support multilingual users interface for visitors of your website and also support this for chat operators in your control panel at www.realtime-chat.com



== Changelog ==

= Live Chat & Online Chat - simple Communication with Customers. (Chats version 1.1.1) =
* Was improved creation of table for log of messages.

= Live Chat & Online Chat - simple Communication with Customers. (Chats version 1.1.0) =
* To Live Chat was added page with settings (authorization settings, colors settings, texts settings, template settings).
* To chat was added capability to change visibility mode (offline, online, hidden).
* Updated styles of template, added sounds.

== Upgrade Notice ==

coming soon

