=== Plugin Name ===
Contributors: callmaker
Tags: call,callmaker,callback
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Callmaker helps you boost website conversion by establishing phone calls with your visitors via VOIP.

== Frequently Asked Questions ==

= How does it work? =

After one of your website visitors engages with your web site for some time, he gets an invitation to be connected with manager. He enters his phone number and your manager and client numbers are being called and then connected.


== Changelog ==

= 0.1 =
* Beta version.