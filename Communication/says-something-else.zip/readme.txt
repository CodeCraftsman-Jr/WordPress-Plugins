=== Says Something Else ===
Contributors: normanyung
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&amp;business=8HGMUBNDCZ88A
Tags: comments, themes, says, thread
Requires at least: 2.7
Tested up to: 2.7.1
Stable tag: 1.0.2

Says Something Else replaces the default “SoAndSo says:” in Wordpress comment threads with whatever you specify.

== Description ==

Says Something Else replaces the default “SoAndSo says:” in Wordpress comment threads with whatever you specify. If you specify more than one replacement, Says Something Else will randomly pick from your collection of specified words.

== Screenshots ==

1. No Screenshots. This plugin changes text. No big deal.

== Installation ==

1. Upload the extracted archive to 'wp-content/plugins/'
2. Activate the plugin through the 'Plugins' menu
3. Open the plugin settings page Settings -> Says Something Else
4. Add/Edit replacement words
4. Enjoy!

== Frequently Asked Questions ==

= I've found a bug, where do I report it? =

The fastest way would be to leave a comment on the [plugin homepage](http://www.robotwithaheart.com/wordpress-work/says-something-else)

== Changelog ==

* 1.0		Initial release
* 1.0.1		Fixed bug by adding stripslashes to JS output.
* 1.0.2		Removed empty() values from the replacement list on runtime.
