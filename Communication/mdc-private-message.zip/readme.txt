=== MDC Private Message ===
Contributors: mukto90
Donate link: http://nazmulahsan.me/
Tags: wordpress message, user message, private message, internal message, message send, wp user message, mdc
Version: 1.0.1
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

MDC Private Message is probably the best plugin to create an easy messaging system in WordPress.

== Description ==

MDC Private Message is probably the best plugin to create an easy messaging system in WordPress.

It helps you create an internal private messaging system where registered users can send private messages among themselves.


== Installation ==

1. Upload the `mdc-private-message` folder and its contents to your `wp-contents/plugins` directory.
2. Activate in the `Plugins` menu.
3. Configure from WordPress admin area.
4. You are done!


== Screenshots ==

1. New Message (from back-end)
2. New Message (from front-end)
3. Inbox (from back-end)
4. Inbox (from front-end)
5. Outbox (from back-end)
6. Outbox (from front-end)
7. New Message Notification
8. Full view of a message
9. Settings page