//As of fcchat version 3.5 load jquery directly
