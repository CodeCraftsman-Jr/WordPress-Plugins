(function(){
if(FCChatConfig.language_template_overrides)FCChatConfig.language_template_overrides();
if(FCChatConfig.global)FCChatConfig.global.template_overrides();
}());