<?php

/* 
 * Enter your password below.
 * It is HIGHLY RECOMMENDED that you use a strong password here.
 * Strong passwords should contain 12 or more random characters, mixing uppercase
 * and lowercase letters with numbers and punctuation marks.
 */

 $password = '';
 
 /* 
 * Notification email. (Optional) Email confirmation will be sent to the address below when
 * a file is edited.
 */

  $email = '';

?>