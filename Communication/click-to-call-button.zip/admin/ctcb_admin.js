jQuery(document).ready(function($){
    $('.button_colour').wpColorPicker();
    $('.active_colour').wpColorPicker();
});