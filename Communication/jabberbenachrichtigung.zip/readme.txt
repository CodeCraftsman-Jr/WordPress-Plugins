=== Jabbernotification ===
Contributors: Missi
Tags: comments, jabber, xmpp
Requires at least: 2.0.2
Tested up to: 2.9
Stable tag: 0.99-RC2
Donate link: http://foo.entartete-kunst.com/
Notify the Admin about new comments via jabber.

Admin- Benachrichtigung ueber neue Kommentare per Jabber.

== Description ==

A fully-configurable Wordpress plugin which informs the admin about new comments through Jabber.

Ein Wordpressplugin, welches den Admin bei neuen Kommentaren per Jabber benachrichtigt und klickfreudig administrative Links des selben mitliefert.

== Installation ==

1. Upload all files to your /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in Wordpress
3. Go to the jabber options settings (Settings:Jabberbenachrichtigung)
4. Configure the options as desired
5. Have fun.

1. Alle Dateien ins Pluginverzeichnis uploaden
2. Plugin aktivieren
3. Gehe zu Jabberbenachrichtigung in den Einstellungen.
4. Jabberzugangsdaten eingeben
5. Spaß haben.


== Screenshots ==

http://www.entartete-kunst.com/jabberbenachrichtigung-ueber-neue-kommentare-reload/

== Changelog ==

= 0.99-RC2 =

* fixed a "header already sent"

= 0.99-RC1 =

* I18N
* fix some minor bugs
* waste a lot of time and coffee
* somebody was calculating pi on the server 

= 0.2 =

* Initial- Public

= 0.1 =
* Initial Alpha

