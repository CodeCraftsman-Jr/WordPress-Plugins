=== Call&Book Mobile Bar ===
Contributors: msalerno82
Tags: hotel, booking engine, hotel booking, bottom bar, call, booking, mail
Requires at least: 4.1
Tested up to: 4.2
Stable tag: 1.2
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Call&Book Mobile Bar is a smart and easy buttom bar for responsive websites with call to action: Call, send email, book.

== Description ==


Call&Book Mobile Bar is a plug-in that will help to improve conversion rates for responsive web sites.

The main buttons normally used for contact, buy a service/product  all in one: an easy and user friendly bar with call to action: call, send email, book.

= In this way the mobile user can: =

* Have quick access to all information needed (contacts, maps, etc.);
* Contact  booking centre or have access to the booking engine;
* Book an accommodation in few clicks. 

Call&Book Mobile Bar has been mainly conceived for hotels, B&B, and any accommodation property:
Mobile users need to quickly get in touch with the hotel or book an accommodation.  

Thanks to its “fixed” function, Call&Book Mobile Bar, is always visible and clickable from any web site page, allowing the user an immediate action anytime. 

This plugin is optimized for a better on line user experience. 

Compatible with WPML, the strings can be translated in any language. 

It can be integrated with Events Tracking of Google Analytics.


== Installation ==

1.	Upload Call&Book Mobile Bar folder to the /wp-content/plugins/ directory
2.	Activate the plugin through the 'Plugins' menu in WordPress
3.	Configure the plugin throught Settings -> Call&Book Mobile Bar


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png

== Changelog ==

= 1.2 =
* Added a bar preview in plugin settings

= 1.1.1 =
* Minor fixes to mobile css

= 1.1 =
* Added Google Analytics Event Tracking 
* Added Google Font Library

= 1.0 =
* Call&Book Mobile Bar! Update in order to get proper, stable updates.


