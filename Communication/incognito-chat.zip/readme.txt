===  Incognito Chat - Free Live Chat Plugin (chat roulette) ===
Contributors: Yuriy Antokhin
Donate link: http://incognito-chat.yuriyant.com/
Tags: chat, chatroulette, widget, live chat, simple chat, communication, conversation, talk 
Requires at least: 3.5.0
Tested up to: 4.2.1
Stable tag: 1.1.0
License:GPLv2 or later


Add chat to your blog. Communication without any consequences.

== Description ==

Start communicating without any consequences!
This chat roulette allows you to communicate anonymously and without registration. 
It does not save messages on the server and does not log the names or IP addresses. 
Chat adds to Google Analytics statistics the number of messages, the number of successful 
talks and the number of the opening the chat window.
Fully compatible with mobile devices.
Plugin will not impact your website’s initial-load performance thanks 
to Asynchronous Loading.

Demo: http://wp.yuriyant.com/incognito-chatroulette/


== Screenshots ==

1. Main chat window
2. Universal design 
3. Chat widget (page settings)
4. Compatible with mobile devices 

== Upgrade Notice ==
Up the version to work with update plugin.

== ChangeLog ==

= 1.1.0 =
* Change API URL

= 1.0.0 =
* Initial release



== Installation ==

* Open page: WordpressSite.com/wp-admin/plugin-install.php?tab=upload
* Upload plugin archive
* Click 'Activate'
= OR =
* Extract archive
* Upload directory with files to yur website in /wordpress/wp-content/plugins/
* Open page: WordpressSite.com/wp-admin/plugins.php
* Click "Activate" on "Incognito chat Widget"


= Configurate: =
* In admin menu click to "Incognito chat Widget"
* Select "Settings"
* Link: WordpressSite.com/wp-admin/options-general.php?page=incognito-chat-widget-options
* Select needle options