
//alert("Hello, I am working");
$j= jQuery.noConflict();
$j(document).ready(  function(){

/*$j( "#coin_dd" ).change(function() {
alert( $j( this ).val() ) ;
});
*/


});
