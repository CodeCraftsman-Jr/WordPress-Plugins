# brozzme-cookie-notification
A simple implementation of the Law on Cookies for WordPress

Cookie Notification is a WordPress plugin allows you to inform users that your site uses cookies and to comply with the EU cookie law regulations. This plugin has been developped to improve the integration with no coding skills.
