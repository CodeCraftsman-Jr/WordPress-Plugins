=== Popup Ads Management ===
Contributors: shahalom, microsolutions
Donate Link: http://microsolutionsbd.com/donate
Tags: Publish popup advertisement, Popup Ads Management, display popup by categories, display popup by category, manage ads, manage advertisements, affiliate advertising
Requires at least: 3.6
Tested up to: 4.2.2
Stable tag: 0.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Popup Ads Management plugin helps you to save your advertisement script category wise and let them show to specifica category post and category page.


== Description ==
Popup Ads Management plugin helps you to save your advertisement script category wise and let them show to specifica category post and category page. It is useful for the webmaster who like to get full attention by showing advertisement as soon as the visitor comes in to your site. More over it helps you to save and show the advertisement by your post category.


== Installation ==
1. You can download and install the Popup Ads Management plugin through the built-in Wordpress plugin installer. Alternately, download the zip file then extract and upload the '/popup-advertisements/' folder to your '../wp-content/plugins/' folder.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Update/resave the permalinks (go Settings -> Permalinks and click on the "Save Changes" button) of your site.
4. View the instructions page and enjoy popup advertisement!


== Screenshots ==
1. Add/Edit advertisement for popup
2. Popup advertisement in action on a live site [ z2a.co ]


== Changelog ==

= 0.0.4 =
* Initial beta release



== Upgrade Notice ==

