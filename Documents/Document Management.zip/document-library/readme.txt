=== Plugin Name ===
Contributors: hmayaktigranyan
Donate link: http://hmayaktigranyan.com/
Tags: document library, file library, documents, document taxonomy, files 
Requires at least: 2.8
Tested up to: 3.3.1
Stable tag: 0.1

Document Library plugin for handling documents as custom post type and its taxonomies .

== Description ==

Document Library plugin for handling documents as custom post type and its taxonomies ,and have UI for editing taxonomies.
Also have shortcode for viewing and searching documents and also widget for showing documents.

If you have suggestions for a new add-on, feel free to let me know about it on http://www.hmayaktigranyan.com . 

This plugin sponsor is http://www.huridocs.org/

== Installation ==

1. Upload the files to the `/wp-content/plugins/document-library/` directory
2. Activate the "Document Library" plugin through the 'Plugins' menu in WordPress
3. In Admin menu there will be added "Documents" menu item with sub pages.There you can manage documents ,add/edit fields for documents , change fields names and types,manage settings.  
4. In widgets there is "Document Library Widget" which will add document search box .

== Frequently Asked Questions ==

= How can be taxonomies chnaged from categories to tags? =

In Manage Fields page there is checkbox "Hierarchical" ,unchek it.

== Screenshots ==

1.Docuemnt taxonomies configuration

2.Widget view

== Changelog ==

= 0.1 =
* Adding taxonomies and custom post type "Docuemt".Widget available.


== Upgrade Notice ==

Nothing to upgrade.