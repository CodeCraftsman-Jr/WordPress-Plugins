tabindent
A TinyMCE plugin
Boone B Gorges
http://boonebgorges.com

Allows the Tab key to do normal paragraph indents when in TinyMCE. Also adds a Tab button to the interface, which does the same thing.
