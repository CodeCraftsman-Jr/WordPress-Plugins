<?php

/**
 * Deprecated.
 *
 * As of BuddyPress Docs 1.2, all functionality formerly included in the BP_Docs_Integration class
 * is handled by the BP_Docs_Component class, located in includes/component.php
 *
 * @package BuddyPress_Docs
 */

_deprecated_file( basename(__FILE__), '1.2', BP_DOCS_INCLUDES_PATH_ABS . 'component.php' );
