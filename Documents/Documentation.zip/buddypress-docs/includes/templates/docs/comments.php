<?php
/**
 * Deprecated.  Use single/comments.php instead.
 *
 * @package BuddyPress_Docs
 */

_deprecated_file( basename(__FILE__), '1.2', BP_DOCS_INCLUDES_PATH_ABS . 'templates/docs/single/comments.php' );
require_once ( BP_DOCS_INCLUDES_PATH . 'templates/docs/single/comments.php');
?>