<?php bp_docs_locate_template( 'index.php', true ) ?>
