edButtons[edButtons.length] =
new edButton('grpdocscomparison'
	,'gd_comparison'
	,'[grpdocscomparison guid_redline="" guid_embed="'
	,'" width="600" height="800"]'
	,'1'
);
