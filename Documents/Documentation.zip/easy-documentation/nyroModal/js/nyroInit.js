(function( $ ) {
    $(function() {
        $('.nyroModal').nyroModal();
    });
})( jQuery );