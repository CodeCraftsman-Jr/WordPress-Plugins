Simple-Documentation
====================

Wordpress plugin

Find the stable version on the Wordpress Repository: [Simple Documentation](http://wordpress.org/plugins/client-documentation/)