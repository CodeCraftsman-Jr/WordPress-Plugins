edButtons[edButtons.length] =
new edButton('gd_annotation'
	,'gd_annotation'
	,'[grpdocsannotation file="'
	,'" width="500" height="600" email="" can_view="True" can_annotate="True" can_download="True" can_export="True"]'
	,'1'
);