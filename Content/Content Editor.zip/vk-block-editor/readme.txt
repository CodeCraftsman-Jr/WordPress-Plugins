=== Plugin Name ===
Contributors: kurudrive
Donate link: http://bizvektor.com/
Tags: editor,TinyMCE
Requires at least: 2.0.2
Tested up to: 3.4
Stable tag: 0.1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This pulugin is possible to Block layout on Tinymce editor.

== Description ==

This pulugin is possible to Block layout on Tinymce editor.
If you use this plugin that you can layout to float image, collayout, add section margin...etc 

= Translators =
* Japanese(ja) - [Hidekazu Ishikawa](http://twitter.com/kurudrive)

* @[kurudrive](http://twitter.com/kurudrive) on twitter
* [Hidekazu Ishikawa](https://www.facebook.com/hidekazu.ishikawa) on facebook

== Installation ==

1. Upload `vk-editor` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

= Can this plugin to edit flont end? =

I will upgrade to flont end edit. Please wait a moment. 

= Can builted block was drag and drop? =

Sorry, please wait a moment too. m(T-T)m

== Screenshots ==

1. Layout block built image. Add padding to block after the build. 

== Changelog ==

= 0.1.0.0 beta =
* beta version fitst release.

= 0.1.0.5 beta =
* bug fix

== Upgrade Notice ==

Nothing.