=== Plugin Name ===
Contributors: jamiedust
Donate link: http://jamiedust.net
Tags: tinymce, formats, blockformats, editor
Requires at least: 2.7
Tested up to: 3.2
Stable tag: 1.1

This plugin allows you to select which elements are used in the formats dropdown on the TinyMCE editor.

== Description ==

This plugin allows you to select which elements are used in the formats dropdown on the TinyMCE editor.

Accepted elements are: p,h1,h2,h3,h4,h5,h6,div,address,pre,code,samp

Any problems please [get in touch](http://jamiedust.net "Jamie Dust")

== Installation ==

1. Unzip the archive and upload the folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to 'TinyMCE Blockformats' in the settings menu
1. Enter html elements in the box provided, seperated by a comma, then click save changes

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==