=== Plugin Name ===
Contributors: totoloco_
Donate link: http://www.ushcompu.com.ar/
Tags: captcha, figlet, math, ascii
Requires at least: 2.3
Tested up to: 2.8
Stable tag: trunk

figlet math challenge, captcha replacement, based on TryMath php class and phpFiglet

== Description ==

figlet math challenge, captcha replacement, based on TryMath php class and phpFiglet.

trymath is an accessible way to secure your comments. no image, no gd, only ascii art math using phpFiglet.

phpFiglet is licensed under GPL.

trymath is licensed under Sisterware.

phpFiglet, and trymath, supports more figlet fonts :)

[fonts](http://www.figlet.org/fontdb.cgi "fonts")

[http://www.ushcompu.com.ar/2009/03/30/math-challenge-no-captcha/](http://www.ushcompu.com.ar/2009/03/30/math-challenge-no-captcha/ "homepage")

[Click here](http://www.ushcompu.com.ar/2009/03/30/math-challenge-no-captcha/ "trymath demo") to see trymath in action.

== Installation ==

1. Upload `trymath` directory content to `/wp-content/plugins/trymath/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What is sisterware? =

[Sistereware](http://spazioinwind.libero.it/unforgiven/sisterware.htm "sisterware")

= What is the plugin homepage? =

[http://www.ushcompu.com.ar/2009/03/30/math-challenge-no-captcha/](http://www.ushcompu.com.ar/2009/03/30/math-challenge-no-captcha/ "homepage")

= What is figlet? =
[http://www.figlet.org/](http://www.figlet.org/ "figlet")

== Screenshots ==

1. trymath on opera ([Try the live demo](http://www.ushcompu.com.ar/2009/03/30/math-challenge-no-captcha/ "trymath Demo"))
1. trymath on w3m
