=== Plugin Name ===
Contributors: rockschtar
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=B2WSC5FR2L8MU
Tags: editor, html, font, admin, wpadmin, wordpress
Requires at least: 2.8.6
Tested up to: 4.2
Stable tag: 1.8.1

Brings the old HTML-Editor font from Wordpress 3.1x back to WordPress 3.2 and higher

== Description ==

Brings the old HTML-Editor font from Wordpress 3.1x back to WordPress 3.2 and higher

== Installation ==

1. Upload the whole plugin-folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enjoy the "old" editor font.

== Changelog ==

= 1.4 =
* readme.txt added