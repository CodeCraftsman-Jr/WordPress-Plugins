tinyMCE.addI18n('en.span_dlg',{
title:"Insert HTML span text",
desc:"Insert HTML span text"
});
