<?php if (!headers_sent()) { header('Location: /'); exit(); }
$strings = array(
__('no', 'content-switcher'),
__('yes', 'content-switcher'));