<?php

$path = dirname(__FILE__).'/'.$mce_locale.'_dlg.js';
$strings = file_get_contents($path);

?>
