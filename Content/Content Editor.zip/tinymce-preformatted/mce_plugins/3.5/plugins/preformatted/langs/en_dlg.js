tinyMCE.addI18n('en.preformatted_dlg',{
title:"Insert preformatted text",
desc:"Insert preformatted text"
});
