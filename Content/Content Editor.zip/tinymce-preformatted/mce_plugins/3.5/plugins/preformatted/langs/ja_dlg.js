tinyMCE.addI18n('ja.preformatted_dlg',{
title:"整形済みテキストを挿入",
desc:"整形済みテキストを挿入"
});
