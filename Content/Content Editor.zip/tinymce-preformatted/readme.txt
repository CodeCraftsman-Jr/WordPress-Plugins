=== TinyMCE Preformatted ===
Contributors: miyauchi
Tags: tinymce, Visual Editor, pre, preformatted
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 0.6.0

TinyMCE Preformatted plugin will enable to insert preformatted text like &lt;pre&gt;...&lt;/pre&gt; to WordPress Visual Editor.

== Description ==

TinyMCE Preformatted plugin will enable to insert preformatted text like &lt;pre&gt;...&lt;/pre&gt; to WordPress Visual Editor.

This plugin add [PRE] button to Visual Editor, you can input HTML, PHP, Perl and other sources and then HTML will be escaped.

You will be very happy to write HTML, PHP and other program in post.

* [Plugin Homepage](http://firegoby.theta.ne.jp/wp/mce_preformatted) (Japanese)
* [Support](http://wordpress.org/tags/tinymce-preformatted)

= Translators: =

* Japanese(ja) - [Takayuki Miyauchi](http://firegoby.theta.ne.jp/)

You can send your own language pack to me.


== Installation ==

* A plug-in installation screen is displayed on the WordPress admin panel.
* It installs it in `wp-content/plugins`.
* The plug-in is made effective.

== Screenshots ==

1. Visual Editor.

== Credits ==

This plug-in is not guaranteed though the user of WordPress can freely use this plug-in free of charge regardless of the purpose.
The author must acknowledge the thing that the operation guarantee and the support in this plug-in use are not done at all beforehand.

== Contact ==

email to miya[at]theta.ne.jp
