<div class="updated">
	<p><?php _e( 'Batches deleted!', 'sme-content-staging' ); ?></p>
</div>