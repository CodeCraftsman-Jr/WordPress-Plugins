<div class="wrap">
	<h2>
		<?php _e( 'History' ); ?>
		<p><?php _e( 'List of batches previously deployed to production environment.', 'sme-content-staging' ); ?></p>
	</h2>
	<?php $table->display(); ?>
</div>