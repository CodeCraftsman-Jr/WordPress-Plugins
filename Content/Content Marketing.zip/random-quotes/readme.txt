=== Random Quotes ===
Contributors: srcoley
Tags: quotes, quotations
Donate link: http://twitter.com/srcoley
Requires at least: 2.0.2
Tested up to: 3.0.1
Stable tag: trunk
Version: 1.3

Let's users manage and display quotations anywhere within their WordPress template.

== Description ==

Let's users manage and display quotations anywhere within their WordPress template.

All documentation is in the Random Quotes admin page

== Installation ==

1. Upload the `random-quotes` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Random Quotes admin page to for further instructions

== Frequently Asked Questions ==

= Is this plugin widget ready? =

No, this plugin does not support widgets in this version. Perhaps the next.

== Screenshots ==

1. This is a portion of the admin section for Random Quotes.
2. This is an implementation of the Random Quotes plugin.

== Changelog ==

= 1.0 =
* This is the first version
= 1.1 =
* Fixed "You do not have sufficient permissions to access this page" bug
= 1.2 =
* Fixed security bug
= 1.3 =
* Changed the quotation and quotation2 fields to longtext to support longer quotations

== Upgrade Notice ==

= 1.0 =
There's no new version to upgrade to!
= 1.1 = 
Fixes the "You do not have sufficient permissions to access this page" bug
= 1.2 =
Fixes a security bug
= 1.3 =
Update now and you'll be able to store longer quotations!
