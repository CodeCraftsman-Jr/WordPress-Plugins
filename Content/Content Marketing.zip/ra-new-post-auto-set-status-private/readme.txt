=== RA - New Post Auto Set Status "Private" ===
Contributors: skuramoto
Tags: rains, PostStatus, Default, Private, Publish, Japanese
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0.3

The status of the post exhibited directly from new post is compulsorily changed into "private".

== Description ==
The status of the post exhibited directly from new post is compulsorily changed into "private".

== Installation ==
1. Upload the "ra-newpost-status-auto-private" folder to the "/wp-content/plugins/" directory.
2. Activate the plugin through the Plugins menu in WordPress.

== Changelog ==

= 1.0.3 =
* Compatibility Check.

= 1.0.2 =
* Version Number fix.

= 1.0.1 =
* Contributors name fix.

= 1.0.0 =
* Registration to the plug-in directory.
* First release.
