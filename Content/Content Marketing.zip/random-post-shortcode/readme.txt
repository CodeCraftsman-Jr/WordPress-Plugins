=== Random Post Shortcode ===
Contributors: PowieT
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UST438WYW6HNJ
Tags: random, post, widget, shortcode
Requires at least: 2.8
Tested up to: 4.2
Stable tag: 1.0.1
License: GPLv2

Random Post Shortcode and Widget

== Description ==
Insert shortcode [random-post] to a page or post to display a random post from all of your posts.
Also provides a widget to display the excerpt from a random post (published only).

= Support =
Support Forum @ [powie.de](http://goo.gl/lfR7B)

== Installation ==

1. Upload this Plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Remove plugin ==

1. Deactivate plugin through the 'Plugins' menu in WordPress
2. Delete plugin through the 'Plugins' menu in WordPress

== Screenshots ==
not available

== Frequently Asked Questions ==
not available

= How can I support you? =

Post a comment on [powie.de Forum](http://forum.powie.de)

= What is the plugin page?  =

[Powie](http://www.powie.de)

= Where do I post my feedback? =

Post it at my Forum: [powie.de Forum](http://forum.powie.de)

== Changelog ==
= 1.0.1 (19.01.2013) = 
* New: Random Post Widget

= 1.0.0 (15.01.2013) =
* first version with all required stuff by me

== Upgrade Notice ==
Just Install.

== To do ==
.... you tell me