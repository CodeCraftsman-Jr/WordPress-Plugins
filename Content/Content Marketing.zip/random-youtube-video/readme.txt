=== Random YouTube Video ===
Contributors: Shobba, zigvt85, roycegracie
Tags: youtube, random, video, widget, sidebar
Requires at least: 2.3
Tested up to: 4.0
Stable tag: trunk

This sidebar widget shows a random youtube video from your own list.

== Description ==

This plugin adds a sidebar widget to your wordpress, which shows a random youtube video with own title from a list which you can manage in the admin area.

I hope you'll enjoy it, feel free to leave a comment :-)

<strong>Demo:</strong> Down Check ScreenShots!

<strong>Tested with Windows and Linux and with the latest wordpress as of now 4.1!</strong>

<strong>Upgrading Info:</strong> When updating you should be able to install as an upgrade now without having to re-install everything hopefully!

== Installation ==

1. Upload `youtubevideo.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Manage your video list at 'Options -> Random YouTube Videos'
4. Put the new widget into your sidebar

== Screenshots ==

1. This is the widget in your sidebar
2. The page in your admin area
3. Adds widget to sidebar and enables AutoPlay feature or not!
As of 2.1 this is a new design.
4. Now you can add more then 1 Random YouTube Widget!

== Changelog ==
* 1.0 - first release. Widget can be used, videos can be managed
* 1.1 - some bugs fixed, e.g. new line after title
* 1.2 - subfolder bug fixed, you can now use the plugin in a subfolder
* 1.3 - Another bugfix. Add row button should work for everyone. Thanks to Cody
* 1.3.5 - I hate bugs :P Add row button should definitively work now. Sorry ._.
* 1.3.8 - I hate bugs AND I hate the Internet Explorer -.-" Apologies for the next bugfix update ._.
* 1.5 - Now you can choose the width of the displayed video and (optionally) put a link to my blog below this video
* 1.7 - Fixed language files and patched the broken youtube thanks to roycegracie! Also added the option to the youtube widget
were the user can add an option to enable AutoPlay or not. Tested in Firefox and IE!
* 1.8 - Fixed the widget now it is more modernized which means you can add as many widgets as you want to your sidebar! Community 
suggestion! This has been tested in Firefox and IE and with the latest wordpress!
* 1.9 - Fixed the widget now it is more modernized which means you can add as many widgets as you want to your sidebar! Community 
suggestion! This has been tested in Firefox and IE and with the latest wordpress! I also made a new page for the widget to make it
cleaner for any developers that like to add or delete stuff :)! No more error log!
* 2.0 - Cleaned up the entire code now in DIVS no more tables. The admin page looks a lot different now view
the screen shot on the plugin page. Fixed height so now you can set your own custom height instead of having
it automatically set with the width. Removed screen shots that are not needed any more save more space for users.
Also last but not least I added a preview video on the admin page as promised.
* 2.1 - Added a new style sheet. So users could keep there changed colors during updates. Fixed most of the rare bugs. 
Updated the YouTube player this has the latest iframe version. Removed auto width/height did not work that great on all 
websites now you can choose in pixles! Updated some of the php code. This caused php errors and people who are hosted with 
Windows could not activate the plugin. Added a checkbox for AutoPlay option instead of manually typing it in. This should
work 100% on release tested with version 4.0 and up!
* 2.2 - Fixed rare bug made the video disappear I believe it had to do with the data code at the end.
* 2.3 - Code clean up and fixes.
* 2.4 - More code clean up and fixes and old commented code removed. You can still find on older releases.
* 2.4.1 - Fixed database issue if I changed the sql names they wouldn't update. When you just upgrade the software now it should.
I also fixed missing strings thanks to a community suggestion they were missing the following...''New big update coming this spring!