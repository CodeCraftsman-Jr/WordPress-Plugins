=== RandomPosts Widget ===
Contributors: Dan Mahon
Tags: widget, posts, show random posts,sidebar,random,posts,display posts,list posts,visitors,index,seo,seo widget,seo plugin
Requires at least: 3.0.1
Tested up to: 3.3.1
Stable tag: 1.2

Displays random psots on the sidebar of your blog, ideal for keeping visitors on your site longer and offering more reading.

== Description ==

Displays random psots on the sidebar of your blog, ideal for keeping visitors on your site longer and offering more reading.

This widget is also ideal for SEO as it increases the number of pages interlinked on your site, helping the search engine spiders crawl your site more efficiently. 

Features:

*   configurable number of displayed records;
*   conclusion quote, or just the title;
*   display in a list or any other form (the tags are set).

== Installation ==

1. Unzip files.
2. Upload 'randomposts-widget' to the '/wp-content/plugins/' directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Activate the widget through the 'Widgets' menu in WordPress

== Frequently Asked Questions ==

= Can I customize the look of the widget? =

Yes, look, you can customize the output to record headers, or headers and citations. Also set up html tags to each entry.

== Screenshots ==

1. 'RandomPosts Widget'in use.
2.  Options for adjusting the widget.

== Changelog ==

= 1.0.0 =
* The first version of the widget
