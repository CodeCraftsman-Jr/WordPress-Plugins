=== Random Tumblr ===
Contributors: V.J.Catkick
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2933164
Tags: tumblr, random, sidebar
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 4.3

Sidebar widget which displays one photo from your tumblr entries randomly. This widget pulls only photo image which you uploaded and/or rebloged.

== Description ==

Sidebar widget which displays one photo from your tumblr entries randomly. This widget pulls only photo image which you uploaded and/or rebloged.

== Installation ==

Place the php file in your /wp-content/plugins/ directory
and activate through the administration panel, and then go to the widget panel and
drag it to where you would like to have it!


== Screenshots ==

1. Main View
2. Option Panel

