=== Random Joke ===
Contributors: GigaCart
Donate link: 
Tags: joke, jokes, random, widget, sidebar, random jokes, randomness, just for fun
Requires at least: 2.8
Tested up to: 3
Stable tag: 1.0.5

Random jokes widget helps you display random jokes everywhere on your blog. Over 25,000 jokes in 75 categories. Cheer up your blog readers :)

== Description ==

Widget random joke displays random categorized jokes on your blog. There are over 25,000 jokes in 75 categories. Jokes are saved on our database, so you don't need to have space for all that information. Widget does not use database, but caches data to a file. 

The main features:

* You can add as many widgets as you need, each with it's individual set of options and display one joke from all categories or just selected ones.

* You can set maximum jokes length in words and display only short jokes for example.

== Installation ==

1. Upload the content of random-joke.zip to a dedicated folder in your `/wp-content/plugins/` directory.
2. Change directory cache permissions to 777.
3. Activate the plugin on the 'Plugins' page in WordPress.
4. Go to Appearance -> widgets and drag Jokes widget to selected widget area. Press ctrl + click to select multiple jokes categories. Joke length limit (in words) allows you to set the maximum length of a joke. Widget caches data to a file. Setting "Cache time in seconds" allows you to set for how long the same joke is showed on the site. 

== Changelog ==

= 1.0.5 =
* Fix : Display direct error message instead of fatal error when facing connection problems to our database

= 1.0.4 =
* Update : Updated widget's default parameters values
* Update : Increased connection timeout value to our database

= 1.0.3 =
* Fix : Removed PHP warning message, which was displayed in some cases
* Update : Changed widget's rendering function

= 1.0.2 =
* Update : Changed widget's rendering function

= 1.0.1 =
* Update : Updated plugin description
* Update : Optimized widget's initialization function
