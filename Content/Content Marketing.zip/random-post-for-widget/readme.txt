=== Plugin Name ===
Contributors: 		shashidharkumar
Plugin Name:       	Random Post for Widget
Plugin URI:        	http://www.shashidharkumar.com/random-post-widget-wordpress/
Author URI:        	http://www.shashidharkumar.com/
Author:            	Shashidhar Kumar
Donate link: 		http://www.shashidharkumar.com/donate/
Tags: 			plugin, posts, random, random post, random posts, simple plugin, widget, Wordpress
Requires at least: 	4.0
Tested up to: 		4.2.1
Stable tag: 		trunk
Version:           	3.1
License: 		GPLv2 or later
License URI: 		http://www.gnu.org/licenses/gpl-2.0.html

This simple plugin is a widget that displays a list of random posts on your sidebar. You can exclude certain posts by ID.

== Description ==

This simple plugin is a widget that displays a list of random posts on your sidebar. You can exclude certain posts by ID.

== Installation ==

How to install the plugin (Random Posts for widget) and get it working.

1. Upload random-post-for-widget.zip to the /wp-content/plugins/ directory
2. Activate the plugin through the �Plugins� menu in WordPress
3. Use your �Appearance/Widgets� settings configure
4. See Random Post in widget area than drag and configure

== Configuration ==
1. Widget Title: the title of the widget
2. No of Post: Number of random posts you would like to be display


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png