=== Random Christmas Fact Widget ===


Contributors: monkeymays
Donate Link: http://christmaswebmaster.com/random-christmas-fact-widget/
Tags: Random Christmas Fact, santa claus, holiday, christmas, widget-only, widget, sidebar
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Displays a Random Christmas Fact in your sidebar. 

== Description ==

The Random Christmas Fact Widget displays one of 40 random Christmas facts in your sidebar each time a visitor refreshes the page. 

The Random Christmas Facts will appear in your sidebar widget without CSS formatting to blend perfectly into your site.

For more information about the Random Christmas Fact widget, visit [ChristmasWebmaster.com](http://christmaswebmaster.com/).


== Installation ==
1. Upload plugin and install.
2. On the plugins panel activate the Random Christmas Fact Widget.
3. In the widgets menu drag the Random Christmas Fact Widget to your sidebar.
4. The Random Christmas Fact Widget displays one of 40 random Christmas facts each time your page is loaded.

== Changelog ==

= Version 1 Released 2/23/2015 =

 