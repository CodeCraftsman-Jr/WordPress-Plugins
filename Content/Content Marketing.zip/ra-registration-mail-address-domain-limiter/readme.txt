=== RA - Registration Mail Address Domain Limiter ===
Contributors: skuramoto
Tags: rains, Email, Userregister, Japanese
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.2.8

The domain which can be used for user's registration can be restricted.

== Description ==
The domain which can be used for user's registration can be restricted.

== Installation ==
1. Upload the "ra-register-mail-domain-limiter" folder to the "/wp-content/plugins/" directory.
2. Activate the plugin through the Plugins menu in WordPress.
3. Plug-in settings page link "RMDL" to will be added at "Settings". click to open settings page.

== Changelog ==

= 1.2.8 =
* Compatibility Check.

= 1.2.7 =
* bugfix
* Handling in an under bar in an exclusion address list is fixed.

= 1.2.6 =
* debug

= 1.2.5 =
* Version Number fix.

= 1.2.4 =
* Contributors name fix.

= 1.2.3 =
* Registration to the plug-in directory.
* First release.
