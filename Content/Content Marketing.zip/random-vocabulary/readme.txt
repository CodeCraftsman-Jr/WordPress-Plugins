===  Random Vocab ===
Contributors: rakshithvbharani@gmail.com
Tags: vocabulary,admin, admin area, learn vocabulary, vocabulary on the go,learn new words  
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 1.0.1
License: GPLv2 

Learn New words while developing your website.

== Description ==

This plugin shows new words randomly at the admin's dashboard page below the admin bar.
Whats the big deal here? Well, you can learn new words on the go, while developing your
cool website.

Right Now there are just 100 words,which will be updated. 
This Plugin is pretty much based on Hello Dolly.

Words are taken from http://www.majortests.com/ 

== Installation ==

1. Upload `Random-Vocab` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
Before you want to ask anything please be aware that :  
This Plugin is pretty much based on Hello Dolly.
Words taken from http://www.majortests.com/ 


== Screenshots ==
1. Plugin in action, which is in conjunction with Hello Dolly.


== Changelog ==

= 1.0 =
* First commit to wordpress.org

== Upgrade Notice ==
None


