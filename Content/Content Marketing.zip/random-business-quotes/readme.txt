=== Random Business Quotes ===
Contributors: blnd
Tags: random quotes,business quotes, quotes, quote of the day, business, startup, entrepreneur, random, daily, startup quotes
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Random Business Quotes plugin is a widget that displays responsive business and startup quotes on the sidebar/widgets area.

== Description ==

The Random Business Quotes plugin is a widget that displays business and startup quotes on the sidebar or any widget area.

The quotes inherit your site's styles, and are responsive and made to fit in any screen size.

Quotes are "random" because they're the latest daily entry retrieved from http://www.mentorbit.com/widget-quote.php.

== Installation ==

Install, activate, drag the Random Business Quotes widget to the widgets area and click save.


1. Upload the Random Business Quotes folder to the '/wp-content/plugins/' directory, OR in the admin area, go to Plugins > Add New. Search for Random Business Quotes and click Install Now.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. In Appearance > Widgets, drag Random Business Quotes into the widgets/sidebar area and click save.

== Frequently Asked Questions ==

= How do I make a billion dollars? =

If you want to build a billion-dollar internet company, take a human desire, preferably one that has been around for a really long time, identify that desire and use modern technology to take out steps. - Evan Williams (Twitter Co-founder), business ideas#29

== Screenshots ==

1. Business quotes appear in the widgets/sidebar area.
2. After installing and activating, simply drag Random Business Quotes into the widgets area.

== Changelog ==

= 1.0 =
* First version