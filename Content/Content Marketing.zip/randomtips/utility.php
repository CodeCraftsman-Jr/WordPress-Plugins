<?php
function utilityhello(){
	echo "utility";
}