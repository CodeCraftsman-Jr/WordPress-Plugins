=== Plugin Name ===
Contributors: josemarques
Tags: design, art direction, css, js
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows custom styling and interaction for posts and pages

== Description ==

Sometimes you need some extra styling and TinyMCE does not allow a lot.
This plugin allows you to add per post or page CSS and Javascript.

== Installation ==

1. Upload the plugin contents to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. All set!

== Frequently Asked Questions ==

== Screenshots ==

1. Two extra fields on your post and page screen

== Changelog ==

= 1.0 =
* Bumped up the version for release
= 0.3 =
* Javascript code apoended to the footer 
= 0.2 =
* Added Javascript 
= 0.1 =
* First working draft 
