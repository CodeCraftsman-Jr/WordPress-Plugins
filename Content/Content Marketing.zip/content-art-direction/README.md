# Content Art Direction
WordPress plugin that allows custom styling and interaction for posts and pages

## Licence
GNU General Public License, version 2
