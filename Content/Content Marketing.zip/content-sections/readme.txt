=== Content Sections ===
Contributors: beatpanda
Donate link: http://gaffta.org/support-us
Tags: comments, spam
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create anchor links and tables of contents easily!

== Description ==

Parses shortcodes in your content to produce an anchor link menu. Allows theme authors to overload the template for both the sections and the table of contents. Registers an include for waypoints.js in case theme authors want to use it.
