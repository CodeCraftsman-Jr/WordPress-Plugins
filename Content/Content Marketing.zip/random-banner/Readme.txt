=== Random Banner ===
Contributors: vinoth06, buffercode
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7DHAEMST475BY
Tags: banner, widget, advertisement, ads, banner ads, widget ads, image ads, image widget, ads upload, upload advertisement, upload widget ads
Requires at least: 3.3
Tested up to: 4.2
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Random Banner WordPress plugin provides users with high level of flexibility to show the banner ads randomly

== Description ==
Random Banner WordPress plugin provides users with high level of flexibility to show the banner ads randomly

Through this plugin admin can,

* Admin can able to upload 10 banners or banner links
* Easy to add individual link for each banner, so that when user click the link will be open
* Banners will be displayed randomly based on the number of banners uploaded in setting page
* Banner can be placed using widget, so that admin has more flexibility to add the banner where ever that theme supports widget.
* Custom title can be added for that banner in widget location.

For more information : http://buffercode.com/random-banner-wordpress-plugin/

v 1.2 (27042015)

* Missing title removed layout - Bug Fixes

v 1.1.2 (28042014)

* Support WordPress 3.9


v 1.1.2 (10042014)

* Bug fixes - Banner Aligned Center

v 1.0

* Public release

== Installation ==

1. Upload the "random-banner" directory to the plugins directory.
2. Go to the plugins setting page and activate "Random Banner"
3. Go to settings --> Random Banner --> Upload banner by image or URL and add the link for each image 
4. Go to Appearance --> Widget --> Drag Random Banner Widget to appropriate location
5. Add the custom title.
6. Do save.

For more information : http://buffercode.com/random-banner-wordpress-plugin/

== Changelog ==
= 1.2 =
* Missing title removed layout - Bug Fixes

= 1.1.2.1 =
* Support WordPress 3.9

= 1.1.2 =
* Bug fixes - Banner Aligned Center

= 1.0 =
* Public release

For more information : http://buffercode.com/random-banner-wordpress-plugin/

== Screenshots ==
1. Random banner 100x100 image ads output
2. Random Banner Setting page
3. Random banner 300x250 image ads output
4. Random banner 160x600 image ads output