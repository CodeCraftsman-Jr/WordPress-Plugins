=== Random Phobia ===
Contributors: fkreijmborg
Donate link: http://www.randomphobia.com/donate/
Tags: random, phobia, quote
Requires at least: 2.5
Tested up to: 2.7.1
Stable tag: 1.0

Show off your phobias!

== Description ==

Random Phobia lets you put a single phobia from a textfile into your wordpress blog. 

Features listed below:

*   530 names of fear in the textfile
*   one tiny snippet of php-code is enough to share the angst
*   fully customizable through CSS

== Installation ==

1. Download the plugin zip file.
2. Unzip.
3. Upload the [wp-random-phobia] folder to your [/wp-content/plugins/] directory.
4. Activate the plugin through the Plugins menu in WordPress.
5. Place <?php random_phobia('before', 'after'); ?> in your template at any place and style it through CSS - you should create a div first!

== Frequently Asked Questions ==

= Will there be any German, Spanish, etc language files? =

Yes, of course. You are welcome to help me translate the textfile [phobias.txt] into any language that you desire.

== Screenshots ==

Take a look at the plugin homepage!