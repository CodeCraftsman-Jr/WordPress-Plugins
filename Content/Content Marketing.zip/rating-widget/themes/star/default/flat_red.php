<?php
    $theme_options = new stdClass();
    $theme_options->type = "star";
    $theme_options->style = "flat_red";

    $theme = array(
        "name" => "star_flat_red",
        "title" => "Flat Red Stars",
        "options" => $theme_options
    );
?>
