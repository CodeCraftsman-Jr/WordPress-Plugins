<?php
    $theme_options = new stdClass();
    $theme_options->type = "star";
    $theme_options->style = "flat_blue";

    $theme = array(
        "name" => "star_flat_blue",
        "title" => "Flat Blue Stars",
        "options" => $theme_options
    );
?>
