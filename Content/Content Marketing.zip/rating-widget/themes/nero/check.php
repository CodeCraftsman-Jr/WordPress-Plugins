<?php
    $theme_options = new stdClass();
    $theme_options->type = "nero";
    $theme_options->style = "check";
        
    $theme = array(
        "name" => "check",
        "title" => "Checkboxes (by Trevor H.)",
        "options" => $theme_options
    );
?>
