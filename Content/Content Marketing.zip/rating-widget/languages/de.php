<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Schrecklich",
        "ratePoor" => "Schlecht",
        "rateAverage" => "Durchschnittlich",
        "rateGood" => "Gut",
        "rateExcellent" => "Ausgezeichnet",
        "rateThis" => "Bewertung abgeben",
        "like" => "Ich mag es",
        "dislike" => "Ich mag nicht",
        "vote" => "Abstimmen",
        "votes" => "Stimmen",
        "thanks" => "Vielen Dank",
        "outOf" => "von",
        "weRecommend" => "Wir empfehlen",
    );
?>