<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Baisu",
        "ratePoor" => "Blogas",
        "rateAverage" => "Vidutinis",
        "rateGood" => "Geras",
        "rateExcellent" => "Puikus",
        "rateThis" => "Įvertink šitą",
        "like" => "Patinka",
        "dislike" => "Nepatinka",
        "vote" => "Balsuoti",
        "votes" => "Balsų",
        "thanks" => "Ačiū",
        "outOf" => "iš",
        "weRecommend" => "Rekomenduojame",
    );
?>
