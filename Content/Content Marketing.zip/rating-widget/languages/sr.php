<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Užasno",
        "ratePoor" => "Slabo",
        "rateAverage" => "Osrednje",
        "rateGood" => "Dobro",
        "rateExcellent" => "Odlično",
        "rateThis" => "Oceni ovo",
        "like" => "Dopada",
        "dislike" => "Ne dopada",
        "vote" => "Glasaj",
        "votes" => "Glasovi",
        "thanks" => "Hvala",
        "outOf" => "од",
        "weRecommend" => "Препоручујемо",
    );
?>
