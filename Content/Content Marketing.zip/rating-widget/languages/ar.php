<?php
    $dir = "rtl";
    $hor = "left";
    $dictionary = array(
        "rateAwful" => "مروع",
        "ratePoor" => "سيئة",
        "rateAverage" => "متوسط",
        "rateGood" => "جيد",
        "rateExcellent" => "ممتاز",
        "rateThis" => "معدل هذا",
        "like" => "مثل",
        "dislike" => "لا أحب",
        "vote" => "التصويت",
        "votes" => "الأصوات",
        "thanks" => "شكرا",
        "outOf" => "من أصل",
        "weRecommend" => "ونحن نوصي",
    );
    
    $numbers = array('۰', '۱', '۲', '۳', '۴', '٥', '٦', '۷', '۸', '۹');
