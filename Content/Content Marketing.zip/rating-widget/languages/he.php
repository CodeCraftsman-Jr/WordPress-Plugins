<?php
    $dir = "rtl";
    $hor = "left";
    $dictionary = array(
        "rateAwful" => "גרוע",
        "ratePoor" => "רע",
        "rateAverage" => "ממוצע",
        "rateGood" => "טוב",
        "rateExcellent" => "מצויין",
        "rateThis" => "דרג",
        "like" => "בעד",
        "dislike" => "נגד",
        "vote" => "הצבעה",
        "votes" => "הצבעות",
        "thanks" => "תודה",
        "outOf" => "מתוך",
        "weRecommend" => "אנו ממליצים",
    );
?>
