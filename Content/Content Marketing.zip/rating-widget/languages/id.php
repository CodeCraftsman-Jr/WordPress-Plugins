<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Mengerikan",
        "ratePoor" => "Jelek",
        "rateAverage" => "Sedang",
        "rateGood" => "Baik",
        "rateExcellent" => "Bagus Sekali",
        "rateThis" => "Beri Nilai",
        "like" => "Suka",
        "dislike" => "Tidak suka",
        "vote" => "Pilih",
        "votes" => "Pemilihan",
        "thanks" => "Terima Kasih",
        "outOf" => "dari",
        "weRecommend" => "Kami Merekomendasikan",
    );
?>
