<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Kamala",
        "ratePoor" => "Huono",
        "rateAverage" => "Keskinkertainen",
        "rateGood" => "Hyvä",
        "rateExcellent" => "Erinomainen",
        "rateThis" => "Arvioi tämä",
        "like" => "Tykkää",
        "dislike" => "Ei tykkää",
        "vote" => "Ääni",
        "votes" => "Ääntä",
        "thanks" => "Kiitos",
        "outOf" => "ulos",
        "weRecommend" => "Suosittelemme",
    );
?>
