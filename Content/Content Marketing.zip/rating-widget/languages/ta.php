<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "மிக மிக‌ ந‌ன்று",
        "ratePoor" => "மிக‌வும் ந‌ன்றாக‌யில்லை",
        "rateAverage" => "ஏற்றுக்கொள்ளாம்",
        "rateGood" => "ந‌ன்று",
        "rateExcellent" => "மிக‌ ந‌ன்று ",
        "rateThis" => "வாக்க‌ளிக்க‌",
        "like" => "பிடித்திருக்கின்ற‌து",
        "dislike" => "பிடிக்க‌வில்லை",
        "vote" => "வாக்கு",
        "votes" => "வாக்குக‌ள்",
        "thanks" => "ந‌ன்றி",
        "outOf" => "வெளியே",
        "weRecommend" => "நாங்கள் சிபாரிசு",
    );
    
    $numbers = array('௦', '௧', '௨', '௩', '௪', '௫', '௬', '௭', '௮', '௯');
