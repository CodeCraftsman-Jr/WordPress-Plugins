<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Groaznic",
        "ratePoor" => "rau",
        "rateAverage" => "Mediu",
        "rateGood" => "Bun",
        "rateExcellent" => "Excelent",
        "rateThis" => "Apreciaza",
        "like" => "Imi place",
        "dislike" => "Nu-mi place",
        "vote" => "Voteaza",
        "votes" => "Voturi",
        "thanks" => "Multumim",
        "outOf" => "din",
        "weRecommend" => "Vă recomandăm",
    );
?>
