<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "ひどい",
        "ratePoor" => "悪い",
        "rateAverage" => "平均",
        "rateGood" => "良い",
        "rateExcellent" => "優れた",
        "rateThis" => "このダウンロードを評価",
        "like" => "いいね！",
        "dislike" => "嫌い",
        "vote" => "投票",
        "votes" => "投票",
        "thanks" => "ありがとうございます",
        "outOf" => "問題外",
        "weRecommend" => "オススメ",
    );

//    $numbers = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');