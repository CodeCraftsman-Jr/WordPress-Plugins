<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Strašný",
        "ratePoor" => "Slabý",
        "rateAverage" => "Priemerný",
        "rateGood" => "Dobrý",
        "rateExcellent" => "Výborný",
        "rateThis" => "Hodnotenie",
        "like" => "Páči sa mi to",
        "dislike" => "Nepáči sa mi to",
        "vote" => "Hlas",
        "votes" => "Hlasy",
        "thanks" => "Ďakujem",
        "outOf" => "z",
        "weRecommend" => "Odporúčame",
    );
?>
