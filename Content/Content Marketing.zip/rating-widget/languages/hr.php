<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Strašno",
        "ratePoor" => "Loše",
        "rateAverage" => "Prosječno",
        "rateGood" => "Dobro",
        "rateExcellent" => "Izvrsno",
        "rateThis" => "Ocijenite ovo",
        "like" => "Sviđa mi se",
        "dislike" => "Ne sviđa mi se",
        "vote" => "Glas",
        "votes" => "Glasova",
        "thanks" => "Hvala",
        "outOf" => "od",
        "weRecommend" => "Preporučamo",
    );
?>