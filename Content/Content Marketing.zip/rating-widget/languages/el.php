<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Απαίσιο",
        "ratePoor" => "Φτωχό",
        "rateAverage" => "Μέτριο",
        "rateGood" => "Καλό",
        "rateExcellent" => "Εξαιρετικό",
        "rateThis" => "Βαθμολόγησέ το",
        "like" => "Μου αρέσει",
        "dislike" => "Δεν μου αρέσει",
        "vote" => "ψήφος",
        "votes" => "ψήφοι",
        "thanks" => "Ευχαριστώ",
        "outOf" => "στα",
        "weRecommend" => "Συνιστούμε",
    );
?>
