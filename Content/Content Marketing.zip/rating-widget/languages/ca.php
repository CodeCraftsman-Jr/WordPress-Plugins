<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Horrible",
        "ratePoor" => "Pobre",
        "rateAverage" => "Mitjà",
        "rateGood" => "Bon",
        "rateExcellent" => "Excel·lent",
        "rateThis" => "Puntua això",
        "like" => "M'agrada",
        "dislike" => "No m'agrada",
        "vote" => "Votar",
        "votes" => "Vots",
        "thanks" => "Gràcies",
        "outOf" => "de cada",
        "weRecommend" => "Recomanem",
    );
?>
