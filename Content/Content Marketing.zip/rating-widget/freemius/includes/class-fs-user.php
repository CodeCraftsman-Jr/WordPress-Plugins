<?php
	class FS_User {
		public $id;
		public $email;
		public $first;
		public $last;
	}