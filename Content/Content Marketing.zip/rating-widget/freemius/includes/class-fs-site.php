<?php
	class FS_Site {
		public $id;
		public $slug;
		public $public_key;
		public $secret_key;
		public $user_id;
		public $version;
	}