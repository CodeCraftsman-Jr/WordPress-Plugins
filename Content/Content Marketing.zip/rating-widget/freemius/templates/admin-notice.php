<div class="<?php echo $VARS['type'] ?> rw-notice"><span class="rw-slug"><b>rating</b><i>widget</i></span> <b class="rw-sep">&#9733;</b> <?php echo $VARS['message'] ?></div>
