<?php
    class RW_EmptyArgumentException extends RW_InvalidArgumentException { }