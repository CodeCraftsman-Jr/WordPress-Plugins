<?php
    class RW_ArgumentNotExistException extends RW_InvalidArgumentException { }