<?php
    class RW_InvalidArgumentException extends RW_Exception { }