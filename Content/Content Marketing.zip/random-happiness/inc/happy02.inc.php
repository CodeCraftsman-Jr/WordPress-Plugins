<?php
// Happiness Library
// File Format: line 1, name of library (will be displayed)
//              all subsequent lines - are random happy thoughts (will be displayed randomly)
//
// Library Name: Movie Quotes
// Library Desc: This happiness library contains 'Movie Quotes'
// Library File: happy02.inc.php
// Library Ver.: 1.0
// Library Date: Fri Sep 19 10:45:59 MDT 2014
// Update Sched: Every January

$happy_thoughts = "Movie Quotes
You've got to ask yourself one question: 'Do I feel lucky?' Well, do you punk?
Magic mirror, on the wall - who is the fairest one of all?
Why don’t you come up sometime and see me.
You played it for her, you can play it for me. If she can stand it, I can. Play it!
Fasten your seat belts, it’s going to be a bumpy night.
Toto, I’ve a feeling we’re not in Kansas anymore.
All right, Mr. DeMille, I’m ready for my close-up.
Made it, Ma. Top of the world!
Jane, Tarzan... Jane, Tarzan
The point is, ladies and gentleman, that greed, for lack of a better word, is good. Greed is right, greed works.
You're gonna need a bigger boat.
Well, here's another nice mess you've gotten me into!
You dirty, yellow-bellied rat…
You're going out a youngster, but you've got to come back a star!
Well, gentlemen. We have ways to make men talk.
Win just one for the Gipper.
Badges? We ain't got no badges. We don't need no badges. I don't have to show you any stinkin' badges!
What makes you think you can just walk in there and find, uh, what we need? - They're called boobs, Ed.
Why is the rum always gone?
My precious.
Fish are friends, not food.
I'll be back. 
Goodbye, Mr. Bond.
Fuh-get about it!
I'll have what she's having.
Well, here's another nice mess you've gotten me into!
You can be my wingman any time.";
?>
