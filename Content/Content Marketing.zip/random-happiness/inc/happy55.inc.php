<?php
// Happiness Library
// File Format: line 1, name of library (will be displayed)
//              all subsequent lines - are random happy thoughts (will be displayed randomly)
//
// Library Name: Holidays
// Library Desc: This happiness library contains 'Holidays'
// Library File: happy55.inc.php
// Library Ver.: 1.0
// Library Date: Fri Dec 19 09:47:22 MST 2014
// Update Sched: Somewhen in December

$happy_thoughts = "Holidays
Sharing the holiday with other people, and feeling that you're giving of yourself, gets you past all the commercialism. - Caroline Kennedy
My normal life is like being on holiday - Valentino Rossi
I have had a holiday, and I'd like to take it up professionally. - Kylie Minogue
A summary of every Jewish holiday: They tried to kill us, we won, let's eat! - Alan King
April in Paris, chestnuts in blossom, holiday tables under the trees.  E. Y. Harburg
Valentine's Day is my favorite holiday. Lindsay Ellingson
Maybe Christmas, the Grinch thought, doesn't come from a store. Dr. Seuss
The two most joyous times of the year are Christmas morning and the end of school. Alice Cooper
It is a fine seasoning for joy to think of those we love. Moliere
Let's be naughty and save Santa the trip. Gary Allan
Santa Claus has the right idea - visit people only once a year. Victor Borge
A good conscience is a continual Christmas. Benjamin Franklin
What I find fascinating about Hanukkah, the Jewish festival of lights we celebrate at this time of the year, is the way its story was transformed by time. Jonathan SacksA
In union there is strength. ~Aesop
Sticks in a bundle are unbreakable. ~Kenyan Proverb
Every man is the architect of his own fortune. ~Sallust
A snowflake is one of God's most fragile creations, but look what they can do when they stick together! ~Author Unknown
Many hands make light work. ~John Heywood
For the spirit of Christmas fulfils the greatest hunger of mankind. ~Loring A. Schuler
The perfect Christmas tree? All Christmas trees are perfect! ~Charles N. Barnard
The best Christmas trees come very close to exceeding nature. ~Andy Rooney
There are no strangers on Christmas Eve. ~Mildred Cram and Adele Comandini
May the lights of Hanukkah usher in a better world for all humankind.  ~Author Unknown
I ask not for a lighter burden, but for broader shoulders.  ~Jewish Proverb
Until you pin me, George, Festivus is not over.
I got a lotta problems with you people!
I find tinsel distracting.
Festivus is Back!  I'll get the pole out of the crawlspace.
Festivus is your heritage, it's part of who you are.
It's a festivus miracle ~Kramer
A perpetual holiday is a good working definition of hell. - George Bernard Shaw";
?>
