=== Random Happiness ===
Contributors: WebYourBusiness,greghl
Donate link: http://webyourbusiness.com/random-happiness
Requires at least: 3.0
Stable tag: 1.0.3.2
Tested up to: 4.3
License: GPLv2 or later
Tags: Admin, admin, happing, random, quotes, fortune cookie, cookie, cookies, fortunes, happiness
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is just a plugin, it provides random happy thoughts in the upper right of your admin screen on every page.

== Description ==

This is just a plugin, it provides random happy thoughts in the upper right of your admin screen on every page.

== Installation ===

1. Upload `random-happiness.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Random happy thoughts will appear in your admin section of your site - do NOT install with Hello Dolly

== Screenshots ==

1. random happiness

== Frequently Asked Questions ==

If you have questions - ask them on our webpage

== Upgrade Notice ==

= 1.0.3.2 =
tested on WordPress 4.2.4
= 1.0.3.1 =
tested on WordPress 4.2 Powell

= 1.0.3 =
added holiday quotes as inc/happy55.inc.php

= 1.0.2 =
added Fall happiness quotes as inc/happy11.inc.php

= 1.0.1 =
added happiness quotes as inc/happy10.inc.php

= 1.0 =
No upgrades yet

== Changelog ==

= 1.0.3.2 =
tested on WordPress 4.2.4
