=== Plugin Name ===
Contributors: ThemesTitan
Donate link:http://themestitan.com/
Tags: custom post type
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Custom post type and Taxonomy functionality for WordPress Themes build by ThemesTitan. Please do not waste your time with this plugin if you are not using one of the themes from ThemesTitan.

== Installation ==

1. Download and unzip files. Or install "TT CPT Kit" plugin using the WordPress plugin installer. In that case, skip 2.
2. Upload "TT CPT Kit" to the "/wp-content/plugins/" directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Now Custom Post Types should be visible on Admin Menu

== Frequently Asked Questions ==
None

== Screenshots ==
None


== Upgrade Notice ==
None

== Changelog ==

= 1.0.0 =
* Initial release