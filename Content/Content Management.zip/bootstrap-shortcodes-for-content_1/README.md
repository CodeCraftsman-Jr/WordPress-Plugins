# Plugin Wordpress Bootstrap Shortcodes for Content

This plugin give you a bunch of shortcodes that allows you to draw content using Bootstrap CSS and HTML. 

Shortcodes:
[gridbox] - Allows you to show a grid with post types related.

Parameters:
- post_type -> slug of Post type that you want to show.
- posts_per_page -> 
- col -> Columns that you want to show.
- date -> true or false. If you want to show in the grid.
- tax -> Show Taxonomy that the post in.
- size -> image size for post thumbnail

[imagepostslider] - Image Slider from Images attached in a post

[carouselcpt] - Multiple elements Carousel 

- post_type -> slug of Post type that you want to show.
- tax -> Show Taxonomy that the post in.
- title -> Title that goes before
- type -> post or tax
- col -> Elements visibles
- titlep -> true or false. Show Title's post in carousel