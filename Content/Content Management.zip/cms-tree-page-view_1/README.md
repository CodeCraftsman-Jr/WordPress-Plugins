# WordPress CMS Tree Page View

This plugin for WordPress gives you a tree view of all your pages and custom posts in WordPress. 
Edit, view, add and search pages, and use drag and drop pages to rearrange the order.

[Visit the plugin homepage for more information](http://wordpress.org/plugins/cms-tree-page-view/).

