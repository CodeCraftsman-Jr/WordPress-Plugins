=== Plugin Name ===
Contributors: mithublue
Tags: content grabber,content,posts grabber,post loop,content loop
Requires at least: 3.6
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin to help you grab content of any post type and display them as you want

== Description ==

This plugin will create a widget in your widget panel, this widget will let you grab content/post of any post type and control style how you want the posts to view in the frontend

Features:

(1) Chose post of any type that you want to grab
(2) Set how many posts you want to display per page
(3) Set how the posts should be ordered
(4) Set post status
(5) Set html template that the posts can use in loop to display
(6) Control the style for the loop html


== Installation ==

1. Upload `content-grabber` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Screenshots ==

1. screenshot-1


