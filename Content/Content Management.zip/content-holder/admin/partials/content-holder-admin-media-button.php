<style>
.content_holder_media_link span.dashicons{
	color: #888;
	font-size: 20px;
	margin-top: 2px;
}
.wp-core-ui a.content_holder_media_link{
	padding-left: 0.4em;
}
</style>

<a href="#TB_inline?width=480&inlineId=select_content_holder" class="thickbox button content_holder_media_link" id="add_content_holder_link" title="<?php  _e("Add Content Holder", 'content-holder') ?>"><span class="dashicons dashicons-migrate"></span> <?php _e("Add Content Holder", "content-holder") ?></a>