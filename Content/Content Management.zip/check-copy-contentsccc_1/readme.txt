=== Plugin Name ===
Contributors: kanakogi
Donate link: http://www.amazon.co.jp/registry/wishlist/2TUGZOYJW8T4T/?_encoding=UTF8&camp=247&creative=7399&linkCode=ur2&tag=wpccc-22
Tags: copy, notice, mail, AJAX, post
Requires at least: 3.0 or higher
Tested up to: 4.0
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

If someone reposts or quotes text content from your website, you'll get a discreet email letting you know, along with the sections quoted and the URL.

== Description ==

If someone reposts or quotes text content from your website, you'll get a discreet email letting you know, along with the sections quoted and the URL.
You can find out what part of your article has garnered interest, and which sections are being quoted by others.  
Note 1: The quoted sections that appear in the notification email will be extracted from your original blog post (the_content();).  
Note 2: This plugin will work on full blog post pages and on static pages. It will not work on front pages.


== Installation ==

1. Upload the entire `check-copy-contents` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. The control panel of Head Cleaner is in 'Settings > CCC settings'.





== Changelog ==
**1.3 - January 5, 2015**  
Bug fix.

**1.1 - August 7, 2013**  
Bug fix.

**1.0.0 - July 24, 2013**  
Initial release.