=== Plugin Name ===
Contributors: kanakogi
Donate link: http://www.amazon.co.jp/registry/wishlist/2TUGZOYJW8T4T/?_encoding=UTF8&camp=247&creative=7399&linkCode=ur2&tag=wpccc-22
Tags: copy, notice, mail, AJAX, post
Requires at least: 3.0 or higher
Tested up to: 4.0
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

誰かが、あなたのブログの文章をコピーしたら、そのコピーされた箇所とページのURLを、こっそりとあなたにメールで通知します。

== Description ==
誰かが、あなたのブログの文章をコピーしたら、そのコピーされた箇所とページのURLを、こっそりとあなたにメールで通知します。
その記事のどこに興味を持たれたのか、引用されているのはどの箇所なのかを知ることが出来ます。  
※注1：コピーを通知する箇所は、本文( the_content(); )で出力された文章になります。  
※注2：記事詳細ページ、固定ページの本文が対象になります。トップページでは動きません。

== Installation ==

1. `/wp-content/plugins/` ディレクトリに `check-copy-contents` ディレクトリを作成し、その中にプラグインファイルを格納してください。
一般的には .zip から展開された check-copy-contentsフォルダをそのままアップロードすれば OK です。
2. WordPress の "プラグイン" メニューから "Check Copy Contents(CCC)" を有効化してください。
3. Check Copy Contents(CCC) のオプション設定は "設定 > CCC settings" で行えます。




== Changelog ==
**1.3 - January 5, 2015**  
Bug fix.

**1.1 - August 7, 2013**  
Bug fix.

**1.0.0 - July 24, 2013**  
Initial release.