<?php
/**
Component Name: OTW Grid Manager
Plugin URI: http://OTWthemes.com
Description:  OTW Grid Manager
Author: OTWthemes.com
Version: 0.001 light version
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Grid Manager';
$otw_component['version']    = '0.001';
$otw_component['class_name'] = 'OTW_Grid_Manager';

?>