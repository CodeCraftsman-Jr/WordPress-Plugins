=== Brand In Content===
Contributors: AboZain
Donate link: http://unitone.ps
Tags: brand, image, content
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple, lightweight WordPress plugin replace your Brand name with Image Logo or custom style in WordPress Content

== Description ==
Branding is a key element for any site owner. Whether you own a large company, or are one person blogging, your brand is your identity.
Brand In Content is a simple plugin gives you the ability to replace your Brand name with Image Logo or custom style in WordPress Content.

== Installation ==

This section describes how to install the plugin and get it working.
1. Upload `brand-in-content.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Where can I find the setting after activate the plugin =

Go to Settings -> Brand In Content

== Screenshots ==

1. This screen shot description where you find the plugin settings.
2. This screen shot description the plugin settings.

== Changelog ==

= 1.0 =
* First version.
= 1.1 =
* Translation Support.
