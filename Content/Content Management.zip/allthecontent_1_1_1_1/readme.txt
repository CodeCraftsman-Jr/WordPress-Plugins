=== AllTheContent ===
Contributors: allthecontent
Tags: allthecontent, content, feeds, wires, fresh content, importer, import
Requires at least: 4.0
Tested up to: 4.1
Stable tag: 0.1.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.allthecontent.com/wordpress-plugin

== Description ==
AllTheContent is an importer for ATCML format. Get all your content imported into your Wordpress automatically.

= Highlighted Features =

* Automatically import new content
* Map AllTheContent themes with Wordpress categories
* Reorganize your contents.
* Automatically publish new imported content or let it as draft for validation

Documentation can be found on the plugin page
http://www.allthecontent.com/wordpress-plugin

== Installation ==
1. Unzip the plugin archive
2. Upload `allthecontent` folder to the `/wp-content/plugins/` directory
3. Activate the AllTheContent plugin through the 'Plugins' menu in WordPress
4. Configure the plugin by going to the `AllTheContent` menu item that appears in your dashboard menu.

Full Installation process can be found on the plugin page:
http://www.allthecontent.com/wordpress-plugin

== Screenshots ==

http://www.allthecontent.com/wordpress-plugin

== Frequently Asked Questions ==

No FAQ yet

== Upgrade Notice ==

No upgrade notice yet

== Changelog ==

= 0.1.1 (2015-04-15) =
* fix uninstall
* fix readme url

= 0.1.0 (2015-02-03) =
* Initial release
