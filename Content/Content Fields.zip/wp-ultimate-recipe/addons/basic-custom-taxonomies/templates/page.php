<div class="wrap">

    <div id="icon-themes" class="icon32"></div>
    <h2>WP Ultimate Recipe <?php _e( 'Custom Tags', 'wp-ultimate-recipe' );?></h2>

    <?php settings_errors(); ?>

    <?php do_settings_sections( 'wpurp_taxonomies_settings' ); ?>

</div>