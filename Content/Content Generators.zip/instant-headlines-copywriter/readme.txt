=== Instant Headlines Copywriter ===
Contributors: optimalplugins
Donate link: http://www.optimalplugins.com
Tags: blog, post, headlines, title, swipe, file, generator, wordpress
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Instantly Generate Attention Grabbing Headlines with Just One Click.

== Description ==

Instantly Write Attention Grabbing Headlines with Just One Click.

* 250 High Conversion Headlines for instant Swipe and Deploy.
* 8 Instant Headline Suggestions with a click on a button.
* Automatically populate the Post or Page Title with the selected headline suggestion.
* Responsive design that fit perfectly with WordPress.

For further information and instructions please see the [](http://www.optimalplugins.com/)

== Screenshots ==
1. Type in a topic or keyword, then press <Enter> or click "Generate" to get instant headline suggestions.

== Installation ==
1. Install and activate the plugin on the Plugins page.

If you would prefer to do things manually then follow these instructions:

1. Upload the `optimal-headline-lite` folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Create a post or a page, you should see a headline metabox displayed underneath the title.

== Changelog ==

= 1.0.0 =
Initial Release