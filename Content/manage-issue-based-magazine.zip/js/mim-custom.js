jQuery(document).ready(function(){
alert("ddd");
});