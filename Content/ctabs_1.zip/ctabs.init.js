var $jctbs = jQuery.noConflict();

$jctbs(function() {
	cache: false;
	ajaxOptions: {cache: false};
	$jctbs("#ctabs").cTabs();
  });