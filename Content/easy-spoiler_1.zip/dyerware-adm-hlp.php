<div style="display:inline-block;">
	<div style="display:inline;float:left;">
			<div>	
				<div><h3 style="text-align:center">iPhone RSS reader:</h3></div>
				<div><p style="text-align:center"><img src="http://www.dyerware.com/main/personalize/images/FeaturePics/Flitter!.PNG"  height="40"/><a href="https://itunes.apple.com/us/app/flitter/id320129198?ls=1&mt=8"><img border="0" src="http://www.dyerware.com/main/personalize/images/FeaturePics/Download_on_the_App_Store_Badge.png" height="50"></a></p></div>
			</div>
	</div>
	<div style="display:inline;float:left;margin:0px 10px">
			<div >	
				<div><h3 style="text-align:center">iPad RSS Love:</h3></div>
				<div><p style="text-align:center"><img src="http://www.dyerware.com/main/personalize/images/FeaturePics/feedHopper.png"  height="50"/><a href="https://itunes.apple.com/us/app/feedhopper-rss-reader/id361881998?ls=1&mt=8"><img border="0" src="http://www.dyerware.com/main/personalize/images/FeaturePics/Download_on_the_App_Store_Badge.png" height="50"></a></p></div>
			</div>
	</div>
	<div style="display:inline;float:left;margin:0px 10px">
			<div>	
				<div><h3 style="text-align:center">Doodle Dice: Free Game</h3></div>
				<div><p style="text-align:center"><img src="http://www.dyerware.com/main/personalize/images/FeaturePics/icon-dg-5.png"  height="50"/><a href="https://itunes.apple.com/us/app/doodle-dice/id561309891?ls=1&mt=8"><img border="0" src="http://www.dyerware.com/main/personalize/images/FeaturePics/Download_on_the_App_Store_Badge.png" height="50"></a></p></div>
			</div>
	</div>
</div>