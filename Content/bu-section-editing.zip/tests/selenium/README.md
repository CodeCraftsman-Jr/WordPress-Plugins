These tests were written against an outdated private fork of the WordPress unit tests suite that integrated with Selenium.

You can safely ignore them for now.
