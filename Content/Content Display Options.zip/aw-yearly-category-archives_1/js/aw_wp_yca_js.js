jQuery(document).ready(function() {
	if(jQuery('#useCustomHtmlPhp').is(':checked')){
		//
	} else {
		jQuery('#codeSubmitWrapper').hide();
	}
});
