<?php
    
function atcontent_coexistense_pin_it_buttons_add( $content ) {
	return $content;
}

?>