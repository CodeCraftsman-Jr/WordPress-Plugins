<?php

namespace plainview\sdk_broadcast\table;

/**
	@brief		Head section of table.
	@since		20130430
	@version	20130430
**/
class head
	extends section
{
	public $tag = 'thead';
}
