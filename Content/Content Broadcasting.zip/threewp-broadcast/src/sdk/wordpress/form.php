<?php

namespace plainview\sdk_broadcast\wordpress;

if ( ! class_exists( 'plainview::form' ) )
	require_once( dirname( __FILE__ ) . '/../form.php' );

class form
	extends \plainview\sdk_broadcast\form
{
}
