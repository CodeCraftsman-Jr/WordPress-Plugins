<?php

namespace plainview\sdk_broadcast\form2\inputs;

/**
	@brief		Number range text input.
	@author		Edward Plainview <edward@plainview.se>
	@copyright	GPL v3
	@version	20130524
**/
class range
	extends number
{
	public $type = 'range';
}

