<?php

namespace threewp_broadcast;

/**
	@brief		Backwards compatability class for link_data.
	@see		link_data
	@since		2014-08-31 20:48:46
**/
class BroadcastData
	extends broadcast_data
{
}
