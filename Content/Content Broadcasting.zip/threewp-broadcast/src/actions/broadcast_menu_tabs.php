<?php

namespace threewp_broadcast\actions;

class broadcast_menu_tabs
	extends action
{
	/**
		@brief		IN: The tabs object which the plugins may modify.
		@since		2014-04-18 09:02:46
	**/
	public $tabs;
}