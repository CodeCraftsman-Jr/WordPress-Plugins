<?php

namespace threewp_broadcast\actions;

class menu
	extends action
{
	/**
		@brief		The broadcast object.
		@since		20131006
	**/
	public $broadcast;
}
