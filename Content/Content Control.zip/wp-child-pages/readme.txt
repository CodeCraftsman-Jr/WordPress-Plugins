=== WP Child Pages ===
Contributors: Mladjo
Tags: child, page, widget, navigation, nav, children, shortcode, plugin, wordpress
Requires at least: 3.8
Tested up to: 4.3
Stable tag: 1.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.txt

This Plugin displays child pages of the parent page it is placed on. Display your child pages by widget or visual shortcode. 

== Description ==

This Plugin displays child pages of the parent page it is placed on. 

Display your child pages by widget or visual shortcode. 

If there are no child pages, the widget or shortcode will not show.

Via the options you can set whether you want to display title, content limited by number of characters, set size of featured thumbnail. 

Please feel free to contribute on https://github.com/mladjom/wp-child-pages

== Installation ==

Standard WordPress installation; either:

- Go to the Plugins -> Add New screen in your dashboard and search for this plugin; then install and activate it.

Or

- Upload this plugin's zip file into Plugins -> Add New -> Upload in your dashboard; then activate it.

== Screenshots ==

1. Widget editing interface.
2. Shortcodes generator.

== Changelog ==

= 1.1 =
* Widget Updated

= 1.0 =
* Initial Release