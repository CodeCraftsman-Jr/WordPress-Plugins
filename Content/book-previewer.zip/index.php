<?php
defined('ABSPATH') or die("Incorrect path");
/* Do not display the plugin folder */
?>