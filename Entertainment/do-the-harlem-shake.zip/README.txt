=== Do The harlem Shake ===
Contributors: narayanprusty
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Animates website when someone searches for "do the harlem shake"

== Description ==

Animates website when someone searches for "do the harlem shake"

== Installation ==

Just upload the plugin and install it. In WordPress search form search for "do the harlem shake" and the result page will be dancing.