=== Doctor House Quotes ===
Contributors: http://ejohnny.net & http://ma.tt
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9FXG6CN7DCTA6
Tags: doctor, house, quote, lines, wordpress
Requires at least: 2.0.2
Tested up to: 3.0
Stable tag: 1.1

This plugin quotes random lines used by Doctor House in House MD tv show. (based on Hello Dolly)

== Description ==

Description: This is just a plugin that quotes some lines used by Doctor House in House MD tv show. This plugin is based on Hello Dolly and i hope in time it will do more than just quote some lines.

For more information please read the article about this plugin from my blog:
http://ejohnny.net/blog/2010/doctor-house-quotes-wordpress-plugin.html

== Installation ==

How to install it? Like any other plugin, just download the archive and install the plugin using wordpress wizard from Plugins > Add New > Upload or extract the files anywhere on you hdd and them using a ftp client move them to the plugins directory (�/wp-content/plugins/(here) )


1. Upload `doctor-house-quotes.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it!

For support email me at: admin@ejohnny.net 

== Frequently Asked Questions ==

= Why did i made this plugin? =

Because I am a House MD fan!

= What about Cuddy? =

She's great!

== Screenshots ==

1. We can see here the plugin activated
2. We can see here the plugin on work

== Changelog ==
= 1.1 =

Enhancements:
* 5 more lines added to quotes
* plugin url added
* authors url added
