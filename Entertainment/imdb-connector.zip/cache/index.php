<?php
  /** Nothing's going on here; just protecting your privacy */