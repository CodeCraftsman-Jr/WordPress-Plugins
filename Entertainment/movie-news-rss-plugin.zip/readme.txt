=== Movie Rss Feed ===
Contributors: Guy
Tags: news, widget, sidebar, movie, movies, links, plugin, rss feed, newsticker
Requires at least: 2.9
Tested up to: 3.0
Stable tag: 1.0

Adds a customizeable widget which displays the latest Movie news from The Movie Blog. It can be integrated anywhere in the blog. This newsticker shows up the last five or more Movie posts. This is a very nice solution for all Movie lovers and Movie related blog owners that want to stay in the loop of what's happening in the Movie industry and keep their readers in the loop too.

== Description ==

Adds a customizeable widget which displays the latest Movie news from The Movie Blog. It can be integrated anywhere in the blog. This newsticker shows up the last five or more Movie posts. This is a very nice solution for all Movie lovers and Movie related blog owners that want to stay in the loop of what's happening in the Movie industry and keep their readers in the loop too.

If you have tech related questions/support etc, though I don't see why you would (check the read me file included for help), it's really a basic plugin, shoot me a msg on my blog (guyro.com) in the comments and i'll do my best to get back to you.


*Feature List*

* customizable widget
* displays a user-defined number of links
* title shortening

== Installation ==

*Could not be simpler*
1. Extract `movie-rss-feed.zip`.
2. Upload the `movie-rss-feed`-folder to your `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.
