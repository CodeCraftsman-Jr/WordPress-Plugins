=== Joke of the Day ===
Contributors: allis741 
Donate link: http://www.premiumresponsive.com/wordpress-plugins/
Tags: widget, joke, jokes, funny video, funny, funny foto, funny jokes, post, posts, link, links, promote, SEO, category, sidebar, feed, rss
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: trunk

Plugin "Joke of the Day" displays jokes on your blog. There are over 40,000 jokes in 40 categories.
 
== Description ==

Plugin "Joke of the Day" displays categorized jokes on your blog. There are over 40,000 jokes in 40 categories. Jokes are saved on our database, so you don't need to have space for all that information. 
 
== Installation ==

1. Upload the folder joke-of-the-day to the /wp-content/plugins/ directory
2. Activate the plugin Joke of the Day through the 'Plugins' menu in WordPress
3. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.

== Screenshots ==

1. Joke of the Day Widget Screenshot
 
== Changelog ==

= 3.0 =
* Tested up to 4.1.1 WP     
* Updated script

= 2.9 =
* Tested up to 3.6 WP     
* Changed new feed link
* Updated script

= 2.8 =
* Tested up to 3.3.2 WP     
* Updated script

= 2.7 =
* Updated code
* Changed new feed link
* Upadated screenshot

= 2.6 =
* Tested up to 3.3.1 WP     
* Updated script

= 2.5.1 =
                                                                                                                                                                
* Fix widget bugs.
* Tested up to 3.1.3 version WP

= 2.4 =
                                                                                                                                                                
* Changed new feed link
* Tested up to 3.1.2 version WP

= 2.3 =
* Tested upto 3.1 WP and fix bugs
 
= 2.2 =
* Script Update.

= 2.1.1 =
* Update readme.txt file.
                                                                                    
= 2.1 =
* Script Update.

= 2.0 =
* Tested upto 3.1 WP 

= 1.9.1 =
* Changed works upto 3.0.3 WP 

= 1.8 =
* Script Update.

= 1.7 =
 * Fix bugs.

= 1.6 =
* Update tags.

= 1.5 =
*  Fix bugs.

= 1.4 =
 * Fix bugs.

= 1.3 =
 * Fix bugs.

= 1.1 =
*  First stable version.