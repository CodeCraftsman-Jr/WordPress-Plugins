=== Fighting The Lyrics ===
Contributors: mrobinso
Tags: songs, lyrics, albums, artists, admin_header
Requires at least: 2.0
Tested up to: 2.7
Stable tag: 1.06

Got tired of Hello Dolly lyrics, and being a Peter Gabriel fan, wrote this instead.

That's it.

== Description == 

Got tired of Hello Dolly lyrics, and being a Peter Gabriel fan, wrote this instead.
You can upload multiple .txt files containing lyrics, follow a naming convention
to display artist, album and song name, together with a line from the lyrics.


== Installation ==

Upload the entire directory 'fightingthelyrics to the '/wp-content/plugins/' directory.
Edit the lyrics_css() function in the fightingthelyrics.php file to suit your site look.
Add or remove lyrics files as you see fit, following the naming convention.

Activate the plugin.


== Screenshots ==

None


== Frequently Asked Questions ==


None