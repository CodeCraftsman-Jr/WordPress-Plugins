

<div class="wgames-logo-view" style="padding: 15px;">
    <img src="<?php echo $setting_logo_path?>" style="display: none; width:304px; margin-top: 20px;margin-left: 10px;">
     <h2 style="color: #428bca">Critic Games</h2>
</div>

