﻿=== Online Games ===
Contributors: Critic Team
Donate link: http://critic.net/wp-plugin/
Tags: widget, arcade, html5, gaming, media, flash, puzzles, admin, ajax, content, sidebar, image, images, widgets, game, games, post, posts, page, pages, shortcode, bike, cars, call of duty, dragonball, sport, sports, freecell, solitaire, mahjong, hockey, basketball, cards, fantasy, fun, pacman, backgammon, chess, sonic, spiderman, ninja, happy wheels, car, gladiator, lost, puzzle, sudoku, arcade, embed, pgn, critic, critic games
Requires at least: 3.5
License: GPL v2
Tested up to: 4.1
Stable tag: 2.3.0

Display up to 65 free HD Games in your website easily using shortcodes. Arcade games like Mario, Solitaire, Backgammon, Chess & more.

== Description ==

Display free online games in your website easily in less than a minute.

* You can display each game individually on each post or page using simple shortcode(s).

= The Games =

Scroll until the end of the page to see what games are available.

= Boards / Cards / Sports / Fantasy =

* Backgammon

* Backyard Sports

* Baseball Team

* Batman Defend Gotham

* Bicycle Run

* Billiads

* BMX Extreme

* Call of Duty Crossfire

* Car Twisted Dreams

* Chess

* Construction Bike

* Court Basketball

* Crescent Solitaire

* Dragonball 1

* Fall Time Sudoku

* Freecell Grey

* Governor of Poker 2

* Happy Wheels

* Lake Fishing

* Lightning

* Mahjong

* Ninja Battle 3

* Pacman

* Pinch Hitter 2

* Pokemon Tower Defense

* Rainforest Solitaire

* Snooker

* Solitaire Collection

* Sonic The Hedgehog

* Spider Man 3

* Spider Solitaire

* Sprinter

* Super Bike X

* Super Mario Bros 2

* Super Mario Land

* Super Mario World

* Table Hockey

* Tom & Jerry Puzzle

* Twisted Tennis

* Ultimate Baseball

* World Cup Penalty


= HD Games =


* After Night Falls

* A Night in Paris

* At the Copa

* Boomanji

* Ghouls Gold

* Gladiator

* Gold Diggers

* Gypsy Rose

* Heist

* House of Fun

* Lost

* Mad Scientist

* Pharaoh King

* Puppy Love

* Rock Star

* Royal Reels

* Safari Sam

* The True Sheriff

* Three Wishes

* True Illusions

* Tycoons

* Under The Bed

* Upon a Time

* Viking Age


== Screenshots ==

1. Settings Games Page 1
2. Settings Games Page 2

== Installation ==

1. Upload the `games` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Configure the plugin by going to the `Critic Games` menu that appears in your admin menu

== Changelog ==
1st release on Wordpress.

== Upgrade Notice ==
1st release on Wordpress.