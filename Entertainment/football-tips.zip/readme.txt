=== Football Tips ===

Contributors: Nababsingh Ramdharry
Tags: bet, tips, widget, football, odds, football tips, bet compare, online bookies, soccer, soccer tips, world cup tips, world cup 2010 tips, FIFA World Cup 2010 Tips
Requires at least: 2.0.2
Tested up to: 3.0
Stable tag: 0.02

== Description ==
The Goal.mu Football Tips Wordpress Widget will display the latest football tips from 
Goal.mu together with the latest best odds from various online bookies.Football Tips from
the England, France, Spain, Italy, Germany and so on.Get the latest FIFA World Cup 2010 betting 
tips together with the best odds.

== Installation ==
Here are some installation instructions:

   *  Click the download link below to get the latest version
   *  Drop the tips Widget folder into your wp-content/plugins folder
   *  Go to your Administration:Plugins page and activate the Football Tips Widget.
   *  Go to Presentation:Widgets
   *  Move (drag and drop) the widget to where you would like it in your active sidebar
   *  Click on the config button for the Football Tips.
   *  Enter the title you want visitors to see on the sidebar
== Frequently Asked Questions ==

= Is this a widget plugin? =

Yes, this is a Widget Plugin.

== Screenshots ==
1. This is the screenshot of how the widget will be.

== Changelog ==
= 0.01 =
This is the first version
= 0.02 =
Removal of Bookies images.

== Upgrade Notice ==
= 0.01 =
There's no new version to upgrade to!

= 0.02 =
Upgrade to Football Tips 0.02