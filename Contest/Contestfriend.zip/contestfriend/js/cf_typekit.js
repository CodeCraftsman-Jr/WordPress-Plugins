
if(window.Typekit)
{
    try
    {
        Typekit.load();
    }
    catch(e)
    {
        alert(e);
    }
}