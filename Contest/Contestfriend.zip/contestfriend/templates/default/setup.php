<?php
echo '</span>
        <span class="cf_poweredby">'.__('Powered by', 'contestfriend').' <a href="http://contestfriend.com">ContestFriend</a></span>
        <div class="cf_clear"></div>
    </div>
</div>
';
?>