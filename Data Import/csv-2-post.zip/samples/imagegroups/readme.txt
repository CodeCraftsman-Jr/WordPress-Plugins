The group of images found in the same folder as this file are for test
purposes. The images contain keywords, three in total. The keywords
can be found in a public test file I host on Google Documents.

https://docs.google.com/spreadsheets/d/1J140c85Kl5fE_9dQAIgSq-uATtD-Jtwje4G1WQFgBbU/edit?usp=sharing

The "imagegroups" column can be selected in the "Grouped Image Importing"
panel. CSV 2 POST will then import groups of images per post. It does this
by matching each unique term (one per row) with the filenames. 

If you do all of this using my test data. You will create 3 posts, each
with some images attached and resulting in new WordPress media.