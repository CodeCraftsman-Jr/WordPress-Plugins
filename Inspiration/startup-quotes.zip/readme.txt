=== Startup Quotes ===
Contributors: od3n
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=P463T8P3SPBVJ&lc=US&item_number=WordPress&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: startup, quote, quotes, inspiring, entrepreneur, widget, sidebar
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 1.0.0
License: GPLv2 or later

Inspiring entrepreneur startup quotes from influential people in the industry.

== Description ==

This plugin will display one startup quote at a time. Get data from API.

Check out [Startup Quotes Demo](http://wpkreatif.com/).

== Installation ==

To install this plugin,

1. Install Startup Quotes either via the WordPress.org plugin directory, or by uploading the files to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Appearance > Widgets to add the widget to your sidebar.
4. That's it. You're ready to go!

== Frequently Asked Questions ==

How do I contact you?
- Just email me to mr.od3n@gmail.com

== Screenshots == 
1. Output example.

== Changelog ==

= 1.0 =
* Initial release. Plugin created on 11/04/2012

== Upgrade Notice ==

= 1.0 =
