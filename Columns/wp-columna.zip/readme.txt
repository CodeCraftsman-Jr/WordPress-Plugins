=== WP-Columna ===
Contributors: web2webs
Plugin URI: http://web2webs.com/plugin-de-columnas-de-wordpress/
Donate link: http://web2webs.com/plugin-de-columnas-de-wordpress/
Author URI: http://web2webs.com/
Tags: column, columns, layout, cms, pages, posts
Requires at least: 3.5
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add columns to visual editor and the page, another easier way to make columns using visual editor without HTML knowledge nor shortcodes. 

== Description ==

Add columns to visual editor and the page, another easier way to make columns using visual editor without HTML knowledge nor shortcodes. 

This plugin provides you with 4 general column layout in your visual editor.

== Installation ==

1. Upload `wp-columna` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to visual editor and create layout columns

== Screenshots ==

1. Extra buttons in visual editor