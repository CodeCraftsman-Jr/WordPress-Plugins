<?php
/** 
 * @package   USGS Steam Flow Data
 * @author    Chris Kindred <Chris@kindredwebconsulting.com>
 * @license   GPL-2.0+
 * @link      http://www.kindredwebconsulting.com
 * @copyright 2015 Kindred Web Consulting
 */
?>

<!-- This file is used to markup the public facing aspect of the plugin. -->