=== Plugin Name ===
Contributors: automattic, briancolinger
Donate link: 
Tags: importer, vox, WordPress.com
Requires at least: 2.9
Tested up to: 3.0
Stable tag: 0.7

Import posts, comments, tags, and attachments from a Vox.com blog.

== Description ==

Import posts, comments, tags, and attachments from a Vox.com blog.

If you install this plugin on WordPress 2.9 you will need the WP_Importer base class. 
You can download it here: http://wordpress.org/extend/plugins/class-wp-importer/

== Installation ==

1. Upload the `vox-importer` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Tools -> Import screen, Click on Vox

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 0.1 =
* Initial release
