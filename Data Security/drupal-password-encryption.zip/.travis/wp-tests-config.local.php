<?php
/**
 * Environment-specific test suite settings.
 *
 * @see wp-tests-config.php
 */

define( 'DB_NAME', 'wordpress_test' );
define( 'DB_USER', 'travis' );
define( 'DB_PASSWORD', '' );
define( 'DB_HOST', 'localhost' );
