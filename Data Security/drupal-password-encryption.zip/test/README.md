These tests run using [BevanR's test suite boilerplate for WordPress websites](https://github.com/BevanR/Test-suite-boilerplate-for-WordPress-websites).

@todo Find and use the standard method for testing plugins hosted on WordPress.org.
