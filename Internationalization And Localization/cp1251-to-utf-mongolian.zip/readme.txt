﻿=== Plugin Name ===
Contributors: Amarsanaa J
Donate link: http://webipress.com/
Tags: wp, php, utf-8, converter, cp1251, mongolian , cryllic
Requires at least: 2.0
Tested up to: 3.0
Stable tag: 1.0

Windows-1251 ээс Unicode-utf8 стандарт монгол үсгийн хэврүү хөрвүүлэгч

== Description ==
 Title, content, excerpt дээр хөрвүүлэлт хийгддэг.

- Хэрэглэхэд хялбар ба үнэгүй ашиглагдана.
- Нэмж хөгжүүлэлт нээлттэй шүү!



== Installation ==

1. Архивласан файлыг татаж авна.
2. `cp1251_to_utf.php` файлыг  `/wp-content/plugins/` хавтаст хуулна.
3. Wordpress -н цэснээс нэмэлт гэсэн хэсэгт орж нэмэлтийг идэвхжүүлнэ.

== Frequently Asked Questions ==

= Is Share-Widget free? =
Yes!

== Screenshots ==

1. Өмнө нь
2. Дараа нь

== Changelog ==

= 1.0 =
* new

== Upgrade Notice ==

= 1.0 =
new

== Arbitrary section ==

none

== A brief Markdown Example ==

none