=== National Characters ===
Contributors: OptArt
Tags: national,characters,national characters,special,registration,sign up,polish,latin,cyrillic,arabic,username,multibyte,utf8
Requires at least: 3.0
Tested up to: 4.2.3

Allows you to enter national characters (special characters) in username during registration.

== Description ==
The plugin allows you to enter national characters (special characters) in username during registration.

Based on the WP core function. WordPress does not allow to use national characters in usernames by default. This plugin fixes this issue.

== Installation ==
= Automatic installation =

This is the easiest option to install WordPress plugin. To do an automatic install of National Characters, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type “National Characters” and click Search Plugins. You can install it by simply clicking “Install Now”.

= Manual installation =

If your server does not permit automatic installation of a WordPress Plugin or you wish to control the placement and installation process you can do a manual installation by following these steps:

1. Download National Characters plugin to your desktop.
2. Extract the plugin folder to your desktop.
3. With your FTP program, upload the extracted folder to the wp-content/plugins folder in your WordPress directory online.
4. Go to Plugins screen and find the newly uploaded Plugin in the list.
5. Click Activate to activate it.

== Changelog ==
= 1.0.0 =
- Initial release