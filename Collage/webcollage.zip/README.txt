=== Web Collage ===
Contributors: Sudipta Bhawmik
Donate link: 
Tags: links, blogroll, screen shot, artviper
Requires at least: 2.0.2
Tested up to: 2.5
Stable tag: 1.1


WebCollage is a cute plugin for Wordpress sites. It creates a collage of snapshots of the websites that you have in your 

links database or blogroll.

== Description ==

Webcollage creates a collage of snapshots of the webpages of your links (blogroll) on any page in your Wordpress site. All 

you need to do is specify the tag "[webcollage]" in the page where you want the collage to appear. 
Click on any snapshot and it will take you to the corresponding website. If you have the "Snapshots" plugin installed, you 

can see a larger screen image of the website when you bring your mouse pointer over any image.

The beauty of the collage depends on the websites you link to.
Webcollage uses artviper.net's screen shot generation service. This service is free as long as the usage is non-commercial. 

Hence, please do not use this plugin on any commercial web site.
The website snapshots may take few minutes to load up. But once they are in your cache, the collage gets generated very quickly.

== Installation ==

Download the zip file and follow the instructions below:

    * Unzip the file
    * Upload the folder webcollage to your wordpress plugins directory/folder
    * Activate the plugin in your wordpress admin/plugins page.
    * To create a webcollage on a page, insert the tag "[webcollage]".
