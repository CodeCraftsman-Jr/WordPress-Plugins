=== Plugin Name ===
Contributors: nilswindisch
Donate link: http://nilswindisch.de
Tags: mootools, framework
Requires at least: 2.0
Tested up to: 2.6
Stable tag: 1.2

This plugin adds the Mootools Javascript framework to your site. Useful if you use/code plugins that require Mootools.

== Installation ==

1. Upload the folder `mootools-framework` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

Great, isn't it. You're done!

== Frequently Asked Questions ==

= Is the a version history? =

[yes, here](http://nilswindisch.de/code/wordpress/plugin-mootools/)

== Screenshots ==

no, it's really not that exciting.