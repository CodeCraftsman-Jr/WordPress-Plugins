=== gcal-table ===
Tags: google calendar, calendar, table, events
Requires at least: 3.5
Stable tag: 0.4.0
License: The MIT License (MIT)
License URI: http://opensource.org/licenses/MIT

Plugin to display a Google Calendar feed as a html table.

== Description ==

Gcal-table will display a Google Calendar feed in your blog post or page as a html table

To insert the table you need the calendar-ID of the calendar you want to display.
Place to following shortcode where you want the table to appear:
`[gcal-table url="CALENDAR-ID"]`

####The following options are available:
* Date-format
* Time-format
* Number of events


== Screenshots ==

1. Example Calendar integration

