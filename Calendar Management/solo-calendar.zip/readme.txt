=== SoloCalendar ===
Tags: solocalendar, solo
Requires at least: 3.9
Tested up to: 4.2
Stable tag: 1.2
Contributors: solocalendar.com
Donate link: http://solocalendar.com/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

SoloCalendar simplifies process of adding booking form to your site

== Description ==

This plugin adds a little button in your post editor with all booking forms from your SoloCalendar account.

== Installation ==

1. Activate the plugin

2. Log into your SoloCalendar.com account and click top right link (your name)

3. Copy API key you'll see

4. Paste API key into plugin\'s settings page

5. You will see SC button in the editor with your booking forms from your SoloCalendar account.

== Screenshots ==

1. Plugin's settings page

2. Post editor with integrated SoloCalendar button