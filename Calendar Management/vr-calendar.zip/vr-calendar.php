<?php
/*
Plugin Name: Vacation Rental Calendar
Plugin URI: http://strongenging.com/vrwt/wordpress.php
Description: Shortcode for displaying a vacation rental calendar via an iCal feed
Version: 1.2.1
Author: Strong Engineering LLC
Author URI: http://strongenging.com/
*/

require('php/admin-page.php');
require('php/shortcodes.php');
