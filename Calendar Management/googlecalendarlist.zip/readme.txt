=== Plugin Name ===
Contributors: Crisium
Donate link: http://tumblingdrills.com/help-improve
Tags: 1.0,1.1
Requires at least: 2.0.2
Tested up to: 3.3.2
Stable tag: 1.1
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shows a fancy event list from your google calendar. Use [googlecalendarlist] on your pages or posts.

== Description ==

Shows a fancy event list from your google calendar. 

Use [googlecalendarlist] on your pages or posts.


== Installation ==

Use the standard wordpress install.

Modify the settings under the Settings Menu -> googleCalendarList

Use the [googlecalendarlist] on your pages or posts to see the event list.

== Frequently Asked Questions ==

= A question that someone might have =

== Screenshots ==

1. Screenshot of the settings
2. Screenshot of a page using [googlecalendarlist] shortcode

== Changelog ==

= 1.0 =
* Initial commit.

= 0.1 =
* add some documentation

== Upgrade Notice ==

= 1.0 =
*Initial commit

== A brief Markdown Example ==

Ordered list:

1. Easy to read event view from a google calendar.
1. Localization options.

`<?php code(); // goes in backticks ?>`