<?php
if(class_exists('AttendanceAdmin')){
?>

		<div id="attendance-header" class="clearfix">
			<div class="plugin-name">出勤・勤怠管理プラグイン <?php echo OSAM_PLUGIN_VERSION; ?></div>
			<div class="header-link"><a href="http://lp.olivesystem.jp/category/wordpress-plugins" target="_blank">お知らせ・プラグイン情報</a> | <a href="http://lp.olivesystem.jp/wordpress" target="_blank">サイト制作</a> | <a href="http://lp.olivesystem.jp/wordpress%E3%83%97%E3%83%A9%E3%82%B0%E3%82%A4%E3%83%B3%E9%96%8B%E7%99%BA" target="_blank">プラグイン開発</a> | <a href="http://lp.olivesystem.jp/license#attendance" target="_blank">ライセンス取得</a></div>
		</div>

<?php
}
?>