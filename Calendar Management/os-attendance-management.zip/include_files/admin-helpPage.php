<?php
if(class_exists('AttendanceAdmin')){
?>
	<div id="attendance-plugin">
		<?php include_once(OSAM_PLUGIN_INCLUDE_FILES."/admin-head.php"); ?>
		<?php include_once(OSAM_PLUGIN_INCLUDE_FILES."/user-helpPage.php"); ?>
	</div>

<?php
}
?>