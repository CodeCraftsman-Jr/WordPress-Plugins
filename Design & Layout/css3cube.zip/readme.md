# CSS3 Cube #
**Contributors:**      fracalo
  
**Tags:**              css3, cube, front-page, customizer, preview
  
**Requires at least:** 4.1
  
**Tested up to:**      4.1.2
  
**Stable tag:**        1.0.0
  
**License:**           GPLv2 or later
  
**License URI:**       http://www.gnu.org/licenses/gpl-2.0.html
  

Integrates a cube-template for displaying page previews on front page in css3 cube fashion, configurable through the wp-customizer.


## Description ##
The CSS3 Cube plugin is made for displaying feature content in front page;
you'll be able to build a css3 cube on front page and use the sides of the cube to preview the featured pages content.

The featured content is configurable through the customizer.


### Usage ###
Once installed the plugin navigate to the customizer screen an have fun!!


## Changelog ##

### 1.0.1 ###
 * added opacity setting on cube sides.
 * fixed CSS issues.
