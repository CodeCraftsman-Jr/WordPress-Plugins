<?php

/*
* Title                   : Booking System (WordPress Plugin)
* Version                 : 2.0
* File                    : views/views-frontend.php
* File Version            : 1.0
* Created / Last Modified : 14 October 2014
* Author                  : Dot on Paper
* Copyright               : © 2012 Dot on Paper
* Website                 : http://www.dotonpaper.net
* Description             : Booking System front end views class.
*/

    if (!class_exists('DOPBSPViewsFrontEnd')){
        class DOPBSPViewsFrontEnd extends DOPBSPViews{
            /*
             * Constructor
             */
            function DOPBSPViewsFrontEnd(){
            }
        }
    }