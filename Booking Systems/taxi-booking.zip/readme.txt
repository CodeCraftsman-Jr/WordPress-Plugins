=== The Booking Form - ground transportation, taxi, limo, minicabs ===
Tags: booking form,booking integration,booking,taxi booking,shuttle booking,airport transfers,transfers booking
Requires at least: 4.2.2

This plugin will integrate The Booking Form from booking.drivenot.com with your WordPress website.

== Description ==
DriveNot The Booking Form is a hosted online and mobile booking and dispatch system for Transportation companies - taxi, shuttle, limo, mini cab, private hire vehicles, chauffeur etc.

[Get The Booking Form](http://booking.drivenot.com) here.

With this wordpress plugin you can publish The Booking Form on your WordPress website.

See DriveNot [The Booking Form demo](http://booking.drivenot.com/demo-frame#demo) here.

== Installation ==
Normal WordPress installation process. 