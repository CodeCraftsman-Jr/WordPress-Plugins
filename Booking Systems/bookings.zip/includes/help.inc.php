<div id="zingiri-help">
<h3>Help</h3>
<ul>
<li><a href="http://www.zingiri.com/go/downloads.php?action=displaycat&catid=6" target="_blank">User Manual</a></li>
<li><a href="https://wordpress.org/support/plugin/bookings" target="_blank">Support Forums</a></li>
<?php if (get_option('bookings_lic')) {?>
<li><a href="http://www.zingiri.com/go/submitticket.php?step=2&deptid=5" target="_blank">Technical Support</a></li>
<?php } else {?>
<li><a href="javascript:alert('Support is only available to Bookings Pro users.\nPlease upgrade to Pro or use our forums instead.');">Technical Support</a></li>
<?php }?>
<li><a href="http://www.zingiri.com/go/submitticket.php?step=2&deptid=12" target="_blank">Sales Enquiry</a></li>
<li><a href="http://www.zingiri.com/bookings/pricing-signup/" target="_blank">Get Bookings Pro</a></li>
</ul>
</div>
