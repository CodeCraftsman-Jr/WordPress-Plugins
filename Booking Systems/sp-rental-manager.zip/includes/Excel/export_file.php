<?php
include_once('databasecon.php');//to make database connecti

?>	
	
	
	
	
	