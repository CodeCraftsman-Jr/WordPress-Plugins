	
	
	function sp_rm_add_feature(){
		
		jQuery('#sp_rm_feature_end').before('<div id="sp_rm_feature_main" class="sp_rm_feature">Feature Name <input type="text" name="features[]" value=""> Feature Value <input type="text" name="features_value[]" value=""></div>');
	}
	
