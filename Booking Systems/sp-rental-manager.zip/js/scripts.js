jQuery(document).ready(function() {

	
	
	
	
	jQuery('.sp_rm_change_image').bind('click', function() { 		
		
		jQuery('.sp_main_image').attr('src', jQuery(this).attr('href'));
		return false;
	})







;});