<?php

class Services_Twilio_Rest_Lookups_PhoneNumbers extends Services_Twilio_LookupsListResource { }
