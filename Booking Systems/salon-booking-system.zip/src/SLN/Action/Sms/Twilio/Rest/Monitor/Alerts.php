<?php

class Services_Twilio_Rest_Monitor_Alerts extends Services_Twilio_MonitorListResource {

}
