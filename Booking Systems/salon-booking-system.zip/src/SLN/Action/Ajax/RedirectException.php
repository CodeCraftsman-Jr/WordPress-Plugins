<?php

/**
 * marino: yes it's dirty and i like it:)
 */
class SLN_Action_Ajax_RedirectException extends Exception{

}