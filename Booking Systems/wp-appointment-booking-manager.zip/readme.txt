=== Wordpress Appointment Booking Manager ===
Contributors: upscalethought

Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=upscalethoughtsoln@gmail.com&item_name=Donation+for+Appointment_booking_manager
Tags: booking, appointment, appointment scheduling, appointment scheduling booking, event booking, appointment booking, doctors schedule, admin, administration, AJAX, appointment, availability, availability calendar, lawer appointment scheduling booking, Book, Booking calendar, booking form, booking system, booking engine, booking module, booking plugin, calendar, contact form, Physiotherapists appointment scheduling,  service booking,online booking calendar, online reservation, Reservation, reservation calendar, reservations, reservation plugin, service scheduling, schedule, scheduling, date blocker, jquery, management, meeting, Meeting scheduling, Organizer, rent, Rental, reservation system, schedule calendar, schedule system, service, to book, tutors appointment booking, instructors schedule booking, singer appointment scheduling, php appointment booking system, php mysql appointment schedule booking, wordpress online appointment schedule booking, wordpress appointment schedule reservation, Wordpress appointment schedule booking, wordpress appointment schedule booking script, singer appointment,artist appointment,photographer appointment scheduling booking, wp appointment schedule manager, wp  appointment schedule reservation system, wp reservation script

Requires at least: 3.3.0
Tested up to: 4.2
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


"Wordpress Appointment Booking Manager" provides an easy way to manage your appointment schedule booking and check availability in custom Calendar.

== Description ==

Using "Wordpress Appointment Booking Manager" plugin you can manage online Appointment Schedule Booking services for your site.
You can manage the bookings (availability) on an ourly/custom time basis. booking calendar page will be created automatically and to generate
calendar in frontend shortcode will be automatically copied. you can add/edit service/venue/timeslot or any schedule or delete bookings from admin to manage the full system.
you can show and manage your appointment scheduling/any service(or something else).


> **Get more features and full technical support with our pro verison**
> [Wordpress Appointment Booking Manager Pro](http://upscalethought.com/?page_id=9 ) also comes with a premium paid version. Upgrade to [Wordpress Appointment Booking Manager Pro]( http://upscalethought.com/?page_id=9).
>


Your Customers will be able to:

	
= KEY BENEFITS: =
- very easy to install and configure. 
- Very flexible functionality. Fit to very wide range of business.
- All bookings and settings are stored in your DB. You don't need third party account(s).
- An easy to use Booking Admin Panel that displays bookings in Calendar Overview and lets you manage bookings.
- Built with jQuery, Ajax and other technologies.
- Easy to install and integrate into your site. because necessary post or page will be automatically created and shortcodes will be automatically copied to page.
	
= FEATURES: =
- Make appointment schedule bookings in friendly booking interface - select the date(s) and fill form fields.
- Prevent of double booking for already reserved schedule time (1 booking per 1 schedule or time slot for a venue).

= Additional Features Available with the Pro (paid) version only =
- Free Installation Service
- Unlimited Service and Venue Entries
- Integrated Payment Gateways
- Built in Shopping Cart Enabled
- Personalized Calendar User Interface
- Manage Booking Straight From the Custom Made Calendar
- Unlimited Background Color setting for Schedule Event
- Dynamic Customized date Picker for Service/Schedule wise
- Appointment Scheduling Calendar month, week and day view
- Full Technical Support From Us

[Upgrade to the Pro version](http://upscalethought.com/?page_id=9) for all the pro features.


= Manage your Bookings in Admin Panel: =
- Comfortable Admin Panel for appointment schedule booking management. View appointment bookings in Calendar Overview Panel (Timeline) with possibility to set Day/Week/Month view 
	or in Booking Listing Table with pagination.
- In manage booking Search the booking(s) by different parameters, using the Filter in Admin Panel.
- Pagination of the booking listing.
- Administrator can edit or Delete specific bookings.
- View the bookings in booking calendar of any month of any year.

= You can use this booking calendar as: =
- Booking calendar / availability calendar for a doctor, lawyer, therapist, gym instractor.
- Booking calendar / availability calendar for a phycologist.
- Booking calendar / availability calendar for a consultant.
- Booking calendar / availability calendar for counseling.
- A shift calendar.
- Whatever you need!
	 
This plugin is compatible and tested up to Wordpress Version: 4.1 

<p>Some of our popular extensions include the followings:</p> 
<p><a rel="nofollow" href="https://profiles.wordpress.org/upscalethought/#content-plugins">UpScaleThought Wordpress Plugin</a></p>

Check http://upscalethought.com/?page_id=9 for more Plugins.


== Screenshots ==

1. Admin - add appointment

2. Admin - add css fix

3. Admin - add schedule

4. Admin - add service

5. Admin - add timeslot

6. Admin - add venue

7. Admin - add-edit appointment popup

8. Admin - appointemnt calendar-month view

9. Admin - appointment calendar- day view

10. Admin - event background color setting

11. Admin - manage appointment

12. Admin - payment setting-general

13. Admin - payment setting-payemnt method

14. Admin - appointemnt calendar-weekview

15. Front - calendar day view

16. Front - calendar month view

17. Front - calendar week view

== Changelog ==

= 1.0 =
This is the initial version of the plugin.

== Installation ==

1) Copy/Upload 'appointgen-ustsappointment' folder to the '/wp-content/plugins/' directory
2) Activate 'Wordpress Appointment Booking Manager' form wp plugin option in admin area
3) Plugin will appear in the menu bar of WP Dashboard
4) create timeslot/venue/service/schedule for booking.
5) please save primary menu if no rooms gallery or booking calendar is showing in front end.

== FAQ ==

= 1.1 =
First version of Wordpress Appointment Booking Manager . No errors known.