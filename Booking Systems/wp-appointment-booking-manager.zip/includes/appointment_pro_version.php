<style type="text/css">
  .btnprover {
      background: linear-gradient(to bottom, #2638B8, #3498db) repeat scroll 0 0 #3cb0fd;
      border-radius: 3px;
      color: #ffffff;
      font-family: Georgia;
      font-size: 15px;
      padding: 8px 15px;
      text-decoration: none;
  }
</style>
<div class="wrapper">
  <div class="wrap" style="float:left; width:100%;">
    <div id="icon-options-general" class="icon32"></div>
    <div style="width:70%;float:left;"><h2>Wordpress Appointment Booking Manager Pro</h2></div>
       <div class="main_div">
        <div class="metabox-holder" style="width:98%; float:left;">
            <div id="namediv" class="stuffbox" style="width:60%;min-height:450px;">
              <h3 class="top_bar">More Features Available in Our Pro Version:-</h3>
              <div style="padding-top:15px;margin-left:20px;">
                <a class="btnprover" target="_blank" href="http://upscalethought.com/?page_id=9" style="width:100px;height: 20px;background-color: #2638B8;color:white;" >Wordpress Appointment Booking Manager Pro</a>
              </div>  
               <form id="frmCssFix" action="" method="post" style="width:100%">
                 <div style="margin: 20px;">
                    <ol>
                      <li>Free Installation Service</li>
                      <li>Unlimited Service and Venue Entries</li>
                      <li>Integrated Payment Gateways.</li>
                      <li>Built in Shopping Cart Enabled</li>
                      <li>Personalized Calendar User Interface</li>
                      <li>Manage Booking Straight From the Custom Made Calendar</li>
                      <li>Unlimited Background Color setting for Schedule Event</li>
                      <li>Dynamic Customized date Picker for Service/Schedule wise</li>
                      <li>Appointment Scheduling Calendar month, week and day view</li>
                      <li>Full Technical Support From Us</li>
                    </ol>
                   <div style="padding-top:15px;">
                     <b>Please Have Our Professional Version to get more features and full supports </b><br/><br/><br/>
                     <a class="btnprover" target="_blank" href="http://upscalethought.com/?page_id=9" style="width:100px;height: 20px;background-color: #2638B8;color:white;" >Wordpress Appointment Booking Manager Pro</a>
                    </div>
                   <div style="float:right;padding-top:35px; font-size: 11px;">Developed by: <a target="_blank" href="http://upscalethought.com/">UpScaleThought Solutions</a></div>
                 </div> 
               </form>	 
            </div>
         </div>
       </div>  
  </div>
</div>