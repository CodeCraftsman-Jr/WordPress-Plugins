<?php
if ( !include_once( plugin_dir_path( __FILE__ ) . '../common/constants.php') ) echo "timebank include error";
if ( !include_once( plugin_dir_path( __FILE__ ) . '../common/mysql_functions.php') ) echo "timebank include error";
?>