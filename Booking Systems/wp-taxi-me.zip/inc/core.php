<?php

require_once( WP_TAXI_ME_PLUGIN_PATH . '/inc/options.php' );
require_once( WP_TAXI_ME_PLUGIN_PATH . '/inc/display-options.php' );
require_once( WP_TAXI_ME_PLUGIN_PATH . '/inc/widget.php' );

?>