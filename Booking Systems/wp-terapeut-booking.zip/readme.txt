=== WP Terapeut Booking ===
Contributors: BoMoellerDK
Tags: Terapeut Booking
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 3.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Terapeut Booking is a plugin for users of the online booking platform found on www.terapeutbooking.dk

== Description ==

The plugin is rather simple. It makes it possible for users of Terapeut Booking to insert a link to a popup booking form on any place of their WordPress website.
Simply install the plugin and insert [wpterapeut] on any page of your WordPress site to enable a link for your users to show your booking form.

== Installation ==

Simply activate the plugin by installing it through the WordPress Plugin search in your WordPress installation.
After activation there will be a new menu for "Terapeut Booking."

In the new menu you can configure your settings. 

== Frequently Asked Questions ==

= Is it possible to simply link to a booking form instead of the popup? =

Yes - this proces is described in Terapeut Booking. Login on system.terapeutbooking.dk and follow the description there.

== Changelog ==

= 1.0 =
* First version of the plugin

= 1.1 =
* Bug fixes

= 1.2 =
* Bug fixes for warnings showing

= 2.0 =
* Bug fixes

= 3.0 =
* Newest release

= 3.1 =
* Newest release

= 3.2 =
* Newest release

