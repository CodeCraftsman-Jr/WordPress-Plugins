<?php
/**
 * Silence is golden.
 *
 * @package SuperSaaS
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
