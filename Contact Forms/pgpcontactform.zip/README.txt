=== PgpContactForm ===
Contributors: maxvgc
Donate link: 
Tags: comments, spam
Requires at least: 2.0.2
Tested up to: 3.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Widget for generating pgp encrypted messages in javascript (and
sending in php).

== Description ==

This widget allows any site visitor to send the site owner a PGP
encrypted message. The public key encryption is done in javascript,
and sent to the server via ajax for maximum transparency. The widget
requires uses a captcha to prevent bots.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. upload and activate plugin zip archive
2. visit [url to plugin]/install/index.html Past your public key in the form. 
3. Copy the output values into [url to plugin]/install/config.js 
4. put your email address in [url to plugin]/install/config.php
5. in the widget control menu, place the contact widget in the sidebar.

== Frequently Asked Questions ==
= what's my public key? =
start here: http://www.gnupg.org/

== Changelog ==

= 1.0 =
first release!

== Upgrade Notice == 
first release!

== Screenshots ==
screenShot.png
