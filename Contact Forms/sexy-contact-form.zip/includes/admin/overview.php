<div id="cpanel">
	<div class="icon">
		<a href="admin.php?page=sexyforms" title="Forms">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/category.png' , __FILE__ );?>" /><br />
						Forms
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon">
		<a href="admin.php?page=sexyfields" title="Fields">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/answer.png' , __FILE__ );?>" /><br />
						Fields
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon">
		<a href="admin.php?page=sexytemplates" title="Templates">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/template.png' , __FILE__ );?>" /><br />
						Templates
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>


<div id="cpanel">
	<div class="icon" style="float: right;">
		<a href="http://creative-solutions.net/wordpress/creative-contact-form" target="_blank" title="">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/shopping_cart.png' , __FILE__ );?>" /><br />
						Buy Commercial Version!
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon" style="float: right;">
		<a href="http://creative-solutions.net/forum/creative-contact-form-wordpress/" target="_blank" title="">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/forum.png' , __FILE__ );?>" /><br />
						Support Forum
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
<div id="cpanel">
	<div class="icon" style="float: right;">
		<a href="http://creative-solutions.net/wordpress/creative-contact-form" target="_blank" title="">
			<table style="width: 100%;height: 100%;text-decoration: none;">
				<tr>
					<td align="center" valign="middle">
						<img src="<?php echo plugins_url( '../images/project.png' , __FILE__ );?>" /><br />
						Project Homepage
					</td>
				</tr>
			</table>
		</a>
	</div>
</div>
