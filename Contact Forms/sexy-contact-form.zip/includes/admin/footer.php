<table class="adminlist bottom_table" style="width: 100%;clear: both;"><tr><td align="center" valign="middle" id="twoglux_ext_td" style="position: relative;">
	<div id="twoglux_bottom_link"><a href="http://creative-solutions.net/wordpress/creative-contact-form" target="_blank">Creative Contact Form</a> developed and designed by <a href="http://creative-solutions.net/" target="_blank">Creative Solutions</a></div>
	<div style="position: absolute;right: 2px;top: 7px;">
		<a href="http://creative-solutions.net/wordpress/creative-contact-form" target="_blank" id="twoglux_ext_homepage" style="margin: 0 2px 0 0px;" class="twoglux_ext_bottom_icon" title="Go to project homepage">&nbsp;</a>
		<a href="http://creative-solutions.net/forum/creative-contact-form-wordpress/" target="_blank" id="twoglux_ext_support" class="twoglux_ext_bottom_icon" title="Here You can ask any questions related to this plugin">&nbsp;</a>
		<a href="http://creative-solutions.net/wordpress/creative-contact-form" target="_blank" id="twoglux_ext_buy" class="twoglux_ext_bottom_icon" title="Buy version without backlink and limits">&nbsp;</a>
	</div>
</td></tr></table>

<style>
.wpsxp_more_products {
	padding-bottom: 14px;
	border-bottom: 2px dashed #bbb;
	font-style: italic;
	color: #464646;
	margin: 15px 0 30px 10px;
	font-weight: normal;
	font-size: 22px;
	text-align: center;
}
.wpsxp_ext_name {
	display: block;
	font-style: italic;
	font-weight: bold;
	margin: 0 0 20px 5px;
	text-decoration: none;
	font-size: 26px;
}
.wpsxp_more_product_links {
	display: inline-block;
	float: left;
	padding: 5px 10px;
	font-style: italic;
}
#twoglux_ext_homepage {
	overflow: hidden;
	text-decoration: none;
}
</style>