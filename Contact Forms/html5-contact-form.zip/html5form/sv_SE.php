<?php 
 $language_array = array("Name" => "Namn", 
 						"Email"=>"E-post",
						 "Subject"=>"Ämne",
						 "Message"=>"Meddelande",
						 "The entered letters did not match the control"=>"Bokstäverna du angav matchade inte kontrollen",
						 "You have to enter your name" => "Du måste ange ditt namn!",
						 "You have to enter a valid email adress!" => "Du måste ange en giltig epostadress!",
						 "You have to enter an email adress!" => "Du måste ange en epostadress!",
						 "You have to enter a subject" => "Du måste ange ett ämne!",
						 "You have to enter a message" => "Du måste skriva ett meddelande!",	
						 "Sender" => "Avsändare",	
						 "Your message was sent successfully!" => "Ditt meddelande skickades!",	
						 "There was a problem sending your message, please try again!" => "Ett problem uppstod när ditt meddelande skulle skickas. Vänligen försök igen.",
						 "Submit" => "Skicka",
						 "Enter the text above" => "Ange vilka bokstäver du ser ovan"
	);
 ?>