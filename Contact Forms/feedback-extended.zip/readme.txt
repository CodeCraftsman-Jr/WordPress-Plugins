=== Feedback Extended ===
Contributors: Ehsanul Haque
Author URI: http://ehsanIs.me/
Tags: feedback, reply, extended, jetpack, contact form
Requires at least: 2.8
Tested up to: 3.5.1
Stable Tag: 1.0.0
License: GPLv2
Donate link: http://ehsanis.me/donate/

This plugin requires Jetpack 1.3 or up with Contact Form plugin active. This plugin will enable users to reply to feedbacks from the
admin panel.

== Description ==

With Contact Form active under Jetpack (1.3 or higher) this plugin will add a
new option in the "Feedback Management" area to reply to each message sent.

When a visitor send an email using the Contact Form, the message is sent to
email of the site's owner as well as stored under "Feedback Management" area.
This plugin lets users to reply directly from WP Admin using nice text editor.

The emails are sent in HTML format and user can change the name and email
address the mail will be sent from.


== Installation ==

This plugin can be installed in the standard plugin installation process.

i.e.

1. Upload feedback-extended under /wp-content/plugins/ directory
2. Activate the plugin from Plugins menu

== Changelog ==

= 1.0.0 =
* First release

