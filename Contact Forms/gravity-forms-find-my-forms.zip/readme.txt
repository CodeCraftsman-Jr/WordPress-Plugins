=== Gravity Forms Find My Forms ===
Contributors: benhays
Donate link: 
Tags: gravity forms, gravityforms, find my forms, find forms
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Generate a list of all your forms and which pages they're being used on.

== Description ==

Generate a list of all your forms and which pages they're being used on.

== Installation ==

1. Install as a regular WordPress plugin
2. Create one or many forms
3. Add forms to so many pages that you forget where they are
4. Navigate to Forms->Find My Forms to see where your forms are located

== Frequently asked questions ==

== Screenshots ==

== Changelog ==

### 1.0 
* Initial release

== Upgrade notice ==