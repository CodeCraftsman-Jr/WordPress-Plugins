<?php 
function  html_show_sp_contact_global(){


?>
<div class="updated" style="font-size: 14px; color:red !important"><p><strong>Global Options is disabled in free version. If you need this functionality, you need to buy the commercial version.</strong></p></div>
<table>
              <tr>   
<td width="100%" style="font-size:14px; font-weight:bold"><a href="http://web-dorado.com/5-options/wordpress-contacts-guide-step-5-1.html" target="_blank" style="color:blue; text-decoration:none;">User Manual</a><br />
This section allows you to configure the global options. <a href="http://web-dorado.com/5-options/wordpress-contacts-guide-step-5-1.html" target="_blank" style="color:blue; text-decoration:none;">More...</a><br />
If you want to customize to the global options of your website,than you need to buy a license.
</td>   
<td colspan="7" align="right" style="font-size:16px;">
  <a href="http://web-dorado.com/files/fromSpiderContactsWP.php" target="_blank" style="color:red; text-decoration:none;">
<img src="<?php echo plugins_url("images/header.png",__FILE__) ?>" border="0" alt="http://web-dorado.com/files/fromSpiderContactsWP.php" width="215"><br>
Get the full version&nbsp;&nbsp;&nbsp;&nbsp;
</a>
  </td>
  </tr>
  </table>
      <img src="<?php echo plugins_url("images/global.jpg",__FILE__) ?>" >
<?php
      


}











function html_show_sp_contact_Styles(){


?>



<div class="updated" style="font-size: 14px; color:red !important"><p><strong>Styles and Colors is disabled in free version. If you need this functionality, you need to buy the commercial version.</strong></p></div>

<table>
      <tbody>
          <tr>   
          <td width="100%" style="font-size:14px; font-weight:bold"><a href="http://web-dorado.com/5-options/wordpress-contacts-guide-step-5-2.html" target="_blank" style="color:blue; text-decoration:none;">User Manual</a><br />
          This section allows you to configure the styles and colors. <a href="http://web-dorado.com/5-options/wordpress-contacts-guide-step-5-2.html" target="_blank" style="color:blue; text-decoration:none;">More...</a><br />
          If you want to customize to the styles and colors of your website,than you need to buy a license.</td>   
          <td colspan="7" align="right" style="font-size:16px;">
  <a href="http://web-dorado.com/files/fromSpiderContactsWP.php" target="_blank" style="color:red; text-decoration:none;">
<img src="<?php echo plugins_url("images/header.png",__FILE__) ?>" border="0" alt="http://web-dorado.com/files/fromSpiderContactsWP.php" width="215"><br>
Get the full version&nbsp;&nbsp;&nbsp;&nbsp;
</a>
  </td>
          </tr>
      
      </tbody>
</table>
<img src="<?php echo plugins_url("images/styles_and_colors.jpg",__FILE__) ?>" >


<?php
      

}



function html_show_sp_contact_massages_options(){


		  
		  
		  ?>
        <div class="updated" style="font-size: 14px; color:red !important"><p><strong>Message Options is disabled in free version. If you need this functionality, you need to buy the commercial version.</strong></p></div>
          <table>
<tbody>

              <tr>   
<td width="100%" style="font-size:14px; font-weight:bold"><a href="http://web-dorado.com/5-options/wordpress-contacts-guide-step-5-6.html" target="_blank" style="color:blue; text-decoration:none;">User Manual</a><br />
This section allows you to configure the Message Options. <a href="http://web-dorado.com/5-options/wordpress-contacts-guide-step-5-6.html" target="_blank" style="color:blue; text-decoration:none;">More...</a><br /> 
If you want to customize to the message options of your website,than you need to buy a license.</td>     
 <td colspan="7" align="right" style="font-size:16px;">
  <a href="http://web-dorado.com/files/fromSpiderContactsWP.php" target="_blank" style="color:red; text-decoration:none;">
<img src="<?php echo plugins_url("images/header.png",__FILE__) ?>" border="0" alt="http://web-dorado.com/files/fromSpiderContactsWP.php" width="215"><br>
Get the full version&nbsp;&nbsp;&nbsp;&nbsp;
</a>
  </td>
        </tr>

</tbody>

</table>
        <img src="<?php echo plugins_url("images/massag_op.jpg",__FILE__) ?>" >
<?php	  


}

