    <div class="manage-column scfp-field scfp-field-actions scfp-field-center" scope="col" style="">Actions</div>    
    <div class="manage-column scfp-field scfp-field-export scfp-field-center" scope="col" style="">Export to CSV</div>
    <div class="manage-column scfp-field scfp-field-required scfp-field-center" scope="col" style="">Required</div>
    <div class="manage-column scfp-field scfp-field-visibility scfp-field-center" scope="col" style="">Visibility</div>
    <div class="manage-column scfp-field scfp-field-name" scope="col" style="">Name</div>
    <div class="manage-column scfp-field scfp-field-type" scope="col" style="">Type</div>
    <div class="manage-column scfp-field scfp-field-num" scope="col" style="">Num</div>
