<html lang="en">
<head>
    <meta charset="utf-8"/>	
</head>
<body>
	<div id="main">	
		<div id="main-content">		
            <div class="content">
                <?php echo $params['message'];?>
            </div>
        </div>
    </div>
</body>
</html>