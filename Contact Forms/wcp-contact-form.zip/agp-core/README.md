# AGP Plugins Core

Collection of a base classes for custom WordPress plugins