<?php
namespace Webcodin\WCPContactForm\Core;

class Agp_DbConnectException extends Agp_ExceptionAbstract {
}


