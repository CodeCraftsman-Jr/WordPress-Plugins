<?php
namespace Webcodin\WCPContactForm\Core;

class Agp_Entity extends Agp_EntityAbstract {
}
