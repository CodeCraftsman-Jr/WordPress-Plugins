Collection of a base classes for a custom WordPress plugins

== Changelog == 

= 1.0.6 =
* added: Some global functions for control PHP version

= 1.0.5 =
* Changed: Minor bugfixing

= 1.0.4 =
* Changed: Optimized autoloader class

= 1.0.3 =
* Added: Possibility for generate and include 'classmap.json' file to the autoloader class

= 1.0.2 =
* Changed : Agp_Module::toUrl
