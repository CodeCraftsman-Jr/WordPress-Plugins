<?php
return array(
    'scfp_form_settings' => array(
        'title' => 'Form',
    ),
    'scfp_style_settings' => array(
        'title' => 'Style',
    ),            
    'scfp_error_settings' => array(
        'title' => 'Messages',
    ),    
    'scfp_notification_settings' => array(
        'title' => 'Notifications',
    ),    
    'scfp_recaptcha_settings' => array(
        'title' => 'reCAPTCHA',
    ),        
);