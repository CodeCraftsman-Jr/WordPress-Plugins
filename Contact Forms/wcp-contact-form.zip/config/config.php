<?php
return array(
    'admin' => array(
        'menu' => include (__DIR__ . '/admin-menu.php'),
        'options' => include (__DIR__ . '/admin-options.php'),        
    ),    
    'form' => include (__DIR__ . '/form.php'),        
);


