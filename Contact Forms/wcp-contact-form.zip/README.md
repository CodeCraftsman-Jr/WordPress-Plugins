# wcp-contact-form

Quickly add simple contact form to your site and easily adjust it to your needs.

# Installation

1. Download a copy of the plugin
2. Unzip and Upload 'wcp-contact-form' to a sub directory in '/wp-content/plugins/'.
3. Activate the plugins through the 'Plugins' menu in WordPress.
4. Add shortcode [scfp id="unique-form-id"] on Your page
