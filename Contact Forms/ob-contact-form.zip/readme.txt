=== OB Contact Form ===
Contributors:  owebest
Donate link: http://owebest.com/
Tags: contact form, simple contact form, OB contact form, email contact form, contact us form, email contact us form,contact form plugin wordpress , simple contact form plugin wordpress, wordpress contact form plugin,best wordpress contact form, wordpress contact form, wordpress simple contact form, 
Requires at least: 3.0.1
Tested up to: 4.2.3
Stable tag: 1.0
License: GPLv3 
License URI: http://www.gnu.org/licenses/gpl-3.0.html

OB Contact form is a simple contact form which works out of the box. Use shortcode on posts or pages to generate OB Contact Form. 
== Description ==

OB Contact form is a simple contact form which works out of the box. Use shortcode on posts or pages to generate OB Contact Form.OB Contact Form send all the submitted entries to admin specified email address.
Settings page provides the ease of defining custom Subject, From Name, From Email, Success Message and Error Message.

Add on plugins coming soon to save all entries into database and list them in admin panel.

== Installation ==

1. Upload `OB-contact-form.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Check the OB Contact Form menu in the left side navigation to know the shorcode or use `[obcf_contact_form]`

== Frequently Asked Questions ==

= Can i use shortcode in pages? =

Yes, you can use the shortcode in posts and pages.

= Can i customize email address and email subject? =

Yes, you can specify custom email,name,subject,success message and error message in plugin's setting page.


== Screenshots ==

1. OB Contact Form Settings page
2. OB Contact Form on page

== Changelog ==
= 1.0 =
Main Release

== Upgrade Notice ==

= 1.0 = 
Main Release


== Arbitrary section ==


== A brief Markdown Example ==

Ordered list:

1. Ready to use contact form
1. Customizable notification email address
1. Custom success and error message
