=== FEP Contact Form ===
Contributors: shamim51
Tags: email,mail,contact form, secure contact form, simple contact form,akismet check,akismet
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=4HKBQ3QFSCPHJ&lc=US&item_name=Front%20End%20PM&item_number=Front%20End%20PM&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Requires at least: 2.8
Tested up to: 4.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

FEP Contact Form is a secure contact form to your WordPress site.This can be used with Front End PM or without.

== Description ==
FEP Contact Form is a secure contact form to your WordPress site.This can be used with [Front End PM](https://wordpress.org/plugins/front-end-pm/) or without.

* Admins can set how many messages to show per page in the message box.
* Admins can see all contact message sent to any user.
* Admins can select department and to whom message will be send for that department.
* Manual and AKISMET check of contact message.
* Reply directly to Email address from front end.
* Send Email to any Email address from front end.
* IP, Email blacklist, Whitelist.
* Time delay between two messages send by same user/visitor.


== Installation ==
1. Upload "fep-contact-form" to the "/wp-content/plugins/" directory.
1. Activate the plugin through the "Plugins" menu in WordPress.
1. Create a new page.
1. Paste code `[fep-contact-form]` for FEP Contact Form and `[fep-contact-form-admin]` for FEP Contact Form admin area under the HTML tab of the page editor.
1. Publish the page.


== Frequently Asked Questions ==
= Can i use this plugin to my language? =
Yes. this plugin is translate ready. But If your language is not available you can make one. If you want to help us to translate this plugin to your language you are welcome.


== Screenshots ==

1. FEP Contact Form
2. FEP Contact Form Settings
3. FEP Contact Form Settings 2

== Changelog ==

= 3.2 =

* Initial release.

== Upgrade Notice ==

= 3.2 =

* Initial release.