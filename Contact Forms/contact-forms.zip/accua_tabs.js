jQuery(document).ready(function($) {
	$("#accua_tabs .hidden").removeClass('hidden');
	$("#accua_tabs").tabs();
});
