<?php
class Element_File extends Element {
	protected $attributes = array("type" => "file");
}
