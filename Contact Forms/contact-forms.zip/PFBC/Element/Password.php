<?php
class Element_Password extends Element_Textbox {
	protected $attributes = array("type" => "password", "class" => "pfbc-textbox");
}
