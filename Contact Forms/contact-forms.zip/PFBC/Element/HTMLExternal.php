<?php
class Element_HTMLExternal extends Element_HTML { }
