<?php
/**
 * @version    $Id$
 * @package    WR_Library
 * @author     WooRockets Team <support@woorockets.com>
 * @copyright  Copyright (C) 2012 WooRockets.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.woorockets.com
 */

if ( ! defined( 'WR_CF_LIBRARY_TEXTDOMAIN' ) ) {
	// Text domain for WR Library
	define( 'WR_CF_LIBRARY_TEXTDOMAIN', 'wr-cf-library' );
}
