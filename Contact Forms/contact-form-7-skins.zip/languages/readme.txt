==Adding Translation==

To translate this plugin to your language,
please copy the "cf7skins.po" file and rename with adding
your language country code.
Example for Spanish translation "cf7skins-es_ES.po"

Use Poedit http://poedit.net/download.php to translate the file.