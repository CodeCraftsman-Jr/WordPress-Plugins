=== SimpleContactForm ===
Contributors: Saifuddin Shamim,Mainul Islam, Hasan Mahtab
Donate link: 
Tags: widget, contact, form, contact form, feedback, email,
Version:  1
Requires at least: 3.1
Tested up to: 4.2.2
Stable tag: 4.2


Just another contact form plugin. Simple but flexible.

== Description ==

SimpleContactForm can manage contact forms, plus you can customize the form and the mail contents flexibly with simple markup.



== Installation ==

= First time installation instructions =

   1. Download and unzip SimpleContactform.zip folder to your wordpress plugin directory
   2. Copy the unzipped folder in your Plugins directory under wordpress installation. (wp-content/plugins).
   3. Activate the plugin through the plugin window in the admin panel.
   4. Use the shortcode [SimpleContactForm] to publish the form.


