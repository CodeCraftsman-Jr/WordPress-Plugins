=== Plugin Name ===
Contributors: mithublue, cybercraftit
Tags: WPUF, wpuf, WP User Frontend, WPUF Contact Form, Contact Form, Wordpress User Frontend Contact Form
Requires at least: 3.6
Tested up to: 4.2.2
Stable tag: ''
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An extension of WP User Frontend Plugin to help you make contact form easily and effectively with lots of fields provided.

== Description ==

> #### Note .

> You must have [**wp user frontend plugin**](https://wordpress.org/plugins/wp-user-frontend/) or [**wp user frontend pro**](https://wedevs.com/products/plugins/wp-user-frontend-pro/) installed and activated to have this plugin working !


Note : 

* Unlimited contact forms
* Numerous form fields
* Both ajax (in page) and non ajax (reload page) form process
* Different settings for customization

And many more ...


* Quick Demo On How to Use This Plugin !


[youtube https://youtu.be/GdwUGydA0Ms]





== Installation ==


1. Upload `WPUF Contact Form` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png

== Changelog ==

== 0.1 ==
WPUF Contact Form Released !
