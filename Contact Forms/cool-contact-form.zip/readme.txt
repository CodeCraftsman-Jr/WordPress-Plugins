=== Cool Contact Form ===
Contributors: Nischal Maniar
Tags: contact, form
Requires at least: 2.0.2
Tested up to: 2.7
Stable tag: 1.0

A cool simple contact form with javascript validation. Easy to style through Cascading Style Sheet.

== Description ==
Easy to use contact form. Displays nice looking validation errors and success messages on respective failure and success while sending the mail.

== Installation ==
1) Unzip the plugin in your plugins folder and activate the plugin
2) In the settings section, Enter the title for the contact page and also the email address you want to the recieve the email. Incase no email address is set in the settings, then the mail will be recieved at the email registered for your wordpress blog.
3) Creating a contact page is easy, just add a new Page through your wordpress admin and add following line in that page. <--contact form-->
4) If you want to style the contact form, you will have to do it through your stylesheets of your theme.
5) That's it ! Enjoy !

== Screenshots ==
1) When validation fails
2) When mail sent successfully
3) Content for the contact page