jQuery(document).ready( function( $ ) {

	// Define color picker
	$('.wp-color-picker-field').wpColorPicker();
});