=== Plugin Name ===
Contributors: Alagappan Karthikeyan 
Donate link: me@karthik.sg (paypal id)
Tags: recaptcha form, recaptcha contact form, contact, form, contact form, recaptcha, antispam, captcha, contact form with captcha,secured contact form,secure contact form,contact form with captcha validation.
Requires at least: 3.0
Tested up to: 3.3
Stable tag: 1


Jax Contact form with captcha is simple plugin for your WordPress blog that enables you to have a contact form
with the reCAPTCHA validation field.   

For more information visit http://www.karthik.sg/wp_projects/jaxcon/ 
or to my 
My wordpress profile : http://profiles.wordpress.org/users/karthiksg

== Description ==

Jax Contact form with captcha is simple plugin for your WordPress blog that enables you to have a contact form
with the reCAPTCHA validation field.

Secured Contact form with field validation and spam protect with google` recaptcha

Requirements : 

1. recaptcha private and public keys
      You may need to sign up for recaptcha keys which is available free in the following link -> http://www.google.com/recaptcha
2. one working email address.


Related Links:

* <a href="http://www.karthik.sg/wp_projects/jaxcon/" title="Wordpress contact form with recaptcha plugin">Plugin Homepage</a>
* <a href="http://www.karthik.sg/wp_projects/jaxcon/support/" title="Wordpress contact form with recaptcha plugin">Support Page</a>

== ChangeLog ==

* First release.


== Installation ==

= 2.7 and Older =
Sorry, we do not officially support installations on WordPress 2.8 or older.

= 2.7, 3+ =

<ol>
<li>Unzip jaxcon.zip</li>
<li>Upload jaxcon to your `/wp-content/plugins/` directory</li>
<li>Activate the plugin through the 'Plugins' menu in WordPress</li>
<li>Configure email id and recaptcha keys</li>
<li>Enjoy! Read the <a href="http://www.karthik.sg/wp_projects/jaxcon/">FAQ</a>if there's any errors</li>
</ol>

For video demonstration on this plugin installation, 
kindly visit www.karthik.sg/wp_projects/jaxcon/
If you want to rebuild or want to make custom changes in my code you can svn to the below link for source code. -> http://code.google.com/p/jax-contact-form/source/browse/


== Frequently Asked Questions ==

<b>1. How to get recaptcha keys ?</b>
      You can get it by signing up with your gmail or google account which is available free
      link -> http://www.google.com/recaptcha


== Upgrade Notice ==

Planning to upgrade with more fields or custom fields adding option
Coming Soon..

== Screenshots ==

The below screenshot shows the working copy of contact form
