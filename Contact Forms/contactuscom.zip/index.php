<?php

/**
 * CONTACT FORM BY CONTACTUS.COM
 * 
 * Initialization Contact Form Plugin
 * @author ContactUs.com <support@contactus.com>
 * @copyright 2014 ContactUs.com Inc.
 * Company      : contactus.com
 **/

// Silence is golden.