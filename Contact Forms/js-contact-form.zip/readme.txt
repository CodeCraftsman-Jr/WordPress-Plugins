=== Js Contact Form ===
Contributors: Cx Rana
Developer link: https://cxrana.com
Tags:  Js Contact Form, Wordpress contact form, java scripts wordpress contact plugin, wordpress contact plugin,contact page,Cx Rana,Wp Feedback,WP Contact,js contact form,Bangladesh,contact with us,emails
Requires at least: 2.3
Tested up to: 4.2.4
Stable tag: trunk

Java Scripts Contact Form,with attachment support and Empty Form validation.

== Description == 
= How to Use =
after installation then go to plugin Editor >Js Contact Form.php and search "yourname@mail.com" then replace it with your own email address.</br>
Now go to add new page> Create new pages> paste this code  [contact_form] 

= If Show Error = 
if show Error (Mail Sending Failed): please check your contact form destination e-mail address,login to dashboard> Go to plugin Editor>Js Contact Form.php and and search "yourname@mail.com" then replace it with your own email address.

= Features =
* Simple Contact Pages for Your WordPress Website</br>
* Java Scripts validation Form</br>
* Empty Form validation 
* File/Photos Attachment


Some active user. <a href="http://www.kingsolomonhotel.com/">King Solomon Hotel, London</a>

== Changelog ==

= 2.0 = 
* WordPress 4.2.4 approved


== Installation ==

1. Upload the whole plugin folder to your /wp-content/plugins/ folder.
2. Go to the Plugins page and activate the plugin.
3. Go to your Go to plugin Editor>Js Contact Form.php and and search "yourname@mail.com" then replace it with your own email address.
4. Now create a new pages and paste this code [contact_form]



== Screenshots ==

1. Js Contact Form Example
2. Live Example, King Solomon Hotel, London

== License ==

This file is part of Js Contact Form.

Js Contact Form is free Plugin: don't modify it,under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

Js Contact Form is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with WP Wall. If not, see <http://www.gnu.org/licenses/>.


== Frequently Asked Questions ==

= How does it work? =

It creates a Contact page in your blog under which some config. 

= What if I don't show form, how do I code this to appear in the Contact Page?

Just put this code contact page in your addnew page,

[contact_form]

= How can I Replace contact form destination e-mail ?

Now Go To Go to plugin Editor>Js Contact Form.php and and search "yourname@mail.com" then replace it with your own email address.

= Can I suggest an feature for the plugin? =

Of course, visit <a href="http://cxrana.com">Js Contact Form Contributor</a>

= I like your work, are you available for hire? =

Yes I am, visit my <a href="http://www.cxrana.com">Visit..</a> page to find out more.