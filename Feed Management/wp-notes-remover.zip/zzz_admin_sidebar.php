<style>
    .zzz_app_admin_sidebar {
      
    }

    .zzz_app_admin_sidebar .more_plugins_list li a {
        background: url("<?php echo $WebWeb_WP_NotesRemover_obj->get('plugin_url')?>/zzz_media/star.png") no-repeat scroll 0 0 transparent;
        padding: 0 0 3px 20px;
    }

    .zzz_app_admin_sidebar_like_box, .zzz_app_admin_sidebar_more_plugins {
        clear: both;
        padding-top: 10px;
    }
</style>
<div class="zzz_app_admin_sidebar">
        <?php echo $WebWeb_WP_NotesRemover_obj->generate_newsletter_box(array('form_only' => 1, 'src2' => 'admin_sidebar')); ?>
    
        <br />
        
        <div class="zzz_app_admin_sidebar_more_plugins">
            To request custom web development work please go to <a href="http://Orbisius.com/" target="_blank" title="[New window/tab]">http://Orbisius.com</a>
        </div>

        <div class="zzz_app_admin_sidebar_more_plugins">
            See other <a href="http://profiles.wordpress.org/users/lordspace/profile/public/" target="_blank" title="[New window/tab]">plugins</a> from the same author.
        </div>

        <div class="zzz_app_admin_sidebar_like_box">
            <iframe src="//www.facebook.com/plugins/likebox.php?href=www.facebook.com%2Fpages%2FWebWebca%2F172278676154985&amp;width=250&amp;height=558&amp;colorscheme=light&amp;show_faces=true&amp;border_color&amp;stream=true&amp;header=false&amp;appId=291949997486374" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:250px; height:558px;" allowTransparency="true"></iframe>
		</div>
</div>