<?php
defined( 'ABSPATH' ) or die( 'No direct access please.' );
# Silence is golden.