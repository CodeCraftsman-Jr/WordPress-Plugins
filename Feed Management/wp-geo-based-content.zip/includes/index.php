<?php 
defined( 'ABSPATH' ) or die( 'No direct access please.' );
#silence is gold