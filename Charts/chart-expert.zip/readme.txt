=== Chart Expert ===
Contributors: sagortouch
Tags: area chart, bubble chart, chart, column, donut chart, line, pie chart, responsive, row, table, wordpress plugin
Requires at least: 3.3
Tested up to: 4.1.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Unlimited chart generate plugin .

== Description ==

PmZez Chart Expert by http://pmzez.com/plugins/chart-expert/

Chart Expert gives some classes to each element when generating, so you can define a custom style by the class and it's possible to extend the structure directly by D3 and C3. 

Go to TinyMCE Editor >> Find chart icon and generate chart .

Plugin Features

* Eazy to Installation
* Timeout load another chart
* All browser supported
* Chart load form CSV
* All chart available
* Lightweight
* Responsive
& many More

Youtube : 
https://www.youtube.com/watch?v=5H5JjXeiB-8

Live Preview: http://pmzez.com/plugins/chart-expert/

* Create a post / page and then enable TinyMCE , find chart icon and this icon for generate following chart :

     i) Basic

    ii) Advanced

* Basic :

    1. Insert div ID for plot this chart . Div id may any name like: chart_one, chart_two etc.

    2. Insert CSV file URL that which data you want to plot to chart . That's why you need to first upload a csv data file with header name .

    3. Select chart type like : Bar, Pie, Donut, Line etc.

* Advanced : Actually this section for timeout feature : First load data from one CSV file and then default 1 sec later the chart load another CSV data .  For more example : http://pmzez.com/plugins/chart-expert/

    1. Insert div ID for plot this chart . Div id may any name like: chart_one, chart_two etc.

    2. Insert CSV file URL that which data you want to plot to chart . That's why you need to first upload a csv data file with header name .

    3. Input timeout period , like 1000 for 1 sec, 5000 for 5 sec .

    4. Insert another CSV file URL that which data you want to plot to chart after default 1 sec later . That's why you need to first upload a another csv data file with header name  . For more example : http://pmzez.com/plugins/chart-expert/

    3. Select chart type like : Bar, Pie, Donut, Line etc.

* Enjoy



== Installation ==

* Install it as a regular WordPress plugin.

* After Installed this plugin will work properly.

* Go to TinyMCE Editor >> Find chart icon and generate chart .

* Install Chart Expert plugin and active it on WordPress deshboard plugin section.

* Create a post / page and then enable TinyMCE , find chart icon and this icon for generate following chart :

     i) Basic

    ii) Advanced

* Basic :

    1. Insert div ID for plot this chart . Div id may any name like: chart_one, chart_two etc.

    2. Insert CSV file URL that which data you want to plot to chart . That's why you need to first upload a csv data file with header name .

    3. Select chart type like : Bar, Pie, Donut, Line etc.

* Advanced : Actually this section for timeout feature : First load data from one CSV file and then default 1 sec later the chart load another CSV data .  For more example : http://pmzez.com/plugins/chart-expert/

    1. Insert div ID for plot this chart . Div id may any name like: chart_one, chart_two etc.

    2. Insert CSV file URL that which data you want to plot to chart . That's why you need to first upload a csv data file with header name .

    3. Input timeout period , like 1000 for 1 sec, 5000 for 5 sec .

    4. Insert another CSV file URL that which data you want to plot to chart after default 1 sec later . That's why you need to first upload a another csv data file with header name  . For more example : http://pmzez.com/plugins/chart-expert/

    3. Select chart type like : Bar, Pie, Donut, Line etc.

* Enjoy 

== Screenshots ==

* example -1

* example -2

* example -3

* example -4

* example -5


== Changelog ==

* Initial Release - 1.0

