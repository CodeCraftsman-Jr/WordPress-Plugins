=== Gs_MenuCategories ===
Contributors:
Tags:
Requires at least:
Tested up to:
Stable tag: trunk

Creates a menu structure as a widget, where all posts are placed inside the corresponding category.
