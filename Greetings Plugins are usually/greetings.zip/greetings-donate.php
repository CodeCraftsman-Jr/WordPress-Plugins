<?php
    if(!current_user_can('manage_options')) {
	    die('Access Denied');
    }
?>
    <div class="wrap">
        <h2>If you find this plugin useful to you, please consider making a small donation to help contribute to further development. Thanks for your kind support!</h2>
        <a href="http://rubensargsyan.com/donate/"><img src="https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif" border="0" alt="Donate"></a>
    </div>
