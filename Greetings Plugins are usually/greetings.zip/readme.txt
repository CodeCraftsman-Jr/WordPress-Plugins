=== Greetings ===
Contributors: s_ruben
Donate link: http://rubensargsyan.com/donate/
Tags: greetings, congratulations, occasion, widget, AJAX, occasion
Requires at least: 2.8
Tested up to: 3.0.3
Stable tag: trunk

Any occasion to receive greetings? So, this plugin is just for you!

== Description ==

Any occasion to receive greetings? So, this plugin is just for you! This Widget plugin shows a greeting image which would be uploaded for the occasion and a pop up form for receiving the greetings. It is possible to show the greetings in any post or page.

= In administrator panel you can do the following: =
1. Configure options.
2. Approve, unapprove and delete the greetings.
3. Upload the images, one of which will be shown random by widget.

I wish you to have many occasions to recieve greetings!!!

[Plugin Homepage](http://rubensargsyan.com/wordpress-plugin-greetings)

== Installation ==

1. Upload the greetings directory (including all files within) to the /wp-content/plugins/ directory.
2. Activate the plugin through the Plugins menu in WordPress.
3. Go to the "Appearance"->"Widgets" panel and drag-and-drop the "Greetings" box into your sidebar, configure options and save.
4. To view the greetings write the tag [greetings] in a post or page.

== Frequently Asked Questions ==

For questions contact with the plugin author - [Ruben Sargsyan](http://rubensargsyan.com/contact).

== Screenshots ==

1. Add Greeting
2. The Greetings
3. Greetings Options
4. Edit Greetings
5. Edit Images

== Changelog ==

= 1.1 =
* Changed some deprecated functions.
* Now the avatars of the greetings authors can be shown.

= 1.0 =
* First release.