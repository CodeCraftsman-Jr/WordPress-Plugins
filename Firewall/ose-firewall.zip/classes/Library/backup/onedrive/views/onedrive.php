<?php

class onedriveViewBup extends viewBup
{

}
