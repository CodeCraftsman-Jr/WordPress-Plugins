<?php  
/* 
   Plugin Name: Centrora Security Badge
   Description: Plugin For Showing Centrora Security Badge 
   Author: Centrora Security
   Version: 5.0.15
*/  
include(dirname(__FILE__).'/includes/oseBadgeWidget.php');
?>
