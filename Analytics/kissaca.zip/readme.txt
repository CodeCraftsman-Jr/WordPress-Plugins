=== Kissaca ===
Contributors: OzqaN
Donate link: http://www.ozqan.com
Tags: word, words, sidebar,short
Requires at least: 1.0
Tested up to: 1.0
Stable tag: trunk

Show the area you want in a short blog articles

== Description ==

Show the area you want in a short blog articles.Blog articles that you added appears in the writings of different.

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [Kissaca Readme](http://www.ozqan.com/kissaca-wordpress-eklentisi/  "Kissaca Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[OzqaN WordPress Plugins Development Blog](http://www.ozqan.com/ "OzqaN WordPress Plugins Development Blog")

== Installation ==

[Kissaca Readme](http://www.ozqan.com/kissaca-wordpress-eklentisi/  "Kissaca Readme") (Installation Tab)

== Upgrade Notice ==

= 1.0 =
Do not upgrade now.

== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.


== Screenshots ==

[Kissaca Screenshots](http://www.ozqan.com/kissaca-wordpress-eklentisi/ "Kissaca Screenshots")

== Frequently Asked Questions ==

[Kissaca Support](http://www.ozqan.com/kissaca-wordpress-eklentisi/ "WP-Ban Support ")