<?php /*
Plugin Name: iCharts
Plugin URI: http://dcoda.co.uk/wordpress/
Description: Easily Insert iCharts into your post.
Author: dcoda
Author URI: http://dcoda.co.uk
Version: .4.45
 */
require_once  dirname ( __FILE__ ) . '/library/wordpress/application.php';
new wv35v_application ( __FILE__);
