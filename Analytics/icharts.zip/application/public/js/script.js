function icharts() {};
icharts.prototype = new v35v(icharts_data);
jQuery(document).ready(function() {
	icharts = new icharts();
});
