=== iCharts ===
Contributors: icharts , dcoda
Donate link: 
Tags: charts,icharts, editor,data
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: .4.45

icharts is a WordPress Plugin that allows you to easily insert an iChart in your post.

== Description ==

This plugins requires a PHP 5.2 or above.

icharts is a WordPress Plugin that allows you to easily insert an iChart in your post.

The main purpose of the plugin is to correctly embed icharts into your blog post. 

The plugin is designed to be small, fast and easy to use. 

Once installed, all you need to use it is to click the icharts button and a popup will request the URL where the chart you need to embed is present. You input the URL in the popup and press enter. The system will insert the appropriate embed code including setting the size (height and width) from the source chart.

Plugin was designed and developed for <a href="http://icharts.net">iCharts</a> by <a href="http://profiles.wordpress.org/users/dcoda/">DCoda</a>.

Maintained by <a href="http://icharts.net">iCharts</a> Contact us at info@icharts.net

== Installation ==

1. Disable and delete any old versions of the plugin.
2. Copy the plugin folder to `wp-content/plugins`
3. Log in to WordPress as an administrator.
4. Enable the plugin in the `Plugins` admin panel.
5. Click the 'Getting started' link that now appears next to the plugin.
