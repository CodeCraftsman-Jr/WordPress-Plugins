<?php
class wv35v_cap extends bv35v_base {
}	