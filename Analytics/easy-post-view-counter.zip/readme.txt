=== Easy Post View Counter ===

Contributors: Michael Ringhus Gertz
Tags: post views, post hits, post counter, view counter, postviews
Donate link: http://ringhus.dk
Requires at least: 2.7
Tested up to: 4.1.1
Stable tag: 1.2.3
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

With this plugin you can see how many views a single post has.

== Description ==

With this plugin you can see how many views a single post has.
Just link on the All Post link in the left menu
No need for adding codes anywhere, just plug'n'play

== Installation ==

1. Download the zip file.
2. Extract the zip file. you will now get a folder called EasyPostViewCounter
3. Upload the EasyPostViewCounter folder to wp-content/plugins/
3. Activate Easy Post View Counter under admin menu
4. Done! you are now able to see how many views you posts has

== Frequently Asked Questions ==

= Where can i see the counter =
Under All Posts there is a column, it only shows a digits, which is the amount of times the post has been viewed.

= Can i see how many times the post has been view before installing this plugin =
No, this plugin will not show views before it was installed.

= How can I reset the counter? =
Under Custome Fields, there is a entry called EasyPostViewCounter, change the value of that one to 0. There is no way to reset all posts yet

= Will it count my own views? =
No it will only count views for non administrators.

== Screenshots ==
= There is no screenshots yet =


== Change Log ==

= Version 1.2.3 =
- Fixed counting issue

= Version 1.2.2 =
- Fixed issue where posts are being counted multible times.
- Tested with WP 4.1.1 

= Version 1.2.1 =
- Ensured that this version worked with Wordpress 4.0

= Version 1.1 =
- Made it possible to sort post be views.

= Version 1.0 =
- First released version







