=== TrackbackShotR ===
Contributors: Ahmet
Tags: trackback, pingback, shot, snapshot, snap, websnapr, blog, gravatar, trackbackshotr
Requires at least: 2.5.1
Tested up to: 2.6.5
Stable Tag: 0.3

== Description ==

EasyGravatar is a Plugin to show the gravatars of Commentators, but Trackbacks and Pingbacks haven't
got Email adresses, so they can't have a gravatar. For this, i have create a Plugin named TrackBackShotR
which shows instead a gravatar a snapshot of the Blog of the TB or PB. You can use this with EasyGravatars,
because it doesn't change anything with comments, just with TB and PB

= Localization =

* **English** \* Author: [Ahmet Topal](http://basicblogger.de/2008/12/07/wp-plugin-trackbackshotr/)

== Installation ==

Just upload the .php file and activate it, more under setting/TrackbackShotR

== Frequently Asked Questions ==

No questions Jet

== Screenshots ==

Please visit: http://basicblogger.de/2008/12/07/wp-plugin-trackbackshotr/