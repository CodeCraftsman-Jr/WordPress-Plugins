=== Social Fabric Analytics From Collective Bias ===
Contributors: chriswhittle,jonbeers,clintford,mattjacobson 
Donate link: http://collectivebias.com/
Tags: social fabric, collective bias
Requires at least: 3.0.0
Tested up to: 4.2.2
Stable tag: trunk

Adds the custom code used for Social Fabric campaigns

== Description ==

This plugin adds the custom code used for Social Fabric campaigns

== Installation ==

1. Upload plugin's zip to the `/wp-content/plugins/` directory
2. Extract files
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Enjoy
5. Follow community instructions

== Frequently Asked Questions ==

See community threads

== Screenshots ==

N/A

== Changelog ==

= 1.7 =
* Added formatting for the code to fix issues with some caches

= 1.6 =
* Change some indention
* Moved inline comment to different area to fix certain themes

= 1.0 =
* Birthed

== Upgrade Notice ==

= 1.0 =
* Birthed