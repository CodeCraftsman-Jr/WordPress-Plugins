=== Kiss Metrics ===
Contributors: Stinkyink
Tags: javascript, kiss metrics, analytics
Requires at least: 2.7
Author URI: http://www.stinkyinkshop.co.uk/themes/
Plugin URI: http://www.stinkyinkshop.co.uk/themes/plugins/kiss-metrics/
Tested up to: 3.3
Stable tag: 1.2.1

Enables Kiss Metrics on all pages.

== Description ==

This plugin adds the required javascript for Kiss Metrics.

For more information about Kiss Metrics visit:

[Kiss Metrics](http://www.kissmetrics.com)

For more on the plugin and support with installation, visit:

[Kiss Metrics Plugin @ Stinkyink Themes](http://www.stinkyinkshop.co.uk/themes/plugins/kiss-metrics/)

== Installation ==

1. Upload the `kiss-metrics` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the API Key from Kiss Metrics to the settings (Admin > Settings > Kiss Metrics)

== Changelog ==

1.2.1 - moved JS to wp_head to enable more features from KI.

1.2 - Added conditional to only show JS if API Key present.

1.1 - Bug Fixes

1.0 - Created Plugin