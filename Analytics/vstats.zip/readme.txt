=== VSTATS ===
Contributors: jinfo
Donate link: http://blog.javalog.de
Tags: vstats, counter, visits, wassup
Requires at least: 2.3.3
Tested up to: 2.3.3
Stable tag: trunk



VStats Wordpress Plugin

== Description ==
VStats Wordpress Plugin.  WassUp Plugin required! http://www.wpwp.org
The VStats plugin expands the WassUp plugin. 

Today visits,
Pageviews,
Last 24 h visits,
Day before,
Last week

will be shown inside the sidebar of the wordpress theme


== Installation ==

please visit my installation post: http://blog.javalog.de/?p=12

== Frequently Asked Questions ==

= Question? =

contact me: info@javalog.de

== Screenshots ==
1. VStats
2. VStats inside the Sidebar of Wordpress


