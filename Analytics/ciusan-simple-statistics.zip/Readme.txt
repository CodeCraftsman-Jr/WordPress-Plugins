=== Ciusan Simple Statistics ===
Contributors: Dannie Herdyawan
Donate link: http://www.ciusan.com/submit-donation/
Tags: ciusan, wp, user, registered, widget, total, sidebar, users, register, shortcode, comments, posts, statistics, guest, simple
Requires at least: 3.2
Tested up to: 4.1
Stable tag: 1.0

Show simple statistics.

== Description ==

**Show simple statistics**

<h5><strong>Features:</strong></h5>
<ul><li>Show all registered users on sidebar using widget or on post & page using shortcode.</li>
<li>Show all approved comments on sidebar using widget or on post & page using shortcode.</li>
<li>Show all publish posts on sidebar using widget or on post & page using shortcode.</li></ul>

<h5><strong>Shortcode:</strong></h5>
<ul><li>Use [ciusan_total_registered] for showing all registered users.</li>
<li>Use [ciusan_total_posts] for showing all publish posts.</li>
<li>Use [ciusan_total_comments] for showing approved comments.</li></ul>

<a href="http://plugin.ciusan.com/66/ciusan-simple-statistics/">Ciusan Simple Statistics</a>

== Installation ==

1. Upload 'ciusan-simple-statistics' folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to widget then drag and drop the ` Ciusan Simple Statistics` widget.

== Screenshots ==

1. Widget on Sidebar.
2. Using shortcode on post.
3. Widget sidebar option.

== Changelog ==

= 1.0 =
* First release.
