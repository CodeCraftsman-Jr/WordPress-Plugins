=== The Ultimate Live Tracker ===
Contributors: Nimish Gupta
Donate link: http://www.live.nimlinks.com/donation/
Tags: nimlinks,live.nimlinks,alivestats, live, traffic, live traffic, live users, online users, browsing users, traffic widget,The Ultimate Live Tracking Feed,The ultimate live tracker
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 1.0.2
License: GPL v3
License URI: http://www.gnu.org/copyleft/gpl.html

Best live traffic feed plugin.It is the Combo of : Live Tracking Feed+ Recent Visitors Online + Page Views Counter

== Description ==

The Ultimate Live Tracker by Alivestats.com is BEST Tool for Live Visitor Tracking Feed for Websites and Blogs or Any Other Online Content.It has advance tracking system with accuracy of 99.99%.
It can provide you visitors Browser Name,Operating System,Country Name,Country Flag,City Name,Referrer URL,Viewed Page,Search Query(Google,Bing),Detects Bots,Crawlers,Spiders,Time Of Entry,Total Activities of All Users,Recently Online Users

Web Application is Developed by :

Nimish Gupta & 
Vivek Raj Agarwal

= Tracker Features: =

* Detect IP Addresses Both IPv4 & IPv6
* Premium Material Design Widget
* 249 Countries Visitors Can be Tracked
* Track Website on Realtime
* Track Mobile Devices Information
* Track Operating System of the Visitors
* Adjust widget width.
* Unlimited color customization
* Completely free.!!
* Live Traffic feed powered by <a href="http://alivestats.com/">alivestats.com</a>.

= Visit  Official Website <a href="http://alivestats.com/">here</a> =


= Visit Developer Website <a href="http://www.techniblogic.com/">here</a> =

== Installation ==

Upload The Ultimate Live Tracker into you plugin directory (/wp-content/plugins/) and activate the plugin through the 'Plugins' menu in WordPress.

Customize your widget look and feel from settings page under settings tab.

Save everything and add widget from appearance.!!


== Frequently Asked Questions ==

= Which WordPress versions are supported? =
Tested from WordPress versions 3.0 to latest 4.2

= Can I customize the colors? =
Yes. You can use colour picker to customize complete look and feel.

= Why? =
* This is the only complete free plugin which give the Combo of : Live Tracking Feed+ Recent Visitors Online + Page Views Counter in a material design Widget


== Changelog ==

= 1.0.2 =
* Minor Bug Fixes

= 1.0.1 =
* Bugs Fixes .

= 1.0.0 =
* Free Public Plugin .



== Screenshots ==

1. Live traffic feed Widget example.
2. Customize the widget.
3. Widget Demo

== Upgrade Notice ==

* Bugs Fixes