=== Realtime analytics for the web ===
Contributors: statvoo
Tags: javascript, statvoo, analytics, traffic, realtime, chat, tracking, surf, customer engagement
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.2.5

<a href="https://statvoo.com/">Realtime analytics for the web</a> - <a href="https://statvoo.com/">statvoo.com</a>

== Description ==

Understand your website with <a href="https://statvoo.com/">statvoo.com</a> - <a href="https://statvoo.com/">Realtime analytics for the web</a>.

This plugin adds the tracking codes required to start using statvoo.com right now.

Create an account at <a href="https://statvoo.com/">statvoo.com</a> for FREE and you're done.

No need for complicated and lengthy integration guides.

For more information visit:

[Statvoo.com](https://statvoo.com/)

== Installation ==

1. Upload `statvoo` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. View (Admin > Settings > Statvoo.com) for further setup information
4. Make sure you have an account over at https://.statvoo.com/join
