<foaf:Document rdf:about="<?php echo htmlspecialchars(lh_rdf_curPageURL()); ?>">
<dc:title>SIOC Post profile for "LocalHero Beta"</dc:title>
<dc:description>A SIOC profile describes the structure and contents of a weblog in a machine readable form. For more information please refer to http://sioc-project.org/.</dc:description>
<foaf:primaryTopic rdf:resource="<?php the_permalink_rss() ?>"/>
<admin:generatorAgent rdf:resource="http://localhero.biz/plugins/lh-rdf/"/>
</foaf:Document>