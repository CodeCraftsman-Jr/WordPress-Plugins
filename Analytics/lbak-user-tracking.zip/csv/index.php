<?php
header("Status: 404 Not Found");
?>
