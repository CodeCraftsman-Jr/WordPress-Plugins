<?php
include_once dirname(__FILE__).'/../../faq.html';
?>
