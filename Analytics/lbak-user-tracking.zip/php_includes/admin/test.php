<?php
require_once lbakut_get_base_dir().'/tests/browserTests.php';
?>
