<section id="iteras-paywall-box" class="semantic-content iteras-paywall-box" data-snippet-size="%s">
  <div class="iteras-fade-bar"></div>
  <div class="iteras-box-content">
    %s
  </div>
</section>
