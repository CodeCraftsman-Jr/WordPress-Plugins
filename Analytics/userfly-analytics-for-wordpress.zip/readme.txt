=== Userfly Analytics for Wordpress ===
Contributors: Andy Stramer, Barsness Solutions
Donate link: http://serversideguy.com
Tags: userfly analytics, analytics, userfly, 
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: trunk


Nice and simple plugin that gives an easy option for Usefly code insertion

== Description ==

Nice and simple plugin that gives an easy option for Usefly code insertion

== Installation ==

This section describes how to install the plugin and get it working.


1. Upload 'userfly.php to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Insert Userfly code in the field on the Settings->Userfly page

== Frequently Asked Questions ==

= Why is my code not showing up? =

Firstly check the code that was inserted on the Settings Page. If that is correct, chances are you are missing the wp_head() function in the blogs header



