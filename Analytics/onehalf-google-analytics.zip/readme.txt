=== OneHalf Google Analytics ===
Contributors: itivanov
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZZK78GUAVAASA
Tags: google analytics, google, analytics, tracking
Requires at least: 3.0.1
Tested up to: 4.2.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enables Google Analytics on all blog pages.

== Description ==

OneHalf Google Analytics enables Google Analytics on all blog pages.

== Installation ==
1. Upload unzipped 'ohgoogleanalytics.zip' to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Setting -> OHGoogleAnalytics to enable plugin or modify options

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

== Upgrade Notice ==

== Arbitrary section ==