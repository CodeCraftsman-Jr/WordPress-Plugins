=== GTop Analytics ===
Contributors: butterflymedia, getbutterfly
Donate link: http://getbutterfly.com/wordpress-plugins-free/
Tags: gtop, footer, code, analytics, stats, statistics
Requires at least: 4.0
Tested up to: 4.1.1
Stable tag: 1.1.5.4
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Adds GTop Analytics code to your footer or any other widgetized zone without messing with the source code.

Read more about GTop on http://www.gtopstats.com/ [EN] or http://www.gtop.ro/ [RO].

== Installation ==

1. Put the plugin folder into [wordpress_dir]/wp-content/plugins/
2. Go into the WordPress dashboard and activate the plugin
3. Configure the plugin

== Changelog ==

= 1.1.5.3 =
* UPDATE: Updated WordPress version
* UPDATE: Added help and support links
* FIX: Fixed missing constant

= 1.1.5.3 =
* Added plugin icon
* Various code improvements

= 1.1.5.2 =
* Added license link
* Added donate link

= 1.1.5.1 =
* Cleaned up readme.txt file
* Added links to GTop

= 1.1.5 =
* Updated GTop code sample code for https
* Checked WordPress 3.8-beta compatibility

= 1.1.4.1 =
* Small UI tweaks

= 1.1.4 =
* Added GPL license and marked the readme.txt file
* Checked compatibility with the latest WordPress version
* Removed donate link

= 1.1.3 =
* Removed error reporting

= 1.1.2 =
* Removed hardcoded path
* Removed 2 redundant functions
* Fixed and updated for WordPress 3.5.alpha
* Changed author email
* Faster behaviour by tapping straight into _options table

= 1.1.1 =
* Removed an obsolete link
* Updated for WordPress 3.4

= 1.1 =
* Added widget for easier positioning

= 1.0 =
* First release
