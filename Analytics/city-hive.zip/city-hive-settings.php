<?php
  $CITY_HIVE_SETTINGS = array(
        "api_endpoint"                => "http://api.cityhive.net/api/v1/scan",
        "script_url"                  => "http://widget.cityhive.net/city-hive-widget.js",
        "metadata_name_auto"          => "city-hive-data-auto",
        "products_metadata_name"      => "city-hive-data",
        "related_products_metadata_name"      => "city-hive-data-related-products",
        "producers_metadata_name"      => "city-hive-data-producers",
        "products_noshow_meta"      => "city-hive-noshow"
        );
?>