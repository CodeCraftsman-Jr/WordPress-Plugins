=== WP Live Statistics ===
Contributors: paratheme
Donate link: 
Tags:  statistics, wordpress statistics, wp statistics, live statistics,wordpress stats, live visitors, live Stats, web Stats, analytics, visitors count, stats
Requires at least: 3.8
Tested up to: 4.2.4
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Live website stats for wordpress sites.

== Description ==

Awesome web stats for your website.
get stats for top things like broswers, operating system, Screen Size, Countries, Cities, Referers, Pages, User, link type and many more.



### WP Live Statistics by http://paratheme.com

* [Buy Premium!&raquo;](http://paratheme.com/items/wp-live-statistics-wordpress-stats-plugin/)


= Features =
**Awsome Dashboard for stats**

Awesome graphical representation for top site factors like Top OS, Top Screen Size, Top Browsers, Top Page Terms, Top Countries, Top Cities, Top Referers, Top Pages, Top User.

**Visitor Online**

see who visit your website now and from where by using Google map.

**Visitor List**

List of all visit by date some usefull data you will know about visitors.

**Filter Top Stats**

Filter stats between two date and find top factor for your website. like top 20 user, top 10 url and etc.

**Exclude Browser(Pro feature)**

Now you can exclude any browsers(bot's) for tracing visit.

**Exclude User by ID(Pro feature)**

You can exclude any user by id for tracing.



== Installation ==

1. Install as regular WordPress plugin.
2. Go your Pluings setting via WordPress Dashboard and activate it.

after activating plugin you will see menu "WP Live Stats"

take a test by visiting any page of your website.












== Screenshots ==

1. Dashboard.
1. Visitors list.
1. Live Visitors & Map.




== Changelog ==


= 1.2 =
* 27/01/2015 - add - stats for top factors on your site.


= 1.1 =
* 25/01/2015 - add - Refresh time to check visitor online.
* 25/01/2015 - add - Live visitors and map.
* 25/01/2015 - add - Visitors list page.

= 1.0 =
* 10/11/2014 - Initial release

