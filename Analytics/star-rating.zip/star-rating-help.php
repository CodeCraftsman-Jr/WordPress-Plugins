<?php

if ( ! defined('ABSPATH')) exit; // if direct access 

?>


<div class="wrap">
	<?php echo "<h2>".__(star_rating_plugin_name.' Help')."</h2>";?>
    <br />

	<div class="para-settings">  
        
        
	<h2>Have any issue ?</h2>

	<p>Feel free to Contact with any issue for this plugin, Ask any question via forum <a href="<?php echo star_rating_qa_url; ?>"><?php echo star_rating_qa_url; ?></a> <strong style="color:#139b50;">(free)</strong>
</p>


	<?php
    
    $star_rating_customer_type = get_option('star_rating_customer_type');
    $star_rating_version = get_option('star_rating_version');
    

    if($star_rating_customer_type=="free")
        {
    
            echo '<p>You are using <strong> '.$star_rating_customer_type.' version  '.$star_rating_version.'</strong> of '.star_rating_plugin_name.', To get more feature you could try our premium version. ';
            
            echo '<a href="'.star_rating_pro_url.'">'.star_rating_pro_url.'</a></p>';
            
        }
    elseif($star_rating_customer_type=="pro")
        {
    
            echo '<p>Thanks for using <strong> premium version  '.$star_rating_version.'</strong> of <strong>'.star_rating_plugin_name.'</strong> </p>';	
            
            
        }
    
     ?>


<!--
	<h2>Tutorial</h2>
	<p>Please watch this video tutorial.</p>
    
	<iframe width="640" height="480" src="//www.youtube.com/embed/8OiNCDavSQg?rel=0" frameborder="0" allowfullscreen></iframe>



 -->


<?php
if($star_rating_customer_type=="freeq")
	{
?>


        




	<div class="pricing-table">
        <h2>Pricing</h2>
        <p>you could try our premium version for features.</p>
        <div class="column">
            <div class="paln">Free</div>
            <div class="price">$0</div>
            <div class="cell"><span class="green">Life time free update.</span></div> 
            <div class="cell"><span class="red">Life time support via forum.</span></div>
            <div class="cell"><span class="red">Not applicable.</span></div>                         
            <div class="cell"><span class="green">Responsive Design.</span></div>        
            <div class="cell"><span class="red">Themes(Limited).</span></div>        
            <div class="price">$0</div>
        </div>
        
        <div class="column">
            <div class="paln">Premium</div>
			<div class="price"><a target="_blank" class="buy-now" href="<?php echo star_rating_pro_url; ?>">$5 Buy Now</a></div>
            <div class="cell"><span class="green">Life time free update.</span></div> 
            <div class="cell"><span class="green">Life time support via forum.</span></div>
            <div class="cell"><span class="green">7 Days refund.</span></div>        
            <div class="cell"><span class="green">Responsive Design.</span></div>        
            <div class="cell"><span class="green">Themes(All).</span></div>        
            <div class="price"><a target="_blank" class="buy-now" href="<?php echo star_rating_pro_url; ?>">$5 Buy Now</a></div>
        </div>    
        
    </div>



</div>





 
        
      <?php
      }
	  
	  ?>  
      
<br /> <br /> <br /> 
<h3>Please share this plugin with your friends?</h3>
<table>
<tr>
<td width="100px"> 
<!-- Place this tag in your head or just before your close body tag. -->
<script type="text/javascript" src="https://apis.google.com/js/platform.js"></script>

<!-- Place this tag where you want the +1 button to render. -->
<div class="g-plusone" data-size="medium" data-href="<?php echo star_rating_share_url; ?>"></div>

</td>
<td width="100px">
<iframe src="//www.facebook.com/plugins/like.php?href=<?php echo star_rating_share_url; ?>&amp;width=100&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=false&amp;height=21&amp;appId=743541755673761" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>

 </td>
<td width="100px"> 





<a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php echo star_rating_share_url; ?>" data-text="<?php echo star_rating_plugin_name; ?>">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
</td>

</tr>

</table>
        













    
         
</div>
<style type="text/css">
.star_rating-pro-features{}

.star_rating-pro-features li {
  list-style: disc inside none;
}

</style>