	jQuery(document).ready(function(jQuery)
		{	


			jQuery('#star-rating_items_position_color, #star-rating_items_content_color, #star-rating_items_title_color ').wpColorPicker();
					
					


		});