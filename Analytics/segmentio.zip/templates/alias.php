<script type="text/javascript">
	analytics.alias( "<?php echo esc_js( $from ); ?>", "<?php echo esc_js( $to ); ?>" );
</script>