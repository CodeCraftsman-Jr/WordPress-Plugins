=== Snoobi Tracking ===
Contributors: jsruok
Tags: analytics, snoobi, tracking
Requires at least: 2.5
Tested up to: 2.7.1
Stable tag: trunk

Track your visitors with Snoobi web analytics.

== Description ==

Snoobi Tracking inserts the Snoobi tracking code at the end of every page of 
your blog. You only have to enter the name your Snoobi account in plugin 
settings.

Note: your theme should use wp_footer() call. (See footer.php in your theme 
directory.)


== Installation ==

1. Upload `snoobi-tracking` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. Enter your Snoobi account name in settings page. 
