Launch Check
============

Launch Check is a WordPress plugin that ensures you have made your site visible to search engines, changed the default description, added Google Analytics and installed BruteProtect before launch.

Activate it when you are ready to launch your site and it will alert you if you need to make your site public, change the tagline, add the Google Analytics tracking snippet or setup BruteProtect to protect your site against botnets.
