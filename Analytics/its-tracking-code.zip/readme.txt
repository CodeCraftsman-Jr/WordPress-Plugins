=== IT's Tracking Code ===
Contributors: Intelligent Technology
Tags: tracking, code, admin, site, google, yahoo, bing, piwik, google analytics
Requires at least: 2.0.0
Tested up to: 4.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin used to add tracking code to header & footer section.

== Description ==

Add tracking code on your website without hacking your theme file.

This plugin provide simple way to add your tracking code in html head or footer section of the site.

Also you can use different language. To change language you need to generate .po and .mo files.

Features
* Add tracking code to header & footer section.
* Localization.

== Installation ==

1. Upload and extract 'zip' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add your tracking code by navigating Settings >> Tracking Code

== Frequently Asked Questions ==

None yet

== Screenshots ==

1. Add your tracking code here.

== Changelog ==

= 1.0.0 - 08/01/2015 =
* Initial release.