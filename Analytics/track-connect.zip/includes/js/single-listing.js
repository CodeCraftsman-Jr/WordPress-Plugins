jQuery(document).ready(function() {
	jQuery( "#listing-tabs" ).tabs();
	jQuery( "#inquiry-form" ).validate();
	jQuery( ".iframe-wrap" ).fitVids();
});
