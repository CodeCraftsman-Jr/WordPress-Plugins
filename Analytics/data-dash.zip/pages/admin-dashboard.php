<div class="wrap t201plugin">
	<h2>
		Dashboard
		<a href="<?php print admin_url('admin.php?page=dd-data-counter'); ?>" class="add-new-h2">All Counters</a>
	</h2>

	<div class="tbox">
		<div class="tbox-heading">
			<h3>Quick Overview</h3>
			<a href="http://labs.think201.com/plugins/data-dash" target="_blank" class="pull-right">Need help?</a>
		</div>
		<div class="tbox-body">
			<div id="plugin-description">
				<p class="shortdesc">Data dash allows you to create dynamic counters for your website pages.</p>
				<p class="shortdesc"><strong>Salient Features</strong></p>
				<p class="shortdesc">
				</p><ul>
				<li>Create counters which gets updated from server side</li>
				<li>Give time interval to update counters</li>
				<li>Provide range for the incremental value</li>
				<li>Easy integration to UI using short code &amp; function</li>
			</ul>
			<p>&nbsp;</p>
		</div>	
	</div>
	<div class="tbox-footer">

	</div>
</div>