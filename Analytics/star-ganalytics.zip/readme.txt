﻿=== star-ganalytics ===
Contributors: star
Tags: analytics, google, green, software, plugin
Requires at least: 2.8.4
Tested up to: 2.8.4
Stable tag: trunk
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=liuchangjun%40gmail%2ecom&item_name=wp-codec-cn&no_shipping=0&no_note=1&tax=0&currency_code=USD&lc=US&bn=PP%2dDonationsBF&charset=UTF%2d8

Simplest Google Analytics plugin. Add Google Analytics into the WordPress.

== Description ==

Simplest Google Analytics plugin. Add Google Analytics into the WordPress.

Semi-green software. Only one field `_star_ganalytics_key` is added into the table `wp_options`, there is no garbage in the database when you do uninstallation.

For more information, please visit http://liuchangjun.com/tag/star-ganalytics/

For demo, please visit http://demo.liuchangjun.com/

== Installation ==

1.Upload to your plugins folder, usually `wp-content/plugins/` and unzip the file, it will create a `wp-content/plugins/star-ganalytics/` directory.

2.Activate the plugin on the plugin screen.

3.Go into `Settings`->`Star Google Analytics`, input your google Web Property ID. e.g. `https://www.google.com/analytics/settings/home`

4.Done.

== Uninstallation ==

1.Go into `Settings`->`Star Google Analytics`, remove `Remove all Star Ganalytics Settings`.

2.Go into admin->plugins ,disable star-ganalytics.

3.Done.

== Frequently Asked Questions ==

None.

== Screenshots ==

None.

== Changelog ==

= 0.1 =

* Initial version.
