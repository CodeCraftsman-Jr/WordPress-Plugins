<?php
/**
 * Define signup
 */
define( 'WBOUNCE_NEWS_TEXT', 'To suggest and vote for new features: Let the developer come into contact with you.' );
define( 'WBOUNCE_NEWS_BUTTON', 'Get contacted' );
define( 'WBOUNCE_NEWS_GROUP', 'Signup via Plugin' );
define( 'WBOUNCE_NEWS_NAME', 'b_f65d804ad274b9c8812b59b4d_39ca44d8d3' );
define( 'WBOUNCE_NEWS_ACTION_URL', '//kevinw.us2.list-manage.com/subscribe/post?u=f65d804ad274b9c8812b59b4d&amp;id=39ca44d8d3' );