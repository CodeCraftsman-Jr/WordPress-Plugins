=== The Hits Counter ===
Contributors: gagan0123
Tags: Hits,Counter
Requires at least: 2.1
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Checks and displays the number of hits for posts and pages

== Description ==
Checks and displays the number of hits for posts and pages. There are a lot of other plugins like this already available, but none I found with this simplicity and lightweight.

== Installation ==

1. Add the plugin's directory in the WordPress' plugin directory.
1. Activate the plugin.
1. Enjoy your cup of coffee while the plugin takes care of hits on the posts and pages.

== Changelog ==

= 1.0 =
Initial Release