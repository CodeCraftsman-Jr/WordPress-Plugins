<?php
//Silence is Golden