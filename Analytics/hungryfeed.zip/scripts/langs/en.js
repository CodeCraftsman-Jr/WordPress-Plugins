tinyMCE.addI18n("en.hungryfeed",{
	title: 'HungryFEED Inline RSS',
	longname: 'HungryFEED Inline RSS',
	add: 'Add HungryFEED RSS'
});