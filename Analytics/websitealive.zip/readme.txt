=== WebSitealive ===
Contributors: WebsiteAlive
Tags: chat, zendesk, online chat, live chat, helpdesk, contact us, help desk, chat online, zopim, olark, web chat, livechat, chatting, webchat, help desk software, contact form, chat apps, snapengage, click-to-call, live chat software, chat live, chatbox, chat box, clickdesk, chat programs, live chats, online chats, online web chat, chatting online, live support, web chat online, live web chat, live chat online, chat on line, zopim chat, onlinechat, live chat app, chat web, chat server, on line chat, WordPress chat, wordpress live chat, wordpress live chat plugin, chatlive, live online chat, zopim live chat, chat service, website live chat, website chat software, add chat to website, online live chat, business chat, best live chat software, chat for website, chat applications, chat application, best live chat, online chat software, help desk support software, live customer service, best chat software, chat server software, live chat on website, add live chat to website, website chat widget, live help chat, web chat software, live chat button, live help messenger, live support software, live chat support software, online support chat, chat software for website, live chat widget, chat customer service, livechat software, chatting software, live support chat for website, online chat for free, help desk application, live chat apps, live chat agents, live chat agent, live chat script, live chat solutions, online chat for website, live chat software for website, live chat software for websites, live chat operators, online support software, website customer service, live chat php, help desk app, live help desk, online chat application, online chat customer service, live customer service chat, chat with customer service, live support online, instant online chat, web chat service, online support tools, web site chat, live website chat support, live chat support service, online chat on website, help desk chat software, live help desk software, customer help desk software, live customer support chat, live web chat software, chat for web site, online website chat, chat support services, customer support help desk, online live chat software, live support application, live customer support software, phone, content, free chat, Facebook chat, offline, footer, skype chat, footers, ticketing, free live chat software

WebsiteAlive is the easy-to-use Live Chat/Click-To-Call solution for your WordPress website. Visitors can immediately chat or initiate a click-to-call

== Description ==
WebsiteAlive is the easy-to-use Live Chat/Click-To-Call solution for your WordPress website. Visitors can immediately chat or initiate a click-to-call session with someone at your company who can answer their questions, in real-time. This WordPress plug-in instantly updates your WordPress site with WebsiteAlive Tracking Code which tracks visitors in real-time and also displays a call-to-action icon.

== Installation ==
Installation Instructions:
1. From your Wordpress Admin Dashboard, go to ‘Plugins’ and “Add New.”
2. In the search bar, type in “AliveChat” and then click the Search Plugins button.
3. You will see the “WebsiteAlive” plugin displayed. Click the “Install Now” link.
4. Wordpress will ask you if you are sure that you want to download the plugin. Click Yes.
5. Wordpress will install the plugin, then you will need to click the “Activate Now” link.

Configuration Settings:
Now that you have installed the AliveChat plugin, you are just minutes away from chatting
with your site visitors! To configure your AliveChat plugin, click on the WebsiteAlive link that
you see in the Main menu on the left hand column of your Admin Dashboard.

New Account Setup:
1. If you are new to AliveChat, click on the “New User. Sign Up Now” link.
2. Create a username, and input your email address. Then click the “Register” button
3. Success, your account is created! You will see a window that asks you to select the
website in your new AliveChat account that corresponds with your website, leave
this at “default”, then click “Save Changes”
4. You will receive an email, and your Admin login credentials will be contained
within it. Please go to http://www.websitealive.com and login as Admin.
5. You will need to create an Operator account by clicking on the “Operators” link on
the far left under the “Basics” tab, then click on the link “Create A New Operator”.
6. Now, whenever you are logged in to your operator account, you will see the
embedded icon displayed on your Wordpress site.
7. To change the positioning of your Embedded Icon, or to change the image,
please login to your Admin console from here: http://www.websitealive.com