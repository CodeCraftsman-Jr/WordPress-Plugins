=== Plugin Name ===
Contributors: Minda Sari
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=6DZFJFSVZCVAU
Tags: google maps, jquery, javascript, googlemaps, gmap, gmap3, maps
Requires at least: 3.5
Tested up to: 3.5.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

jQuery plugin to create google maps with advanced features (overlays, clusters, callbacks, events...)
== Description ==
jQuery plugin to create google maps with advanced features (overlays, clusters, callbacks, events...)

For more information visit http://gmap3.net/
Author visit <a href="http://dadanminda.wordpress.com">http://dadanminda.wordpress.com</a>


== Installation ==
1. Upload `indomap/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Input address in metabox post

Its recommended to flush the cache after upgrading.

== Frequently Asked Questions == 
None at this moment.

== Upgrade Notice == 

== Screenshots ==
1. screenshot-1.jpg
2. screenshot-2.jpg

== Credits ==
Created by [Minda Sari](http://www.dadanminda.wordpress.com/)

== Changelog ==
= 1.0.2 = 
* Support indomap on post_type page

= 1.0.1 = 
* Fix bug php tag

= 1.0 = 
* Release