=== Plugin Name ===
Contributors: Linkolo
Tags: linkolo, giełda linków, sprzedaż linków, pozycjonowanie, seo, kupno linków, pozycjonowanie, earn money, link sales
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 2.3.2

Plugin allows for quick system integration Linkolo.pl with a blog based on Wordpress. 

Plugin pozwala na szybką integrację systemu Linkolo.pl z blogiem opartym na WordPress.

== Description ==

Plugin allows for quick system integration Linkolo.pl with a blog based on Wordpress. 

Linkolo.pl is a system that allows the owners of websites make money on the links in the content of the publication of articles on their sites.
--------------------------------

Plugin pozwala na szybką integrację systemu Linkolo.pl z blogiem opartym na Wordpress. 

Linkolo.pl jest systemem pozwalającym właścicielom stron zarabiać na publikacji linków w treści artykułów na ich stronach.

== Installation ==

1. Before installation this plugin, you must upload Linkolo installation files into your Wordpress root directory.
2. Upload files to folder wp-content/plugins
3. Go to administration panel
4. Click "Plugins"
5. Find plugin name "Linkolo Linker" and change status to active.

1. Przed instalacją tego pluginu musisz najpierw wgrać skrypty instalacyjne systemu Linkolo do folderu głównego twojego Wordpressa.
2. Wgrywasz plugin linkolo do folderu wp-content/plugins
3. Wchodzisz do panelu administracyjnego bloga
4. Klikasz menu "Wtyczki".
5. Szukasz wsród wyłączonych pluginów pluginu o nazwie Linkolo Linker i aktywujesz go klikając obok odnosnik "Aktywuj"

== Frequently Asked Questions ==

Brak pytań i odpowiedzi (na razie)

== Changelog ==

= 2.3.2 =

Rozwiązanie problemu z hostingiem na home.pl

= 2.3.1 = 

Zmiana kosmetyczna. Poprawka w wyświetlaniu widgetu w boksach. (Zamiana znacznika </p> na </div>

= 2.3 =

Dodana obsługa linków w boksach (widget).
Usprawniona instalacja. System automatycznie wykrywa i zapisuje ścieżkę do plików systemu Linkolo.pl

= 1.5 =

Dodana angielska wersja językowa

= 1.4 =

Prawdiłowy opis pliku readme.txt

= 1.3 =

Zmiany w wyświetlaniu contentu. Wyeliminowany problem ze znacznikiem <--more-->

= 1.2 =

Wyeliminowany problem z require plików instalacyjnych Linkolo

= 1.1 =

Nauka obsługi SVN na wordpress.org

= 1.0 =

Pierwsza wersja pluginu