=== Trends Forecaster ===
Contributors: SAKURAI Kenichi
Donate link:
Tags: widget, plugin, sidebar, google, hot, trend, game, ranking, forecaster
Requires at least: 2.8
Tested up to: 2.8.4
Stable tag: 1.0.4

This widget shows current Google Trends, Trends Forecasts and Top Trends Forecasters.

== Description ==

This widget shows current Google Hot Trends and Trends Forecasts for today and tomorrow. That is, current and future hot search words are automatically displayed in your pages.

Besides, if you have "Google Account", you can regist your own Hot Trends Forecasts through [http://trendsforecaster.appspot.com/](http://trendsforecaster.appspot.com/) and these forecasts are displayed too.

* You need to regist your `Forecaster ID` for above site through the `Widgets` menu in WordPress
* Hot Trends for U.S. and Japan are being supported now.
* You can regist your forecasts for 8 days later and beyond.

Because Top Trends Forecasters are also displayed in this widget, so you might obtain links to your page from all other sites which use this widget!

== Installation ==

1. Extract all the files
1. Upload the folder `trends-forecaster` to the `/wp-content/plugins/` directory
1. Activate the plugin through the `Plugins` menu in WordPress
1. Activate the widget through the `Widgets` menu in WordPress

== Frequently Asked Questions ==

== Changelog ==

1.0   Initial Release

1.0.1 Added and modified some minor matters about displaying message

1.0.2 Added error handling

1.0.3 Modified comments

1.0.4 Some minor modifications and adjustments

== Screenshots ==
