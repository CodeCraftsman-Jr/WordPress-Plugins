<?php

define('DC_INFOMOUS_CLOUD_PLUGIN_TOKEN', 'dc-infomous-cloud');

define('DC_INFOMOUS_CLOUD_TEXT_DOMAIN', 'infomous_cloud');

define('DC_INFOMOUS_CLOUD_PLUGIN_VERSION', '1.0.4');

define('INFOMOUS_JS_LIB', 'http://www.infomous.com/site/plugins/wp/');
?>
