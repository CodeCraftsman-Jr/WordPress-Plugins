<?php echo $this->ahref($this->href, $this->text, array('title' => 'My Links & Stuff')) ?>

