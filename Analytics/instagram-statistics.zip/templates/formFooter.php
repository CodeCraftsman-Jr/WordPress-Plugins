<small>To get help please email <a href="mailto:support@ink361.com">support@ink361.com</a></small>
<div class="instagram-stats-widget-powered-by">
  <a href="http://ink361.com" target="_blank"></a>
</div>
