<div class="wpstats_social">
	<a class="wpstats_facebook" href="javascript:wpstats_fbshare('http://ink361.com/app/users/ig-<?php echo $details->user_id ?>/<?php echo $details->username ?>/stats');"></a>
	<a class="wpstats_twitter" href="javascript:wpstats_twtshare('http://ink361.com/app/users/ig-<?php echo $details->user_id ?>/<?php echo $details->username ?>/stats');"></a>
</div>