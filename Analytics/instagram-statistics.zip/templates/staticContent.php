<div class="wpstats_noJS">
	View all 
	<a href="http://ink361.com/app/users/ig-<?php echo $details->user_id ?>/<?php echo $details->username ?>/stats" 
		alt="@<?php echo $details->username ?> Instagram Statistics" 
		title="@<?php echo $details->username ?> Instagram Statistics">
		Instagram statistics for @<?php echo $details->username ?>
	</a> 
	on INK361.com.	
</div>