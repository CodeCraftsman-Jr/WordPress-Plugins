<p style="margin-top: 0px;">
  <small>
    <b>Please note:</b>
    This plugin will connect to and use the INK361 Instagram Viewer service to authenticate with the Instagram API. 
    After authenticating you will be redirected back to your Wordpress website.
    During this process we do not store any of your details or your access token.
  </small>
</p>
