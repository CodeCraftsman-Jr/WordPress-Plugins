	<?php if ($details->powered === '1') { ?>
		<div class="wpstats_powered">
			Powered by <a href="http://ink361.com" target="_blank" alt="INK361 Instagram Viewer & Statistics" title="INK361 Instagram Viewer & Statistics">INK361</a>	
		</div>
	<?php } ?>
</div>