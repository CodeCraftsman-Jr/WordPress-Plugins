=== Itunes AppStore App Ranking ===
Contributors: PPeelen
Donate link: http://PaulPeelen.com/iar
Tags: itunes, appStore, ranking, apple
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 1.0

== Description ==
This plugin lets you add your app's position on the appstore to your blog. Simple add the Apple ID, select genre and range and your on the go.

== Installation ==
1. Download the plugin tar.gz file.
1. Unpack the file
1. Upload the directory iTunesAppRaning to your wp-content/plugins/ directory.
1. Activate the plugin in the plugin-manager

== Screenshots ==
1. screenshot1.png

== Changelog ==
= 1.0 =
* The first version is released.

== Frequently Asked Questions ==
None yet

== Upgrade Notice ==
None yet
