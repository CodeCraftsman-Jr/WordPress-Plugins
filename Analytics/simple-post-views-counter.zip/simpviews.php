<?php
/*
  Plugin Name: Simple Post Views Counter
  Plugin URI: http://yooplugins.com/
  Description: This plugin will enable you to display how many times a post has been viewed. The views are displayed in the entry meta of each post, globally troughout your site. Please refer to the included readme.txt file for proper installation instructions and usage.
  Version: 1.6
  Author: RSPublishing
  Author URI: http://yooplugins.com/
  License: GPLv2 or later
  License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

/*
  Copyright 2014/2015  Rynaldo Stoltz  (email : rcstoltz@gmail.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

register_activation_hook(__FILE__, spvco_install());
register_uninstall_hook(__FILE__, spvco_drop());

 if(is_admin()) {
	add_action('admin_menu', 'construct_menu');
}

function construct_menu() {
	add_options_page('Simple Post Views Counter', 'Simple Post Views Counter', 'manage_options', 'wpspv_options', 'return_config');
}

function return_config() {
	require_once('settings.php');
}

function wpspv_conf_link($links) {
  $settings_link = '<a href="options-general.php?page=wpspv_options">Settings</a>';
  array_unshift($links, $settings_link);
  return $links;
}

$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'wpspv_conf_link' );

function rate_wpspv($links, $file) {
	if ($file == plugin_basename(__FILE__)) {
		$rate_url = 'http://wordpress.org/support/view/plugin-reviews/' . basename(dirname(__FILE__)) . '?rate=5#postform';
		$links[] = '<a href="' . $rate_url . '" target="_blank" title="Click here to rate and review this plugin on WordPress.org">Rate this plugin</a>';
	}
	return $links;
}

function spvco_install() {
    global $wpdb;
    $table = $wpdb->prefix . "simpleviews";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
        $sql = "CREATE TABLE " . $table .
                " ( UNIQUE KEY id (post_id), post_id int(10) NOT NULL,
             view int(10),
            view_datetime datetime NOT NULL default '0000-00-00 00:00:00');";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

function spvco_drop() {
    global $wpdb;
    $table = $wpdb->prefix . "simpleviews";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
        $sql = "DROP TABLE " . $table;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

if (!function_exists('echo_views')) {
    function echo_views($post_id) {
        if (update_views($post_id) == 1) {
            $views = get_views($post_id);
            echo number_format_i18n($views);
        } else {
            echo 0;
        }
    }
}

function insert_views($views, $post_id) {
    global $wpdb;
    $table = $wpdb->prefix . "simpleviews";
    $result = $wpdb->query("INSERT INTO $table VALUES($post_id,$views,NOW())");
    return ($result);
}

function update_views($post_id) {
    global $wpdb;
    $table = $wpdb->prefix . "simpleviews";
    $views = get_views($post_id) + 1;
    if ($wpdb->query("SELECT view FROM $table WHERE post_id = '$post_id'") != 1)
        insert_views($views, $post_id);
    $result = $wpdb->query("UPDATE $table SET view = $views WHERE post_id = '$post_id'");
    return ($result);
}

function get_views($post_id) {
    global $wpdb;
    $table = $wpdb->prefix . "simpleviews";
    $result = $wpdb->get_results("SELECT view FROM $table WHERE post_id = '$post_id'", ARRAY_A);
    if (!is_array($result) || empty($result)) {
        return "0";
    } else {
        return $result[0]['view'];
    }
}

?>