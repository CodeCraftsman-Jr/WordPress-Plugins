<div class="wrap">
        <h2><?php _e('Simple Post Views Counter', 'wpspv'); ?></h2><br />
	                <div class="postbox" style="width: 980px;" cellpadding="7"><br />
	<div class="inside">
	<style type="text/css">
	.inside {
	font-family: Arial;
		}
	</style>
<hr /> <i>Hooray ! This plugin has no settings/configurations. Simply add the following code snippet to your themes content.php file (just before the closing &lt;/footer&gt; tag). See included screenshots for reference. <hr />
	   <font color="red"><i>&lt;?php echo 'This post has been viewed'; ?&gt; &lt;?php echo_views(get_the_ID()); ?&gt; &lt;?php echo 'times'; ?&gt;</i></font><hr />
	   Having problems with your site ? Do you have a WordPress issue/error or task that you need help with ? <a href="http://wpemergencyroom.com">WP Emergency Room</a> gives you full access to your own personal support team for just about any small WordPress related fixes and tasks.<br /><hr />
			<br />
	  Please consider making a small donation to help us maintain, update and keep our plugins alive! We appreciate your support!</i> <br></br>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="39JEX9DQXCDJY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>


			</div>
		</div>
	</div>