<?php

/**
 * Nothing much to see here !
 */

?>

<br /><br />
<center>Do you need help fixing your WordPress issues ? <a href="http://wpemergencyroom.com">WP Emergency Room</a> gives you full access to your own personal WordPress support team for any small WordPress related fixes and tasks.</center>