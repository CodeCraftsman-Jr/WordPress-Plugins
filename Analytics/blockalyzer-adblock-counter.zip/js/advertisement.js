jQuery(document).ready(function($) {
    $.adblockJsFile = true;
});