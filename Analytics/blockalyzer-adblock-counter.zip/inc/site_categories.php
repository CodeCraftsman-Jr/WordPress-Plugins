<?php

/**
 * array with site categories used for benchmark comparision
 */

$site_categories = array(
    
    0 => __('(unspecified)', BATD),
    1 => __('Blog', BATD),
    2 => __('- Private', BATD),
    3 => __('- Company', BATD),
    4 => __('- Technology', BATD),
    5 => __('- Hobby & Lifestyle', BATD),
    6 => __('- Business', BATD),
    8 => __('Company Website', BATD),
    9 => __('Private Website', BATD),
    10 => __('Online-Shop', BATD),
    11 => __('Online-Tool', BATD),
    12 => __('Knowledgebase', BATD),
    13 => __('Affiliate-Site', BATD),
    
);