=== View Post counter ===
Contributors: masumbd
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=TAXUBBKCANHLA&lc=US&item_name=bograhost&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: post views,hits,counter,post,view,postviews,view counter,views,total,hits counter,hit,page,widget,post counter plugin,getmasum
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is very simple plugin of view post counter

== Description ==

This is very simple plugin of view post counter. You can use this plugin into your wordpress theme template very easily Just use a php shortcode.

This plugin is capability in all wordpress version.

== Installation ==

1. Upload the view-post-counter plugin to your blog.
2. Active it.
3. Finaly Add This Function "echo bac_PostViews(get_the_ID());" of your single.php,  category.php, archive.php and any where you want.


== Frequently Asked Questions ==

= Can i use this Plugin in any version of wordpress ?=

Yes. You can use this in any version of wordpress.

= How i can use this plugin ?=

Just active it and use back_postViews function .

== Screenshots ==

1. screenshot-1.jpg.
2. screenshot-2.jpg

== Changelog ==

= 1.1 =
* readme.txt file change since the previous version.

= 1.0 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.1 =


= 1.0 =


