=== Bamboo Most Read Posts ===
Contributors: bamboosolutions
Donate link: http://www.bamboosolutions.co.uk
Tags: most read posts
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

List your site's most read posts.

== Description ==

This plugin provides a 'Bamboo Most Read Posts' widget, which works in exactly the same way as the built-in 'Recent Posts' widget, but displays your site's most read posts instead.

Usage

Once the plugin is activated it will begin tracking every visit to a post on your site. Add the 'Bamboo Most Read Posts' widget to your chosen sidebar to display a list of your site's most read posts.