<div class="error">
    <p><?php printf( __( '<b>diib:</b> Please authorize your diib account. You can do it <a href="%1$s">here</a>.', 'diib' ), admin_url( 'options-general.php?page=diib-settings-oauth' ) ) ?></p>
</div>