<div class="error">
    <p><?php printf( __( '<b>diib:</b> Your access token expired but we could not refresh it using your previous authorization. Please re-authorize plugin <a href="%1$s">here</a>.', 'diib' ), admin_url( 'options-general.php?page=diib-settings-oauth' ) ) ?></p>
</div>