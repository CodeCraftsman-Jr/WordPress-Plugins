=== Readability Verifier ===
Contributors: arc90
Tags: readability
Stable tag: 1.0
Version : 1.0
Tested up to: 3.0.5

A simple plugin that allows you to start tracking your Readability reader contributions.

== Description ==
Readability Verifier allows you to easily verify your Wordpress blog with Readability so you can start tracking reader contributions.

== Installation ==
1. Place /readability folder in /wp-content/plugins directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. In the 'Tools' menu, go to Readability Tools.
1. Copy and paste in the text field the verification code given on readability.com when logged in your publisher account.
1. Hit 'Save'!
1. Return to readability.com and hit 'Check Status'. Congrats, you're all set.

== Changelog ==
= 1.0 =
* Places Readability publisher meta tag within HTML header template.

