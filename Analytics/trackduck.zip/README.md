td-wordpress
============

Wordpress plugin for TrackDuck.


VISUAL FEEDBACK FOR WEB DEVELOPMENT AND UI

TrackDuck covers all your feedback needs - from concept to a launched website. Start by getting feedback on mockups, then in development phase and finally make every visitor in launched website part of your QA team!

Get Quality Feedback from Clients and Colleagues

Every issue is marked directly in the website, comes with comment, priority
a snapshot of the area and automatically recorded technical details (device, browser version, OS etc).

Super Easy for Clients to Leave Feedback

Click on the area in the website and add a comment - that’s it! After launch you can get feedback from all website visitors. Just select this option in the project setting dashboard.

Manage Feedback the Way You Want It

Adopt TrackDuck to your needs - choose to track and manage via email, TrackDuck interface or integrate with your organization’s tools - PM, CRM, client support solutions.