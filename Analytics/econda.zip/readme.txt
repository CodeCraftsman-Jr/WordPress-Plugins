=== econda ===
Contributors: Edgar Gaiser
Tags: econda, controlling, analyses, statistics, seo, monitoring
Requires at least: 2.6
Tested up to: 4.1

econda Web Controlling. This plugin enables econda analytics on your site.

== Description ==

This plugin enables econda analytics on your site.

econda is a specialist for high-performance web-analytics solutions with over 1,000 satisfied customers from all areas of e-commerce. 

For your WordPress Blog you can choose between the econda Site Monitor or econda Click Monitor. For further informations visit [econda Web Controlling Website](http://www.econda.de/english.html?campaign=partner/wordpress/website_en). Try the econda Site Monitor now free of charge for 14 days! Test [Site Monitor](http://www.econda.de/produkte/site-monitor/testen.html?campaign=partner/wordpress/siteTesten_en) or [Click Monitor](http://www.econda.de/produkte/click-monitor/testen.html?campaign=partner/wordpress/clickTesten_en) now!

econda's high-end Web analytics provide website and online-shop operators all the data they need for increasing sales and optimizing profits in the long term. The econda Monitor is the data nexus for e-commerce success. With econda's trailblazing r.a.c.e. technology for speedy real-time assessments coupled with boundless flexibility. Quick and easy to integrate as well as perfectly interwoven with a shop system or CMS. The software offers detailed order-process and customer-journey analyses, A/B and multivariate testing, a wealth of e-commerce plug-ins and open ports, and an attractive and intuitive analysis interface.
Furthermore, econda is the first provider to earn the "Certified Data Protection" seal issued by T&Uuml;V Saarland (a German inspection authority) in the field of webshop controlling which proves that econda offers its customers the utmost in security and professionalism with regard to the handling of data.
econda's team of experts shares with customers its web-analytics expertise acquired during hundreds of successful projects. 


== Changelog ==

= 1.1.2 =

* bugfix

= 1.1.1 =

* adapted search

= 1.1.0 =

* additional tracking functions
* update helper class

= 1.0.0 =

* final release

= 0.9.0 =

* Initial release (beta)
