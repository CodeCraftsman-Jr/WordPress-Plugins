=== Plugin Name ===
Contributors: violetcharm
Donate link: http://ziming.org
Tags: visitor,views,analytics,cookie,ip
Requires at least: 2.8
Tested up to: 3.0.1
Stable tag: 1.1.9

This is a thoughtful visitor analytics and interaction plugin for wordpress.

== Description ==

This is a thoughtful visitor analytics plugin for wordpress, it analyses visitor's cookie and ip, from these two features and visitor��s behavior you almost can defined who the visitor was. Once defined, he/she was under your surveillance, you can greet to him directly.
[Demo](http://ziming.org/dev/visitor-analytics)

== Installation ==

1. Unzip the archive and put the 'visitor-analytics' folder into your plugins folder (/wp-content/plugins/).
2. Activate the plugin from the Plugins menu.
3. You can see a sub-menu in Dashboard titled 'Analytics'.

== Usage ==
No till now.

= Changing the CSS =
No till now.
== Screenshots ==
1. Recent Visitors�� List
2. Defined Visitor by Cookie
3. Defined Visitor by IP
4. Greet to Defined Visitors-1
5. Greet to Defined Visitors-2
== Frequently Asked Questions ==
No till now.
== Changelog ==
2010-11-19 Version 1.1.9

fixed a url bug in 'data_analytics.php'.

== Upgrade Notice ==
No till now.