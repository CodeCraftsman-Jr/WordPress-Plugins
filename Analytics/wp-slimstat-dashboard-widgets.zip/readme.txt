=== WP SlimStat Dashboard Widgets ===
Contributors: coolmann
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=BNJR5EZNY3W38
Tags: chart, analytics, visitors, users, spy, shortstat, tracking, reports, seo, referers, analyze, wassup, geolocation, online users, spider, tracker, pageviews, world map, stats, maxmind, flot, stalker, statistics, google+, monitor, seo
Requires at least: 3.1
Tested up to: 3.8
Stable tag: 3.2

== Description ==
This plugin has been discontinued. Dashboard widgets are now available directly in [Slimstat 4](https://wordpress.org/plugins/wp-slimstat/). Go get your copy today!

== Installation ==

Empty Plugin, please do not download!


== Changelog ==

= 3.2 =
* Discontinued. Functionality has been rolled into main plugin.

= 3.1.7 =
* Fixed bug with Async Mode (thank you, [chrisl27](http://wordpress.org/support/topic/dashboard-widgets-do-not-render-when-ajax-updating-enabled))

= 3.1.6 =
* Updated compatibility with WP SlimStat 3.6

= 3.1.5 =
* Fixed warning when admin is served over HTTPS

= 3.1.4 =
* Updated source code to work with new DB Library (WP SlimStat 3.5.2)

= 3.1.3 =
* Fixed Javascript bug

= 3.1.2 =
* Fixed compatibility issue with WP SlimStat

= 3.1.1 =
* Dashboard Widgets now honor your global WP SlimStat permission settings (who can view your reports)

= 3.1 =
* Fixed: now compatible with the latest version of SlimStat

= 3.0.2 =
* Fixed: using the new libraries available in WP SlimStat 3.3 (thank you, pepe)

= 3.0.1 =
* Fixed: fatal error when WP SlimStat was deactivated (thank you, [R4C](http://wordpress.org/support/topic/fatal-error-cant-log-into-wp-dashboard))

= 3.0 =
* Initial release as a standalone plugin