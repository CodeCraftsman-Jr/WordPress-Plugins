<div class="update-nag">
  <p><?php echo sprintf(__('<b>Freespee Call Tracking</b>: Please enter your <a href="%s">customer ID</a> to enable call tracking.', 'freespee_call_tracking'), @admin_url('options-general.php?page=fs_settings_page')); ?></p>
</div>
