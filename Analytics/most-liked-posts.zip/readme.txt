=== Most Liked Posts ===
Contributors: wkrzysztofik
Tags: facebook,popular,like,widget
Requires at least: 3.0
Tested up to: 4.1
Stable tag: trunk
License: GPLv3 or later

Wordpress widget displaying list of posts ordered by number of Facebook likes.

== Description ==
This plugin allow to use new widget - Most liked posts. This widget displays list of posts ordered by number of Facebook likes. Number of likes is updated hourly by wp cronjobs. Plugin doesn't require any additional configuration. Just install, add widget to your sidebar area and have fun!

== Installation ==
1. Install plugin
2. Add new widget - Most liked posts - to your sidebar area
3. Thats all!
