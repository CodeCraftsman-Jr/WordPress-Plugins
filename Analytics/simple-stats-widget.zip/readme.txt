=== Plugin Name ===
Contributors: freephp
Donate link: http://xfuxing.com/
Tags: stats,widget,sidebar,simple
Requires at least: 2.7.1
Tested up to: 2.8.4
Stable tag: 0.9.3

Simple Stats Widget works as a widget!

== Description ==

This widget to record and display the last N visitor areas, from and time, and search engine access, installation and use is very simple.

As the "QQWry.Dat" file is too large(7M), does not seem to be able to upload, you can download the plug-in to the "http://update.cz88.net/soft/qqwry.rar" to download the data file and upload it to the plug-in directory, or you can go to "http://cid-416c7cad6383cdf7.skydrive.live.com/self.aspx/.Public/simple-stats-widget.zip" download plug-ins packaged good.

If you like this plug-in, keep the plug-in at the bottom of the picture information, thank you.

== Installation ==

The plugin is simple to install:

1. Download the zip file
2. Unpack the archive and copy the files into a directory called "simple-stats-widget" in your plugin directory (normally .../wp-content/plugins/). That's it!
3. Activate plugin
4. Go to Appearance -> Widgets for configuration. Before using the plugin.

== Frequently Asked Questions ==

= What is "QQWry.Dat"? =

1. The "QQWry.Dat" is a collection of "cz88.net", non-commercial use IP address database, Thank "cz88.net" as well as the provision of IP data unselfish friends."QQWry.Dat" to conduct a revision every five days, of course, if not necessary, you can not go to upgrade.

= How to download the file "QQWry.Dat" ? =

1. Download URL("http://update.cz88.net/soft/qqwry.rar").
2. Unpark the "qqwry.rar".

= "QQWry.Dat" need to pay ? =

1.It is completely free.

= Why are displayed in areas of incomplete or incorrect ? =

1. "QQWry.Dat" non-commercial purposes because of the collection, it will inevitably be incomplete or incorrect information. If you feel there is a need to revise, you can report to "cz88.net", or tell me that for me to convey.

= How to completely uninstall ? =

1. Remove "simple stats widget" in widgets.
2. Deactivate "simple stats widget" in plugins.
3. Delete "simple-stats-widget" in "wp-content/plugins".
5. Delete "widget_svS" and "data_svS" in options your database tables.
6. OK,Plug-ins and its subsidiary data has completely disappeared from WordPress of your.

If you have additional questions, please message in my blog, I will reply you as soon as possible, thank you for using "simple stats widget". Have a nice day.

== Screenshots ==

1. screenshot-1.jpg

== Changelog ==

= 0.9.3 [SEP 30, 2009] =
* Fixed some minor bugs.

= 0.9 [SEP 24, 2009] =
* First release.
