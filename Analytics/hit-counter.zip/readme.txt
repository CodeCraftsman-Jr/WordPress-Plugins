=== Hit Counter ===
Contributors: Jimisjoss
Author: Jimis Joss
Tags: 
Requires at least: 2.0.0
Tested up to: 3.2.1
Stable tag: 1.2

This plugin is no longer supported. Please use another.