<link type="text/css" rel="stylesheet" href="<?php print REACT_SOCIAL_ANALYTICS_APPLICATION_URL . '/css/reactsocialanalytics.css'; ?>" />
<link type="text/css" rel="stylesheet" href="<?php print REACT_SOCIAL_ANALYTICS_APPLICATION_URL . '/css/social-network-icons.css'; ?>" />

<script type="text/javascript" src="wp-includes/js/jquery/jquery.js"></script>

<!--[if IE 6]>
	<link rel="stylesheet" href="<?php print REACT_SOCIAL_ANALYTICS_APPLICATION_URL ?>/css/ie6.css" type="text/css" media="screen" />
	<script src="<?php print REACT_SOCIAL_ANALYTICS_APPLICATION_URL ?>/js/ie6.js" type="text/javascript"></script>
<![endif]-->
