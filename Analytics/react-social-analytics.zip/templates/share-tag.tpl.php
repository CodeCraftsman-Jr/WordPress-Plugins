<?php
	echo $shareProviders
?>