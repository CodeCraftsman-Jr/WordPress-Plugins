<?php

// Leave empty
$reactConfig['urlSuffix'] = '';
// File in which the OpenReact autoloader class can be found
$reactConfig['autoloaderClassFile'] = REACT_SOCIAL_PLUGIN_ROOT_FOLDER_PATH .'/library/OpenReact/Autoload.php';
// Directory where the OpenReact autoloader will look for classes
$reactConfig['autoloaderLibrary'] = REACT_SOCIAL_PLUGIN_ROOT_FOLDER_PATH .'/library';
