=== Plugin Name ===
Contributors: adiian
Donate link: 
Tags: Google, Google Analytics, Tracking
Requires at least: 2.3.1
Tested up to: 3.0.1
Stable tag: 1.0

Google analytics plugin adds the google tracking code to the blog pages.

== Description ==

Features:

* Easy to install and configure
* Optimized to use minimum of resources

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the  files to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to settings section and add the Web Property ID from Google Analytics

== Frequently Asked Questions ==

= Why just another Analytics plugin? =

Because I wanted to have a simple and optimized one.

== Screenshots ==

1. Setting Preview

== Changelog ==

= 1.0 =
	* google-analytics-plugin.php(created) - actions added: wp_footer

== Upgrade Notice ==

= 1.0 =
This is the first plugin version. No Upgrade Notice yet.