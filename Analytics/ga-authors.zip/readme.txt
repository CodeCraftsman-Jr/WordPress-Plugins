=== GA Authors ===
Contributors: mlazarov 
Tags: Google Analytics, tracking authors post views,
Requires at least: 2.7
Tested up to: 3.2.1
Stable tag: 1.0.2

Track page views by authors in Google Analytics account.
All you have to do is to add Your google analytics profile to the `GA Authors` config page


== Installation ==

1. Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
2. Go to yout Google Analaytics profile and create new profile from existing
site.
3. Enter Google Analytics ID in `GA Authors` config page
4. Create filter in your old Google Analytics profile to exclude visits like '^/by-author/'

