=== Easy Analytics ===
Contributors: welcher
Tags: stats tracking, analytics, Google Analytics
Requires at least: 2.7
Tested up to: 4.3-RC2
Stable tag: 3.4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.ryanwelcher.com/donate/

Allows you to quickly add Google Analytics tracking code to your site.

== Description ==

Allows you to quickly add Google Analytics tracking code to your site. It's crazy easy, hence the name!

== Installation ==

1. Upload `easy_analytics` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add your tracking UA-XXXX number in the settings area

== Screenshots ==

1. Configuration screen

== Changelog ==
= 3.4.2 =

* WordPress Coding Standards Update
* Compatibility check with 4.2 alpha

= 3.4.1 =
* Bux fix

= 3.4 =

* i18n and l10n updates.

= 3.3 =

* Snippet no longer loads for logged in users.

= 3.2 =
* This is a major update! 
* Massive overhaul of codebase including changes to how your preferences are stored
* Plugin settings page has been moved from the Plugins menu to the more appropriate Settings menu
* Choice to use Legacy or Universal Analytics code snippet
* You can choose to put the snippet in the header or the footer of your site
* Add Enhanced Link Attribute for your snippet - be sure to enable it in your GA account!

= 3.1 =
* bug fix

= 3.0 =
* Completely re-written as a class.
* Removed the Site Speed option.
* Cleaned up the interface.
* Added French Language

= 2.6 =
* Fixed a bug that caused the google id to not be stored

= 2.5 =
* Added the _setDomain option

= 2.0 =
* Updated GA snippet
* Added optional Site Speed Sample Rate

= 1.1 =
* Added some basic localization

= 1.0 =
* Plugin was created

== Upgrade Notice ==

= 3.4.1 =
* Critical fix for 3.4 that caused UA numbers to be lost.







