=== Cyclos ===
Contributors: Cyclos, luisfpg
Tags: Cyclos, Cyclos login, Banking, Payment, Barter, Remittances, Micro Finance, Complementary Currency, Mobile Money
Donate link: http://www.cyclos.org/contributors
Requires at least: 4.0
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2

This plugin enables you to easily add a Cyclos login form to your wordpress website.

== Description ==
= Cyclos wordpress Plugin =
This plugin enables you to easily add a Cyclos login form to your wordpress website. Later extra features will be added such as searching for advertisements.

== Installation ==
Please go to the wordpress settings menu and open "Cyclos", further instructions are given there.

== Frequently Asked Questions ==
= What does the plug-in do: = 
The plug-in alows your Cyclos users to login to Cyclos using a wordpress front-end site.

= What is Cyclos: =
Cyclos is payment platform used by banks, mfi's, barters, for remittances and complementary currency systems. For more information please visit: <a href="http:/www.cyclos.org" target="_blank">www.cyclos.org</a>.

= How do I install the plug-in =
Please follow the instructions given in the wordpress setting menu of the plug-in.

== Screenshots ==
1. Login form (in a page).
2. Login form (closeup).
3. Cyclos plugin settings.
4. Customizing labels of the form.

== Changelog ==
This is the first version we published of the plugin.
