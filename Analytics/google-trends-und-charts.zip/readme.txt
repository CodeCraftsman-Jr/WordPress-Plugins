=== Google Trends & Charts ===
Author: Sammy Zimmermanns
Contributors: baynado
Donate link: http://internet-pr-beratung.de/wordpress/
Author URI: http://internet-pr-beratung.de/
Plugin URI: http://internet-pr-beratung.de/google-trends-wordpress/
Tags: shortcode, google trends,charts,google
Requires at least: 3.5.0
Tested up to: 4.2.0
Stable tag: 1.1
License: GPLv2 or Alter
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Gibt Google Trends Graphen per Shortcode aus, zudem kann es die Top-Suchanfragen bei Google in einem Widget oder per Shortcode ausgeben.


== Description ==

Das Plugin gibt Google Trends Graphen per Shortcode aus, zudem kannst Du die Top-Suchanfragen bei Google in einem Widget ausgeben.

Beispiel:

[trends h="500" w="500" q="cats,dogs,+cute+dogs,+cute+cats,+cats+and+dogs" geo="de"]


== Installation ==

1. Upload 'google-trends-charts.php' in das '/wp-content/plugins/' Verzeichnis
2. Aktiviere das Plugin im 'Plugins' Menü in WordPress
3. Nutze der [trends] Shortcode

== Frequently Asked Questions ==

= Wie nutze ich den Shortcode? =

Gebe einfach diesen Shortcode in Deinem Artikel ein, wenn Du einen Trend zu einem bestimmten Suchbegriff ausgeben moechtest.

[trends h="500" w="500" q="katzen,hunde,+süße+hunde,+süße+katzen,+katzen+und+hunde" geo="de"]

Gebe einfach diesen Shortcode in deinem Artikeloder Text-Widget ein, wenn Du die Top-Suchbegriffe aus Deinem Land ausgeben moechtest.

[topsearches h=826 w=400 pn=15 tn=20]

= Für wie viele L�nder werden die Top-Suchbegriffe ausgeben? =

Aktuell werden 46 Laender unterst�tzt.


== Screenshots ==

keine

== Changelog ==

= 1.0 =
* Plugin Release



== Upgrade Notice ==

= 1.0 =
* Plugin Release
 
