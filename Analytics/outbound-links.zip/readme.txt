=== Outbound Links ===
Tags: nofollow,target,link,google,penality,paid link,blank
Requires at least: 3.0.0
Tested up to: 4.0.1
Stable tag: trunk
Donate link: http://www.satollo.net/donations
Contributors: satollo

Force the nofollow and new window on all outbound links.

== Description ==

To avoid Google bans when you have outgoing links considered as paid links, you
must add the rel="nofollow" to every outgoung link. This plugin adds it for you.

If you want outgoing link to open in a new window, this plugin add the correct
attribute to every link it finds.

Links manipulation is limited to post content links.

More here: http://www.satollo.net/plugins/outbound-links.

== Installation ==

Upload the plugin folder into your "wp-content/plugins".
Log in to Wordpress Administration area, choose "Plugins" from the main menu, find "Outbound Links",
and click the "Activate" button.
Go to the options page and activate the funzionalities you prefer.

== History ==

= 2.0.1 =

* Added the domain whitelisting

== Frequently Asked Questions ==

No questions have been asked.

== Screenshots ==

No screenshots are available.
