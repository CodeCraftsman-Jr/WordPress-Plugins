=== Google Analytics by DG ===
Contributors: dgharami
Donate link: http://www.gotodevelop.com
Tags: google, analytics, code, UA, code, javascript
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 1.0.0
License: GPLv2

Simple but powerful plugin to enables Google Analytics on all pages of your site.

== Description ==

This plugin aumatically adds the required javascript for google analytics with your given Google (UA) code.

For more information visit:

[Google Analytics Page](http://www.google.com/analytics)

== Installation ==

1. Upload `google-analytics-by-dg` folder to the `/wp-content/plugins/` folder
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the web property ID from Google Analytics (UA-0000000-0) to the settings (Admin > Tools > Google Analytics)

== Screenshots ==

1. Modified settings panel with Google Analytics.
2. Google Analytics settings page.

