=== Hitsteps Blog Analytics & Live Chat ===
Contributors: hitstep
Tags: analytics, free, stats, statistics, chat, live, dashboard, stat, visitor, visit, heatmap, support, online, visitors, hits, hit, tracking, track, tracker, activity, pageview, seo, counter, visitor tracker, analytic, widget, graph, realtime, daily, label
Requires at least: 1.5
Tested up to: 4.1
Stable tag: 1.00
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.hitsteps.com/features.php#price

Hitsteps Analytics is a free powerful real time website visitor manager, it allow you to view and interact with your visitors in real time.


Hitsteps Analytics is an advanced website traffic, SEO, and visitor analytics application which offers comprehensive visitor activity analysis as well as live chat system.

== Description ==

Hitsteps Analytics is a powerful real time visitor management and live chat tool. 
It allows you to view your visitors stream and follow each visitors to know more about each pages they see. It allow you to engage with your visitors using live chat tool. You'll be provided with detailed information about each visitor such as geolocation, their first visit on your site, referer to your site, their browser, OS and device and much more!
Advantages over Google analytics includes but not limited to Detailed information of each and all visitors, ability to engage with visitors using live chat tool, heatmap for each pages, carefully pre-generated and categorized reports, real-time analytics on all reports and much more...

Read More:
http://www.hitsteps.com/features.php

== Installation ==

It is extremely easy to install.
All that you have to do is: open an account via the hitsteps website, add your site to your account and get your API Code to use the plugin.
 
View The Features That hitsteps Offers:
http://www.hitsteps.com/features.php

== Screenshots ==

1. Hitsteps dashboard.

== Changelog ==

= 1.00 =
* Base Startup for Analytics and Live Chat plugin All-in-One

== Frequently Asked Questions ==

You'll find updated FAQs on [Support page](http://www.hitsteps.com/support.php).