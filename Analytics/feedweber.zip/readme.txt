=== Plugin Name ===
Contributors: Talus
Donate link: http://www.installedforyou.com/wordpress/feedweber-plugin/
Tags: autoresponder, email
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 0.3

Allow your users to subscribe to your FeedBurner Feed and AWeber auto-responder in one form.

== Description ==

Ever wanted to have users who subscribe to you FeedBurner feed automatically subscribe to your
AWeber auto-responder list as well? Now you can.

FeedWeber allows users to enter their email address and automatically subscribe to both
services with just one click.

Worried about spam complaints? Since AWeber subscriptions require verification before the user
is fully subscribed, users still have to double opt-in and follow all of the rules.

== Installation ==

1. Upload the `FeedWeber` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the Widget to your sidebar where you want it and enter the configuration options.

== Frequently Asked Questions ==

= Why does the Feedburner window open in a full window instead of the normal smaller window? =

From what I've seen, it means that jQuery isn't working, so the AWeber part isn't working

== Changelog ==

= 0.1 =
* Plugin written and released.

= 0.2 =
* Minor tweak to fix a bug. Thanks for the feedback.

= 0.3 =
* Removed hardcoded style on form.
* Improved security on input fields and converted before/after to larger text area fields
* Allowed user to input CLASS NAME for form and fields.