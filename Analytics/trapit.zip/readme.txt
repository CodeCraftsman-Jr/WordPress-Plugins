=== Trapit ===
Contributors: Trapit Inc.
Tags: content, curation, blog, rss, trapit
Requires at least: 4.1
Tested up to: 4.2.3
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Trapit Content Curation

== Description ==
Use the Trapit Wordpress plugin to post original, high-quality content you won't find elsewhere. Trapit lets you combine your branded content with content from over 100,000 sources, including blogs, journals, magazines, news services, videos, and podcasts. 

For a demo or to sign-up for Trapit, see: http://trap.it/

== Screenshots ==
1. Create a Post

== Changelog ==
= 1.0.1 =
* Minor UI changes

= 1.0.0 =
* Initial release.
