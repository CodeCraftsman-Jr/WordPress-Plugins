<?php
/**
* Plugin Name: Trapit
* Plugin URI: http://trapit.com/
* Description: Insert content from Trapit.
* Version: 1.0.0
* Author: Trapit Inc.
* Author URI: http://trapit.com/
* License: GPL2
*/

include 'admin-menu.php';
