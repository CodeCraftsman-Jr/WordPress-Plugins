# wordpress-plugin
Wordpress plugin for Trapit
===========================

Installation
------------
To install, create a directory named "trapit" in your Wordpress plugins directory.
The directory structure should look something like:

~/apache-sites/wordpress/wp-content/plugins/trapit

Clone the repository into the new trapit directory.

Setup
-----
Navigate to the Wordpress administration dashboard.
Select the Plugins menu, and click on the "Activate" link in the Trapit plugin entry.

Now navigate to the Trapit menu located in the dashboard, and enter appropriate settings for the email and password.
Save the changes.

You should now be able to start posting Trapit queue items by selecting a section of interest under Trapit -> Categories.
