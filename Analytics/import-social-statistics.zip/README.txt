=== Import Social Statistics ===
Contributors: easantos
Donate link: http://www.easantos.net/
Tags: facebook, likes, number of likes
Requires at least: 4.2.2
Tested up to: 4.2.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Import Social Statistics tracks the number of social interactions for each post.

== Description ==

Import Social Statistics tracks the number of social interactions for each post. Sorts your posts by the number of Facebook likes and finds you most shared content.

== Installation ==

1. Upload `import-social-statistics` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How frequent is the counter updated? =

The counter is updated each time a post is viewed. If a cache plugin is in use then the counter will be updated when the cache expires.

== Screenshots ==

1. Number of Facebook likes in post listings

== Changelog ==

= 1.0.1 =
* README.txt file updated.

= 1.0.0 =
* First version of the plugin.

== Upgrade Notice ==

= 1.0.0 =
First version of the plugin.
