=== Simple Tracking ===
Contributors: FabiDrive
Donate link: http://www.vionic.de
Tags: conversion, tracking, conversiontracking, google, yahoo
Requires at least: 2.1
Tested up to: 2.9.1
Stable tag: 0.2

With Simple Tracking you can add your individual Trackingcode (javascript) to any page or post in your Blog.

== Description ==

With Simple Tracking you can add your individual Trackingcode (javascript) to any page or post in your Blog.
Just add your code in the adminpanel and add a shortcode to your site or post.


== Installation ==

Upload the Simple Tracking plugin to your blog, Activate it, and enter your personalisized data into the settingspane.
To get the code, which you have entered in the adminpanel, running in the Frontend (on a page or post) just enter the shortcode [[[simpleTracking_shortcut1]]] or [[[simpleTracking_shortcut2]]] or [[[simpleTracking_shortcut3]]] to any post or page.
Every Time a User hits the page the script runs through.

You're done!

== Screenshots ==

1. **Administrationwindow** - There you see the adminpanel of Simple Tracking. You can insert 3 trackingcodes. That easy :-)

== Changelog ==

= 0.1 =
* First stable version, no errors known

= 0.2 =
* Internationalisation German/English