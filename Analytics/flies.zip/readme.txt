=== Flies ===

Contributors: axelmolokini

Requires at least: 3.0

Tested up to: 4.1

License: GPLv2 or later

Stable tag: 1.0



Using the shortcode [flies] you can add a fun button that when clicked flies appear. Just for laughs.



== Description ==

Using the shortcode [flies] you can add a fun button that when clicked flies appear. Just for laughs.



== Installation ==

Install and activate the plugin. Add the shortcode [flies] anywhere on your site.



== Screenshots ==

== Changelog ==

== Upgrade Notice ==