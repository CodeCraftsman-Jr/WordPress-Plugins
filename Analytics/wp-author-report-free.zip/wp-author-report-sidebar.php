<div style="float:right; width:200px; min-height:400px; margin-top:50px;">

<table class="widefat">
	<thead>
		<tr><th>Important Links<th></tr>
	</thead>
	<tbody>
		<td>
		<ul>
		<li><a href="http://wpdeveloper.net/plugin/wp-author-report" target="_blank">Plugin Homepage</a></li>
		<li><a href="http://wpdeveloper.net/support" target="_blank">Support</a></li>
		<li><a href="http://wpdeveloper.net/affiliate" target="_blank">Become an Affiliate</a></li>
                <li><a href="http://wpdeveloper.net/" target="_blank">WPDeveloper.net</a></li>
		</ul>	
		</td>
	</tbody>
</table>

<div style="height:10px;"></div>
<table class="widefat">
	<thead>
		<tr><th>Free Subscription<th></tr>
	</thead>
	<tbody>
		<td>
			
			<form action="//WPDeveloper.us10.list-manage.com/subscribe/post?u=a427328bc9fc2657270f66f87&amp;id=97fd2b28ff" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
			<input type="text" style="width:157px;color:#666666; font-size:12px;" name="EMAIL" id="mce-EMAIL" value="Enter your email address" onclick="javascript: if(this.value=='Enter your email address') {this.value='';}"/>
			<input type="hidden" value="WPDeveloper" name="uri"/>
			<input type="hidden" name="loc" value="en_US"/>
			<div style="text-align:center; margin-top:5px;"><input class="button" type="submit" name="subscribe" id="mc-embedded-subscribe" value="Subscribe"/></div>
			</form>
		
		</td>
	</tbody>
</table>
<div style="height:10px;"></div>
<table class="widefat">
	<thead>
		<tr><th>Stay Connected<th></tr>
	</thead>
	<tbody>
		<td>
		<ul>
		<li><a href="https://www.facebook.com/WPDeveloperNet" target="_blank">Facebook</a></li>
		<li><a href="https://twitter.com/WPDevTeam" target="_blank">Twitter</a></li>
		<li><a href="https://www.google.com/+WpdeveloperNet" target="_blank">Google+</a></li>
		</ul>	
		</td>
	</tbody>
</table>
<div style="height:10px;"></div>
<table class="widefat">
	<thead>
		<tr><th>WPDeveloper.net Feed<th></tr>
	</thead>
	<tbody>
		<td>
			<?php wpdev_dashboard_widget_function();?>	
		</td>
	</tbody>
</table>

</div>
