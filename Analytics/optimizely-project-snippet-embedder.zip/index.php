<?php
	// Bye-bye :-)
	header('http/1.1 301 Moved Permanently');
	header('location: /');
