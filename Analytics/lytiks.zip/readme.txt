=== Lytiks ===
Contributors: lytiks
Donate link: http://lytiks.com/
Tags: analytics
Requires at least: 1.0
Tested up to: 3.0.1
Stable tag: 0.1.0

Lytiks is a Marketing Performance Tracking Platform.  This plugin will insert the Lytiks Web Analytics code into your Wordpress Site.

== Description ==

Lytiks provides Web Analytics, Video Tracking, Custom Form Processing, Phone Call Tracking all through a single web application.

== Installation ==

1. Upload all the plugin files to  to the `/wp-content/plugins/lytiks` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Get your tracking code from http://go.lytiks.com/website/wordpress.  If you don't already have an account, go to http://lytiks.com to signup for a free account.
4. Set the tracking ID on the plugin options page.

== Frequently Asked Questions ==

= What does Lytiks do for me? =
Lytiks will track the visitors to your website and allow you to see which page they visit and how many pages each visitor views.

It will also show you how long they stay on your site and allow you to group them using a powerful segmenting tool.  You'll be able to see which referrers and marketing messages bring interested users to your website.

= How much traffic can I track with Lytiks? =

A free Lytiks account will provide you with sufficent resources to track most small websites.  If you anticipate more than 90,000 pageviews in a month you can upgrade your account.  See the website for more information.

== Screenshots ==

1.  The Lytiks Plugin options page.  The unique tracking ID can be found at http://go.lytiks.com/website/wordpress.

== Changelog ==

= 0.1.0 =
* Initial Release


