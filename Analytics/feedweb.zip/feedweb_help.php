<?php ?>
<div class="wrap">
	<div id="icon-plugins" class="icon32"><br /></div>
	<h2><?php _e("Feedweb Plugin Tutorial", "FWTD");?></h2><br/>
	<table>
		<tr>
			<td style='width: 500px;'>
				<h3>How to insert a Rating Widget into a post:</h3>
			</td>
			<td>
				<h3>How to enable the Feeder sidebar widget:</h3>
			</td>
		</tr>
		<tr>
			<td>
				<iframe width="420" height="315" src="//www.youtube.com/embed/HDVuaVlnKIM" frameborder="0" allowfullscreen></iframe>
			</td>
			<td>
				<iframe width="420" height="315" src="//www.youtube.com/embed/TUPOymM6fAc" frameborder="0" allowfullscreen></iframe>
			</td>
		</tr>
	</table>
</div>
