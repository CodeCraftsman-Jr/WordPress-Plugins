=== Most Commenting Visitors ===
Contributors: s_ruben
Donate link: http://rubensargsyan.com/donate/
Tags: most, comments, replies, visitors, authors, widget
Requires at least: 2.8
Tested up to: 3.0.1

This is a widget plugin which helps to display the visitors who left the most number of comments in the Wordpress blog.

== Description ==

This is a widget plugin which helps to display the visitors who left the most number of comments in the Wordpress blog.

[Plugin Homepage](http://rubensargsyan.com/wordpress-plugin-most-commenting-visitors)

== Installation ==

1. Upload the most-commenting-visitors directory (including all files within) to the /wp-content/plugins/ directory.
2. Activate the plugin through the Plugins menu in WordPress.
3. Go to the "Appearance"->"Widgets" panel and drag-and-drop the "Most Commenting Visitors" box into your sidebar, configure options and save.

== Frequently Asked Questions ==

For questions contact with the plugin author - [Ruben Sargsyan](http://rubensargsyan.com/contact).

== Screenshots ==

1. Most Commenting Visitors

== Changelog ==

= 1.3 =
* Now you can set the start date from which the plugin will count the numbers of comments.

= 1.2 =
* This version ignores the following types of comments: trackback and pingback.

= 1.1 =
* Now you can exclude visitors from most commenting visitors by their emails.

= 1.0 =
* First release.