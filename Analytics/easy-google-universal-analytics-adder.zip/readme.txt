=== Google Universal Analytics ===
Contributors: David Byrne
Donate link: 
Tags: google analytics,google universal analytics,universal analytics
Requires at least: 2.8
Tested up to: 3.5.1
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily install the google universal analytics code in to your theme.

== Description ==

Google universal analytics is the latest version of the google analytics tracking code. Google have announced that all new sites should use it from now on. The code can be installed side by side with the existing google analytics synchronous tracking code (ga.js). This plugin simply automates the process of adding the required code. Just plugin in your google analytics id and hostname and it inserts the code.

== Installation ==

1. Upload the folder `google-universal-analytics` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to the settings menu in your admin console and browse to the Google Universal Analytics link
4. Enter your analytics id and hostname (eg example.com)
5. Press submit to activate

Note: You will need to have create an analytics account at google.com/analytics. If you have an existing account you will need
to create a new web property for the universal account.

== Frequently asked questions ==

Can I install this with another plugin that install the old (ga.js) analytics tracking code?

Yes



