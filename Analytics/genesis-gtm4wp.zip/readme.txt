=== Genesis Google Tag Manager for Wordpress ===
Tags: genesis, genesiswp, studiopress, gtm, google tag manager, google analytics
Requires at least: 3.2
Tested up to: 4.1
Stable tag: 1.0.0



== Description ==


== Installation ==

1. Upload the folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What is Google Tag Manager? =

Maybe you don't need this plugin

= What is the Genesis Framework? =

Maybe you don't need this plugin

= The plugin won't activate =

You must have Genesis (1.3+) or a Genesis child theme installed and activated on your site.

== Changelog ==

= 1.0 =
* Initial Release

