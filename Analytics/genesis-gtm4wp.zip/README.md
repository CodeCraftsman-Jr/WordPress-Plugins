# Genesis Google Tag Manager for Wordpress

Adds support on [Genesis Framework](http://studiopress.com) for [DuracellTomi's Google Tag Manager for WordPress](https://wordpress.org/plugins/duracelltomi-google-tag-manager/)

# Instruction
Just upload and activate...

There is no GUI or support options