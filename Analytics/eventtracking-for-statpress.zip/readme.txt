=== Plugin Name ===
Contributors: kazunori ueyama
Donate link: http://joc03.xsrv.jp/plugins-provider/event-tracking-top/
Tags: event tracking
Requires at least: 4.1
Tested up to: 4.
Stable tag: 0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Event Tracking for Statpress is a program made in Japan, which assists you to event tracking on Wordpress.

Also in Google Analytics has event tracking feature, but it is a plug-in to add an event tracking function to statpress is a plug-in for WordPress.
If there is a transition page, but will be a record in statpress, when you click on the external link, when you click on a phone number in smartphone, tablet, etc., will not be a record in statpress.
This plug-in is to record the id of the link to statpress, is what you have to be able to measure the event tracking.

== Installation ==

1. Upload the entire `joc-dl-checker-management` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Attention ==
 
When you install a blog existing already, to avoid unexpected damages or any other unexpected situation, backing up is strongly recommended.

Event Tracking for Statpress is not responsible or does not have any guarantee for any kind of damage that you get by using or installing Event Tracking for Statpress. 
All the procedures must be done with self-responsibility of each user.