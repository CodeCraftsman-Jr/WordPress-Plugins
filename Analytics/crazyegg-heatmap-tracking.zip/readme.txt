=== Crazyegg Heatmap Tracking ===
Contributors: crazyegg
Tags: crazyegg, traffic, tracking, clicktracking
Requires at least: 2.0.2
Tested up to: 4.1
Stable tag: 1.1

The official Crazyegg.com heatmap tracking plugin for Wordpress.

== Description ==

This plugin enables Crazyegg.com heatmap tracking on your WordPress site, with a limited amount of configuration.

== Installation ==

1. Upload the `crazyegg-heatmap-tracking` directory into the `/wp-content/plugins/` directory on your server.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Using the "WordPress *General* Settings" menu, navigate to Crazyegg Heatmap Tracking and enter your Crazyegg.com Account Number.

== Frequently Asked Questions ==

= Do I have to have Wordpress newer than 2.7? =

This plugin should be compatible with all older versions of WordPress up until plugins were first introduced.

== Changelog ==

= 1.1 =
* New domain added for tracking script.

= 1.0 =
* The first version of this plugin.

== Upgrade Notice ==

= 1.0 =
This is needed.
