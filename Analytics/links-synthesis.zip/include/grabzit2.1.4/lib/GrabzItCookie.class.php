<?php
class GrabzItCookie
{
  public $Name;
  public $Value;
  public $Domain;
  public $Path;
  public $HttpOnly;
  public $Expires;
  public $Type;
}
?>