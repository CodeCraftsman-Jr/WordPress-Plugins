<?php
//Get this value from http://grabz.it/api
$grabzItApplicationKey = "APPLICATION KEY";
//Get this value from http://grabz.it/api
$grabzItApplicationSecret = "APPLICATION SECRET";
//The absolute path that you have placed the handler.php on your website
$grabzItHandlerUrl = "URL OF YOUR GrabzItHandler.php FILE (http://www.example.com/grabzit/handler.php)";
?>