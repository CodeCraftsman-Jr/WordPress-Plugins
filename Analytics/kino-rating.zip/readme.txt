=== Plugin Name ===
Contributors: Smiling_Hemp
Donate link: goo.gl/zwzfod
Tags: kino, rating, cineme, imdb, kinopoisk, Kino-Rating
Requires at least: 3.5.1
Tested up to: 4.3
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The plugin adds beautiful pictures with movie ratings.

== Description ==

The plugin adds beautiful pictures with movie ratings.

== Installation ==

1. Upload `kino-rating` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. That's all.

= Video-on installation and configuration plugin =
<p></p>
<p>https://www.youtube.com/watch?v=ViaKbQE4Yo0</p>

== Screenshots ==

1. Settings page images rated

== Changelog ==

= 1.1.1 =
* The output of images is remade, now they are output not only to Single and Page, but also on other pages
* Added possibility of use of several ratings in one record

= 1.1.0 =
* The button in the visual editor is added

= 1.0.0 =
* first version