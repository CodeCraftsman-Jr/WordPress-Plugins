<?php
/**
* Dashboard Widget (no RSS data available)
*/
?>
<div class="rss-widget">
	<img src="<?php echo WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),"",plugin_basename(__FILE__)); ?>../css/outside_logo.png" class="alignright" />
</div>