=== Google Analytics Stats ===
Contributors: Chris Fletcher
Donate link: http://chris-fletcher.com/plug-ins/google-analytics-stats/
Tags: google, analytics, stats 
Requires at least: 2.0.2
Tested up to: 2.7.1
Stable tag: 1.1

Shows a graph of 3 metrics from google analytics on the dashboard. The metrics are Page Views, Visits, and New Visits

== Description ==

The Google Analytics Stats plugin shows a graph of 3 metrics from google analytics on the dashboard. The metrics are Page Views, Visits, and New Visits. It's very easy to setup, comes with its own admin section. Future planned releases will include more metrics and more configurable options.

== Installation ==

1. Install the plugin via the add new plugin form.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Google Analytics Stats under the Settings menu and enter in your account information.