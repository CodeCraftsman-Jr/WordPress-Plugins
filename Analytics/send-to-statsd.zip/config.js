{
  debug: true,
  backends: [ "./backends/console" ]
}
