<?php
/**
 * File from WEBO Site InSight, WEBO Software (http://www.webogroup.com/)
 *
 **/
?><strong class="wsi-error-message"><?php echo $this->variables['error']; ?></strong>
