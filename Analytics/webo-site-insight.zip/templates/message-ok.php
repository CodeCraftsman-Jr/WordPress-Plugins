<?php
/**
 * File from WEBO Site InSight, WEBO Software (http://www.webogroup.com/)
 *
 **/
?><div class="wsi-message wsi-message-ok"><?php echo $this->variables['message']; ?></div>