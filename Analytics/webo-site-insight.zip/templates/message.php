<?php
/**
 * File from WEBO Site InSight, WEBO Software (http://www.webogroup.com/)
 *
 **/
?><strong class="wsi-ok-message"><?php echo $this->variables['message']; ?></strong>