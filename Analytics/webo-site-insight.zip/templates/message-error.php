<?php
/**
 * File from WEBO Site InSight, WEBO Software (http://www.webogroup.com/)
 *
 **/
?><div class="wsi-message wsi-message-error"><?php echo $this->variables['error']; ?></div>
