<?php
/**
 * File from WEBO Site InSight, WEBO Software (http://www.webogroup.com/)
 *
 **/

define('WSI_WIDGET_CLASS_NOT_FOUND', 'Widget class was not found at widget file');
define('WSI_WIDGET_FILE_NOT_FOUND', 'Widget file was not find at widget directory');
define('WSI_WIDGET_INSTALL_FAILED', 'Widget install failed');
define('WSI_WIDGET_UNINSTALL_FAILED', 'Widget uninstall failed');
define('WSI_WIDGET_UNINSTALL_SUCCESS', 'Widget successfully uninstalled');
define('WSI_WIDGET_INSTALL_SUCCESS', 'Widget successfully installed');
define('WSI_WIDGET_DEACTIVATE_SUCCESS', 'Widget successfully deactivated');
define('WSI_WIDGET_DEACTIVATE_FAILED', 'Widget deactivation failed');
define('WSI_WIDGET_ACTIVATE_SUCCESS', 'Widget successfully activated');
define('WSI_WIDGET_ACTIVATE_FAILED', 'Widget activation failed');
define('WSI_DEACTIVATE_WIDGET', 'Deactivate widget');
define('WSI_ACTIVATE_WIDGET', 'Activate widget');
define('WSI_UNINSTALL_WIDGET', 'Uninstall widget');
define('WSI_GROUP_MY', 'My widgets');
define('WSI_GROUP_PANEL', 'Control Panel');
define('WSI_GROUP_NETWORK', 'Network Level');
define('WSI_GROUP_SERVER', 'Server Level');
define('WSI_GROUP_CLIENT', 'Client Level');
define('WSI_ADD_WIDGETS', 'Available widgets');
define('WSI_GROUP_NETWORK_HELP', 'Network Level');
define('WSI_GROUP_SERVER_HELP', 'Server Level');
define('WSI_GROUP_CLIENT_HELP', 'Client Level');
?>
