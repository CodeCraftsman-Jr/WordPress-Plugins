=== Plugin Name ===
Contributors: WEBO Software
Donate link: http://sprites.in/donate/
Tags: performance, gzip, compress, cache, load time, CPU usage, RAM usage, statistics
Stable tag: trunk
Requires at least: 2.6.0
Tested up to: 3.0.1

WEBO Site InSight provides all statistical information about website performance: load time, CPU usage, RAM usage, free disk space, etc.

== Description ==

WEBO Site InSight has a CMS-independent API, and it allows you to re-use any widgets code for all other CMS supported by WEBO Site InSight.

Please read more in [project page Wiki](http://code.google.com/p/webo-site-insight/w/list "project page Wiki")

== Installation ==

== Frequently Asked Questions ==

== Upgrade Notice ==

== Screenshots ==

== Changelog ==

= 0.2.0 =
* Initial version