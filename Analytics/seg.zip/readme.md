Seg's WooCommerce plugin to install tracking code and import historical data into Seg.

The wiki contains more information.
