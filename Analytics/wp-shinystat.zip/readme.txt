 === Plugin Name ===
Contributors: Paolo Rossi
Donate link: http://www.ruscibar.it/donate/
Tags: statistics
Requires at least: 2.8
Tested up to: 3.6
Stable tag: 0.3

WP-ShinyStat is a WordPress plugin that allows a simple integration of ShinyStat counter into your blog sidebar.

== Description ==

WP-ShinyStat is a WordPress plugin that allows a simple integration of ShinyStat counter into your blog sidebar.

WP-ShinyStat doesn't show ShinyStat counter (and doesn't track visits) when you are connected to your blog as admin user.

== Installation ==

1. Upload wp-shinystat folder to the `wp-content/plugins` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to widget page and add ShinyStat widget to your sidebar
1. Configure widget with your ShinyStat code
1. Save the new configuration

== Frequently Asked Questions ==

= Can I put the the shinystat counter out of the sidebar? =

No, the plugin is designed to support only sidebar widget

= I installed the plugin but the counter doesn't appear on my sidebar. What's wrong? =

Be sure that you are using a widget-enabled theme on your wordpress.

== Screenshots ==

1. WP-SninyStat configuration

