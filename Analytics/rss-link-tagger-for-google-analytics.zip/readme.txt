=== RSS Link Tagger for Google Analytics ===
Contributors: timanrebel
Tags: rss,google analytics,tracking
Requires at least: 2.6.2
Tested up to: 2.8.4
Stable tag: 1.1.2

Modifies RSS permalinks to include utm query parameters, used by Google Analytics to track non-adwords advertising campaigns.

== Installation ==

1. Upload `rss-link-tagger-for-google-analytics.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.1.2 =
* Now I really fixt it. Again with thanks to @dougal

= 1.1.1 =
* Fixt bug where feed/atom and feed/rdf request weren't correctly handled by this plugin. With thanks to @dougal for supplying the fixed code.

== Frequently Asked Questions ==

= Where do I find the results for the rss campaign in Google Analytics =

Go to Google Analytics and select the correct website profile. Then go to 'Traffic Sources' in the left menu en select 'Campaigns'
