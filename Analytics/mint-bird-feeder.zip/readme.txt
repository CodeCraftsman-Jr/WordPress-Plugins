=== mint-bird-feeder ===
Contributors: nickforge
Tags: mint, bird-feeder, stats, rss
Requires at least: 2.7
Tested up to: 2.8.5
Stable tag: trunk

This simple plugin provides integration between the Mint Bird Feeder Pepper and WordPress. It adds both Feeds and Seeds tracking support.

== Description ==
