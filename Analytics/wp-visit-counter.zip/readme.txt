=== WP Visit Counter ===
Stable tag: 1.0

Simply displays one more column in your posts/pages for number of visits.
