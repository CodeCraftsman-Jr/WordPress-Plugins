=== Visitor Stats Widget ===
Contributors: Shaon
Donate link:  
Tags: page, posts, post, widget, links, image, admin, sidebar, plugins, plugin, comments, images, visitors, stats, online stats, online visitors
Requires at least: 2.0.2
Tested up to: 3.2.0
Stable tag: 4.3
 

Real-time stats for your wordpress site.
   

== Description ==

Real-time stats for your wordpress site. A list of pages people are currently reading. Beside each page the number of people on that page. Popular pages are near the top of the list. A list of recent readers and the pages they were or are on is also available.

We know you can't monitor the widget 24/7, so we do that for you. Easily check how many people were simultaneously on your site, down to the hour.

Finally, no stats page is complete without knowing where people come from. Our maps pinpoint the location for every one of your readers -- live, right down to their city!

 

== Installation ==


1. Upload `visitor-stats-widget` to the `/wp-content/plugins/`  directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==
N/A

== Screenshots ==
N/A
== Changelog ==

= 1.0.5 = 
* Some minor css issue adjusted

= 1.0.2 =
* 2 minor bug fixed

= 1.0.0 =
* initial release

== Arbitrary section ==
N/A

== A brief Markdown Example ==

== Upgrade Notice ==
N/A