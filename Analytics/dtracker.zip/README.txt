=== Dtracker ===
Contributors: dijo
Tags: download, tracker, track
Requires at least: 2.9.2
Tested up to: 3.0.1
Stable tag: 1.5

Track the details of the users downloading the pdf files from wordpress site.

== Description ==

A simple plugin to track the downloads from the site.

This plugin will help the wordpress admin to track the whitepaper(PDF Files) download from the site and to manage it from the wordpress admin area.


== Installation ==

1. Download the plugin to the system.
2. Go to the Wordpress admin dashboard.
3. Click on the 'Add New' under the 'Plugins' section.
4. Select the Upload method to add the new plugin.
5. Browse the plugin from the system and install the plugin.
6. Activate the plugin.

== Frequently Asked Questions ==

= What type of files will be used for this plugin? =

This plugin will only support PDF File downloads. All The PDF Files will be listed in the download section uploaded through the Media Manager.

= How can I setup a download section in the site? =

Steps to setup a download section:
1. Click on the Widget links under the 'Appearance'.
2. Drag and Drop a Text widget to the place we wish to show the Download section.
3. Title is not needed. So leave the title field blank for the text widget.
4. Put the shortcode '[whitepapers]' in the widget body.
5. If there are any PDF file uploaded already, those file will be listed in the download section else nothing is displayed.

= Where can I see the contact details of the user? =

There is a link called 'DTracker' under the Settings section in the Admin dashboard. Clicking on that link will direct to the page with contact details. 

== Changelog ==
= 1.5 =
*First version
*Basic features

== Upgrade Notice ==

