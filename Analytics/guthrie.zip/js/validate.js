$(document).ready(function() {
	//$("#profileAddForm").validate();
	//$("#profileInviteForm").validate();
});