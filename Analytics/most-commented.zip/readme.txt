=== Most Commented Widget ===
Contributors: nickmomrik
Tags: comments, popular, rank, widget
Stable tag: trunk
Requires at least: 2.8
Tested up to: 2.9

Add a widget to display a list of the posts/pages with the most comments.

== Installation ==
1. Upload `most-commented.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Browse to Appearance->Widgets, add the widget, and configure the options

== Changelog ==

= 2.0 =
* Widgetize the plugin
* Add an option to display to posts, pages, or both
* Do not include posts/pages without comments
