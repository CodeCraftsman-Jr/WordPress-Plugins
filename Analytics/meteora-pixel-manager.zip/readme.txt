=== Meteora Pixels ===
Tags: meteora, meteora.co
Requires at least: 3.5.1
Tested up to: 4.1
Stable tag: trunk
License: Apache-2.0
Contributors: oneofone
License URI: http://www.apache.org/licenses/LICENSE-2.0

Easily install and manage your Meteora Pixel code.

== Description ==
The Meteora pixel manager installs your pixels for you automatically. This will allow you to track all website visitors and add them to your Meteora campaigns. 

Our plugin also has full support for WooCommerce and conversion tracking. Simply install the plugin, login to your Meteora account, and return to the Meteora dashboard to start your campaigns

== Installation ==
1. Install the plugin
2. Login with your Meteora account
3. Return to the Meteora dashboard to start your campaigns

== Changelog ==
0.1 initial release
