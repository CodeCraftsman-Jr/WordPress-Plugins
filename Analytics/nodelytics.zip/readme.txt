=== Nodelytics Real Time Stats ===
Contributors: strx
Donate link: http://www.strx.it/donate
Tags: analytics, statistics, access, spy, stats
Requires at least: 2.0
Tested up to: 3.1.1
Stable tag: 1.1.1

Simplest way to add Nodelytics code to enable real time statistics

== Description ==

Nodelytics is a work-in-progress service that let you see in real time who is 
visiting your web site without reloading the page.

Youtube demo video: http://www.youtube.com/watch?v=Sxwp75HGHMs

== Installation ==

Upload the plugin to your blog, Activate it, Go to http://nodelytics.strx.it/stat/www.YOURSITE.com

== Screenshots ==

1. Nodelytics Simple Grid Interface
2. Nodelytics World Map

== Frequently Asked Questions ==

= Where can I find more info or support =

[Here](http://www.strx.it/2011/04/nodelytics-node-js-real-time-stats/).

== Changelog ==

= 1.1.1 =
* World map support

= 1.1.0 =
* Update to Script version, with referrer support and realtime presence check

= 1.0.1 =
* Img styled to be ever more unobtrusive

= 1.0.0 =
* First Version
