﻿=== MobiDevices PageViews ===
Contributors: MobiDevices Soft
Donate link: http://mobidevices.ru
Tags: MobiDevices, Pageview, Просмотры
Requires at least: 3.3
Tested up to: 4.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Displaying the number of views your publications in the admin. Вывод количества просмотров ваших публикаций в админке

== Description ==

Displaying the number of views your publications in the admin. Plugin developed by <a href="http://mobidevices.ru">MobiDevices</a>.

Вывод количества просмотров ваших публикаций в админке. Плагин разработан компанией <a href="http://mobidevices.ru">MobiDevices</a>.

== Installation ==

1. Установить плагин MobiDevices PageViews
2. Активировать плагин
3. Наслаждаться показом просмотров

== Frequently Asked Questions ==

Если плагин не работает, значит он не включен. По другому никак.

== Screenshots ==

== Upgrade Notice ==

Общее улучшение производительности

== Changelog ==

= 1.0 =
Создание плагина

= 1.1 =
Оптимизация производительности, исправление ошибок и улучшение архитекртуры