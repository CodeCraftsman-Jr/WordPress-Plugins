﻿=== peq Leia Mais spry adobe ===
Contributors: pablo erick
Donate link: http://peq.110mb.com/
Tags: adobe, spry , javascript, efeito, jquery, ocultar texto, pablo erick, pablo, erick, collapse panel, collapse
Requires at least: 3.0
Tested up to: 3.1
Stable tag: 1.0

Abra e Feche um resumo de conteudo de forma pratica.

== Description ==

Oculta o conteúdo de texto e mostra somente um link Leia mais..., ao clicar no link abre o conteúdo de forma suave com javascript.

== Installation ==

1. Upload `peq-leia-mais-adobe-srpy.php` to the `/wp-content/plugins/` directory
2. Use short code [peqLeia abrir='leia mais...' fechar='fechar']

Exemplo

[peqLeia abrir='leia mais...' fechar='fechar']
Conteudo de exemplo non ono no nonon ono o o no no non n on
[/peqLeia]

caso utilize o editor ckeditor adicionar a linha de comando ao arquivo:
ckeditor-for-wordpress/ckeditor.config.js
config.entities = false;


== Screenshots ==

1. screenshot-1.jpg
2. screenshot-2.jpg

