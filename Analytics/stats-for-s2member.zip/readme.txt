=== Stats for S2Member ===
Contributors: PeterShilling 
Donate link:http://helpforwp.com/donate/
Tags: membership,statistics,users
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: trunk

This plugin adds basic statistics to the S2Member Plugin showing how many member signups in the current month & details of member's expiring. 

== Description ==

This is an add on for S2Member. Stats for S2Member adds some basic statistics to the WordPress Dashboard showing the number of members signed up to your WordPress site in the current month.

Additionally, a new menu item Stats for S2Member is added to the S2Member menu that add a full page showing the details of the members that have signed up in the current month as well as those with an expiry coming up.

Here you can choose to filter the users in your site and view the actual accounts that are new and expiring.

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

View the stats from the WordPress Dashboard or look for the new menu item Stats for S2Member in the main S2Member menu.
== Frequently Asked Questions ==

For support and FAQ, please visit http://Support.helpforwp.com
== Screenshots ==
1. Dashboard widget

2. Statistics page

== Changelog ==
Version 1.0.1 initial public release