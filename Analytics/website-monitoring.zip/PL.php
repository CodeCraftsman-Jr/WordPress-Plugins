<?
// SETTINGS PAGE
$lang['sett_0'] = "Wtyczka <strong>Super Monitoring</strong> jest prawie gotowa. Trzeba ją jeszcze <a href=\"options-general.php?page=website-monitoring/supermonitoring.php\">skonfigurować</a>.";
$lang['sett_1'] = 'Super Monitoring - ustawienia wtyczki';
$lang['sett_2'] = 'Jeżeli posiadasz już usługę w serwisie www.supermonitoring.pl, wprowadź token żeby zintegrować ją z panelem WordPress.';
$lang['sett_3'] = 'Token autoryzacyjny:';
$lang['sett_7'] = 'Token znajdziesz w swoich Ustawieniach Konta w serwisie <a href="http://www.supermonitoring.pl/" target="_blank">www.supermonitoring.pl</a>.';
$lang['sett_4'] = 'Język:';
$lang['sett_5'] = 'Zapisz zmiany';
$lang['sett_6'] = 'Jeśli nie masz jeszcze konta w serwisie www.supermonitoring.pl, <a href="http://www.supermonitoring.pl/landing/page1/indexPL.php?utm_source=WordPress&utm_medium=text&utm_campaign=plugin" target="_blank"><strong>zarejestruj się tutaj</strong></a> aby otrzymać 14-dniowe konto próbne.';

// MENU
$lang['menu_1'] = "Twoje strony";
$lang['menu_2'] = "Twoje ustawienia";
$lang['menu_3'] = "Twoje kontakty";

$lang['error_1'] = "Nieprawidłowy token. Token znajdziejsz w swoich Ustawieniach Konta w serwisie <a href=\"http://www.supermonitoring.pl/\" target=\"_blank\">www.supermonitoring.pl</a>.";
$lang['confirm_1'] = "Zmiany zostały zapisane.";
$lang['service_domain'] = 'www.supermonitoring.pl';
?>
