<?
// SETTINGS PAGE
$lang['sett_0'] = "<strong>Super Monitoring</strong> plugin is almost ready. You only need to <a href=\"options-general.php?page=website-monitoring/supermonitoring.php\">configure it</a>.";
$lang['sett_1'] = 'Super Monitoring - plugin settings';
$lang['sett_2'] = 'If you already have a subscription at www.supermonitoring.com, enter your token to integrate the service with WordPress panel.';
$lang['sett_3'] = 'Authorization token:';
$lang['sett_7'] = 'You can find the token in your Account Settings at <a href="http://www.supermonitoring.com/" target="_blank">www.supermonitoring.com</a>.';
$lang['sett_4'] = 'Language:';
$lang['sett_5'] = 'Save changes';
$lang['sett_6'] = 'If you don\'t have an account at www.supermonitoring.com yet, <a href="http://www.supermonitoring.com/landing/page1/?utm_source=WordPress&utm_medium=text&utm_campaign=plugin" target="_blank"><strong>sign up here</strong></a> for a 14-day free trial.';

// MENU
$lang['menu_1'] = "Your websites";
$lang['menu_2'] = "Your settings";
$lang['menu_3'] = "Your contacts";

$lang['error_1'] = "Invalid token. You can obtain your token in your Account Settings at <a href=\"http://www.supermonitoring.com/\" target=\"_blank\">www.supermonitoring.com</a>.";
$lang['confirm_1'] = "Changes have been saved.";
$lang['service_domain'] = 'www.supermonitoring.com';
?>