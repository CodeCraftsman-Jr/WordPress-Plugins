<?
// SETTINGS PAGE
$lang['sett_0'] = "<strong>Super Monitoring</strong> plugin está casi listo. Sólo tienes que <a href=\"options-general.php?page=website-monitoring/supermonitoring.php\">configurarlo</a>.";
$lang['sett_1'] = 'Super Monitoring - configuración del plugin';
$lang['sett_2'] = 'Si ya tiene una suscripción a www.supermonitoring.com, introduzca su token de integrar el servicio con el panel de WordPress.';
$lang['sett_3'] = 'Token de autorización:';
$lang['sett_7'] = 'Usted puede encontrar el token de configuración de tu cuenta en <a href="http://www.monitoreo-sitios.com/" target="_blank">www.monitoreo-sitios.com</a>.';
$lang['sett_4'] = 'Idioma:';
$lang['sett_5'] = 'Guardar cambios';
$lang['sett_6'] = 'Si usted no tiene una cuenta en www.monitoreo-sitios.com todavía, <a href="http://www.supermonitoring.com/landing/page1/?utm_source=WordPress&utm_medium=text&utm_campaign=plugin" target="_blank"><strong>regístrese aquí</strong></a> para una prueba gratuita de 14 días.';

// MENU
$lang['menu_1'] = "Su sitios web";
$lang['menu_2'] = "Su suenta";
$lang['menu_3'] = "Sus contactos";

$lang['error_1'] = "Token incorrecta. Usted puede obtener su ficha en configuración de tu cuenta en <a href=\"http://www.monitoreo-sitios.com/\" target=\"_blank\">www.monitoreo-sitios.com</a>.";
$lang['confirm_1'] = "Los cambios se han guardado.";
$lang['service_domain'] = 'www.monitoreo-sitios.com';
?>