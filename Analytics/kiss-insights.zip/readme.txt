=== Kiss Insights ===
Contributors: Stinkyink
Tags: javascript, kiss insights, analytics
Requires at least: 2.7
Author URI: http://www.stinkyinkshop.co.uk/themes/
Plugin URI: http://www.stinkyinkshop.co.uk/themes/plugins/kiss-insights/
Tested up to: 3.3.1
Stable tag: 2.0.3

Enables Kiss Insights on your WordPress powered blog!

== Description ==

This plugin adds the required javascript for Kiss Insights.

For more information visit:

[Kiss Insights](http://www.kissinsights.com/)
[Stinkyink Plugin Page](http://www.stinkyinkshop.co.uk/themes/plugins/kiss-insights/)

== Installation ==

1. Upload `kissinsights` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Copy your unique javascript URL from the Kiss Insights account screen
4. Create your surveys as usual on the Kiss Insights website
5. Done!

== Changelog ==

2.0.3 - moved plugin to wp_head at request of KI to improve access to other KI features

2.0.2 - fixed problem with missing options.php file!!!! Sorry!

2.0.1 - updated version number in main plugin file because I fogot

2.0 - Added options screen so people can tie plugin to their account :-)

1.0 - Created Plugin