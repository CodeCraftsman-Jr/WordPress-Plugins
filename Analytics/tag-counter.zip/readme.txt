=== Tag counter ===
Contributors: tomek00
Tags: tag, tags, count, counter, widget
Donate link: http://wp-learning.net/blog/felajanl
Requires at least: 3.4
Tested up to: 4.1.1
Stable tag: trunk

Writes in the slidebar the numbers of tags

== Description ==
Writes in the slidebar the numbers of tags

== Installation ==

1. Extract the plugin folder from the downloaded ZIP file.
2. Upload tags to your /wp-content/plugins/ directory.
3. Activate the plugin from the "Plugins" page in your Dashboard.
4. Activate the widget through the 'Widgets' menu in WordPress

== Frequently Asked Questions ==
None

== Screenshots ==
None

== Upgrade Notice ==
Nothing

== Changelog ==

None