<div class="wrap">
    <div class="para-settings">
        <div class="para-dashboard">
        	

            
			<div class="dash-box">
                <div class="dash-box-title"><span class="para-icons user-crowd">Total Visitor</span></div>
                <div class="dash-box-info">Estimate total visitor session. </div>
                <div class="total-session">0<?php //echo pvc_paratheme_TotalSession("session_id"); ?></div>
            </div>  
            
            
			<div class="dash-box">
                <div class="dash-box-title"><span class="para-icons user-crowd">Unique Visitor</span></div>
                <div class="dash-box-info">Estimate unique visitor. </div>
                <div class="unique-visitor">0<?php //echo pvc_paratheme_UniqueVisitor("ip"); ?></div>
            </div>  
            
			<div class="dash-box">
                <div class="dash-box-title"><span class="para-icons user-crowd">Unique Page View</span></div>
                <div class="dash-box-info">Estimate unique page view. </div>
                <div class="unique-visitor">0<?php //echo pvc_paratheme_UniquePageView("isunique"); ?></div>
            </div>              
			<div class="dash-box">
                <div class="dash-box-title"><span class="para-icons user-crowd">Unique Page View</span></div>
                <div class="dash-box-info">Estimate unique page view. </div>
                <div class="unique-visitor">0<?php //echo pvc_paratheme_UniquePageView("isunique"); ?></div>
            </div>  




           
        </div> <!-- para-dashboard --> 


		
	</div> <!-- para-settings --> 	  
</div>