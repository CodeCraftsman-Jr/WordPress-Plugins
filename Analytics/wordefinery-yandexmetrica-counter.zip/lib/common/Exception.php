<?php

namespace wordefinery;

class Exception extends \Exception {

}
