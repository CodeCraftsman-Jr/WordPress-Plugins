﻿=== Wordefinery Yandex.Metrica Counter ===
Contributors: wordefinery
Donate link: http://wordefinery.com/
Tags: yandex, metrica, metrika, counter, widget, rating, tracker
Requires at least: 2.7
Tested up to: 3.4.1
Stable tag: trunc

Displays Yandex.Metrica Counter

== Description ==

* Widget, footer and shortcode


== Installation ==

1. Upload and unzip `wordefinery-yandexmetrica-counter` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

= System Requirements =

* WordPress 2.7 or greater (tested up to 3.4.1)
* Recommended WordPress 3.0 or greater
* PHP 5.2 or greater
* Recommended PHP 5.3 or greater

= Known Issues =

* Widget disabled on WordPress 2.7 - 2.7.1


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.6.8.1 =
* Fix fatal error

= 0.6.8 =
* Fix preview issues
* Fix widget output

= 0.6.7 =
* Fixed PHP 5.2 warnings

= 0.6.5 =
* Ported to WordPress 2.7 (limited functionality)
* Fix bug with shortcode

= 0.6.3 =
* Add Gradient option

= 0.6.2 =
* Ported to WordPress 2.8
* Fix bug with multiple informers

= 0.6.1 =
* Ported to PHP 5.2

= 0.6 =
* Testing

== Upgrade Notice ==

