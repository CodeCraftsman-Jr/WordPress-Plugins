=== Sandbox Analytics ===

Contributors: Stringcan
Tags: sandbox, crm, marketing software, small business software, lead, leadcapture, lead management, Stringcan
Requires at least: 4.1
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Track users to your website with your Sandbox CRM dashboard.

== Description ==

Sandbox Analytics pairs your Sandbox CRM account with your WordPress site so you can track new visitors. Sandbox and Sandbox Analytics are a must have for maximizing your company\'s marketing effort.

== Installation ==

1. Simply download the plugin and install.
2. Click the Sandbox icon in the left menu.
3. Check \"Enable Tracking\".
4. Enter your Sandbox account number.
5. Save your options!

== Screenshots ==

1. Enable tracking and add your account number on the options page.