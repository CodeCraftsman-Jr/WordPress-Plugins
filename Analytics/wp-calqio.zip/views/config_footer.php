<?php include_once( dirname(__FILE__).'/include_js.php' ); ?>

	</div><!-- / bootstrap-wpadmin -->
</div><!-- / wrap -->
