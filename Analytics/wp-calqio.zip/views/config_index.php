<?php
$sBaseDirname = dirname(__FILE__).ICWP_DS;
include_once( $sBaseDirname.'config_header.php' );
include_once( $sBaseDirname.'config-options-table.php' );
include_once( $sBaseDirname.'config_footer.php' );
