=== Plugin Name ===
Contributors: Net-Freak
Donate link: http://net-freak.dk/
Plugin URI: http://net-freak.dk/nf-livecounter-stats-wordpress-pluginwidget/
Author URI: http://Net-Freak.dk
Tags: Livecounter, stats, Statistics
Requires at least: 2.0.2
Tested up to: 3.0.4
Stable tag: 1.0.3

Here is a short description of the plugin.

== Description ==

Et lille plugin der er i stand til at vise dine Livecounter stats p&aring; din hjemmeside via widgets. 

== Installation ==

Installer pluginnet og aktiver din widget.

== Frequently Asked Questions ==

= Min widget viser ikke stats, hvad g&oslash;r jeg? =

Tjek om du har husket at skrive dit rigtige livecounter ID ind i din widget.


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png

== Changelog ==
= 1.0.2 =
* Bugfixes.

= 1.0.1 =
* NF-Livecounter tilf�jet til Wordpress.org Pluginarkiv.

= 1.0 =
* NF-Livecounter Pluging released.

== Arbitrary section ==



== A brief Markdown Example ==

Et lille plugin der er i stand til at vise dine Livecounter stats p&aring; din hjemmeside via widgets.

[feedly mini] 