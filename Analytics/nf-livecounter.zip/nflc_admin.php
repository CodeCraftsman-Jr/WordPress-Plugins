<div class="wrap">
<h2>NF Livecounter Stats</h2>
<?php
echo utf8_encode('<p>Denne side er reseveret for fremtidige features og indstillinger. Som landet ligger pt. er <strong>NF Livecounter Stats</strong> kun i en beta udgave, og har derfor ikke f�et andre indstillinger eller funktioner endnu, udover dem som du finder ved at konfigurere din <strong>Livecounter Widget</strong>.</p><p>Dette plugin er lavet af <strong><a href="http://net-freak.dk/" target="_blank" title="Bes�g Net-Freak.dk">Peter Piilgaard (Net-Freak)</a></strong>, og du kan l�se mere om dette plugin, dets opdateringer og nyheder p� <strong><a href="http://net-freak.dk/nf-livecounter-stats-wordpress-pluginwidget/" target="_blank" title="NF Livecounter Stats">NF Livecounter plugin siden</a>..</strong></p>');
?>
</div>
