=== No Piwik for me ===
Contributors: ppfeufer
Donate link:
Tags: piwik, analytics
Requires at least: 3.2
Tested up to: 3.8-alpha
Stable tag: 1.2
License: GPLv2

Erstellt den Shortcode <code>[no_piwik]</code> um die nutzerbezogene Deaktivierung von Piwik zu ermöglichen.

== Description ==

Ermöglicht es dem Besucher der Webseite mit einem einfachen Mausklick das Tracking von Piwik zu deaktivieren. Setzt voraus das [WP-Piwik](http://wordpress.org/extend/plugins/wp-piwik/ "WP-Piwik") installiert und aktiviert ist.
Der Shortcode <code>[no_piwik]</code> kann dann ganz einfach im Impressum unter den Klausel für Piwik verwendet werden.

== Installation ==

**Installation via Wordpress**

1. Menu 'Plugins' -> 'Installiern' und nach 'No Piwik for me' suchen
1. Installieren klicken

**Manuelle Installation**

1. Plugin herunterladen und entpacken
1. Verzeichnis `no-piwik-for-me` nach `/wp-content/plugins/` hochladen.
1. Plugin aktivieren.

== Screenshots ==

Keine.

== Changelog ==
= 1.2 =
* (02. November 2012)
* Tested up to WordPress 3.8-alpha

= 1.1 =
* (02. 01. 2013)
* Ready for WordPress 3.5

= 1.0 =
* (09. 05. 2012)
* Initial Release

== Frequently Asked Questions ==

Bei Fragen, nutze bitte die Kommentare unter [http://blog.ppfeufer.de/wordpress-plugin-no-piwik-for-me/](http://blog.ppfeufer.de/wordpress-plugin-no-piwik-for-me/).

== Upgrade Notice ==

Einfach machen :-)
