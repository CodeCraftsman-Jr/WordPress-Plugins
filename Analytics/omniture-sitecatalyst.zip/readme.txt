=== Omniture - SiteCatalyst ===
Contributors: Rudi Shumpert
Tags: Omniture web analytics, statistics, stats, tracking
Requires at least: 2.8
Tested up to: 2.9
Stable: 0.1.0 


This plugin will add tracking features to your wordpress blog without have to know any PHP, 
edit code, or cut and paste tracking code to footers.  Also, if you change or update themes, 
you will not have to remember to update tracking code.  You will have to be able to upload your
Omniture s_code.js file to directory on your web server.

== Description ==

This plugin will add tracking features to your wordpress blog without have to know any PHP, 
edit code, or cut and paste tracking code to footers.  Also, if you change or update themes,
 you will not have to remember to update tracking code.  You will have to be able to upload your
Omniture s_code.js file to directory on your web server.


**Features**

* Enter all settings through admin screen
* Tracks all pages 
* Captures logged in status of users
* Captures internal search terms
* Captures number of search results
* Captures 404 data
* Ability to track/not track Administrators
* Ability to set event to track comments and to set event number in admin settings
* Added Reporting widgets from inside WordPress (Optional)

== Installation ==

ADD INSTALL NOTES HERE

Install:

Copy files to wp-content/plugins
Activate Plugin in admin>plugins


== Frequently Asked Questions ==

= Where can I find out more information about the plugin? =

View project page for more details
http://www.rudishumpert.com/projects/wp-omniture/

=What is an Omniture SiteCatalyst Widget=

Omniture has created a SiteCatalyst Widget that allows you to add reportlets from SiteCatalyst Dashboards to your aggregator/portal of choice (iGoogle, My Yahoo, etc�).
More Info: http://blogs.omniture.com/2008/11/23/sitecatalyst-widgets-inside-omniture-sitecatalyst/


== Screenshots ==

View project page for more details
http://www.rudishumpert.com/projects/wp-omniture/