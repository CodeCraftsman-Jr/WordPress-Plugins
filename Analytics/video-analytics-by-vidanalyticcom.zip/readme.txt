=== VidAnalytic (defunkt) ===
Contributors: vidanalytic
Donate link: vidanalytic.com
Requires at least: 2.8
Tested up to: 4.0
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

VidAnalytic (Defunct)

