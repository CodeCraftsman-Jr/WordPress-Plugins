=== tagBeep uptime monitor ===
Contributors: opradu
Tags: admin, uptime, email, plugin, monitoring, service, monitor, alert, downtime, optimize
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: trunk

Get an email when your blog is offline or slow. Fast and easy install, it takes just five seconds to set up.

== Description ==

This free plugin will send you an email when your blog is offline. 

How to use:

1. Activate the plugin
2. Review the auto completed information.
3. Enter a new password for tagbeep and you are done.

Thanks for stopping by and I hope you like the plugin!

== Installation ==

1. Download the plugin zip archive.
2. Extract it in your `wp-content/plugins` folder or upload via admin panel.
3. Browse to your plugins section and active the plugin.

== Frequently Asked Questions ==

= How does it work? =

The plugin will register your blog with tagBeep�s uptime monitoring service. After that tagBeep will check your site periodically.

= Will this plugin slow my blog down? =

After you register with tagBeep via the plugin, no more code will run on your host. TagBeep will check your site every five minutes by making a request.

= Are there any other alert options? =

Yes! You can use email, email2sms, twitter, sms via the manage account button from the plugin.

= Contact me via email: =

contact@tagbeep.com

== Screenshots ==

1. the plugin settings
2. tagBeep uptime monitoring plugin

== Changelog ==

= 1.1 =
* This is the first public release. 
* added fast install