=== Mechanic Who's Online Visitor ===

Contributors: adityasubawa
Donate link: http://www.adityasubawa.com
Tags: whos online, online visitor, online user, who is online visitor, simple online visitor
Requires at least: 3.2
Tested up to: 3.4.1
Stable tag: 1.3

very simple who's online visitor plugins enables you to track number of visitors online in an easy to install.  

== Description ==

Mechanic Who's Online Visitor is display number of online visitor or guest on your WordPress website and blog. very simple who's online visitor plugins enables you to track number of visitors online in an easy to install as a widgets.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `whosmechanic.zip` to the `/wp-content/plugins/` directory. You can do this using 'Upload' functionality provided in plugins section of your wordpress dashboard
2. Activate the plugin through the `Plugins` menu in WordPress
3. Go to `Appearance` >> `Widgets` and drag `Mechanic - Who is Online` in to your widget area.
4. Save
5. You are done. 

== Screenshots ==

1. Display Example

== Frequently Asked Questions ==

= How to editing display of Text Widgets? =

you must open the file `wp-whosmechanic.php` plugins on the `wp-content/plugins/whosmechanic/` and look PHP code on line 134 and 137, 134 for visitor online and 137 for no one visitor online. You must understand PHP programming to do that action.

== Changelog ==

= 1.0 =

fix title widgets

= 1.1 =

upgrade to 1.3

= 1.3 =

Plug-in is now compatible upto wordpress version 3.5.1

== Credits ==

[Aditya Subawa](http://www.adityasubawa.com/) - This plugin was created by Aditya Subawa. If you like this widget and would like to donate to help support new versions of this widget you can do so at the <a href="http://www.adityasubawa.com">support center</a> website.

== Contact ==

If you need help, support or would just like to provide your comments and suggestions you may visit us online at <a href="http://www.adityasubawa.com">my personal website</a> or <a href="http://balimechanicweb.net">web design</a> support center.

