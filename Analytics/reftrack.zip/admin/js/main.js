jQuery(document).ready(function($) { 
	
	$('#reftrack-addnewbtn').on('click', function() { 
		$('.reftrack-addnewuser').fadeToggle();
	});
	
});
