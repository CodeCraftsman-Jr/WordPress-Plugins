=== Reftrack ===
Contributors: djuric
Tags: reftrack, referral tracking, affiliate
Donate link: https://firescripts.net
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.txt

With this referral tracking plugin you can log visits of users who you give unique referral link and keep track of their actions on website


== Description ==
<p>Reftrack plugin allows admin of the site to create unique referral links which can be used to track visits that came from this link to the website.</p>
<p>There is full table with logs of all visits so you can keep track how many visits came from particular referral link</p>


== Installation ==
1. Upload plugin folder (unzipped) to the "/wp-content/plugins/" directory OR complete zip package in Plugins > Add New > Upload menu in admin of wordpress
2. Activate the plugin through the "Plugins" menu in WordPress.

== Changelog ==
= 1.0 =
* Initial release.

= 1.1 =
* Pagination bug fixed
