=== Recent visited ===
Contributors: lpkapil,namastemukesh
Tags: Recent visited products, posts, Recent visited custom posts, custom posts, recent visited, recent visited items, last visited items
Requires at least: 2.8
Tested up to: 4.1.1
Stable tag: 1.0

A plugin to display recently visited custom post type. display last visited selected post type items using short-code :[VISITED_ITEMS]

== Description ==
A plugin to display recently visited custom post type. admin can use this plugin to show recent visited registered post types items to website visitor using simple short-code: 

[VISITED_ITEMS]



== Installation ==
1. install plugin zip file \'recent-visited.zip\' and active plugin.
2. set post types and number of posts to show from Recent visited admin menu item.
3. use short-code: [VISITED_ITEMS]

== Frequently Asked Questions ==
Question. is this plugin support custom post types , like products etc ?

Answer: yes, it supports all registered post types.

== Screenshots ==
1. http://s1.postimg.org/mneagpd5r/screenshot_1.png
2. http://s3.postimg.org/n9zkz1hw3/screenshot_2.png

== Changelog ==
released first version 1.0