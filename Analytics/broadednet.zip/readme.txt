=== BroadedNet ===
Contributors: dangpraveen
Tags: blog,blog traffic,blog netwok,blog community,blog promote,blog promotion tool,traffic
Donate link: http://broaded.net
Requires at least: 3.0
Tested up to: 4.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Connect to Broaded.net, a network of blogs for promotion and traffic

== Description ==
BroadedNet is a network of blogs  for blog promotion and traffic. It takes your blog article from a single position and spreads it all over the network. Members generate huge traffic to their blogs without search engines and social media. BroadedNet is a free platform
Go to [BroadedNet](http://broaded.net) and signup for your free account now

== Installation ==
1. Upload `broadedNet.zip` to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress
That will be it

== Frequently Asked Questions ==
Q. Is this a requirement to join the BroadedNet community?
A. While this is the only means we have now to connect Wordpress Blogs to the core system, in the nearest future, we will be making available some html/javascript option.

== Screenshots ==
1. BroadedNet Widget configuration
2. This is how the widget looks like on one blog in the network. This widget is configured to show gravatar of bloggers who posted campaings.
3. Here is the widget on another blog, this time configured not to show gravatar. Note that the widget takes the inbuilt design of your theme.
4. From version 1.4, Sticky Posts were added to be shown on top of the widget. Here is a sample.

== Changelog ==

1.4 Setting the number of entries on the widget

1.3 Added more widget features

1.2 Security update

1.1 Bug correction

1.0 Initial release

== Upgrade Notice ==
1.4 Added Sticky Entries to widget

1.3 More features were added on the widet in this version

1.2 Security update

1.1 stable version

1.0 Initial release