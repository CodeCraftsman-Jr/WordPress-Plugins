=== Sewol Count ===
Contributors: pangol
Tags: sewol
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a program that count day after Sewol Ferry Disaster. Sewol Ferry Disaster happened in Korea.
I hope that we don't forget Sewol Ferry

== Description ==

This is a program that count day after Sewol Ferry Disaster.

Major features in Sewol Count include:

* widget : day count after Sewol Ferry 
* color is yellow

== Installation ==

1. Upload the Sewol Count plugin to your blog, Activate it
1. In widgets, you can use it

== Screenshots ==

1. Screenshot of widget setting
2. Screenshot of plugin in action

== Changelog ==

= 1.0 =
* add count function

= 1.0.1 =
* add Korean Language

= 1.0.2 =
* add Konrean Title

= 1.0.3 =
* fix widget error

= 1.0.4 =
* fix some errors about widget

= 1.0.5 =
* fix widget title 

= 1.0.6 =
*remove duplicated widget titles