=== Analog Clock WP-7 ===
Contributors: Style-7
Donate link: 
Tags: analog clock, decoration
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Original analog clock for decoration and show the current time


== Description ==
Original analog clock for decoration and show the current time
Options: change secondary color and size from 160 to 256 pixels.


== Installation ==
1. Upload "analog_clock_wp-7.php" to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress
3. Select menu item "Plugins/Widgets", find "Analog Clock WP-7" click on it and select "Install", select widget destination place (best view on right slidebar).
4. In Administrator menu select size of the clock and secondary color.


== Frequently Asked Questions ==


= What about foo bar? =


== Screenshots ==
1. Clock appereance.


== Changelog ==
n/a


== Upgrade Notice ==
n/a