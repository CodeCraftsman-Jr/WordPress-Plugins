(function( $ ) {
	'use strict';


})( jQuery );
