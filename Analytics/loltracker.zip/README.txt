=== LoL Tracker ===
Contributors: vvasiloud
Donate link: -
Tags: lol,league of legends,riot,free week champions,rotation,api,stats,summoner
Requires at least: 3.7.0
Tested up to: 4.1.1
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

LoL Tracker is a set of tools relating your league of Legends account. 

== Description ==
 
In this current version there is only the functionality of "Free Week Champions Widget".

Reviews, requests and questions are always welcome!

More information: https://github.com/vvasiloud/wp-loltracker

All images used in this plugin are property of Riot Games, Inc.
Riot Games, League of Legends and PvP.net are trademarks, services marks, or registered trademarks of Riot Games, Inc.

== Installation ==

1. Upload `lol-tracker` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add your Riot API Key 
4. Add the widget
5. Done!

== Screenshots ==

1. Widget Screenshot. 
2. Options Page.

== Frequently Asked Questions ==

= Where I can find the Riot API Key? =
More information about obtaining a key here : http://developer.riotgames.com

== Changelog ==

= 1.0 =
* Initial version


== Upgrade Notice ==

= 1.0 =
Free Week Champions widget feature
