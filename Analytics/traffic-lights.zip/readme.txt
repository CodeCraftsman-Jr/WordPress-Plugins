=== Traffic Lights ===
Contributors: theode
Donate link: http://www.wp-plugin-dev.com/donate
Tags: traffic,lights,status
Requires at least: 3.0
Tested up to: 4.3.1
Stable tag: 0.13
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin which shows a simply traffic light to show some status to visitors.

== Description ==

Wanna show your visitors if they can call you or if you are available. 

As traffic light function for projects every logged in user can choose between red, amber and green.

You have it as dashboard widget, as sidebar widget and shortcode [trafficlights].

This Version can be connected with "HRM Work Tracking" and is showing Green for somebody is present, yellow somebody is there but in pause and red nobody is there. 





== Installation ==

1. Upload 'traffic-lights' folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Frequently asked questions ==

= Where can I get support? =
Contact us at http://www.wp-plugin-dev.com/support-contact/


== Changelog ==

= 0.1 =  Initial release