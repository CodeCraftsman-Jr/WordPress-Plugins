=== TR Easy Google Analytics ===
Contributors: BestThemeRoad
Author URI: https://profiles.wordpress.org/bestthemeroad
Author: ThemeRoad
Donate link: 
Tags: analytics, google, javascript,analytics, analytics dashboard, dashboard, google, google analytics, google analytics dashboard, google analytics widget, multisite, Realtime,wpmu,statistics, widget, GA code, Google Analytics in WordPress, remarketing analytics,universal analytics, WordPress Google Analytics,display advertising, GA code, GA code integration, GA Plugin, GA Script, google,Google Analytics in WordPress,statistics, universal analytics,WP Google Analytics, WP Google Analytics, Plugin,clicky, code, google, google analytic,PhpSword, piwik, Realtime, stats, tracking, Web Statistics, yahoo,GA code, GA code integration, GA Plugin,WordPress Google Analytics, WP Google Analytics, WP Google Analytics Plugin, display advertising, GA code, google analytics, Google Analytics in WordPress, universal analytics, WordPress Google Analytics,analytics, display advertising, GA code, GA code integration, GA Plugin, GA Script, google, google analytics, Google Analytics in WordPress, tracking code, universal analytics, WordPress Google Analytics, WP Google Analytics, WP Google Analytics Plugin, google,monitor, plugin, reports, shortcode, statistic, techgasp, widget, wordpress.

Requires at least: 3.5
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily Add Google Analytics for your websites and tracking all pages your sites perfectly.


== Description ==

### TR Easy Google Analytics by http://themeroad.net

Easy Google analytics is one of the best simple plugin to add or connect your websites with Google analytics.Its really easy for use everyone.Just install the plugin as like other wordpress plugin.And then you will see the analytics options in your dashboard.Then click analytics options and then you see a textarea.You will just copy the Google analytics tracking code and paste here. That's it and you will enjoy now. And Then you will get all kind of visitors reports from Google analytics. Because your all pages of your websites now link up or connected with google Analytics. So, enjoy and don't forget to rated us.

Plugin Features !!!!!

* Easy to use.
* Copy the Tracking Code and paste after install the plugin.

 
* [Our Premium Plugins](http://themeroad.net/154-2/)
 * [TR WP Custom Login](http://themeroad.net/Products/wp-custom-login-page/)
 * [TR Advanced Price Plan Pro](http://themeroad.net/Products/tr-price-plan-pro/)
 * [TR WooCommerce Image Zoom PRO](http://themeroad.net/Products/tr-woocommerce-image-zoom-pro/)
 * [TR Carousel Slider Pro](http://themeroad.net/Products/tr-carousel-slider-pro-4/)
 * [TR Logo Slider Pro](http://themeroad.net/Products/tr-logo-slider-pro/)
 * [TR Filterable Portfolio Pro](http://themeroad.net/Products/204/)
 * [TR Nice Accordion Pro](http://themeroad.net/Products/tr-premium-accordion-pro/)


== Installation ==

Via WordPress -
1. Install as a regular WordPress plugin.
2. From WordPress Dashboard go to "Plugins>> Add New>> Uploads", select 'TR Easy Google Analytics.zip' file and upload it. Or
3. Upload faq plugin to the /wp-content/plugins/ directory
4. Activate the plugin through the 'Plugins' menu in WordPress




Via FTP -

1. Upload .zip file to your WordPress plugin directory and unzip it.
2. Go your Plugins setting via WordPress Dashboard and activate it.
3. Then Publish some post on by go to'testimonial' and 'Add-new' post type with thumbnail



== Frequently asked questions == 

1. Is it a simple Plugin?
  Ans: Yes.
2. Have any options to contact for solve our problem?
  Ans: Ofcourse,why not. Just mail us BestThemeRoad@gmail.com or comments  to solve your problem.

== Screenshots ==

1. This is the view of  admin panel page.
2. This is the view of the analytics options plugin.




== Changelog ==

= 1.0 =
* Initial release
