<?php namespace Sitewit\Exception;

class SW_Api_Exception extends \Exception {

}
