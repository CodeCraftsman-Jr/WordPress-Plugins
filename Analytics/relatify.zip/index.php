<?php

/* Code is poetry */