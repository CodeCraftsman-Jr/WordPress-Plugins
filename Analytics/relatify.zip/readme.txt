=== Related Posts By Relatify ===
Contributors: Asif2BD, Relatify, tapan29bd, rupok
Donate link: http://relatify.co/go/free
Tags: related content, wordpress releated, related posts, more like this, related contents, nrelate, related widget, yarpp, simple related
Requires at least: 3.8.1
Tested up to: 4.1.1
Stable tag: 0.9.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The best & smartest related contents/posts plugin for WordPress. The only Related Contents Framework in the industry.

== Description ==

[Relatify](http://relatify.co/) - takes related contents for WordPress into different level. **Relatify** gives a complete new meaning of related contents. Now you don't have to slow down your site or rely on some third party service. And the design possibility is endless. Take a ride with us, we assure you won't regret it.



**Features:**

*  **New** Pro Templates **Elegant Pro** & **Modern Pro** now available
*  **New** Brand new interface, and lots of other feature.
*  **New** Ability to control & exclude Categories
*  **New** Ability to control & exclude tags
*  **New** Design update for Option Page
*  Smartest related results
*  Modern design
*  Full control how it looks in your site
*  Ability to use Featured Image, or image from custom field or first image from the post.
*  Ability to control image size
*  Theming capability
*  Premium design.
*  Tons of free design and more coming every week
*  Prompt support
*  Smart Mouse Hover effects available in design
*  Dynamic image size control
*  Templates Update.


== Installation ==

This section describes how to install the plugin and get it working.

= 1) Install =

= Modern Way: =
1. Go to the WordPress Dashboard "Add New Plugin" section.
2. Search For "relatify". 
3. Install, then Activate it.

= Old Way: =
1. Unzip (if it is zipped) and Upload `relatify` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

= 2) Configure =
1. Reach out to the Relatify-> Settings Page 
2. Configure as you need.



== Frequently Asked Questions ==

= How do I change design =

Go to Relatify-> Settings Page, select template you like.
 
= So, you have pro design? =

Go to Relatify-> Settings Page, Check the bottom Premium Themes demo, clicking the image will take you to our buy page.
 
 
 
== Screenshots ==

1. Relatify Setting Screen.
2. Templates 1
3. Templates 2
4. Templates 3
5. Templates 4
6. Templates 5
7. Templates 6
8. Templates 7



== Changelog ==

= 0.9.5 - 2015-03-21 =
* Redesign themeing engine
* Pro design shape up
* All existing bug fixed.

= 0.9.4 - 2015-03-13 =
* {Internal] Bug fix.

= 0.9.3 - 2015-03-06 =
* Ability to exclude Tags & Category
* Better Option Page design
* Minor bug fix
* Templates Update.

= 0.9.2 - 2015-03-05 =
* Dynamic Image size
* Templates Update
* Featured Image size bug fix
* Code cleanup, minor fix.

= 0.9.1 - 2015-02-27 =
* Resolved Ticket# [1](https://wordpress.org/support/topic/theme-1-not-show-preview)
* Bug fixed in theme #6 & #7.
* Widget bug fixed.

= 0.9.0 - 2015-02-25 =
* Initial submission


== Upgrade Notice ==

= 0.9.5 =
* Must update. More control on tags & categiry, major update, bug fix. 


== Donation ==

You may buy the premium templates to support the development.

http://relatify.co/go/free