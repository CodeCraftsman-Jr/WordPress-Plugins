﻿=== DL Yandex Metrika ===
Contributors: dyadyalesha
Plugin URI: http://vcad.dd-l.name/wp-plugins/
Tags: dl, yandex, metrika, yandex metrika, seo
Requires at least: 3.2
Tested up to: 4.3
Stable tag: 0.3.6.2

Яндекс.Метрика для вашей консоли WordPress

== Description ==

Данный плагин позволит вам легко просматривать статистику яндекс метрики прямо в консоли вашего сайта

Яндекс.метрика - это сервис веб-аналитики для оценки эффективности сайтов. Он позволяет анализировать: конверсию и выручку сайта, эффективность рекламы (яндекс.директ, яндекс.маркет и т. д.), аудиторию сайта и поведение посетителей, источники, привлекающие посетителей. Все инструменты яндекс.метрики бесплатны.

Плагин официально добавлен на страницу API Yandex Metrika в раздел "Плагины для CMS" [https://tech.yandex.ru/metrika/](https://tech.yandex.ru/metrika/)

Если вы хотите помочь в разработке этого плагина - добро пожаловать на [github](https://github.com/dyadyal/dl-yandex-metrika)

== Installation ==

1. Распакуйте архив с плагином
2. Загрузите папку с плагином в директорию /wp-content/plugins/ на вашем сервере
3. Активируйте плагин в разделе плагины в панели администрирования WordPress

== Screenshots ==

1. Виджеты в консоли

2. Страница "Посещаемость"

3. Страница "География"

4. Страница "Демография"

== Changelog ==
= 0.3.6.2 =
* bug fixes

= 0.3.6.1 =
* bug fixes

= 0.3.6 =
* add admin bar menu

= 0.3.5 =
* a more easy registration

= 0.3.4 =
* add page mobile

= 0.3.3 =
* add page os

= 0.3.2 =
* add page traffic_load

= 0.3.1 =
* add dashboard widgets demography

= 0.3 =
* add filter
* bug fixes

= 0.2.3 =
* add page inpage
* bug fixes

= 0.2.2 =
* add dashboard widgets traffic
* add dashboard widgets geo

= 0.2.1 =
* add page demography

= 0.2 =
* add page geo

= 0.1.1 =
* add page traffic

= 0.1 =
* start project