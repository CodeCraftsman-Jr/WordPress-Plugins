=== AE Visitor ===

Contributors: Adi Wicaksana
Donate link: http://www.aldo-expert.com
Tags: visitor, counter, web visit, web counter, simple counter
Requires at least: 3.5
Tested up to: 4.2.3
Stable tag: 1.8

very simple visitor plugins enables you to track number of visitors online in an easy to install.  

== Description ==

AE Visitor is display number of visitor or guest on your WordPress website and blog in day, yesterday, week, month, and all. very simple AE Visitor plugins enables you to track number of visitors online in an easy to install as a widgets.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `ae-visitor.zip` to the `/wp-content/plugins/` directory. You can do this using 'Upload' functionality provided in plugins section of your wordpress dashboard
2. Activate the plugin through the `Plugins` menu in WordPress
3. Go to `Appearance` >> `Widgets` and drag `AE Visitor` in to your widget area.
4. Save
5. You are done. 

== Screenshots ==

1. Display Example

== Frequently Asked Questions ==

== Changelog ==

= 1.8 =

support for WP 4.2.3
fix activation plugin

= 1.7 =

fix some bug

= 1.6 =

fix some bug

= 1.5 =

fix AE Menu icon
fix image broken link

= 1.4 =

fix some bug
fix AE Menu

= 1.3 =

fix AE Menu

= 1.2 =

fix AE Menu
fix Un-Install

= 1.1 =

Plug-in is now compatible upto wordpress version 3.4.x

= 1.0 =

fix title widgets
fix cookie

== Credits ==

[Adi Wicaksana P.](http://www.aldo-expert.com/) - This plugin was created by Adi Wicaksana. If you like this widget and would like to donate to help support new versions of this widget you can do so at the <a href="http://www.aldo-expert.com">support center</a> website.

== Contact ==

If you need help, support or would just like to provide your comments and suggestions you may visit us online at <a href="http://www.aldo-expert.com">my personal website</a>.

