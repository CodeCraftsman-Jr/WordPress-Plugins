=== Veb Traffic ===
Contributors: vebtraffic
Donate link: http://vebtraffic.com/
Tags: traffic sharing, peer 2 peer, p2p traffic, share traffic, exchange traffic, traffic exchange
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 2.2.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Peer 2 Peer traffic sharing internet service.
Vebtraffic.com is rebuilding the way businesses think of traffic for their website.

== Description ==

Have you ever been frustrated with spending a lot of money buying traffic for your website. Veb Traffic is focused on p2p traffic source which makes it easy for you to integrate our plugin to your website and use Google Chrome or Firefox plugin extension to help you earn free traffic.

How does it work? Simple, you download Veb Traffic Wordpress plugin ( Then open the Surfer link provided on your WordPress plugin. Simply view other peoples websites and earn credit and others will see your website and products and services you have to offer.  The process is simple, Free and comes with full support.  All traffic source can be tracked via Google Analytics for your website.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Click Settings and signup for a new API user and key

== Frequently Asked Questions ==

= Is it free? =

Yes, to sign up and generate credits is FREE. The more credits you generate, the more traffic you get

= Can I sell my credits that I earned? =

Yes, in order to sell your credits, you need to find a buyer and setup a purchase link from your VebTraffic Dashboard.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* Initial plugin set up and launch

== Upgrade Notice ==

== Arbitrary section ==

You may provide arbitrary sections, in the same format as the ones above.  This may be of use for extremely complicated
plugins where more information needs to be conveyed that doesn't fit into the categories of "description" or
"installation."  Arbitrary sections will be shown below the built-in sections outlined above.

== A brief Markdown Example ==


Here's a link to [WordPress](http://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
"Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`
