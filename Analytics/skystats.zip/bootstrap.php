<?php

/**
 * SkyStats bootstrapping.
 * 
 * @since 0.0.1
 *
 * @package SkyStats
 */

defined( 'ABSPATH' ) or exit();

/**
 * Load definitions.
 */
require_once dirname( __FILE__ ) . '/includes/defines.php';