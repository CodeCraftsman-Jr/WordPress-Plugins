=== WhatConverts ===
Contributors: WhatConverts
Tags: whatconverts, call tracking, analytics call tracking, goal tracking, form tracking, form metrics, form analytics, conversion optimization, CRO, adwords call tracking
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 1.0.2

Enables WhatConverts on all pages.

== Description ==

This plugin adds the required tracking code for WhatConverts.

For more information visit, [WhatConverts](https://www.whatconverts.com/).

== Installation ==

1. Upload 'whatconverts' directory to your plugins directory
2. Activate the plugin through the plugins menu in WordPress
3. Navigate to the plugin settings, 'Settings' > 'WhatConverts'
4. Add your Profile ID from [WhatConverts](https://www.whatconverts.com/)

== Screenshots ==

1. Modified settings panel with WhatConverts.
2. WhatConverts settings page.
