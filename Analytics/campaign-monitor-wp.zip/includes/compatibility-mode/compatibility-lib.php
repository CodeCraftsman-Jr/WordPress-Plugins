<?php

/*
 * this array provides name, plugin dir ,is_front_end, css of a conflicted plugin
 */
$compatibility_items = array (
                            
                        'MiniMax-Page-Layout-Builder' => array(
                                            'plugin_dir' => 'page-layout-builder/page-layout-builder.php' ,
                                            'is_front_end' => false ,
                                            'css' => '.fca_eoi_settings_layout_2 p {
                                                                                overflow: inherit;
                                                                                visibility: inherit;
                                                                                width: inherit;
                                                                                height: inherit;
                                                                                }'                                         
                                )
                 
                
                       );
