=== LeadElephant for Wordpress ===
Contributors: leadelephant
Tags: leadelephant, tracking, code, leads, companies
Requires at least: 3.6
Tested up to: 4.1.1
Stable tag: 1.0.0

Plugin for integrating LeadElephant into your website.


== Description ==

Plugin for integrating LeadElephant into your website.

For more information: [LeadElephant.com](http://www.leadelephant.com/?utm_source=wordpress&utm_medium=link&utm_campaign=leadelephant-plugin-page "LeadElephant")

== Installation ==

1. Upload and extract `leadelephant.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the LeadElephant tracking code in Settings >> LeadElephant


== Changelog ==

= 1.0 =
* Initial release