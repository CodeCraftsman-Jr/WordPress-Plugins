All these files can be open with the free GIMP software :
http://www.gimp.org/
You can use it to add a version to the OS image