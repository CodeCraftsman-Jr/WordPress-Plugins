=== Advanced Google Universal Analytics ===
Contributors: stefanoai
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=stefanoai%40stefanoai%2ecom&lc=IS&item_name=StefanoAI&no_note=0&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: advanced google universal analytics, wordpress universal analytics, wordpress google universal analytics, google universal analytics, google analytics, analytics, no track people, no track role
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 0.5
License: GPLv2 or later

Enter the tracking code for google analytics universal, in your wordpress site by simply putting your ID in the settings. 
You can also choose which role or user not will be tracked, and also if you want to track WP-Admin Panel.

== Description ==

Enter the tracking code for google analytics universal, in your wordpress site by simply putting your ID in the settings. 
You can also choose which role or user not will be tracked, and also if you want to track WP-Admin Panel.

== Installation ==

Upload the Advanced Google Universal Analytics plugin to your blog, Activate it, put your tracking code.

You're done!

== Frequently Asked Questions ==



Thank you.

= I can make a donation to help keep the software up to date? =
Sure just press <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=stefanoai%40stefanoai%2ecom&lc=IS&item_name=StefanoAI&no_note=0&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest">here</a>

Thank you so much.


== Screenshots ==

1. The Options page.

== Changelog ==

= 0.5 =
* added tracking for wp-admin panel (included wp-login page)

= 0.4 =
* auto domain if empty field

= 0.3 =
* fixed warning print

= 0.2 =
* fixed little bug on tracking code

= 0.1 =
* Welcome