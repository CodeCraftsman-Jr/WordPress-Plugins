=== Video Analytics ===

Contributors: mmcachran
Tags: youtube, video, google analytics
Requires at least: 3.8
Tested up to: 4.1
Stable tag: trunk

Embed multiple videos and track usage/playback via Google Analytics

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

== Usage ==

After activation, you will have a YouTube button in your TinyMCE toolbar to embed videos and these videos will use the JS API to track playback.

== Changelog ==

= 0.5.0 =
* Text domain fix

= 0.4.0 =
* Code cleanup and restructuring

= 0.3.0 =
* Initialize _gaq inside JS init

= 0.2.0 =
* cleanup