=== trendcounter Stats for WordPress ===
Contributors: trendcounter
Tags: trendcounter, stats, analytics, statistics, visitors, counter
Requires at least: 3.1
Tested up to: 4.1
Stable tag: 0.4

See in real-time what is happening on your blog with trendcounter


== Description ==

This is the official trendcounter Plugin for WordPress. It adds trendcounter either as Widget, or as Footer element to your blog.
If you're interested in seeing what trendcounter has to offer, try out our [Demo](http://www.trendcounter.com/report/demo/)

 
== Installation ==

The installation is a simple straight forward process. You'll need a trendcounter account for this plugin. If you don't have one, go to http://www.trendcounter.com and signup for a new account.

1. Install the plugin via the WordPress Plugin Directory (or via download)
1. Go to the Plugin menu an activate this plugin
1. Login to your trendcounter account and go to the "Project HTML" settings. 
1. Click "trendcounter Options" in the "Plugins" menu, and paste your trendcounter "Project Settings" into the displayed field
1. Choose between "Footer" and "Widget" mode
1. Press save


== Frequently Asked Questions ==

= Where can I signup for trendcounter? =
Get your free account at http://www.trendcounter.com

= Can I insert more than one trendcounter Widget at once? =
No, never do that! Your visitors would be tracked multiple times.


== Screenshots ==

1. Administration interface
2. Integration example
3. Example real-time dashboard


== Changelog ==

= 0.1 =
Initial release

= 0.2 =
Minor changes and readme updates

= 0.3 =
Minor changes

= 0.4 =
Integration of the new trendcounter.js API

== Upgrade Notice ==

