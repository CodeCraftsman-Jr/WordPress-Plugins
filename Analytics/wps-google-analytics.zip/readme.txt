=== WPS Google Analytics ===
Contributors: vinoj.cardoza
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=vinoj%2ecardoza%40gmail%2ecom&currency_code=GBP&lc=US&bn=PP%2dDonationsBF&charset=UTF%2d8
Tags: google, analytics, google analytics, analysis
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: trunk
License: GPLv2 or later

WPS Google Analytics allows you to easilly add your Google Analytics code through out the whole site.

== Description ==

WPS Google Analytics allows you to easilly add your Google Analytics code through out the whole site. Just add your ID, choose if you are on a sub-domain (setting in Google Analytics), and enter the domain.

WPS Google Analytics will not track admin users logged-in.

If you have any question, you can find the plugin page here : http://www.vinojcardoza.com/blog/wps-google-analytics

= Donations =

Thanks for downloading and installing my plugin. You can show your appreciation and support for future development by contributing a small donation.

= Translation =
Translation is enabled for this plugin. If someone interested in translating this plugin please visit the following link and post in the comments section with your contact email. Thanks.

http://www.vinojcardoza.com/blog/wps-google-analytics

= Translated languages =

* French

== Installation ==

1. Download the plugin.
2. Upload to your blog (/wp-content/plugins/).
3. Activate it.
4. Click the Google Analytics menu.
5. Fill in the options.

You're done!

Uninstalling is as simple as deactivating the plugin.

== Screenshots ==

1. screenshot-1.gif

== Change Log ==

= Version 1.1 =
* Tested compatibility with Wordpress 4.1.1.