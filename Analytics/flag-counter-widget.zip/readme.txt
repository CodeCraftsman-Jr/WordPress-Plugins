=== Counter - Flag Counter ===
Contributors: Holger Deschakovski
Tags: counter, website, blog, geo, geo location, widget, widgets, flag counter, besucherzähler, flaggen, geo ip
Requires at least: 2.0
Tested up to: 4.3

Display an Javascript based Flag Counter in an Widget.

== Description ==

Display an Javascript based Flag Counter inside an Widget.
Adjustable Javascript Code.
Up to 500 of your last Visitors with their City and Country, 
visited Page and referring Page.
Alternatively, display the Countries with Visitors Numbers.
More Information at http://www.flags.es

If you like the Flag Counter please rate it at https://wordpress.org/plugins/flag-counter-widget/
Thank you :)

== Installation ==

1. Upload to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in Network Admin
3. Put the Widget into your Template at Admin Menu -> Appearance -> Widgets

