<?php
/**
* this form for view widget
* show link to setting form
*/

?>
<br />

    <a href="<?php echo admin_url( 'admin.php?page=stats_counter&settings' ) ;?>">Counter Settings</a><br /><br />
   
    