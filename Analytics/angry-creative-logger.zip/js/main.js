
jQuery( document ).ready( function() {

	// Scroll log to bottom
	var objDiv = jQuery("#aci-settings-wrap .latest > ul");
	objDiv.scrollTop( objDiv[0].scrollHeight );

});

