=== Mind Reader ===
Contributors: DeepAman
Tags: mind,reader,scanner,mind reader,brain scanner,game,wordpress game,
Requires at least: 2.8
Tested up to: 3.4.1
Stable tag: 1.0.1

Brain test, what you think at movement,just fun with creative   .



== Description ==
This plugin is just like a trick game, for find out symbol that is remember in your mind
How to play this game 
# Think of a number with 2 digits (ex: 63)
# Subtract from this number its 2 digits (63 - 6 -3 = 54 )
# Find the symbol that corresponds to this number
# Concentrate on the symbol and click on the blank square...
# your remember symbol will here.





== Installation ==

1. Upload the `mindreader` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu
3. Navigate to 'mind machine' menu from admin panel 
4. put short code [min_reader_machine] on page where you want display your game
== uninstall ==

Simply delete the old `mindreader` folder, and remove the shortcode [min_reader_machine]  line from your page file.

== Screenshots ==

1. This screenshot-1.png shows table of the code and signs that is choosed by player. 
