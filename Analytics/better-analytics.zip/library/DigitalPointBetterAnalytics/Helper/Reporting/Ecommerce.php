<?php

abstract class DigitalPointBetterAnalytics_Helper_Reporting_Ecommerce extends DigitalPointBetterAnalytics_Helper_Reporting_Abstract
{

}