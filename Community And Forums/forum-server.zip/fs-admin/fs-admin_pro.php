<?php
/*
 * This file contains code specific for PRO version of the plugin.
 * If the file is empty, you are using a free version.
 *
 */
class  vasthtmladmin_pro{
	
	function show_forum_seo_urls($op = false) {
		return '';
	}
}
?>
