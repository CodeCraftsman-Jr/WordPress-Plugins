<?php

get_header();

?>

<div id="primary">
	<div id="content" role="main">
		<!-- Integrator_Marker -->
		<!-- Integrator_Tag -->
		<!-- Integrator_Marker -->
	</div>
</div>

<?php
get_footer();
?>