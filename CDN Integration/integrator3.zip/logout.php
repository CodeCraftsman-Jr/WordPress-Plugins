<?php

$path	=	dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR;
require_once( $path . 'logout.php' );

?>