function reset_emotion() {
	document.getElementById('gmo_tinymce_emotion').value = document.tinymcesmiley.default_emotion.value;
}