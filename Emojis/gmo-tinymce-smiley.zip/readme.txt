=== Plugin Name ===

Plugin Name: GMO TinyMCE Smiley
Plugin URI: 
Author: GMO WP Cloud
Author URI: https://www.wpcloud.jp/en/
Contributors: Takeaki Nagashima
Donation Link: 
Tags: Widget,TinyMCE,kaomoji,emoticons
Requires at least: 3.8
Tested up to: 4.1.1 
Stable tag: Version 1.1 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

GMO TinyMCE Smiley is a plugin to let you instantly add smilies into your site from the toolbar. 


== Installation ==

Search and download plugin from either WordPress admin page or http://wordpress.org/plugins.  
From the WordPress admin page, simply activate the plugin, or upload a file from "Add New" to install and activate plug-in.  

Time required for installation: Approximately 15 seconds. 

== Frequently Asked Questions ==

Why you created this plugin? 
-It was an idea popped up during our team discussion we had on Friday.  We all thought it was a terrific idea at first, but all ended up wondering why we came up with this plugin after the weekend. 
    

== Changelog == 
= 1.1 =
* Updated Author Profile

= 1.0 =
* Initial Release

== Upgrade Notice ==

== Screenshots ==

1. button image

