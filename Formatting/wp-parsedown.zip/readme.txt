=== WP-Parsedown ===
Contributors: cadeyrn
Donate link:
Tags: markdown, editor, parsedown
Requires at least: 3.0
Tested up to: 4.2.1
Stable tag: 0.4
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Parse content output with [Parsedown Extra](http://www.parsedown.org/)

== Description ==

Parse the_content with [Parsedown Extra](http://www.parsedown.org/demo?extra=1) to display [Markdown Extra](https://en.wikipedia.org/wiki/Markdown_Extra) content in HTML parser.


== Installation ==

1. Upload contents of `wp-parsedown.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the `Plugins` menu in WordPress ( site or Network wide )

== Changelog ==

= 0.3 =
*2015-05-05*

* updating Parsedown and Parsedown Extra libraries
* removing wp-common dependancy
* changing debug log method

= 0.2 =
*2014-09-23*

* added removal of wpautop filters; they are not needed when Parsedown is doing it's job
* updated parsedown libs

= 0.1.1 =
*2014-09-06*

* fixing breaking [embed] elements by reodering this plugin

= 0.1 =
*2014-07-22*

Initial release
