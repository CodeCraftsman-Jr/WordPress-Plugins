an <b>important</b> <a href=''>link</a>

broken<br/>
line

<b>inline tag</b> at the beginning

<span>http://example.com</span>