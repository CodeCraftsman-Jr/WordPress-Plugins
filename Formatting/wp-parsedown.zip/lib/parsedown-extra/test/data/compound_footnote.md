footnote [^1] and another one [^2]

[^1]: line 1
      line 2

    > quote

    another paragraph
      
[^2]:
    paragraph
    
    another paragraph
    