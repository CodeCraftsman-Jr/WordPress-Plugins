=== Halloween quotes ===
Contributors: GigaCart
Donate link: 
Tags: quotes, quotations, jokes, random, widget, sidebar, random jokes, randomness, halloween, animation
Requires at least: 2.9
Tested up to: 3.0.1
Stable tag: 1.0.0

Scare your blog visitors with special Halloween effects that appear unexpectedly at specified time intervals.  There are many different types of animations such as a laughing witch, a running black cat and many more that will be displayed randomly. The widget also displays a random Halloween joke on each page.

== Description ==

Scare your blog visitors with special Halloween effects that appear unexpectedly at specified time intervals.  There are many different types of animations such as a laughing witch, a running black cat and many more that will be displayed randomly. The widget also displays a random Halloween joke on each page.

The main features:

* Add as many **widgets** as you need.
* Enable / disable halloween animation. At least one widget is required on the site to display the animations.
* Modify time period between animations. Minimum time period is 15 seconds.

== Installation ==

1. Upload the content of halloween-quotes.zip to a dedicated folder in your `/wp-content/plugins/` directory.
2. Activate the plugin on the 'Plugins' page in WordPress.
3. Modify animation settings on "Halloween" menu.
