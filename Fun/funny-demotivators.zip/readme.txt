=== Demotivational Post ===

Contributors: Demotivational Post
Description: Demotivational Post widget add to your website new page with  big collection of Demotivational Posters . All pictures hosting in http://demotivationalpost.com so you don't pay for transfer. If user click some picture he open new tab with source of picture. All pictures are checked by moderator and  will be grabbed from home page  http://demotivationalpost.com , you can see how working this widget in my  sample blog http://funmot.com/english/Demotivational-posters/ . If plugin not work try to disable recent posts or use another theme. 
Tags: widget, pictures , theme, funny , demotivators, motivational posters , gallery , plugin , image , page , site , humor , links , post, cartoons , Demotivational Post, demotivational posters , demotivationalpost.com , demotivational post , meme
Version: 1.3 
Tested up to: 3.2.1
Author: Darek Rycyk
Author URI: http://demotivationalpost.com/info/contact.php
Plugin URI: Plugin URI: http://demotivationalpost.com/trunk/
Adds: Big collection of Demotivational Posters.
License: GPL2

== Description ==

Demotivational Post widget add to your website new page with  big collection of Demotivational Posters . All pictures hosting in http://demotivationalpost.com so you don't pay for transfer. If user click some picture he open new tab with source of picture. All pictures are checked by moderator and  will be grabbed from home page  http://demotivationalpost.com , you can see how working this widget in my  sample blog http://funmot.com/english/Demotivational-posters/
If plugin not work try to disable recent posts or use another theme.


== Installation ==

Plugin have only one  file


Here it is in graphic form:


- wp-content
	- plugins
		- widgets
			| demotivational_post.php
	
You install Demotivational Post plugin in admin panel like other plugins. Plugin add one page to your site so don't change title and name this new page because plugin generate new page with title "demotivators".

 If you want to remove plugin first disable plugin in admin panel and later remove new page with title "demotivators"