<?php
/*
Plugin Name: Futurama Quotes
Plugin URI: http://0xff.akop.org/
Description: Writes a random quote from TV's best show, Futurama.
Author: Akop Karapetyan
Version: 1.0
Author URI: http://www.akop.org
*/ 

$quotes = <<< end
Fry: [voiceover] Space... It seems to go on and on forever... But then you get to the end and a gorilla starts throwing barrels at you.
Fry: Before, she was demanding and possessive. But now she wants me to do stuff and stay with her all the time.
John Jackson: ... and I say your three-cent titanium doesn't go too far enough!
Leela: Don't let their identical DNA fool you. They differ on some key issues.
Mayor Poopenmeyer: The man who single-handedly defeated the Retiree people of the Assisted Living Nebula, Zapp Brannigan.
Zapp Brannigan: We'll simply set a new course, for that empty region over there - near that blackish, holish thing.
Bender: These balls are making me testy!
Bender: That's no flying saucer. That's my ass!
Bender: I'm experiencing a powerful yearning to cram my gullet full of mackerel heads.
Mrs. Wong: You should marry him. Or at least use him to conceive a grandchild for us.
Zapp Brannigan: ... I must warn you, if you so much as glance at another woman, I'll be all over Leela like a fly on a pile of very seductive manure.
Fry: I learned how to handle delicate social situations from a little show called "Three's Company."
Bender: Humans are no threat to us. They're stupid, putrid cowards.
Emotitron Jr.'s Mom: What did I tell you? No. more. hanging. wires!
Bender: Now, if you excuse me... I have a buttocks to tattoo!
Femputer: That does not fempute!
Calculon: Great Shatner's ghost!
Bender: I got a hundred bucks on Rectal Exam Bot!
Professor Farnsworth: I'll be the judge of who's cool, using the coolometer!
Professor Farnsworth: Good Lord! I'm getting a reading of over 40 mega-Fonzies.
Fry: That could be my beautiful soul sitting naked on her couch if I could just learn to play this stupid thing.
Dr. Zoidberg: A complete sandwich? You got fleeced! I would have settled for a hard roll with ketchup inside!
Professor Farnsworth: Correct. Six thousand hulls!
Sentinel Bot: Which of the following would you prefer: a) a puppy, b) a pretty flower from your sweetie, or c) a large, properly-formatted data file?
Dr. Zoidberg: "Dog food," you say?
Leela: Me? Award? Him? Me? Good?
Fry: Believe it or not, I have more important things to do today than laugh and clap my hands... Reschedule.
Fry: We might not be a traditional family like the Murphys next door or the lesbian coven across the street, but we are a family.
Mom: Don't let the door hit you on the way out... 'Cause I don't want ass-prints on my new door!
Professor Farnsworth: I'll ruin you like I ruined this company!
Calculon: Get your stinkin' trike off me, you damn dirty ape!
That Guy: My only regret.. is that I have... boneitis!
Fry: This company's on the fast track to the "It" list. Blast back kudos all around!
That Guy: Delivery has nothing to do with the delivery business. Image, people, image!
Thermostadt Robot: With all your modern science, are you any closer to understanding the mysteries of how a robot walks, or talks?
Bender: Your kid is great. How hard did you say you had to hit him? 
Sal: Let me introduce you to your scab coworkers you'll be scabbin' with.
Calculon: Ordinarily, to see acting like that you'd have to sit through a tampon commercial.
Bender: You're screwier than my aunt Rita. And she's a screw!
Professor Farnsworth: WERNSTROM...!
Bender: The light... It's blinding! And the ass pain... It's searing!
Michelle: Fry, why must you analyze everything with your relentless logic?
Bender: So, what'll it be? My place? Or you?
Calculon: Son of a bit!
Rusty: Say, Wendy. Your chassis is a little scuffed. Mind if I polish it for you?
Yivo: ...at first I wished only to bang out a cheap one with your universe. But it's your own fault. Your universe dresses provocatively.
Crushinator: Thank you, Bob Barker. I'm as happy as a girl can be. End statement.
Monique: Oh Calculon, I'm afraid you have a fourth personality the other three don't know about... And it and I... are lovers!
Roberto: Ah, that first time was just to case the joint and rob it a little.
Bender: Humans like cabbage, right?
Roberto: I'm gonna kill you, you fifty-sixin'...
Fry: I don't like this place. It's 120 degrees and there's very little oxygen.
Flexo: That's "Flexo outranks me, sir"!
Bender: Save it for the cross-burning, Adolf!
Professor Farnsworth: Please, Fry, I don't know how to teach - I'm a professor!
Fry: The mathematics of wonton burrito meals...
Leela: Bender, why are you spending so much time in the bathroom? Are you jacking on in there?
Bender: I don't recall ever fighting Godzilla, but that is SO what I would've done!
Fry: It's all there, in the macaroni.
Hermes: I'll just have a Shirley Hemple.
Multiple Personality Lincoln Bot: I was born in 200 log cabins.
Hyperchicken: I may be a simple country hyperchicken, but I know when we're finger-licked.
Bender: Leela is experiencing the greatest joy a woman can have. Worshipping some low-life jerk.
Bender: I'm Bender. You know, the lovable rascal.
Leela: This is Officer 1BDI, requesting backup.
Don Bot: As the duly elected mobsters of this union, it is our duty to support the struggle of these proud lazy slobs.
Linda: We seem to be experiencing technical difficulties... And crap like I've never seen!
Fry: That's a chick show. I prefer programs of the genre: "World's Blankiest Blank."
Professor Farnsworth: You take one nap in a ditch in the park and they start declaring you this and that!
Professor Farnsworth: Line up for your pre-flight coffee enemas!
Dr. Zoidberg: If there's a delicious cake, isn't it better to have one sliced, than none at all? Even if four other guys eat the other four slices, and all thrusting their sweaty naked bodies at the cake?
Bender: Being a robot is great, but we don't have emotions, and sometimes that makes me very sad.
Bender: Fine, I'll go build my own lunar lander! With blackjack! And hookers! In fact, forget the lunar lander and the blackjack!
Fry: Help! I can't swim in jelly, as far as I know!
Leela: Yo, homes, we need a microwave.
Planet Express Ship: Bender was just helping me zip up my turbine.
Adlai: I've never been good with words, which is why I'm in such a delicate conundrum.
Farnsworth: Your net-suits will let you experience Fry's worm-infested bowels as if you were actually wriggling through them!
Bender: Float like a floatbox, sting like an automatic stingin' machine.
Bender: Are you familiar with the old robot saying "does not compute"?
Bender: Care to contribute to the Anti-Mugging-You fund?
Fry: Go gather your nuts, you nagging grasshopper!
Bender: OK, but I don't want anyone thinking we're robosexuals, so if anyone asks - you're my debugger.
Bender: An upgrade? I thought we all agreed I was perfect.
Fry: The less fortunate get all the breaks!
Morbo: Kittens give Morbo gas.
Bender: Your best is an idiot!
Scruffy: Wow. I've never seen him so sad. Or ever before.
Bender: With my mighty robot powers, I can get sick of things much quicker than you humans.
Bender: Call me old fashioned, but I like a dump to be as memorable as it is devastating.
Professor Farnsworth: Did everything just jump around, or did my brain just stroke off there for a second?
Roberto: I've seen lines move faster in a sperm bank.
Fry: It's hot! The butter in my pocket is melting!
Bender: Do a flip!
LaBarbara: Husband, can't you go anywhere without lighting something up?
Professor Farnsworth: While you were gone, the 'trotters held a news conference to announce that I was a "jive sucka."
Bender: I'm so embarrassed. I wish everybody else was dead.
Bender: Bender's a genius!
Bender: This is awkward... Introducing your new girlfriend to Chesty McNagnag.
Zapp Brannigan: I like your style, Fry - you remind me of a young me. Not much younger, mind you, perhaps even a couple of years older.
Bender: Good point, Bender!
Zapp Brannigan: I don't pretend to understand Brannigan's Law. I merely enforce it.
Robot Devil: You're not nice!
Fry: Prepare to be thought at!
Bender: The only reason you get all the guys is because you dress like a tramp.
Leela: This is, by a wide margin, the least likely thing that has ever happened.
Bender: The laws of science be a harsh mistress.
Fry: Existing is basically all I do!
Bender: I only know enough binary to ask where the bathroom is.
Fry: Sweet justice! Sweet, juicy justice!
Dr. Zoidberg: I help those who help themselves!
Fry: Hardy Boys... too easy. Nancy Drew... too hard!
Bender: I'm a fraud. A poor, lazy, sexy fraud.
Fry: It's a widely-believed fact!
Bender: I hate the people who love me, and they hate me.
Fry: Why am I sticky and naked? Did I miss something fun?
Bender: Oh, so, just 'cause a robot wants to kill humans that makes him a "radical"?
Fry: I'm never gonna get used to the thirty-first century. Caffeinated bacon? Baconated grapefruit? Admiral Crunch?
Fry: I'm gonna be a science fiction hero, just like Uhura, or Captain Janeway, or Xena!
Bender: You can't count on God for jack! He pretty much told me so himself.
Bender: Lick my frozen metal ass!
Fry: Apartment 1I. The old me would've made a joke about that.
Bender: Bite my red-hot glowing ass!
Bender: Bite my colossal metal ass!
Professor Farnsworth: Ah, to be young again... and also a robot.
Bender: I'm one of those lazy, homeless bums I've been hearing about.
Fry: I'm literally angry with rage!
Alternate Farnsworth: Getting the brain out was the easy part. The hard part was getting the brain out.
Bender: But... those girls don't wear cases! You can see their bare circuits!
Fry: Where's Captain Bender? Off catastrophizing some other planet?
Fry: I haven't had time off since I was twenty-one through twenty-four.
Bender: Fathero!
Fry: I refuse to testify on the grounds that my organs will be chopped up into a patty.
Bender: Wait! My cheating unit malfunctioned! You gotta give me a do-over!
Dr. Zoidberg: They're all like, "Stop spraying me with ink, Zoidberg". "Put on pants, Zoidberg." "Don't touch our fancy box, Zoidberg."
Dr. Zoidberg: Surrender your mysteries to Zoidberg! 
Dr. Zoidberg: Someday they'll watch, from down in the gutter they will, as King Zoidberg caresses their fancy box!
Dr. Zoidberg: I saw a frilly cake in here you'd remember all your life! I know I will. [caresses picture] Late at night it haunts me with its frosted beauty. ORDER THE CAKE, DAMMIT!
Dr. Zoidberg: If you wanna sleep in the tent tonight, you're welcome to join me and Hermes for a little "just friends" spooning.
Robot Devil: Give me back my hands! These things are always touching me in places...
Fry: Stop being such a baby and chop my hands off!
Roberto: Parole officer says I gotta upgrade or he won't gimme back my stabbin' knife!
Roberto: Now stand back, I gotta practice my stabbin'.
Roberto: Later, blood.
Hermes: Jamaicans have other interests! Which is why the limbo team got detained at the airport.
Bender: Maybe you can interface with my ass! By biting it!
Free Waterfall Senior: If rubbing frozen dirt in your crotch is wrong, hey, I don't wanna be right.
Zapp Brannigan: She's built like a steakhouse, but she handles like a bistro!
Zapp Brannigan: You win again, gravity!
Roberto: Gimme the remaining dough. And all the calendars. And that pen! Try to tear it so most of the beads are on my end!
Dr. Zoidberg: Scalpel! .... Blood-bucket! ... Priest! Next patient!
Fry: Leela, there's something I've wanted to tell you for a long time, but every time I try, I get nervous and my mouth feels it's stuffed with peanut butter, even when it's not.
Fry: I refuse to testify on the grounds that my organs will be chopped up into a patty.
Bender: I know you're just a carbon-based life form, but I'll always think of you as a big pile of titanium.
Free Waterfall Senior: Let's conservate!
Leela: Well, it's a Type M planet. So it should at least have roddenberries.
Fry: It's like a party in my mouth and everyone is throwing up.
Bender: Someone's acting awfully aluminum.
Leela: I haven't been so happy since double-soup Tuesday at the orphanarium!
Fry: When I'm with you, every day is a double-soup Tuesday.
Zapp Brannigan: Sham-paggan?
Mom: Jerkwad robots make me sick to my ass!
Professor Farnsworth: Unless this is a nude love-in... get the hell off my property!
Fry: Amy, you know how at first you like chocolate, but then you start to get tired of it because it always wants to hang out with you?
Bender: Shooting DNA at each other to make babies... I find it offensive!
Bender: Congratulations Fry, you snagged a perfect girlfriend. Amy is rich, she's probably got other characteristics...
Fry: ... I just made out with that radiator woman from the radiator planet.
Fry: Hey, my girlfriend had one of those! Actually, it wasn't hers, it was her dad's. Actually, she wasn't my girlfriend. She just lived next door and never closed her curtains.
Bender: You, sir, have defaced a national treasure. I demand you restore my buttocks to their former glory!
Fry: Look, could chocolate just let me finish?
Bender: Tempers are wearing thin. Let's just hope some robot doesn't kill everybody.
Fry: No I'm.. doesn't!
Richard Nixon's Head: I remember my body. Flabby, pasty skin, riddled with phlebitis - a good Republican body. God, I loved it.
Richard Nixon's Head: Now beat it, before I get Cambodian on your asses!
Fry: Why couldn't she be the other kind of mermaid? With the fish part on top and the lady part on the bottom!
Zoidberg: I don't like the looks of this doctor. I bet I've lost more patients than he's even treated!
Gunther: All I want out of life is to be a monkey of moderate intelligence who wears a suit. That's why I've decided to transfer to business school!
Richard Nixon's Head: Prepare to evacuate Earth.. I mean.. New Scamedonia.
William Shatner: We're just pawns in his diabolical game of checkers!
Richard Nixon's Head: Computers may be twice as fast as they were in 1973 but your average voter is as drunk and stupid as ever. The only one who's changed is me. I've become bitter, and let's face it, crazy over the years. And once I'm swept into office, I'll sell our children's organs to zoos for meat. And I'll go into people's houses at night and wreck up the place!
Inuitbot: Yes, it's true. I ran over that bird-watching jerk and a hundred others. Even my best friend from aromatherapy school.
Calculon: Oh, fate most cruel, would that my boundless acting skills would avail me a sword with which to slay this wretched curse.
Bender: Give us a name, MacButt!
Bender: Let's kick him some more.
Fry: I never told anybody this, but a thousand years ago I used to look up at the moon and dream about being an astronaut. I just didn't have the grades, nor the physical endurance. Plus I threw up a lot and nobody liked spending a week with me.
Professor Farnsworth: Now, now. Perfectly symmetrical violence never solved anything.
Alternate Farnsworth: Oh, you'd like us to believe that wouldn't you, Leela? Or should I say "Evila"?
Dr. Zoidberg: I ate garbage yesterday, and it didn't cost me three hundred dollars!
Bender: Friends, I've come to free you from your complicated lives� Free you from the complicated part, I mean, not the lives part.
Wernstrom: We laughed until our teeth fell out.
Leela: You see that giant quasar you're headed into? You might want to scooch a few parsecs to the left.
Bender: You may have to "metaphorically" make a deal with the "devil." And by "devil," I mean Robot Devil. And by "metaphorically," I mean get your coat.
Wernstrom: Pencils down, prune-face.
Zapp Brannigan: Search them for paper! And bring me a rock.
Sal: We're all scared, it's the human condition. Why do you thinks I put on this tough-guy facade?
Sal: He's busteds, let's gets hims outta heres.
Zapp Brannigan: Soo beautiful... Yet so neutral.
Robot Devil: You can't just have your characters announce how they feel. That makes me feel angry!
Bender: Robot porno theater? I was in that... general area last night.
Gypsy: My friend, you have nothing to worry about. Except a nightmarish life of unremitting horror!
Fry: Bender is supposed to murder his closest friend, which I thought was me. But he went straight for you. He didn't even try to second-degree murder me.
Lrrr: One of these days Ndnd... Bang! Zoom! Straight to the third moon of Omicron Persei 8!
Announcer: It is my pleasure to introduce the host of the Kyoto Global Warming Conventions, the Inventor of the Environment, and first Emperor of the Moon, Al Gore!
Attila the Hun: No shoot firestick in space canoe! Cause explosive decompression!
Bender: Fry, in order for me to "get busy" with maximum efficiency, I need a girl with a big 400-ton booty.
Dr. Zoidberg: The president is gagging on my gas bladder! What an honor!
Fry: That THAT Mr. President! Sir!
That Guy: Switzerland is small and neutral! We are more like Germany -- ambitious and misunderstood!
Bender: Oh cruel fate, to be thusly boned. Ask not for whom the bone bones... it bones for thee.
Bender: My life, and by extension everyone else's, is meaningless.
Bender: Somebody tried to run me over. And not with a normal hover-car. It crept along the ground on round, rubber feet, like a wolf!
Professor Farnsworth: Show us this "the wheel."
Solicitorbot: To my loyal butler, You There, for his decades of service, I leave a pittance, to be paid in 20 equal installments of one-twentieth of a pittance each.
Thermostadt Robot: I choose to believe what I was programmed to believe!
Fry: These new hands are great! I'm gonna break 'em in tonight.
That Guy: I'm proud to be the shepherd of this herd of sharks.
Bender: You people wonder why I'm still single? It's 'cause all the fine robot sisters are dating humans!
Roberto: I'm not crazy! Don't call me crazy! I'm just not user-friendly! 
Bender: Don't kill me yet! I'm starting to come down with Stockholm Syndrome� handsome!
Don Bot: That wad of scab money should be slushin' my funds and kicksin' my back. 
Bender: You call yourself divorced?! You're making a mockery of one of our most oldest institutions!
Zapp Brannigan: We need rest! The spirit is willing, but the flesh is spongy and bruised.
Mafia Supplicant: Please, Don Bot. Look into your hard drive, and open your mercy file!
Lrrr: We will raise your planet's temperature for one million degrees a day... for five days!
Calculon: I was all of history's great acting robots. Acting Unit 0.8; Thespomat; David Duchovny!
Hermes: You do a nice "hand job," Zoidberg.
Bender: Scarab Forearm Bird Bird Bird!
Hedonism Bot: I, too, have known unconventional love. Perhaps you, I, and Jambi could get together and compare notes eh?
Hedonism Bot: Let us cavort like the Greeks of old. You know the ones I mean...
Anglelyne: Hey, according to the Scab Handbook, that is extremely inappropriate banter.
Humorbot 5.0: Anecdote accepted. Snappy comeback not found.
Hermes: That's it, Barbados Slim. You've gone one toke over the line!
Scientist: Now that the garbage is in space, Doctor, perhaps you can help me with your sexual inhibitions?
Fry: Bender, if this is some kind of a scam, I don't get it. You already have my power of attorney.
Zapp Brannigan: The best way into a girl's bed is through her parents. Have sex with them, and you're in.
Bender: This is the worst kind of discrimination. The kind against me!
Bender: Stupid anti-pimping laws...
Mayor Poopenmeyer: You people aren't Santa! You're not even robots! How dare you lie in front of Jesus!?
Bender: Shut up baby, I know it.
Morbo: WINDMILLS DO NOT WORK THAT WAY!
Lrrr: This concept of "wuv" confuses and infuriates us!
Lrrr: Why does Ross, the largest "friend" not simply eat the other five?
Fry: All year long the grasshopper kept burying acorns for winter, while the octopus mooched off his girlfriend and watched TV. Then the winter came, and the grasshopper died, and the octopus ate all his acorns, and also he got a race car.
Mayor Poopenmeyer: I wanna make sure this isn't another scam, like global warming, or second-hand smoke.
Dr. Zoidberg: My mother was a saint! Get out!
Hyperchicken: Now, Pramela, I know it's scary in that thar witness box, but t'aint no need to fear me.... BuCawk! ... I'm sorry, I thought you was corn.
Fry: Oh the fools! If only they'd built it with six thousand and one hulls! When will they learn??
Glurmo: This concludes the part of the tour where you stay alive.
Zapp Brannigan: Kif, I'm feeling the Captain's Itch.
Amy Wong: You just have to give guys a chance. Sometimes you meet a guy and think he's a pig, but then later on you realize he actually has a really good body.
Barbados Slim: I see you're still able to limbo under the bar of fashion sense?
Bender: What an awful dream! Ones and zeros everywhere... and I think I saw a two.
Professor Farnsworth: You must take him to his ancient home world, which will soon erupt in an orgy of invertebrate sex.
Bender: There's nothing wrong with murder, so long as you let Bender wet his beak.
Bender: Blackmail is such an ugly word. I prefer "extortion." The "x" makes it sound cool.
Al Gore: If we don't go back there and make that event happen, the entire universe will be destroyed... And as an environmentalist, I'm against that.
Nichelle Nichols: Murder isn't working, and that's all we're good at.
Nichelle Nichols: An eternity with nerds. It's the Pasadena Star Trek Convention all over again.
Dr. Zoidberg: I want the tactile pleasure in cutting him here... [points to Fry's neck] in the gonads!
Bender: Hey, what kind of party is this? There's no booze and only one hooker.
Bender: Tubes? You're older than you said you were!
Dr. Zoidberg: I've performed a few mercy killings...
Dr. Zoidberg: You seem malnourished. Are you suffering from internal parasites?
Edna: Teach me to love, you squishy poet from beyond the stars.
Fry: I'm flattered, really. If I was gonna do it with a big freaky mud bug, you'd be way up the list.
Bender: Hey, Bender the Offender doesn't need you. Bender the Offender doesn't need anybody.
Billionaire Bot: You'll be the most unpopular robot fighter since Sergeant Feces Processor.
Fry: Man, I thought Ultimate Robot Fighting was real, like pro wrestling, but it turns out it's fixed, like boxing.
Bender: What do you mean "we", mammal?
Alternate Bender: Bite my glorious golden ass!
Calculon: I've seen plagues that had better opening nights than this!
Fry: *I* should be the one in that grave.
Bender: Grab a shovel. I'm one skull short of a Mouseketeer reunion.
Zapp Brannigan: Oh god, I've never been so happy to be beaten up by a woman.
Amazon: It time snu-snu!
Femputer Fembot: Do you know what it's like to be a fembot living in a manbot's manputer's world?
Bender: Stay away from our women! You've got metal fever, boy! Metal fever.
Leela: After all this time, somebody else with one eye... who isn't a clumsy carpenter, or a kid with a BB gun.
Zapp Brannigan: In the game of chess you can never let your adversary see your pieces.
Fry: Dear Horse god, I know I don't usually pray to you. Sometimes I doubt you even exist, but if you're willing to grant me luck... please... stamp your hoof once.
Professor Farnsworth: My internet browser heard us saying the word "Fry," and it found a movie about Philip J. Fry for us. It also opened my calendar to Friday and ordered me some french fries.
Star Trek Priest: ...and Scotty beamed them up to the Klingon ship, where they would be no Tribble at all...
Dr. Zoidberg: It's toe-tappingly tragic!
Bender: Okay, I'm done re-kaboobling the energymotron.. or whatever.
Leela: You can't go to Omega 3 -- it's forbidden. I forbid you!
Fry: Like a balloon, and.. something bad happens!
Melllvar's Mother: He's not a child. He's thirty-four!
Robot Santa: Your mistletoe is no match for my TOW missile!
William Shatner: When I directed Star Trek V, I got a good performance out of me, because I respected me so much!
Dr. Zoidberg: [voice-over] As the candy hearts poured into the fiery quasar a wondrous thing happened, why not. They vaporized into a mystical love radiation that spread across the universe destroying many, many planets, including two gangster planets and a cowboy world.
God: Bender, being God isn't easy. If you do too much, people get dependent on you. And if you do nothing, they lose hope. You have to use a light touch, like a safecracker, or a pickpocket.
Fry: I know Big Vinny said he was giving me the kiss of death, but I still think he was gay.
Dr. Zoidberg: Is desire to mate a feeling?
Dr. Zoidberg: Oh, it's all so complicated, with the flowers, and the romance, and the lies upon lies!
Wireframe Dummy 1: Is heaven missing an angel? 'Cause you've got nice cans!
Leela: Way to go, Fry. Now every galaxy is gonna be cracking wise about our mamas.
Hermes: I'm just glad my fat, ugly mama is not alive to see this...
Professor Farnsworth: Enough about your promiscuous mother, Hermes.
Bender: Take it off! Magnets screw up my inhibition unit.
Fry: I'm not a robot like you, I don't like having discs crammed into me... unless they're Oreos... and then only in the mouth.
Calculon: Have you got an extra GOTO 10 line?
Harold Zoid: People, people, please -- just because it's a dramatic scene, doesn't mean you can't do a little comedy in the background.
Ndnd: It is true what they say. Women are from Omicron Persei 7. Men are from Omicron Persei 9.
Leela: How would you feel if I flushed Fry down the toilet?
Hermes: Today's mission is to go to the Brain Slug planet.
Reverend Preacherbot: Wretched sinner unit! The path to Robot Heaven lies here, in the Good Book 3.0.
Fry: I hear that. I spent most of my teen years loving my body. Of course it was tough love...
Leela: Fry, he opened up relations with China. He doesn't want to hear about your ding-dong.
Lrrr: Instead of shooting where I was, you should have shot where I was going to be!
Zapp Brannigan: Now THERE's a wave of destruction that's easy on the eyes.
Professor Farnsworth: Now I'll need a fake ID to buy ultra-porn.
Professor Farnsworth: Oh, dear, I should have shown him "Electrogonorrhea: The Noisy Killer" instead.
Zapp Brannigan: That young man fills me with hope. Plus some other emotions which are weird and deeply confusing...
Planet Express Ship: You're just jealous! Nobody loves you because you're tiny and made of meat!
Zapp Brannigan: Don't ask me. You're the ones who are going to be dying.
Leela: Well, at least here you'll be treated with dignity. Now strip naked and get on the probulator!
Zapp Brannigan: Don't blame yourself, Kif. We were doomed from the start. I guess all that remains now is for the captain to go down with the ship.
Leela: I'll find Fry's coffin, get his corpse, and keep it under my mattress to remind me that he's really dead. That'll prove I'm not insane!
Professor Farnsworth: Some people think I'm robbing the cradle, but I say she's robbing the grave.
Professor Farnsworth: Oh dear, she's stuck in an infinite loop and he's an idiot! Oh well, that's love for you, I guess.
Professor Farnsworth: It's a spaceship, damn it! Not a prom limousine!
Leela: Depth at forty five hundred feet... Forty eight hundred... Fifty hundred... Five thousand feet!
Richard Nixon's Head: Good evening, ignorant pigs. Put down your crack pipes and your beer bongs and pay attention, as I sign a historic peace accord with ambassador Kong of planet Nintendu 64.
Fry: Wait a second, I know that monkey -- his name is Donkey!
Planet Express Ship: Why not make a national endowment for strip clubs while we're at it?
Leela: Bender! Ship! Stop bickering or I'm gonna come back there and change your opinions manually!
Professor Farnsworth: Monkeys aren't donkeys, quit messing with my head!
Fry: Now he's trapped in a book I wrote -- a crummy world of plot holes and spelling errors.
Giant Brain: The big brain am winning again! I am the greetest! I must now leave Earth for no raisin!
Planet Express Ship: Stop it! You're mussing up my trajectory!
Leela: Planet Express Ship - cover your shame!
Professor Farnsworth: Sold your body? Oh, Bender, I've been down that road. I know it's glamorous and the parties are great, but you'll end up spending every dollar you make on jewelry and skintight pants.
Bender: Dating a robot... it's an atrocimacy!
Bender: Would you stifle there, meatbag?
Hedonism Bot: Oh sirrah! A *man* writing an opera about a *woman*? How deliciously absurd!
Zapp Brannigan: Leela, I noticed that you're unescorted. May I escort you behind that bush?
Hedonism Bot: I apologize for nothing!
Professor Farnsworth: Oh, a lesson in not changing history from Mr. I'm-my-own-grandfather!
Henry Kissinger's Head: Young man, you have the bravery of a hero. And breath as fresh as a summer ham.
Professor Farnsworth: Professor!!! Lava!!! Hot!!!
Dr. Zoidberg: Once again, the conservative, sandwich-heavy portfolio pays off for the hungry investor!
Fry: Don't you worry about blank. Let me worry about blank.
Fry: Don't you worry about Planet Express. Let me worry about blank.
Bender: For now, I'll just stick to dating cheap floozies on the side.
Hedonism Bot: Your latest performance was as delectable as dipping my bottom over and over into a bath of the silkiest oils and creams.
Lrrr: Mmm, this jerked chicken is good. I think I'll have Fry's lower horn jerked.
Leela: Well, Fry, it looks like you get to hold on to your lower horn.
Bender: Oh, how I wish I could believe or understand that!
Joey Mousepad: The boss -- he likes a wall against which his back can be put against. Such as like this there. 
Joey Mousepad: But what if management remains intragnizant?
Enos: ... did you ever get the feeling you're only going with girls 'cause you're supposed to?
Morbo: Morbo will now introduce the candidates - Puny Human Number One, Puny Human Number Two, and Morbo's good friend, Richard Nixon.
Professor Farnsworth: ... and the microwave radiation, combined with the gravitons and graviolis from the supernova, blasted us through time itself!
Richard Nixon's Head: Nixon's pro-war and pro-family.
Lucy Liu Bot: I'll be just... [monotone] MASSIVE CORN CLOG IN PORT 7.
Lucy Liu Bot: Oh, Fry, I love you more than the moon, the stars, the... [monotone] POETIC IMAGE 37 NOT FOUND.
Wireframe Dummy 2: My two favorite things are commitment and changing myself.
Leela: Does that dummy have a brother?
Planet Express Ship: If you don't like the stations, you could just play with my buttons 'til you find something we both enjoy.
Zapp Brannigan: If we hit that bullseye, the rest of the dominoes should fall like a house of cards. Checkmate.
Zapp Brannigan: Now, like all great plans, my strategy is so simple an idiot could have devised it.
Sal: Whoas! Cripe!
That Guy: Awesome. Awesome to the max!
Bender: In the event of an emergency, my ass can be used as a flotation device.
Zapp Brannigan: On my command all ships will line up and file directly into the alien death cannons, clogging them with wreckage.
Robot Elder: Silence! I concur.
Bot Planet Robot: Sir, are you aware that you're leaking coolant at an alarming rate?
Zapp Brannigan: You're a brave robot, son. But when I'm in command every mission's a suicide mission.
Robot Santa: As for the rest of you, I'm going to tear off your skin like wrapping paper and deck the halls with your guts!
Bender: Ah, computer dating. It's like pimping, but you rarely have to use the phrase "upside your head."
Zapp Brannigan: You won't have time for sleeping, soldier, not with all the bedmaking you'll be doing.
Countess: Bender, I don't care if you have money. I love you for your artificial intelligence and your sincerity simulator. 
Lrrr: I am Lrrr of the Planet Nintendu 64! Tremble in fear at our three different types of ships!
Zapp Brannigan: I find the most erotic part of a woman is the boobies.
Calculon: Sir, your derangement is impressive. I appoint you my official stalker.
Jack Johnson: It's time for someone who has the courage to stand up and say, "I'm against those things that everybody hates!"
Hermes: Sweet... something.. of someplace...
Mom: Now I'm off to some charity BS for knocked-up teenage sluts.
John Jackson: Now, I respect my opponent. I think he's a good man. But quite frankly... I agree with everything he just said.
Zapp Brannigan: Kif, I have made it with a woman. Inform the men.
Bender: Boy, who knew a cooler could also make a handy wang coffin?
Professor Farnsworth: Most video tapes were damaged in 2047 during the second coming of Jesus.
Zapp Brannigan: I am the man with no name, Zapp Brannigan!
Mom: If I ever see him again, I swear I'll jam a squirrel in him!
Lrrr: Stop eating our young! And its pronounced "guacamole"!
Mom: Stick a bastard in it, you crap!
end;

// This just echoes the chosen line, we'll position it later
function futurama_quote() 
{
  global $quotes;

  // Here we split it into lines
  $quotes = explode("\n", $quotes);

  // And then randomly choose a line
  $chosen = wptexturize( $quotes[ rand(0, count($quotes) - 1) ] );

?>
<div class="futurama-contents">
  <span class="futurama-header">Random Futurama Quote</span>
  <p>
   <?= preg_replace("/^([^:]+:) (.*)$/", "<span class=\"futurama-char\">\\1</span> <span class=\"futurama-quote\">\\2</span>", $chosen) ?>
  </p>
</div>
<?php
}

?>
