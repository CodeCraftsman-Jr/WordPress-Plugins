<?php if ('wpctc_section-general' == $section['id']) : ?>

    <p>Set options influencing the behavior of all instances of this widget.</p>
    <input type="hidden" name="wpctc_settings[general][clear-cache-on-save]" value="0">

<?php endif; ?>
