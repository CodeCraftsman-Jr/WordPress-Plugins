<style type="text/css">
  #extendy-current-settings {
    padding:5px;
    border:1px solid #8BEA81;
    background-color:#BDEDA3;
  }
</style>