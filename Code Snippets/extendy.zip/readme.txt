=== Plugin Name ===
Contributors: sintaks
Tags: extendy, toolbar
Requires at least: 2.0.2
Requires at least: 2.0
Tested up to: 2.8.2
Stable tag: trunk

The Extendy plugin installs your toolbar from http://extendy.com on your blog. 

== Description ==

This plugin installs the Extendy toolbar to your blog without having to make edits to any of your template files. Note that you must have an Extendy account, available for free at http://extendy.com . Requires PHP 5.2.x+ with SimpleXML and URL file-access enabled.

== Installation ==

Upload the Extendy plugin to your blog. Activate it and enter the appropriate campaign api key from your Extendy.com account. You can find this on the "Install Extendy" page for a given campaign.

Requires PHP 5.2.x+ with SimpleXML and URL file-access enabled.
