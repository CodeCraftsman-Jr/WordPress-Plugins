## SyntaxHighlighter Evolved

Easily post syntax-highlighted code to your WordPress site without having to modify the code at all. As seen on WordPress.com.

## Development On The Next Version

A major rewrite is currently occurring in the [4.0 branch](https://github.com/Viper007Bond/syntaxhighlighter/tree/4.0). Go there if you want to see the current work in progress code.