<p><strong>
<?php _e('Related:', PostSnippets::TEXT_DOMAIN); ?>
</strong></p>

<p><a href="http://wordpress.org/support/plugin/post-snippets" target="_blank"><?php
_e('Support Forums', PostSnippets::TEXT_DOMAIN);
?></a></p>

<p><a href="https://github.com/artstorm/post-snippets" target="_blank"><?php
_e('GitHub Repository', PostSnippets::TEXT_DOMAIN);
?></a></p>

<p><a href="http://johansteen.se/donate/" target="_blank"><?php
_e('Donate', PostSnippets::TEXT_DOMAIN);
?></a></p>
