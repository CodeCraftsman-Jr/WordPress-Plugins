SyntaxHighlighter Evolved: TypeScript Brush
======================================

This Wordpress Plugin adds support for the TypeScript language to the [SyntaxHighlighter Evolved] (https://www.knarfalingus.com/).

This plugin is simple to use. Once you've installed the SyntaxHighligher Evolved plugin, simply upload this plugin and activate it. Then you can add highlighting to any TypeScript code simply by wrapping it in either the "typescript", "tscript" or "ts" shortcodes.

