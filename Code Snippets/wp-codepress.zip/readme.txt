=== CodePress Plugin for WordPress ===
Contributors: bobef
Tags: syntax, highligthing, code, editor
Requires at least: 2.5
Tested up to: 2.5
Stable tag: trunk

Converts the theme editor and plugin editor text areas in the admin panel to syntax-highlighted fields.

== Description ==

Converts the theme editor and plugin editor text areas in the admin panel to syntax-highlighted fields.

== Installation ==

1. Unzip into 'wp-content/plugins'
1. Download CodePress from http://www.codepress.org/
1. Unzip into 'wp-content/plugins/wp-codepress'
1. Now you should have 'codepress' directory under 'wp-content/plugins/wp-codepress'
1. Activate

If you want to change the styles, edit codepress/languages/*.css

== Screenshots ==

1. Editing a style sheet
2. Editing a PHP file