<?php

global $wishpot_plugin_url;

require_once('../../../../wp-load.php');

header('Content-type: text/css');

?>

html
{
  background:    url(<?php echo $wishpot_plugin_url . 'img/widget/bg2.png' ?>);
}