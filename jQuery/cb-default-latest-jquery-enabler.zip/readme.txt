=== CB Default Latest JQuery Enabler ===
Contributors: hmbashar
Donate link: http://fb.linuxhostlab.com
Tags: Wordpress Latest jQuery Enabler, Latest jQuery Enable plugin, WordPress jQuery enable.
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

This is just Wordpress Default Latest Jquery Enable.


== Installation ==

* Just Upload `CB Default Latest JQuery Enabler` to the `/wp-content/plugins/` directory
* Activate the plugin through the 'Plugins' menu in WordPress
* And enjoy this plugin.

== Frequently Asked Questions ==



== Screenshots ==


== Changelog ==

= 1.1 =
* support 4.3 version.


= 1.0 =
* just create new version.