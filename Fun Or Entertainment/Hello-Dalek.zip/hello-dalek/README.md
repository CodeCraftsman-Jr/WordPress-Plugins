#Hello Dalek
A simple plugin that displays Dr. Who Quotes in the same fashion as the Hello Dolly Plugin.

All characters from Dr. Who belong to thier respective owners. 

Shoutout to Dan Griffiths, who approves of this plugin (and helped with the quotes)

Licensed under GPL 2.0
