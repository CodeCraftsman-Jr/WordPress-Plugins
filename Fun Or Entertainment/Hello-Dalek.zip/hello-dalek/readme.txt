=== Hello Dalek ===
Contributors: NikV
Tags: Hello, Dalek, Who, First Doctor
Requires at least: 3.9
Tested up to: 4.1
Stable tag: 1.0
License: GNU GPLv2+
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Dr. Who quotes. Presented in the same fashion as hello Dolly.

== Description ==
How about a new Dr. Who quote every time you refresh the admin? This will bring fans quotes all the way back to the first doctor.

== Installation ==

1. Unpack the entire contents of this plugin zip file into your `wp-content/plugins/` folder locally
2. Upload to your site
3. Navigate to `wp-admin/plugins.php` on your site (your WP Admin plugin page)
4. Activate this plugin

OR you can just install it with WordPress by going to Plugins >> Add New >> and type this plugin\'s name

== Frequently Asked Questions ==


== Screenshots ==

== Changelog ==
= 1.0 =
Version 1.0 Release

== Upgrade Notice ==
= 1.0 =
Initial Commit!