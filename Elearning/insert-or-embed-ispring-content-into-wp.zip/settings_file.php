<?php
/*
This settings is being used in whole wordpress
*/
define('WP_ISPRING_EMBEDER_UPLOADS_DIR_NAME','ispring_uploads');
?>