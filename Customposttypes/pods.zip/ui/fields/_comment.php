<p<?php PodsForm::attributes( $attributes, $name, $type, $options ); ?>>
    <?php echo $message; ?>
</p>