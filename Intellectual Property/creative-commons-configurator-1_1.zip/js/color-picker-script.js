jQuery(document).ready(function($){
    $('.cc-color-field').wpColorPicker();
    // See: https://make.wordpress.org/core/2012/11/30/new-color-picker-in-wp-3-5/
});
