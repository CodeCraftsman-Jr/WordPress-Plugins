=== Get Menu Joomla ===
Contributors: Roger Torres
Donate link: http://cuscosoft.com/get-joomla-menu/
Tags: joomla, cms, menu, joomla menu, menu joomla, get menu joomla 
Requires at least: 2.0.2
Tested up to: 3.0
Stable tag: 1

Get Joomla menu, you get a menu and displays it in joomla wordpress plugin is specially designed for those who use wordpress joomla and in addition,

== Description ==

Get Joomla menu, you get a menu and displays it in joomla wordpress plugin is specially designed for those who use wordpress joomla and in addition, this plugin will display a menu of joomla wordpress as a widget or embedded in the template.


== Installation ==

1 Download the file. Zip to your computer and access your wordpress admin panel.

2 In your admin panel go to the plugins section and select Add new segment. Find the file wp-get-joomla-meu.zip you downloaded and click the Install button. Unzip and install the WordPress plugin.

3 Click on the link Activate Plugin,

4 dirijate the Settings menu then find Joomla menu, which will take you to the configuration of the plugin,

Settings.

To configure the connection with joomla can provide the name of the joomla configuration.php file or enter data access joomla database.
When connected enter the menu data.

As shown in the menu?

The menu can be displayed in two ways through a widget or the template.

Widget
When you have activated the plugin also activate a widget Get the name of Joomla go menu Menu Appearance -> Widgets and drag Joomla Menu Get the widget panel active.

Template
You can also include the menu with the template for this you have to add in the template code <?Php get_joomla_menu ('Title Menu');?> 


== Changelog ==

= 1.0 =
is a first version

== A brief Markdown Example ==


1 Download the file. Zip to your computer and access your wordpress admin panel.

2 In your admin panel go to the plugins section and select Add new segment. Find the file wp-get-joomla-meu.zip you downloaded and click the Install button. Unzip and install the WordPress plugin.

3 Click on the link Activate Plugin,

4 dirijate the Settings menu then find Joomla menu, which will take you to the configuration of the plugin,

Settings.

To configure the connection with joomla can provide the name of the joomla configuration.php file or enter data access joomla database.
When connected enter the menu data.

As shown in the menu?

The menu can be displayed in two ways through a widget or the template.

Widget
When you have activated the plugin also activate a widget Get the name of Joomla go menu Menu Appearance -> Widgets and drag Joomla Menu Get the widget panel active.

Template
You can also include the menu with the template for this you have to add in the template code <?Php get_menu_joomla ('Title Menu');?> 