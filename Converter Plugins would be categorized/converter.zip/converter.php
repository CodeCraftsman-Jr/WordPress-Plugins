<?php
/*
Plugin Name: Converter
Plugin URI: http://ajayver.com
Description: This plugin adds a widget that allows users to convert different values
Version: 1.0
Author: ajayver
Author URI: http://ajayver.com
License: GPL2
*/


include( plugin_dir_path( __FILE__ ) . 'widget.php');

