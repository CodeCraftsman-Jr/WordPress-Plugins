=== Converter ===
Contributors: ajayver
Donate link: http://goo.gl/fVSGe
Tags: converter, calculator, cooking
Requires at least: 2.7
Tested up to: 3.5.2
Stable tag: 1.0

This plugin adds a widget that allows your users to convert different ingredients to different measurements.

== Description ==

This plugin adds a widget that allows your users to convert different ingredients to different measurements. The data is taken from two csv files: data/ingredients.csv and data/measurements.csv. You can add as much more ingredients or measurements as you like.

== Screenshots ==

1. This is how the widget looks in twentytwelve theme with no styling.


== Changelog ==

= 1.0 =
*Plugin's initial publication
