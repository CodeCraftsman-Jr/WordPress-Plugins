=== Post Gallery Ultimate ===
Contributors: jeffbullins
Donate link: http://www.thinklandingpages.com
Tags:  post, gallery, 
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An easy way to place a post gallery with content on your Wordpress site.

== Description ==


An easy way to place a post gallery with content on your Wordpress site.

###What you get when you use the Post Gallery post gallery

*  Put any post or page on your post gallery
*  post gallery headline
*  post gallery header content
*  post gallery footer content
*  includes your site header and footer


###Unlimited post galleries

You can create as many post galleries as you want.  The Post Gallery lets you create post gallery and save them for when ever you are ready to use them.

###Quick Start Guide

* [post gallery quick start guide at thinklandingpages.com] (http://www.thinklandingpages.com/post-gallery/)



== Installation ==


1. Upload `post-gallery` to the `/wp-content/post-gallery/` directory
1. Activate the post gallery through the 'Post Gallery' menu in WordPress
1. Click **Post Gallery** on the admin menu to enable and set your options.


== Frequently Asked Questions ==

= Do I have to know how to program or design? =

No.  The post gallery does the programming and design.

= Is there a limit to the number of post gallery I can create? =
No, unlimited post gallery can be created.

= Can the post gallery be put on my homepage? =
Yes, you can set a post gallery as you homepage.

= Can I put any post or page on a post gallery? =
Yes, any post or page can be on a post gallery page.


== Screenshots ==

[See screenshots at thinklandingpages.com] (http://www.thinklandingpages.com/post-gallery/)


== Changelog ==

= 1.0 =
* First Release


