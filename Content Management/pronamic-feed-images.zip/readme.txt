=== Pronamic Feed Images ===
Contributors: pronamic, remcotolsma
Tags: pronamic, feed, image, thumbnail, rss
Requires at least: 3.0
Tested up to: 3.2
Stable tag: 1.0.0

This plugin automatically adds the post thubmanil to the WordPress feeds, the image size can be easily configured.

== Description ==

This plugin automatically adds the post thubmanil to the WordPress feeds, the image size can be easily configured.
This plugin differs from other plugins because it is built according the WordPress Coding Standards and uses many 
powerful WordPress functions.


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your 
WordPress installation and then activate the Plugin from Plugins page.


== Screenshots ==

...


== Changelog ==

= 1.0.0 =
*	No longer auto add images to feed content

= 0.1 =
*	Initial release


== Links ==

*	[Pronamic](http://pronamic.eu/)
*	[Remco Tolsma](http://remcotolsma.nl/)
*	[Markdown's Syntax Documentation][markdown syntax]

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
		"Markdown is what the parser uses to process much of the readme file"


== Pronamic plugins ==

*	[Pronamic Google Maps](http://wordpress.org/extend/plugins/pronamic-google-maps/)
*	[Gravity Forms (nl)](http://wordpress.org/extend/plugins/gravityforms-nl/)
*	[Pronamic Page Widget](http://wordpress.org/extend/plugins/pronamic-page-widget/)
*	[Pronamic Page Teasers](http://wordpress.org/extend/plugins/pronamic-page-teasers/)
*	[Maildit](http://wordpress.org/extend/plugins/maildit/)
*	[Pronamic Framework](http://wordpress.org/extend/plugins/pronamic-framework/)
*	[Pronamic iDEAL](http://wordpress.org/extend/plugins/pronamic-ideal/)

