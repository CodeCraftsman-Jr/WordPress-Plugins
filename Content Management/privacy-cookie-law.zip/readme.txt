=== Privacy Cookie Law ===
Contributors: ninjapress, wowdinamica, stefanobutto
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=LNY8C3ESXK5MG
Tags: privacy law, cookie law
Requires at least: 3.2
Tested up to: 3.6
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add a banner on your website in compliance with new cookie law

== Description ==

In compliance with new cookie law you have to inform the visitors about your cookies management.
With our free plugin you can resolve quickly the problem adding on the top of your 
website a banner that shows your compliance status regarding the new cookie law.
 From this banner the visitor can click to a link to obtain more informations. 
We recommend to realize the specific explanation page about your privacy cookies
 management before install the plugin. 

Languages: english, italiano;

== Installation ==

* Upload the files on the plugins section of your Wordpress;
* Activate the plugin through the 'Plugins' menu in WordPress;
* Create a new page/post and watch the option at the end of the page.

== Frequently Asked Questions ==

= How to use =

* [FAQ](http://www.ninjapress.net/instant-membership/faq/) 
* [Contact us](http://www.ninjapress.net/contacts/) 

== Screenshots ==


== Changelog ==

= 1.0.1 =
Correct minor bug

= 1.0 =
Initial revision

== Upgrade Notice ==

There is no news of importance 
