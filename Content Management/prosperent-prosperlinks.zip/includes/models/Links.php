<?php
require_once(PROSPERLINKS_MODEL . '/Base.php');
/**
 * Search Model
 *
 * @package Model
 */
class Model_Links_Links extends Model_Links_Base
{
	public function __construct()
	{

	}
}