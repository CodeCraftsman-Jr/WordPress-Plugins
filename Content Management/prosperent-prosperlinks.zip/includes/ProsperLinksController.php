<?php
/**
 * ProsperLinks Controller
 *
 * @package 
 * @subpackage 
 */
class ProsperLinksLinksController
{
    /**
     * the class constructor
     *
     * @package 
     * @subpackage 
     *
     */
    public function __construct()
    {
    }
}
 
$prosperLinksLinks = new ProsperLinksLinksController;