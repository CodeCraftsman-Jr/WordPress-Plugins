=== Plugin Name ===
Contributors: Hemant Dhote.
Donate link: 
Tags:  best carousel slider, best post slider, best responsive slider, best slideshow, best slideshow plugin, bxslider, carousel slider, excerpt, featured thumbnail, get posts, image, image slider, image slideshow, images, logo scroller, news slider, nivo slider, owl slider, popular posts, Post, post slider, post slider plugin, posts, posts slider, recent, recent post, recent post slider, recent posts, responsive carousel
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Posts Carousel  Slider is a WordPress posts content slider plugin. Posts slider displays your blog's recent posts using beautiful slider.

To use this slider use this short code [post_carousel_slider] in page and post where you want to show that .

== Description ==

Posts Carousel  Slider is a WordPress posts content slider plugin. Posts slider displays your blog's recent posts using beautiful slider.

To use this slider use this short code [post_carousel_slider] in page and post where you want to show that .


== Installation ==

This section describes how to install the plugin and get it working.

1.Upload the entire Post Slider  Plugin folder to the /wp-content/plugins/ directory.
2.Activate the plugin through the 'Plugins' menu in WordPress.
3.You will find 'Post Slider' menu in your WordPress admin panel.



== Changelog ==

= 1.0 =
1.Basic Version
