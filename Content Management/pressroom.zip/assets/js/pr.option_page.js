jQuery(function(){

  // Chosen init
  if(jQuery(".chosen-select").length)
    jQuery(".chosen-select").chosen();
});
