<?php

function edd_panorama_license_menu() {

	global $psp_settings_page;

	$psp_settings_page = add_submenu_page( 'edit.php?post_type=psp_projects','Project Panorama Settings', 'Settings', 'manage_options', 'panorama-license', 'edd_panorama_license_page' );

}
add_action('admin_menu', 'edd_panorama_license_menu');

function edd_panorama_license_page() {
	$license 	= get_option( 'edd_panorama_license_key' );
	$status 	= get_option( 'edd_panorama_license_status' );

    wp_enqueue_script(
        'admin-settings.js',
        PROJECT_PANARAMA_URI . '/assets/js/admin-settings.js',
        array('jquery'),
        null,
        true
    );

	?>
	<div class="wrap">
		<h2><?php _e('Project Panorama Options','psp_projects'); ?></h2>

        <br>

        <?php

            if( isset( $_GET[ 'tab' ] ) ) {
               $active_tab = $_GET[ 'tab' ];
            } else {
                $active_tab = 'psp_general_settings';
            }

            if(isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true') {

            flush_rewrite_rules(); ?>

            <div class="updated">
                <p><?php _e('The Project Panorama settings have been updated','psp_projects'); ?>.</p>
            </div>

        <?php } ?>
		
		<form method="post" action="options.php">

			<?php settings_fields('edd_panorama_license'); ?>

            <div id="psp_appearance" class="psp-settings-tab psp-settings-tab-active">

                <table class="form-table">
                    <tbody>
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_logo"><?php _e('Logo for Project Pages','psp_projects'); ?></label>
                            </th>
                            <td>
                                <input id="psp_logo" type="text" size="36" name="psp_logo" value="<?php echo get_option('psp_logo','http://'); ?>" />
                                <input id="psp_upload_image_button" class="button" type="button" value="Upload Image" />
                            </td>
                        </tr>
                    </tbody>
                </table>

                <table class="form-table">
                    <tbody>
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_use_custom_template"><?php _e('Use Custom Template'); ?></label>
                            </th>
                            <td>
                                <input type="checkbox" id="psp_use_custom_template" value="1" name="psp_use_custom_template" class="js-psp-choose-custom-template" <?php echo get_option('psp_use_custom_template') === '1' ? 'checked="checked"' : null;?> />
                            </td>
                        </tr>

                        <?php // TODO: wrap in conditional for pro only feature ?>
                        <tr class="js-psp-choose-custom-template-active-show" style="display:none;">
                            <th scope="row" valign="top">
                                <label for="psp_use_custom_template"><?php _e('Choose Custom Template'); ?></label>
                            </th>
                            <td>
								
							
								
                                <?php
                                    $templates = wp_get_theme()->get_page_templates();

                                    if (!empty($templates)) :

                                        $templates['page.php'] = 'Standard Page';
                                ?>

                                    <select id="psp_custom_template" name="psp_custom_template">
                                        <option value=""><?php _e('Choose Template'); ?></option>
                                        <?php foreach($templates as $t_filename => $t_name) : ?>
                                            <option <?php echo get_option('psp_custom_template') === $t_filename ? 'selected' : null;?> value="<?php echo $t_filename;?>">
                                                <?php echo $t_name; ?>
                                            </option>
                                        <?php endforeach; ?>

                                    </select>
									
									<div class="psp-warning">
										<span><?php _e('Warning: This is an unsupported feature and might not work or display well with all themes.','psp-projects'); ?></span>
									</div>

                                <?php else: ?>
                                    <div style="color:red;">
                                        <?php _e('There are no custom templates in your current theme.'); ?>
                                    </div>

                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <fieldset class="psp-fieldset">
                    <legend><?php _e('Header','psp_projects'); ?></legend>


                <table class="form-table psp-color-table">
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_header_background"><?php _e('Header Background','psp_projects'); ?></label>
                        </th>
                        <td>
                            <input id="psp_header_background" value="<?php echo get_option('psp_header_background'); ?>" name="psp_header_background" class="color-field" rel="2a3542">
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="psp_header_text"><?php _e('Header Text','psp_projects'); ?></label>
                        </th>
                        <td>
                            <input id="psp_header_text" value="<?php echo get_option('psp_header_text'); ?>" name="psp_header_text" class="color-field" rel="fff">
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="psp_header_accent"><?php _e('Accent Text','psp_projects'); ?></label>
                        </th>
                        <td>
                            <input id="psp_header_accent" value="<?php echo get_option('psp_header_accent'); ?>" name="psp_header_accent" class="color-field" rel="aeb2b7">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_menu_background"><?php _e('Menu Background','psp_projects'); ?></label>
                        </th>
                        <td>
                            <input id="psp_menu_background" value="<?php echo get_option('psp_menu_background'); ?>" name="psp_menu_background" class="color-field" rel="2a3542">
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="psp_menu_text"><?php _e('Menu Text','psp_projects'); ?></label>
                        </th>
                        <td>
                            <input id="psp_menu_text" value="<?php echo get_option('psp_menu_text'); ?>" name="psp_menu_text" class="color-field" rel="fff">
                        </td>
                    </tr>
                </table>

                </fieldset>

                <fieldset class="psp-fieldset">
                    <legend><?php _e('Body','psp_projects'); ?></legend>

                    <table class="form-table psp-color-table">
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_body_background"><?php _e('Body Background','psp_projects'); ?></label>
                            </th>
                            <td>
                                <input id="psp_body_background" value="<?php echo get_option('psp_body_background'); ?>" name="psp_body_background" class="color-field" rel="f1f2f7">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_body_heading"><?php _e('Body Heading','psp_projects'); ?></label>
                            </th>
                            <td>
                                <input id="psp_body_heading" value="<?php echo get_option('psp_body_heading'); ?>" name="psp_body_heading" class="color-field" rel="999">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_body_background"><?php _e('Body Text','psp_projects'); ?></label>
                            </th>
                            <td>
                                <input id="psp_body_text" value="<?php echo get_option('psp_body_text'); ?>" name="psp_body_text" class="color-field" rel="333">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_body_link"><?php _e('Body Link','psp_projects'); ?></label>
                            </th>
                            <td>
                                <input id="psp_body_link" value="<?php echo get_option('psp_body_link'); ?>" name="psp_body_link" class="color-field" rel="000">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_footer_background"><?php _e('Footer Background','psp_projects'); ?></label>
                            </th>
                            <td>
                                <input id="psp_footer_background" value="<?php echo get_option('psp_footer_background'); ?>" name="psp_footer_background" class="color-field" rel="2a3542">
                            </td>
                        </tr>
                    </table>

                    <p><input type="button" class="psp-reset-colors button-secondary" value="Reset Colors to Default" name="psp-reset-colors"></p>


                </fieldset>

                <fieldset class="psp-fieldset">
                    <legend><?php _e('Custom Styling','psp_projects'); ?></legend>
                    <table class="form-table">
                        <tr>
                            <th scope="row" valign="top">
                                <label for="psp_open_css"><?php _e('Custom CSS','psp_projects'); ?></label>
                            </th>
                            <td>
                                <textarea rows="10" cols="75" name="psp_open_css" id="psp_open_css"><?php echo get_option('psp_open_css'); ?></textarea>
                            </td>
                        </tr>
                    </table>
                </fieldset>

            </div>

            <?php do_action('psp_settings_page'); ?>

			<?php submit_button(); ?>

		</form>
	<?php
}

function edd_panorama_register_options() {
	// creates our settings in the options table
	register_setting('edd_panorama_license', 'edd_panorama_license_key', 'edd_sanitize_license');

	// Additional options
	add_option('psp_slug','panorama');
	add_option('psp_logo');
	add_option('psp_flush_rewrites');
    add_option('psp_rewrites_flushed');
	add_option('psp_back');

	register_setting( 'edd_panorama_license', 'psp_slug' );
	register_setting( 'edd_panorama_license', 'psp_logo' );
	register_setting( 'edd_panorama_license', 'psp_flush_rewrites' );
    register_setting( 'edd_panorama_license', 'psp_rewrites_flushed' );
	register_setting( 'edd_panorama_license', 'psp_back');

    // Notifications
    register_setting( 'edd_panorama_license', 'psp_from_name');
    add_option('psp_from_name');

    register_setting( 'edd_panorama_license', 'psp_from_email');
    add_option('psp_from_email');

    register_setting( 'edd_panorama_license', 'psp_default_subject');
    add_option('psp_default_subject');

    register_setting( 'edd_panorama_license', 'psp_default_message');
    add_option('psp_default_message');

    register_setting( 'edd_panorama_license', 'psp_include_logo');
    add_option('psp_include_logo');

    // Color Styling

    // Header
    add_option('psp_header_background','#2a3542');
    add_option('psp_header_text','#aaa');
    add_option('psp_menu_background','#2a3542');
    add_option('psp_menu_text','#fff');
    add_option('psp_header_accent','#aeb2b7');

    // Body
    add_option('psp_body_background','#f1f2f7');
    add_option('psp_body_text','#333');
    add_option('psp_body_link','#000');
    add_option('psp_body_heading','#999');
    add_option('psp_footer_background','#2a3542');

    // Custom Template
    add_option('psp_use_custom_template', '0');
    add_option('psp_custom_template', '');


    add_option('psp_open_css');

    // Register Settings
    register_setting( 'edd_panorama_license', 'psp_header_background' );
    register_setting( 'edd_panorama_license', 'psp_header_text');
    register_setting( 'edd_panorama_license', 'psp_menu_background');
    register_setting( 'edd_panorama_license', 'psp_menu_text');
    register_setting( 'edd_panorama_license', 'psp_header_accent');

    register_setting('edd_panorama_license','psp_body_background');
    register_setting('edd_panorama_license','psp_body_text');
    register_setting('edd_panorama_license','psp_body_link');
    register_setting('edd_panorama_license','psp_body_heading');
    register_setting('edd_panorama_license','psp_footer_background');

    register_setting( 'edd_panorama_license', 'psp_open_css');

    // Custom Template
    register_setting('edd_panorama_license', 'psp_use_custom_template');
    register_setting('edd_panorama_license', 'psp_custom_template');
	
	// Advanced
	register_setting('edd_panorama_license', 'psp_disable_js');
	
}

add_action('admin_init', 'edd_panorama_register_options');

function edd_sanitize_license( $new ) {
	$old = get_option( 'edd_panorama_license_key' );
	if( $old && $old != $new ) {
		delete_option( 'edd_panorama_license_status' ); // new license has been entered, so must reactivate
	}
	return $new;
}

add_action('admin_init', 'psp_check_if_rewrites_flushed');
function psp_check_if_rewrites_flushed() {

    $flushed = get_option('psp_rewrites_flushed');

    if($flushed != 'yes') {
        flush_rewrite_rules();
        update_option('psp_rewrites_flushed','yes');
    }

}



/************************************
* this illustrates how to activate
* a license key
*************************************/

function edd_panorama_activate_license() {

	// listen for our activate button to be clicked
	if( isset( $_POST['edd_license_activate'] ) ) {

		// run a quick security check
	 	if( ! check_admin_referer( 'edd_panorama_nonce', 'edd_panorama_nonce' ) )
			return; // get out if we didn't click the Activate button

		// retrieve the license from the database
		$license = trim( get_option( 'edd_panorama_license_key' ) );


		// data to send in our API request
		$api_params = array(
			'edd_action'=> 'activate_license',
			'license' 	=> $license,
			'item_name' => urlencode( EDD_PROJECT_PANORAMA ), // the name of our product in EDD
		    'url'   => home_url()
        );

		// Call the custom API.
		$response = wp_remote_get( add_query_arg( $api_params, PROJECT_PANORAMA_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );



		// make sure the response came back okay
		if ( is_wp_error( $response ) )
			return false;

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// $license_data->license will be either "active" or "inactive"

		update_option( 'edd_panorama_license_status', $license_data->license );

	}



}
add_action('admin_init', 'edd_panorama_activate_license',0);

function psp_check_activation_response() {

    // retrieve the license from the database
    $license = trim( get_option( 'edd_panorama_license_key' ) );


    // data to send in our API request
    $api_params = array(
        'edd_action'=> 'activate_license',
        'license' 	=> $license,
        'item_name' => urlencode( EDD_PROJECT_PANORAMA ), // the name of our product in EDD
        'url'   => home_url()
    );

    // Call the custom API.
    $response = wp_remote_get( add_query_arg( $api_params, PROJECT_PANORAMA_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

    var_dump($response);

}


/***********************************************
* Illustrates how to deactivate a license key.
* This will descrease the site count
***********************************************/

function edd_panorama_deactivate_license() {

	// listen for our activate button to be clicked
	if( isset( $_POST['edd_license_deactivate'] ) ) {

		// run a quick security check
	 	if( ! check_admin_referer( 'edd_panorama_nonce', 'edd_panorama_nonce' ) )
			return; // get out if we didn't click the Activate button

		// retrieve the license from the database
		$license = trim( get_option( 'edd_panorama_license_key' ) );


		// data to send in our API request
		$api_params = array(
			'edd_action'=> 'deactivate_license',
			'license' 	=> $license,
			'item_name' => urlencode( EDD_PROJECT_PANORAMA ) // the name of our product in EDD
		);

		// Call the custom API.
		$response = wp_remote_get( add_query_arg( $api_params, PROJECT_PANORAMA_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

		// make sure the response came back okay
		if ( is_wp_error( $response ) )
			return false;

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// $license_data->license will be either "deactivated" or "failed"
		if( $license_data->license == 'deactivated' )
			delete_option( 'edd_panorama_license_status' );

	}
}
add_action('admin_init', 'edd_panorama_deactivate_license');


/************************************
* this illustrates how to check if
* a license key is still valid
* the updater does this for you,
* so this is only needed if you
* want to do something custom
*************************************/

function edd_panorama_check_license() {

	global $wp_version;

	$license = trim( get_option( 'edd_panorama_license_key' ) );

	$api_params = array(
		'edd_action' => 'check_license',
		'license' => $license,
		'item_name' => urlencode( EDD_PROJECT_PANORAMA )
	);

	// Call the custom API.
	$response = wp_remote_get( add_query_arg( $api_params, PROJECT_PANORAMA_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

	if ( is_wp_error( $response ) )
		return false;

	$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	if( $license_data->license == 'valid' ) {
		echo 'valid'; exit;
		// this license is still valid
	} else {
		echo 'invalid'; exit;
		// this license is no longer valid
	}
}