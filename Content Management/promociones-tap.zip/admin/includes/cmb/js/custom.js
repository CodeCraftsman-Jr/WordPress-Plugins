jQuery(document).ready(
  function($) {
    /**
     * Metabox of Post
     */

    /**
     * End Post
     */
  }
);