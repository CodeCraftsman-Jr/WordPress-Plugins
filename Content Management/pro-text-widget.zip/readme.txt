=== Pro Text Widget ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: pro text widget,custom text widget,advanced text widget,text widget,widget,text
Requires at least: 2.9
Tested up to: 4.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Pro Text Widget plugin.You have choice to text widget show only specific Post/category/Page.

== Description ==

Pro Text Widget plugin.You have choice to text widget show only specific Post/category/Page.

= Features : =

 1. You have choice to specific to widget show only  posts/pages/categories.
 2. Multiple post/category/page option(comma separated).


More detail : http://socialcms.wordpress.com/


== Installation ==


1. Upload the **pro-text-widget** folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go Appearance => widgets section  see **Pro Text Widget**

== Frequently Asked Questions ==

* **Only show in all post pages**

 In Widget section "*Display Only In*" set to **Post** and  "*Display IDs*"  set to blank.

* **Only show in specific category page**

 In Widget "*Display Only In*" set to **Category** and  "*Display IDs*"  set category ids which you want.


== Screenshots ==

1. This screen shot description corresponds to screenshot-1.png.


== Changelog ==

= 1.1 =
* Fix Error in page case

= 1.0 =
* Initial release

== Upgrade Notice ==

N/A