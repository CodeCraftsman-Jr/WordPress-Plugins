=== Posts widget with tabs ===
Contributors: WEB4PRO_co
Donate link: http://www.web4pro.net
Tags: Posts, tabs, widget, tabs widget
Requires at least: 3.5.1
Tested up to: 4.2.1
Stable tag: tabs/widget
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This widget allows you to display posts in the tabs on certain settings. You can output posts by different settings and set number of posts and label of tabs.


== Installation ==

1. Upload or extract the `posts_tabs_widget` folder to your site's `/wp-content/plugins/` directory. You can also use the *Add new* option found in the *Plugins* menu in WordPress.  
2. Enable the plugin from the *Plugins* menu in WordPress.

= Usage =

1. Go to Appearance > Widgets.
2. Find Tabs Widget in Available Widgets and add to the selected sidebar.
3. Specify the desired options for tabs and hit save.

== Screenshots ==

1. Widget settings.
2. Mapping widget.

== Changelog ==

= 1.0 =
