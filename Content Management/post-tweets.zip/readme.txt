=== Post Tweets ===
Contributors: viaviwebtech
Donate link: https://www.paypal.com/cgi-bin/webscr?button=donate&business=viaviwebtech%40gmail.com&item_name=Post+Tweets+Donation&quantity=&amount=&currency_code=&shipping=&tax=&notify_url=http%3A%2F%2Fviaviweb.com&cmd=_donations&bn=JavaScriptButton_donate&env=www&submit.x=66&submit.y=12
Tags: post, page, tweets, twitter, post tweets, social, social media
Requires at least: 3.0.1
Tested up to: 4.0.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows wordpress authors to post their tweets from post and pages.

== Description ==

This plugin allows wordpress authors to post their tweets from post and pages.

A simple plugin for thouse who dont want to install complex plugins in their site and save time.

Just install this plugin and configure it with admin and you can add your posts on your twitter as tweet.

You can Tweet from your website you dont need to go on twitter to tweet..

So install this plugin and save your time..  Also dont forget to rate & share this plugin..


= Features =
  * Easy and simple.
  * Easy setting and configuration  

= Author =
Developed by [viaviweb.com](http://viaviweb.com)
 
== Installation ==

Just flow the following easy steps..

1. Click the 'Post Tweets' button at admin menu
2. Set Consumer key,Consumer secret,Access Token,Access Token Secret and press Save Changes Button
 

== Frequently Asked Questions ==

= Q. How do I set my Twitter account's details? =

A. You will find the instructions from [twitter](https://dev.twitter.com/apps)

 
== Screenshots ==
 
1. Post custom tweets 
2. Set twitter account
3. If you want to post as tweet

== Changelog ==

= 1.0.0 =
Initial version released

== Upgrade Notice ==
Nothing here




