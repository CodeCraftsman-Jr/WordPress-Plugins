=== Plugin Name ===
Contributors: vijaypadhariya
Donate link: http://www.digitize-info.com/
Tags: post filters, post management, administrator post
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

post management made easy by this plugin provides you with the various post filters!

== Description ==

Post management made easy by this plugin! I had been working across many wordpress sites with a lots of posts in them, so I think to create
one plugin which will help Authors to manage posts by date filters and also the Author filters. More filters will come based on Custom post
type support.

Yes its translation ready.


== Installation ==
1. Upload `dg_posts_filter` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Open `posts` and see the extra filters there!

== Frequently Asked Questions ==

= Do you have questions or issues with `dg_posts_filter`?=

Kindly visit http://www.digitize-info.com and contact us about that, and we will reply back.


== Screenshots ==

1. This is how Post filters will appear

== Changelog ==

= 1.0.0 =
* We just Born, stay tuned for more features!

== Upgrade Notice ==

= 1.0.0 =
This is first version!