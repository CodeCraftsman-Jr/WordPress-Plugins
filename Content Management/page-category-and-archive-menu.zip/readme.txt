=== Plugin Name ===
Contributors: aueda
Donate link: http://tempspace.net/plugins/
Tags: page,pages,category,categories,menu,list,link
Requires at least: 3.2.0
Tested up to: 3.2.1
Stable tag: 4.3

== Description ==

You can embed page, category, and archive menu in your Wordperss site. You can get documentation and view demos from following site:<br>
http://tempspace.net/plugins/?page_id=33

If you are annoyed with consumption of large amount of window space by page, category, and archive list, this plugin will be useful.

When the bottom of the menu seems to be out of the window, the menu is "multi-columnized" automatically. Also, when the right side of the menu seems to be out of the window, the horizontal position of the menu is
automatically adjusted.

You can change font-size, color, spacing in the admin page easily.

== Installation ==

Install the plugin like usual ones. Then activate it.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot

== Changelog ==

= 1.0.0 =
* First release.
