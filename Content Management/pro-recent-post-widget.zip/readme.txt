=== Pro Recent Post Widget ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: pro recent post widget,widget,custom recent post,advanced recent posts widget,exclude post,exclude post in recent post widget,exclude category
Requires at least: 3.0.1
Tested up to: 4.2.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Pro Recent Post Widget plugin.You have choice to specific category recent post show.exclude any category,exclude any post

== Description ==

Pro Recent Post Widget plugin.You have choice to specific category recent post show.exclude any category,exclude any post

**Features**

1. You have choice to specific category recent post show.
2. exclude any post.
3. exclude any category.

More Detail : http://socialcms.wordpress.com/


== Installation ==


1. Upload the **pro-recent-post-widget** folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go Appearance => widgets section  see **Pro Recent Posts**


== Frequently Asked Questions ==

N/A

== Screenshots ==

1. screenshot-1.png  : screen shot admin widgets section.


== Changelog ==

= 1.1 =
* Add exclude post option

= 1.0 =
* Initial release

== Upgrade Notice ==

N/A