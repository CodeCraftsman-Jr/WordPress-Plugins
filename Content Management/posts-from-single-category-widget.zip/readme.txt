=== Plugin Name ===
Contributors: 		shashidharkumar
Plugin Name:       	Posts from Single Category Widget
Plugin URI:        	http://www.shashidharkumar.com/post-from-single-category-widget-wordpress/
Author URI:        	http://www.shashidharkumar.com/
Author:            	Shashidhar Kumar
Donate link: 		http://www.shashidharkumar.com/donate/
Tags: 			plugin, posts, posts from category, multiple posts from category, widget, Wordpress
Requires at least: 	4.0
Tested up to: 		4.2.1
Stable tag: 		trunk
Version:           	3.0
License: 		GPLv2 or later
License URI: 		http://www.gnu.org/licenses/gpl-2.0.html

This plugin is a widget that displays a list of posts from single category on your sidebar. You can also assign how may words will be display for each category content. You can customize your Read more text as well.

== Description ==

This plugin is a widget that displays a list of posts from single category on your sidebar. You can also assign how may words will be display for each category content. You can customize your Read more text as well.

== Installation ==

How to install the plugin (Posts from Single Category Widget) and get it working.

1. Upload post-from-single-category.zip to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use your 'Appearance/Widgets' settings configure
4. See Posts from Single Category in widget area than drag and configure

== Configuration ==
1. Widget Title: the title of the widget
2. Category of Post: Select category of post to display
3. Number of Posts: Number of posts you would like to be display
4. Content Length: You can define length of content
5. Read More text: You can also define the read more link text
6. RSS Link: If you want to show rss link of that category

== Screenshots ==

1. screenshot-1.png
1. screenshot-2.png
