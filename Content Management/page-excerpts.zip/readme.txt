=== Page Excerpts ===
Contributors: jbrinley
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZLZJSSEGR2MU2
Tags: pages, excerpts, widget
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.0.2

Adds an excerpt field to pages, and provides a widget for displaying page excerpts

== Description ==

The standard excerpt field will appear on pages, just as it does on posts.

Additionally, there is a new widget to display the excerpt of a selected page.

Created by [Flightless](http://flightless.us/)

== Installation ==

1. Upload the Page Excerpts plugin to your blog
1. Activate it


== Changelog ==

= 1.0 =
* Initial version
