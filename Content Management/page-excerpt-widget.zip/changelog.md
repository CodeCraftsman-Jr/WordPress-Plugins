== Changelog ==

= 0.4 =
2015-1-15

updated tested until

= 0.2 =
2013-1-6

Rewrite for multiple instances

* WP 2.8 is a requirement now

= 0.1 =
2012-7-11

Initial release

* Define the amount of characters to use as an excerpt
* Select the page from all existing pages
* Link the title of the page, to the page
* Append a link to the page
* Decide a custom label for the read more link
