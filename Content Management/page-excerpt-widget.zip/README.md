Page-Excerpt-Widget
===================

A simple WordPress widget for creating page excerpts as a widget