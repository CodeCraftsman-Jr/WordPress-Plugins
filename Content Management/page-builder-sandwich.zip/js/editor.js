// @codekit-append "_editor-add-post-element.js";
// @codekit-append "_editor-start.js";
// @codekit-append "_editor-core.js";
// @codekit-append "_editor-toolbars.js";
// @codekit-append "_editor-toolbar-actions.js";
// @codekit-append "_editor-columns.js";
// @codekit-append "_editor-column-actions.js";
// @codekit-append "_editor-modal.js";
// @codekit-append "_editor-jetpack.js";

// Backward Compatibility: WP 4.1
// @codekit-append "backward-compatibility/4.1/_editor-toolbars.js"

// @codekit-append "_editor-end.js";
// @codekit-append "_util.js";