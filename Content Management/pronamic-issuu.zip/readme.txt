=== Pronamic Issuu ===
Contributors: pronamic, remcotolsma
Tags: pronamic, issuu, pdf, document, deprecated
Requires at least: 3.0
Tested up to: 3.2
Stable tag: 1.0.1

Deprecated — Easily integrate Issuu documents into WordPress.

== Description ==

> This plugin is deprecated so Pronamic wil no longer support and maintain this plugin.
>
> If you want to help maintain the plugin, fork it on [GitHub](https://github.com/pronamic/wp-pronamic-issuu) and open pull requests.


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your 
WordPress installation and then activate the Plugin from Plugins page.


== Capabilities ==

*	read_issuu_documents
*	read_private_issuu_documents


== Screenshots ==

...


== Changelog ==

= 1.0.1 =
*	Added an deprecated notice.

= 1.0 =
*	Initial release


== Links ==

*	[Pronamic](http://pronamic.eu/)
*	[Remco Tolsma](http://remcotolsma.nl/)
*	[Markdown's Syntax Documentation][markdown syntax]

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
		"Markdown is what the parser uses to process much of the readme file"


== Pronamic plugins ==

*	[Pronamic Google Maps](http://wordpress.org/extend/plugins/pronamic-google-maps/)
*	[Gravity Forms (nl)](http://wordpress.org/extend/plugins/gravityforms-nl/)
*	[Pronamic Page Widget](http://wordpress.org/extend/plugins/pronamic-page-widget/)
*	[Pronamic Page Teasers](http://wordpress.org/extend/plugins/pronamic-page-teasers/)
*	[Maildit](http://wordpress.org/extend/plugins/maildit/)
*	[Pronamic Framework](http://wordpress.org/extend/plugins/pronamic-framework/)
*	[Pronamic iDEAL](http://wordpress.org/extend/plugins/pronamic-ideal/)

