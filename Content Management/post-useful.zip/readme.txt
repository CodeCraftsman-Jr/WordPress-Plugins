=== Post Useful ===
Contributors: leobaiano, nicholas_io
Donate link: http://lbideias.com.br/donate
Tags: vote, rate, useful
Requires at least: 3.8
Tested up to: 4.1.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows users to enter if the post is useful or not.

== Description ==

This plugin includes posts in the user option to inform the post content helped or not. It is suitable for use on blogs and websites that publish tutorials and recipes that help users.

= Contribute =

You can contribute to the source code in our [GitHub](https://github.com/leobaiano/post-useful) page.

== Installation ==

To install just follow the installation steps of most WordPress plugin's:

e.g.

1. Download the file post-useful.zip;
2. Unzip the file on your computer;
3. Upload folder post-useful, you just unzip to `/wp-content/plugins/` directory;
4. Activate the plugin through the `Plugins` menu in WordPress;
5. Be happy.

== Screenshots ==

1. Box for the user to sort the content.

2. Once the user sorts the post.

3. Box displaying the post classifications on the edit page.

= Credits =

* Translate: Marco Andrei <contact@marcoandrei.com>, Leo Baiano <ljunior2005@gmail.com>