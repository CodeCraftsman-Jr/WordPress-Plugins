<p class="error">
	<?= $message ?>
</p>