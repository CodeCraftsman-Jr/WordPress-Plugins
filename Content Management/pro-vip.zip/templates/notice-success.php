<p class="success">
	<?= $message ?>
</p>