<?php
wp_login_form();