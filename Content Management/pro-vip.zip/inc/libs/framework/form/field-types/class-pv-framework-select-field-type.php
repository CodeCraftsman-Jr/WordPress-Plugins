<?php
/**
 * @class          PV_Framework_Select_Field_Type
 * @version        1.0
 * @package        Phoenix Framework
 * @category       Class
 * @author         Vahidd
 */

defined( 'ABSPATH' ) or die; // Prevents direct access

class PV_Framework_Select_Field_Type extends PV_Framework_Form_Field_Type_Base {


	var $options;

	function __construct( $params ) {
		parent::__construct( $params );
		$this->options = $params[ 'options' ];
	}


	function display() {
		$output = '';
		$output .= PV_Framework_HTML::htmlDropDownList( $this->settings[ 'inputName' ], (string) $this->get_value(), $this->options, array( 'class' => 'form-control ' . $this->settings[ 'inputClasses' ] ) );

		return $output;
	}

}
