<?php

if ( ! defined( 'WPINC' ) ) {
	die;
}

return array(

	'creatorUrl'     => 'http://pro-vip.ir/',
	'latestNewsFeed' => 'http://pro-vip.ir/en/category/pro-vip/feed/'

);