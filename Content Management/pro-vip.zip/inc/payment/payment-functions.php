<?php

function wvGetGateway( $id = null ) {
	return Pro_VIP_Payment_Gateway::getGateway( $id );
}
