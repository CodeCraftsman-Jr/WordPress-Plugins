=== Pro VIP ===
Contributors: Pro-WP
Tags: vip,membership,downloads,shop
Donate link: http://pro-wp.ir/fa/payment
Requires at least: 3.6
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Sell files through wordpress

== Installation ==
1. Visit 'Plugins > Add New'
2. Search for 'Pro VIP'
3. Activate Pro-VIP from your Plugins page.

== Screenshots ==

1. VIP Settings.
2. File post edit.
3. Plugin Dashboard.
4. Admin payments list.
5. View payment.
6. Users VIP column.
7. Bulk edit.
8. User edit.
9. File view.
10. Purchase file.

== Changelog ==

= 0.1.2 - 15/07/2015 =
* Added - Pro-VIP API
* Added - SMS support
* Added - Custom Payment Form
* Localisation - Updated fa_IR languages files
* Bug Fixes

= 0.1.3 - 18/07/2015 =
* Added - Now guest users can purchase files without registering
* Bug Fixes

= 0.1.4 - 18/07/2015 =
* Fixed - Some RTL CSS styles
* Localisation - Updated fa_IR languages files
