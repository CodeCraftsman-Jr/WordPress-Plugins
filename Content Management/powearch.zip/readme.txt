=== Powearch ===
Contributors: ishihara takashi
Tags: search
Requires at least: 4.2.2
Tested up to: 4.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Release.Is a powerful search plugin for WordPress users.
Implements typeahead.js using a ingrimental search.

Start by pressing SHIFT key two times.

= Featured =

* Admin Menu Search
* Post Search
* Page Search
* Media Searchd
* Cusotom Post Type Search
* User Search
* Select a color scheme
* Select a trigger key
* Starting from the admin bar

Github repo

https://github.com/1shiharaT/powearch/


== Installation ==

1. Upload `powearch` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Startup screen
2. Setting page screen

== Changelog ==

= 1.0.0 =
Added setting page.

= 0.0.2 =
Added screenshot

= 0.0.1 =
create plugin.

