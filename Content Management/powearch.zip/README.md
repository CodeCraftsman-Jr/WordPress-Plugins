## Powearch - WordPress Launcher Plugin

![Powearch](http://zippy.gfycat.com/OnlySecondArabianhorse.gif)

After installation, nothing Let's press the shift key twice without thinking.
You should be able to understand what kind of plugins this plugin.

[WordPres Plugins Directory](http://wordpress.org/plugins/powearch/)

## Featured

* Admin Menu Search
* Post Search
* Page Search
* Media Search 
* Cusotom Post Type Search
* User Search
* Select a color scheme
* Select a trigger key


