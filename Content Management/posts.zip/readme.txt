=== Post Next ===
Contributors: umarbajwa
Tags: posts,next post,previous posts,post loop, best carousel slider, best post slider, best responsive slider, best slideshow, best slideshow plugin, carousel slider, custom post type, excerpt, get posts, google, image, image slider, image slideshow, images, new posts, new slider, news slider, next posts, nivo slider, owl slider, page, page slider, pages, popular posts, Post, post slider, post slider plugin, posts, posts slider, product slider, recent, recent post, recent post slider, recent posts, responsive carousel, responsive carousel slider, responsive slider, responsive slideshow, shortcode, sidebar, sidebar slideshow, slider, slider plugin, slideshow, sticky, testimonial scroller, thumbnail, thumbnail slider, ticker, widget, widgets, woocommerce, WooCommerce Products, woocommerce slider, wordpress, wordpress,posts,plugin,post,page, slideshow
Stable tag:2.0
Requires at least: 3.4
Tested up to: 4.3


Adds interactive sticky next post popup/optin.

== Description ==

Adds interactive sticky next post popup/optin.

Increase your blog post traffic by adding this powerful tool. Show them preview of next/Previous post. Select different layouts/designs to match with your theme.

> <strong>How Post Next attracts Visitors ?</strong>

> The Post Next plugin appends a popup/optin box at bottom corner of the page when user scrolls half height of current page which shows that visitor is interested in your content and wants to read more of your posts, So its beautiful design grabs user attention and guide them by showing a short preview of next or previous post.

== Installation ==

1. Upload \`plugin-name.php\` to the \`/wp-content/plugins/\` directory
1. Activate the plugin through the 'Plugins' menu in WordPress



== Screenshots ==


