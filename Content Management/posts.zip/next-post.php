<?php
/*
Plugin Name: Next Posts
Author: umarbajwa
Description: Create Next posts boxes in minutes for your WordPress websites.
Plugin URI: http://web-settler.com/mailchimp-subscribe-form/
Author URI: http://web-settler.com/mailchimp-subscribe-form/
Version: 1.0
Donate link: http://web-settler.com/mailchimp-subscribe-form/
*/

include 'includes.php';



 ?>