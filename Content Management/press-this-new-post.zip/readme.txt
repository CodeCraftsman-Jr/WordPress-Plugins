=== Press This New Post ===
Contributors: DrewAPicture
Tags: press this, new post, posting
Requires at least: 3.1.0
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a 'Press This' item to the '+ New' drop-down in the Toolbar for directly accessing Press This.

== Description ==

Easily access the direct link to your Press This posting form with this simple Toolbar addon. Use it from the front- or back-end as sort of a "Quick Draft on steroids" to easily start new posts on your site.

== Installation ==

1. Visit the Plugins > Add New screen in your WordPress admin, and search for "Press This New Post".
1. Click "Install Now", and when that's finished, click "Activate".

== Changelog ==

= 1.0 =
* First version.