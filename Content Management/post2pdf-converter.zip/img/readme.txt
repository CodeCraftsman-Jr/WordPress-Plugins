PDF icons are a part of "Crystal Clear" by Everaldo Coelho.
"Crystal Clear" is licensed under LGPL.

http://www.everaldo.com/