=== Pro Recent Comments ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: pro recent comments widget,widget,custom recent comments,advanced recent comments,pro recent comments,filter recent comments,custmize recent comments,recent comments,filter comments,custom comments
Requires at least: 2.9
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Pro Recent Comments Widget plugin.You have choice to customize your most recent comments.

== Description ==

Pro Recent Comments Widget plugin.You have choice to customize your most recent comments.

**Features**

1. You have choice to specific post comments only  show.
2. exclude any post comments.
3. set maximum no of comments.

More detail : http://socialcms.wordpress.com/


== Installation ==


1. Upload the **pro-recent-comments** folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go Appearance => widgets section  see **Pro Recent Comments**


== Frequently Asked Questions ==

* **How to only select post comments?**

  In pro recent comments  section post ids section add post id which post comment you want

* **How to exclude comments given post id?**

  In pro recent comments  section  exclude post id section add post id which post comment you want to exclude



== Screenshots ==

1. screenshot-1.png  : screen shot admin widgets section.


== Changelog ==

N/A

== Upgrade Notice ==

N/A