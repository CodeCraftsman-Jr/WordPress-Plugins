=== PS AUTO SITEMAP for Widget ===
Contributors: yyano
Tags: PS AUTO SITEMAP, sitemap, widget
Requires at least: 4.0
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display a sitemap that was created in PS AUTO SITEMAP.

== Description ==
This plugin will display the Sitemap of made ​​with  PS AUTO SITEMAP as widget.
PS AUTO SITEMAP is required to run.

== Upgrade Notice ==
none.

== Installation ==
1. Upload `psas-widget.php` to the `/wp-content/plugins/psas-widget/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Changelog ==

= 0.1 =
* First version.