=== Pro Categories Widget ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: pro categories widget,exclude categories widget,exclude categories,advanced categories widget,exclude categories,exclude category,category
Requires at least: 2.9
Tested up to: 4.3
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Pro Categories Widget plugin.You have choice to specific categories exclude.

== Description ==

Pro Categories Widget plugin.You have choice to specific categories exclude.

= Features : =

 1. You have choice to specific categories exclude.
 2. Show post count like WordPress category widget.
 3. Exclude multiple categories (comma separated).
 4. Show all categories.

More detail : http://socialcms.wordpress.com/


== Installation ==


1. Upload the **pro-categories-widget** folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go Appearance => widgets section  see **Pro Categories Widget**

== Frequently Asked Questions ==

* **How to show all categories with no post

Hide Category with no posts option ckeck box to uncheck

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.png.


== Changelog ==

= 1.2 =
* fix error multiple widget case

= 1.1 =
* Add hide category with no posts option

= 1.0 =
* Initial release

== Upgrade Notice ==

N/A
