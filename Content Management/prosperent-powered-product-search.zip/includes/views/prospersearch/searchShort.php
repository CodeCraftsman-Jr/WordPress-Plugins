<div style="<?php echo 'width:' . $pieces['w'] . $pieces['ws'] . ';' . $pieces['css']; ?>">
    <form class="searchform" method="POST" action="" rel="nolink">
        <input class="prosper_field" type="text" name="q" id="s" placeholder="<?php echo !$options['Search_Bar_Text'] ? 'Search Products' : $options['Search_Bar_Text']; ?>">
        <input class="prosper_submit" type="submit" value="Search">
    </form>
</div>
