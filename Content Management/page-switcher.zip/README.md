=== Page Switcher ===
Tags: page switcher, post switcher, switch, change page, smart search, switch pages
Requires at least: 3.0.0
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily change or switch the current page to other pages from the wordpress editor.

== Description ==
Easily change or switch the current page to other pages from the wordpress editor. It also adds a search widget to the dashboard to access your pages faster, also there is a added filter to post types as well. Also the main search box inside the page edot was replace with this plugin

== Installation ==
Install the plugin into the plugins/page-switcher directory, and activate.
From the post edit screen, above the \"Publish\" button is the \"Post Type\" interface.
Change post types as needed.

== Screenshots ==

1. This is the first screen shot
'/assets/screenshot-1.png'

2. This is the second screen shot
'/assets/screenshot-2.png'

3. This is the third screen shot
'/assets/screenshot-3.png'

4. This is the fourth screen shot
'/assets/screenshot-4.png'