=== Plugin Name ===
Contributors: pgogy
Tags: geo tag, kml, google maps
Requires at least: 3.1
Tested up to: 4.2.2
Stable tag: 0.3

Post Geo Tag allows a series of co-ordinates and place names to be attached to blog posts.

== Description ==

Post Geo Tag allows a series of co-ordinates and place names to be attached to blog posts.

This data can then be exposed as a KML layer people can access via a URL from your blog, or the blog owner can set up a page on the site and display the geo tags on a google map.

[vimeo https://vimeo.com/60042534]

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Tagging a post
2. An example map
3. KML Feed

== Frequently Asked Questions ==

No Questions have been asked yet. 

== Changelog ==
No changes yet 

= 0.1 =
First version released. Still a development version. I expect it to work, but problems may occur for some.