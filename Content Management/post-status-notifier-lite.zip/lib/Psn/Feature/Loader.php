<?php
/**
 * PSN feature loader
 *
 * @author    Timo Reith <timo@ifeelweb.de>
 * @copyright Copyright (c) 2014 ifeelweb.de
 * @version   $Id$
 * @package
 */
class Psn_Feature_Loader extends IfwPsn_Wp_Plugin_Feature_Loader
{
    protected function _init()
    {
        // add features
    }
}
