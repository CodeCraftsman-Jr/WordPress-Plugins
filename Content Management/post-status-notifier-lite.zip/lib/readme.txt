Due to compatibility reasons between other WordPress plugins, the external libraries got renamed:
Zend -> IfwZend (Zend Framework: http://framework.zend.com/)
Twig -> IfwTwig (Twig Template Engine: http://twig.sensiolabs.org)