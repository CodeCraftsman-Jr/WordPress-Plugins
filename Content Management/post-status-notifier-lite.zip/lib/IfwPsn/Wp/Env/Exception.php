<?php
/**
 * ifeelweb.de WordPress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 * 
 * IfwPsn_Wp_Env_Exception
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id$
 */
require_once dirname(__FILE__) . '/../Exception.php';

class IfwPsn_Wp_Env_Exception extends IfwPsn_Wp_Exception
{}
