<?php

class IfwPsn_Wp_Tpl_Text
{
    public function __($text, $domain)
    {
        return __($text, $domain);
    }
}
