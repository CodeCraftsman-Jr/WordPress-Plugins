<?php
/**
 * ifeelweb.de WordPress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 *
 *
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id$
 */
interface IfwPsn_Wp_Plugin_Application_Adapter_ZendFw_Autostart_Interface
{
    public function execute();
}
