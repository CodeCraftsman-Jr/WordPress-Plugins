<?php
/**
 * ifeelweb.de WordPress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 * 
 * Plugin_Bootstrap_Interface
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id$
 */
interface IfwPsn_Wp_Plugin_Bootstrap_Interface
{
    public function bootstrap();
}
