<?php
/**
 * ifeelweb.de WordPress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 * 
 * Wp_Plugin_Exception
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id$
 * @package   IfwPsn_Wp_Plugin
 */
class IfwPsn_Wp_Plugin_Exception extends IfwPsn_Wp_Exception
{}
