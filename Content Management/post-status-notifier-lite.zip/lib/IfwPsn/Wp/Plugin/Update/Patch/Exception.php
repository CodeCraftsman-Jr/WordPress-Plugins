<?php
/**
 * ifeelweb.de WordPress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 * 
 * Patch exception
 *
 * @author    Timo Reith <timo@ifeelweb.de>
 * @copyright Copyright (c) ifeelweb.de
 * @version   $Id$
 * @package   IfwPsn_Wp_Plugin_Update
 */ 
class IfwPsn_Wp_Plugin_Update_Patch_Exception extends IfwPsn_Wp_Plugin_Exception
{
}
