<?php
/**
 * ifeelweb.de WordPress Plugin Framework
 * For more information see http://www.ifeelweb.de/wp-plugin-framework
 * 
 * Module interface
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id$
 */
interface IfwPsn_Wp_Module_Bootstrap_Interface
{
    public function bootstrap();
}
