<?php
/**
 * Error controller
 *
 * @author   Timo Reith <timo@ifeelweb.de>
 * @version  $Id$
 * @package  IfwPsn_Wp
 */
class PsnErrorController extends IfwPsn_Zend_Controller_Error
{
}
