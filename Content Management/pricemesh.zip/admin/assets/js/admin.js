(function ( $ ) {
    "use strict";

    $(function () {

        // Place your admin-facing JavaScript here

    });

}(jQuery));