=== Prosperity ===
Contributors: hahncgdev
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YEM6BT83GHFD4
Tags: bible, bible verses about prosperity, wealth, bible verses, prosperity, scriptures, admin, donations, donate, wp plugin, plugin, widget, escrituras
Requires at least: 2.6
Tested up to: 4.2.2
Stable tag: 2.0.1

Displays random scriptures in posts and admin panel. Bible verses about prosperity. Prosperity Scriptures.

== Description ==

This plugin displays random bible verses concerning prosperity in posts using a shortcode. This plugin also displays random prosperity scriptures on every admin page. These are daily reminders will help you create a prosperous mindset and set you on the biblical path to create wealth.

**Newly Added: Widget functionality to be able to display scriptures in sidebar on every page.**

**Now with shortcode functionality to display scriptures in posts.**

*Prosperity scriptures tell us we can be wealthy, have prosperity, and live in abundance.*

For more information visit: <a href="http://labs.hahncreativegroup.com/wordpress-plugins/prosperity/" title="wp plugin Prosperity">Prosperity WP Plugin</a>

Other plugins: <a href='http://wordpress-photo-gallery.com/reflex-gallery-premium/'>ReFlex Gallery Pro</a>, <a href='http://wordpress.org/extend/plugins/reflex-gallery/' title='Responsive WordPress Photo Gallery'>ReFlex Gallery</a>, <a href="http://labs.hahncreativegroup.com/wordpress-gallery-plugin/" title="Easy WordPress Image Gallery">WP Easy Gallery Pro</a>, <a href="http://labs.hahncreativegroup.com/wordpress-plugins/custom-post-donations-pro/" title="Custom Post Donations Pro - PayPal Donations in WordPress">Custom Post Donations Pro</a>, <a href="http://wordpress.org/extend/plugins/wp-easy-gallery/" title="WP Easy Gallery">WP Easy Gallery</a>, <a href="http://wordpress.org/extend/plugins/custom-post-donations/" title="Custom Post Donations - PayPal Donations in WordPress">Custom Post Donations</a>, <a href="http://codecanyon.net/item/jquery-email-obfuscate-plugin/721738/?ref=HahnCreativeGroup">Email Obfuscate</a>, <a href='http://labs.hahncreativegroup.com/wp-translate-pro/'>WP Translate Pro</a> and <a href="http://wordpress.org/extend/plugins/wp-translate/">WP Translate</a>

== Installation ==

1. Upload the `prosperity` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

**Aug. 4, 2011 - v1.0**

* First Release

**Oct. 7, 2011 - v1.5**

* Added shortcode functionality to allow displaying of random scriptures in posts
* Newly added admin panel

**Oct. 28, 2011 - v2.0**

* Added widget functionality to allow displaying of random scriptures in sidebar
* Code refactored into classes to prevent namespace conflicts
* Scriptures added

**Nov. 22, 2011 - v2.0.1**

** Added missing verse citations

