=== PRyC WP: Add timestamp to style.css link ===
Contributors: PRyCpl
Tags: WordPress, Languages, style.css, timestamp, style
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add timestamp to style.css file

== Description ==

Add timestamp to style.css link (eg: style.css?1412863646&#038). Also works with child theme style.css

== Installation ==
1. Upload 'pryc-wp-add-timestamp-to-stylecss-link' dir to the '/wp-content/plugins/' directory
2. Activate the plugin through the \'Plugins\' menu in WordPress

== Screenshots ==

== Changelog ==
1.0.1: First public ver.