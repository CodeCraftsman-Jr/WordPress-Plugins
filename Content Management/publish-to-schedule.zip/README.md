Here you can see more information about this WordPress plugin:
https://wordpress.org/plugins/publish-to-schedule/

I'm using Git and a local build system with Jenkins to deploy it to WordPress Plugin on SVN.
Anytime I push to this repository on Github the SVN on WordPress will be updated too.

You can have more information on comments here:
https://github.com/alexbenfica/Publish-to-Schedule-WordPress-plugin/blob/master/build/git-to-svn.sh

