=== Pages Order ===

Author: SedLex
Contributors: SedLex
Author URI: http://www.sedlex.fr/
Plugin URI: http://wordpress.org/plugins/pages-order/
Tags: page, post, order, hierarchy, hierarchical
Requires at least: 3.0
Tested up to: 4.2
Stable tag: trunk
License: GPLv3

With this plugin, you may re-order the order of the pages and the hierarchical order of the pages.

== Description ==

With this plugin, you may re-order the order of the pages and the hierarchical order of the pages.

Moreover, you may add this hierarchy into your page to ease the navigation of viewers into your website

= Multisite - Wordpress MU =

This plugins is compatible with multisite installation of Wordpress.

= Localization =

* English (United States), default language
* Spanish (Chile) translation provided by Barbara
* Spanish (Spain) translation provided by Verto, Verto Producciones
* Italian (Switzerland) translation provided by Lamberto75
* Italian (Italy) translation provided by Lamberto75
* Portuguese (Brazil) translation provided by GilianedeJ.AlaminosNascimento

= Features of the framework =

This plugin uses the SL framework. This framework eases the creation of new plugins by providing tools and frames (see dev-toolbox plugin for more info).

You may easily translate the text of the plugin and submit it to the developer, send a feedback, or choose the location of the plugin in the admin panel.

Have fun !

== Installation ==

1. Upload this folder pages-order to your plugin directory (for instance '/wp-content/plugins/')
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to the 'SL plugins' box
4. All plugins developed with the SL core will be listed in this box
5. Enjoy !

== Screenshots ==

1. The tree view in the admin dashboard
2. The configuration page
3. The tree view displayed in the front pages
4. The breadcrumb displayed in the front pages

== Changelog ==

= 1.1.2 = 
* NEW: Delete temp files upon desinstall

= 1.1.1 = 
* NEW: Add icons

= 1.1.0 = 
* NEW: HOW TO
* NEW: Menu entry for pages

= 1.0.11 = 
* NEW: CSS updated

= 1.0.10 = 
* Stop using get_page which is deprecated

= 1.0.9 = 
* Improve the appearence of the plugin

= 1.0.7 = 
* Modification of the page plugin on wordpress

= 1.0.6 = 
* Lighten the plugin and add translations

= 1.0.5 = 
* Update the core

= 1.0.4 = 
* Correct a bug with some installation and the button

= 1.0.3 = 
* The look and feel of the frontend tree is improved

= 1.0.2 = 
* Add a breadcrumb and screenshots

= 1.0.1 = 
* First release

== Frequently Asked Questions ==

 
InfoVersion:46ed11e4a2374872924555d53a5ea62221ef027f