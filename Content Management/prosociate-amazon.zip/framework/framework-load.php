<?php

require_once PROSSOCIATE_ROOT_DIR.'/framework/options.php';


function Soflyy_time() {
	return time();
}