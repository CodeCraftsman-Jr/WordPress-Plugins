<?php

/**
 * Instance of the base plugin for use on the child template tags.
 *
 * @since    1.0.0
 */
function pc_base(){
    return new Purecharity_Wp_Base();
}