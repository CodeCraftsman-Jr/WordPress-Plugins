=== Plugin Name ===
Contributors: opr18
Donate link: http://thomas-roberts.co.uk
Tags: footer, analytics, javascript, paste
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: trunk
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows you to just add code that you want to be printed in the footer of your site.

== Description ==

This plugin allows you to just add code that you want to be printed in the footer of your site. Useful if you want to add google analytics code or something like that.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the 'print-stuff-in-footer' folder to the plugins directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. In the admin menu, edit the stuff that gets printed into the footer by clicking the "Print stuff in footer" link

== Frequently Asked Questions ==

= Can I add javascript to this? =

Yes

== Screenshots ==

No screenshots for this.

== Changelog ==

= 1.0 =
Made the plugin.

== Upgrade Notice ==

I don't know what this section is for
