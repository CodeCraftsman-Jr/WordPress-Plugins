=== PX Slider ===
Contributors: tikendramaitry, rahulbrilliant2004
Donate link: http://www.wpfruits.com
Tags: parallax slider, cool parallax slider, slider plugin, plugin
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 1.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
   

== Description ==
Try this an awesome Parallax Slider. Cool plugin plugin to add a parallax effect to your web page. One click install and quick backend settings make it easy to use for you.  

**Click here to see a demo** - <a href="http://www.wpfruits.com/downloads/wp-plugins/px-slider-wordpress-plugin/" target="_blank">Demo Url</a>

= Features =
* Easy to use: Just select the category you want to display and it will start working for you
* Ready-made Templates: PX Slider comes with 4 ready-made templates for you to choose from.
* Create your own template: If you want to do something creative yourself you can create your own template by just uploading the three layers of images and you are ready with your new template.
* Template Code/Short Code Ready: PXslider can be inserted anywhere on the page just use the Shortcode or if you want to insert it inside a page template you can use the template code too.
* Last but not the least its free.


**Click here to see a demo** - <a href="http://www.wpfruits.com/downloads/wp-plugins/px-slider-wordpress-plugin/" target="_blank">Demo Url</a>



Read more instructions about how to use here http://www.wpfruits.com/downloads/wp-plugins/px-slider-wordpress-plugin/

== Features ==
* Easy to use: Just select the category you want to display and it will start working for you
* Ready-made Templates: PX Slider comes with 4 ready-made templates for you to choose from.
* Create your own template: If you want to do something creative yourself you can create your own template by just uploading the three layers of images and you are ready with your new template.
* Template Code/Short Code Ready: PXslider can be inserted anywhere on the page just use the Shortcode or if you want to insert it inside a page template you can use the template code too.
* Last but not the least its free.


== Installation ==
1. Upload `px-slider` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Activate the plugin via the 'Plugins' menu in WordPress, you'll automatically redirected to plugin admin panel.
4. Plugin configuration settings are located in 'PXslider'.
5. Use '[pxslider]' shortcode inside WordPress post editor or use the '<?php if(function_exists("pxslider")) { pxslider(); } ?>'  template Code inside theme template file.


**For More Details please visit** - http://www.wpfruits.com/downloads/wp-plugins/px-slider-wordpress-plugin/

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==
1. The settings page.

== Changelog ==

= Version 1.2.2 =

* Fixed few styles and jQuery issues.
* Compatible with the WordPress latest version (3.9).

= Version 1.2.1 =

* Fixed few issues with WordPress 3.6.
* Fixed few styles and jQUery issues.
* Fixed few functionality issues.

= Version 1.2.0 =

* Added Custom Images option in admin panel.
* Fix some jquery issues with WordPress 3.5 version.
* Upload your own images instead of going through categories
* Fixed timthumb issue. 

= Version 1.0.1 =

* Fixed some jquery and style issues with WordPress 3.5 version

= Version 1.0.0 =

* Initial release.

== Upgrade notice ==
Please upgrade quickly.



== Arbitrary section 1 ==

