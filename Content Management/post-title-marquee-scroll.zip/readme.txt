=== Post title marquee scroll ===
Contributors: gopiplus, www.gopiplus.com
Donate link: http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/
Author URI: http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/
Plugin URI: http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/
Tags: post, title, marquee, scroll
Requires at least: 3.4
Tested up to: 4.2.2
Stable tag: 8.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
Post title marquee scroll is a simple wordpress plugin to create the marquee scroll in the website with post title.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/](http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/)

*   [Live Demo](http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/)	
*   [More info](http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/)				
*   [Comments/Suggestion](http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/)		
*   [About author](http://www.gopiplus.com/work/)			

Post title marquee scroll is a simple wordpress plugin to create the marquee scroll in the website with post title. In the admin we have option to choose the category and display order. We can add this plugin directly in the theme files. Also we have widget and short code option.

**Features of this plugin**

*   Easy to customize
*   Easy styles override option
*   Configurable scroll amount
*   Option to update scroll delay
*   Option to update the scroll direction
*   Option to pause the scroller on mouse over
*   Option to choose category
*   Option to select order
*   Option to enter number of post to scroll

[Click here](http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/) to see detail information about this plugin.	

**Plugin configuration**

*   Drag and drop the widget.		
*   Add directly in the theme.		
*   Short code for posts and pages.		
	
== Installation ==

[See Installation Instruction and Configuration information and Demo](http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/)	   

== Frequently Asked Questions ==

[Frequently Asked Questions](http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/)			

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/

2. Admin Screen. http://www.gopiplus.com/work/2011/08/08/post-title-marquee-scroll-wordpress-plugin/

== Changelog ==

= 1.0 =		
					
First version.

= 2.0 =	
						
Small short code bug fixed.

= 3.0 =

Tested upto 3.3			

= 4.0 =

Reset Query issue has been fixed.

= 5.0 =

Tested upto 3.4

= 6.0 =

New demo link, www.gopiplus.com

= 7.0 =

Slight changes in the short code.

= 7.1 =

Tested upto 3.5

= 8.0 =

Tested up to 3.6
Added some security feature.

= 8.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (post-title-marquee.po) available in the languages folder.

= 8.2 =

1. Tested up to 3.9

= 8.3 =

1. Tested up to 4.0

= 8.4 =

1. Tested up to 4.1

= 8.5 =

1. Tested up to 4.2.2

== Upgrade Notice ==

= 1.0 =	
						
First version.

= 2.0 =	
						
Small short code bug fixed.

= 3.0 =

Tested upto 3.3			

= 4.0 =

Reset Query issue has been fixed.

= 5.0 =

Tested upto 3.4

= 6.0 =

New demo link, www.gopiplus.com

= 7.0 =

Slight changes in the short code.

= 7.1 =

Tested upto 3.5

= 8.0 =

Tested up to 3.6
Added some security feature.

= 8.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (post-title-marquee.po) available in the languages folder.

= 8.2 =

1. Tested up to 3.9

= 8.3 =

1. Tested up to 4.0

= 8.4 =

1. Tested up to 4.1

= 8.5 =

1. Tested up to 4.2.2