﻿=== Publish On Screen ===
Contributors: parselearn
Donate link: http://wp-parsi.com/
Tags: Publish,on top, Top, Screen, Publish Button, Update Button, Save Button, RTL, Publish On Top, Floating Publish Button
Requires at least: 3.6
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later

A WordPress plugin that alters the position and behavior of the Publish button.

== Description ==

A WordPress plugin that alters the position and behavior of the Publish button, making it stick to the bottom of the page when scrolling down the page (RTL Support).

== Installation ==

1. Upload plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Preview

== Changelog ==

= 1.0 =
* First Release.