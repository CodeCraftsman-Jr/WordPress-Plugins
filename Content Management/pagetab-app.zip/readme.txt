=== PageTabApp.com Facebook Tab For Fan Page ===
Contributors: pagepress
Plugin Name: PageTabApp.com Facebook Tab For Fan Page
Plugin URI: http://www.pagetabapp.com
Author: PageTabApp.com
Tags: facebook fan page, wordpress, wordpress to facebook, wordpress to facebook fanpage, create facebook fan page, tab manager, facebook tab page
Requires at least: 3.0.0
Tested up to: 3.5
Stable tag: 1.10

This plugin will help to create Facebook Fan Page tab without any installation required.

== Description ==

PageTab is uniquely very different from other Fan Page Tab software because you don't need to create any Facebook app to use it, no installations required and you don't need to upload webpages separately, it can become your tab manager. It's amazingly simple to use and there is no hosting or SSL certification cost, we take care all of that for you. PageTab is free.

Sign up for free at http://pagetabapp.com/

== Installation ==

You can use the built in installer and upgrader, or you can install the plugin manually.

1. You can either use the automatic plugin installer or your FTP program to upload it to your wp-content/plugins directory the top-level folder. Just upload the folder "pagetab-app" to the directory /wp-content/plugins/.

2. Activate the plugin through the 'Plugins' menu in WordPress.

3. Watch the video tutorial how to sync your Wordpress post/ page with Facebook fan page http://www.youtube.com/watch?v=Ar-jhQr08ho

== Frequently Asked Questions ==

Please read these FAQs at http://pagetabapp.com/faq
