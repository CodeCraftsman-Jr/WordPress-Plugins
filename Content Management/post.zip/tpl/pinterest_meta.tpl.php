<p>
    <table class="form-table inside">
        <tr valign="top">
            <td>
                <label for="pinterest_url">URL of the image:</label><br/>
                <input type="text" id="pinterest_url" name="pinterest_url" value="<?php echo $pinterestImgUrl; ?>" class="widefat"/>
            </td>
        </tr>
    </table>
</p>