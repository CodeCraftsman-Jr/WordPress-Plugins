<?php

/******************************
* data processing
******************************/

// this function saves the data
function ggs_save_data() {

}