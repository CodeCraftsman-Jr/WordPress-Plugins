alert-box
=========

The alert box is a class built for WordPress developers to include in themes and plugins with the intent of providing a common structure for persistent alerts. 
