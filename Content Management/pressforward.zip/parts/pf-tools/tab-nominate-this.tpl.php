<?php
		pressforward()->form_of->nominate_this('as_paragraph');