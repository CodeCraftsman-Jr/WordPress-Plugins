<?php

/**
 * PressForward needs a little setup to be fully functional
 */

// Install the Relationships table
PF_Feed_Item_Schema::install_relationship_table();
