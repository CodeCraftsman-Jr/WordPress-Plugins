=== POST CATEGORY HEIGHT EDIT ===
Contributors: gqevu6bsiz
Donate link: http://gqevu6bsiz.chicappa.jp/please-donation/?utm_source=wporg&utm_medium=donate&utm_content=pche&utm_campaign=1_3
Tags: category, post, posts, post-new, category height, admin
Requires at least: 3.8
Tested up to: 4.1.1
Stable tag: 1.4
License: GPL2

It is adjustable plugin the height of the category meta box of edit posts screen.

== Description ==

== Installation ==

1. Upload `post-category-height-edit` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. The height of the portion of the Category has become to be able to change.
   Adjust the size by pulling the knob on the bottom right.

== Frequently Asked Questions ==

= A question that someone might have =

= What about foo bar? =

== Screenshots ==

1. This is a activated plugin.
2. This is category stretch.

== Changelog ==

= 1.4 =
* Added: Support to [Cunnections Business Directory](https://wordpress.org/plugins/connections/).

= 1.3 =
* Updated: Support to Custom Post Types.

= 1.2.2 =
* Updated: Resizable css print.

= 1.2.1 =
* Bug Fixed: Width setting of categories.
* Updated: Translation files.
* Updated: Action hook.

= 1.2 =
* Support SSL.
* Check 3.6.

= 1.1.1 =
I changed a little explanation.

= 1.1 =
Change to a one-year retention period for the category box height.

= 1.0.1 =
none the max-height css.

= 1.0 =
This is the initial release.

== Upgrade Notice ==

= 1.0 =

== Arbitrary section ==

日本語でのご説明:

このプラグインは、記事投稿画面と記事編集画面内にある、カテゴリを選択する部分の
高さを調整するプラグインです。
使い方はいたって簡単で、プラグインを有効にすると、カテゴリ選択部分の右下に、
小さな"つまみ"みたいなものが表示されているので、
それをつまんでお好みの高さに調節してください。