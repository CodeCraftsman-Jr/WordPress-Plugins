=== Preview ===
Contributors: previewapp
Tags: Preview, Preview App, discuss, management, comments, design, bug, tracker
Requires at least: 3.1
Tested up to: 4.0
Stable tag: 1.1.5
License: Preview App

Preview-App allow your wordpress to comments and discuss your webdesign and developpement against the Preview Web service to see if they look like and bugless.

== Description ==


Preview-App extension allow your wordpress to comments and discuss your webdesign and developpement against the Preview APP online tool to see if they look like and bugless.

Preview-app is an online revolutionary platform very complete wich allow you to manage digitals & colaborative projects online.
this platform allow you to unify all the digital work ( like ergonomics, graphism, developpment,check back) with a unic interface. 

If you need to share one or several mock up, or if you need a demonstration of an tablet or smartphone application, Preview-app give you tools to present and drive the development of your creations like no other solution.


PS: You'll need an [Preview APP account](http://Preview-app.net/) to use it.  

== Installation ==

1. Upload the Preview plugin to your website (to the '/wp-content/plugins/' directory)
2. Activate it throught the 'Plugins' menu in wordpress
3. Then you can use Preview App with your wordpress(http://www.preview-app.net/).


== Changelog ==


= 1.1.1 =
* Provide a Js to your wordpress to launch project and manage your work with Preview APP

= 1.1.2 =
* Provide a Js to your wordpress to launch project and manage your work with Preview APP

= 1.1.3 =
* allow iframe from preview

= 1.1.4 =
* remove local script

= 1.1.5 =
* minor modifications
