<?PHP
#-----------------------------------------------------------------------------------------
# IT ITALIANO LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Errore: uno o piu' elementi obbligatori sono mancanti
nel file config.php!";
$LANG_MISSING_VAR_H3="Si prega di ripetere lo script di configurazione,
lanciando il file install.php ";
$LANG_PERM_FILTER="Permesso negatio.  Richiesto il filtro.";
$LANG_GALLERIES="Gallerie Picasa";
$LANG_GALLERY="Galleria";
$LANG_IMAGES="immagini";
$LANG_PRIVATE="Privato";
$LANG_PUBLIC="Publico";
$LANG_WHERE="Luogo";
$LANG_ACCESS="Accesso";
$LANG_PHOTOS_IN="foto nel";
$LANG_ALBUMS="album";
$LANG_BACK="indietro alla lista degli album";
$LANG_PAGE="Pagina";
$LANG_GET="Preleva";
$LANG_GENERATED="Pagina generata da";
?>
