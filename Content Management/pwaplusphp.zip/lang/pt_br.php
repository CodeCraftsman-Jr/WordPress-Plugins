<?PHP
#-----------------------------------------------------------------------------------------
# PT-BR PORTUGUESE LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Erro: Uma ou mais variáveis necessárias não foram encontradas em config.php!";
$LANG_MISSING_VAR_H3="Por favor execute o arquivo de configuração install.php novamente.";
$LANG_PERM_FILTER="Permissão negada. Filtro obrigatório.";
$LANG_GALLERIES="Galerias do Picasa";
$LANG_GALLERY="Galeria";
$LANG_IMAGES="imagens";
$LANG_PRIVATE="Privado";
$LANG_PUBLIC="Público";
$LANG_WHERE="Local";
$LANG_ACCESS="Acesso";
$LANG_PHOTOS_IN="fotos em";
$LANG_ALBUMS="álbuns";
$LANG_BACK="voltar para lista de álbuns";
$LANG_PAGE="Página";
$LANG_GET="Baixar";
$LANG_GENERATED="Página gerada por";
?>
