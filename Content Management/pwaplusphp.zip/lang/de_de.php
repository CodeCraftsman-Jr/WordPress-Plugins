<?PHP
#-----------------------------------------------------------------------------------------
# GERMAN LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Fehler: Mindestens eine der benötigten Variabeln fehlen in der config.php!";
$LANG_MISSING_VAR_H3="Bitte das install.php-Konfigurationsskript noch einmal starten.";
$LANG_PERM_FILTER="Zugriff wegen fehlendem Filter verweigert.";
$LANG_GALLERIES="Picasa Galerien";
$LANG_GALLERY="Fotogalerie";
$LANG_IMAGES="Bilder";
$LANG_PRIVATE="Privat";
$LANG_PUBLIC="allgemein";
$LANG_WHERE="Ort";
$LANG_ACCESS="Zugriff";
$LANG_PHOTOS_IN="Fotos in";
$LANG_ALBUMS="Alben";
$LANG_BACK="Zurück zur Übersicht";
$LANG_PAGE="Seite";
$LANG_GET="Erhalten";
$LANG_GENERATED="Seite erstellt mit";
?>