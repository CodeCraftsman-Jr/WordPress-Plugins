﻿<?PHP
#-----------------------------------------------------------------------------------------
# PWA+PHP ÌÇÌN TR TÜRKÇE DÌL DOSYASI 
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Hata: config.php den bir veya birkaç gerekli değişkenler mevcut değil!";
$LANG_MISSING_VAR_H3="Lütfen install.php konum makalesini yeniden çalıştırın.";
$LANG_PERM_FILTER="Ìzin verilmedi.  Filitreme gerekli.";
$LANG_GALLERIES="Picasa Galerileri";
$LANG_GALLERY="Galeri";
$LANG_IMAGES="fotoğraflar";
$LANG_PRIVATE="Özel";
$LANG_PUBLIC="Genel";
$LANG_WHERE="Mevki";
$LANG_ACCESS="Erişim";
$LANG_PHOTOS_IN="fotoğraflar, kayıt yeri:";
$LANG_ALBUMS="albümler";
$LANG_BACK="Albüm listesine geri git";
$LANG_PAGE="Sayfa";
$LANG_GET="Al";
$LANG_GENERATED="Sayfayı oluşturan";
?>