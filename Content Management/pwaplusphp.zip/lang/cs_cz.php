<?PHP
#-----------------------------------------------------------------------------------------
# CZECH LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Chyba: Jedna nebo více povinných proměnných z config.php chybí!";
$LANG_MISSING_VAR_H3="Prosím spusťte znovu konfigurační skript install.php.";
$LANG_PERM_FILTER="Přístup odepřen.  Vyžadován filtr.";
$LANG_GALLERIES="Picasa galerie";
$LANG_GALLERY="Galerie";
$LANG_IMAGES="obrázky";
$LANG_PRIVATE="Soukromé";
$LANG_PUBLIC="Veřejné";
$LANG_WHERE="Umístění";
$LANG_ACCESS="Přístup";
$LANG_PHOTOS_IN="fotografie v";
$LANG_ALBUMS="alba";
$LANG_BACK="zpět na seznam alb";
$LANG_PAGE="Stránka";
$LANG_GET="Přijmout";
$LANG_GENERATED="Stránka vytvořena";
?>
