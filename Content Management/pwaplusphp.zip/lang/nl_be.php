<?PHP
#-----------------------------------------------------------------------------------------
# NEDERLANDSE VERTALING VOOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Fout: E�n of meer variabelen niet aanwezig in config.php!";
$LANG_MISSING_VAR_H3="Gelieve het configuratiescript opnieuw te installeren via install.php!";
$LANG_PERM_FILTER="Toegang geweigerd. Filter is vereist.";
$LANG_GALLERIES="Picasa Webalbum";
$LANG_GALLERY="Albums";
$LANG_IMAGES="fotos";
$LANG_PRIVATE="Priv�";
$LANG_PUBLIC="Openbaar";
$LANG_WHERE="Locatie";
$LANG_ACCESS="Toegang";
$LANG_PHOTOS_IN="fotos in";
$LANG_ALBUMS="albums";
$LANG_BACK="terug naar het album-overzicht";
$LANG_PAGE="Pagina";
$LANG_GET="Download";
$LANG_GENERATED="Pagina gegenereerd door";
?>
