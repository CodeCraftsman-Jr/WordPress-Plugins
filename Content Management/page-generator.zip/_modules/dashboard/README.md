WP Cube Dashboard Widget
=========================

Adds a Dashboard Widget to any WordPress Plugin, listing other available premium plugins from wpcube.co.uk