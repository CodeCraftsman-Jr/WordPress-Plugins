<?php
//This file allows you to store strings to be translated
//
//Usefull if you have a multilingual site
//and if you want to modify the 'Title text' displayed by page-navi-slider
//
//Just add your own string as show bellow ($a=__('your own string','page-navi-slider');)
//and update your language file with poedit.
//
//Your language files must be named page-navi-slider-(language code).mo and saved in the /lang directory
//
//Poedeit : http://www.poedit.net/
// 
$a=__('Page %%NUMBER%% of %%TOTAL%%','page-navi-slider');
?>