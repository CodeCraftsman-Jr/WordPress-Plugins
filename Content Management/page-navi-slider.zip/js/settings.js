jQuery.noConflict();
jQuery(function() {
	jQuery( "#wpns_tabs" ).tabs({});
	
	jQuery( "#wpns_resizable" ).resizable({
		handles: 'e'
	});

});