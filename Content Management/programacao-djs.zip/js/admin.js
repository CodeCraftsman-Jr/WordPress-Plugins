function my_confirm(mensagem,urldestino){
	if(confirm(mensagem)){
		document.location = urldestino;
	}
}