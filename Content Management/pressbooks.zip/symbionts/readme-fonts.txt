------------------------------------------------------------------------------
The following fonts are distributed with PressBooks
------------------------------------------------------------------------------

Cardo is Copyright (c) David J. Perry and released under the SIL Open Font License 1.1
@see: http://scholarsfonts.net

Crimson Text is Copyright (c) 2010, Sebastian Kosch (sebastian@aldusleaf.org) and released under the SIL Open Font License 1.1
@see: http://www.google.com/fonts/specimen/Crimson+Text

Linux Biolinum is Copyright (c) 2003–2012, Philipp H. Poll released under the SIL Open Font License 1.1
@see: http://www.linuxlibertine.org | gillian at linuxlibertine.org

Linux Libertine is Copyright (c) 2003–2012, Philipp H. Poll and released under the SIL Open Font License 1.1
@see: http://www.linuxlibertine.org | gillian at linuxlibertine.org

Marcellus is Copyright (c) 2012, Brian J. Bonislawsky DBA Astigmatic (AOETI) (astigma@astigmatic.com) and released under the SIL Open Font License 1.1
@see: http://www.google.com/fonts/specimen/Marcellus+SC

Oswald is Copyright (c) Vernon Adams and released under the SIL Open Font License 1.1
@see: https://github.com/vernnobile/OswaldFont

Roboto Condensed is copyright Christian Robertson and released under the Apache License, version 2.0
@see: http://www.google.com/fonts/specimen/Roboto+Condensed

Sorts Mill Goudy is Copyright Barry Schwartz and released under the SIL Open Font License 1.1
@see: http://www.google.com/fonts/specimen/Sorts+Mill+Goudy
