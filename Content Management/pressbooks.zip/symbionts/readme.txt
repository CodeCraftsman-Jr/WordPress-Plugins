------------------------------------------------------------------------------
About symbionts
------------------------------------------------------------------------------

Symbionts are 3rd party open source vendors that may or may not be licensed
under the GPLv2.

These additional libraries have their own licensing requirements and, as such,
should not be directly modified by PressBooks developers.

------------------------------------------------------------------------------

Operative verb is "should," the following libs have been patched/forked by PressBooks:

* custom-metadata (https://github.com/connerbw/custom-metadata)
