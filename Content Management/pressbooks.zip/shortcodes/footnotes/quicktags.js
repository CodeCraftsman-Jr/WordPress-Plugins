edButtons[edButtons.length] = new edButton('ed_fn', 'fn', '[footnote]', '[/footnote]', '');
