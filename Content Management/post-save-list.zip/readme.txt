=== Post Save & List ===
Contributors: markzero
Tags: save button, list posts, save, list
Tested up to: 4.1.1
Stable tag: 1.0.0

This plugin allows you to add Save button next to Publish button. When you click the Save button you'll get redirected to Posts list page.

== Description ==
This plugin allows you to add Save button next to Publish button. When you click the Save button you'll get redirected to Posts list page.

You can find this plugin also on https://github.com/markzero/post-save-list.

== Installation ==
Download the plugin, unzip it, place it under plugins/ directory and activate it.

