# Post Save & List

This plugin allows you to add Save button next to Publish button. When you click the Save button you'll get redirected to Posts list page.
