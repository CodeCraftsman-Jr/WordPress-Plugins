=== PagePressApp.com Auto Facebook Fan page Wall Post ===
Contributors: pagepress
Plugin Name: PagePressApp.com Auto Facebook Fan page Wall Post
Plugin URI: http://www.pagepressapp.com
Author: PagePressApp
Tags: facebook fan page, wordpress, wordpress to facebook, wordpress to facebook fanpage
Requires at least: 3.0.0
Tested up to: 3.5
Stable tag: 1.70

This plugin will help to publish your Wordpress blog's posts to your Facebook fan page's wall on auto-pilot.

== Description ==

It's a Facebook app that "syndicates" WordPress blog's content to a fan page. Basically, the app will enable the content posted on a WordPress blog to appear on a Facebook fan page and also the Wall automatically.

== Installation ==

You can use the built in installer and upgrader, or you can install the plugin manually.

1. You can either use the automatic plugin installer or your FTP program to upload it to your wp-content/plugins directory the top-level folder. Just upload the folder "pagepressapp" to the directory /wp-content/plugins/.

2. Activate the plugin through the 'Plugins' menu in WordPress.

3. That's it. You do not need to configure the plugin because it will automatically connects to your PagePress Dashboard at http://pagepressapp.com/member/

4. Make sure the "Auto Wall Post" option is activated in your PagePress Dashboard.

== Frequently Asked Questions ==

Please read these FAQs at http://pagepressapp.com/faq
