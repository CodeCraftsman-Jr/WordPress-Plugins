<?php
require_once('../../../wp-load.php');
require_once('../../../wp-admin/includes/admin.php');

do_action('admin_init');

?>