=== Pricing Table Dynamite ===
Contributors: jeffbullins
Donate link: http://www.thinklandingpages.com
Tags: pricing table, pricing tables, price table, price comparison chart, responsive pricing table, comparison, comparison table, css table, price, price gird, pricing, pricing box, pricing grid, table, pricing page, landing page, woocommerce, special offer, discount offer, offer, page, posts, post, widget, plugins, plugin, pricing table shortcode, pricing table plugin pro, pricing table ready, pricing table responsive, pricing table paypal
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily create a responsive pricing table for your Wordpress site in minutes.  Pricing tables have never been so easy to place on your site.

== Description ==

Easily create a responsive pricing table for your Wordpress site in minutes.  Pricing tables have never been so easy to place on your site.

* Sell as many products as you want with Unlimited Pricing Tables
* No Coding means anyone can create a pricing table
* Edit the content right on the pricing table and know exactly what it will look like
* Professional pricing table template so you don’t have to design anything
* Easily place a pricing table on any post or page
* Responsive design for mobile

[Upgrade to the Pro version!](http://www.thinklandingpages.com/special/pricing-table-dynamite/)

Pricing tables are an essential part of selling anything online.  You need your pricing table to look good.  The pricing table dynamite plugin delivers the pricing tables you need to be successful.

###Sell as many products as you want with Unlimited Pricing Tables

Create an unlimited amount of beautiful pricing tables that will get you the sale.  We have integrated state of the art technology with the Wordpress plugin api to deliver a pricing table plugin that gives you what you want.  

###No Coding means anyone can create a pricing table

With the pricing table dynamite plugin, you can create pricing tables in minutes without any html, javascript, or css coding.  Never again wonder what your pricing tables will look like.

###Edit the content right on the pricing table and know exactly what it will look like

Gone are the days of filling out a bunch of form fields and opening another window to see what your pricing tables look like.

Pricing Table Dynamite gives you the ability to edit the content right on the table itself.  That's right, click on the content in the table and start editing just like you would when typing a paper.  

Do you want to add a new row or column to your pricing table?  Just click a button on the pricing table edit page and instantly a new row or column will appear on your pricing table.  If you decide you don't want the row or column, click the delete button on the pricing table edit page and the row or column goes away.  It is that easy.

You can add as many rows as you want to each column of your pricing tables.  You also can add an unlimited number of columns to each pricing table, but you may want to keep the number of columns to 10 or less because the text will start to have problems with flowing and you customers may become confused by all of the information on one pricing table.

Each column has a header for you to define the package/product name represented on the pricing table.

You then get a custom pricing column that is designed to standout on your pricing table.  You can place a different price in each column’s pricing row.  You also have the option the leave any pricing row blank if you don’t want show a price for that column of the pricing table.

When you want to add more rows, just click the add row button under the column you want the row added to.  A new row will be created in the correct column on your pricing table.  You can then edit the default text right in place.  If you decide you don’t want the row, there is a delete link under the text of each row.
Call to action button with easy linking

Each row is equipped with a call to action button that allows you to edit the text and save a link to send you customers to when they click the button on your pricing table.  To edit the text, just click on it and start typing right on the landing page.

To save a link to send you customers to for payment processing, just double click the call to action button on the pricing table edit page and a box will popup for you to save your link.

###Professional pricing table template so you don’t have to design anything

The pricing tables created with the Pricing Table Dynamite plugin will give a polished, professional look to your offers so your customers will know you mean business.  The handcrafted, professional design would take a highly skilled developer days to create. 

###Easily place a pricing table on any post or page

Once you create a pricing table, you can easily place it on any post or page with the following shortcode, [ptd_pricing_table tableid="468"].  Place the shortcode anywhere you want the pricing table to appear.

###Responsive design for mobile

All of your pricing tables created with Pricing Table Dynamite are mobile friendly.

The core design is based on the Foundation Framework responsive pricing table.  We leverage their work and then added our touch to make the pricing tables work seamlessly with your Wordpress site.  The Foundation Framework api is not used or need for the plugin to work.  

[Upgrade to the Pro version!](http://www.thinklandingpages.com/special/pricing-table-dynamite/)


== Installation ==


1. Upload `pricing-table-dynamite` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Click **Pricing Table Dynamite** on the admin menu to enable and set your options.


== Frequently Asked Questions ==

= Do I have to know how to program or design to use the pricing tables? =

No.  The plugin does all the heavy lifting.  You just edit your pricing table on the screen.

= How many pricing tables can I create? =

You can create an unlimited amount of pricing tables.

= Can I change the colors of the pricing tables? =
The pro version of the plugin give you the ability to change the colors of you pricing tables.


== Screenshots ==

[See screenshots at thinklandingpages.com] (http://www.thinklandingpages.com/pricing-table-dynamite-quick-start/)

== Changelog ==

= 1.0 =
* First Release


