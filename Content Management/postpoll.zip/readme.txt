=== Postpoll ===
Contributors: k2klettern
Tags: Poll, Encuesta, Postpoll, Postpoll-api, poll, poll of post, post poll, poll of posts, posts poll
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 0.1.3
License: GPLv2 or later

Postpoll allows admin to set a poll of all or some of posts in the wordpress to vote.

== Description ==

Postpoll allows admin to set a poll of all or some posts in the wordpress to vote..

Major features in Postpoll include:

* Creation of more than one poll.
* Filtering per user login, set a voted cookie to avoid more votes on a simple visit, show or hide results to voter.
* Create all polls as you need
* View a report of results
* Widget to show the poll on sidebars
* Use of the post thumbnail on poll and results
* Uses Ajax


== Installation ==

Upload the Postpoll plugin to your blog, Activate it, begin to create polls.

1, 2, 3: You're done!

== Screenshots ==

1. Add an administration Menu to manage the polls
2. You can Edit your poll, adding the posts to it. You can see how it will be show the poll on the front and select which method you want to use (selector, radio, multiple)
3. A widget is provided to show the poll with a Selector
4. This is how you will see a poll in your Widget with multiple option mode to Vote, also with the posts thumbnail option on
5. If you set to show totals after use vote this is how user will see it


== Changelog ==

= 0.1.0 =
*Release Date - 18th Juny, 2015*

* First Release

= 0.1.1 =
*Release Date - 23rd Juny, 2015*

*Added Cookies for voting only one time for each poll
*Added the option to include the image thumbnail of the post as mini-thumbnail on the poll
*Upgrade of logged user option
*Upgrade of AJAX service to allow more than one poll on the same page

= 0.1.2 =
*Release Date - 10n July, 2015*

*Added Spanish translation
*Added .pot file for translate with any language

= 0.1.3 =

*Change of functions to PHP5 for support of WP4.3

