=== Prettier Trackbacks ===
Contributors: wp_guy
Tags: comments, trackbacks, pingbacks, ellipsis
Requires at least: 2.0
Tested up to: 2.5.1
Stable tag: trunk

== Description ==

Prettier Trackbacks replaces the "[...]" found at the beginning and end of every trackback in your block for just the "..." or whatever you specify.

== Installation ==

To install the plugin just follow these simple steps:

1. Upload `prettier-trackbacks.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it. Additionally you can go to Plugins > Edit Plugins > Prettier Trackbacks and change what the plugin replaces the "[...]" for.
