=== PageRank ===
Contributors: Yatko
Donate link: http://www.yatko.com/
Tags: pagerank, page rank, google, rank, google rank, google page rank, site rank, button, pagerank button, pagerank display, pagerank check, pagerank checker, plugin, plugins, widget, page, analytics, keywords, meta, seo, sidebar, simple, stats, hit, tracking
Requires at least: 2.0.2
Tested up to: 2.9.1
Stable tag: 1.0.0

statistX PageRank displays the Google (TM) PageRank of your WordPress blog.

== Description ==

statistX PageRank displays the Google (TM) PageRank of your WordPress blog.
The widget is automatic and can be configured to display different button styles.

Visit <a href="http://pr.statistx.com/pagerank-display.php" target="_blank">Free pagerank Display</a> for details.

== Installation ==

1. Upload `pagerank.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
3. Activate the PageRank Widget and set the Button Style (Style)

== Frequently Asked Questions ==

= What is the statistX PageRank  =

statistX PageRank displays a small button on your blog that shows the Google (TM) PageRank of your page.
The widget is completely automatic and can be configured to display the button style that fits your design.

== Changelog ==

= 1.0.0 =
* First version

== Upgrade Notice ==
* none

== Screenshots ==
* none
