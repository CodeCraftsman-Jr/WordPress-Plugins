=== Posts Slider===
Contributors:Umarbajwa,websettler
Donate link: http://web-settler.com/posts-slider/
Tags:banner rotator, best carousel slider, best post slider, best responsive slider, best slideshow, best slideshow plugin, bxslider, carousel slider, excerpt, featured thumbnail, get posts, image, image slider, image slideshow, images, logo scroller, news slider, nivo slider, owl slider, popular posts, Post, post slider, post slider plugin, posts, posts slider, recent, recent post, recent post slider, recent posts, responsive carousel, responsive carousel slider, responsive slider, responsive slideshow, royal slider, scroll, showcase, sidebar slideshow, slider, slideshow, sticky, testimonial scroller, thumbnail, thumbnail slider, ticker, wordpress slideshow, wow slider
Requires at least:3.1 
Tested up to: 3.9.2
Stable tag:3.0
License:GPLv2 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Posts Slider is a WordPress posts content slider plugin with touch for mobile devices. You can slide custom post types with custom taxonomies.Carousel + single slide slider.

==Description==
Posts Slider is a WordPress posts content slider plugin with touch for mobile devices. Posts slider displays your blog's recent posts using beautiful slider. Description Posts slider is light weight touch supported, responsive posts content slider plugin.Manage your posts to show in slider with custom taxanomies (categories, tags,authors e.t.c), With pre-designed layouts to save your time. Simple and easy to use no coding skills required.

* Responsive touch slider.
* Carousel + single slide slider option.
* Fully Customizable slider.
* Select how much posts to display and order them by popularity or date.
* Entire slide links to post.
* Fast support + Free Updates.
* Mouse Draggable
* Pre-designed layouts.
* Limit words of description (i.e excerpt).
* Select what taxonomies to include in carousel (categories, tags, author e.t.c.).
* More transition effects.
* Gradients Supported.


Wants to create Unlimited Sliders <a href='http://web-settler.com/posts-slider/' target='_blank'>Get Premium Version</a>


== Screenshots ==

For Screenshots and more inforamtion Visit: <a href="http://web-settler.com/posts-slider">Screen Shots</a>


 == Installation ==
* Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

* Use shortcode to make slider visible.


== Changelog ==

= 3.0 =
* Included All features for free.
* Can create unlimited slider.






