=== Post Paging ===
Contributors: tomek00
Tags: post paging, pagination, next and previous post, next post link, post navigation, navigation, previous post link
Donate link: http://wp-learning.net/blog/felajanl
Requires at least: 4.0
Tested up to: 4.1.1
Stable tag: trunk

Show next and previous post links at posts

== Description ==
Show next and previous post links at posts

== Installation ==

1. Extract the plugin folder from the downloaded ZIP file.
2. Upload paging folder to your /wp-content/plugins/ directory.
3. Activate the plugin from the "Plugins" page in your Dashboard.

== Frequently Asked Questions ==
None

== Screenshots ==
1. screenshot-1.png
2. screenshot-2.png

== Upgrade Notice ==
Nothing

== Changelog ==

None