=== Page Cornr for October===
Contributors: Cathy Tibbles, luciano, 
Tags: breast cancer, page flip, page peel, corner
Requires at least: 2.7
Tested up to: 2.8.4
Stable tag: 1.1.4
Page Cornr has been modified by Desperately Seeking WordPress 
on the occasion of Pink for October & Breast Cancer Awareness.

== Attribution == 
Ribbon courtesy of http://carolsutton.net
Based on the original Page Cornr Plugin vby Luciano.

== Description ==
Displays a pink Breast Cancer Awareness ribbon on the top right corner.  When hovered over, it will expand to approx. 300px. When clicked, it leads to Susan G. Komen foundation.
Page Cornr has been modified by Desperately Seeking WordPress 
on the occasion of Pink for October & Breast Cancer Awareness.

== Installation ==
1. From the plugin menu in wordpress, upload plugin to your installation.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. That's it - there are no configurations.  For the original plugin visit http://www.luxiano.com.ar/page-cornr/, 
which includes a settings page to modify the image and text behind the page curl.

==Frequently Asked Questions === 
Does it works with IE? 
=Yes! IE 6 included!


== Changelog === 
1.1.1 - added link to Susan G. Komen foundation
1.1.2 - added missing images
1.1.3 - added missing images again! 
1.1.4 - display with shadow on recover

== Screenshots ==
1. Top right hand corner of our website
2. Page Cornr, when hovered with mouse