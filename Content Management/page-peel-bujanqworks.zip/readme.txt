=== Page Peel BujanQWorkS ===
Contributors: bujanq, bodsink
Donate link: http://www.herukurniawan.com/donation/
Tags: page peel, banner, ads, plugin, content, page
Requires at least: 1.3
Tested up to: 2.8.5
Stable tag: 1.3

page peel bujanqworks you make in your advertising and promotion is very easy to use.

== Description ==

What is a Page Peel? Page Peel is the banner ads in web corner if we focus on the mouse cursor will display in the ad folding effect that large ads open. And if the ad is clicked will lead to other web pages that show advertisements.

Page Peel is the development BujanQWorkS page peel made by christian Harz for the web - web custum / or homemade. To be used for wordpress without opening the source code embedded in the template file, bind BujanQWorkS this source into a user friendly plugin.

== Installation ==

Step - Step

    1. Download file plugin page-peel-bujanqworks.zip
    2. Install the plugin in the plugins menu
    3. For the configuration BujanQWorkS page peel can be seen from the Settings menu on the Dasbord wp-admin.
    4. to version 1.3 can only make changes to the small banners, large banner and URL address

== Screenshots ==
1. screenshot Peel BujanQWorks
1. option Page Peel BujanQWorks

== Changelog ==

= 1.3 =

* changes variabel support Wordpress 3.0

= 1.2 =

* changes in the database table structure
* additional features color choices, shadow and target link

= 1.1 =

* Change folder name 'page-peel-bw' to 'page-peel-bujanqworks' 

= 1.0 =

* The First Version
