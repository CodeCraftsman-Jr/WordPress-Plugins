<?php echo $item["layout"]["name"] ?>

      <?php if ($item["layout"]["configuration"]["show_slider"]) { ?>
        with slider

      <?php } ?>
<br>
<small>
  <?php echo $item["layout"]["width"] ?>px &times; <?php echo $item["layout"]["height"] ?>px
</small>
