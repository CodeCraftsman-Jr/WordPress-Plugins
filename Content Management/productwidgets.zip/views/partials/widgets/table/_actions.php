<div class='widget-preview-container' id='preview-<?php echo $item["identifier"] ?>'>
  <div class='widget-preview-wrapper'></div>
</div>
<a class='button thickbox widget-preview-button' data-js-code='<?php echo $item["js_code"] ?>' href='#TB_inline?width=<?php echo $item["layout"]["width"] + 20 ?>&height=<?php echo $item["layout"]["height"] + 20 ?>&inlineId=preview-<?php echo $item["identifier"] ?>'>
  Preview
</a>
