<textarea class='autoselect' readonly>[productwidget id="<?php echo $item["identifier"] ?>"]</textarea>
