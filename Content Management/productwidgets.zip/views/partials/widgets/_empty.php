<h3>
  You have not added any widgets yet.
</h3>
<p>
  To add your first widget, click the "Add New" button above.
</p>
<p>
  Once you have added at least one widget, a list of your widgets
  <br>
  with stats about impressions and clicks will appear here.
</p>
