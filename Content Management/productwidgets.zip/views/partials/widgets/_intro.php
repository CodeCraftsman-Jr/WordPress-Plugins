<p>
  This screen shows a list of all your widgets. If you recently added a new widget, it might take a couple of minutes before it shows up here.
</p>
<div id='widgets'></div>
