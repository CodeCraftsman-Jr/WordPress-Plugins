<div class='ajax-loader'>
  <img src='<?php echo $this->plugin_url."images/ajax-loader.gif" ?>'>
  Loading, please wait...
</div>
