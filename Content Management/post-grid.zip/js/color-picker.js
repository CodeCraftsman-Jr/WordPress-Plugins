	jQuery(document).ready(function(jQuery)
		{	


			jQuery('#post_grid_title_color,#post_grid_content_color').wpColorPicker();
					
					


		});