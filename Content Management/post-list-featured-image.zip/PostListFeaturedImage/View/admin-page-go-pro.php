<?php
if ( !defined( 'ABSPATH' ) || preg_match(
		'#' . basename( __FILE__ ) . '#',
		$_SERVER['PHP_SELF']
	)
) {
	die( "You are not allowed to call this page directly." );
}
?>
<div class="go-pro">
	<div class="instr-vid">
        <iframe width="560" height="315" src="//www.youtube.com/embed/-LVmTTcLyLs?rel=0" frameborder="0" allowfullscreen></iframe>
	</div>
	<div style="clear:both;"></div>
	<div id="link-btns">
		<a href="http://jaggededgemedia.com/pro-plugins-shop/" target="_blank">
            <button id="pro-btn">Go Pro NOW!</button>
		</a>
	</div>
</div>
