=== Plugin Name ===
Contributors: roycegracie
Donate link: http://www.zeevm.co.il
Tags: gallery, post gallery, post archive, post
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

this plugin create a gallery/archive of posts. you can decide how many words will be Shawn under each post and more. used very easily using the shortcode: [post-gallery cat="1" words="10" onpage="5"]

by using this plugin you can present the posts of every category in a very nice way, much more orgenized than how most themes do it.

*it's fully responsive.
== Installation ==


1. Upload `post-gallery-and-archive folder` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. create some posts with fetured images in them.
4. add the shortcode any ware in your site (posts or pages): [post-gallery cat="1" words="10" onpage="5"]
5. that is it ! now you can see the post archive / gallery

== Frequently Asked Questions ==

= can i change the number of posts presented on page ? =
yes ! the value "onpage" is in charge of this, just weite the number of posts you want to show. if you want to show them all, just leave it blank or write "999".

= can i show all posts from all categories ? =

yes, just leave the "cat" value blank, like this: cat=""

= how can i tell what is the category ID ? =

well, that is easy ! when you press on the category you will see up on the browser address bar the ID of the cat.
see here:
http://www.wprecipes.com/how-to-find-wordpress-category-id

== Screenshots ==

1. this is an example of how it will look like 


== Changelog ==

= 1.0 =
this is the first version


== A brief Markdown Example ==

Ordered list:

1. more options to the admin panel for better flexibility
2. translation PO&MO files


Here's a link to [WordPress](http://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`
