=== PRyC WP: Widget Shortcode ===
Contributors: PRyCpl
Tags: WordPress, widget, widgets, support, shortcode, shortcodes
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add shortcode support to widgets

== Description ==
Add shortcode support to widgets

== Installation ==
1. Upload `pryc-wp-widget-shortcode` dir to the `/wp-content/plugins/` directory
2. Activate the plugin through the \'Plugins\' menu in WordPress

== Screenshots ==

== Changelog ==
1.0.1: First public ver.