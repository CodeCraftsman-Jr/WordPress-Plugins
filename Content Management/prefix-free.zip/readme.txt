=== -Prefix-Free for WordPress ===
Contributors: CCDzine
Requires at least: 
Tested up to: 4.2
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Eliminates the need for vendor prefixes in CSS by including open source -Prefix-Free.

== Screenshots ==



== Changelog ==

1.0

* Initial Release