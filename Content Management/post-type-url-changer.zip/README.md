# Post Type URL Changer

Ever wanted to have an archive page with any post type, but you thought I don't need a specific post to point visitors to it's page rather to a custom one, 
than this plugin does that.
Use any post type and make it direct wherever you want, eg having a Product at a another store but you thought to do some addvertisement at your site than this does the trick

Installation

* Upload `post-type-url-changer` to the `/wp-content/plugins/` directory
* Activate the plugin through the 'Plugins' menu in WordPress
* Go to Settings - Post Type URL Changer and enable it for the post types you want