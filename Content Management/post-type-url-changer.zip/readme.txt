=== Plugin Name ===
Contributors: burimshala
Donate link: http://themeforest.net/user/UmbrellaStudios
Tags: url, post, type
Requires at least: 3.4
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Edit any post URL to a custom one

== Description ==

Ever wanted to have an archive page with any post type, but you thought I don't need a specific post to point visitors to it's page rather to a custom one, 
than this plugin does that.
Use any post type and make it direct wherever you want, eg having a Product at a another store but you thought to do some addvertisement at your site than this does the trick

== Installation ==

1. Upload `post-type-url-changer` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings - Post Type URL Changer and enable it for the post types you want