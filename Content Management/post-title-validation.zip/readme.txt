=== Post-title-validation ===
Contributors: pranavpathakjaora
Tags: Title validation, Post, Page
Requires at least: 3.5.1
Tested up to: 4.2.2
Stable tag: 1.1
Version: 1.1
License: GPLv2 or later

The Post-title-validation Plugin helps to create validation on title field of post, page, custom content type.

== Description ==
The Post-title-validation Plugin helps to create validation on title field of post, page, custom content type. If user will not enter title field then it will alert user that "Please insert title".


= Requirements =

* WordPress 3.5.1 or greater
* PHP 5.2.6 or greater (5.3 recommended)
* MySQL 4.1.2 or greater (5.x recommended)

== Installation ==

This plugin uses the standard installation procedure: install the plugin's folder inside of 'wp-content/plugins' (make sure the folder is named *Post-title-validation*).


== Changelog ==
Jquery trim() function is added in post-title-validation.js file.


== Frequently Asked Questions ==

Is it works for custom content type?
Yes it works.