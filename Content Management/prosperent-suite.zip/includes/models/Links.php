<?php
require_once(PROSPER_MODEL . '/Base.php');
/**
 * Search Model
 *
 * @package Model
 */
class Model_Links extends Model_Base
{
	public function __construct()
	{

	}
}