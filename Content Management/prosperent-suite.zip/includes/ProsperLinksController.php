<?php
/**
 * ProsperLinks Controller
 *
 * @package 
 * @subpackage 
 */
class ProsperLinksController
{
    /**
     * the class constructor
     *
     * @package 
     * @subpackage 
     *
     */
    public function __construct()
    {
    }
}
 
$prosperLinks = new ProsperLinksController;