<?php
class PostsMapsAdminServices {

	public function __construct() {
	}
}
?>