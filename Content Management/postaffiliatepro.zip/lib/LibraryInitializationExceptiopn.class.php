<?php
/**
 *   @copyright Copyright (c) 2007 Quality Unit s.r.o.
 *   @author Juraj Simon
 *   @package WpPostAffiliateProPlugin
 *   @version 1.0.0
 *
 *   Licensed under GPL2
 */
if (!class_exists('LibraryInitializationException')) {
    class LibraryInitializationExceptiopn extends Exception {}
}
?>