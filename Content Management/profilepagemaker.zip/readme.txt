﻿=== ProfilePageMaker ===


Contributors:國島惇

Requires at least:WordPress 3.9.7


Tested up to:WordPress 4.2.3


Stable tag:1.1

Here is a short description of the plugin. This should be no more than 150 characters. No markup here.
プロフィールのページを作成することができます。プラグイン内で作成したソースを投稿や固定ページに投稿して使用します。

== Description ==
プロフィールのページを作成することができます。プラグイン内で作成したソースを投稿や固定ページに投稿して使用します。
プロフィールページ内にはJavaScriptが組み込まれているので動きのあるページがご堪能いただけます。

== Installation ==
プラグインページの新規追加から追加してください。


== Changelog ==更新履歴を書いていきます。
= 1.0 =
* 公開開始

= 1.1 =
* 文言修正

