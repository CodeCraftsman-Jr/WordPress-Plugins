=== Product View Counter ===
Contributors: aihimel
Tags: woocommerce, product, view counter
Requires at least: 4.2.2
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

The plugin keeps track your product pageviews of today, yesterday, last week and total views.


== Description ==

This is a wordpress and woocommerce extension that keeps track of your product page view.
It categories the views into today, yesterday, last week and total.


== Installation ==

The installation process is very simple.

1. Install and activate Woocommerce.
1. Install Product View Counter plugin from wordpress plugin directory or upload the plugin manually to your server at /wp-content/plugins/ directory.
1. Activate the plugin through 'Plugins' menu in the Wordpress Administrator.
1. Go to Woocommerce >> Product View Counter.


== Frequently Asked Questions ==

= Will I support the plugin? =

Yes, I will support the plugin.


== Screenshots ==

1. View in single product page.
2. Plugin options.

== Changelog ==

= 1.0 =
* Initial Release
