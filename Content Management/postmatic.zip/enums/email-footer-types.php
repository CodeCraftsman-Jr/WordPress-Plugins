<?php

class Prompt_Enum_Email_Footer_Types {
	const WIDGETS = 'widgets';
	const TEXT = 'text';
}