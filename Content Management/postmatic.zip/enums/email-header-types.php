<?php

class Prompt_Enum_Email_Header_Types {
	const IMAGE = 'image';
	const TEXT = 'text';
}