<?php

class Prompt_Enum_Content_Types {
	const TEXT = 'text/plain';
	const HTML = 'text/html';
}