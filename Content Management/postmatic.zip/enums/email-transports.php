<?php

class Prompt_Enum_Email_Transports {
	const LOCAL = 'local';
	const API = 'api';
}