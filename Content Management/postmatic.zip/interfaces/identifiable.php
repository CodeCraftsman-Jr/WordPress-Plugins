<?php

/**
 * An interface for objects that can return an ID.
 */
interface Prompt_Interface_Identifiable {
	function id();
}