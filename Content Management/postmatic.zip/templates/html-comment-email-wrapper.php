<?php
$is_comment = true;
include dirname( __FILE__ ) . '/html-email-wrapper.php';
