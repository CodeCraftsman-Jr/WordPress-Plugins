=== PostRank ===
Contributors: JinnLynn
Tags: views,  rank, counter, postviews, post, page
Requires at least: 2.7
Tested up to: 3.4.2
Stable tag: 0.1.3

== Description ==

The ranking of your posts. Visit [Plugin Page](http://jeeker.net/projects/postrank/ "PostRank") for usage information and project news.

== Screenshots ==

1. Admin page

== Installation ==

1. Upload `postrank` to your `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.