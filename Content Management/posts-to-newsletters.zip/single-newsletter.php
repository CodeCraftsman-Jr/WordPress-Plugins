<!DOCTYPE HTML>
<html><head><META http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body style="margin:0">

<?php
the_post();  
the_content();
?> 

</body></html>