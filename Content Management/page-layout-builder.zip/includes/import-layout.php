<div style="padding: 10px;">
<form action="" enctype="multipart/form-data" method="post">
<input type="hidden" name="wpmxtask" value="importlayout">
Upload Import File:                               
<input type="file" name="importlayout"> <br><br>
<input type="submit" class="ui-button ui-widget ui-state-default ui-corner-all" value="Upload and Import">
</form>
</div>
