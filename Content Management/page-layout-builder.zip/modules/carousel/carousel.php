<?php
/*
Plugin Name: Post Carousel
Plugin URI: #
Description: Carousel Module using CarouFredSel
Author: Shaon
Version: pro_only
Author URI: #

*/ 
