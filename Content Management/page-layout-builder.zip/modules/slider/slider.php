<?php
/*
  Plugin Name: All sliders
  Plugin URI: #
  Description: All sliders
  Author: Shaon
  Version: pro_only
  Author URI: #
 */
