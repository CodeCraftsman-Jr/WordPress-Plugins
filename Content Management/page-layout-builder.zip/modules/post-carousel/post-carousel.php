<?php
/*
Plugin Name: Post Carousel
Plugin URI: #
Description: Post Carousel using Bootstrap
Author: Shaon
Version: pro_only
Author URI: #
*/

