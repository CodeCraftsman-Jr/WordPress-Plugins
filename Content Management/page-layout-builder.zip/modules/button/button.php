<?php
/*
Plugin Name: Button 
Plugin URI: #
Description: MiniMax Button with icon support
Author: Shaon
Version: pro_only
Author URI: #
*/
