<?php
/*
Plugin Name: Notepad
Plugin URI: #
Description: Notepad to show information or To-do list
Author: Shaon
Version: pro_only
Author URI: #
*/
