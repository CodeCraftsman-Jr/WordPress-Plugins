<?php
/*
Plugin Name: Social media lock widget
Plugin URI: #
Description: Twitter, G +1, FB Like lock for private contents
Author: Shaon
Version: pro_only
Author URI: #
*/

