<?php
/*
Plugin Name: Folded corner 
Plugin URI: #
Description: Create Folded Corner Box with Various Colors
Author: Shaon
Version: pro_only
Author URI: #
*/
