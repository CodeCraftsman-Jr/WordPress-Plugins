<?php
/*
  Plugin Name: Twitter Timeline
  Plugin URI: #
  Description: Twitter Timeline for minimax
  Author: Shaon
  Version: pro_only
  Author URI: #
 */

