<?php
/*
Plugin Name: MiniMax Separator 
Plugin URI: #
Description: Separates Two MiniMax Blocks/Rows
Author: Shaon
Version: pro_only
Author URI: #
*/
