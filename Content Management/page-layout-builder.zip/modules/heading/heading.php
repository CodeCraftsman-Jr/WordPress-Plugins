<?php
/*
Plugin Name: Heading 
Plugin URI: #
Description: 5 Different Heading Styles
Author: Shaon
Version: pro_only
Author URI: #
*/
