UPDATE 
	wp_posts
SET
	post_type = 'pronamic_event' 
WHERE
	post_type = 'event'
;