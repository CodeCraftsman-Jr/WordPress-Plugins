<?php

/**
 * Pronamic data event interface
*/
interface Pronamic_DateEventInterface {
	/**
	 * Get event hash code
	 */
	public function get_event_hash_code();
}
