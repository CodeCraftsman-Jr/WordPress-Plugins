=== Post Expiring ===
Contributors: potreb
Author URI: http://potrebka.pl
Tags: expiring, expired, date of deactivation , date of expiring, posts expiring, expired post
Tested up to: 4.1
Stable tag: 1.4
Requires at least: 3.8

Expire post by set the date of expiring 

== Description ==
Allows you to add an expiration date to posts.
[youtube https://www.youtube.com/watch?v=EYGoW6HMyuk]

== Changelog ==
= 1.4 =
Add a new calendar with choice hours and minutes
Add join/where filter for next/previous post links
= 1.3 =
Add default styles for calendar.
= 1.1 =
Add expiring date support for page post type. Now only works with posts and pages.
= 1.1 =
Small improvements to the code. Change plugin file structure.
= 1.0 =
* Make plugin


== Installation ==
To do a new installation of the plugin, please follow these steps
1. Install plugin in dashboard and activate or download the post-expiring.zip file to your computer.
2. Unzip the file
3. Upload post-expiring folder to the /wp-content/plugins/ directory
4. Activate the plugin through the 'Plugins' menu in WordPress
