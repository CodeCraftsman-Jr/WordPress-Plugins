=== Page Management Dropdown ===
Contributors: jaschaephraim
Donate link: http://jaschaephraim.com/wordpress/
Tags: admin, administration, page, pages, menu, cms
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 2.7

Adds a link to edit each individual page to the Pages admin menu.

== Description ==

Ideal for using WordPress as a CMS, Page Management Dropdown expands the *Pages* administration menu by adding a link to edit each of your individual pages.

== Screenshots ==

1. Here is an example of the expanded *Pages* admin menu with Page Management Dropdown activated. You can see that there is a menu item for each individual page.
