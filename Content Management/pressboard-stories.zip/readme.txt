=== Pressboard Stories ===
Contributors: pressboard
Tags: sponsored stories, content marketing
Requires at least: 2.7
Tested up to: 4.2.3
Stable tag: 1.05
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically activate your Pressboard sponsored stories.

== Description ==

Automatically activate your Pressboard sponsored stories.

== Installation ==

1. Activate the plugin through the 'Plugins' menu in WordPress.
2. Under Settings -> Pressboard Stories, enter your Media ID.

== Frequently Asked Questions ==

= Where do I find my Media ID? =

Login to your Pressboard account at https://manage.pressboard.ca, click "Web Sites", open your web site and click "Get Code".

== Screenshots ==

1. sponsor stories that matter

== Changelog ==

= 1.05 =
* Allow script to load over a secure connection.

= 1.01 =
* Updated and tested against WordPress 4.1.1

= 1.0 =
* Initial version.

