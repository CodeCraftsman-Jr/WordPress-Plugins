<div class="wrap">
	<?php echo "<h2>".__('Wordpress Pricing Tables Info')."</h2>";?>
    <br />

		  
        
        
<h3>Need Help ?</h3>

Please watch this video tutorial<br /> <br />
<iframe width="640" height="360" src="//www.youtube.com/embed/O6YBeh56NEQ" frameborder="0" allowfullscreen></iframe>

<p>We will be happy to help you <span class="smiley"></span> <br />
Please report any issue via our support forum <a href="http://kentothemes.com/questions-answers/">kentothemes.com &raquo; Q&A</a> ask any question. <br />
        Checkout Our Latest Plugin <a href="http://kentothemes.com/">http://kentothemes.com</a>
</p>
<br />
<hr />
<h3>Do You Like This Plugin ?</h3>
<table>
<tr>
<td width="100px"> 
<!-- Place this tag in your head or just before your close body tag. -->
<script type="text/javascript" src="https://apis.google.com/js/platform.js"></script>

<!-- Place this tag where you want the +1 button to render. -->
<div class="g-plusone" data-size="medium" data-href="http://kentothemes.com/items/plugins/wordpress-pricing-table/"></div>

</td>
<td width="100px">

<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fkentothemes.com%2Fitems%2Fplugins%2Fwordpress-pricing-table%2F&amp;width=100&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=false&amp;height=21&amp;appId=743541755673761" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>

 </td>
<td width="100px"> 

<a href="https://twitter.com/share" class="twitter-share-button" data-url="http://kentothemes.com/items/plugins/wordpress-pricing-table/" data-text=" WordPress Pricing Tables">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
</td>

</tr>

</table>
<hr />


<br />
<h3>Need Premium Version Of "Pricing Tables" ?</h3>
<p>
If you need more feature for your pricing table then you could try our pro version which support lot more features and easy to use than free version.<br />
<br />
<b>Pro Version Features</b><br />

# Life Time Update.<br />
# Life Time Support via forum.<br />
# One Time purchase.<br />
# 7 Days Refund.<br />
# Easy to use.<br />
# Different Background Color for column.<strong style="color:#139b50;">(Premium Only)</strong><br />
# Four different themes.<strong style="color:#139b50;">(Premium Only)</strong><br />
# Top And Bottom Gradient. <strong style="color:#139b50;">(Premium Only)</strong><br />
# Column Corner Radius.<strong style="color:#139b50;">(Premium Only)</strong><br />
# Table Column Margin.<strong style="color:#139b50;">(Premium Only)</strong><br />
# Hide Blank Field Style. <strong style="color:#139b50;">(Premium Only)</strong><br />
# Custom font size for column header, price, signup link.<strong style="color:#139b50;">(Premium Only)</strong><br />
# Custom color for column header, price, signup link.<strong style="color:#139b50;">(Premium Only)</strong><br />
# Custom height for column header, price, signup.<strong style="color:#139b50;">(Premium Only)</strong><br />
# Unlimited Number Pricing Table Using shortcodes.<br />
# Unlimited column color for each column.<br />
# Featured Colum And Hover effect.<br />
<br /><br />
<h3>Pro Vesrion:</h3><br />
<strong style="font-size:30px;">Price: $5(USD)</strong><br />
Plugin Link: <a target="_blank" href="http://kentothemes.com/items/plugins/wordpress-pricing-table/">http://kentothemes.com/items/plugins/wordpress-pricing-table/</a><br /><br /> <br />
<img src="<?php echo  plugins_url(); ?>/pricing-tables/css/pricing-tables-pro.png" />
</p>
        
        
        
        
        
        
        
        
        
         
</div>
