=== Wordpress Custom Post Field ===
Contributors: tushal304
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=N9U6APJY23C6N
Tags: wordpress custom post Field, post ,custom ,post field,manage post, Shortcode, post shortcode,custom post shortcode ,custom field ,post field ,wordpress post field,custom post in wordpress, add custom post
Requires at least: 3.5
Tested up to: 4.2.2
License: GPLv2

Wordpress Custom Post Field for creating custom post types and custom taxonomies in WordPress site.and easy manage custom post.

== Description ==
This Plugin Is Create For Add Costum Post Type in Wordpress .
Just Simple You define post in Admin panel and it use in wordpress site.
You can manage this post add ,update and delete by manual from admin panel site.
This plugin provides an easy to use to create and administer custom post types and taxonomies in WordPress. 

== Installation ==

1. Upload the Wordpress Custom Post Field folder to the plugins directory in your WordPress installation
2. Activate the plugin
3. Navigate to the Wordpress Custom Post Field Menu



== Screenshots ==

1. Create a New custom post type
2. Custom post type and taxonomies are added Display in dashbord admin menus
3. List Of Wordpress Custom Post type
4. Easily add new post in costom type.
5. List Of shortcode ,Simple copy shortcode and past in page


== Changelog ==

= 0.1 =
* First beta release

= 0.2 =
* Remove conflic code 

= 2.0 =
* Add Shortcode For Display Post On page

= 2.1 =
* Remove Error "Header already send....".

Now you can easily start creating custom post types and taxonomies in WordPress

