//PRIVY WIDGET CODE
var _d_site = _d_site || PrivyWebsiteWidgetParams.account_identifier; (function() {
var script = document.createElement('script'); script.type = 'text/javascript'; script.async = true;
script.src = document.location.protocol + '//widget.privy.com/assets/widget.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(script, s); })();