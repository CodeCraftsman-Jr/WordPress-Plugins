=== PRyC WP: Google Sitelinks Search Box snippest ===
Contributors: PRyCpl
Tags: WordPress, Google, Google search, Sitelinks Search Box
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin add to homepage code required to activate new Sitelinks Search Box @ Google search

== Description ==
Plugin add to homepage code required to activate new Sitelinks Search Box @ Google search.

See more: https://developers.google.com/webmasters/richsnippets/sitelinkssearch

== Installation ==
1. Upload `pryc-wp-google-sitelinks-search-box-snippest` dir to the `/wp-content/plugins/` directory
2. Activate the plugin through the \'Plugins\' menu in WordPress

== Screenshots ==
1. Default search before
2. Default search after

== Changelog ==
1.0.1: First public ver.