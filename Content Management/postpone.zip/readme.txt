=== Postpone ===
Contributors: urre
Donate link: hej@urre.me
Tags: publish, schedule, postpone
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.0.0

Schedule a post in 1 hour, Tomorrow 8 am, Tomorrow after lunch, Tonight, Next monday or Next month.

== Description ==

Postpone helps you easily select when you want to publish a post or a page. Postpone a post/page by: 1 hour, Tomorrow 8 am, Tomorrow after lunch, Tonight, Next monday or Next month.

* [Github](https://github.com/urre/postpone)

== Installation ==

1. Upload the `postpone` folder to your `/wp-content/plugins/` directory
2. Activate the "Postpone" plugin in your WordPress administration interface
3. Done!

== Feedback ==

Contact me at hej@urre.me or at https://twitter.com/urre and hopefully I can do something about it.

== Screenshots ==

1. Postpone

== Frequently Asked Questions ==

This plugin is available in the following languages:

* English
* Swedish

== Changelog ==

= 0.1.0 =
* First version in repository