<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class SP_Connection_Manager extends SP_Connection_Manager_Core {}