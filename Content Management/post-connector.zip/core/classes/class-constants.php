<?php

abstract class SP_Constants extends SP_Constants_Core {}