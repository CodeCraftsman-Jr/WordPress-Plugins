=== Post-counter ===
Contributors: tomek00
Tags: post, posts, count, counter, widget
Donate link: http://wp-learning.net/blog/felajanl
Requires at least: 3.4
Tested up to: 4.1.1
Stable tag: trunk

Writes in the slidebar the numbers of your posts

== Description ==
Writes in the slidebar the numbers of your posts

== Installation ==

1. Extract the plugin folder from the downloaded ZIP file.
2. Upload posts to your /wp-content/plugins/ directory.
3. Activate the plugin from the "Plugins" page in your Dashboard.
4. Activate the widget through the 'Widgets' menu in WordPress

== Frequently Asked Questions ==
None

== Screenshots ==
None

== Upgrade Notice ==
Nothing

== Changelog ==

None