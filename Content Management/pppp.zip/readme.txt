=== Powerful Posts Per Page ===
Contributors: Toro_Unit
Tags: post type,taxonomy,cms,posts per page
Requires at least: 3.5
Tested up to: 4.2
Stable tag: 0.8.0

Posts per page for custom post types and taxonomies.

== Description ==

Simple Customization posts per page for your sites.

= Available Setting =

* Custom Post Type
* Custom Taxonomy
* Category
* Tag


This plugin use `pre_get_posts`.

[This Plugin published on GitHub.](https://github.com/torounit/pppp)

Donation: Please send Amazon Gift to donate[at]torounit.com.

= Translators =
* Japanese(ja) - [Toro_Unit](http://www.torounit.com/)


== Installation ==

* Download the pppp.zip file to your computer.
* Unzip the file.
* Upload the `pppp` directory to your `/wp-content/plugins/` directory.
* Activate the plugin through the 'Plugins' menu in WordPress.

That's it. You can access the posts per page setting by going to *Settings -> Reading*.


== Screenshots ==

* screenshot-1.png



== Changelog ==

= 0.8.0 =
* Unit Test.

= 0.7.2 =
* Fix Not Working Category and Tag.

= 0.7.1 =
* Fix uninstall hook method call.

= 0.7 =
* Divid into small class a large class.

= 0.6 =
* First release.
