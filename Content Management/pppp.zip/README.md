#Powerful Posts Per Page


各投稿タイプ・タクソノミーのアーカイブページでの、１ページの最大表示数を管理画面から変更できます。

内部的にはpre_get_postsを使っています。

##インストール
` wp-content/plugin` に展開してください。


![Screenshot](https://raw.github.com/torounit/pppp/master/screenshot-1.png)

##License

GPL v2 or Later.
