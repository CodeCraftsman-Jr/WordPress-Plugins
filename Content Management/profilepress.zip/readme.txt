=== Profile ===
Contributors: nerdaryan
Donate link: https://www.paypal.com/cgi-bin/webscr?business=rah12@live.com&cmd=_xclick&item_name=Donation%20to%20Profile%20development
Tags: community, profile, frontend, buddypress
Requires at least: 4.1.1
Tested up to: 4.1.1
Stable tag: 0.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Profile - WordPress profile plugin, easily add custom user fields.

== Description ==
This plugin will show a nice user profile with user fields and posts. Also you can easily create profile field on user profile page.


= Help & Support =
For fast help and support, please post on our forum http://wp3.in/questions/


**Page Shortcodes**

Use this shortcode in base to Profile work properly
`[profile]`


== Installation ==

Its very easy to install the plugin.



== Frequently Asked Questions ==

**Page Shortcodes**

`[profile]` add profile shortcode to your base page for profile to work properly


== Screenshots ==



== Changelog ==

= 0.0.6 =

* Fixed conflict with AnsPress

= 0.0.5 =

* Added post_name when creating base page

