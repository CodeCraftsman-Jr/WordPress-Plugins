===  Content Copy Protection & Prevent Image Save  ===
Contributors: fakhris 
Donate link: http://www.clogica.com/donations.htm
Tags: content, content copy protection,content protection,content theft,copy protection,image protect,image protection,secure content,no right click,prevent copy, protect blog,plagiarism
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: trunk
Content Copy Protection & Prevent Image Save is a plugin for content protection from copying to other sites, it prevents content and protect from select and copy and also prevents images saving from context menu

== Description ==

As you know, the duplicate content can decrease your blog ranking in search engines, if someone copied your content, it will marked as duplicate content!, this plugin is for content protection and can protects your content from steeling, it prevents content select and copy and also prevents images saving from context menu, install this plugin to have a unique content and high page rank.

<h3>You can see the PRO version to get advanced protection:
</h3>
<ul>
<li>Protect your content from selection and copy.</li>
<li>No one can save images from your site.</li>
<li>No right click or context menu.</li>
<li>Show alert message, Image Ad or HTML Ad on save images or right click.</li>
<li>Disable the following keys&nbsp; CTRL+A, CTRL+C, CTRL+X,CTRL+S or CTRL+V.</li>
<li>Advaced and easy to use control panel.</li>
</ul>
<p>By showing ads, turn thieves into money....
<a target="_blank" href="http://www.clogica.com/product/wp-content-protection-manager">click here to see details and live preview</a></p>


== Installation ==
<ul>
<li>Go to the wordpress control panel and go to "Plugins" menu and press the button "Add New".</li>
<li>Go to the tab "Upload" and choose the file "Prevent_Content_Copy_and_Image_Save_Protection.zip", click the button "Upload" to get the file uploaded.</li>
<li>Lockup the plugin, and click "Activate" to get it active.</li>
<li>Go to the Options page and configure the plugin.</li>
</ul>

<p>view this posts if you want more details about installing plugins: <a href="http://www.wpfasthelp.com/how-to-install-wordpress-plugins.htm">
http://www.wpfasthelp.com/how-to-install-wordpress-plugins.htm</a></p>

== Screenshots ==
1. Screenshot shows all options available in control panel
