=== POST PER CATEGORY WIDGET===
Tags: POST,category posts,categories,post per category widget 
Requires at least: 4.1.1
Tested up to: 4.2.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A widget that display a post from each category with attached thumbnail.


<h4>Widget Options</h4>
<ul>
<li>Easly customizable Stylesheet.</li>
<li>Can be fit with responsive designs.</li>
</ul>

== Installation ==

You can use the built-in installer, or you can install the plugin manually.
<ul>
<li>1. Go to the menu 'Plugins' -> 'Install' and search for 'POST PER CATEGORY WIDGET.</li>
<li>2. Click 'install'.</li>
<li>3. After installation go to widget section and place POST PER CATEGORY WIDGET in your sidebar.</li>
</ul>



== Frequently Asked Questions ==

= A question that someone might have =

== Screenshots ==

1. post per category widget in sidebar


== Changelog ==

= 1.1 =
* Update stylesheet with responsive designs.
* Tested with latest wordpress version

= 1.0 =
* Released