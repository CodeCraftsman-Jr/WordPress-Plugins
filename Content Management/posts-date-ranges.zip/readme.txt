=== Posts Date Ranges ===
Contributors: jaytesh
Donate link: http://www.jaytesh.com/donate/
Tags: filters, post filters, date range filters, admin filters
Stable tag: 2.2
Requires at least: 3.0
Tested up to: 3.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This WordPress Plugin will Add Options in admin posts lists page to pick up start-date and end-date ranges to filter posts in your wordpress admin.

== Description ==

This WordPress Plugin will Add Options in admin posts lists page to pick up start-date and end-date ranges to filter posts in your wordpress admin. It will give you instant filter options without any type of configuration just install it and use it.

Added Filters to Filter Posts having Featured Image and Not Having Featured Image

== Installation ==

1. Upload posts-date-ranges to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. No Settings needed to use this plugin. It will add filters for Start Date: and End Date: in Posts edit lists

== Frequently Asked Questions ==

= Will it work on pages? =

It will work on pages and custom post types.

= It follow some Date Format? =

Please select date using datepicker provided in input.

= It work on Start Date or End Date seperately? =

Yes.

== Screenshots ==

1. Screenshot after installing the plugin. It will add filters for Start Date: and End Date: in Posts edit lists with date picker screenshot-1.jpg

== Changelog ==

= 2.2 =
Fixed Jquery Conflicts in admin

= 2.0 =
Added Filters to Filter Posts having Featured Image and Not Having Featured Image

= 1.0 =

First Release
