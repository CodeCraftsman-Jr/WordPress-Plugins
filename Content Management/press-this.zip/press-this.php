<?php
/*
Plugin Name: Press This
Plugin URI: https://wordpress.org/plugins/press-this/
Description: Now merged into WordPress (4.2.0), no longer does anything.
Version: 0.1-20150312
Author: Press This Team
Author URI: https://corepressthis.wordpress.com/
Text Domain: press-this
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/