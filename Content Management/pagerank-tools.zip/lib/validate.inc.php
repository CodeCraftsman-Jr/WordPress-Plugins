<?php

function validate_email($email){
	
}

?>