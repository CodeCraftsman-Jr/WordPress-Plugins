=== Pagerank tools ===
Contributors: mahype
Tags: pagerank,page rank,rank,siterank,site rank,pr,stats,statistics,seo,google
Requires at least: 2.9.x
Tested up to: 3.0.4
Stable tag:  1.1.5

Monitor pageranks of your wordpress sites.

== Description ==
This plugin gives you an overview about the pageranks of your whole urls. This is the professional version of the pagerank tools.

Requests to google where made in moment of visitors request of a site. There is no cron option, cause of better random requests. 

<h4>Function overview</h4>

<ul>
    <li>Graphical statistics of all pageranks</li>
    <li>Graphical pagerank history of urls</li>
    <li>Export pageranks to CVS (MS-Excel compatible)</li>
    <li>Updtate email on pagerank change</li>
</ul>

PageRank is a trademark of Google, Inc.

== Installation ==
1. Upload 'Pagerank tools' to the '/wp-content/plugins/' directory<br>
2. Activate 'Pagerank tools' on plugin page.


That's it, have fun!

== Screenshots ==

1. **URL overview**
2. **Detailed URL view**

== Changelog ==
<h4>1.1.5</h4>
<ul>
<li>Dismissing test values</li>
</ul>

<h4>1.1.4</h4>
<ul>
<li>Fixed missing CSS</li>
<li>Added Donation Button</li>
</ul>

<h4>1.1.3</h4>
<ul>
<li>Fixed missing statistic images</li>
</ul>

<h4>1.1.2</h4>
<ul>
<li>Different Bugs</li>
</ul>

<h4>1.1.1</h4>
<ul>
<li>Check if an url already exists or not to prevent checking non existant URLs to google</li>
</ul>

<h4>1.1</h4>
<ul>
<li>Turned all pro frunctions to free</li>
</ul>

<h4>1.0</h4>
<ul>
<li>First version of Pagerank tools professional</li>
</ul>


