<?php
/**
 * @wordpress-plugin
 * Plugin Name:       PayPal Express Checkout WC4JP
 * Plugin URI:        http://wc.artws.info/product/paypal-for-woocommerce-plugin/
 * Description:       Easily enable PayPal Express Checkout for Japanese User. Each option is available separately so you can enable them individually.
 * Version:           0.9
 * Author:            ArtisanWorkshop
 * Author URI:        http://wc.artws.info/
 * License:           GNU General Public License v3.0
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Domain Path:       /i18n/
 * GitHub Plugin URI: https://github.com/artsanworkshop/paypal-express-wc4jp
 *
 *************
 * Attribution
 *************
 * PayPal for WooCommerce is a derivative work of the code from WooThemes / SkyVerge,
 * which is licensed with GPLv3.  This code is also licensed under the terms
 * of the GNU Public License, version 3.
 */

/**
 * Exit if accessed directly.
 */
if (!defined('ABSPATH'))
{
    exit();
}

/**
 * Set global parameters
 */
global $woocommerce, $pp_settings, $pp_pro, $pp_payflow, $wp_version;

/**
 * Get Settings
 */
$pp_settings = get_option( 'woocommerce_paypal_express_settings' );
//$pp_pro     = get_option('woocommerce_paypal_pro_settings');
//$pp_payflow = get_option('woocommerce_paypal_pro_payflow_settings');
if(!class_exists('WC4JP_Gateway_Paypal')){
    class WC4JP_Gateway_Paypal
    {
        /**
         * General class constructor where we'll setup our actions, hooks, and shortcodes.
         *
         */
        
        const VERSION_PFW = '1.1.6.3.4';
        
        public function __construct()
        {

            /**
             * Check current WooCommerce version to ensure compatibility.
             */
            
            $woo_version = $this->wpbo_get_woo_version_number();
            if(version_compare($woo_version,'2.1','<'))
            {
                exit( __('PayPal for WooCommerce requires WooCommerce version 2.1 or higher.  Please backup your site files and database, update WooCommerce, and try again.','paypal-express-wc4jp'));
            }

            add_filter( 'woocommerce_paypal_args', array($this,'ae_paypal_standard_additional_parameters'));
            add_action( 'plugins_loaded', array($this, 'init'));
            register_activation_hook( __FILE__, array($this, 'activate_paypal_for_woocommerce' ));
            register_deactivation_hook( __FILE__,array($this,'deactivate_paypal_for_woocommerce' ));
            add_action( 'wp_enqueue_scripts', array($this, 'woocommerce_paypal_express_init_styles'), 12 );
            add_action( 'admin_notices', array($this, 'admin_notices') );
            add_action( 'admin_init', array($this, 'set_ignore_tag'));
            add_filter( 'woocommerce_product_title' , array($this, 'woocommerce_product_title') );
//            add_action( 'woocommerce_sections_checkout', array( $this, 'donate_message' ), 11 );
            add_action( 'parse_request', array($this, 'woocommerce_paypal_express_review_order_page_wc4jp') , 11);

            // http://stackoverflow.com/questions/22577727/problems-adding-action-links-to-wordpress-plugin
            $basename = plugin_basename(__FILE__);
            $prefix = is_network_admin() ? 'network_admin_' : '';
            add_filter("{$prefix}plugin_action_links_$basename",array($this,'plugin_action_links'),10,4);
            add_action( 'woocommerce_after_add_to_cart_button', array($this, 'buy_now_button'));
            add_action( 'woocommerce_after_mini_cart', array($this, 'mini_cart_button'));            
            add_action( 'woocommerce_add_to_cart_redirect', array($this, 'add_to_cart_redirect'));
            add_action( 'woocommerce_after_single_variation', array($this, 'buy_now_button_js'));
            add_action('admin_enqueue_scripts', array( $this , 'onetarek_wpmut_admin_scripts' ) );
            add_action('admin_print_styles', array( $this , 'onetarek_wpmut_admin_styles' ) );
            add_action( 'woocommerce_cart_calculate_fees', array($this, 'woocommerce_custom_surcharge') );
            add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'add_div_before_add_to_cart_button' ), 25);
            add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'add_div_after_add_to_cart_button' ), 35);
            add_action( 'admin_init', array( $this, 'wc4jp_check_version' ), 5 );
        }

        /**
         * Get WooCommerce Version Number
         * http://wpbackoffice.com/get-current-woocommerce-version-number/
         */
        function wpbo_get_woo_version_number()
        {
            // If get_plugins() isn't available, require it
            if ( ! function_exists( 'get_plugins' ) )
            {
                require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            }

            // Create the plugins folder and file variables
            $plugin_folder = get_plugins( '/' . 'woocommerce' );
            $plugin_file = 'woocommerce.php';

            // If the plugin version number is set, return it
            if ( isset( $plugin_folder[$plugin_file]['Version'] ) )
            {
                return $plugin_folder[$plugin_file]['Version'];
            }
            else
            {
                // Otherwise return null
                return NULL;
            }
        }

        /**
         * Add gift amount to cart
         * @param $cart
         */
        function woocommerce_custom_surcharge($cart){
            if (isset($_REQUEST['pp_action']) && ($_REQUEST['pp_action']=='revieworder' || $_REQUEST['pp_action']=='payaction') && WC()->session->giftwrapamount){
                $cart->add_fee( __('Gift Wrap', 'paypal-express-wc4jp'), WC()->session->giftwrapamount );
            }
        }

        function onetarek_wpmut_admin_scripts()
        {
            $dir = plugin_dir_path( __FILE__ );
            wp_enqueue_media();
            wp_enqueue_script( 'jquery');
        }

        function onetarek_wpmut_admin_styles()
        {
            wp_enqueue_style('thickbox');

        }

        /**
         * Return the plugin action links.  This will only be called if the plugin
         * is active.
         *
         * @since 1.0.6
         * @param array $actions associative array of action names to anchor tags
         * @return array associative array of plugin action links
         */
        public function plugin_action_links($actions, $plugin_file, $plugin_data, $context)
        {
            $custom_actions = array(
                //'configure' => sprintf( '<a href="%s">%s</a>', admin_url( 'admin.php?page=wc-settings&tab=checkout' ), __( 'Configure', 'paypal-express-wc4jp' ) ),
                'docs'      => sprintf( '<a href="%s" target="_blank">%s</a>', 'http://wc.artws.info/docs/paypal-for-woocommerce/', __( 'Docs', 'paypal-express-wc4jp' ) ),
                'support'   => sprintf( '<a href="%s" target="_blank">%s</a>', 'http://wordpress.org/support/plugin/paypal-express-wc4jp/', __( 'Support', 'paypal-express-wc4jp' ) ),
                'review'    => sprintf( '<a href="%s" target="_blank">%s</a>', 'http://wordpress.org/support/view/plugin-reviews/paypal-express-wc4jp', __( 'Write a Review', 'paypal-express-wc4jp' ) ),
            );

            // add the links to the front of the actions list
            return array_merge( $custom_actions, $actions );
        }

        function woocommerce_product_title($title){
            $title = str_replace(array("&#8211;", "&#8211"), array("-"), $title);
            return $title;
        }

        function set_ignore_tag(){
            global $current_user;
            $plugin = plugin_basename( __FILE__ );
            $plugin_data = get_plugin_data( __FILE__, false );

            if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) && !is_plugin_active_for_network( 'woocommerce/woocommerce.php' ) ) {
                if(!in_array(@$_GET['action'],array('activate-plugin', 'upgrade-plugin','activate','do-plugin-upgrade')) && is_plugin_active($plugin) ) {
                    deactivate_plugins( $plugin );
                    wp_die( "<strong>".$plugin_data['Name']."</strong> requires <strong>WooCommerce</strong> plugin to work normally. Please activate it or install it from <a href=\"http://wordpress.org/plugins/woocommerce/\" target=\"_blank\">here</a>.<br /><br />Back to the WordPress <a href='".get_admin_url(null, 'plugins.php')."'>Plugins page</a>." );
                }
            }
            $user_id = $current_user->ID;
            /* If user clicks to ignore the notice, add that to their user meta */
            $notices = array('ignore_pp_ssl', 'ignore_pp_sandbox', 'ignore_pp_woo', 'ignore_pp_check', 'ignore_pp_donate');
            foreach ($notices as $notice)
                if ( isset($_GET[$notice]) && '0' == $_GET[$notice] ) {
                    add_user_meta($user_id, $notice, 'true', true);
                }
        }

        function admin_notices() {
            global $current_user, $pp_settings ;
            $user_id = $current_user->ID;

//            $pp_pro = get_option('woocommerce_paypal_pro_settings');
//            $pp_payflow = get_option('woocommerce_paypal_pro_payflow_settings');
            $pp_standard = get_option('woocommerce_paypal_settings');

            do_action( 'wc4jp_admin_notices', $pp_standard );

/*            if (@$pp_pro['enabled']=='yes' || @$pp_payflow['enabled']=='yes') {
                // Show message if enabled and FORCE SSL is disabled and WordpressHTTPS plugin is not detected
                if ( get_option('woocommerce_force_ssl_checkout')=='no' && ! class_exists( 'WordPressHTTPS' ) && !get_user_meta($user_id, 'ignore_pp_ssl') )
                    echo '<div class="error"><p>' . sprintf(__('WooCommerce PayPal Payments Pro requires that the %sForce secure checkout%s option is enabled; your checkout may not be secure! Please enable SSL and ensure your server has a valid SSL certificate - PayPal Pro will only work in test mode. | <a href=%s>%s</a>', 'paypal-express-wc4jp'), '<a href="'.admin_url('admin.php?page=woocommerce').'">', "</a>", '"'.esc_url(add_query_arg("ignore_pp_ssl",0)).'"', __("Hide this notice", 'paypal-express-wc4jp'))  . '</p></div>';
                if ((@$pp_pro['testmode']=='yes' || @$pp_payflow['testmode']=='yes' || @$pp_settings['testmode']=='yes') && !get_user_meta($user_id, 'ignore_pp_sandbox')) {
                    $testmodes = array();
                    if (@$pp_pro['enabled']=='yes' && @$pp_pro['testmode']=='yes') $testmodes[] = 'PayPal Pro';
                    if (@$pp_payflow['enabled']=='yes' && @$pp_payflow['testmode']=='yes') $testmodes[] = 'PayPal Pro PayFlow';
                    if (@$pp_settings['enabled']=='yes' && @$pp_settings['testmode']=='yes') $testmodes[] = 'PayPal Express';
                    $testmodes_str = implode(", ", $testmodes);
                    echo '<div class="error"><p>' . sprintf(__('WooCommerce PayPal Payments ( %s ) is currently running in Sandbox mode and will NOT process any actual payments. | <a href=%s>%s</a>', 'paypal-express-wc4jp'), $testmodes_str, '"'.esc_url(add_query_arg("ignore_pp_sandbox",0)).'"',  __("Hide this notice", 'paypal-express-wc4jp')) . '</p></div>';
                }
            } elseif (@$pp_settings['enabled']=='yes'){
                if (@$pp_settings['testmode']=='yes' && !get_user_meta($user_id, 'ignore_pp_sandbox')) {
                    echo '<div class="error"><p>' . sprintf(__('WooCommerce PayPal Express is currently running in Sandbox mode and will NOT process any actual payments. | <a href=%s>%s</a>', 'paypal-express-wc4jp'), '"'.esc_url(add_query_arg("ignore_pp_sandbox",0)).'"', __("Hide this notice", 'paypal-express-wc4jp')) . '</p></div>';
                }
            }*/
            if(@$pp_settings['enabled']=='yes' && @$pp_standard['enabled']=='yes' && !get_user_meta($user_id, 'ignore_pp_check')){
                echo '<div class="error"><p>' . sprintf(__('You currently have both PayPal (standard) and Express Checkout enabled.  It is recommended that you disable the standard PayPal from <a href="%sadmin.php?page=wc-settings&tab=checkout&section=wc_gateway_paypal">the settings page</a> when using Express Checkout. | <a href=%s>%s</a>', 'paypal-express-wc4jp'),get_admin_url() ,'"'.esc_url(add_query_arg("ignore_pp_check",0)).'"', __("Hide this notice", 'paypal-express-wc4jp')) . '</p></div>';
            }

            if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) && !get_user_meta($user_id, 'ignore_pp_woo') && !is_plugin_active_for_network( 'woocommerce/woocommerce.php' )) {
                echo '<div class="error"><p>' . sprintf( __("WooCommerce PayPal Payments requires WooCommerce plugin to work normally. Please activate it or install it from <a href='http://wordpress.org/plugins/woocommerce/' target='_blank'>here</a>. | <a href=%s>%s</a>", 'paypal-express-wc4jp'), '"'.esc_url(add_query_arg("ignore_pp_woo",0)).'"', __("Hide this notice", 'paypal-express-wc4jp') ) . '</p></div>';
            }
        }

        //init function
        function init(){
            global $pp_settings;
            if (!class_exists("WC_Payment_Gateway")) return;
            load_plugin_textdomain('paypal-express-wc4jp', false, dirname(plugin_basename(__FILE__)). '/i18n/');
            add_filter( 'woocommerce_payment_gateways', array($this, 'wc4jp_add_paypal_pro_gateway'),1000 );
            remove_action( 'woocommerce_proceed_to_checkout', 'woocommerce_paypal_express_checkout_button', 12 );
            if( isset($pp_settings['button_position']) && ($pp_settings['button_position'] == 'bottom' || $pp_settings['button_position'] == 'both')){
                add_action( 'woocommerce_proceed_to_checkout', array( 'WC_Gateway_PayPal_Express_WC4JP', 'woocommerce_paypal_express_checkout_button_wc4jp'), 12 );
            }
            add_action( 'woocommerce_before_cart', array( 'WC_Gateway_PayPal_Express_WC4JP', 'woocommerce_before_cart'), 12 );
            remove_action( 'init', 'woocommerce_paypal_express_review_order_page') ;
            remove_shortcode( 'woocommerce_review_order');
            add_shortcode( 'woocommerce_review_order', array($this, 'get_woocommerce_review_order_wc4jp' ));

//            require_once('classes/wc-gateway-paypal-pro-payflow-angelleye.php');
//            require_once('classes/wc-gateway-paypal-pro-angelleye.php');
            require_once('classes/wc-gateway-paypal-express-wc4jp.php');

            //Short Code functions
			require_once('classes/class-wc-paypal-shortcode.php');
        }

        /**
         * woocommerce_paypal_express_init_styles function.
         *
         * @access public
         * @return void
         */
        function woocommerce_paypal_express_init_styles() {
            global $pp_settings;
            wp_register_script( 'wc4jp_button', plugins_url( '/assets/js/wc4jp-button.js' , __FILE__ ), array( 'jquery' ), WC_VERSION, true );
            if ( ! is_admin() && is_cart()){
                wp_enqueue_style( 'ppe_cart', plugins_url( 'assets/css/cart.css' , __FILE__ ) );
                wp_enqueue_script('wc4jp_button');
            }

            if ( ! is_admin() && is_checkout() && @$pp_settings['enabled']=='yes' && @$pp_settings['show_on_checkout']=='yes' )
                wp_enqueue_style( 'ppe_checkout', plugins_url( 'assets/css/checkout.css' , __FILE__ ) );
            if ( ! is_admin() && is_single() && @$pp_settings['enabled']=='yes' && @$pp_settings['show_on_product_page']=='yes'){
                wp_enqueue_style( 'ppe_single', plugins_url( 'assets/css/single.css' , __FILE__ ) );
                wp_enqueue_script('wc4jp_button');
            }

            if (is_page( wc_get_page_id( 'review_order' ) )) {
                $assets_path          = str_replace( array( 'http:', 'https:' ), '', WC()->plugin_url() ) . '/assets/';
                $frontend_script_path = $assets_path . 'js/frontend/';
                $suffix               = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
                wp_enqueue_script( 'wc-checkout', plugins_url( '/assets/js/checkout.js' , __FILE__ ), array( 'jquery' ), WC_VERSION, true );

                wp_localize_script( 'wc-checkout', 'wc_checkout_params', apply_filters( 'wc_checkout_params', array(
                    'ajax_url'                  => WC()->ajax_url(),
                    'ajax_loader_url'           => apply_filters( 'woocommerce_ajax_loader_url', $assets_path . 'images/ajax-loader@2x.gif' ),
                    'update_order_review_nonce' => wp_create_nonce( "update-order-review" ),
                    'apply_coupon_nonce'        => wp_create_nonce( "apply-coupon" ),
                    'option_guest_checkout'     => get_option( 'woocommerce_enable_guest_checkout' ),
                    'checkout_url'              => esc_url(add_query_arg( 'action', 'woocommerce_checkout', WC()->ajax_url() )),
                    'is_checkout'               => 1
                ) ) );
            }
        }

        /**
         * Run when plugin is activated
         */
        function activate_paypal_for_woocommerce()
        {
            // If WooCommerce is not enabled, deactivate plugin.
            if(!in_array( 'woocommerce/woocommerce.php',apply_filters('active_plugins',get_option('active_plugins'))) && !is_plugin_active_for_network( 'woocommerce/woocommerce.php' ))
            {
                deactivate_plugins(plugin_basename(__FILE__));
            }
            else
            {
                global $woocommerce;
                
                // Create review page for Express Checkout
                wc_create_page(esc_sql(_x('review-order','page_slug','woocommerce')),'woocommerce_review_order_page_id',__('Checkout &rarr; Review Order','paypal-express-wc4jp'),'[woocommerce_review_order]',wc_get_page_id('checkout'));

                // Log activation in Artisan Workshop database via web service.
/*                $log_url = $_SERVER['HTTP_HOST'];
                $log_plugin_id = 1;
                $log_activation_status = 1;
                wp_remote_request('http://www.angelleye.com/web-services/wordpress/update-plugin-status.php?url='.$log_url.'&plugin_id='.$log_plugin_id.'&activation_status='.$log_activation_status);*/
            }
        }

        /**
         * Run when plugin is deactivated.
         */
        function deactivate_paypal_for_woocommerce()
        {
            // Log activation in Artisan Workshop database via web service.
/*            $log_url = $_SERVER['HTTP_HOST'];
            $log_plugin_id = 1;
            $log_activation_status = 0;
            wp_remote_request('http://www.angelleye.com/web-services/wordpress/update-plugin-status.php?url='.$log_url.'&plugin_id='.$log_plugin_id.'&activation_status='.$log_activation_status);*/
        }

        /**
         * Adds PayPal gateway options for Payments Pro and Express Checkout into the WooCommerce checkout settings.
         *
         */
        function wc4jp_add_paypal_pro_gateway( $methods ) {
            foreach ($methods as $key=>$method){
                if (in_array($method, array(/*'WC_Gateway_PayPal_Pro', 'WC_Gateway_PayPal_Pro_Payflow', */'WC_Gateway_PayPal_Express'))) {
                    unset($methods[$key]);
                    break;
                }
            }
//            $methods[] = 'WC_Gateway_PayPal_Pro_AngellEYE';
//            $methods[] = 'WC_Gateway_PayPal_Pro_Payflow_AngellEYE';
            $methods[] = 'WC_Gateway_PayPal_Express_WC4JP';

            return $methods;
        }

        /**
         * Add additional parameters to the PayPal Standard checkout built into WooCommerce.
         *
         */
        public function ae_paypal_standard_additional_parameters($paypal_args)
        {
            $paypal_args['bn'] = 'ArtisanWorkshop_Cart_EC_JP';
            return $paypal_args;
        }

        /**
         * Add the gateway to woocommerce
         */
        function get_woocommerce_review_order_wc4jp( $atts ) {
            global $woocommerce;
            return WC_Shortcodes::shortcode_wrapper(array($this,'woocommerce_review_order_wc4jp'), $atts);
        }
        /**
         * Outputs the pay page - payment gateways can hook in here to show payment forms etc
         **/
        function woocommerce_review_order_wc4jp() {
            global $woocommerce;
            //$woocommerce->nocache();
            wc_print_notices() ;
            echo "
			<script>
			jQuery(document).ready(function($) {
				// Inputs/selects which update totals instantly
                $('form.checkout').unbind( 'submit' );
			});
			</script>
			";
            //echo '<form class="checkout" method="POST" action="' . add_query_arg( 'pp_action', 'payaction', add_query_arg( 'wc-api', 'WC_Gateway_PayPal_Express_WC4JP', home_url( '/' ) ) ) . '">';
            $template = plugin_dir_path( __FILE__ ) . 'template/';

            //Allow override in theme: <theme_name>/woocommerce/paypal-paypal-review-order.php
            wc_get_template('paypal-review-order.php', array(), '', $template);

            do_action( 'woocommerce_ppe_checkout_order_review' );
            //echo '<p><a class="button cancel" href="' . $woocommerce->cart->get_cart_url() . '">'.__('Cancel order', 'paypal-express-wc4jp').'</a> ';
            //echo '<input type="submit" class="button" value="' . __( 'Place Order','paypal-express-wc4jp') . '" /></p>';
            //echo '</form>';
        }

        /**
         * Review page for PayPal Express Checkout
         */
        function woocommerce_paypal_express_review_order_page_wc4jp() {
            if ( ! empty( $_GET['pp_action'] ) && $_GET['pp_action'] == 'revieworder' ) {
                $woocommerce_ppe = new WC_Gateway_PayPal_Express_WC4JP();
                $woocommerce_ppe->paypal_express_checkout();
            }
        }

        /**
         * Javascript code to move it in to button add to cart wrap
         */
        function buy_now_button_js() {
            global $pp_settings;
            if (@$pp_settings['enabled']=='yes' && @$pp_settings['show_on_product_page']=='yes')
            {
                ?>
                <script type="text/javascript">
                    jQuery(document).ready(function(){
                        jQuery('input.single_variation_wrap_wc4jp').appendTo(".variations_button");
                    });
                </script>
            <?php
            }
        }

        /**
         * Display Paypal Express Checkout on product page
         */
        function buy_now_button() {
            global $pp_settings, $post;
            if (@$pp_settings['enabled']=='yes' && @$pp_settings['show_on_product_page']=='yes')
            {
                ?>
                <div class="wc4jp_button_single">
                <?php
                $_product = wc_get_product($post->ID);
                $hide = '';
                if($_product->product_type == 'variation' ||
                    $_product->is_type('external') ||
                    $_product->get_price() == 0 ||
                    $_product->get_price() == '')
                {
                    $hide = 'display:none;';
                }

                if (empty($pp_settings['checkout_with_pp_button_type'])) $pp_settings['checkout_with_pp_button_type']='paypalimage';
                switch($pp_settings['checkout_with_pp_button_type'])
                {
                    case "textbutton":
                        if(!empty($pp_settings['pp_button_type_text_button'])){
                            $button_text = $pp_settings['pp_button_type_text_button'];
                        } else {
                            $button_text = __( 'Proceed to Checkout', 'woocommerce' );
                        }
                        $add_to_cart_action = esc_url(add_query_arg( 'express_checkout', '1'));
                        echo '<div id="paypal_ec_button_product">';
                        echo '<input data-action="'.$add_to_cart_action.'" type="submit" style="float:left;margin-left:10px;',$hide,'" class="single_variation_wrap_wc4jp paypal_checkout_button button alt" name="express_checkout"  onclick="',"jQuery('form.cart').attr('action','",$add_to_cart_action,"');jQuery('form.cart').submit();",'" value="' .$button_text .'"/>';
                        echo '</div>';
                        echo '<div class="clear"></div>';
                        break;
                    case "paypalimage":
                        $add_to_cart_action = esc_url(add_query_arg( 'express_checkout', '1'));
                        $button_img =  "https://www.paypal.com/".WC_Gateway_PayPal_Express_WC4JP::get_button_locale_code()."/i/btn/btn_xpressCheckout.gif";
                        echo '<div id="paypal_ec_button_product">';
                        echo '<input data-action="'.$add_to_cart_action.'" type="image" src="',$button_img,'" style="float:left;margin-left:10px;',$hide,'" class="single_variation_wrap_wc4jp" name="express_checkout" value="' . __('Pay with PayPal', 'paypal-express-wc4jp') .'"/>';
                        echo '</div>';
                        echo '<div class="clear"></div>';
                        break;
                    case "customimage":
                        $add_to_cart_action = esc_url(add_query_arg( 'express_checkout', '1'));
                        $button_img = $pp_settings['pp_button_type_my_custom'];
                        echo '<div id="paypal_ec_button_product">';
                        echo '<input data-action="'.$add_to_cart_action.'" type="image" src="',$button_img,'" style="float:left;margin-left:10px;',$hide,'" class="single_variation_wrap_wc4jp" name="express_checkout" value="' . __('Pay with PayPal', 'paypal-express-wc4jp') .'"/>';
                        echo '</div>';
                        echo '<div class="clear"></div>';
                        break;
                }
                ?>
                </div>
                <?php
            }

        }

        /**
         * Redirect to PayPal from the product page EC button
         * @param $url
         * @return string
         */
        function add_to_cart_redirect($url) {
            if (isset($_REQUEST['express_checkout'])||isset($_REQUEST['express_checkout_x'])){
                $url = esc_url_raw(add_query_arg( 'pp_action', 'expresscheckout', add_query_arg( 'wc-api', 'WC_Gateway_PayPal_Express_WC4JP', home_url( '/' ) ) )) ;
            }
            return $url;
        }

        /**
         * Donate function
         */
/*        function donate_message() {
            if (@$_GET['page']=='wc-settings' && @$_GET['tab']=='checkout' && in_array( @$_GET['section'], array('WC_Gateway_PayPal_Express_WC4JP', 'wc_gateway_paypal_pro_angelleye', 'wc_gateway_paypal_pro_payflow_angelleye')) && !get_user_meta(get_current_user_id(), 'ignore_pp_donate') ) {
                ?>
                <div class="updated donation">
                    <a target="_blank" href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=SG9SQU2GBXJNA"><img style="float:left;margin-right:10px;" src="https://www.angelleye.com/images/paypal-for-woocommerce/donate-button.png" border="0" alt="PayPal - The safer, easier way to pay online!"></a>
                    <p>We are learning why it is difficult to provide, support, and maintain free software. Every little bit helps and is greatly appreciated. </p>
                    <p>Developers, join us on <a href="https://github.com/artisanworkshop/paypal-woocommerce" target="_blank">GitHub</a>. Pull Requests are welcomed!</p>
                    <a style="float:right;" href="<?php echo esc_url(add_query_arg("ignore_pp_donate",0));?>">x <?php echo __("Hide", 'paypal-express-wc4jp');?></a>
                    <div style="clear:both"></div>
                </div>
            <?php
            }
        }*/

        function mini_cart_button(){
            global $pp_settings/*, $pp_pro, $pp_payflow*/;
            if( @$pp_settings['enabled']=='yes' && (empty($pp_settings['show_on_cart']) || $pp_settings['show_on_cart']=='yes') && WC()->cart->cart_contents_count > 0) {
                echo '<div class="paypal_box_button" style="position: relative;">';
                if (empty($pp_settings['checkout_with_pp_button_type'])) $pp_settings['checkout_with_pp_button_type'] = 'paypalimage';
                switch ($pp_settings['checkout_with_pp_button_type']) {
                    case "textbutton":
                        if (!empty($pp_settings['pp_button_type_text_button'])) {
                            $button_text = $pp_settings['pp_button_type_text_button'];
                        } else {
                            $button_text = __('Proceed to Checkout', 'woocommerce');
                        }
                        echo '<a class="paypal_checkout_button button alt" href="' . esc_url(add_query_arg('pp_action', 'expresscheckout', add_query_arg('wc-api', 'WC_Gateway_PayPal_Express_WC4JP', home_url('/')))) . '">' . $button_text . '</a>';
                        break;
                    case "paypalimage":
                        echo '<div id="paypal_ec_button">';
                        echo '<a class="paypal_checkout_button" href="' . esc_url(add_query_arg('pp_action', 'expresscheckout', add_query_arg('wc-api', 'WC_Gateway_PayPal_Express_WC4JP', home_url('/')))) . '">';
                        echo "<img src='https://www.paypal.com/" . WC_Gateway_PayPal_Express_WC4JP::get_button_locale_code() . "/i/btn/btn_xpressCheckout.gif' border='0' alt='" . __('Pay with PayPal', 'paypal-express-wc4jp') . "'/>";
                        echo "</a>";
                        echo '</div>';
                        break;
                    case "customimage":
                        $button_img = $pp_settings['pp_button_type_my_custom'];
                        echo '<div id="paypal_ec_button">';
                        echo '<a class="paypal_checkout_button" href="' . esc_url(add_query_arg('pp_action', 'expresscheckout', add_query_arg('wc-api', 'WC_Gateway_PayPal_Express_WC4JP', home_url('/')))) . '">';
                        echo "<img src='{$button_img}' width='150' border='0' alt='" . __('Pay with PayPal', 'paypal-express-wc4jp') . "'/>";
                        echo "</a>";
                        echo '</div>';
                        break;
                }

                /**
                 * Displays the PayPal Credit checkout button if enabled in EC settings.
                 */
/*                if (isset($pp_settings['show_paypal_credit']) && $pp_settings['show_paypal_credit'] == 'yes') {
                    // PayPal Credit button
                    $paypal_credit_button_markup = '<div id="paypal_ec_paypal_credit_button">';
                    $paypal_credit_button_markup .= '<a class="paypal_checkout_button" href="' . esc_url(add_query_arg('use_paypal_credit', 'true', add_query_arg('pp_action', 'expresscheckout', add_query_arg('wc-api', 'WC_Gateway_PayPal_Express_WC4JP', home_url('/'))))) . '" >';
                    $paypal_credit_button_markup .= "<img src='https://www.paypalobjects.com/webstatic/en_US/i/buttons/ppcredit-logo-small.png' alt='Check out with PayPal Credit'/>";
                    $paypal_credit_button_markup .= '</a>';
                    $paypal_credit_button_markup .= '</div>';

                    echo $paypal_credit_button_markup;
                }*/
                ?>
                <div class="blockUI blockOverlay wc4jpOverlay" style="display:none;z-index: 1000; border: none; margin: 0px; padding: 0px; width: 100%; height: 100%; top: 0px; left: 0px; opacity: 0.6; cursor: default; position: absolute; background: url(<?php echo WC()->plugin_url(); ?>/assets/images/ajax-loader@2x.gif) 50% 50% / 16px 16px no-repeat rgb(255, 255, 255);"></div>
                <script type="text/javascript">
                    jQuery(document).ready(function($){
                        $(".paypal_checkout_button").click(function(){
                            $(".wc4jpOverlay").show();
                            return true;
                        });
                    });
                </script>
                <?php
                echo "<div class='clear'></div></div>";
            }
        }
        function add_div_before_add_to_cart_button(){
            ?>
            <div class="wc4jp_buton_box_relative" style="position: relative;">
            <?php
        }
        function add_div_after_add_to_cart_button(){
            ?>
            <div class="blockUI blockOverlay wc4jpOverlay" style="display:none;z-index: 1000; border: none; margin: 0px; padding: 0px; width: 100%; height: 100%; top: 0px; left: 0px; opacity: 0.6; cursor: default; position: absolute; background: url(<?php echo WC()->plugin_url(); ?>/assets/images/ajax-loader@2x.gif) 50% 50% / 16px 16px no-repeat rgb(255, 255, 255);"></div>
            </div>
            <?php
        }
     
        public function wc4jp_check_version() {
        	
        	$paypal_express_wc4jp_version = get_option('paypal_express_wc4jp_version');
        	if( empty($paypal_express_wc4jp_version) ) {
        		
        		// PayFlow
                $woocommerce_paypal_pro_payflow_settings = get_option('woocommerce_paypal_pro_payflow_settings');
                if( isset($woocommerce_paypal_pro_payflow_settings) && !empty($woocommerce_paypal_pro_payflow_settings)) {
                	
                	if( !isset($woocommerce_paypal_pro_payflow_settings['payment_action']) && empty($woocommerce_paypal_pro_payflow_settings['payment_action'])) {
                		$woocommerce_paypal_pro_payflow_settings['payment_action'] = 'Sale';
                	}
                	
                	if( !isset($woocommerce_paypal_pro_payflow_settings['send_items']) && empty($woocommerce_paypal_pro_payflow_settings['send_items']) ) {
                		$woocommerce_paypal_pro_payflow_settings['send_items'] = 'yes';
                	}
                	
                	update_option('woocommerce_paypal_pro_payflow_settings', $woocommerce_paypal_pro_payflow_settings);
                }
                
                // DoDirectPayment
                $woocommerce_paypal_pro_settings = get_option('woocommerce_paypal_pro_settings');
                if( isset($woocommerce_paypal_pro_settings) && !empty($woocommerce_paypal_pro_settings)) {
                	
                	if( !isset($woocommerce_paypal_pro_settings['payment_action']) && empty($woocommerce_paypal_pro_settings['payment_action']) ) {
                		$woocommerce_paypal_pro_settings['payment_action'] = 'Sale';
                	}
                	
                	if( !isset($woocommerce_paypal_pro_settings['send_items']) && empty($woocommerce_paypal_pro_settings['send_items']) ) {
                		$woocommerce_paypal_pro_settings['send_items'] = 'yes';
                	}
                	
                	update_option('woocommerce_paypal_pro_settings', $woocommerce_paypal_pro_settings);
                }
                
                // PayPal Express Checkout
                $woocommerce_paypal_express_settings = get_option('woocommerce_paypal_express_settings');
                if( isset($woocommerce_paypal_express_settings) && !empty($woocommerce_paypal_express_settings)) {
                	
                	if( !isset($woocommerce_paypal_express_settings['payment_action']) && empty($woocommerce_paypal_express_settings['payment_action'])) {
                		$woocommerce_paypal_express_settings['payment_action'] = 'Sale';
                	}
                	
                	if( !isset($woocommerce_paypal_express_settings['cancel_page']) && empty($woocommerce_paypal_express_settings['cancel_page'])) {
                		$woocommerce_paypal_express_settings['cancel_page'] = get_option('woocommerce_cart_page_id');
                	}
                	
                	if( !isset($woocommerce_paypal_express_settings['send_items']) && empty($woocommerce_paypal_express_settings['send_items'])) {
                		$woocommerce_paypal_express_settings['send_items'] = 'yes';
                	}
                	
                	if( !isset($woocommerce_paypal_express_settings['billing_address']) && empty($woocommerce_paypal_express_settings['billing_address'])) {
                		$woocommerce_paypal_express_settings['billing_address'] = 'no';
                	}
                	
                	if( !isset($woocommerce_paypal_express_settings['button_position']) && empty($woocommerce_paypal_express_settings['button_position'])) {
                		$woocommerce_paypal_express_settings['button_position'] = 'bottom';
                	}
                	
                	update_option('woocommerce_paypal_express_settings', $woocommerce_paypal_express_settings);
                }
 				
                update_option('paypal_express_wc4jp_version', self::VERSION_PFW);
        	}
        }
    }
}
new WC4JP_Gateway_Paypal();