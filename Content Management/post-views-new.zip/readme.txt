=== Post Views ===
Contributors: bansod_deven
Tags: views, posts, posts_views, post views, Post views, Page views, Post_views
Requires at least: 3
Tested up to: 4.1
Stable tag: 3.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Post_views is a Simple Wordpress Plugin to show the views till date ( from the date of using the plugin infact ), of various posts and pages of a blog.

== Description ==

 * Wordpress Plugin for viewing Number of views for the Posts and Pages of a Blog.
 * This simple Plugin Helps the Admins to get the Info about the Views till date of various posts on the Blog in a form of Table Chart.
 * This may help them to Judge their various Authors and may also get the Idea of the tastes of their readers.

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'Post_views'
3. Activate Post_views from your Plugins page.

= From WordPress.org =

1. Download Post_views
2. Upload the 'post_views-new' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate Post_views from your Plugins page.

If Any Problem, mail me at devenbansod [dot] bits [at] gmail [dot] com.

== Screenshots ==
1. Admin Area of the Plugin(Dashboard->Settings->Post Views)

== FAQS ==
If any problem, mail me at devenbansod [dot] bits [at] gmail [dot] com.

Thanks
 
== Support ==
Post any Query in the Support Section.
I would be more than Happy to answer them.