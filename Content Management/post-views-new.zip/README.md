=== Post_views ===
=================

Contributors: bansod_deven

Donate Link: facebook.com/bansoddeven

Tags: Post Views, Page Views

Requires at least: 3.7

Tested Up to: 3.7

Stable Tag: 1.0

License: GPLv2

License URI: http://www.gnu.org/licenses/gpl-2.0.html

A very Simple Wordpress Plugin for showing "Number of views" for each of the Post till date.


== Description ==
 * Wordpress Plugin for viewing Number of views for the Post.
 * This simple Plugin Helps the Admins to get the Info about the Views till date of various posts on        
    the Blog.
 * This may help them to Judge their various Authors and may also get the Idea of the tastes of 
    their readers.

== Installation ==
 * Just Download the Zip, Extract it in your 'Wordpress root directory/wp-content/plugins/'.
 * Goto the Dashboard->Plugins->Installed Plugins.
 * You wil see the Plugin Posts_views listed there.
 *  Go and Activate it. And Enjoy.

== Changelog == 
None

== Upgrade Notice == 
Download The New Zip File and Paste in the folder where original Files are there  

== Screenshots == 
None

== Frequently Asked Questions ==
If any problem, mail me at devenbansod [dot] bits [at] gmail [dot] com.

Thanks
