=== Prosite Merge New Blog Template ===
Contributors: voltairemakeit
Donate link: none
Tags: new blog templates, prosites, wpmudev
Requires at least: 4.2.2
Tested up to: 4.2.2
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically assigned a template (New Blog Templates) to a level (Pro Sites)
Look for Prosite Level New Blog Template the new plugin

== Description ==

With the Prosite Merge New Blog Template you can allocate New Blog Templates to Pro Sites levels. The user who register choose a level and a template is automatically chosen. Prosite Merge New Blog Template works with New Blog Templates plugin from WPMUDEV and Pro Sites plugin from WPMUDEV. Pre Made Blog Template can be easily assigned to each Level at the sign up easily.

This is an add-on to the beautiful plugins New Blog Templates and Pro Sites levels from WPMUDEV (you need those first). If If something is broken, don't blame them.  See [http://wpmudev.com](http://wpmudev.com) for the official, original plugins.

It's been a feature waited for years by the users of WPMUDEV plugins ;)

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the prosite-merge-new-blog-template folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Do I need the New Blog Templates and Pro Sites to make the Prosite Merge New Blog Template working =

Yes.

= How to map a template and a level? =

In the dashboard of the main site go to the Prosite Merge New Blog Template menu.
The first column displays the level id from Pro Sites.
The second column displays the level name from Pro Sites.
The third column displays the template id from New Blog Templates.
The fourth column displays the template name from New Blog Templates.
The fifth column displays a list of template id from New Blog Templates.

You can modify the template assigned to a level in the fifth column and click on save.


== Screenshots ==

1. Menu

== Changelog ==

= 1.4 =
* Redirection.

= 1.3 =
* Redirection to the new plugin.

= 1.2 =
* Plugin to delete.

= 1.1 =
* Better description.

= 1.0 =
* First release.

== Upgrade Notice ==

= 1.4 =
Redirection.

= 1.3 =
Redirection to the new plugin.

= 1.2 =
Plugin to delete.

= 1.1 =
Better description.

= 1.0 =
This is the first release.