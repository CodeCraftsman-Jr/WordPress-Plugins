<div class="error clearfix push-monkey-unknown-client" style="background-image:url('<?php echo $image_url; ?>')"> 
	<div class="button-wrapper">
		<a href="<?php echo $settings_url; ?>" class="push-monkey-btn">Sign In</a>
	</div>
	<div class="text-wrapper">
		<h4>You are almost ready to send desktop push notifications!</h4>
		<p>
		Go <a href="<?php echo $settings_url; ?>">here</a> to sign in with your Push Monkey account or create an account on-the-spot. 
		<a href="http://www.getpushmonkey.com/help?source=plugin#q16" target="_blank">More info about this &#8594;</a>
		</p>
	</div>
</div>
