=== Plugin Name ===
Contributors: Ontwerpstudio Trendwerk, Harold Angenent
Donate link: http://plugins.trendwerk.nl
Tags: page,order,pageorder,management,overview,more,show,ordering,hierarchy,structure
Requires at least: 2.8.5
Tested up to: 2.9.1
Stable tag: 2.1

This plugin is no longer supported! Use WP's Custom Menu! Allow users to order pages easily in the page overview and also add some clarity to the overview. Also includes the Show more pages plugin.

== Description ==

This plugin is no longer supported! Use WP's Custom Menu! Allow users to order pages easily in the page overview and also add some clarity to the overview. Also includes the Show more pages plugin.

With this plugin its really easy for you and your clients to manage pages. You can drag and drop pages to where you want them. Also, with the Show more pages plugin, you can choose how many pages you want to show in the overview. That way, theyre easier to manage.


== Installation ==

1. Extract the contents to the `/wp-content/plugins/page-manager/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

For tips on how to use this plug-in, scroll to How to use.


== Frequently Asked Questions ==


== Screenshots ==

1. Order pages easily by dragging the move icon up or down

== Changelog ==

= 2.0 =
* WP 3.0 compatible

= 1.1 =
* Removed Show more pages (read why on the blog)
* Fixed a small php bug

= 1.0 =
* Plugin created


== Quick list ==

* Easily manage your pages
* Adds more structure to the pages overview
* Choose how many pages you want to show on the page overview