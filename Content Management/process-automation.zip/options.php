<h3>Tidio Automation</h3>
<p>Click "Go to Tidio Automation" to continue to your panel.</p>
<a href="<?php echo "https://external.tidioautomation.com/access?privateKey=".self::getPrivateKey(); ?>" class="button button-primary" target="_blank">Go to Tidio Automation</a>