=== Abandoned Cart Automations for Woocoomerce ===
Contributors: tidiotidio,maciekmp
Tags: abandoned cart, shopping cart abandonment, woocommerce, tidio, automation, post, plugin, admin, zopim, marketing automation, abandon cart
Donate link: http://www.tidioautomation.com/
Requires at least: 3.4
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An incredibly simple plugin that encourages customers to finish their purchase by  sending a reminder of the items they have left in their carts 

== Description ==

= BOOST YOUR SALES THROUGH EMAIL AUTOMATION AND EARN AT LEAST 15% MORE! =

Our Abandoned Cart Plugin gives you the ability to remind your users of items they left in their carts without having made a purchase. This simple and effective technique brings users back to your website and gives them a refreshed look at your products. With Automation, not only can you remind your users of their abandoned cart but you can also offer them special discounts on certain products on their next visit to your store,( i.e. “Thanks for returning to the site, How about a 5% discount?”). You will also be able to add these users to your Help-center or register them as a ticket in your system

The installation process couldn’t be any easier. Just add the plugin to your store and you’ll be ready to start automating processes. You won’t have to Login or register at all.

= Aside from “Abandoned Cart” you will have a wide selection of other Automations at your disposal which will help increase the sales of your E-Store: =

* Send an email when a user adds a product to the cart but doesn’t proceed to the payments section, conversion grows between 3% and 5%
* Send an email to a visitor when they create a new account with you, conversion grows 0.5%
* Send an email 7 days after registration, offering a discount coupon, conversion grows 3%
* Send an email when user experiences a problem with payment, conversion grows 2%
* Send recurring, personalized email offers, conversion grows between 1% and 2% with each email
* Create your own Automations to suit your business and marketing need

= This plugin is completely free! =

[youtube https://www.youtube.com/watch?v=fFR7OMmFqYc]

== Installation ==

1. Go to WordPress Control Panel
1. Click "Plugins", then "Add New"
1. Type "Tidio Automation" and click "Search Plugins"
1. Download and install the Plugin
1. Click the "Activate Plugin" link
1. Move to the "Process Automation" section in the menu
1. Done! Now you can start collect your data

== Frequently Asked Questions ==

= Do I need to sign up in order to use the Process Automation? =
No, in order to use the Automation you just need to install the add-on and it’s done! 
No registration/logging in.    

= Do I need to know any programming language to install Process Automation? =
No

= Can I install Process Automation on my plain html site? =
Yes

== Screenshots ==
-

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.
