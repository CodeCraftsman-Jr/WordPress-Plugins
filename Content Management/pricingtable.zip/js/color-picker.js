	jQuery(document).ready(function(jQuery)
		{	

	jQuery(document).on('click', '#pricingtable_admin', function()
				{
					
					
					jQuery('.pricingtable_cell_header_bg_color, .pricingtable_cell_signup_bg_color, .pricingtable_cell_price_bg_color, .pricingtable_cell_signup_button_bg_color').wpColorPicker();
					
					
						
			})

		});