jQuery(document).ready(function()
	{

	jQuery(document).on('dblclick', '.header-pack', function()
		{
			jQuery(".header-pack").toggleClass("lock open")
		
		})



	jQuery(document).on('dblclick', '.signup-pack', function()
		{
			jQuery(".signup-pack").toggleClass("lock open")
		
		})



	jQuery(document).on('dblclick', '.price-pack', function()
		{
			jQuery(".price-pack").toggleClass("lock open")
		
		})





				

	});	







