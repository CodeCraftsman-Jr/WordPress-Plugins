=== Progressive License ===
Tags: creative commons, license, licensing
Contributors: alexkingorg
Requires at least: 2.2
Tested up to: 2.6
Stable tag: 1.0

Progressive license is a plugin that gives authors an opportunity to put Creative Commons or Custom Licenses on their posts.

== Description ==

Progressive license is a plugin that gives authors an opportunity to put Creative Commons or Custom Licenses on their content.  It also gives authors the ability to put time frames on the licenses.  This give the authors the chance to use a different license depending on how old their post is.

Development of this plugin was sponsored by the good folks at <a href="http://redmonk.com">RedMonk</a>.

== Details ==

Progressive License gives you the follow functionality:

* Create custom licenses
* Add a license to a post depending on the date of the post
* Add a license image to your post to show the current license

== Installation ==

1.  Download the plugin archive and expand it (you've likely already done this).
2.  Put the progressive-license.php file into your wp-content/plugins/ directory.
3.  Go to the Plugins page in your WordPress Administration area and click 'Activate' for Progressive License
4.  Go to the Progressive License Options page (Options > Progressive License) to set your license preferences.
5.  Optional - add new licenses as desired

== Configuration ==

There are a number of configuration options for Progressive License.  You can find these in Options > Progressive License

== Known Issues ==

None at the current time.

== Frequently Asked Questions ==

None at the current time.

= Anything else? =

That's it - enjoy!