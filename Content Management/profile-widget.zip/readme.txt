=== Profile widget ===
Contributors: ryanhellyer
Donate link: https://geek.hellyer.kiwi/donate/
Tags: widget, profile, avatar
Requires at least: 3.4
Tested up to: 4.4
Text Domain: profile-widget
Stable tag: 1.1



A WordPress widget for displaying user profile information on single post pages.

== Description ==

A WordPress widget for displaying user profile information on single post pages.

<a href="https://geek.hellyer.kiwi/products/profile-widget/">See the Profile widget page for more information</a>.

= Languages =

* English
* German

== Installation ==

Simply install and activate. You will then have a new widget available to use called the "Profile widget".

<a href="https://geek.hellyer.kiwi/products/profile-widget/">See the Profile widget page for more information</a>.

== Frequently Asked Questions ==

Q. Where is the settings page?
A. There is none.

<a href="https://geek.hellyer.kiwi/products/profile-widget/">See the Profile widget page for more information</a>.

== Screenshots ==

1. The <a href="https://geek.hellyer.kiwi/products/profile-widget/">Profile widget</a> in action.
2. The <a href="https://geek.hellyer.kiwi/products/profile-widget/">Profile widget</a> as shown in the widgets section of the admin panel.

== Changelog ==

= 1.1 (21/12/2014) =
* Changed domain references to <a href="https://geek.hellyer.kiwi/">geek.hellyer.kiwi</a>
* Fixed bug affecting an applied filter
* Improved data escaping on output
* Added a better screenshot
* Moved the screenshot to the /assets/ folder

= 1.0.2 (13/1/2013) =
* Modified the readme.txt file

= 1.0.2 (10/1/2013) =
* Fixed bug with before and after widget text

= 1.0.1 (23/11/2012) =
* Added readme.txt file for WordPress.org plugin repository
* Added license.txt file

= 1.0.1 (12/11/2012) =
* Initial plugin creation

== Credits ==

* <a href="http://www.dss.dep.no/">DSS</a> - Norwegian Government Administration Services (provided resources to help improve the plugin)<br />
* <a href="http://metronet.no/">Metronet</a> - Provided resources to help improve the plugin<br />
