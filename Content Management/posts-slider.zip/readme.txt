=== Posts Slider ===
Contributors:umarbajwa,websettler
Donate link: http://web-settler.com/posts-slider/
Tags:widget,pages,best carousel slider,best post slider, best responsive slider,best slideshow, best slideshow plugin, carousel slider,excerpt,image, get posts, image, image slider,image slideshow, images,news slider,custom post type,nivo slider, owl slider, popular posts,Post,post slider, post slider plugin, posts, posts slider,recent, recent post, recent post slider,recent posts, responsive carousel,responsive carousel slider,responsive slider, responsive slideshow,royal slider, sidebar slideshow,slider,slideshow, sticky, testimonial scroller, thumbnail,thumbnail slider,ticker,wordpress  slideshow,slider,shortcode,sidebar,woocommerce,woo commerce products,woo commerce slider,product slider
Requires at least:3.3 
Tested up to: 4.0
Stable tag:1.3
License:GPLv2 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create beautiful and elegant posts sliders easily in minutes. Supports Woocommerce , Custom post types.

==Description==

Posts Slider is a WordPress posts content slider plugin with touch for mobile devices. Posts slider displays your blog's recent posts using beautiful slider. Description Posts slider is light weight touch supported, responsive posts content slider plugin.Manage your posts to show in slider with custom taxanomies (categories, tags,authors e.t.c), With pre-designed layouts to save your time. Simple and easy to use no coding skills required.


<strong> Featured on : <a href='http://www.wpbeginner.com/showcase/9-most-popular-free-responsive-wordpress-slider-plugins/' target='_blank'>wpbeginner</a>, <a href='http://themesurface.com/wordpress/free-posts-slider-wordpress-plugins/' target='_blank'>Theme Surface</a>, <a href='http://www.designrazzi.net/wordpress-slider-plugins.html' target='_blank'>Designrazzi</a></strong>

* Responsive touch slider.
* Carousel + single slide slider option.
* Fully Customizable slider.
* Select how much posts to display and order them by popularity or date.
* Entire slide links to post.
* Fast support + Free Updates.
* Mouse Draggable
* Pre-designed layouts.

<strong> <a href='http://web-settler.com/posts-slider/'>Premium version</a> </strong>
* Supports Custom Post Types.
* Supports WooCommerce Products.
* Custom Styling.
* Select what taxonomies to include in carousel (categories, tags, author e.t.c.).
* Transition effects.


Wants to create Unlimited Posts Sliders <a href='http://web-settler.com/posts-slider/' target='_blank'>Get Premium Version</a>


== Screenshots ==

For Screenshots and more inforamtion Visit: <a href="http://web-settler.com/posts-slider">Screen Shots</a>


 == Installation ==
* Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

* Find menu item entitled Posts Slider.
* Create Your Slider.
* Use shortcode to make slider visible.


== Changelog ==

= 3.0 =
* Included All features for free.
* Can create unlimited slider.






