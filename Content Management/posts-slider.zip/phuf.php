<style type="text/css">
html{
	background: #333333;
}
.wrapper{
	width: 100%;
	height: 100%;
	background: #333333;
	text-align: center;
}

#msg{
	margin: 25% 10% 25% 10%;
	text-align: center;
	background: #e3e3e3;
	padding: 10%;
}
h2{
	font-weight: 100;
	font-family: sans-serif;
}	
</style>

<div class='wrapper'>
	<div id='msg'>
		<h2>You have reached maximum number of Posts Slider To get Unlimited Slider visit : <a href="http://web-settler.com/posts-slider">Premium Version</a></h2>
	</div>
</div>