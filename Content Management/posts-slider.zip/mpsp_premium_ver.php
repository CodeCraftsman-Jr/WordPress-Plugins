<?php

function mpsp_premium_ver_metabox($post){

?>
<style type="text/css">
	#mpsp_rate_button{
		text-align: center;
		padding:8% 5% 8% 5%;
		background:#FFA635;font-size:19px;border:none;color:#fff; border-bottom:8px solid #E08A1C;
		text-decoration: none;
	}
	#mpsp_rate_button:hover{
		background: #FF9918;

	}
	#mpsp_rate_button:active{
		border: none;
		padding-top: 9%;
	}

</style>

<li>
	Create Unlimited Posts Sliders.
</li>
<li>
	Add Custom Styling.
</li>
<li>
	Unlock All Layouts.
</li>
<li>
	Unlock All features.
</li>
<li>
	Premium Version Supports Taxanomies.
</li>
<li>
	All Custom Post Types Supported.
</li>
<li>
	Supports WooCommerce Products.
</li>
<li>
	Use Posts Slider as widget.
</li>
<a style='text-decoration: none;' href="http://web-settler.com/posts-slider/" target='_blank'><div id='mpsp_rate_button' style=''>Get Premium Version</div></a>


<?php

}





 ?>