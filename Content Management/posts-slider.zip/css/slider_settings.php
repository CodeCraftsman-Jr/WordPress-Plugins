<style type="text/css">

.owl-item{
	
	background-color:black;

}



</style>