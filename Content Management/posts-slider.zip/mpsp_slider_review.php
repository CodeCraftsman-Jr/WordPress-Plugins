<?php

function mpsp_slider_review($post){

?>
<style type="text/css">
	#rate_button{
		text-align: center;
		padding:8% 10% 8% 10%;
		background:#FFA635;font-size:22px;border:none;color:#fff; border-bottom:8px solid #E08A1C;
		text-decoration: none;
	}
	#rate_button:hover{
		background: #FF9918;

	}
	#rate_button:active{
		border: none;
		padding-top: 9%;
	}

</style>
<p>Please Support us by rating us five stars, It matters alot.<br> <i>Thank you</i></p>
<a style='text-decoration: none; 'href="http://wordpress.org/support/view/plugin-reviews/posts-slider#postform" target='_blank'><div id='rate_button' style=''>Rate This Plugin</div></a>


<?php

}





 ?>