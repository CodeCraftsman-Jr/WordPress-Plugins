jQuery(document).ready(function(){
			    jQuery('.mpsp-color-picker').wpColorPicker();
			});