<?php

/*
Plugin Name:Posts Slider Free
Description: Creates  beautiful Slides of your Posts.
Author: Umar Bajwa
Plugin URI: http://web-settler.com/posts-slider/
Author URI: http://web-settler.com/posts-slider/
Version:1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://web-settler.com/posts-slider/
*/

/*  Please do not Modify the code od ths plugin without permission. Thank you */

include 'mpsp_cs_post_type.php';
include 'mpsp_metaboxes.php';
include 'mpsp_scripts.php';
include 'mpsp_shortcode_gen.php';



?>