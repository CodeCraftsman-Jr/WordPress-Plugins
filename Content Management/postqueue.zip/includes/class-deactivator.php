<?php

/**
 * Fired during plugin deactivation.
 */
class Ph_Postqueue_Deactivator {

	/**
	 * deactivate plugin
	 */
	public static function deactivate() {

	}

}
