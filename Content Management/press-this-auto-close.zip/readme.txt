﻿=== Press-this auto close ===
Plugin Name: Press-this auto close 
Contributors: haoqisir
Donate link: http://haoqis.com/
Tags: baidu, analytics, statistics, stats, tracking
Requires at least: 3.0.0
Tested up to: 3.3.2
Stable tag: trunk

This is a plugin for Press-this tool, it auto close your window when you publish your post after 3 seconds. 

== Description ==
This is a plugin for Press-this tool, it auto close your window when you publish your post after 3 seconds. 

该插件为wordpress的"快速发布",添加在3秒后自动关闭其窗口的功能.

== Installation ==
1. Upload  to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= where is the press-this =

/wp-admin/tools.php

== Changelog == 
= 1.1 =
init release

