<?php
	//Silence is golden.
