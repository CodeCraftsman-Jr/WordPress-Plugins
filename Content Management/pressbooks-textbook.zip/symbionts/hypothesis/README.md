##Install Directions

Just enable the plugin and your Wordpress site will have Hypothesis enabled. No settings to fiddle with (for now)

