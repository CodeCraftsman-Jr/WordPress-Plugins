<?php

    namespace EchoSign\Options;
    
    class GetDocumentImageUrlsOptions extends AbstractDocumentOptions {}