<?php

    namespace EchoSign\Options;
    
    class GetDocumentUrlsOptions extends GetDocumentsOptions {}