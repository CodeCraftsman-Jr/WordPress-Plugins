=== DomainLabs Whois ===
Contributors: bmericc
Donate link: http://links.bahri.info/donation
Tags: whois, domain, search, whois search, wp whois, wordpress whois, domain whois, whois plugin, wordpress whois plugin, ip whois
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0.3

DomainLabs Domain Whois Plugin for Wordpress 

== Description ==

DomainLabs whois plugin; domain and Ip address whois lookup allows you on with Wordpress

== Installation ==

1. Upload `domainlabs-whois.zip` to the `/wp-content/plugins/` directory
1. Extract to this directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Add to domain whois widget to your templates
1. Create to page or entry for whois result pages
1. Add to %%whoisresults%% keyword in created page or entry
1. Set to whois result page url Settings -> Domain Whois 

== Screenshots ==

1. This screen shot Settings -> Domain Whois
2. This screen shot widget
3. This screen shot whois results page

== Frequently Asked Questions ==

Nobody asked anything yet

== Changelog ==
1.0.3

* wordpress 4.1 support

1.0.2.1

* just readme files typo fixed

1.0.2

* .tr whois encoding(iso8859-9) problem has been fixed
* added support for querying whois server domain names are not on our list

1.0.1

* .us, .uk, .ch support has been added

1.0

* First version published

== Upgrade Notice ==

* An optional update. You can look at Changelog
