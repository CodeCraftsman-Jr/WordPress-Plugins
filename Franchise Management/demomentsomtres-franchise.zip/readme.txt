=== DeMomentSomTres Franquicia ===
Contributors: marcqueralt
Tags: franchise manager, stores
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later

DeMomentSomTres Franquicia

== Description ==
Manages the communication for a franchises showing each one of the shops allowing to publish their "own blog", their "own events" and their own social networks

= Features =
* Store posttype with store specific information
* Event Manager and Posts integration

= History & Raison d’être =
* Initiallu designed for [Xerigots](http://xerigots.cat)

== Installation ==

This label generator can be installed as any other WordPress Plugin.

It requires DeMomentSomTres Tools plugin.

The system should be configured with allow_open directive active.

== Frequently Asked Questions ==


== Screenshots ==

== Changelog ==
= 1.0.1 =
* WooCommerce compatibilty Bug

= 1.0 =
* Initial release
* Translation ready