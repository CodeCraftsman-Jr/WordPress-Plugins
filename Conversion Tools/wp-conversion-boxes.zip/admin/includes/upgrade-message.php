<?php

$upgrade_message = "<span style='display: block; font-size: 12px; color: grey;'><a href='http://wpconversionboxes.com/?utm_source=Upgrade+To+Pro&utm_medium=link&utm_campaign=WPCB' target='_blank'><em>".__('Upgrade To Pro','wp-conversion-boxes')."</em></a> ".__('to be able to use this feature.','wp-conversion-boxes')."</span>";

?>