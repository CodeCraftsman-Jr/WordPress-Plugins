<?php
# Silence is golden.

