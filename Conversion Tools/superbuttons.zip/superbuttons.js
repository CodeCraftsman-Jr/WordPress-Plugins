jQuery(document).ready(function(){
	jQuery(".superbutton a span").dropShadow({left: 1, top: 1, opacity: 1, blur: 0, color: "#222"});
	jQuery(".sprbtn_lightgray a span").dropShadow({left: 1, top: 1, opacity: 1, blur: 0, color: "#fff"});
});