tinyMCE.addI18n('en.superbuttons',{
	desc:"Create A SuperButton",
	superbutton_title:"Create a SuperButton",
	text:"Button Text",
	button_link:"Link",
	title:"Title",
	image_url:"Image URL",
	style:"Style",
	target:"Target",
	open_in_the_same_window:"Open link in the same window",
	open_in_a_new_window:"Open link in a new window",
	rel:"rel-attribute"
});