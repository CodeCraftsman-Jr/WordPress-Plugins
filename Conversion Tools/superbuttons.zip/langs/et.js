tinyMCE.addI18n('en.superbuttons',{
	desc:"Sisesta SuperButton",
	superbutton_title:"Sisesta SuperButton",
	text:"Nupu tekst",
	button_link:"Link",
	title:"Tiitel",
	image_url:"Pildi URL",
	style:"Stiil",
	target:"Target",
	open_in_the_same_window:"Ava link samas aknas",
	open_in_a_new_window:"Ava link uues aknas",
	rel:"rel-atribuut"
});