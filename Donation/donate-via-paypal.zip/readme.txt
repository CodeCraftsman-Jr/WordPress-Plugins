=== donate via paypal ===
Contributors: smoothcoding
Donate link: http://phppoet.com/donate/
Tags: donate , via , paypal ,donation , plugin , after , post , content
Requires at least: 3.3
Tested up to: 3.5
Stable tag: 1.1.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A wordpress plugins to add paypal donation button after each post content .

== Description ==

A wordpress plugins to add paypal donation button after each post content . 
It has been developed for not profiting organizations . It comes with options to select weather you want to display it on post , pages or both . 
you can also add some text before your paypal donate banner via options. 

== Installation ==

1. Upload `plugin` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1.go to settings -> donate via paypal and add your options . 

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

== Screenshots ==
1. Screenshot donatie butten after each post content
2. Screenshot paypal admin options
3. Screenshot extra text after banner

== Changelog ==

added currency support

== Upgrade notice ==



== Support and feature request ==

visit http://phppoet.com/donate-via-paypal-wordpress-plugin/ for support and feature request . 