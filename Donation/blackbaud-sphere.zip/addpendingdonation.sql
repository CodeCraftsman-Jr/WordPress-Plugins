ALTER TABLE `wpgu34buyn_2_supporters` ADD `pending_donations` DECIMAL(10,2) NOT NULL AFTER `amount_raised`;
ALTER TABLE `wpgu34buyn_3_supporters` ADD `pending_donations` DECIMAL(10,2) NOT NULL AFTER `amount_raised`;
ALTER TABLE `wpgu34buyn_4_supporters` ADD `pending_donations` DECIMAL(10,2) NOT NULL AFTER `amount_raised`;
ALTER TABLE `wpgu34buyn_supporters` ADD `pending_donations` DECIMAL(10,2) NOT NULL AFTER `amount_raised`;