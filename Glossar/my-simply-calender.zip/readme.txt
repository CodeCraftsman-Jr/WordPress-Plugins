=== My Simply Calender ===

Contributors: adityasubawa
Donate link: http://www.adityasubawa.com
Tags: calender, simple calender, simply calender
Requires at least: 3.2
Tested up to: 3.5.1
Stable tag: 1.2

very simple and basic calender for wordpress site. easy to install and no configuration at all. 

== Description ==

My Simply Calender is very simple and basic calender for wordpress site. easy to install and no configiration at all.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `cal-mechanic.zip` to the `/wp-content/plugins/` directory. You can do this using 'Upload' functionality provided in plugins section of your wordpress dashboard
2. Activate the plugin through the `Plugins` menu in WordPress
3. Go to `Appearance` >> `Widgets` and drag `My Simply Calender` in to your widget area.
4. Save
5. You are done. 

== Screenshots ==

1. Display Example

== Frequently Asked Questions ==

= How to editing display of red text on the Widgets? =

Red letters means a holiday or rather was Sunday. to edit, open the file wp-calmechanic.php and looking '$warna="#FF0000"' and replace with your colour.

== Changelog ==

= 1.0 =

Fix style on frontpage

= 1.1 =

fix help URL

= 1.2 =

Plug-in is now compatible upto wordpress version 3.5.1

== Credits ==

[Aditya Subawa](http://www.adityasubawa.com/) - This plugin was created by Aditya Subawa. If you like this widget and would like to donate to help support new versions of this widget you can do so at the <a href="http://www.adityasubawa.com">support center</a> website.

== Contact ==

If you need help, support or would just like to provide your comments and suggestions you may visit us online at <a href="http://www.adityasubawa.com">my personal website</a> or <a href="http://balimechanicweb.net">web design</a> support center.

