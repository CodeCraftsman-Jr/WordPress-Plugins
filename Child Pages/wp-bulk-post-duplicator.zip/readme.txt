=== WP Bulk Post Duplicator ===
Contributors: rajeshsantosh
Tags: wordpress, duplicate posts, bulk duplicate, duplicate post by year, bulk duplicate posts,huge posts duplicate, large posts duplicate, duplicate pages, bulk duplicate pages,duplicate bulk pages
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.1
License: GPLv2

Plugin duplicates the posts,pages all at once based on the post type,post status and even year of posts created.

== Description ==

This plugin used to duplicate the posts all at once based on the post type,post status and even year(optional) of posts created and also allows to select the status of posts being duplicated. It provides an interface from where the admin can choose the post types,post status and even year of post created. Admin can also select status of posts being duplicated.By default the post with be duplicated with "draft" status.
the success message displays number of posts duplicated.

== Installation ==

To install WP Bulk Post Duplicator

1. Use WordPress' built-in installer
2. Access the "WP Bulk Posts Duplicator" menu option under Settings.

== Frequently Asked Questions ==

= Does this plugin support custom post types? =

Yes, all registered custom post types are supported.

= How to duplicate custom post types? =

Go to wp-admin >> Settings >> WP Bulk Posts Duplicator and choose the custom post-type and the post status to be duplicated.

== Screenshots ==

1. Screenshot of main screen, choosing post-type and custom post-type to duplicate.


== Changelog ==

= 1.1 =
* update on tagging categories of posts getting duplicated