var BizChatId = BizChat_widget_object.BizChatId;
var WidgetId = BizChat_widget_object.WidgetId;

(function () {   
	var script = document.createElement('script');
	script.src = biz.biz_chat_plugin_path;
	document.getElementsByTagName('HEAD').item(0).appendChild(script);    
})();
