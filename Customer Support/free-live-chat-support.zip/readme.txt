=== BizChatBox - Free Live Chat Plugin ===
Contributors: BizChatBox
Donate link: https://www.BizChatBox.com
Tags: chat, livechat online, livechat, chats, live chat, bizchatbox, web chat, online chat, chat online, wordpress chat, customer support, live help, chat widget, customer help, chat widget, Free chat, free live chat, plugin, widget, chat plugin, ecommerce, live chat plugin, live help, visitor chat, WordPress chat, online support, support, support plugin, live help, Post, Posts, sidebar, page, pages, comments, e-commerce, notification, social, widgets, wp chat
Requires at least: 3.0.1
Tested up to: 4.3.1
Stable tag: trunk

BizchatBox is a 100% FREE hosted live chat software that allows businesses to engage with their customers in real time. Try it for free!

== Description ==

BizChatBox  is a Web App that makes it easy for website owners to chat with their visitors from anywhere. BizChatBox is packed with all the features you need to provide premium customer support. It is light weight, reliable, customizable and scalable chat widget. Gain your competitive advantage today.

Website : www.bizchatbox.com

Demo : https://www.youtube.com/watch?v=ABVqQVsmpbE

Installation: https://www.youtube.com/watch?v=sq5rHwvYv8Q


100% Free

Unlimited Chat Widgets

Unlimited Chats on unlimited websites, blogs, forums etc

Unlimited Operators Accounts

We support 30+ Languages

iPhone and Android Mobile Apps

No advertisements

Highly customizable look and feel design

Geo-location data for users -- know where your visitors are from

Ban users by IP also unblock them as you need

Daily emails reports

Full chat transcript history

User ratings for interactions

Customizable canned responses for common questions

Integrations with third party products

Chat Widget Animations

Custom Image on chat Widget

Use animated GIF for chat widget images

if you have any problems using BizChatBox please do not hesitate to contact us : info@bizchatbox.com

== Installation ==

Installation: https://www.youtube.com/watch?v=sq5rHwvYv8Q

1. Install and activate plug-in.
2. Click on the new BizChatBox button in your left sidebar.
3. Click on Setup Your Chat Widget button.
4. Sign in or create a new account 
5. Select a widget for your web site.
6. Click the link to your BizChatBox dashboard and get ready to Customer Support!

== Frequently Asked Questions ==

1. Do I have to install any extra software?

No, just this plugin.
 
2. How can I change the appearance of the widget on my page?

You can change all your widget settings from your BizChatBox dashboard.

3. What pricing plans do you offer?

BizChatBox is 100% Free.
 
4. Are there any advertisements?

No! There are no annoying ads in BizChatBox.
 
5. What do my visitors see if I'm not online to take their chats?

You decide! Your widget can display an offline indicator, disappear entirely, or let visitors email you with their questions.
 
6. Can I temporarily remove the chat widget from my site without losing my settings?

Yes, deactivating the BizChatBox plugin will stop the widget from showing up, but your preferred widget settings will remain for when you want to reactivate it.


== Screenshots ==

1. Chat Widget Minimized

2. Live Chat Widget 

3. Customize Chat Widget via BizChatBox Dashboard

== Changelog ==
= 1.8 =
* Improved UI and resolve cross template issues

= 1.7 =
* Safari Browser issue resolved. UI Improved

= 1.6 =
* Cross Browser sign up issue resolved and minor UI changes

= 1.5 =
* GEO IP issue resolved 

= 1.2 =
* Load performance improved. Layout improvements. 

= 1.1 =
* Minor Bug fixes

= 1.0 =
* Plugin launch.


== Upgrade Notice ==
= 1.8 =
* Improved UI and resolve cross template issues

= 1.7 =
* Safari Browser issue resolved. UI Improved

= 1.6 =
* Cross Browser sign up issue resolved and minor UI changes

= 1.5 =
* GEO IP issue resolved 

= 1.2 =
* Load performance improved. Layout improvements. 

= 1.1 =
* Minor Bug fixes

= 1.0 =
* Plugin launch.



