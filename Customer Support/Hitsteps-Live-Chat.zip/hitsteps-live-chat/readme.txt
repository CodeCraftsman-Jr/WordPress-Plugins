=== Hitsteps Ultimate Live Chat ===
Contributors: hitsteps
Tags: ticket, manager, visitors, chat, message, contact, customer, live, help, support, Zopim, clickdesk, hitsteps, analytics, counter,snapengage,zopim,livechat,livehelp, realtime, analytics, stats
Requires at least: 1.5
Tested up to: 4.2.1
Stable tag: 2.01
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.hitsteps.com/features.php#price

Hitsteps is a powerful visitor manager which allow you to monitor and engage with your website visitors and convert them into customers.

== Description ==

Hitsteps Analytics is a powerful real time visitor management and live chat tool. 
It allows you to view your visitors stream and follow each visitors to know more about each pages they see. It allow you to engage with your visitors using live chat tool. You'll be provided with detailed information about each visitor such as geolocation, their first visit on your site, referer to your site, their browser, OS and device and much more!
Advantages over Google analytics includes but not limited to Detailed information of each and all visitors, ability to engage with visitors using live chat tool, heatmap for each pages, carefully pre-generated and categorized reports, real-time analytics on all reports and much more...

Read More:
http://www.hitsteps.com/features.php

== Installation ==

It is extremely easy to install.
All that you have to do is: open an account via the hitsteps website, add your site to your account and get your API Code to use the plugin.
 
View The Features That hitsteps Offers:
http://www.hitsteps.com/features.php

== Changelog ==

= 1.00 =
* Base Startup

= 1.06 =
* Fixed minor bugs

= 1.11 =
* Reduced number of tags to WordPress's standard number of 12-15 keywords.

= 1.12 =
* Added message tag

= 2.00 =
* Major GUI Upgrade


== Frequently Asked Questions ==

You'll find updated FAQs on [Support page](http://www.hitsteps.com/support.php).