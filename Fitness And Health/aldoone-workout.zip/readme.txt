=== AldoOne-Workout ===
Tags: aldoOne, workout, fitness, exercise, sport
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A responsive and simple way to display your workouts. Create new workouts, add exercises, descriptions, video links and copy-paste the shortcode into any post/page. This free version is NOT limited and does not contain any ad.

== Installation ==
1. In your WordPress admin panel, go to Plugins > New Plugin
2. Find AldoOne-Workout plugin by Alaettin Dogan and click Install now
3. Alternatively, download the plugin and upload the contents of aldoOne-workout.zip to your plugins directory, which usually is /wp-content/plugins/
4. Activate the plugin

== Frequently Asked Questions ==
= Usage =
1. Create new Workouts.
2. Add shortcode [aldoOne-workout] to any post/page.

= Support =
Email support: alaettin87@gmail.com

== Changelog ==
= 1.0 =
* Responsive Workout custom type/shortcode