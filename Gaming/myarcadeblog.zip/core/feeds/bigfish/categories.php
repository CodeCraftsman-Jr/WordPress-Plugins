<?php
$bigfish_categories = array(
  array(
    "ID"      => "21",
    "Name"    => "Adventure",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "1",
    "Name"  => "Arcade & Action",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "19",
    "Name"  => "Brain Teaser",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "5",
    "Name"  => "Card & Board",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "11",
    "Name"  => "Casino",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "26",
    "Name"  => "Family",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "15",
    "Name"  => "Hidden Object",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "3",
    "Name"  => "Mahjong",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "18",
    "Name"  => "Marble Popper",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "17",
    "Name"  => "Match 3",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "4",
    "Name"  => "Puzzle",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "29",
    "Name"  => "Strategy",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "25",
    "Name"  => "Time Management",
    "Status"  => "",
    "Mapping" => "",
  ),
  array(
    "ID"    => "6",
    "Name"  => "Word",
    "Status"  => "",
    "Mapping" => "",
  ),
);
?>