//Set up the color pickers to work with our text input field
jQuery(document).ready(function($){

	//$('#gl_marker_color').wpColorPicker();
	
});