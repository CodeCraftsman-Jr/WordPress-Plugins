﻿; <?php die( 'This file should not be used directly' ); ?>
; -- do not modify the above line for security reasons --
;
; WP Super Edit Plugin Configuration file
;
; This is a plugin configuration file for WP Super Edit.
; Each TinyMCE plugin added to WP Super Edit should have similar options.
;

; WP Super Edit options for this plugin

desc = "MsE"
notice = "Monsters Editor 1.0, powered by <a href=http://www.guiguan.net target=_blank>Laurel</a>. It brings back the passion and wisdom of latest <a href=http://www.fckeditor.net/ target=_blank>Fckeditor</a> and <a href=http://kfm.verens.com/ target=_blank>KFM</a>."
status = N

; Tiny MCE Buttons provided by this plugin

[mse]
desc = "MsE"
notice = "Monsters Editor 1.0, powered by <a href=http://www.guiguan.net target=_blank>Laurel</a>. It brings back the passion and wisdom of latest <a href=http://www.fckeditor.net/ target=_blank>Fckeditor</a> and <a href=http://kfm.verens.com/ target=_blank>KFM</a>."
status = N
row = 0
position = 0
separator = Y
plugin = "mse"