function addEvent(o,t,f){
	o.addEventListener(t,f,false);
}
