function getWindow(){
	return document.body;
}
