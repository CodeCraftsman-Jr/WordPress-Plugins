function getWindow(){
	return window;
}
