// see license.txt for licensing
function clearSelections(e){
// not possible yet
}
function setOpacity(e,o){
// not possible yet
}
