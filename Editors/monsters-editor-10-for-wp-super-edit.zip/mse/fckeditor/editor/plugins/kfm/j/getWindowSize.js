function getWindowSize(){
	return {x:window.innerWidth,y:window.innerHeight};
}
