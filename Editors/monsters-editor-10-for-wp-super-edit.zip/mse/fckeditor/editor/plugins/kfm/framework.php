<?php
require $kfm_base_path.'includes/object.class.php';
require $kfm_base_path.'includes/file.class.php';
require $kfm_base_path.'includes/image.class.php';
require $kfm_base_path.'includes/directory.class.php';
?>
