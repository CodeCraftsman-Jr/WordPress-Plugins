KFM - Kae's File Manager
version 0.7

LICENSE
see license.txt for licensing

INSTALLATION
http://kfm.verens.com/documentation

INFORMATION
http://kfm.verens.com/

BUGS AND FEATURES
http://mantis.verens.com/
