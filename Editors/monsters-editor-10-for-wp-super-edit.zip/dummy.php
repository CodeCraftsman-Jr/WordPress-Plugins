<?php
/*
Plugin Name: Monsters Editor for WP Super Edit
Plugin URI: http://www.guiguan.net/2007/07/monsters-editor-10-for-wp-super-edit/
Description: As a plugin for WP Super Edit, Monsters Editor (MsE) brings the magic of Fckeditor back to TinyMCE. So if you prefer TinyMCE as its concision, but used to Fckeditor's powerful functions, then MsE is your good choice.
Author: Laurel
Version: 1.1
Author URI: http://www.guiguan.net/
*/
?>