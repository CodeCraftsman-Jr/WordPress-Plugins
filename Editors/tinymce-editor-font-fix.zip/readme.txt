=== TinyMce editor Font FIX ===
Contributors: Yossi Jana
Donate link: http://www.webist.co.il
Tags: Tiny,tinymce, editor, tinymce editor, editor fix, tinymce fix, tinymce font, editor font, editor font fix, font fix, tinymce editor, editor font fix, wordpress editor
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 1.0

Built to run on EVERY install you have, TinyMce editor Font FIX changes unneeded css of the Tinymce editor.

== Description ==

This WordPress plugin change the font style, in my opinion, default crappy font size and font family to something better. Its all about being effective and productive. How can you be productive if the default tinyMCE font style is total crap? So here we go, this plugin gonna fix your nightmare. 

It will change the font family of TinyMCE editor to Arial and also change the font size to 15px. Its Important you to understand that its not effects your website design. This plugin was create for tinyMCE editor in admin panel. Lightweight and great plugin that everyone needs! Hope you Enjoy

 DON'T FORGET - GIVE ME 5 STARS :) THANX

The link for more info - [Webist](http://www.Webist.co.il/).

Supported by - [iDox - שיווק באינטרנט](http://www.iDox.co.il/).

***Hebrew Description***

התוסף יעזור לכם לתקן את הבעיה הידוע בעורך הויזואלי של בוורדפרס. פונט הלא ברור ולא נוח לקריאה במיוחד בשפה העברית. היא קטנה, לא ברורה ולא נוחה עבור כל משתמשי מערכת וורדפרס. התוסף משנה את גודל הכתב ל-15 פיקסל ואת הרקע לצבע אפור שנעים לעיין.

חשוב לזכור שתוסף מיועד לפנל ניהול של וורדפרס ואינו נועד לשינוי גודל הכתב בתבנית עצמה. ז"א היא נועדה לשנות / לתקן את הבעיה בעורך וויזואלי של TinyMCE בפנל ניהול של וורדפרס בלבד.

שתפו, תעבירו ותשתמשו.

רק לא לשכוח לבקר באתר
[Webist - וורדפרס](http://www.Webist.co.il/)


***Georgian Description***

მოდული დაგეხმარებათ ავტორებს ცნობილი ხარვეზების კორექტირება როგორც ვიზუალური რედაქტორი WordPress. გაურკვეველია შრიფტი და არა განსაკუთრებით იოლად წაკითხვა ებრაულ. არის პატარა, გაურკვეველი და არასასიამოვნო ყველა მომხმარებლებს WordPress სისტემა. მოდული ცვლის ზომას 15 პიქსელზე და ფონის ფერს.


არ დაგავიწყდეთ ეწვიეთ ჩვენ საიტს

***Romanian Description***


Acest plugin WordPress schimba stilul de font, în opinia mea, dimensiunea fontului implicit nasol şi familia de fonturi la ceva mai bun. Sa tot despre a fi eficient şi productiv. Cum poţi fi productiv în cazul în TinyMCE implicit stilul de font este de rahat total? Deci, aici vom merge, acest plugin va repara dvs. de coşmar. Se va schimba familia de fonturi de editor TinyMCE la Arial şi, de asemenea, modifica dimensiunea fontului la 15px. De important pe care să înţeleagă că ei nu efecte de design site-ul dvs.. Acest plugin a fost de a crea pentru TinyMCE editor, în panoul de admin. Plugin-ul uşor şi de mare, încât toată lumea are nevoie! Sper să vă bucuraţi

= Current Operations =

Changes the fonts size and the font family to 15px Arial

== Other Notes ==

*Hope you will enjoy from it as much as we do!

== Installation ==

1. Install TinyMce editor Font FIX either via the WordPress.org plugin directory, or by uploading the files to your server
2. After activating Go to create new post!.
5. That's it.  You're ready to go!

== Frequently Asked Questions ==

No questions :)

== Changelog ==

= 1.0 =
The release of the plugin.