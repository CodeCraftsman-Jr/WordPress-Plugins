=== EasyCode ===
Donate link: http://ppc.000a.de/
Tags: code, programmer,program,share,post,lightweight
Requires at least:
Tested up to: 2.8
Stable tag: 1.31
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The lightweight plugin can insert your code in your posts and comments.
For programming blogs,it can allow code to show in a more friendly way.

