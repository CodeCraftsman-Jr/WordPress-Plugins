=== WP Horoscope ===
Contributors: nguyenvanduocit
Tags: horoscope,widget,shortcut
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=FPVMDJZTR4K2L&lc=VN&item_name=Sen%20Viet%20Org&item_number=wordpress¤cy_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Requires at least: 3.0.1
Tested up to: 4.0
License URI: http://laptrinh.senviet.org

WP Horoscope - Cung hoàng đạo cho wordpress giúp hiển thị thông tin trong ngày của các cung hoàng đạo.

== Description ==
WP Horoscope là một plugin rất hay, cho phép bạn lấy thông tin trong 1 ngày của các cung hoàng đạo cho wordpress. Hỗ trợ bạn hiển thị trong widget hoặc trong shortcut.
Rất hiệu quả và tiện lợi cho các bạn thích cung hoàng đạo.

Plugin hỗ trợ hai vị trí hiển thị là trong sidebar và trong shortcode

= Cộng đồng wordpress Việt Nam =
*   [Sen Việt](https://laptrinh.senviet.org)
*   [Facebook page](https://www.facebook.com/pages/Wordpress-Vi%E1%BB%87t-Nam/1531229807110426)
*   [Google plus](https://plus.google.com/112246631672323028789?prsrc=5)

= Dành cho nhà phát triển =

**Hướng dẫn** : [Viết plugin WP Horoscope - Cung hoàng đạo cho wordpress](http://laptrinh.senviet.org/wordpress-plugin/viet-plugin-wp-horoscope-cung-hoang-dao-cho-wordpress/)
**Github** : [wp-horoscope](https://github.com/senviet/wp-horoscope)

== Screenshots ==
1. shortcut
2. widget