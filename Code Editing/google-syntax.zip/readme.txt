﻿=== google-syntax ===
Contributors: princehaku
Donate link: http://3haku.net
Tags: google, syntax, code , prettify ,syntaxhighlighter ,代码高亮
Requires at least: 2.0
Tested up to: 3.8
Stable tag: 0.2

This is a code prettify plugin. the code higlighting effect will be seen directly in the mce editor.

== Description ==

This is a code prettify plugin using google-code-prettify. click the add-code media button to insert your code. the code higlighting effect will be seen directly in the mce editor.这是一个代码高亮插件  使用google code prettify 安装后在文章发布处点击插入代码按钮即可插入代码   代码高亮效果会直接在mce中预览可见

Related Links:

* <a href="http://3haku.net">Plugin Homepage</a>
* <a href="http://code.google.com/p/google-code-prettify/">Google Code Prettify</a>

*This release is compatible with all WordPress versions since 2.0. *

== Installation ==

1. Upload the full directory into your wp-content/plugins directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. click the add-code button whick in media button to insert your code


== Frequently Asked Questions == 

== Changelog ==

Until it appears here, the changelog is maintained on [the plugin website](http://3haku.net "Changelog")

== Screenshots ==

1. click here to insert your code
2. the code in your mce editor

== License ==

This plugin is free for everyone! You can use it free of charge on your personal or commercial blog.

== Translations ==

