=== Better Code Editor ===
Contributors: nazmul.hossain.nihal
Tags: code,codes,editor,wp-admin,plugin-editor.php,theme-editor.php
Requires at least: 3.5 
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=FYMPLJ69H9EM6

Make your editor better!

== Description ==

Make you WordPress code editor with "Better Code Editor".Using this plugin you can modify your code editor.You can see line numbers,detect error in your codes.You can chose 28 different themes for your editor.

Using this you edit :

*   Themes 
*   Plugins

== Installation ==

1. Upload `better-code-editor` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Then go to the Settings >> Code Editor page to set a theme for editor

Note: Don't change "better-code-editor" directory name

== Screenshots ==

1. Code Editor
2. Themes for code editor

== Upgrade Notice ==

= 1.0 =
* Plugin Created

== Changelog ==

= 1.0 =
* Plugin Created