=== Lite Event Calendar ===
Contributors: dpereyra
Donate link: http://wpsleek.com/
Tags: calendar, events, recurring events, ical, modern, elegant, professional, unique, clean, wordpress, responsive, dates
Requires at least: 3.8
Tested up to: 4.0.1
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Lite Event Calendar plugin adds a professional and sleek calendar to your posts or pages. 100% Responsive, also you can use it inside a widget.

== Description ==

The Lite Event Calendar plugin adds a professional and sleek calendar to your posts or pages. 100% Responsive, also you can use it inside a widget.

<ul>

<li>Elegant & Sleek Design</li>
<li>Responsive Layout</li>
<li>Easy to manage Events</li>
<li>Special Dates</li>
<li>Google Map support</li>
<li>RTL support</li>
<li>Upcoming Events Widget</li>
<li>Recurring Events (Daily, Weekly, Monthly and Yearly)</li>
<li>Date range support</li>
<li>Dark/Light skin color.</li>
<li>iCal feed import</li>
<li>Filter Events by Category</li>
<li>Translate it easily.</li>
<li>Cross Browser Support</li>
<li>Simple to Customize</li>

</ul>

Get [WP Pro EventCalendar](http://codecanyon.net/item/wordpress-pro-event-calendar/2485867?ref=DPereyra "WP Pro EventCalendar") for more features.

Enjoy !

== Installation ==

Upload and install the zip file.

Once the plugin has been activated you will notice a new button in the sidebar menu called "Events Calendar".

If you want to upgrade to the PRO version, you will need to first deactivate this plugin and then activate the PRO Event Calendar.

== Changelog ==

= 1.0.2 = 
* Added Po language files

= 1.0.1 = 
* Fixed issue when seeing event

= 1.0 =
* Release

== Upgrade Notice ==

= 1.0 =
Release

== Screenshots ==

1. Calendar View

== Frequently Asked Questions ==

= Is it Multi Site ready? =

Yes!. You can use it in any WP Multisite installation.

