<form method="post" action="<?= TICKET_PLUGIN_URL;?>CI/index.php/company/insert">
    
          <div class="main_pro_pi">
               
               <div class="fileds">
               
    <div class="form_holder">
      <label><span>Company Name</span></label>
      <input type="text" value="" placeholder="Enter Company Name" name="company_name">
    </div>
                        
       <div class="form_holder">
          <button type="submit" class="sbmt sbmt_base sbmt_base-no-border"><i class="fa fa-spinner upload_icon"></i>Add</button>
       </div>
               
    </div>
    
        
         
              </div>
</form>