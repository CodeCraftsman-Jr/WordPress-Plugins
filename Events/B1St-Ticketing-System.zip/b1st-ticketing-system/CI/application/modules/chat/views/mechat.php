<li class="me">
       <div class="image_placeholder"><img src="<?= B1st_getGravatar($fromemail);?>" /></div>
       <div class="chat_txt">
              <?php echo $chatrow;?>
              <span class="time_chat">Just Now</span>
       </div>
</li>