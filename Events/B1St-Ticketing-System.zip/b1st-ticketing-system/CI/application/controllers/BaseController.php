<?php
class BaseController extends CI_Controller {
	var $model;
    	function __construct(){
        parent::__construct();
			
	}
	
}
