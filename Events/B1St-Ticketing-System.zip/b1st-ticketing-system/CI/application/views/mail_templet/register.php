<div style="border:4px solid #000;">
<table width="600" cellspacing="0" cellpadding="0" border="0" align="center" style="font-family:Arial,Helvetica,sans-serif;font-size:14px"> 
   
   <tbody>
   <tr> 
    <td width="600" height="30" style="padding-left:10px">Hello {firstname} {lastname},<br> </td> 
   </tr> 
   <tr> 
    <td width="600" valign="top" height="150" style="padding-left:10px"> 
    <p>
     {email_body}
    </p> 
    </td> 
   </tr> 
<!--    <tr> 
 <td width="600" height="30" style="padding-left:10px">Regards,</td> 
</tr>  -->
<!--    <tr> 
 <td width="600" height="20" style="padding-left:10px"><a target="_blank" style="text-decoration:none" href="#">{admin}</a></td> 
</tr>  -->
   
 </tbody>
 </table>
 <table width="480" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center" style="padding:0px;color:rgb(153,153,153);font-size:10px;line-height:1.5em;border:1px solid #fff"> 
   
   <!--<tbody><tr> -->
    <!--<td style="padding:5px 0px">To stop receiving these emails please <a target="_blank" href="#" style="color:rgb(153,153,153)">click here </a> to unsubscribe. <br> </td> -->
   <!--</tr></tbody>-->
 </table>
</div>