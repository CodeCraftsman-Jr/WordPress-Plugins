=== Plugin Name ===
Contributors: London Drum
Tags: london,event,events,listing,listings,plugin,widget,whatson,uk,music,gigs,concerts,shows,bands,singers
Requires at least: 2.8
Tested up to: 2.9.2
Stable tag: 1.0

This plugin has been discontinued. See http://www.londondrum.com/events/?cat=856

== Description ==

This plugin has been discontinued. See http://www.londondrum.com/events/?cat=856

== Installation ==

This plugin has been discontinued. See http://www.londondrum.com/events/?cat=856

== Upgrade ==

This plugin has been discontinued. See http://www.londondrum.com/events/?cat=856

== Frequently Asked Questions ==

This plugin has been discontinued. See http://www.londondrum.com/events/?cat=856
