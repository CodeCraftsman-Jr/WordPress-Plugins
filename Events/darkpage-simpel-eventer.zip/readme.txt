=== darkPage Simple Eventer ===
Contributors: darkpage.at
Tags: event, guest list, signup, party, meetup, guest, list, simple
Requires at least: 2.7
Tested up to: 2.8.2
Stable tag: 1.2

Simple create an event with guestlist and signup.

== Description ==
Darkpage Simple Eventer is an simple event script that alows you to add an signup form to any post you want.
It includes the form with 3 awnswer types and shows the Guest list.

Add [dpe] to your post to include the signup form.

= Changelog =

**v1.0**
1st release

**v1.2**
Bugfix: Fatal error on load.
Add: English support

== Installation ==

- Copy all files to your plugin direktory (wp-content/plugins/dp_eventer/)


== Usage ==

Just type [dpe] in that position you want to have the signup form with guest list.

If you wannt to change language to english you have to edit the plugin and change the $dpe_language to "en" as described.
You also can customize the language file (dpe_lang.php) and if you want add new languages.


== Frequently Asked Questions ==

= Wich language does it support? =
I only added German and English. But you can add any Language by your own.

= Is there any language file? =
Yes, called "dpe_lang.php" in same directory.

= Will it create any new database tables? =
Yes, it adds a new table to the database.


== Screenshots ==
[dpe Screenshots](http://darkpage.at/stuff/dpeventer/ "Eventer Screenshots")