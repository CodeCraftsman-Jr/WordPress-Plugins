<?php
/*
You can edit this file how you want it too for customed text!
*/

//# English

$dpl["en"]["vote1"] = "I'm in!";
$dpl["en"]["vote2"] = "Unfortunately can not.";
$dpl["en"]["vote3"] = "Can not say anything concrete.";
$dpl["en"]["your_stat"] = "Your current status";
$dpl["en"]["change_stat"] = "Change your status";
$dpl["en"]["signup"] = "Sign up now!";
$dpl["en"]["guestlist"] = "Guestlist";
$dpl["en"]["table_head_name"] = "User";
$dpl["en"]["table_head_status"] = "Status";
$dpl["en"]["no_signups"] = "no registrations now";


//# German (Deutsch)

$dpl["de"]["vote1"] = "Bin dabei!";
$dpl["de"]["vote2"] = "Kann leider nicht!";
$dpl["de"]["vote3"] = "Kann noch nichts konkretes sagen.";
$dpl["de"]["your_stat"] = "Dein aktueller Status";
$dpl["de"]["change_stat"] = "Status &auml;ndern";
$dpl["de"]["signup"] = "Jetzt Anmelden!";
$dpl["de"]["guestlist"] = "G&auml;steliste";
$dpl["de"]["table_head_name"] = "User";
$dpl["de"]["table_head_status"] = "Status";
$dpl["de"]["no_signups"] = "noch keine Anmeldungen";

?>