<?php
define("PLUGIN_LONG_NAME", "Events Calendar");
define("PLUGIN_SHORT_NAME", "ec");
define("PLUGIN_PATH", str_replace("\\", "/", substr(dirname(__FILE__), strlen($_SERVER['DOCUMENT_ROOT']))));
?>