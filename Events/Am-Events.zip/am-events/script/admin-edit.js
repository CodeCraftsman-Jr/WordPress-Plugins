jQuery(function() {

	jQuery(".trash_recurrent > a").click( function() { return confirm(localization.confirmation);} );

});