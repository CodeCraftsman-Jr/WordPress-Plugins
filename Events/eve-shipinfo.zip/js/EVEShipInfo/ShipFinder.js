var EVEShipInfo_ShipFinder =
{
	'dialogRendered':false,
		
	DialogConfigure:function()
	{
		if(this.dialogRendered) {
			this.elDialog.show();
		}
	}
};