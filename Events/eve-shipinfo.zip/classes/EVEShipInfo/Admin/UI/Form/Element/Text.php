<?php

class EVEShipInfo_Admin_UI_Form_Element_Text extends EVEShipInfo_Admin_UI_Form_ElementInput
{
	public function getType()
	{
		return 'text';
	}
}