<?php

class EVEShipInfo_Admin_UI_Form_Element_Static extends EVEShipInfo_Admin_UI_Form_Element
{
	protected function _renderElement()
	{
		return $this->name;
	}
}