=== Website Diary ===
Contributors: kahi
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=kahi%40kahi%2ecz&item_name=Kahi&no_shipping=1&cn=Your%20note%2e%2e%2e&tax=0&currency_code=EUR&lc=CZ&bn=PP%2dDonationsBF&charset=UTF%2d8
Tags: admin, administration, diary, tracking, notes
Requires at least: 2.9
Tested up to: 3.0.1
Stable tag: trunk

For keeping diary-like notes, so you can quickly overview recent changes on your site (and spot the source of an eventual problem). Adds a box on your administration dashboard. See the screenshot.

== Description ==

For keeping diary-like notes, so you can quickly overview recent changes on your site (and spot the source of an eventual problem). Adds a box on your administration dashboard. Only administrators are allowed to add and read diary-records (see the beginning of the source code for detailed explanation).

= Requirements =

**PHP 5** on your server is necessary to run this plugin.

== Screenshots ==

[Show a screenshot](http://cl.ly/d2c122f2ae13dc9609ef)

== Changelog ==

= 0.9.1 = 
* FIX: (Mostly visual) deatils 

= 0.9 = 
* (First public realease)