<?php echo $body; ?>
