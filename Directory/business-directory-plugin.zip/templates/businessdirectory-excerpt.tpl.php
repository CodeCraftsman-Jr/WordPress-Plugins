<?php echo $thumbnail; ?>

<div class="listing-details">
<?php echo $listing_fields; ?>
</div>