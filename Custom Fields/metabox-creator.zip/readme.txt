=== Plugin Name ===
Contributors: paul-henri 
Donate link: http://www.metaboxcreator.com/
Tags: metabox
License: GPLv2
Requires at least: 3.8
Tested up to: 4.1
Stable tag: trunk

Advanced tool to easily create meta boxes.


== Description ==

Advanced tool to easily create meta boxes.


== Installation ==

1. Download the plugin zip archive.
2. Extract it in your `wp-content/plugins` folder or upload via admin panel.
3. Browse to your plugins section and active the plugin


== Frequently Asked Questions ==

Soon...


== Upgrade Notice ==

None


== Screenshots ==

Soon...


== Changelog ==

= 1.0 =
* First release
