<div id="postbox-container-1" class="postbox-container">
<div class="meta-box-sortables">
<!-- Oldalsáv támogatás -->
<div class="postbox">
<h3><span>Támogatás / Licenc</span></h3>
<div class="inside">
<p style="text-align:justify">Hiba esetén kérem vegye fel velem a <script>//<![CDATA[
     eval(unescape('%70%6c%75%6d%69%34%31%3d%5b%27%25%36%62%25%37%37%27%2c%5b%27%25%36%66%25%37%32%25%36%37%27%2c%27%25%36%62%25%36%31%25%37%32%25%36%34%25%36%39%25%37%37%25%36%35%25%36%32%27%5d%2e%72%65%76%65%72%73%65%28%29%2e%6a%6f%69%6e%28%27%2e%27%29%5d%2e%6a%6f%69%6e%28%27%40%27%29%3b%65%77%70%6f%70%30%37%3d%27%6b%61%70%63%73%6f%6c%61%74%27%3b%64%6f%63%75%6d%65%6e%74%2e%77%72%69%74%65%28%65%77%70%6f%70%30%37%2e%6c%69%6e%6b%28%27%6d%61%69%27%2b%27%6c%74%6f%3a%27%2b%70%6c%75%6d%69%34%31%29%29%3b'))
     //]]></script>-ot, hogy mielőbb el tudjam végezni a javítást.<br /><br />
     A WordPress Megosztás Bővítmény programozása, karbantartása jelentős munkát igényelt és igényel, ezért alkottam meg az alábbi licenct:
     <ul>
     <li><em> 1. A felhasználó ingyenesen használhatja, telepítheti a bővítményeket saját weboldalára, blogjára. A fájlokba igénye szerint belejavíthat.</em></li>
     <li><em> 2. A bővítményt a GPL/GNU licenc értelmében nem értékesítheti, letöltésként nem publikálhatja. Közvetlen publikálás helyett javaslom hivatkozás használatát a bemutatkozó oldalamhoz!</em></li>
     </ul>
</p>
<p><center>Copyright &copy; 1986 - <?php echo date('Y'); ?><br><a target="_blank" href="http://www.kardiweb.org">Laszlo Espadas (KardiWeb)</a></center></p>
</div>
</div>
<!-- /Oldalsáv támogatás -->

<!-- Oldalsáv hasznos hivatkozások -->
<div class="postbox">
<h3><span>Hasznos hivatkozások</span></h3>
<div class="inside">
<p>
     <ul>
     <li><a target="_blank" href="http://www.kardiweb.org/">Laszlo Espadas (KardiWeb)</a></li>
     <li><a target="_blank" href="http://wordpress.org/support/plugin/wordpress-megosztas-bovitmeny">Támogató fórum</a></li>
     <li><a target="_blank" href="https://github.com/KardiWeb/WordPress-Megosztas-Bovitmeny/">Github fejlesztői oldal</a></li>
     <li><a target="_blank" href="https://github.com/KardiWeb/WordPress-Megosztas-Bovitmeny/issues">Kérdések</a></li>
     <li><a target="_blank" href="http://kozosseg.wphu.org/">WordPress Magyar Közösség</a></li>
     <li><a target="_blank" href="http://www.hostrider.eu/">Masszív wordpress tárhely</a></li>
     <li><a target="_blank" href="http://www.tutiizek.eu/">Legjobb receptek</a></li>
     <li><a target="_blank" href="http://www.tutiblog.eu/">Ingyenes WordPress blog</a></li>
     <li><a target="_blank" href="http://themeforest.net/category/wordpress/?ref=KardiWeb">Premium wordpress sablonok</a></li>
     <li><a target="_blank" href="http://codecanyon.net/category/wordpress/?ref=KardiWeb">Premium wordpress bővítmények</a></li>
     </ul>
</p>
</div>
</div>
<!--/Oldalsáv hasznos hivatkozások-->

</div> <!-- .meta-box-sortables -->
</div> <!-- #postbox-container-1 .postbox-container -->
