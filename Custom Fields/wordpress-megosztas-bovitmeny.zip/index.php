<?php
/*
Az index.php fájlt ne töröljük ki.
A Megosztás mappa védelmére szolgál.
*/
?>
