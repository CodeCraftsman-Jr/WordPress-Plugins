﻿=== Mais Comentados ===
Contributors: reitor
Donate link: http://reitor.org
Tags: widget, mais populares, comentarios, sidebar, comment, most popular
Requires at least: 2.0
Tested up to: 3.0.1
Stable tag: 1.5

Este é um widget muito simples, ele exibe links para postagens que possuem mais comentários.

== Description ==

Este widget, cria em sua sidebar(barra lateral) uma lista de links para os posts que possuem mais comentários.

Para obter uma lista completa das mudanças de cada versão, visite [a pagina do plugin](http://reitor.org/wp-plugins/maiscomentados/).

== Installation ==

1. Enviar o arquivo maiscomentados.php para o diretório de plugins do wordpress.
2. Ative o plugin.
3. Navegue para o Painel de Configuração e personalize o widget.

== Screenshots ==

1. Painel de Configuração do Plugin.
2. Exemplo de uso do plugin.

== Frequently Asked Questions ==

É configuravel?

Sim. Dê uma olhada nas opções do painel de configuração do widget.