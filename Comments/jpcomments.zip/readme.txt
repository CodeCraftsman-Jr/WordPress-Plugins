=== jpComments ===
Contributors: envex, jprim
Donate link: http://jprim.com/
Tags: twitter, comments
Requires at least: 2.9
Tested up to: 3.0
Stable tag: trunk

Override the WordPress comment system to use only a users Twitter information

== Description ==

Override the WordPress comment system to use only a users Twitter information

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `jpComments` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Style it up!

== Frequently Asked Questions ==

= Why are you guys so awesome? =

We just are.

== Screenshots ==

1. screenshot-1.png

== Changelog ==

= 1.0 =
* Initial Release into the wild