=== Plugin Name ===
Contributors: KKulikovskis
Donate link: http://cleancomments.com
Tags: comments, spam, social
Requires at least: 3.0.1
Tested up to: 4.2.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows you to use CleanComments commenting system in Wordpress

== Description ==

CleanComments allows you to have comments that have added value to your content. No more spam or excessive moderation.

This is a user-moderated commenting system, but blog/site owners still keep rights for full comment moderation.

For more info go to http://cleancomments.com

== Installation ==

1. Unzip in the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Input key that you got from CleanComments website
4. Your commenting system is set up

== Frequently Asked Questions ==

No FAQ so far.

== Changelog ==

1.0 -> 1.0.1

Fixed KEY validation bug;


== Upgrade Notice ==

None

== Screenshots ==

Screenshots will be added