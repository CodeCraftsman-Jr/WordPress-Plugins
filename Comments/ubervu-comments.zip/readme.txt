=== uberVU Comments ===
Author: uberVU Team
Contributors: emanuel.lainas
Author URI: http://www.ubervu.com
Tags: comments, reactions, ubervu
Requires at least: 2.0.2
Tested up to: 2.8.4
Stable tag: 1.2

== Description ==
This plugin displays reactions to your posts from all over the web using the ContextVoice API