<?php namespace Qdiscuss\Core\Exceptions;

use Exception;

class InvalidConfirmationTokenException extends Exception
{
}
