<?php namespace Qdiscuss\Core\Exceptions;

use Exception;

class PermissionDeniedException extends Exception
{
}
