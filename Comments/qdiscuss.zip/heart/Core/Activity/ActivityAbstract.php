<?php namespace Qdiscuss\Core\Activity;

abstract class ActivityAbstract implements ActivityInterface
{
}