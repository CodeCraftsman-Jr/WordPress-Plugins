<?php namespace Qdiscuss\Core\Search;

interface GambitInterface
{
    public function apply($string, $searcher);
}
