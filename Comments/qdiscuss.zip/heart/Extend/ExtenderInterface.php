<?php namespace Qdiscuss\Extend;

use Qdiscuss\Application;

interface ExtenderInterface
{
	public function extend(Application $app);
}