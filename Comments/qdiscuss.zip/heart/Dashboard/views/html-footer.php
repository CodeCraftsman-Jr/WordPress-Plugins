<div class="qd-footer">
	<h2><?php echo _e("See Our Other Awesomeness"); ?></h2>
	<hr>
	<div class='container well'>
		<a href="http://colorvila.com/qdiscuss" target="blank"><img alt="qdiscuss forum" src="<?php echo QDISCUSS_URI .  '/public/dashboard/images/support-forum.jpg'; ?>"/></a>
		<a href="http://colorvila.com/themes" target="blank"><img alt="qdiscuss themes" src="<?php echo QDISCUSS_URI .  '/public/dashboard/images/themes-club.jpg'; ?>"/></a>
	</div>
</div>


