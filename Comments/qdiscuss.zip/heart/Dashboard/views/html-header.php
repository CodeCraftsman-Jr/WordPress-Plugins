<!-- <ul class="subsubsub qd-header qd-fixed">
	<?php 
		$items =  \Qdiscuss\Dashboard\Dashboard::$header_menus;
		foreach ($items as $value) :
	?>
		<li class="<?php echo \Qdiscuss\Dashboard\Dashboard::get_menu_active($value['name']) ? 'qd-active' : '';?>"><a href='<?php echo $value['url']; ?>'><?php echo $value['name']; ?></a></li>
		<?php endforeach; ?>
	
</ul>
<div class="qd-header">
	<hr>
</div> -->
