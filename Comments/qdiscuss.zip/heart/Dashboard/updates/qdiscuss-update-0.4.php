<?php 
use Qdiscuss\Core\Models\Setting;

Setting::setValue('extensions_enabled', '[]');