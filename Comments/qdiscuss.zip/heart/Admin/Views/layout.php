<div class="global-page" id="page">
  <div id="back-control"></div>
  <div class="global-drawer">
	<header class="global-header" id="header">
	  <div id="back-button"></div>
	  <div class="container">
		<h1 class="header-title"><a href="#" onclick="app.history.home()">QDiscuss Admin</a></h1>
		<div id="header-primary" class="header-primary"></div>
		<div id="header-secondary" class="header-secondary"></div>
	  </div>
	</header>
  </div>
  <main class="global-content">
	<div class="side-nav admin-nav title-control" id="admin-nav"></div>
	<div class="admin-content" id="content"></div>
  </main>
</div>
