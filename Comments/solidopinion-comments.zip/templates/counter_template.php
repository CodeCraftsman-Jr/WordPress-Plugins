<div class="so_rating" data-countifnorating="true"
    data-sitename="%%SO_SITENAME%%"
    data-thread_url="%%SO_THREAD_URL%%" >
</div>
<script src="//api.solidopinion.com/widget/embed.js" async="async"></script>