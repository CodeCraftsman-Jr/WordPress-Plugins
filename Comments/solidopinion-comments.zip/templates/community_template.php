<div class="so_community"
     data-sitename="%%SO_SITENAME%%">
</div>
<script src="//api.solidopinion.com/widget/embed.js" async="async"></script>