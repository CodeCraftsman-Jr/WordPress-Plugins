=== Moderation mode planning ===
Contributors: thirad
Donate link: http://thibaultradelet.com/dev/
Tags: moderation, comments, planning
Requires at least: 2.7
Tested up to: 2.7
Stable tag: 1.0

This pluging allow you to program your moderation mode, it automatically updates the comment_moderation option, as the days and time slot selected.

== Description ==

This pluging allow you to program your moderation mode, it automatically updates the comment_moderation option, as the days and time slot selected.

== Installation ==

1. Download the plugin
2. Unzip moderation-mode-planning.zip
3. Upload the entire moderation-mode-planning folder to your plugins directory
4. Go to the Plugins page in your WordPress Administration area and click to 'Activate' the moderation-mode-planning plugin.
5. Configure your options in moderation-mode-planning page

== Screenshots ==

1. Moderation-mode-planning plugin admin page
