<div id="mc_embed_signup">
<form action="http://kevinw.us2.list-manage.com/subscribe/post?u=f65d804ad274b9c8812b59b4d&amp;id=20c3ab10d8" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
	<div class="mc-field-group updated">
		<label for="mce-EMAIL"><?php echo INCOM_NEWS_TEXT; ?></label><br>
		<input type="email" value="<?php esc_html_e( 'Enter your email address', INCOM_TD ); ?>" name="EMAIL" class="required email" id="mce-EMAIL" onclick="this.focus();this.select()" onfocus="if(this.value == '') { this.value = this.defaultValue; }" onblur="if(this.value == '') { this.value = this.defaultValue; }">
		<input type="hidden" name="GROUPS" id="GROUPS" value="<?php echo INCOM_VERSION_NAME; ?>" />
		<input type="submit" value="<?php echo INCOM_NEWS_BUTTON; ?>" name="subscribe" id="mc-embedded-subscribe" class="button">
	</div>
	<div id="mce-responses" class="clear">
		<div class="response" id="mce-error-response" style="display:none"></div>
		<div class="response" id="mce-success-response" style="display:none"></div>
	</div>
    <div style="position: absolute; left: -5000px;"><input type="text" name="b_f65d804ad274b9c8812b59b4d_20c3ab10d8" tabindex="-1" value=""></div>
</form>
</div>