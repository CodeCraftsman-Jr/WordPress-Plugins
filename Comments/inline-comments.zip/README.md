Inline Comments by [Kevin Weber](http://kevinw.de/)
====================

Inline Comments adds your comment system to the side of paragraphs, headlines and other sections (like headlines and images) of your post. It performs native with WordPress comments. You can get it from here: http://kevinw.de/inline-comments/

You may know notes and annotations from Medium.com or Quartz. It feels like commenting in Microsoft Word, it goes easy and fast. Thousands of people love inline comments.

The comment area is shown when you click the comment count bubbles (left or right) beside any section.
With this plugin commentators can better refer to specific paragraphs or statements in an article.
Furthermore, readers can comment while reading (and don't have to scroll to the very bottom).