=== noComment ===
Contributors: pasxal
Tags: noComment, comments, no comment, posts
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 1.0a

== Description ==

A plugin that shows you the posts that noone wants to comment. By activating it you can then add a widget defining how many posts you want to display.

== Installation ==
Upload the noComment plugin to your blog, and activate it.

I think you're done!

Dont forget to activate the widget!

= 1.0a =

* Functional

