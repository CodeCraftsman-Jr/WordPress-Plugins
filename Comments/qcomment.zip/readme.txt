=== qComment ===
Contributors: (qComment)
Donate link: https://qComment.ru
Tags: comments
Requires at least: 1.1.3
Tested up to: 1.1.3
Stable tag: 1.1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Exchange QComment gives you unlimited opportunities for PR and promotion on the Internet. 
Promote brands, groups in social networks, video on youtube, raise the reputation of the Internet with the comments and feedback.

== Installation ==

1) unzip the file in the folder wp-content / plugins
2) to activate the plug-in control panel, site
3) fill in a form on the page settings (Settings -> QComment). It is mandatory must be specified access key to the API, other settings - depending on the project requirements.
4) On the Create (edit) posts will be an additional block (meta box), which allows you to create a project, buy, accept or reject comments.

== Frequently Asked Questions ==

= ok? =

ok


== Screenshots ==

1. no screenshots


== Changelog ==

= 1.1 =
* Add limit to url

= 1.0 =
* first update

== Upgrade Notice ==

= 1.1 =
Add limit to url

= 1.0 =
first update



`<?php code(); // goes in backticks ?>`