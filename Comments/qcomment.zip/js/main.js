var QComment = angular.module('QComment', []);

QComment.value('projectDefaults', projectDefaults);