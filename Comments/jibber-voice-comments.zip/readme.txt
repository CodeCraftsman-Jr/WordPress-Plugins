=== Plugin Name ===
Contributors: Jibber.social
Donate link: http://jibber.social
Tags: jibber, comments, social
Requires at least: 3.0
Tested up to: 3.9.2
Stable tag: 1.0.0

Replace WordPress commenting with jibber comments

== Description ==

This plugin is a drop-in solution for replacing the default WordPress commenting system with Jibber.social

= 1.0 =
* First release.
