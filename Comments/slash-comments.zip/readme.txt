=== Slash Comments ===
Contributors: rob1n
Tags: feed, slash
Tested up to: 3.5
Stable tag: 2.0

Adds the slash:comments module to feeds, which tells the feed reader how many comments there are on the post.

== Description ==

**This plugin is now obsolete on account of the functionality being included with WordPress.**

This plugin adds the [`slash:comments`](http://web.resource.org/rss/1.0/modules/slash/) tag to RSS feeds, which 
tells feed readers such as [Google Reader](http://www.google.com/reader/) or [Bloglines](http://www.bloglines.com/) 
how many comments there currently are on that post.

A simple plugin, really. It evolved out of a [Trac ticket](http://trac.wordpress.org/ticket/4023) that didn't get 
included into the [WordPress](http://wordpress.org/) core.

== Installation ==

1. Upload `slash-comments.php` to your `wp-content/plugins` directory.
2. Activate the plugin through the Plugins menu in the WordPress admin.
3. Enjoy.