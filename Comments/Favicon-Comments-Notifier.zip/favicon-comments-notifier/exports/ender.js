!function($) {
  var notificon = require('notificon');
  $.ender({
    notificon: notificon
  });
}(ender)