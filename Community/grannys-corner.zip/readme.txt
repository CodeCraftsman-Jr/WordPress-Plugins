=== Grannys Corner ===
Contributors: opajaap
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=OpaJaap@OpaJaap.nl&item_name=Grannys-Corner&item_number=Support-Open-Source&currency_code=USD&lc=US
Tags: textwidget, widget, qTranslate
Version: 1.6
Stable tag: trunk
Author: J.N. Breetvelt
Author URI: http://www.opajaap.nl/
Requires at least: 2.8
Tested up to: 4.2

This plugin is designed to easily enter a text in a widget for a specific user without the need to enter the admin screen.


== Description ==

This plugin is designed to easily enter a text in a widget for a specific user without the need to enter the admin screen.

At activation of a Grannys Corner widget, a title can be entered and a username selected. 
When the user that 'owns' the widget is logged in, the text area is editable for him/her.
When he presses the save button, he will see the final result. 
If he/she wants to change the content, the page needs to be re-opened by the logged in user.
Multiple instances of the widget can be activated and owned by different users.
The plugin can be translated. Dutch language files are included.
The plugin supports qTranslate.

== Installation ==

You can install the plugin from the WP Admin Plugins page, or manually.

== Frequently Asked Questions ==

= How can i translate the plugin into my language? =

* Find on internet the free program POEDIT, and learn how it works.
* Use the file grc.pot that is located in grannys-corner/langs to create or update
grc-[your languagecode].po and grc-[your languagecode].mo.
* Place these file in the langs subdir.
* If everything is ok, mail me the files and i will distribute them so other users can use it too.
* For more information on POT files, domains, gettext and i18n have a look at the I18n for 
WordPress developers Codex page and more specifically at the section about themes and plugins.

== Changelog ==

= 1.6 =

* Changed class definitions to be compat with php5.

= 1.5 =

* Allowed tags in text: a,b,br,i,span
* Text will be auto paragraphed ( wpautop() ).
* You can have multiple widgets for the same user.

= 1.4 =

* Tested on wp 3.8 

= 1.3 =

* Grannys corner now supports qTranslate.

= 1.2 =

* On some installations the post method does not work, so now we use the get method.

= 1.1 =

* Clear button added.
* Changing the widget settings now rememberes the owner.

= 1.0 = 

* 1.0 Initial release

== Upgrade Notice ==

== Licence ==

Grannys Corner is released under the GNU GPL licence. ( http://www.gnu.org/copyleft/gpl.html )