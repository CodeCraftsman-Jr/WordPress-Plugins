=== Combination Widget For Disqus ===
Plugin URI: http://www.trickspanda.com
Description: Add a Disqus combination widget to your WordPress blog's sidebar.
Version: 1.2
Requires at least: 2.5
Tested up to: 4.1
Contributors: hardeepasrani
Author URI: http://www.hardeepasrani.com
Tags: disqus, comments, widgets, recent comments, popular threads, top commenters
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Add Disqus combination widget to your WordPress with our user-friendly plugin. Just install the plugin to your WordPress and visit Widget settings in Appearance menu to add our widget to your blog.

The widget shows following on in a tabbed widget:

1. Recent Comments
2. Popular Threads
3. Top Commenters

== Installation ==

1. Upload the plugin to your 'wp-content/plugins' directory, or download and install automatically through your admin panel.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= How you created this? =

We used Disqus' original combination script for the widget.

== Screenshots ==

1. Disqus combination Widget On Back-end.

== Changelog ==

= 1.1 =
* Added an option to change widget title.

= 1.2 =
* Added a translation file.