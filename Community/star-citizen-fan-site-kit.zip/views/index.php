<?php
// No directory listing permitted
print 'You are not permitted to view the contents of this directory';
?>