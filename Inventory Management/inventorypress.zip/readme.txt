=== Plugin Name ===
Contributors: Noland626		
Donate link: http://workbold.com/
Tags: inventory, management
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 3.4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily Manage Your Entire Inventory Using a Small Yet Powerful Set of Custom Post Types.

== Description ==

Easily Manage Your Entire Inventory Using a Small Yet Powerful Set of Custom Post Types.

== Installation ==

This section describes how to install the plugin and get it working.


1. Upload the files to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Changelog ==

= 1.7 =
* New Added Features

= 1.0 =
* Initial release

== Upgrade Notice ==

== Screenshots ==

1. Easy "backend" Administration
2. Track data about your products better
3. Define Common Materials
4. Define Common Product Types
5. Define Common Brands
