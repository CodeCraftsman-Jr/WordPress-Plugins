<?php

define('WOO_PRODUCT_STOCK_ALERT_PLUGIN_TOKEN', 'woo-product-stock-alert');

define('WOO_PRODUCT_STOCK_ALERT_TEXT_DOMAIN', 'product_stock_alert');

define('WOO_PRODUCT_STOCK_ALERT_PLUGIN_VERSION', '1.0.0');
?>