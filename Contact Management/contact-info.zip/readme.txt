=== contact info ===
Contributors: avimegladon
Donate link: http://donateafo.net84.net/
Tags: contact, email, phone, address, second mail option, info, address info, contact info, mail
Requires at least: 2.0.2
Tested up to: 3.8.1
Stable tag: 2.1a

This plugin will allow you to add contact information from admin panel and show them in frontend. Using shortcodes and functions.

== Description ==

This plugin automatically allows you to write shortcodes to wordpress text widgets.

<strong>For Phone No :</strong> <strong>&lt;?php echo ci("phone"); ?&gt;</strong> Or Shortcode <strong>[ci show="phone"]</strong><br />
<strong>For Email Address :</strong> <strong>&lt;?php echo ci("email");?&gt;</strong> Or Shortcode <strong>[ci show="email"]</strong><br />
<strong>For Address/Any Text :</strong> <strong>&lt;?php echo ci("address");?&gt; </strong> Or Shortcode <strong>[ci show="address"]</strong></p>

how to use information is also available is plugin admin section.

== Installation ==


1. Upload `contact_info` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

= For any kind of problem =

1. Please email me avi.megladon@gmail.com. My site is http://avifoujdar.wordpress.com/contact/ 
2. Or you can write comments directly to my plugins page. Please visit here http://avifoujdar.wordpress.com/2014/02/13/login-widget/


== Screenshots ==

1. admin panel plugin view


== Changelog ==

= 1.0 =
* this is the first release.

= 0.1 =
* version 0.1

== Upgrade Notice ==

= 1.0 =
this is my frist plugin that I uploaded to wordpress. I will try to update this plugin and more of my plugins to wordpress. 
