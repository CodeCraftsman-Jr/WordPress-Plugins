<?php
/**
 * Email Header
 *
 * @package 	Give/Templates/Emails
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// {email} is replaced by the content entered in Downloads > Settings > Emails

?>
{email}