********************************************************

  Give I18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Give updates.
  
  Keep custom Give translations in /wp-content/languages/give/
  
  You want to translate, help, or improve a translation.
  
  Join our WP-Translations Community at
  https://www.transifex.com/projects/p/give/

  More info at http://wp-translations.org/

********************************************************
