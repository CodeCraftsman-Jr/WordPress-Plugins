(function( $ ) {
	'use strict';

	/**
	 * Dashboard JS
	 */

})( jQuery );
