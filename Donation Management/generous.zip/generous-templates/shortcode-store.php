<?php

/**
 * (Shortcode) Generous Store
 *
 * Outputs categories list and default category.
 *
 * Usage: [generous store]
 *
 * @since      0.1.0
 *
 * @package    WP_Generous
 * @subpackage WP_Generous/generous-templates
 */
?>

[generous categories]
[generous category=featured]