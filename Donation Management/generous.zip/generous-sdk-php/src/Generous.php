<?php

// Generous singleton
require( dirname(__FILE__) . '/Generous/Generous.php' );

// Connections
require( dirname(__FILE__) . '/Generous/ApiRequestor.php' );