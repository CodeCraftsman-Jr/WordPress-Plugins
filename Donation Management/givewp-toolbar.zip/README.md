# GiveWP Toolbar Plugin

A time-saving plugin for non-profits using the GiveWP Plugin by WordImpress. Simply adds some cool menus to the WordPress admin bar. You need to have the [Give WordPress plugin](https://wordpress.org/plugins/give/) installed for the plugin to work. 
