=== Exchange Rates Today ===
Contributors: Silver222
Tags: woocommerce, price, exchange rates
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 2.5.7
License: GPLv2 or later

Change your price acording today exchange rates

== Description ==

A simple plugin for WooCommerce that allows you to change the price according to the exchange rate. For example, you set the price on the website in dollars and in-store price is displayed in local currency, you simply are asking today's exchange rate, but the plugin automatically changes all prices.


== Installation ==

Upload the plugin to your blog and activate it.


== Changelog ==

= 1.0 =
First version :)
= 1.1 =
Fixed some bugs. Now plugin works not only with catalogue and change price at whole shop.