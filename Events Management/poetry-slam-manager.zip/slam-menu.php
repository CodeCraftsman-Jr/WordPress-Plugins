<h4>Slam Manager - Settings</h4>
<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post" accept-charset="utf-8">
	<p><input type="submit" value="Save Settings"></p>
</form>