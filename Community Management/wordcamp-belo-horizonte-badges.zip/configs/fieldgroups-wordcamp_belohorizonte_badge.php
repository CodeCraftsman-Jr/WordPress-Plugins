<?php
/**
*
* fieldgroups for wordcamp-belohorizonte-badges/wordcamp_belohorizonte_badge
*
* @package WordCamp_Belohorizonte_Badges
* @author Myles McNamara myles@smyl.es
* @license GPL-2.0+
* @link http://smyl.es
* @copyright 2015 Myles McNamara
*/


$configfiles = array(
	self::get_path( __FILE__ ) . 'wordcamp_belohorizonte_badge-configuration.php', 
);

