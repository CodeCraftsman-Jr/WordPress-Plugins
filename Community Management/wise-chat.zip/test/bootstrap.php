<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

// source directory:
require_once(dirname(__FILE__).'/../src/WiseChatContainer.php');