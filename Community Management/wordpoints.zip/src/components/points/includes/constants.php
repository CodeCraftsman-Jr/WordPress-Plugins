<?php

/**
 * Points component constants and global variables.
 *
 * @package WordPoints\Points
 * @since 1.7.0
 */

global $wpdb;

$wpdb->wordpoints_points_logs     = "{$wpdb->base_prefix}wordpoints_points_logs";
$wpdb->wordpoints_points_log_meta = "{$wpdb->base_prefix}wordpoints_points_log_meta";

// EOF
