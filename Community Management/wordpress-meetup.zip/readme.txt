=== Plugin Name ===
Contributors: fferraiu
Donate link: 
Tags: wordpress, meetup, user activity
Requires at least: 3.2.1
Tested up to: 3.2.1
Stable tag: 0.5

Allows you to integrate your wordpress blog with the platform capabilities of meetup

== Description ==

This plugin allows you to integrate your wordpress blog with the platform capabilities of meetup. 
This provides a widget that allows you to view a list of recent activities of your group meetup. 

== Installation ==

The quickest method for installing the importer is:

1. Visit Tools -> Import in the WordPress dashboard
1. Click on the WordPress link in the list of importers
1. Click "Install Now"
1. Finally click "Activate Plugin & Run Importer"

If you would prefer to do things manually then follow these instructions:

1. Upload the `wordpress-importer` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Tools -> Import screen, click on WordPress

== Changelog ==

= 0.1 =
* Initial beta release

== Frequently Asked Questions ==