<div id="vc-main" data-access-token="<?php echo get_option('vicomi_comments_api_key'); ?>">
</div>
<script type="text/javascript" src="http://assets.vicomi.com/assets/widgets_static.js"></script>
</body>

