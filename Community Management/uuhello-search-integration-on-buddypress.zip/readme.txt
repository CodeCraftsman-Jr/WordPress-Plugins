=== uuHello Search Integration on BuddyPress ===
Contributors: uuhello.com
Donate link: http://usi.uuhello.com/
Tags: buddypress, search, uuhello, business, travel, live, shopping
Requires at least: 2.8.6
Tested up to: 2.8.6
Stable tag: Beta 0.0.1

uuHello is a Vertical search engine. expert at Travel, Live, Shopping and e-Commerce domain. 
uuHello Search Integration on BuddyPress(http://usi.uuhello.com/) is a Plugin to help you integration Vertical Search function to your community.
 

== Description ==

uuHello is a Vertical search engine. expert at Travel, Live, Shopping and e-Commerce domain. 
uuHello Search Integration on BuddyPress(http://usi.uuhello.com/) is a Plugin to help you integration Vertical Search function to your community. include:
 
1. Business Search
1. Travel Search
1. Live Search
1. Shopping Search


== Installation ==

This Plugin works without you having to make any changes. But we recommend that you customize it as described below, before you begin using it in a live setting.

1. Download the Plugin from this website. 
1. Upload the '`uuhello-search-integration-on-buddypress`' folder to the '`/wp-content/plugins/`' directory
1. Activate the Plugin through the 'Plugins' menu in WordPress


Make sure you change the *VERSION NUMBER* every time you make changes to the Plugin.

== Frequently Asked Questions ==

= How to ask a question? =

Click [here](http://uuhello.com/contact) and ask me a question.

= Why is the FAQ empty? =


== Screenshots ==

There are currently no screenshots.


== Changelog ==

= Beta 0.0.1 =
* First Release, it is in Beta.  Please do not rate this Plugin.


