=== Inventive lotteries and giveaways ===
Contributors: 1nventive
Donate link: http://1nventive.it/
Tags: wordpress lottery, wordpress lotteries, wordpress giveaway, wordpress giveaways, wordpress sweepstake, wordpress sweepstakes, woocommerce lottery, woocommerce lotteries, woocommerce giveaway, woocommerce giveaways, woocommerce sweepstake, woocommerce sweepstakes
Requires at least: 3.8
Tested up to: 4.3
Stable tag: 1.01
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Inventive lotteries and giveaways is the perfect tool to boost your sales and customer fidelity in your online blog, website or shop.

You can create lotteries, givaways, sweepstakes in a very customizable way.

== Description ==

	In this lite version, you can create giveaways for user registered on a certain date, using wordpress pages as prizes.

If you want more features, check the PRO version



**MAIN FEATURES OF THE PRO VERSION**

1. There are 6 ways to organize your lottery, giveaway, sweepstake:

Buy ticket: User buy a ticket and get access to your giveway

Registration to website: New user register to your website and get access to your giveaway

Minimum order: User place an order with a minimum sub total and get access to your giveaway

Poll: User answer to some questions for your market survey and get access to your giveway

Question: User has to answer correctly to a question to participate in the giveaway

Code: User receive a code and use it to partecipate in the giveaway
 
2. It works with wordpress standalone or with woocommerce

3. You can assign as prizes posts, products, discount coupons

4. Templatized to customize your giveaway

5. Codes auto generation with custom length

6. Plan your lottery to be active only on certain dates

7. Very simple and effective to use

8. Widget and shortcode to display your giveaway anywhere you want to

9. You can set conditions, age and country restriction

10. You can generate automatically an order when somebody win a prize

11. Move unassigned prizes to the next lottery

12. You can download a csv with winners list

13. Translation ready

14. Send an email when somebody win

15. Animated draw

16. You can convert user role when he has got access to the lottery (useful if you offer access to discounts or restricted areas based on role)

17. You have two ways for drawing the prizes, a random mode or you can assign for sure a prize for every user. So this plugin isn�t just for lotteries and giveways, but also to give for sure discount coupons or anything you want for each kind of method.

Buy the pro version
http://www.1nventive.it/en/product/inventive-wordpress-woocommerce-lotteries-giveaways-sweepstakes/

== Installation ==

refer to documentation

== Frequently Asked Questions ==

refer to documentation

== Screenshots ==


== Changelog ==

== Upgrade Notice ==

