=== Easy Magazine ===
Contributors: Filtr8
Tags: widget, news, twitter, facebook, content, media, marketing, newsletter, magazine, posts, shortcode
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 4.3
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html

Add to your web site a stunning magazine with amazing news, images and stories, highly relevant to your business

== Description ==

Effortlessly discover, publish and share amazing stories and news to make your visitors stay longer and come back more often. 
Drive traffic to your website, improve your conversion rate, and delight your visitors!

With [Filtr8](https://filtr8.com/join "Welcome to Filtr8") you become a publisher of engaging magazine about the latest news, developments and insights in your business area. 
New relevant stories come to your Filtr8 Newsroom automatically, and you just choose which ones to publish and share to your social networks.

Providing the relevant high-qualiy content to your audience is an excellent way of growing engagement, 
establishing thought leadership and getting new leads for your business.

And your audience will simply love it.

== Screenshots ==

1. Filtr8 Magazine
2. Getting the shortcode from your Filtr8 Newsroom
3. Using the shortcode on your WP page

== Installation ==

1. Sign up for [Filtr8](https://filtr8.com/join "Sign up for Filtr8"), create your Newsroom feed and publish some items
1. Install and activate Filtr8 Magazine plugin on your WordPress Plugins page
1. Grab the shortcut code for your magazine from your Filtr8 Newsroom using the "Magazine setup" button (see screenshots)
1. Add shortcode to your page (see screenshots)
1. See [Filtr8 Quick Guide](http://filtr8.uservoice.com/knowledgebase/articles/605733-filtr8-quick-guide "Filtr8 Quick Guide") for more details on magazine's configuration


== Changelog ==

= 1.0.0 =
* Initial release