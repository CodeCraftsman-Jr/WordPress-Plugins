jQuery(document).ready(function($) {

	jQuery("body").css('background', 'transparent');					
	jQuery('.wp_cta_content').css('margin' , 'none');
	
});