jQuery(document).ready(function() 
{ 
	//jQuery("label[for=edd-gateway-paypal]").hide();
}); 
    