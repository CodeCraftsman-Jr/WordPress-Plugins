=== toodoo ===
Tags: toodoo, snapshot, comments
Requires at least: 2.1
Tested up to: 2.5.1
Stable tag: 2.1.1

Addung toodoo.ru capabilities to your blog.

== Description ==
1. http://toodoo.ru/support/wordpress
2. http://toodoo.ru/support/wordpress2

== Installation ==

1. Upload `toodoo` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
