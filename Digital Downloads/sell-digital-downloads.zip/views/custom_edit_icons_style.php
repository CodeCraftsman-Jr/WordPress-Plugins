<style>

.icon32-posts-isell-product {
	background:transparent url("<?php echo plugins_url( '/images/product-32x32.png', dirname(__FILE__) ) ?>") no-repeat !important;
}

.icon32-posts-isell-order {
	background:transparent url("<?php echo plugins_url( '/images/order-32x32.png', dirname(__FILE__) ) ?>") no-repeat !important;
}

</style>
