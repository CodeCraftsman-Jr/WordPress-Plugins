=== Tom's Guide Download Widget ===
Contributors: Best of Media
Tags: download, télécharger, tom's guide
Requires at least: 2.8
Tested up to: 3.1.3
Stable tag: 1.0.5
License: GPLv2 or later



== Description ==

Tom's Guide Download Widget will display in real time download content from its main websites http://downloads.tomsguide.com/ (English) and http://telecharger.tomsguide.fr/ (French)

== Installation ==

* Upload the Tom's Guide Download Widget plugin to your blog

* Activate it

* Then drag the widget to your chosen widget area (as many times as you want).

* You can then customize it directly on the widgets control page, or by clicking on the Tom's Guide plugin settings.

== Changelog ==

= 1.0.5 =
* Fix version

= 1.0.4 =
* Fix version

= 1.0.3 =
* Update english domain name

= 1.0.2 =
* Update french domain name

= 1.0.1 =
* Some bug fixes for Internet Explorer 6

= 1.0.0 =
* First release of the plugin

== Screenshots ==

1. Display in real time download contents from Tom's Guide.
2. Customize your widget to adapt it to your Wordpress theme.
