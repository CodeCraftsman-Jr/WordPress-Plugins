<?php
/**
 * Delightful Downloads Page Support
 *
 * @package     Delightful Downloads
 * @subpackage  Admin/Page Support
 * @since       1.3
*/

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


