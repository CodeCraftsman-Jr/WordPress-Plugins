<div style="
    padding:10px;
    margin:20px auto;
    background-color:white;
    width:90%;
    height:100px;
    border-radius: 20px;
    border: 1px gray;">
    
    <div style="float:right;">
			    <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
				<input type="hidden" name="cmd" value="_s-xclick">
				<input type="hidden" name="hosted_button_id" value="F2JK36SCXKTE2">
				<input type="image" src="https://www.paypalobjects.com/webstatic/en_US/btn/btn_donate_pp_142x27.png" border="0" name="submit" alt="PayPal - Il metodo rapido, affidabile e innovativo per pagare e farsi pagare.">
			    </form>
			</div>
	
    <div style="float:left;width:25%;">
        <img width="160px" src="<?php echo get_site_url(); ?>/wp-content/plugins/cloud/includes/wpcloud.png" />
    </div>
        <h4>Welcome to WP Cloud, a WordPress plugin for members-based storage that rocks.</h4>
        If you like this plugin you can rate it or donate for its development :)<br/>
        If you don't like this plugin you can send me your opinion and how can i make it better :(
</div>
	
<div style="
    float:right;
    padding:10px;
    background-color:white;
    width:300px;
    height:800px;
    border-radius: 20px;
    border: 1px gray;
    position: relative;
    margin-right: 47px;">
	
    <h3>Who am I?</h3>
    <p>
        <img width="80px" height="80px" style="margin:2px;border-radius:50px;float:left;" src="http://gravatar.com/avatar/c70b8e378aa035f77ab7a3ddee83b892?d=mm&s=150&r=G">

Hi! I'm <b>Marco</b>, 20 years old, live in <a href="http://www.comune.sanpellegrinoterme.bg.it" target="_blank">San Pellegrino Terme</a> and study Computer Engineering at the University of Bergamo.<br/>
I really hope to make you happy and comfortable using this plugin. If you found problems, or have suggestions, don't existate to let me know!
<!-- AddThis Follow BEGIN -->
    <center>
        <div class="addthis_toolbox addthis_32x32_style addthis_default_style">
            <a class="addthis_button_facebook_follow at300b" addthis:userid="milesimarco" href="http://www.facebook.com/milesimarco" target="_blank" title="Follow on Facebook"><span class=" at300bs at15nc at15t_facebook"><span class="at_a11y">Share on facebook</span></span><span class="addthis_follow_label">Facebook</span></a>
            <a class="addthis_button_twitter_follow at300b" addthis:userid="milesimarco" href="//twitter.com/milesimarco" target="_blank" title="Follow on Twitter"><span class=" at300bs at15nc at15t_twitter"><span class="at_a11y">Share on twitter</span></span><span class="addthis_follow_label">Twitter</span></a>
            <a class="addthis_button_linkedin_follow at300b" addthis:userid="milesimarco94" href="http://www.linkedin.com/in/milesimarco94" target="_blank" title="Follow on LinkedIn"><span class=" at300bs at15nc at15t_linkedin"><span class="at_a11y">Share on linkedin</span></span><span class="addthis_follow_label">LinkedIn</span></a>
            <a class="addthis_button_google_follow at300b" addthis:userid="MarcoMilesi" title="Follow on Google" href="https://plus.google.com/MarcoMilesi" target="_blank"><span class=" at300bs at15nc at15t_google_follow"><span class="at_a11y">Share on google_follow</span></span><span class="addthis_follow_label">Google</span></a>
            <a class="addthis_button_youtube_follow at300b" addthis:userid="milesimarco" href="http://www.youtube.com/user/milesimarco?sub_confirmation=1" target="_blank" title="Follow on Youtube"><span class=" at300bs at15nc at15t_youtube"><span class="at_a11y">Share on youtube</span></span><span class="addthis_follow_label">Youtube</span></a>
            <a class="addthis_button_instagram_follow at300b" addthis:userid="milesimarco" href="http://instagram.com/milesimarco" target="_blank" title="Follow on Instagram"><span class=" at300bs at15nc at15t_instagram"><span class="at_a11y">Share on instagram</span></span><span class="addthis_follow_label">Instagram</span></a>
	</center>
	<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-53552ffe3024cab2"></script><div id="_atssh" style="visibility: hidden; height: 1px; width: 1px; position: absolute; z-index: 100000;"><iframe id="_atssh665" title="AddThis utility frame" style="height: 1px; width: 1px; position: absolute; z-index: 100000; border: 0px; left: 0px; top: 0px;" src="//ct1.addthis.com/static/r07/sh164.html#iit=1405178756523&amp;tmr=load%3D1405178756202%26core%3D1405178756317%26main%3D1405178756515%26ifr%3D1405178756529&amp;cb=0&amp;cdn=1&amp;chr=UTF-8&amp;kw=&amp;ab=-&amp;dh=www.comune.sanpellegrinoterme.bg.it&amp;dr=http%3A%2F%2Fwww.comune.sanpellegrinoterme.bg.it%2Fwp-admin%2F&amp;du=http%3A%2F%2Fwww.comune.sanpellegrinoterme.bg.it%2Fwp-admin%2Fadmin.php%3Fpage%3Dimpostazioni-wpgov&amp;dt=Impostazioni%20soluzioni%20WPGOV.IT%20%E2%80%B9%20Comune%20di%20San%20Pellegrino%20Terme&amp;dbg=0&amp;md=0&amp;cap=tc%3D0%26ab%3D0&amp;inst=1&amp;vcl=2&amp;jsl=1&amp;prod=undefined&amp;lng=it&amp;ogt=&amp;pc=men&amp;pub=ra-53552ffe3024cab2&amp;ssl=0&amp;sid=53c15384e9340336&amp;srpl=1&amp;srcs=1&amp;srd=1&amp;srf=1&amp;srx=1&amp;ver=300&amp;xck=0&amp;xtr=0&amp;og=&amp;aa=0&amp;csi=undefined&amp;rev=1404214985&amp;ct=1&amp;xld=1&amp;xd=1"></iframe></div><script type="text/javascript" src="http://ct1.addthis.com/static/r07/core142.js"></script>
	<!-- AddThis Follow END -->
        <hr>
            <p>
                <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FWPGOv&amp;width=290&amp;height=258&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false&amp;appId=262031607290004" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:290px; height:258px;" allowtransparency="true"></iframe>
            </p>
            <p>
                <img src="http://www.comune.sanpellegrinoterme.bg.it/wp-content/plugins/amministrazione-trasparente/govconfig/panels/includes/mmsignature.png">
            </p>
    </p>
</div>