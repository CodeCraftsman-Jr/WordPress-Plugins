=== Change Category Checkbox to Radio Button ===
Contributors: hmbashar
Donate link: http://fb.linuxhostlab.com
Tags: Change WP Taxonomy Type, Change Category type, Category type change, Change checkbox to Radio Button.
Requires at least: 3.0.1
Tested up to: 4.2.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
If you want select one category in your wordpress when user post, then required change category/taxonomy type in your post option. so if you don't know how to it. then use this plugin. if you use this plugin then automatic change category/taxonomy type checkbox to Radio button.

== Installation ==

This section describes how to install the plugin and get it working.

example: 

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How to install this plugin? =

Just follow this information
1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

= How to use this plugin? =

Just install this plguin. and check your category/taxonomy type in your post option. or see this screenshot http://prntscr.com/7yd7rs

== Screenshots ==

1. Output
