<?php
	include('./wp-config.php');
	require (ABSPATH .'wp-content/plugins/feedback' . '/rss2.php');
	
?>