=== Here Without You ===
Contributors: 
Donate link: 
Tags: 3DD, Hello Dolly, Here Without You,
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 3DD, Hello Dolly, Here Without You,
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here Without You. When enabled, you see random phrase from the song Here Without. 

== Description ==

Here Without You. When enabled, you see random phrase from the song Here Without You song of the band 3 Doors Down at the upper right of your admin screen on every page. based on Hello Dolly 

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==



== Screenshots ==



== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==