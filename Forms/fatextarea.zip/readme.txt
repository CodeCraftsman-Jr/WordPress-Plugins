﻿=== Plugin Name ===
Donate link: http://www.yonadi.com
Tags: fatextarea , ltr, rtl, admin, wordpress3.2
Tested up to: 3.2
Requires at least: 2.0.2
Stable tag: trunk

change textarea from rtl to ltr .
== Description ==

change textarea from rtl to ltr .

by http://yonadi.com and http://supportweb.ir

== Installation ==


1. Upload the zipped file to yoursite/wp-content/plugins
2. Activate the plugin through the 'Plugins' menu in WordPress
3. visit my site and comment here http://yonadi.com and http://supportweb.ir
4 . enjoy .

== Screenshots ==

1. before install

2. after install
