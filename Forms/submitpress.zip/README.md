# SubmitPress
Manage Your User-Contributed Online Magazine with Wordpress
