
<div class="error">
	<p>Gravity Forms DPS PxPay requires <a target="_blank" href="http://webaware.com.au/get-gravity-forms">Gravity Forms</a> to be installed and activated.</p>
</div>
