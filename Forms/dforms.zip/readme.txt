=== dForms ===
Contributors: animexxx
Donate link: http://example.com/
Tags: forms, form
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create web forms and manage submission. Drag-and-drop the form elements to create your professional looking form. 

== Description ==

Create web forms and manage submission. Drag-and-drop the form elements to create your professional looking form. 

== Installation ==

1. Upload plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

= What is dForms ? =

dForms is extension for creating online forms for your WordPress site. 

== Screenshots ==

1. Creating form
2. Form view
3. Submissions

== Changelog ==

= 1.0 =
* New plugin

== Upgrade Notice ==

= 1.0 =
No notice


== Arbitrary section ==


== A brief Markdown Example ==

