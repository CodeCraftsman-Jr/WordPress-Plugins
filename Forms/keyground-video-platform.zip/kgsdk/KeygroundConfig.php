<?php
define('API_URL','http://api.keyground.net/0.3.3/api.php');
//define('API_KEY','4f6b5b32c1c4771df3af44c346f524a5babdca4e');
define('API_KEY','234234234');
?>