<div class="wrap">
<h1>Are you sure you want to reset?</h1> 
It will erase your posts and install from Keyground.
</div>

<form name="reset-form" method="post" action="?page=keyground&action=reset">
<p class="submit"><input type="submit" name="reset-sure" id="submit" class="button-primary" value="Yes,Reset!"  />
<input type="submit" name="reset-no" id="submit" class="button-primary" value="No."  /></p>
</form> 