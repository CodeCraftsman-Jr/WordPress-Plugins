<div class="kg-video-container">
<div class="container-title">New Added Videos</div>
<? foreach($videos as $video):?>
<? include('video_box.tpl.php')?>
<? endforeach;?>
</div>