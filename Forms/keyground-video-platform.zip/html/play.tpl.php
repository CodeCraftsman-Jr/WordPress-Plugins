<div class="kg_play">
	<div class="video_player">
		<?php echo $video->embed_code; ?>
	</div>
	<div class="video_info">
		<?php echo $video->description; ?>
	</div>
</div>
