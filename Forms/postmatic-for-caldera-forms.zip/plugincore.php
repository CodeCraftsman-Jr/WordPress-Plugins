<?php
/**
* @package   Caldera_Forms_Postmatic
* @author    Josh Pollock <Josh@CalderaWP.com>
* @license   GPL-2.0+
* @link      
* @copyright 2015 Josh Pollock for CalderaWP
*
* @wordpress-plugin
* Plugin Name: Postmatic For Caldera Forms
* Plugin URI:  https://calderawp.com/downloads/postmatic-for-caldera-forms/
* Description: Postmatic integration for Caldera Forms
* Version:     1.0.0
* Author:      Josh Pollock <Josh@CalderaWP.com>
* Author URI:  http://calderawp.com
* Text Domain: cf-postmatic
* License:     GPL-2.0+
* License URI: http://www.gnu.org/licenses/gpl-2.0.txt
* Domain Path: /languages
*/
