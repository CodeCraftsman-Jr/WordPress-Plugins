=== Postmatic For Caldera Forms ===
Contributors: Shelob9
Donate link: http://example.com/
Tags: comments, spam
Requires at least: 4.0
Tested up to: 4.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Postmatic integration for Caldera Forms.

== Description ==
Add [Postmatic](https://gopostmatic.com/) site subscriptions to your WordPress forms, using [Caldera Forms](https://calderawp.com/downloads/caldera-forms/).

* Learn more at [https://calderawp.com/downloads/postmatic-for-caldera-forms/](https://calderawp.com/downloads/postmatic-for-caldera-forms/)
* Submit issues or pull requests at [https://github.com/CalderaWP/cf-postmatic](https://github.com/CalderaWP/cf-postmatic)


== Installation ==

* Install Postmatic.
* Install this plugin.
* Add the proccesor to your Caldera Form.

== Frequently Asked Questions ==
= Does It Go To Eleven? =
Maybe...

== Screenshots ==
1. Example form

== Changelog ==

== 1.0.0 ==
First release. WOO!
