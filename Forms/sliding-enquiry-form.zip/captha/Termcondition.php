<html>
	<head>
    	<title>
        </title>
        
        <link rel="stylesheet" type="text/css" href="../newform/style.css"/>
    </head>
    <body>
    	<div id="wrap"> <!--wrap start-->
    	<div id="wrap2">  <!--wrap2 start-->
       
       	<h2 class="free_account">Detail of Term & Condition</h2> 
         
          <form action="" method="post">
			<h3>I. Defined Terms:</h3>
Unless otherwise specified, the capitilised words shall have the meanings as defined herein below:

    "Agreement" Shall mean and include the completed application form, its attachment(s) and the terms and conditions stated herein. It shall deemed to have been executed at New Delhi.
<br />

    <h3>"Company": </h3>Is defined as Bennett, Coleman & Company Limited an existing Company under the Companies Act, 1956 and having its registered office at Dr. Dadabhai Naoroji Marg, Mumbai, along with its unit for the Company's website Timesjobs.com.
   <br />

   <h3> "Date of Commencement: </h3> Is the dat e indicating the acceptance of the application by the user to the service. It shall be specified by the company in it s notice to the user either through e-mail or conventional mail.

<br />
    <h3>"Date of Termination":</h3> Is the date of expiry mentioned in the notice or/and the letter of termination.

<br />
    <h3>"Product Catalogue":</h3> Contains time to tim e information and description of the Services for the User provided by the Company in writing or contained in the website Timesjobs.com.
<br />

    <h3>"Registration Data":</h3> Is the database of all the particulars and information supplied by the User on initial application and subscription, including but without limiting to the User' s name, telephone number, mailing address, account and email address.

<br />

    Words referring to masculin e include the feminine and the singular include the plural and vice versa as the context admits or requires; and Words importing persons includes individuals, bodies corporate and unincorporated.

<br />
    <h3>"Services":</h3> Means the Services to be provided by the Company to the User of Timesjobs.com and shall include the provision of following facilities:


    Service to the User wishing to post resume or curriculum vitae for the purpose of seeking employment.


    Service to the User who wishes to secure recruitment through Timesjobs.com and its Internet links.


    Service to the user who wishes to place a print advertisement in any of the group publications through the www.timesjobs.com site


    Service to the User who wishes to insert advertisements at Timesjobs.com.


    Service to the User who wishes to receive advertisements and promotional messages on www.timesjobs.com and through emails.


    "Timesjobs.com": Is defined as the Internet web site of the Company at www.timesjobs.com.


    "User": Is defined as an individual or corporate subscriber for the Services and the signatory, whose particulars are contained in the application form and includes his successors and permitted assignees.



<h3>II. Commencement of Service</h3>

    The Service shall be deemed to have commenced on the Date of Commencement.


    Hiring / employing through Timesjobs.com is available only to individuals/organisations who can form legally binding contracts under applicable law.



III.Subscription Fees

    The applicable rate of the Subscription Fees for the Service provided shall be such as mentioned in the Product Catalogue or as may be prescribed by the Company from time to time.


    Liability for the Subscription Fees shall accrue from the Date of Commencement.


    All individual Users who access or make postings of information at Timesjobs.com for the purpose of seeking employment shall be exempted from the application of this clause.



		
       </form>
        </div> 
    </div> 
    </body>
</html>
