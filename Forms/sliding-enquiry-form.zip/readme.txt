=== Sliding Enquiry Form ===
Contributors: Jaimin Suthar
Donate link: http://jaimindeveloper.ml/
Tags: Sliding Enquiry Form, icon,css3,jquery,css3 effects,feedback
Requires at least: 3.6
Tested up to: 4.2.2
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Sliding Enquiry Form is a simple and easy wordpress plugin used to add popup on fixed position like bottom, left or right side with CSS3 effects.

== Description ==

Sliding Enquiry Form is a simple, easy and fully-customizable wordpress plugin used to add popup on fixed position like footer left, footer right, left side or right side with CSS3 effects.

You can display any content like contact form, feedback form, advertising, content, social buttons. Add your content with shortocdes in visual text editor in same way as you edit your wordpress post/page.

Engage your users with this Sliding Enquiry Form plugin.

== Installation ==

**Installation Instruction & Configuration**  	

1. You can use the built-in installer. OR
Download the zip file and extract the contents. Upload the 'Sliding Enquiry Form' folder to your plugins directory (wp-content/plugins/).

2.Activate the plugin through the 'Plugins' menu in WordPress. 	

3.Go to Settings -> Sliding Enquiry Form and set Form Name,Email-Id,title,color and icon.

== Screenshots ==

1. Admin settings screenshot
2. Sliding Enquiry Form closed
3. Sliding Enquiry Form open
3. Sliding Enquiry Form validation with mail functionality


== Frequently Asked Questions ==

= if you have any problem for Configuration This plugin? =

1.Download the zip file and extract the contents. Upload the 'Sliding Enquiry Form' folder to your plugins directory (wp-content/plugins/).

2.Activate the plugin through the 'Plugins' menu in WordPress. 	

3.Go to Settings -> Sliding Enquiry Form and set Form Name,Email-Id,title,color and icon.


== Changelog ==


= 1.0 =
* Initial Relaese

== Upgrade Notice ==

= 1.2 =
* Added feature to best Security in enquiry form.

= 1.1 =
* Added options for all field added by admin panel