=== EasyReply ( DISCONTINUED ) ===
Contributors: dcoda
Donate link: http://easyreply.dcoda.co.uk/donate/
Stable tag: DISCONTINUED
Tags: php5.2
Requires at least: 3.0.0
Tested up to: 3.2.1
Discontinued as similar functionality is now part of WordPress
== Description ==
<!--description-->

<!--description-->

