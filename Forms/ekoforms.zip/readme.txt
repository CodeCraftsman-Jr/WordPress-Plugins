=== Ekoforms ===
Contributors: gagnongraphisme
Donate link: none yet
Tags: easy, forms, axial, axialdev, ekoforms, payment, e-commerce, paypal
Requires at least: 3.0
Tested up to: 3.1.1
Stable tag: 1.0

Embed your Ekoforms using shortcodes in no time. Easy e-commerce. Visit www.ekoforms.com.

== Description ==

Embed your Ekoforms using shortcodes in no time. Easy e-commerce. Visit www.ekoforms.com.

== Installation ==

1. Extract and upload the `axial-ekoforms` folder to your `/wp-content/plugins/` directory;
2. Activate the plugin through the 'Plugins' menu in WordPress;
3. Click on `axial ekoforms` in your menu for documentation on the shortcode.
4. Use the shortcode anywhere.

== Changelog ==

= 1.0 =
* First stable version