=== Plugin Name ===
Contributors: dastanbiz
Donate link: http://dastan.biz/
Tags: corner band, ribbon
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 1.0

This Wordress plugin in the top right corner of your site to appear in the date you wish to place on the corner band does. 

== Description ==

This Wordress plugin in the top right corner of your site to appear in the date you wish to place on the corner band does. This is english versiyon. But the screenshots is Turkish version. If you want to use Turkish version please download it from http://dastan.biz/gune-ozel-kose-bandi

== Installation ==

1. Upload `ddcb.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings and Daily Different Corner Band menu and add your corner bands about special days

== Frequently Asked Questions ==

Just install and activate this plugin

== Screenshots ==

1. Settings
2. Example

== Changelog ==

= 1.0 =
First version