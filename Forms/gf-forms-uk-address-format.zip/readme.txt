﻿=== GF Forms - UK address format ===
Contributors: pigeonhut,rajiv-jyasha 
Donate link:
Tags: Gravity Forms, UK Address format, Gravity forms UK
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 1.0.1

Add Support for UK address and postcode to Gravity forms

== License ==
GF Forms- UK address format is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

GF Forms- UK address format  is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with GF Forms- UK address format. If not, see <http://www.gnu.org/licenses/>.

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Add Support for UK address and postcode to Gravity forms, allowing for one click selection of "UK" as an option in countries within Gravity forms.

Plugin comes pre-populated with all UK counties

 

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

 
== Frequently Asked Questions ==

none

== Changelog ==
ver 1.0 release 1 of the plugin.

==Readme Generator== 

This Readme file was generated using <a href = 'http://sudarmuthu.com/wordpress/wp-readme'>wp-readme</a>, which generates readme files for WordPress Plugins.