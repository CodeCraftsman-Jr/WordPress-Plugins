<?php 
/**
* input object
*/
class FormInputField extends InputField
{
  protected $prefix_attr = 'form_';
}