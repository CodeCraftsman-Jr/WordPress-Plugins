<?php 
/**
* input object
*/
class SettingInputField extends InputField
{
  protected $prefix_attr = 'setting_';
}