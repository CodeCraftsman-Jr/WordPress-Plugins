=== Bank Transfer Confirmation Form ===
Contributors: -
Donate link: -
Tags: confirm payment, payment, e-commerce, woo commerce
Requires at least: 3.9
Tested up to: 4.1
Stable tag: 0.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Building confirmation payment form for e-commerce website that has direct bank payment.

== Description ==

Building confirmation payment form for e-commerce website that has direct bank payment.

This plugin provide

* confirmation payment form
* auto send email
* custom label which you want

How to use..

1. custom settings at settings->bank transfer
2. add shortcode [bank_confirmation_form] at somewhere that you want (post, page)

== Installation ==

1. Download the plugin zip file.
2. Extract floder from the zip file and upload to your /wp-content/plugins directory.
3. From your Plugin Management page, activate the plugin.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.0.2 =

* you can set display label for theme

= 0.0.1 =

* page can set customize template
* setting email for send email

