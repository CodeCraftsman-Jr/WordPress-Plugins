# wordpress-confirmation-payment-form
Building confirmation payment form for e-commerce website that has direct bank payment
