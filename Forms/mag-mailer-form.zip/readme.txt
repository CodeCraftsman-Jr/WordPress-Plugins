=== Mag mailer form ===
Contributors: Magissim
Donate link: http://www.magissim.com/
Tags: forms, contact form, email
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Mag mailer form allows you to create contact forms quickly and easily.

== Description ==

Mag mailer form is a plugin designed to create contact forms quickly and easily, either using a shortcode or your own html.

== Installation ==

1. Upload `mag-mailer-form` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Place [mag_mailer_form id='my_form_id'] or use your own html form with a specific id (ex. mag-mailer-my_form_id) in your templates.

== Frequently Asked Questions ==
=  =

== Screenshots ==

1. Shortcode and default fields.
2. Very simple email settings.
3. Settings using your own HTML form.

== Changelog ==

= 1.0 =
1. Release

== Upgrade Notice ==
= =

== A brief Markdown Example ==

Ordered list:

1. Features in the next release : Captcha, saveIntoDb option