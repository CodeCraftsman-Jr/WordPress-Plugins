=== Volunteer Form ===
Contributors: nik
Tags: form, volunteer
Requires at least: 3.5.0
Tested up to: 4.0.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Provides a smart tag that allows site administrators to provide a form for submissions from volunteers.

== Description ==

Generates a volunteer form with submissions available in a new admin section.

== Installation ==

1. Upload the `volunteerform` directory to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. Place `[volunteer_form]`  shortcode in any page on the site.

== Changelog ==

= 0.1 =
Initial version
