=== Google Places  ===
Contributors: innovativeweb 
Tags: Google places , local seo , Google Places rankings , google places business , google places optimization,google places for business,google places seo,google places ranking
Requires at least: 2.8 or higher
Tested up to: 3.2
Stable tag: trunk

Google Places plugin is designed specifically for Business owners to help optimize their business listing, local Google seo , Places and earth.

== Description ==

\"**Google Places**\" also known as \"**Google Maps**\" is a great way to find local business near your city. If you need more visibility in local search results,Maps and earth this plugin is a must.  

Google Places plugin is designed specifically for Business owners to help optimize their business listing on Google Search , Places and earth. Google Places plugin is designed to help your business increase in visibility on google Local searches , maps and Google Earth.
Things to use while optimizing Google Places for Local Seo and Local Google maps

(1) Use the same business name , Address , Phone as used in google Places listing.

(2) Add the same details in your contact us Page.

(3) Include link to local.kml file in Home Page - Makes it Easy for google To crawl your KML file

If you have any questions or queries about local seo feel free to mail me at ritesh@innovativewebdesign.in

For more info on google places plugin -

http://www.innovativewebdesign.in/wp-google-places-plugin/

<a href=\"http://www.innovativewebdesign.in\">Innovative</a><a href=\"http://www.innovativewebdesign.in\">website design</a>


== Installation ==

(1)Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

(2) <span style=\"color: #444444; font-family: sans-serif; font-size: 13px; line-height: 22px;\">Go to Settings->Google Places plugin settings</span>

(3) Fill in all the information on the form.

Thats It! You are done.

Check Domain.com/filename.kml

Check domain.com/georss.xml

 
== Frequently Asked Questions ==

What to do with XML and KML file ?

Add the georss.xml file in your sitemap.

In your Google , Yahoo , Bing Webmaster account add georss.xml file along with your general Sitemap.

 


 
== Changelog ==
<span style=\"color: #444444; font-family: sans-serif; font-size: 13px; line-height: 22px;\">First version, beta testing for Google Places.</span>
 


