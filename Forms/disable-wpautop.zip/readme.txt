=== Disable WPautop ===
Contributors: nickmomrik
Tags: wpautop, disable
Stable tag: trunk

Disables the wpautop function for the_content and the_excerpt

== Installation ==
1. Upload `disable-wpautop.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress}
