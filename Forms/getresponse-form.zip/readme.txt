=== GetResponse Form ===
Contributors: jeffbullins
Donate link: http://www.thinklandingpages.com
Tags:   contact form, contact form 7, form, getresponse, mailinglist, multisite, newsletter, optin, registration form, shortcode, sign-up form, subscribe, opt-in, mailing list, email form, email marketing, forms, subscribe form, subscription, email, marketing, signup, GetResponse form, GetResponse plugin, getresponse signup form, getresponse signup widget, getresponse widget, getresponse wordpress
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An easy way to place a GetResponse form on your Wordpress site.

== Description ==

An easy way to place a GetResponse form on your Wordpress site.

###What you get when you use the GetResponse Form Creator plugin

*  Place a GetResponse form with a simple shortcode [getresponse_form id="%postId%"]
*  Put GetResponse form on any post or page.
*  GetResponse form headline
*  GetResponse form background color
*  GetResponse form message
*  GetResponse form button
*  Unlimited GetResponse forms

###Add GetResponse forms to any post or page

Whether you are writing a post about your company or another company, you can include a well formatted GetResponse form.

###Quick Start Guide

* [GetResponse form quick start guide at thinklandingpages.com] (http://www.thinklandingpages.com/getresponse-form/)

###Unlimited GetResponse forms

Add as many GetResponse forms to your site as you like.  The GetResponse Form Creator plugin lets you create GetResponse forms and save them for when ever you are ready to use them.



== Installation ==


1. Upload `getresponse-form-creator` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Click **GetResponse Form Creator** on the admin menu to enable and set your options.


== Frequently Asked Questions ==

= Do I have to know how to program or design? =

No.  The plugin does the programming and design.

= Is there a limit to the number of GetResponse forms I can create? =
You can create an unlimited number of GetResponse forms.

= Can the GetResponse forms be put on my homepage? =
Yes, you can put GetResponse forms on your homepage by using the GetResponse Form Creator plugin shortcode on you homepage.

= Can I put GetResponse forms on any post or page? =
Yes, use the GetResponse forms shortcode, [getresponse_form id="%postId%"] on your pages and posts.

= What information do I need to hook the form up to my GetResponse account? =
You need the GetResponse campaign token.


== Screenshots ==

[See screenshots at thinklandingpages.com] (http://www.thinklandingpages.com/getresponse-form/)


== Changelog ==

= 1.0 =
* First Release


