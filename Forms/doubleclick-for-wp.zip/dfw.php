<?php
/*
Plugin Name: 	DoubleClick for WordPress
Description: 	A simple way to serve DoubleClick ads in WordPress.
Version: 		0.1
Author: 		Will Haynes for INN
Author URI: 	http://github.com/inn
*/

include('dfw-init.php');