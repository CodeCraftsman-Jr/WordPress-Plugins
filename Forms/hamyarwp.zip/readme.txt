 === HamyarWP ===
Contributors: nipoto
Donate link: http://ideyeno.ir
Tags: hamyar, hamyar wordpress, wordpress, همیار, وردپرس, همیار وردپرس, فارسی, پارسی
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0.5
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

افزونه‌ی همیار وردپرس برای وردپرس فارسی ...

== Description ==

= همیار وردپرس =

افزونه‌ی همیار وردپرس برای وردپرس فارسی ...

http://hamyarwp.com

== Installation ==

1. به برگه 'افزونه‌ها' در مدیریت وردپرس رجوع کرده و بر روی 'افزودن' کلیک کنید
2. 'HamyarWP' را جستجو کنید
3. افزونه ذکر شده را نصب کرده و توضیحات صفحه‌ی مدیریت آن را مطالعه کنید

== Changelog ==

= 1.0 =
* نمایش آخرین اخبار همیار وردپرس در بخش مدیریت
* امکان تعیین تعداد نمایش اخبار : 3، 5، 7 یا 10
* و ...

== Screenshots ==

1. نمایش آخرین اخبار در پنل مدیریت