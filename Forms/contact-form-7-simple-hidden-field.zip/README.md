Contact Form 7 - Simple Hidden Field
====================================

Add simple & dynamic hidden fields in Contact Form 7

See readme.txt