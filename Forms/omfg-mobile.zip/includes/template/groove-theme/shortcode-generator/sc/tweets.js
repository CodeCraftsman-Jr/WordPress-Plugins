scnShortcodeMeta = {
    attributes: [{
		label:"Username",
		id:"name",
		help:"Enter the Twitter username to display the tweets.",
		defaultValue: 'visioniz',
	}, {
		label:"Count",
		id:"count",
		help:"How many Tweets would you like to display?",
		defaultValue: '10',
	}],
    shortcode: "groove_tweets"
};