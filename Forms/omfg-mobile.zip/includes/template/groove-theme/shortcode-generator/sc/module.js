scnShortcodeMeta = {
    attributes: [{
		label:"CSS Class",
		id:"title",
		help:"Optional CSS class."
	}],
    shortcode: "groove_module"
};