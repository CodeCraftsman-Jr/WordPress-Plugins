scnShortcodeMeta = {
    attributes: [{
		label:"Title",
		id:"title",
		help:"Enter the title for the Contact Form."
	}, {
		label:"Intro",
		id:"intro",
		help:"Enter some intro text to display above the contact form."
	}, {
		label:"Email",
		id:"email",
		help:"Enter the email address the contact from should get sent to."
	}],
    shortcode: "groove_contact_form"
};