jQuery(document).ready(function($) {
	
	/* Sidebar Control */
	$(".controls a").click(function() {
		$("#content").toggleClass("open");
		$("#content").delay(300).toggleClass("fixed");
		$(".controls").toggleClass("active");
	}); 
	
	/* Scrolling Areas 
	if (!!('ontouchstart' in window)) {
		$('.content-scroll').touchScroll();
		$('.sidebar-scroll').touchScroll();
	}
	*/
	
});