// SHORTCODE JQUERY
// ======================================= -->

jQuery(document).ready(function($){


});