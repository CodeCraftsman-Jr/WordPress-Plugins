<?php include 'header.php'; ?>
						
			<!-- Main Content Area -->
			<section id="main">
			
				<?php omfg_mobile_pro_page_content(); ?>
				
			</section>
		
<?php include 'footer.php'; ?>