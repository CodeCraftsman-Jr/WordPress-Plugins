			
			<!-- Copyright Information -->
			<footer>
				<?php echo $footer_text; ?>
			</footer>
	
		</div>
	</section>
	<!-- Main Content End -->

</div>

<?php omfg_mobile_pro_footer(); ?>

</body>
</html>