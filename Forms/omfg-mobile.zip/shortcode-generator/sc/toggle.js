scnShortcodeMeta = {
    attributes: [{
        label: "Title",
        id: "title",
        help: "Toggle Title.",
    }, {
        label: "Toggle Content",
        id: "content",
        help: "The content to display in the toggle. HTML is allowed.",
    }],
    defaultContent: "This is some content in a toggle. You can put HTML and even another short code in here if you like!",
    shortcode: "omfg_toggle"
};