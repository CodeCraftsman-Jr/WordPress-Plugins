<?php

/*
Break
============================*/
function vz_break( $atts, $content = null ) {
	return '<div class="clear"></div>';
}
add_shortcode('omfg_clear', 'vz_break');



/*
Line Break
============================*/
function vz_linebreak( $atts, $content = null ) {
	return '<hr /><div class="clear"></div>';
}
add_shortcode('omfg_clearline', 'vz_linebreak');