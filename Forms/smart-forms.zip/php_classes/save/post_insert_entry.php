<?php
class PostInsertEntry extends InsertEntryBase{

    public function __construct(&$formId,&$formEntryData,&$formOptions,&$elementOptions,&$additionalData)
    {
        parent::__construct($formId,$formEntryData,$formOptions,$elementOptions,$additionalData);
    }






}