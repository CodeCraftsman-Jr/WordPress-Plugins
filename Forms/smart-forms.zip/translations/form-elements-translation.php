<?php
$translationArray=array(
	"DefaultCountry"=>__("Default Country")
);

wp_localize_script('smart-forms-form-elements','SmartFormsElementsTranslation',$translationArray);