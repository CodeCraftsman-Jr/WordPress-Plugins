<?php
/**
 * Created by JetBrains PhpStorm.
 * User: edseventeen
 * Date: 4/1/13
 * Time: 8:44 PM
 * To change this template use File | Settings | File Templates.
 */

    wp_enqueue_script("jquery");
?>

<p style="font-size:25px; font-weight: bold;color: red;">If you have an idea, or need support, let me know!!</p>

<br/>

<p style="font-size: 20px; font-weight: bold;">You can reach me in:</p>

<h1 style="margin-bottom:30px; margin-left: 50px;"><a href="https://twitter.com/ed_roj" target="_blank"  style="padding: 0;margin:0 0 10px 0;font-family: verdana;">Twitter</a></h1>

<h1 style="margin-left: 50px;"><a href="https://www.facebook.com/pages/Smart-Forms/1453714741522601" target="_blank" style="font-family: verdana;"> Facebook </a></h1>


<div id="fb-root"></div>
<!-- UserVoice JavaScript SDK (only needed once on a page) -->
<!-- UserVoice JavaScript SDK (only needed once on a page) -->
<script>(function(){var uv=document.createElement('script');uv.type='text/javascript';uv.async=true;uv.src='//widget.uservoice.com/KEbPBYQH5NSMeg9FlVf8yQ.js';var s=document.getElementsByTagName('script')[0];s.parentNode.insertBefore(uv,s)})()</script>

<!-- The Classic Widget will be embeded wherever this div is placed -->
<!--<div data-uv-inline="classic_widget" data-uv-mode="full" data-uv-primary-color="#cc6d00" data-uv-link-color="#007dbf" data-uv-default-mode="support" data-uv-forum-id="238969" data-uv-width="100%" data-uv-height="550px"></div>
<!-- The Classic Widget will be embeded wherever this div is placed -->
<div style="display: block; padding: 10px;" data-uv-inline="classic_widget" data-uv-mode="full" data-uv-primary-color="#cc6d00" data-uv-link-color="#007dbf" data-uv-default-mode="support" data-uv-forum-id="210516" data-uv-width="100%" data-uv-height="550px"></div>

<br/>
<div class="fb-comments" data-href="https://www.facebook.com/SmartDonations" data-width="700" data-num-posts="10"></div>