<?php

require_once SMART_FORMS_DIR. 'smart-forms-bootstrap.php';
wp_enqueue_style("smart-forms-add-ons",SMART_FORMS_DIR_URL.'css/screens/add_ons.css');

wp_enqueue_script('isolated-slider',SMART_FORMS_DIR_URL.'js/rednao-isolated-jq.js');
wp_enqueue_script("smart-forms-add-ons",SMART_FORMS_DIR_URL.'js/main_screens/smart-forms-add-ons.js',array('isolated-slider'));


?>
<div class="bootstrap-wrapper addOnsContainer" style="margin:10px;">

	<div class="progress progress-striped active">
		<div class="progress-bar"  role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
			Loading Descriptions
		</div>
	</div>

	<!--
	<div class=" col-sm-3 sfPanel">
		<div class="panel panel-default">
			<div class="panel-heading">Panel heading without title</div>
			<div class="panel-body">
				Panel content
			</div>
			<div class="panel-footer"><span class="sfLearnMore">&nbsp;</span></div>
			<input type="hidden" class="sfUrl" value="http://www.google.com.mx"/>
		</div>
	</div>

	<div class=" col-sm-3 sfPanel">
		<div class="panel panel-default">
			<div class="panel-heading">Panel heading without title</div>
			<div class="panel-body">
				Panel content
			</div>
			<div class="panel-footer"><span class="sfLearnMore">&nbsp;</span></div>
			<input type="hidden" class="sfUrl" value="http://www.google.com.mx"/>
		</div>
	</div>

	<div class=" col-sm-3 sfPanel">
		<div class="panel panel-default">
			<div class="panel-heading">Panel heading without title</div>
			<div class="panel-body">
				Panel content
			</div>
			<div class="panel-footer"><span class="sfLearnMore">&nbsp;</span></div>
		</div>
	</div>

	<div class=" col-sm-3 sfPanel">
		<div class="panel panel-default">
			<div class="panel-heading">Panel heading without title</div>
			<div class="panel-body">
				Panel content
			</div>
			<div class="panel-footer"><span class="sfLearnMore">&nbsp;</span></div>
		</div>
	</div>

	<div class=" col-sm-3 sfPanel">
		<div class="panel panel-default">
			<div class="panel-heading">Panel heading without title</div>
			<div class="panel-body">
				Panel content
			</div>
			<div class="panel-footer"><span class="sfLearnMore">&nbsp;</span></div>
		</div>
	</div>

	<div class=" col-sm-3 sfPanel">
		<div class="panel panel-default">
			<div class="panel-heading">Panel heading without title</div>
			<div class="panel-body">
				Panel content
			</div>
			<div class="panel-footer"><span class="sfLearnMore">&nbsp;</span></div>
		</div>
	</div>
</div>