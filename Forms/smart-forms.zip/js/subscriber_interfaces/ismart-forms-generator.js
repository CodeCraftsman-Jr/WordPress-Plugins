function ISmartFormsGeneratorBase(options)
{
    this.Generator=options.Generator;

}

ISmartFormsGeneratorBase.prototype.BeforeInitializingFieldData=function()
{

};

ISmartFormsGeneratorBase.prototype.FormSubmissionCompleted=function()
{

};