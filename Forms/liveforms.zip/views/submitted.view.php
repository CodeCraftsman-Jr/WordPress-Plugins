<?php /* <!DOCTYPE html>
<html>
<head>
    <title>Live Form - Drag & Drop Form Builder</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">

    <!-- Optional theme -->
    <!-- link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap-theme.min.css" -->
    <link rel="stylesheet" href="flat-ui/css/flat-ui.css">
    <link rel="stylesheet" href="css/style.css">


    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js"></script>
    <script src="js/mustache.js"></script>
    <script src="flat-ui/js/bootstrap-select.js"></script>
    <script src="js/jquery.form.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Voltaire|Glass+Antiqua|Open+Sans:400,700' rel='stylesheet' type='text/css'>

    <link href='css/animate.min.css' rel='stylesheet' type='text/css'>
    <script>
        $(function(){
            $("select").selectpicker({style: 'btn btn-info', menuStyle: 'dropdown-inverse'});
            $('.ttipf').tooltip({placement:'left'});
        });
    </script>
</head>
<body style="background: #ffffff;padding: 50px;text-align: center">
<table style="height: 100%"><tr><td style="height: 100%" valign="middle"><p>
                <?php */ echo $thankyoumsg; /* ?>

            </p></td></tr></table>

</body>
</html>
<?php */ die(); ?>