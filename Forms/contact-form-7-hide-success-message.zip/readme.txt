=== Contact Form - 7 : Hide Success Message ===
Contributors: rohilmistry
Donate link: https://www.paypal.com
Tags: Contact Form 7, contact, form, cf7, contact-form7, contact-form 7, contact-form-7, hide, success, message, contact form-7 hide success message, hide success message, msg, alert, alert message, contact form-7 alert message, addon, add-on
Requires at least: 3.8
Tested up to: 4.3
Stable tag: 1.1.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

An add-on for Contact Form 7 that will let you to hide only Success Message after defined time.

== Description ==

Contact Form 7 : Hide Success Message will allow you to simply hide the message with Effect after some delay time.

**Now you can also hide validation and failed message with premium plugin (Only $2)**

**Features**

* You can choose effect.
* You can speed time of the effect.
* You can decide delay time(after that time message will disappear)
* You don't need to deactivate the plugin. You can disable plugin from the Setting page.

Many user want to hide success message that is been generated after email has been sent successfully but somehow they are not able to find it on google.So this plugin will allow them to hide it wihout any coding or additional settings.

We always welcome your [suggestion](https://wordpress.org/support/plugin/contact-form-7-hide-success-message) and We are always there to support you.

[Support Page](https://wordpress.org/support/plugin/contact-form-7-hide-success-message)

Even Contribution is also welcome. Contact me through rohilmistry [dot] ymail [dot] com.


**NOTE:** You need to enable the plugin from its setting tab and then only message will be hide otherwise it will remail there.It will only hide the **SUCCESS MESSAGE**.
**INITIAL RELEASE**

== Installation ==

Follow steps described below to install that plugin:

e.g.

1. Download **zip** file from the wordpress plugin page.
2. Upload that file to your wordpress site
3. Activate it.
4. Go to Settings > Hide Success Message tab > Enable it.

== Frequently Asked Questions ==

= Why message is not working? =

It might be because you have not Enabled it from the `Settings > Hide Success Message tab`.

= I want to get help, where should I go? =

Post your issue to our [Support Page](https://wordpress.org/support/plugin/contact-form-7-hide-success-message)

== Screenshots ==

1. Back End Setting Panel

== Changelog ==

= 1.1.2 =
Compitable with the Latest version of the Wordpress 4.3. (Date: 8 September, 2015)

= 1.1.0 =
Compitable with the Latest version of the Wordpress 4.2.2. (Date: 17 May, 2015)

= 1.0.0 =
* Initial release.

= 0.5 =
* Initial beta release.

== Upgrade Notice ==

= 1.1.2 =
* Compitable upto 4.3.If you found any bug or want any help, go to our [Support Page](https://wordpress.org/support/plugin/contact-form-7-hide-success-message)