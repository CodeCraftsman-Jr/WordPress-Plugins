=== Gravatar Hovercards ===
Contributors: ItsAbhik
Name: Gravatar Hovercards
Tags: Gravatar, Hovercards, Gravatar Hovercards, Avatar, Admin, Profile
Requires at least: 3.0
Tested up to: 3.3
Stable tag: 1.5
Donate link: http://www.itsabhik.com

Gravatar Hovercards shows the commentator's profile information from Gravatar on hovering the cursor on that commentator's gravatar.

== Description ==

Gravatar Hovercards shows the commentator's profile information from their Gravatar profile when someone hover the cursor on that commentator's gravatar in a WordPress blog.

* Follow me on <a href="https://plus.google.com/106671843900352433725?rel=author">Google+</a> | <a href="http://www.facebook.com/itsabhik">Facebook</a> | <a href="http://twitter.com/#!/itsabhik">Twitter</a>


== Installation ==

1. Download the zip file and extract it on your local computer
2. Upload the "gravatar-hovercards" folder and all it's content into your wp-plugins folder
3. Activate the Gravatar Hovercards plugin from your Plugins menu.

== Frequently Asked Questions ==

= How Do I check if the Plugin is working? =

This plugin doesn't add any admin menu upon activation. To check if it's working, just hover your mouse in any comment on your blog having a gravatar image.

== Screenshots ==
1. How it actually looks like

== Upgrade Notice ==
Overwrite the existing files in the /plugins/gravatar-hovercards/ folder

== Changelog ==

= 1.0 =
* Introductory Version.

= 1.5 =
* Added compatibility with WordPress 3.X.X