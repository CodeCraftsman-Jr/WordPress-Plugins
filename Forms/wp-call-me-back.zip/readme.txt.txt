=== WP callback ===
Contributors: pigeonhut
Donate link: 
Tags: Call Back, call back widget, quick contact, arrange call back
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.1.5

WP Call Back, gives you the ability to quickly add a call back widget to the sidebar of your website.


== License ==
WP Call Back is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

WP Call Back is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with WpController Worker. If not, see <http://www.gnu.org/licenses/>.

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

WP Call Back, gives you the ability to quickly add a call back widget to the sidebar of your website.

Colours are controlled via a colour picker in the settings.
Times and messages can be customised to suit.

Our other free plugins can be found at https://profiles.wordpress.org/pigeonhut/

To see more about us as a company, visit www.web9.co.uk

Proudly made in Belfast, Northern Ireland.


== Installation ==

install via the plugins system in WordPress or manually
1. Upload `Zip file` to the `/wp-content/plugins/` directory & extract.
then:
Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==


== Screenshots ==

1.



== Upgrade Notice ==
de-activate existing plugin
remove from dashboard
activate plugin and re-add domain






