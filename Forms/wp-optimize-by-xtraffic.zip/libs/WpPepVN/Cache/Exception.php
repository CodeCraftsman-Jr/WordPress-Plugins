<?php 
namespace WpPepVN\Cache;

/**
 * WpPepVN\Cache\Exception
 *
 * Exceptions thrown in WpPepVN\Cache will use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}