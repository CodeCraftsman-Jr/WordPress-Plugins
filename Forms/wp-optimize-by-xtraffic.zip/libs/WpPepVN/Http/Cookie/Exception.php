<?php 
namespace WpPepVN\Http\Cookie;

/**
 * WpPepVN\Http\Cookie\Exception
 *
 * Exceptions thrown in WpPepVN\Http\Cookie will use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}
