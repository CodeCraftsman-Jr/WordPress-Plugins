<?php 

namespace WpPepVN\Tag;

/**
 * WpPepVN\Tag\Exception
 *
 * Exceptions thrown in WpPepVN\Tag will use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}
