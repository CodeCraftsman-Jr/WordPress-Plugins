<?php 
namespace WPOptimizeByxTraffic\Application\Module\Backend\Controller;

class ControllerBase extends \WpPepVN\Mvc\Controller
{
	public function __construct() 
    {
		parent::__construct();
	}
	
}