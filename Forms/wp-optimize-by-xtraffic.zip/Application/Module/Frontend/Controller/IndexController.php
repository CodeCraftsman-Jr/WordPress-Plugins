<?php
namespace WPOptimizeByxTraffic\Application\Module\Backend\Controller;

class IndexController extends ControllerBase
{
    
	public function __construct() 
    {
		parent::__construct();
	}
	
    
	public function indexAction() 
    {
		//$this->view->render('layout/global', array('content' => 'home/index'));
		//$this->view->testVar = 'testVar : '. time();
	}
}