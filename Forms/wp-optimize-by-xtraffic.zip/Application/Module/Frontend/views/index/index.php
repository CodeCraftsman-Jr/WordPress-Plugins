<p>Welcome to Fresh MVC!</p>
<p>I have a lot of work to do here but don't let that stop you! Code!</p> 