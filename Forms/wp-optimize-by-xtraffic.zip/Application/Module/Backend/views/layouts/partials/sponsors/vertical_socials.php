<?php 
	echo '
<div class="row" style="text-align: center;">
	<iframe width="auto" height="1000" frameborder="0" src="//static.pep.vn/library/pepvn/wp-optimize-by-xtraffic/client/vertical_01.html?utm_source='.rawurlencode(WP_PEPVN_SITE_DOMAIN).'&utm_medium=plugin-wp-optimize-by-xtraffic-v-'.WP_OPTIMIZE_BY_XTRAFFIC_PLUGIN_VERSION.'&utm_campaign=WP+Optimize+By+xTraffic"></iframe>
</div>';
?>