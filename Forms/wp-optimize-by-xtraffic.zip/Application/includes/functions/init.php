<?php 
include_once (__DIR__ . DIRECTORY_SEPARATOR . 'minify.php');
include_once (__DIR__ . DIRECTORY_SEPARATOR . 'general.php');