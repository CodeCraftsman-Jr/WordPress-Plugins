<?php 
namespace WPOptimizeByxTraffic\Application\Service;

class Iso3166
{
	
}