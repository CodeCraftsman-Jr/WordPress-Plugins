<?php 
namespace WPOptimizeByxTraffic\Application\Service;

class WpConfigs
{
	
}