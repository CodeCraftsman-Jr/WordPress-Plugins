=== Forms by Systemo ===
Contributors: casepress
Tags: forms, form, callback, feedback, contact form, contact forms, custom form, custom forms, form, form administration, form builder, form creation, form creator, form manager, forms, forms builder, forms creation, forms creator, forms manager
Requires at least: 3.0.0
Tested up to: 4.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Fully customise WordPress forms with powerful shortcodes.

== Description ==

Forms is the perfect solution for any wordpress website which needs more flexible forms. 

Forms for contact page, CTA and landing page based on WordPress.

* Insert form as shortcode
* Create form template as post type
* Save data as post and send to email.


= Website =
https://github.com/systemo-biz/forms-s

= Documentation =
https://github.com/systemo-biz/forms-s/wiki

== Installation ==

1. Upload 'forms-s' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1 =
* Init realease
