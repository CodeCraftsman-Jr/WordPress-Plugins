<?php

/*
 * No uninstall operations required.
 */

?>
