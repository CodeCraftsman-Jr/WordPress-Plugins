<?php
/**
 * Search Form
 *
 * This file is being included into "../class-shortcodes.php" file's shortcode_render() method.
 *
 * @since  1.0
 */



//Output
	$output = get_search_form( false );

?>