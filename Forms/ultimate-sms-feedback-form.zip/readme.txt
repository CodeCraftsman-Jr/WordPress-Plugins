=== Ultimatesmsapi SMS PLugin ===
Contributors: Rahul Chaudhary
Donate link: http://ultimatesmsapi.tk/
Tags: sms, free sms api, sms api, sms contact, SMS gateway
Requires at least: 2.0
Tested up to: 3.4.2
Stable tag: 4.3

GET FEEDBACK MESSAGES ON YOUR PHONE USING ANY FREE SMS PROVIDER

== Description ==

GET FEEDBACK MESSAGES ON YOUR PHONE USING ANY FREE SMS PROVIDER

No need to register on <a href='http://ultimatesmsapi.tk'>ultimatesmsapi.tk</a> nut you need to register on any one of the SMS provider site which are supported by ultimatesmsapi.tk

== Installation ==

1. Download the zip package
2. Login to your Wordpress Admin Panel
3. Go to Plugins-> Add New -> Upload & upload the zip package
4. Go to Settings-> Ultimatesmsapi SMS & fill in the required parameters (examples are provided at the settings screen)
5. Just write [ultimatesmsapi] in any post where you want to show the SMS form


== Frequently Asked Questions ==

= Will this work always? =

Yes, just make sure you configure the Gateway properly on the settings page.

= Do I need to register on your site also? =

No, you dont need to register on my site.

== Screenshots ==

1. Screenshot
