=== ZD Pre Loader===
Contributors: zakirbd63
Tags: smooth, pre-loading, page, post, loading
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple and nice pre-loading effect for your wordpress site.

== Description ==
Simple and nice pre-loading effect for your wordpress site. I have add only the bounce loading effects for this plugin. You can easily the the pre-loader color from the ZD Preload Option page. 

== Installation ==
1. Download the zip file and Install as a regular WordPress plugin.
2. If you want to change the preload color then just go to ZD Preload Option under the setting menu and change the color. 


== Screenshots ==
1. ZD Pre Loading Effect in Site


== Changelog ==
= Initial release  1.0 =
