=== Contact Form 7 Redirect ===
Contributors: tahiryasin
Donate link: 
Tags: contact, form, redirect, cf7, contact form 7, thank you
Requires at least: 3.3
Tested up to: 4.2.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily redirect Contact Form 7 forms to any thank you URL.

== Description ==

This plugin seamlessly integrates with Contact Form 7 Plugin and provides an option to redirect forms to any thank you page URL. Different forms can have different thank you page URL. 

== Installation ==

1. Upload zip to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the form you want to redirect and put the thank you page URL
4. Save the form, done !

== Frequently asked questions ==

Feel free to ask on support page, if you have any question. 

== Screenshots ==

1. It adds a new field Redirect URL to contact form settings page.

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==

