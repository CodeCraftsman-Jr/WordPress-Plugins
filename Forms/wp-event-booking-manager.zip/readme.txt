=== wordpress Event booking Manager ===
Contributors: upscalethought

Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=upscalethoughtsoln@gmail.com&item_name=Donation+for+wordpress_event_booking
Tags: booking, event, event management, event ticket booking, event booking, ticket booking, doctors event, admin, administration, AJAX, event, availability, availability calendar, lawer event scheduling booking, Book, Booking calendar, booking form, booking system, booking engine, booking module, booking plugin, calendar, contact form, parties event registration,ticketing,event ticket booking,conference booking,online event registration booking calendar, online reservation, Reservation, reservation calendar, reservations, reservation plugin, event scheduling, event management, event planner, date blocker, jquery, management, meeting, Meeting event scheduling, Organizer, rent, Rental, reservation system, event calendar, event system, sponsor, to book, tutors event booking, summits event booking, singer event scheduling booking, php event booking system, php mysql event booking calendar, wordpress online event registration booking, wordpress event schedule reservation, Wordpress event ticket booking, wordpress event ticket booking script, gatherings event booking,appointment ticketing,photographer event scheduling booking registration, wp event calendar booking manager, wp  event calendar ticket reservation system, wp reservation script

Requires at least: 3.3.0
Tested up to: 4.2
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


Provides an easy way to manage your event calendar booking and check availability in custom Calendar and manage registration and ticket selling.

== Description ==

"wordpress Event booking Manager" plugin will enable online Event Ticket Booking services for your site.
You can manage the bookings (availability) on an ourly/custom time basis. event booking calendar page will be created automatically and to generate
calendar in frontend shortcode will be automatically copied. you can add/edit sponsors/venues/organizers or any event or delete bookings from admin to manage the full system.
you can show and manage your event ticket Booking/any event(or something else).

> **Get our pro version and get more features and full technical support**
> [wordpress Event booking Manager Pro](http://upscalethought.com/?page_id=9 ) also comes with a premium paid version. Upgrade to [wordpress Event booking Manager Pro]( http://upscalethought.com/?page_id=9) for exceptional features, including a detailed Integrated Payment Gateway, Customized Calendar view, Free Technical support and much more. [Checkout all the awesome pro features]( http://upscalethought.com/?page_id=9).
>


Your Customers will be able to:

	
= KEY BENEFITS: =
- very easy to install and configure. 
- Very flexible functionality. Fit to very wide range of business.
- All bookings and settings are stored in your DB. You don't need third party account(s).
- An easy to use Event Booking Admin Panel that displays Event bookings in Calendar Overview and lets you manage bookings.
- Built with jQuery, Ajax and other technologies.
- Easy to install and integrate into your site. because necessary post or page will be automatically created and shortcodes will be automatically copied to page.
	
= FEATURES: =
- Make event Registration ticket bookings in friendly booking interface - select the date(s) and time and fill form fields.
- Prevent of booking for already reserved event (no of ticket booking for a event which is exactly equal to total no of seat).
- RESPONSIVE event booking and availability Calendar to fit any device
- Add/Edit/Manage Event Booking from Admin Interface.
- Insert Event Ticket Booking Calendar into any Post/Page using ShortCode [evntgen_ustscalendar].
- Pretty modern administration interface.
- Supports both am/pm time.
- Allows inserting the organizer, sponsors and venues for an event.
- Allows defining the product name at PayPal, the currency, tax,administrator email and the PayPal language in pro version.
- any kind of event, event registration and ticketing can be managed by this plugin.
- Colors customization - Event-Calendar Wordpress event commerce plugin lets you brand the event color so it would perfectly fit your website's colors and theme.
- Unlimited number of event, unlimited number of clients.
- venue, organizer, sponsor are unlimited and fully dynamic. so you can set according to your need.
- Multiple-currency support.
- Show events in the daily, weekly or monthly view.
- Easily add, edit or delete event in WP Admin.
- automatically page created and shortcode copied to page to generate calendar and payment process related pages. so its really easy to install and configure.
- and much more coming soon...

= Additional Features Available with the Pro (paid) version only =
- Free Installation Service
- Unlimited Events Entries
- Integrated Payment Gateways
- Built in Shopping Cart Enabled
- Personalized Calendar User Interface
- Manage Booking Straight From the Custom Made Calendar
- Unlimited Background Color setting for Schedule Event
- Email Support
- Booker receives an email
- Owner (admin) receives email of booking
- Event Calendar month, week and day view
- Full Technical Support From Us

[Upgrade to the Pro version]( http://upscalethought.com/?page_id=9) for all the pro features, and read more in [depth details](http://upscalethought.com/?page_id=9 ) about the plugin.


= Manage your Bookings in Admin Panel: =
- Comfortable Admin Panel for Event schedule booking management. View Event bookings in Calendar Overview Panel (Timeline) with possibility to set Day/Week/Month view 
	or in Booking Listing Table with pagination.
- In manage booking Search the booking(s) by different parameters, using the Filter in Admin Panel.
- Pagination of the booking listing.
- Administrator can edit or Delete specific bookings.
- View the Event bookings in booking calendar of any month of any year.

= Desired Businesses / You can use this Event booking calendar plugin as: =
- parties ticket booking.
- tech conferences.
- Summits.
- gatherings.
- appointments.
- charities.
- masses.
- events
- Whatever you like!
	 
This plugin is compatible and tested up to Wordpress Version: 4.2 

<p>Some of our popular extensions include the followings:</p> 

 <p><a rel="nofollow" href="http://upscalethought.com/?page_id=9">UpScaleThought Plugins</a></p>


Check <a rel="nofollow" href="http://upscalethought.com/?page_id=9">UpScaleThought Products</a>  for more Plugins.


== Screenshots ==

 
1. Admin - event category

2. Admin - manage venue

3. Admin - add new venue

4. Admin - add event booking

5. Admin - event booking managememnt

6. Admin - event calendar

7. Admin - event color setting

8. Admin - frontend css fix

9. Front - Event Booking Calendar

== Changelog ==

= 1.0 =
This is the initial version of the plugin.

== Installation ==

1) Copy/Upload 'evntgen-ustsbooking' folder to the '/wp-content/plugins/' directory
2) Activate 'wordpress Event booking Manager Pro' form wp plugin option in admin area
3) Plugin will appear in the menu bar of WP Dashboard
4) create venue/sponsors/organizer/events for booking.
5) please save primary menu if no rooms gallery or booking calendar is showing in frontend.

== FAQ ==

= 1.1 =
First version of "wordpress Event booking Manager Pro" . No errors known.