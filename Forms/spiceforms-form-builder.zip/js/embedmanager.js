EmbedManager.embed({
			key: spiceform.sf_path+"forms/view",
			width: "100%",
			mobileResponsive: true,
			embedId:spiceform.id
			});iFrameResize();