=== jQuery CommentVaidation ===
Author: FoO Iskandar
Donate link: http://iskandar.web.id/
Tags: comments
Requires at least: 2.9
Tested up to: 2.9
Stable tag: 0.2

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

jQuery Validation for WP comment system 

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `jquery-comment-validation` folder to the `/wp-content/plugins/` directory
2. Activate the plugin and check out on your blog comment.



