<div id="marketo_fat_popup_container" style="display:none;">
    <h3>Enter a Marketo Form ID</h3>
    <br>
    <input type="text" name="marketo_form_id" />
    <p class="description">Make sure this form is only used once on a page, as duplicate forms on the same page will cause unpredictable behaviour. Multiple forms with different IDs are acceptable.</p>
    <p><input type="button" class="button-primary marketo-fat-add-shortcode" value="Insert Form"></p>
</div>