=== Plugin Name ===
Contributors: (feedbacknote)
Donate link:
Tags: admin, development
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Feedback Note makes communication between clients and developers super efficient.

== Description ==

Feedback Note makes communication between clients and developers super efficient. This is done by adding a note with feedback directly on the area where the change should be made.

The feedback is organized in your Wordpress panel and ready for export to your favorite project management tool like Trello and Basecamp.

== Installation ==

This section describes how to install and activate the plugin.

Use the automatic plugin installer or download the files and put the FeedbackNote folder into /wp-content/plugins/.
Activate the plugin through the 'Plugins' menu in WordPress.
That’s it! Your ready for Feedback!

== Screenshots ==

== Changelog ==

= 0.9 =
First version

== Arbitrary section ==
