<?php 
header('Content-type: text/css'); 
require_once('../../../../wp-load.php');
?>
#syntax_shortcode_striping_nth_slider{
	width: 215px;
	margin-top: 8px;
}
