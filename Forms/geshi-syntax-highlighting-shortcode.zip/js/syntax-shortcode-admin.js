jQuery(function($) {
	 $('#colorpicker').farbtastic();
 });