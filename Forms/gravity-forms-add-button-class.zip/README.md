# gravityforms-add-button-class  
Add CSS classes to the Submit button in Gravity Forms directly from the Form Settings Panel
