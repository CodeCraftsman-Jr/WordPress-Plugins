=== cf7 Confirm Field ===
Contributors: mdoff
Donate link: http://example.com/
Tags: contact-form, cf7
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin allows to make sure that e.g. emails in two fields are the same

== Description ==

*It's not a standalone plugin* requires installed *Contact Form 7*

This plugin solves problem of e.g. email verification or email confirmation.

Just create second field with `_confirm` at the end of the field name. Look in the screenshots for example.



== Installation ==

1. Upload `cf-confirm-field` folder or `cf-confirm-field.php` file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Screenshots ==

1. Example form

== Changelog ==

= 0.0.1 =
First version
