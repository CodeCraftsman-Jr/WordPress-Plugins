Gravity Forms Approvals Add-On
==============================

Gravity Forms Approvals is an Add-On for [Gravity Forms](http://www.stevenhenty.com/gravityforms)

This add-on was originally created as part of tutorial for developers.

http://www.stevenhenty.com/gravity-forms-approvals/

The first part of the tutorial can be found here:

http://www.stevenhenty.com/gravity-forms-platform-tutorial/
