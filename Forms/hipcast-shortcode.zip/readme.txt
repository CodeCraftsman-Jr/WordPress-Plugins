=== Hipcast Shordcode ===
Contributors: vs_dev
Tags: hipcast
Requires at least: 3.0.2
Tested up to: 3.0.2
Stable tag: 1.0.0

Allows Hipcast.com users to post their media directly to WordPress blogs.

== Description ==

This plugin streamlines the process of hipcast.com users to post their hipcast media into their blog using shortcodes.

== Installation ==

To install this plugin, simply click the "Install Now" link then activate it in your installed plugins list.

== Frequently Asked Questions ==

How do I use the Hipcast Plugin?

Once you've installed the plugin to your blog, simply login to your hipcast.com account and set up your blog. 
Make sure you select the blog type to be WordPress and you check the "Use Plugin" option.

== Changelog ==

1.0 -- Added basic support for hipcast.com users.
