=== Plugin Name ===
Contributors: pyoon
Donate link: http://eff.org/
Tags: fish, seafood, fishbase, random
Requires at least: 2.7.1
Tested up to: 2.7.1
Stable tag: trunk

Links to a random fishbase entry, changes daily.

== Description ==

Not much to say, really. Provides a random link to the awesome fishbase.org. Tested with older versions but no promises. It's not particularly complicated or anything.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. I think that's it. Did I forget something?

== Frequently Asked Questions ==

= What? Why bother? =

This plugin is clearly not for you.

= Your plugin is dumb. =

Can you help me make it better? That would be cool.