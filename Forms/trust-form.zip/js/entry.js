var trustFormEntries;
(function(a){
	trustFormEntries =
	{
		init:function()
		{
			//postboxes.add_postbox_toggles("trustform");
			//a(".inside").css("background-color", "white");
			//a(".hndle").css("background-color", "white");
		},
	},
	a(document).ready(function ()
    {
        trustFormEntry.init();
    })
})(jQuery);