=== firstform ===
Contributors: fnotes
Tags: form,inquiry,contact
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy create a inquiry form, Check the inquiry.


== Description ==

You can place the inquiry form to the articles and fixed page, the widget.
Just continue to add form items with a shortcode, you can create a form.


== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently asked questions ==

= Q. How to add or validate forms ? =

A. Just add them to select an item.


== Screenshots ==

1. Configuration
2. Inquiry list
3. shortcode


== Changelog ==

= 1.0 =
* Initial release


== Upgrade notice ==


== Arbitrary section ==
