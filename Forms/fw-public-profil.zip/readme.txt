=== Plugin Name ===
Contributors: WieserFranz
Donate link: http://www.wieser.at/wordpress/plugin
Tags: Profil, Public,
Requires at least: 0.1
Tested up to: 3.3.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Public Profil - Benutzerdaten auf Seiten oder Beiträge per Shortcode anzeigen

== Description ==
Profil Daten und auch erweiterte Profilfelder können im Frontend auf Seiten, Beiträge usw plaziert werden

	╔═╦╗╔╗╔╦══╦══╦╗ ╔╗     ╔═╦═╦═╦═╦╦══╦╦╦╦╦═╦═╦═╦═╗
	║║║║║║║║╔═╣║║║║ ║╚╦╗╔╗ ║═╣║║═║║║╠══║║║║║═╣╚╣═╣║║
	║╔╣╚╣╚╝║╚ ║║║║║ ║║║╚╝║ ║╔╣ ║║║║║║══╣║║║║═╣╗║═╣ ║
	╚╝╚═╩══╩══╩╩╩═╝ ╚═╣╔═╝ ╚╝╚╝╩╩╩╩═╩══╩══╩╩═╩═╩═╩╝╚
	                  ╚╝


== Installation ==

1. Entpacke das Downloadfile und lade den Plugin Ordner in den  `/wp-content/plugins/` Ordner
1. Aktiviere das Plugin unter  'Plugins' Menü in WordPress
1. mit Shortcode [fwuserblock user="username"]Name: [fwuser feld="last_name"] Vorname: [fwuser feld="first_name] und noch ein Text [/fwuserblock] werden Blöcke in Posts gestaltet um ein oder mehrer Profile von Usern darzustellen.
1. Ideal für zum Beispiel Vereinsfunktinäre, Firmenmitarbeiter

== Frequently Asked Questions ==
1.
1.
1.


== Screenshots ==
* kommt bald


== Changelog ==


= 0.1 =
* Grundfunktion

== Upgrade Notice ==
* erste Version
