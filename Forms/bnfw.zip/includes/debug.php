<?php
/**------------------------------------------------------------------------ *
 * Debugger functions
 *
 * Include this file for debugging
 * ------------------------------------------------------------------------ */

// Debugger
//add_filter('the_content', 'bnfw_debug');

// function bnfw_debug($content){
// 	$bnfw_options = get_option('bnfw_settings');

// 	if ( !isset( $wp_roles ) )
// 		$wp_roles = new WP_Roles();
// 	var_dump($wp_roles->get_names());

// 	var_dump($bnfw_options);
// 	return $content;
// }
?>
