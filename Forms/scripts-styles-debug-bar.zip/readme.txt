=== What Scripts Styles Debug Bar ===
Contributors: ravinderk, sudeep333
Tags: Debug, Debug Bar
Requires at least: 3.1
Tested up to: 4.1
Stable Tag: 0.2
Dependencies: debug-bar plugin
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A tiny plugin to display all enqueued scripts and style


== Description ==

A tiny plugin to display all enqueued scripts and styles.
Adds two menu items into debug-bar menu:
1) All Scripts
2) All Styles


== Installation ==

* Install debug-bar plugin first.
* Upload the folder `scripts-styles-debug-bar` to the `/wp-content/plugins/` directory
* Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

= Can I use this on production / live site? =

You can you it for both sites to debug your script and style files.

== Screenshots ==

1. All scripts panel
2. All styles panel


== Upgrade Notice ==
* Always use the latest and the greatest for the best experience.


== How to use == 
It will get attached with debug-bar plugin [ check All Scripts and All styles Panels in Debug Bar ].


== Changelog ==

= 0.2 =
Some small fixes

= 0.1 =
Initial Release