<?php


 


piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_widget_title'


 ,'label' => __('Widget Title','hcard-widget')


 ,'description' => ''


 ,'value' => ''


 ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));











piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_legalname'


 ,'label' => __('Legal Name','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_brand'


 ,'label' => __('Brand','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_phone'


 ,'label' => __('Phone','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_fax'


 ,'label' => __('Fax','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_email'


 ,'label' => __('Email','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_url'


 ,'label' => __('Website','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));


piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_street'


 ,'label' => __('Street Address','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_street2'


 ,'label' => __('Address Line 2','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));


piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_city'


 ,'label' => __('City','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_state'


 ,'label' => __('State or Province','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_country'


 ,'label' => __('Country','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));


piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_postcode'


 ,'label' => __('ZIP/Postal Code','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_twitter'


 ,'label' => __('Twitter','hcard-widget')


 ,'description' => __('Twitter username without the @','hcard-widget')


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_fb'


 ,'label' => __('Facebook URL','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_gplus'


 ,'label' => __('Google Plus URL','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





piklist('field', array(


 'type' => 'text'


 ,'field' => 'hcard_org_linkedin'


 ,'label' => __('LinkedIn URL','hcard-widget')


 ,'description' => ''


 ,'value' => ''


  ,'columns' => 12


 ,'attributes' => array(


 'class' => 'text'


 )


));





?>