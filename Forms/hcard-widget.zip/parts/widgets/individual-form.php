<?php

 

piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_widget_title'

 ,'label' => __('Widget Title','hcard-widget')

 ,'description' => ''

 ,'value' => ''

 ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_name'

 ,'label' => __('Name','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));

 

 piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_job'

 ,'label' => __('Job Title','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_org'

 ,'label' => __('Organization','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_phone'

 ,'label' => __('Phone','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_fax'

 ,'label' => __('Fax','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_email'

 ,'label' => __('Email','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_website'

 ,'label' => __('Website','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_street'

 ,'label' => __('Street Address','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_street2'

 ,'label' => __('Address Line 2','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));

piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_city'

 ,'label' => __('City','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_state'

 ,'label' => __('State or Province','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_country'

 ,'label' => __('Country','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));

piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_postcode'

 ,'label' => __('ZIP/Postal Code','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_twitter'

 ,'label' => __('Twitter','hcard-widget')

 ,'description' => __('Twitter username without the @','hcard-widget')

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_fb'

 ,'label' => __('Facebook URL','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_gplus'

 ,'label' => __('Google Plus URL','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));



piklist('field', array(

 'type' => 'text'

 ,'field' => 'hcard_ind_linkedin'

 ,'label' => __('LinkedIn URL','hcard-widget')

 ,'description' => ''

 ,'value' => ''

  ,'columns' => 12

 ,'attributes' => array(

 'class' => 'text'

 )

));









?>