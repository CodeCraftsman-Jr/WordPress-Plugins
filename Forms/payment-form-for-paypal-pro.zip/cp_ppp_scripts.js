function cp_ppp_insertForm() {
    send_to_editor('[CP_PPP]');
}