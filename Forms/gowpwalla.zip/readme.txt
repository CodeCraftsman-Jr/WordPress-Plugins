=== GoWPWalla ===
Contributors: scottkahler
Tags: gowalla, geolocation
Requires at least: 2.9
Tested up to: 2.9.2

GoWPWalla uses the gowalla.com API service to pull back user account Gowalla status

== Description ==

Add Description

== Installation ==

Add Installation Instructions

== Screenshots ==

* screenshot-1.png
* screenshot-2.png
* screenshot-3.png
* screenshot-4.png

== Changelog ==

= 1.0.2 =
* Adding Application Icon
* Adding some customizable fields for list lengths
* Making Large Icon Recent Spots and Compact Icon Recent Spots
* Adding a Location Widget
= 1.0.1 =
* Initial Release
