=== Find Us ===
Contributors: wpdprx
Donate link: http://wordpress.designpraxis.at/
Tags: map, google maps, google
Requires at least: 2.1
Tested up to: 2.2.2
Stable tag: trunk

== Description ==

This plugin displays a map on your website and allows your visitors to find their way to your location.
Languages available: english, deutsch(german), espanol(spanish)

== Installation ==

1. As always: download, unzip and upload to your WordPress plugins directory
2. Get Your Google API Key
3. activate the plugin within you WordPress Administration Backend
4. go to Options > Findus and enter API Key and location
5. Make use of [findusmap] throughout your posts and pages

== Frequently Asked Questions ==

= Can I have custom maps from post to post? =

Of course, check out the AdvancedMode of the Find Us Options in your WordPress admin backend.

= I get an error about file_get_contents(), what to do? =

The error
Warning: file_get_contents() [function.file-get-contents]: URL file-access is disabled in the server configuration
appears on hosts that do not allow file-access. This error was fixed by using snoopy.
Download the newest version!

== Screenshots ==

1. Just enter where your journey starts...

