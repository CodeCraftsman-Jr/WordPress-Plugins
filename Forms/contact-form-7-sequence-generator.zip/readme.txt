=== Contact Form 7 Sequence Generator ===
Contributors: edpittol, gutobenn
Tags: contact form, sequence, generator
Requires at least: 3.6
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Generate a sequence for use with a Contact Form 7 form.

== Description ==
Generate a sequence for use with a Contact Form 7 form.

= Development = 
https://github.com/aztecweb/contact-form-7-sequence-generator

== Installation ==

1. Upload 'contact-form-7-sequence-generator' folder to the '/wp-content/plugins/' directory
2. Include the shortcode [sequence-generator] in Mail or Mail(2) bodies of a contact form

== Changelog ==

= 1.00 =
Initial version
