# Genesis js / no-js Changelog

## 2.0.0 (2014-08-23)

* Refactor class into a new file. Stops using half-implemented Singleton pattern.
* Update documentation.
* Add GitHub Updater support.

## 1.0.1 (2011-06-02)

* Improved plugin so script is hooked in with priority 1 - avoids a theme placing anything before the script (props [Josh Stauffer](http://twitter.com/joshstauffer))

## 1.0.0 (2011-05-24)

* Initial release.