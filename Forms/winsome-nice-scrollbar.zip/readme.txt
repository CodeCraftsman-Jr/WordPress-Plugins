=== Winsome Nice Scrollbar ===
Tags: wordpress scrollbar,jQuery scrollbar, scrollbar,nice scrollbar,custom scrollbar
Requires at least: 3.0.1
Tested up to: 4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will add a nice custom scrollbar. You can controll scrollbar settings from admin nice scrollbar admin panel.

== Description ==

### Winsome nice scrollbar by http://abdullahmasum.elance.com/

This plugin will add a nice custom scrollbar. No shortcode needed and very lightweight.

Plugin Features

* Unlimited color
* Strong admin panel for customizing
* Border and brder-radius supports 
* Mobile touch option. 
* Very Lightweight.
* Controlling scroll speed
& many More

Live Preview: http://www.mhost.5gbfree.com/demo

== Installation ==

<strong> One click installation </strong>

* Install it as a regular WordPress plugin
* after installation winsome scrollbar option panel add automatically.
e.g.

1. Upload `plugin` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

= A question that someone might have =

= What about color ? =

You can controll color from admin panel color picker.

= What about shortcode ? =

you need no shortcode. one click installation(super easy)

== Screenshots ==

1.admin panel menu
2.admin panel

== Changelog ==


= 1.1 =
* Initial release

== Upgrade Notice ==

