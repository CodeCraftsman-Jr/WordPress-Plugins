=== Plugin Name ===
Contributors: techgin
Donate link: http://techgin.com
Tags: users contact form, registered user contact form, contact form, simplecontact form
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is  simple plugin that allow logged users send short messages directly to admin email. 

== Description ==

This is  simple plugin that allow logged users send short messages directly to admin email.  Admin will receive, user name, user email, subject and messagecontent. Plugin only will be see for registered and logged users. Also this plugin uses own styles. You can change form input field styles by changing style.css in plugin folder.

== Installation ==
1. Upload `users_contact_form` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place `<?php do_action('ucf_contact_form'); ?>` in your templates where you want to show contact form/

== Frequently Asked Questions ==
= hoe can I change email address ? =

You can cnage via own user profile.

== Screenshots ==

1. Contact form example.

== Changelog ==

= 0.1 =
Created plugin & added capability to tranlsate field and messages via codestyle localization plugin

== Upgrade Notice ==

= 0.1 =
No upgrade notices at this time.
