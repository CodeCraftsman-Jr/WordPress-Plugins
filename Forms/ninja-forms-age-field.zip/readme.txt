=== Ninja Forms Age Field ===
Contributors: ivan_paulin
Tags: ninja, forms, age, field, birth date, ninja forms
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin uses date picker field on front-end for adding date of birth, and converts birth date into age number. 

== Description ==

This plugin uses date picker field on front-end for adding date of birth, and converts birth date into age number. Input date format must be: mm/dd/yyy
Ninja Forms plugin must be install prior Ninja Forms Age Field extension.

It simply adds input field with date-picker on front-end, visitor is required to choose his birth date from calendar.
When form is submitted, visitor age will be returned, instead of full date.


== Installation ==

This section describes how to install the plugin and get it working.

Upload ninja-forms-extension-age-field.zip file through WordPress admin, or

FTP:
1. Upload `ninja-forms-extension-age-field` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


