=== Generate Disable Mobile ===
Contributors: edge22
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UVPTY2ZJA68S6
Tags: generatepress, disable mobile
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Disable mobile functionality in GeneratePress

== Description ==

Disable mobile functionality inside the GeneratePress theme.

Simply install, activate and you're done!

This plugin requires GeneratePress to be your active theme - without GeneratePress, this plugin is useless.

== Installation ==

There's two ways to install.

1. Go to "Plugins > Add New" in your Dashboard and search for: Generate Disable Mobile
2. Download the .zip from WordPress.org, and upload the folder to the `/wp-content/plugins/` directory via FTP.

In most cases, #1 will work fine and is way easier.

== Changelog ==

= 0.1 =
* Initial release

== Upgrade Notice ==

= 0.1 =
* Initial release