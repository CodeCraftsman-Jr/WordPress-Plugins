<?php

$mrt_sms_db_version = "1";

function mrt_kareem_install () {
   global $wpdb;
   global  $mrt_kareem_db_version;
$mrt_kareem_db_version = "2.4"; //new db version
  
   }

?>
