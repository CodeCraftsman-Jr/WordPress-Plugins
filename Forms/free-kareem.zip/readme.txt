=== Plugin Name ===
Contributors: hallsofmontezuma
Donate link
https://www.paypal.com/us/cgi-bin/webscr?cmd=_flow&SESSION=nYi5HJVq6fuOBRzbG7YslsSQsGfDUWdnqvSvwaFWEwSXhQDd514NemjN-RK&dispatch=5885d80a13c0db1f38432c9462fe7313791b4c12e10393700fb86c39eca5ec92
Tags: kareem, free speech
Requires at least: 2.0
Tested up to: 2.7
Stable tag: .5.5

Kareem Amer is an Egyptian blogger who is being wrongfully imprisoned and
tortured by the Egyptian government for exercising free speech in blogs, which
criticized certain aspects of corruption in the Muslim clergy and in the
Egyptian government. The Free Kareem Coalition, a non-profit team of free
speech advocates, primarily made up of Muslims, sponsored the creation of this
plugin to provide awarenes for the cause. It allows the display of a widget
promoting the group and creating awareness of the situation.

== Description ==


***All donations for this plugin go directly to the Free Kareem Coalition***

Kareem Amer is an Egyptian blogger who is being wrongfully imprisoned and
tortured by the Egyptian government for exercising free speech in blogs, which
criticized certain aspects of corruption in the Muslim clergy and in the
Egyptian government. The Free Kareem Coalition, a non-profit team of free
speech advocates, primarily made up of Muslims, sponsored the creation of this
plugin to provide awarenes for the cause. It allows the display of a widget
promoting the group and creating awareness of the situation.


**Features**<br />
-includes built-in widget<br />
-easy, simple administrative management interface<br />

**Future Releases**<br />
*email me or start a thread with features you would like to see<br />


== Installation ==

1. Create backup.
2. Upload the zip file to the `/wp-content/plugins/` directory
3. Unzip.
4. Activate the plugin through the 'Plugins' menu in WordPress
5. Drag the widget over to your active widgets.
6. Enjoy.

Please let me know any bugs, improvements, comments, suggestions.


== Frequently Asked Questions ==

= Can I customize this plugin? =
Absolutely. Whether you would like to show only Kareem's photo and the feed
from FreeKareem.org, or only a video and the social networking links, or
simply an alert and a count-up of his time in prison, or a "tell a friend"
e-mail option to increase awareness, or anything in between - this plugin
allows you to choose whichever you prefer to show on your sidebar. 

= How do I customize it? =
After you download and upload the plugin to your WordPress site (see
"Installation"), go to "Settings" and proceed to the Free Kareem tab. Tick
whatever option you would like your widget to include, and untick whatever you
wish to eliminate. All the buttons are ticked by default, but this is just to
show you the options before you begin customizing it depending on your needs.

= Is it compatible with WordPress 2.7? =
Yes. It is compatible with every version of WordPress since 2.0 and we'll
continue making it compatible with future releases of WordPress as well. 

= Does this plugin come in different languages? =
Yes, very soon. Thanks to the outstanding support of volunteers we are
currently working on launching this plugin in different languages. If you
would like to translate this plugin, please let us know.

= Can I edit this plugin? =
Everyone is welcome and encouraged to edit and improve upon this plugin.

= I have a technical issue with this plugin, what do I do? =
If you have problems with this plugin, please do not hesitate to contact us:
editor[at]freekareem.org, you may also post about it on the WordPress support
forums where many experts will be able to help you.


== Screenshots ==
1. Management Screen


== Free Kareem ==

Visit our homepage at [Semper Fi Web Design](http://semperfiwebdesign.com/ "Raleigh Web Design") or our plugin page at [Semper Fi Plugins][sf plugins].
We look forward to hearing your comments and suggestions.

[sf plugins]: http://semperfiwebdesign.com/plugins/
            "Raleigh Web Design"
