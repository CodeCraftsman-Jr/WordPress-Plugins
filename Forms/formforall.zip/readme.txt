=== Contact form Form For All - Easy to use, fast, 37 languages. === 
Contributors: FormForAll
Donate link: https://www.formforall.com/
Tags: formforall, form4all, form for all, form, forms, online forms, form builder, lead generation, contact form, contact forms, survey, order form, online survey, registration form, event registration form, signup form, login form, subscription form, newsletter form, lead generation form, multilingual, social login, Facebook connect, Facebook, responsive design, double optin, arabic, armenian, bengali, bulgarian, catalan, chinese (simple), czech, danish, dutch, english, estonian, finnish, french, flemmish, georgian, german, greek, hebrew, hindi, hungarian, indonesian, italian, japanese, korean, lithuanian, norwegian, persian, polish, portuguese, slovak, spanish, swedish, russian, turkish, ukrainian, formulaire de contact, formulaire, formulario de contacto, registro, reserva, inscripcion, inicio de sesion, formulario, cadastro, Google+ connect, modulo di contatto, modulo, Kontaktformular, Formular, formularz kontaktowy, formularz, форма контактов, форма, social login form, formulário de contacto, formulário, Contactformulier, formulier, Iletisim formu, formu

Requires at least: 3.5.1
Tested up to: 4.3
Stable tag: 1.0
License: GPLv2 or later

Drag and Drop interface. Tens of predefined fields, including Connect with Facebook and Google+. 37 languages. Responsive design. Double opt-in.


== Description ==
With <a href="http://www.formforall.com" rel="nofollow" target="_blank">FORM FOR ALL</a>, create and launch your online forms <a href="http://www.formforall.com" rel="nofollow">IN SECONDS</a>!</p>
<p><a href="http://www.formforall.com/features" rel="nofollow">EXCLUSIVE FEATURES</a>: Connect with Facebook Form, Google+ Form, Double opt-in form, forms in 37 languages.</p>
<p><a href="http://www.formforall.com/pricing" rel="nofollow">FREE PLAN</a> available and <a href="http://www.formforall.com/pricing" rel="nofollow">1st MONTH FREE</a> on all paid plans. No engagement.</p>

For this plugin to work, you need:

* to open a Form For All account: signup for free at https://www.formforall.com and test all our plans freely for one month.
* to use our User API key (refer to http://blog.formforall.com/ ).

<h4>DESCRIPTION</h4>

Contact form, Sign-up form, Log-in form, Subscription form, Booking form, Survey form, Event registration, Email newsletter… Just do any form with our online form builder!

Our FormForAll's plugin and widget allow you to easily insert your FormForAll forms into your sidebar and to embed them into your Wordpress site.

* <a href="http://www.fr.formforall.com" rel="nofollow">Français</a>: Formulaire de contact, formulaire de Sign-up, formulaire de Log-in, formulaire d'inscription, formulaire de réservation, formulaire de sondage, email newsletter… Faites tout simplement n'importe quel formulaire avec notre générateur de formulaire !
Nos plugin et widget FormForAll vous permettent d'insérer facilement vos formulaires FormForAll dans votre barre de menu et de les intégrer dans votre site Wordpress. (Plus d'infos sur http://www.fr.formforall.com )

* <a href="http://www.es.formforall.com" rel="nofollow">Español</a>: Formulario de contacto, formulario de Sign-up, formulario de Log-in, formulario de inscripción, formulario de reserva, formulario de sondeo, e-mail newsletter… Con nuestro creador podrá generar cualquier tipo de formulario.
Nuestro plugin FormForAll y widget le permite insertar fácilmente los formularios FormForAll en tu barra lateral e incrustarlos en tu sitio de WordPress. (Más info en http://www.es.formforall.com )

* <a href="http://www.it.formforall.com" rel="nofollow">Italiano</a>: Modulo di contatto, modulo di registrazione, modulo di accesso, modulo di registrazione, modulo di prenotazione, modulo di sondaggio, newsletter... Crea facilmente qualsiasi modulo con il nostro generatore di moduli!
Il nostro plugin per Wordpress e il nostro widget permettono di inserire facilmente i moduli FormForAll nella barra dei menu e di integrarli nel tuo sito Wordpress. (Maggiori informazioni su http://www.it.formforall.com)

* <a href="http://www.de.formforall.com" rel="nofollow">Deutsch</a>: Kontaktformular, Sign-up-Formular, Log-in-Formular, Anmeldeformular, Buchungsformular, Umfrageformular, E-Mail-Newsletter Erstellen Sie jegliche Formulare mit unserem Formulargenerator!
Unser Wordpress Plugin und unser Widget bieten Ihnen die Möglichkeit, Ihre FormForAll Formulare einfach in Ihre Menüleiste einzufügen und sie in Ihrer Wordpress Webseite zu integrieren. (Mehr über http://www.de.formforall.com)

* <a href="http://www.pl.formforall.com" rel="nofollow">Polski</a>: Formularz kontaktowy, formularz rejestracji, formularz logowania, formularz subskrypcji, formularz rezerwacji, formularz sondażu, e-mail newsletter… Stwórz dowolny formularz za pomocą naszego kreatora formularzy!
Wtyczka do Wordpressa oraz widżet pozwalają wkleić w łatwy sposób formularze FormForAll do Twojego paska menu oraz połączyć je z Twoją stroną Wordpress. (Więcej informacji na temat http://www.pl.formforall.com)

* <a href="http://www.ru.formforall.com" rel="nofollow">Русский</a>: Форма контактов, форма подписки, форма входа, форма регистрации, форма бронирования, форма опроса, электронный бюллетеньи так далее. Создавайте любые формы с помощью нашего генератора форм!
С помощью нашего подключаемого модуля Wordpress и нашего виджета вы можете легко вставлять ваши формы FormForAll в строку меню и интегрировать их в ваш сайт Wordpress. (Подробнее http://www.ru.formforall.com)

* <a href="http://www.pt.formforall.com" rel="nofollow">Português</a>: Formulário de contacto, formulário de Sign-up, formulário de Log-in, formulário de inscrição, formulário de reserva, formulário de sondagem, e-mail newsletter, etc. Faça qualquer tipo de formulário com o nosso gerador de formulários!Com FormForAll, os seus formulários Wordpress são criados em alguns segundos! Basta transferir e instalar o nosso Wordpress form plugin, e é tudo! (Ver mais http://www.pt.formforall.com )

* <a href="http://www.nl.formforall.com" rel="nofollow">Nederlands</a>: Contactformulier, registratieformulier, inlogformulier, inschrijvingsformulier, reserveringsformulier, enquêteformulier, inschrijving voor evenementen, e-mailnieuwsbrief… Met onze formbuilder creëert u op eenvoudige wijze elk type formulier!
Met onze Wordpress-plugin en onze widget kunt u gemakkelijk uw FormForAll-formulieren in uw menubalk invoegen en deze integreren in uw Wordpress-website. (Meer weten http://www.nl.formforall.com )

* <a href="http://www.tr.formforall.com" rel="nofollow">Türkçe</a>: Iletisim formu, Hesap olusturma formu, Oturum açma formu, kayit olma formu, rezervasyon formu, anket formu, e-bülten… Form üreticimizle her tür formu kolayca yapin !
Wordpress eklentimiz ve widgetimiz FormForAll formlarinizi kolayca menü çubugunuza yerlestirmenizi ve bunlari Wordpress sitenize entegre etmenizi saglar. (Daha fazla bilgi edinin http://www.tr.formforall.com )


<h4>FEATURES</h4>

* <a href="http://www.formforall.com/features" rel="nofollow">DRAG & DROP</a> interface.
* <a href="http://www.formforall.com/features#formfields" rel="nofollow">EXTENSIVE SELECTION OF FORM FIELDS</a>: predefined fields (log-in, sign-up, name, address, identity, credit card, date / time...), customized fields (text, radio buttons, check boxes).
* <a href="http://www.formforall.com/features#formfields" rel="nofollow">FILE UPLOAD</a>
* <a href="http://www.formforall.com/features#sociallogin" rel="nofollow">Connect with FACEBOOK and GOOGLE+</a>: insert our Connect with Facebook / Google+ social login field into your forms and have your web users fill in their info with their social network identity.
* <a href="http://www.formforall.com/features#optin" rel="nofollow">DOUBLE OPT-IN</a>: When your web users submit their form, an e-mail with a verification link is sent to their declared e-mail address. When the web user clicks on the link in the e-mail, we pass the information on to you.
* <a href="http://www.formforall.com/features#captcha" rel="nofollow">SSL, RSA key, Captcha.</a>
* <a href="http://www.formforall.com/features" rel="nofollow">Your logo, font, size, colors</a>: choose whatever you want, or create your own custom CSS.
* <a href="http://www.formforall.com/features#compatibility" rel="nofollow">RESPONSIVE DESIGN</a>: all forms you create are in responsive design (compatible with all Smartphones, tablets and PC''s).
* <a href="http://www.formforall.com/features#notifications" rel="nofollow">NOTIFICATION EMAILS</a>: we send you an e-mail as soon as a form has been submitted including all details.
* <a href="http://www.formforall.com/features#submissionconfirmation" rel="nofollow">CONFIRMATION EMAILS</a>: every time a form is submitted, we send a confirmation e-mail on your behalf to your web users.
* <a href="http://www.formforall.com/features#submissionconfirmation" rel="nofollow">FORM SUBMISSION MESSAGE or REDIRECTION</a>: a default message can be displayed to the user once the form is submitted, or the user can be redirected to the URL of your choice.
* <a href="http://www.formforall.com/tour#collect" rel="nofollow">DATA COLLECTION</a>You can export submitted data using our Export CSV or on a real time basis using our API.

<h4>37 LANGUAGES</h4>

Build your form in one of our 37 languages and have it displayed in all 37 languages: 

<p>* Arabic, Armenian, Bengali, Bulgarian, Catalan, Chinese (simple), Chinese (traditionnal), Czech, Danish, Dutch, English(us), English(uk), Estonian, Finnish, Flemish, French, Georgian, German, Greek, Hebrew, Hindi, Hungarian, Indonesian, Italian, Japanese, Korean, Lithuanian, Norwegian, Persian, Polish, Portuguese, Slovak, Spanish, Swedish, Russian, Turkish, Ukrainian.</p>
<p>* Looking for a 38th language ? <a href="http://www.formforall.com/contact" rel="nofollow">Tell us!</a></p>

<h4>PUBLISHING</h4>

* Our Form For All plugin and widget allows you to easily insert your FomForAll forms into your sidebar and to embed them into your Wordpress site wherever you want.
* If you want to include one of your form in an e-mail, we provide you with a hosted URL.
* Alternatively, we can also provide you with a JavaScript that you just have to copy / paste, which will embed your form on a HTML page of your site.

<h4>DATA COLLECTION</h4>
 
* <a href="http://www.formforall.com/features#submissionconfirmation" rel="nofollow">CONFIRMATION EMAILS</a>: every time a form is submitted, we send a confirmation e-mail on your behalf to your web users.
* <a href="http://www.formforall.com/tour#collect" rel="nofollow">DATA COLLECTION</a>You can export submitted data using our Export CSV or on a real time basis using our API. ( https://www.formforall.com/documentation#api ).
* Activity reports. 

== Installation ==

<a href="http://blog.formforall.com/how-to-install-formforalls-wordpress-contact-form-plugin/" rel="nofollow">Detailed explanations</a> / <a href="http://blog.formforall.com/comment-installer-le-plugin-formforall-pour-wordpress/" rel="nofollow">Mode d'emploi détaillé</a> / <a href="http://blog.formforall.com/como-instalar-el-plugin-formforall-para-wordpress/" rel="nofollow">Instrucciones de instalación</a>

* .1. Go to https://www.formforall.com to open a FormForAll account (we have a free plan / on all paid plans, the 1st month is free, and you have no further engagement.), and create your forms.
* .2. In the WordPress dashboard, click on Plugins and type FormForAll in the search box.
* .3. Once you have found our WordPress contact form FormForAll plugin, click on Install now.
* .4. A new window opens. Click on Install now.
* .5. Click on Activate Plugin. You should see our WordPress contact form Plugin on your Plugins'' list.
* .6. Look at your WordPress toolbar, our logo icon should have appeared at the right of the toolbar menu. Click on the icon.
* .7. If a new window opens with the message : “Parameters have not been set correctly”, go to next step, otherwise skip to step 12. Click on the message “Parameters have not been set correctly”.
* .8. To use our API, you need to enter 2 parameters. To get them, click on the link “To get an API key”.
* .9. You are now redirected to FormForAll online form builder site. Log-in to your account, go to MY ACCOUNT and then to USER API KEY.
* .10. On the USER API KEY window, you see the User ID and API key parameters that you have to copy on WordPress. Once copied on WordPress, click on “Save changes”.
* .11. A “settings saved” message should appear and confirm that your API parameters have been saved.
* .12.  Congratulations, you’re done! A new window opens. All forms you have created on your FormForAll online form builder account appear there. Just select one form and click on “Add a form” to insert it wherever you want on your WordPress site!


== Frequently Asked Questions ==
<h4>What do I need to do first ?</h4>
Open an account on https://www.formforall.com . It is free.

<h4>How do I add a form to my site ?</h4>
Once you have opened a FormForAll account and you have installed our plugin, you'll see our little FormForAll logo at the right end of your WordPress toolbar menu (if you don't see it, contact us!). If you click on it, all forms you have created on your FormForAll online form builder account appear there. Just select one form and click on “Add a form” to insert it wherever you want on your WordPress site!

<h4>How much will it cost me then ?</h4>
We have <a href="http://www.formforall.com/pricing" rel="nofollow">a free and premium monthly plans</a>. You can resign your monthly plans at any time. 
You have a 7 day satisfied or reimbursed guaranty.
And your first monthly payment is offered so that you can test us for free.

<h4>What is included in the free plan ?</h4>
With our free plan, you can create and publish as many forms as you want providing none of them include more than 5 fields and you remain below 100 submissions per month.

<h4>In your free plan, 5 fields isn't a lot!</h4>
The way we count our fields for our pricing is slightly different from others. For example:
<p>Name: Firstname and Lastname are counted as 1 field.</p>
<p>Adress:Street, city, zip code, state, country are counted as 1 field.</p>
<p>Login: ID and password are counted as 1 field.</p>
<p>Signup: ID and password are counted as 1 field.</p>
<p>and so on...</p>

<h4>Where can I find my FormForAll User API key ?</h4>
To get your FormForAll User API key, login to your FormForAll account
(https://www.formforall.com) then go to ‘My Account’ then to ‘User API key’.

<h4>How to have my form in different languages ?</h4>
When you have finished creating your form on your FormForAll account, you'll find in the SETTINGS menu our LANGUAGE submenu. There, Select our Multilingual Display option, and when a web user sees your form, labels will automatically be displayed in their own language based on the language defined in their browser or in the default language selected above if their language is not yet supported. Users can also manually change the language to suit their own preferences by selecting their prefered language from the list.

<h4>Need any assistance ?</h4>
Do not hesitate! We are here to help you! Contact us at: http://www.formforall.com/contact

== Screenshots ==

1. Control panel
2. Creating a form / step 1: give a name to your form and select the language in which you want to build it.
3. Creating a form / step 2: to start building your form, simply drag & drop the fields from the Form Builder Toolbar.
4. Each field has options that you can select by a quick click.
5. Our Social login field : Let your users connect with their Facebook or Google+ identity.
6. Settings: once your form is built, select the default language in which it will be displayed, and whether you want a multilingual display.
7. you may upload your logo at the top of your form.
8. you define your font, size and colors. Or your own CSS.
9. you may use SSL for your form (https:// ....)
10. You may include a Captcha at the bottom of your form.
11. One of our exclusive feature : double opt-in!
12. Notification e-mails, confirmation e-mails, submission message menu.
13. Publishing : link to share to be used in an e-mail newsletter.
14. With our partner Zapier, more than 260 applications to integrate your form with.
15. Our records API Key, to get all your submissions in real time.

== Changelog ==
<h4>Plugin translation - V1.2 - 06.02.2014</h4>
* The plugin is now translated in English, French, Spanish and Portuguese

<h4>09.06.2015</h4>
* compatibility 4.3

<h4>05.11.2015</h4>
* compatibility 4.2

<h4>04.09.2014</h4>
* compatibility 4.0

<h4>10.03.2014</h4>
* 1 new language (chinese traditionnal)

<h4>22.01.2014</h4>
* 15 new languages

<h4>V1.1 - 23.12.2013</h4>
* Wordpress 3.8 support

<h4>V1.0</h4>
* Initial release.
