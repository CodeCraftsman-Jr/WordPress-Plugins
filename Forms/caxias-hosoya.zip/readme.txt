=== Caxias Hosoya ===
Contributors: tkc49,gatespace,jim912
Tags: 
Requires at least: 1.0.1
Tested up to: 3.8.1
Stable tag: 3.8.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

これはただのプラグインではありません。伝説上のシンガー カシアス・ホソヤによって歌われた最も有名な WordPress のキーワードに要約される、同一世代のすべての人々の希望と情熱を象徴するものです。これは世界で最初で最後になるかわからない WordBench Kobe 公式プラグインです。このプラグインが有効にされると、プラグイン管理画面以外の管理パネルの右上に「君の瞳にダッシュボード」からの歌詞がランダムに表示されます。

== Description ==

これはただのプラグインではありません。伝説上のシンガー カシアス・ホソヤによって歌われた最も有名な WordPress のキーワードに要約される、同一世代のすべての人々の希望と情熱を象徴するものです。これは世界で最初で最後になるかわからない WordBench Kobe 公式プラグインです。このプラグインが有効にされると、プラグイン管理画面以外の管理パネルの右上に「君の瞳にダッシュボード」からの歌詞がランダムに表示されます。

= Special Thanks =
* gatespace
* jim912
* pictron
* hissy
* WordCamp Kobe2013 Member and WordPress Community friends.

= Usage =

[Read me.](https://github.com/tkc49/caxias-hosoya/blob/master/README.md)

== Installation ==

1. Upload the entire `caxias-hosoya` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

You will find an additional field while Edit categories.


== Frequently Asked Questions ==

You have no question because of simple plugin.

== Screenshots ==
1. It will be displayed here


== Changelog ==

= 1.0.1 =
Adding header image. * thank you pictron!

= 1.0.0 =
First release.


