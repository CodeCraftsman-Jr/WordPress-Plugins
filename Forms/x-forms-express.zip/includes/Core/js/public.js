// JavaScript Document
jQuery(document).ready(
function()
	{
	//##dynamic-data
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	////public script: tin_coating////
	jQuery('select[name="tin_coating_Id"] option[value='+jQuery('input[name="selected_tin_coating"]').val() +']').attr('selected',true);
	////END:public script: tin_coating////
	////public script: side_stripe_codes////
	jQuery('select[name="side_stripe_codes_Id"] option[value='+jQuery('input[name="selected_side_stripe_codes"]').val() +']').attr('selected',true);
	////END:public script: side_stripe_codes////
	////public script: internal_lacquer_codes////
	jQuery('select[name="internal_lacquer_codes_Id"] option[value='+jQuery('input[name="selected_internal_lacquer_codes"]').val() +']').attr('selected',true);
	////END:public script: internal_lacquer_codes////
	////public script: external_lacquer_codes////
	jQuery('select[name="external_lacquer_codes_Id"] option[value='+jQuery('input[name="selected_external_lacquer_codes"]').val() +']').attr('selected',true);
	////END:public script: external_lacquer_codes////
	////public script: dwi////
	jQuery('select[name="dwi_Id"] option[value='+jQuery('input[name="selected_dwi"]').val() +']').attr('selected',true);
	////END:public script: dwi////
	
	////public script: regions////
	jQuery('select[name="regions_Id"] option[value='+jQuery('input[name="selected_regions"]').val() +']').attr('selected',true);
	////END:public script: regions////
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	////public script: dynamic_forms////
	jQuery('select[name="dynamic_forms_Id"] option[value='+jQuery('input[name="selected_dynamic_forms"]').val() +']').attr('selected',true);
	////END:public script: dynamic_forms////
	////public script: shopping_basket////
	jQuery('select[name="shopping_basket_Id"] option[value='+jQuery('input[name="selected_shopping_basket"]').val() +']').attr('selected',true);
	////END:public script: shopping_basket////
	
	//END:##dynamic-data
	}
);
					