// JavaScript Document
jQuery(document).ready(
function()
	{
	//##dynamic-data
	//END:##dynamic-data
	}
);