=== Contact Form 7 Tiny MCE ===
Contributors: bastho, ecolosites
Donate link: http://eelv.fr/adherer/
Tags: cf7, contact form 7, tiny mce, editor, form
Requires at least: 3.1
Tested up to: 4.3
Stable tag: /trunk
License: GPLv2

Add tiny MCE to ContactForm7 editor

== Description ==
Add tiny MCE to ContactForm7 editor

== Installation ==
L
ike every plugins

== Frequently asked questions ==

= Which editor does it loads =
The plugins loads Teeny Tiny MCe editor (the pressthis one's)


== Screenshots ==

<img src="http://ecolosites.eelv.fr/files/2013/07/CF7MCE.png"/>


== Changelog ==

= 1.0.0 =
* WP 4.3 compliant
* Add editor in emails

= 1.0.0 =
* Compatible with version 4.2x of Contact form 7
* Separated JS file

= 0.1.4 =
* Fix : Hide footer editor in WP 4.1+

= 0.1.3 =
* Fix : TinyMCE 4*/WP 3.9+ friendly

= 0.1.2 =
* Fix : Hide textarea only if tinyMCE is loaded to prevent interactions

= 0.1.1 =
* Fix : Detect if tinymce.settings exists

= 0.1.0 =
* Plugin creation

== Upgrade notice ==

= 0.1.3 =
* Warning : Requires WP 3.9+
