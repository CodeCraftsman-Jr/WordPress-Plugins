Nivo Lightbox
=============

A simple, flexible, responsive, retina-ready jQuery lightbox plugin. See http://dev7studios.com/nivo-lightbox for more info.
