<?php

namespace OAuth\Common\Exception;

/**
 * Generic library-level exception.
 */
class Exception extends \Exception
{
}
