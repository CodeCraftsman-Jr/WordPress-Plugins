<?php 
/*
$USERNAME = 'username@sample.com';
$PASSWORD = 'changeme';
*/

$USERNAME = 'dfclab1@salesforce.com';
$PASSWORD = 'sforce123';

?>