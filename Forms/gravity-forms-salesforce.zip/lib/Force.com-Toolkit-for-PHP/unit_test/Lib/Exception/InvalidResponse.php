<?php
class Lib_Exception_InvalidResponse extends Exception {}