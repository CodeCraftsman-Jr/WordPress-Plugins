=== SRS_Form ===
Contributors: Samonta Roy, Sadiatun Nur Hafsa
Requires at least: 3.0.1
Tested up to: 3.9
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is another simple contact form. It is flexible and ease of use. For more info please check readme file. 

== Description ==

SRS_Form is a clean and simple contact form for wordpress.

It contains Name,Email,Password,City,ContactNo and message.

Use shortcode [SRS_FORM] to display form on page.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use shortcode in page, post or in widgets.

Shortcodes

[SRS_FORM]


== Frequently Asked Questions ==

= How do I install this plugin? =

You can install as others regular wordpress plugin. No different way. Please see on installation tab.



== Screenshots ==

No screenshots needed, just follow the installation instruction.

== Upgrade Notice ==


No upgrade yet. This is version: 1.0


== Changelog ==

= 1.0 =
* Initial Release