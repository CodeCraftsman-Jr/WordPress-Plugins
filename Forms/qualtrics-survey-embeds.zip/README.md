Qualtrics Survey Embeds
=

A WordPress plugin that adds a Qualtrics Embed Handler to WordPress allowing for quick survey embeds.

## Contributing

Contributions are welcome. Open up an issue and describe what you'd like to add.

## Licensing

This repository is licensed under the [MIT](LICENSE).