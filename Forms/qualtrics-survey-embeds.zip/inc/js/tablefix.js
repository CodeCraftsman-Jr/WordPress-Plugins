jQuery(function ($) { 
	$('#qse_settings_default_pxorpercent').insertAfter('#qse_settings_default_width'); 
});