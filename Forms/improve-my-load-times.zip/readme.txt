=== Plugin Name ===
Contributors: Podz	
Donate link: 
Tags: plugin, plugins, admin, compression, gzip, page, post, blog
Requires at least: 2.0.2
Tested up to: 3.3.0
Version: 1.5

This plugin allows you to compress your webpages to save bandwidth and make your blog load faster!

== Description ==

This plugin allows you to compress your webpages to save bandwidth and make your blog load faster!

As soon as you enable the plugin, compression will be automatically enabled and your blog will load much, much quicker! You should also save between 50% - 80% bandwidth too, just by using this plugin!

== Installation ==

1. Upload the plugin file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Frequently Asked Questions ==

= Does this work? =

Yes.

== Changelog ==

= 1.0.3 =
* Admin option labels changed
* Tested on latest beta of Wordpress

= 1.0.1 =
* Made file more lightweight by removing unneeded functions
* Added a description to the admin panel to clear up a problem mentioned
* This plugin works on the latest version of Wordpress

= 1.0.0 =
* First Release
