<?php
namespace Amoforms\Exceptions;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Access
 * @since 1.0.0
 * @package Amoforms\Exceptions
 */
class Access extends Base {}
