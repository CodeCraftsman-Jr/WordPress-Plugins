<?php
namespace Amoforms\Exceptions;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Argument
 * @since 1.0.0
 * @package Amoforms\Exceptions
 */
class Argument extends Base {}
