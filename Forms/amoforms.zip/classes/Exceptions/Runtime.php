<?php
namespace Amoforms\Exceptions;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Runtime
 * @since 1.0.0
 * @package Amoforms\Exceptions
 */
class Runtime extends Base {}
