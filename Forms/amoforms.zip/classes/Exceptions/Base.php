<?php
namespace Amoforms\Exceptions;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Base class for all Amoforms exceptions
 * @since 1.0.0
 * @package Amoforms\Exceptions
 */
abstract class Base extends \Exception {}
