<?php
namespace Amoforms\Controllers\Exceptions;

use Amoforms\Exceptions\Base;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Controller
 * @since 1.0.0
 * @package Amoforms\Controllers\Exceptions
 */
class Controller extends Base {}
