<?php
namespace Amoforms\Libs\Shortcodes\Exceptions;

use Amoforms\Exceptions\Runtime;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Manager_Runtime
 * @since 1.0.0
 * @package Amoforms\Libs\Shortcodes\Exceptions
 */
class Manager_Runtime extends Runtime {}
