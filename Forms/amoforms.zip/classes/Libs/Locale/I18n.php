<?php
namespace Amoforms\Libs\Locale;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class I18n
 * @since 1.0.0
 * @package Amoforms\Libs\Locale
 */
class I18n implements Interfaces\I18n
{
	public static function get($string)
	{
		//TODO: get localized string
		return $string;
	}
}
