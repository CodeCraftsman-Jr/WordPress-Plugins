<?php
namespace Amoforms\Views;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Settings
 * @since 1.0.0
 * @package Amoforms\Views
 */
class Settings extends Base {}
