<?php
namespace Amoforms\Views;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Form
 * @since 1.0.0
 * @package Amoforms\Views
 */
class Form extends Base {}
