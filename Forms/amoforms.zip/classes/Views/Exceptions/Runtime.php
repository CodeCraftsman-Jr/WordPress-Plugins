<?php
namespace Amoforms\Views\Exceptions;

defined('AMOFORMS_BOOTSTRAP') or die('Direct access denied');

/**
 * Class Views
 * @since 1.0.0
 * @package Amoforms\Views\Exceptions
 */
class Runtime extends \Amoforms\Exceptions\Runtime {}
