=== Aweber Subscriber Form ===
Contributors: freewebmentor
Tags: api, aweber, email, email marketing, form, mailing list, marketing, newsletter, web, webform
Requires at least: 3.5.1
Tested up to: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows you to add a aweber Email Subscription form widget on your sidebars of wordpress websites and blogs.

== Description ==

This plugin allows you to add a aweber Email Subscription form widget on your sidebars of wordpress websites and blogs.


== Installation ==

1. Unzip folder to the `/wp-content/plugins/` directory
2. Log into your Wordpress admin and activate the 'Aweber Subscriber Form' plugin through the 'Plugins' menu
3. Once the plugin is installed and enabled you can find it in your widgets.
4. Create your Aweber YOUR-UNIQUE-LIST-ID  from <a href="http://www.aweber.com/" target="_blank">Aweber</a>


== Frequently Asked Questions ==



== Screenshots ==



== Changelog ==


== Upgrade Notice ==
