﻿<?php
// If uninstall not called from WordPress exit
delete_option('loading_page_options');
?>