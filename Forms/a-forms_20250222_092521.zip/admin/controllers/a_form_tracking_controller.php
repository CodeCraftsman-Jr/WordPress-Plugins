<?php
final class AdminAFormTrackingController {
	public static function indexAction() {
		AdminAFormTrackingPage::indexPage();
	}

	public static function showAction() {
		AdminAFormTrackingPage::showPage();
	}

	public static function searchAction() {
		AdminAFormTrackingPage::showPage();
	}

	public static function viewAction() {
		 AdminAFormTrackingPage::viewPage();
	}
}
?>