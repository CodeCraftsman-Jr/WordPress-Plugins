<?php
final class AdminAFormSettingsController {
	public static function indexAction() {
		AdminAFormSettingsPage::indexPage();
	}
}
?>