=== Simplest Contact Form ===
Contributors: utkarsh.shinde
Tags: simplest-contact-form,comments, spam
Requires at least: 3.0.1
Tested up to:  4.1.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Features:
 * Simple Contact Form easy to Use.
 * Use Shortcode on any page and Post
 *Use Simplest Contact Form Widget 

== Installation ==

1. Extract `simplest-contact-form.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place [simplest_contact_form] at any Page and Post
4. Add Widget from Appearance>Widgets in Any Sidebar

== Changelog ==

= 1.0 =
* First version.
= 1.1 =
* Widgetized the plugin.Add Widget.
= 1.2 =
* Updated verified fields messages
