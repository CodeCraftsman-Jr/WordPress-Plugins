=== Forms actions ===
Contributors: gdurtan
Tags: Send email, quesionarie, ACF, Advanced Custom Field, Frontend
Requires at least: 3.1
Tested up to: 4.0
Stable tag: 1.2.2
License: GPLv2 or later

Forms actions - plugin to realize form actions like send email, create post, pool requests. Now work only with ACF forms (in feauture with Ninja Forms, Gravity Forms, Contact Form 7)

== Description ==

Forms actions - plugin to realize form actions like send email, create post, pool requests

Major features in Forms actions include:

* Send email, target questions, clear form

== Frequently Asked Questions ==

No questions yet.

== Installation ==

Upload the Forms actions plugin to your blog, Activate it.

1, 2, 3: You're done!

== Changelog ==
= 1.2.2 =
* Ajax methods

= 1.1.2 =
* Register DB tables

= 1.1.0 =
* Better display
* New action - Create post
* New action - Update post
* New action - Register user
* New action - Update user
* New action - Login user
* Add 2signon autentication 
* Add new ajax alpaca api methods

= 1.0.3 =
* Better email template
* Email Messages was better ordering
* New action - dont display after send
* New action - create post

= 1.0.0 =
* Send email
* Target questions to best responce
* Clear form after send

== Screenshots ==

1. Activate Forms actions
