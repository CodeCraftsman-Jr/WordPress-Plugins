WooCommerce Stacked Add-to-Cart Product Forms
======================

A handy plugin for stacking the add-to-cart section of complex WooCommerce product types under the main image and summary. Useful if the add-to-cart section of your products appears very narrow or squeezed.
