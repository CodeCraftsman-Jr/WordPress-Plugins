<?php

require_once( dirname( __FILE__ ) . '/admin/ajax-backlink.php' );

require_once( dirname( __FILE__ ) . '/admin/ajax-delete-element.php' );

require_once( dirname( __FILE__ ) . '/admin/ajax-insert-element.php' );

require_once( dirname( __FILE__ ) . '/admin/ajax-load-element-details.php' );

require_once( dirname( __FILE__ ) . '/admin/ajax-load-elements.php' );

require_once( dirname( __FILE__ ) . '/admin/ajax-update-element.php' );

?>