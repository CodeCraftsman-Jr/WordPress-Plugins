=== Plugin Name ===
Contributors: (rkpolin)
Tags: preloader, preload Animation, google inbox style preload
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

RKP Preloader is a google inbox style preloader.

== Description ==
RKP Preloader is a google inbox style preloader. You can integrate it easy without any coding knowledge. 

Features:
1. Fully responsive. Scales with its container.
2. Nice color setting options
3. You can set to your page top or bottom.
4. You can set animation speed.
5. You can set animation bar width.

You can see demo here <a href="http://facebond.com/plugins/rkp-awesome-preloader/" target="_blank">RKP Awesome Preloader DEMO</a>

If you like this plugin please leave your ratings.

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Do I need any programming knowledge? =

No. 


== Screenshots ==

1. /assets/screenshot-1.jpg
2. /assets/screenshot-2.jpg
3. /assets/screenshot-3.jpg


== Changelog ==

= 1.0 =
* Initial release

* List versions from most recent at top to oldest at bottom.

== A brief Markdown Example ==

Ordered list:


