=== Change Author Link Structure ===
Contributors: wpyb
Tags: author, permalink, username, id, url
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 0.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

To prevent that usernames are publically visible, the username in the author's permalink is replaced with the author's ID.  

== Description ==

To prevent that usernames are publically visible, the username in the author's permalink is replaced with the author's ID.  
In case the page is invoked with the default permalink structure, it is displayed "Page not found".

== Installation ==

1. Upload `change-author-link-structure.zip` to the `/wp-content/plugins/` directory
2. Unzip `change-author-link-structure.zip`.
3. Activate the plugin in the admin menu 'Plugins'.

== Changelog ==

= 0.1 =
First release
= 0.1.1 =
Readme Update
