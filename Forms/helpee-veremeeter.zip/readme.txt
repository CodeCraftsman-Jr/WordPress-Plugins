=== Plugin Name ===
Contributors: kaups, 
Donate link: http://help.ee/
Tags: veremeeter, widget, eesti, estonia, doonorid, verekeskus, help.ee, blood donation
Requires at least: 3.0
Tested up to: 3.0.4
Stable tag: 1.3

Help.ee Veremeeter on WP vidin, mis näitab www.verekeskus.ee vereseisu. Kui olukord on kehv, läheb vidin punaseks.

== Description ==

Help.ee Veremeeter on WP vidin, mis näitab www.verekeskus.ee vereseisu. Kui olukord on kehv, läheb vidin punaseks.

* Andmeid uuendatakse iga tunni tagant
* Serverile antakse tagasi natuke statistikat, kui palju sinu leht Veremeetrit näitas
* Veremeeter oskab näidata ka viimaseid help.ee heategevusprojekte (seadistatav on-off ja arv)
* Veremeetri infoleht: http://www.help.ee/veremeeter

== Installation ==

1. Kliki Install nupule.
2. Aktiveeri (Activate) plugin peale installeerimist.
3. Mine adminmenüüs valikule "Välimus/Moodulid" ("Appearance/Widgets")
4. Leia üles "Help.ee Veremeeter" ja lohista see hiirega paremale mõnele Widgeti-alale.
5. Seadista soovide kohaselt.

This section describes how to install the plugin and get it working.

== Frequently Asked Questions ==

= Kas on küsimusi? =

Lisame, kui küsimusi tekib


== Screenshots ==

veremeeter.png

== Changelog ==

= 1.0 =
* 31.01.2011 - Lanseerime esimese versiooni


== Upgrade Notice ==

= 1.0 =
Hetkel veel uuendusi pole.

= 1.3 =
file_get_contents hoiatuse vaigistamine
