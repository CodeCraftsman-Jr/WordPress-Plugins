
=== Plugin Name ===

Contributors: ah125i
Tags: 
social bookmarking, seo, digg, delicious, buzz, stumble upon, sharing, saving,

Requires at least: 2.6

Tested up to: 2.6

Stable tag: trunk


Adds links for submitting to Digg, Delicious, Buzz, and Stumble to pages and posts.

 Great for SEO or building traffic.

== Description ==



This plugin is for adding submission links for Digg, Delicious, Buzz, and Stumble to pages and posts.  
This plugin is useful for building traffic to your website and also for Search Engine Optimization (SEO). 
It allows you to choose between six options of pages/posts to add to. They are: 

1. Home page (if it is a page)

2. Posts page (default home page)

3. All Pages

4. Posts on archive pages

5. Single page posts

6. Other types of pages



== Installation ==


1. Upload `simple-submit` directory to the `/wp-content/plugins/` directory

2. Activate the plugin through the 'Plugins' menu in WordPress

3. Configure from the settings pane



== Frequently Asked Questions 

==



== Screenshots ==

 
1. screenshot.png