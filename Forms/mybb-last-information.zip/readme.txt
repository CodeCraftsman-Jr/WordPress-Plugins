=== Plugin Name ===
Contributors: pctricks.ir
Donate link: http://donate.shiraali.com/
Tags: mybb, mybb info,mybb last post,mybb last user
Requires at least: 3.0.1
Tested up to: 3.6.5
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show Mybb Last Information Like lastPosts,Lastuser,Most viewed topic And .... .
== Description ==
 * ADD Widget
 * Show Last Posts
 * Show Last Users
 * Show Most Viewed Threads
 * Show Hot Threads
 * Show Top Posters
 * Show Users By Top Reputation
 * Show Top File Downloaded
 * Show Top Reffer
 * Show Forum Statistics
 * Last Posts Title Character Option
 * File Title Character Option
 * Nubmber Items Option
 * disable/enable Sections Option
 
 <a href="http://pctricks.ir/">Live Demo</a>

== Installation ==

1. Upload plugin From wordpress admin and Active it.
2. Go to Setting >> mybbinfo and Set options
3. Go to widget and Drag&Drop Mybb Information widget in You theme Position.

== Frequently Asked Questions ==


== Screenshots ==

1. options.png
2. site_index.png
3. widget.png

== Changelog ==

= 1.0 =
 * ADD Widget
 * Show Last Posts
 * Show Last Users
 * Show Most Viewed Threads
 * Show Hot Threads
 * Show Top Posters
 * Show Users By Top Reputation
 * Show Top File Downloaded
 * add Widget Mybb information
 * Nubmber Items Option
 * disable/enable Sections Option
 = 1.5 =
 * Show Top Reffer
 * Show Forum Statistics
 * Last Posts Title Character Option
 * File Title Character Option
 = 1.5.1 =
 * Fix small problem
