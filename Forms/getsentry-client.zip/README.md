wordpress-sentry
================

A WordPress plugin to handle reporting php error to the [Sentry error reporting system](https://getsentry.com/welcome/).
