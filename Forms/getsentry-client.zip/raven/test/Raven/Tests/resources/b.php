<?php
// filename: /tmp/b.php
include_once '/tmp/a.php';
