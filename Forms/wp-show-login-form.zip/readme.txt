=== wordpress login form to anywhere ===
Contributors: ajay3085006
Donate link: https://ajaysharma3085006.wordpress.com/
Tags: login form, frontend login form, wordpress login form, show login form, form
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

shows wordpress login form to anywhere in widget , page  or post, have shortcode [wplfta_login_form]
== Description ==
shows wordpress login form to anywhere in widget , page  or post, have shortcode [wplfta_login_form],
also can set custom label for fields from wordpress admin


<h3>To add login  to your website </h3>

<h3> Method 1</h3>or use short code <code>[wplfta_login_form]</code> to your page or post or text widget 
<h3> Method 2</h3>to use in theme use <code>&lt;?php echo do_shortcode('[wplfta_login_form]'); ?&gt;</code> to your template 
	


== Installation ==

The plugin can be use just by installing it by wordpress admin or upload manually. 

1. Upload `wp-login-form-to-anywhere` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Now go to (login form) tab at wp-admin

== Frequently Asked Questions == 
= How to use plugin on page or posts ? =
use [wplfta_login_form] shortcode in page, post or widget.

For more visit blog [wplfta_login_form](https://ajaysharma3085006.wordpress.com/ "wplfta_login_form")


== Screenshots ==

1. User view after installation

2. Admin setting page

== Changelog ==
= 0.1 =
Login form to anywhere


== Upgrade Notice ==

= 0.2 =
add validation options