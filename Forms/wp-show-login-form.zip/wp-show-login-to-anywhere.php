<?php
    /*
  Plugin Name: wordpress login form to anywhere
  Plugin URI: http://ajaysharma3085006.wordpress.com/
  Description: shows wordpress login form to anywhere in widget , page  or post, have shortcode [wplfta_login_form]
  Version: 0.1
  Author: Ajay Sharma
  Author URI: http://ajaysharma3085006.wordpress.com/
  License: GPLv2 or later
 */
 
 
 require_once('inc/functions.php');
 require_once('inc/class.php');
 require_once('admin/options.php');