=== OkConfirm ===
Contributors: okconfirm
Donate link: http://okconfirm.com/
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin provides a simple way to embed OkConfirm.com widgets on WordPress sites.

== Description ==

This plugin adds a shortcode named [okconfirm] that can be used to quickly embed OkConfirm.com widgets in your pages/posts.

i.e. [okconfirm widget="checkout" id="EVENT UUID GOES HERE"]

== Frequently Asked Questions ==

Nothing to see here.

== Screenshots ==

Nothing to see here.

== Installation ==

1. Upload `okconfirm` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =
* Provides shortcode for embedding the checkout button.

== Upgrade Notice ==

Nothing to see here.
