=== Gravity Forms To Excel AddOn (sample/readme.txt) ===
Contributors: 
Tags: gravityforms, excel, excel export, forms, attachment, email, notification, no CSV
Donate link: 
Requires at least: 3.7
Tested up to: 4.2.2
Stable tag: 0.1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



1. Import gift-certificate.json into Gravity Forms
2. Upload gift-certificate.xlsx on the form settings page in the tab "GF2Excel" and update the settings
3. Create a page or post and include the form shortcode.
4. Submit the form and see the attached Excel file