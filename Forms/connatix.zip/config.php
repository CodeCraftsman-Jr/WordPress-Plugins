<?php
define('CONNATIX_PLUGIN_URL', plugin_dir_url( __FILE__ ));


