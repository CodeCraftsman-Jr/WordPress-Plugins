=== Benchmark by Duo Leaf ===
Contributors: DuoLeaf
Tags: benchmark, performance, loading
Requires at least: 3.0.0
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv3

This plugin records how long it takes to load each page in your client's browser. That way you can identify which pages need improvements in terms of performance.

== Description ==

This plugin records how long it takes to load each page in your client's browser. That way you can identify which pages need improvements in terms of performance.

Features

* Record up to 100 visits

Coming soon

* Take snapshots
* Filter which urls should be recorded
* Charts (lots of them)


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload plugin to `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Screenshots ==

1. Example of records

== Changelog ==

= 1.0.1 =
* Improved the admin area.
* Bug fixes.

= 1.0.0 =
* Initial version.
