<?php

class dl_b_Stats {

    /**
     * Properties
     */
    public $id = 0;
    public $url = '';
    public $start = '';
    public $end = '';

    
}

