<div class="update-nag">
	<?php _e( 'Install or activate WooCommerce to start using Belco.', 'wp_belco' ); ?> <a href="<?php echo admin_url('plugins.php');?>">Activate now</a>.
</div>