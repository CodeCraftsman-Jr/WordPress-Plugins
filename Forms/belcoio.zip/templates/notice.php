<div class="update-nag belco-install-notice">
	<?php _e( 'Connect your Belco account to start receiving calls.', 'wp_belco' ); ?> <a href="<?php echo admin_url('admin.php?page=belco');?>">Connect now</a>.
</div>