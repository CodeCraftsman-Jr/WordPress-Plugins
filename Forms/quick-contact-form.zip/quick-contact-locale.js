jQuery('.qcfdate').datepicker({
    monthNames: objectL10n.monthNames,
    monthNamesShort: objectL10n.monthNamesShort,
    dayNames: objectL10n.dayNames,
    dayNamesShort: objectL10n.dayNamesShort,
    dayNamesMin: objectL10n.dayNamesMin,
    dateFormat: objectL10n.dateFormat,
});