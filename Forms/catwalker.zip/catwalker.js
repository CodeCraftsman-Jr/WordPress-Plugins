jQuery(document).ready(function($) {
		// $() will work as an alias for jQuery() inside this function

//		$('form.crosscat-form').submit(function(){
//			var dd1 = $(this).siblings('#crosscat-dd1');
//			var dd2 = $(this).siblings('#crosscat-dd2');
//			var dd1Cat = dd1.find(':selected').val();
//			var dd2Cat = dd2.find(':selected').val();
//			var ccQuery = $(this).find('[name="cat"]');
//			ccQuery.val(dd1Cat + "-" + dd2Cat);
//			});
//		
//		}); //end of jQuery
