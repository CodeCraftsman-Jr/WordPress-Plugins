=== Beauty Contact Popup Form ===
Contributors: Dilip kumar, Tagwebs Technologies
Donate link: http://www.uholder.com/
Author URI: http://www.uholder.com/
Plugin URI: http://www.uholder.com/
Tags: popup-contact-form,beautiful-popup-contact-form,beauty-contact-form,popup-contact,popup-form,contact-form,email-form,popup,popup-contact-form, contact,contact-us,contact-easy,email-us,email,popup,popup-contact-us,form,
Requires at least: 2.9.2
Tested up to: 4.1
Stable tag: 6.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


This Contact Popup form plugin display popup form by clicking button or text link in the front end of the website with beautiful and attractive design.

== Description ==

It is an simple and Beautiful contact popup form, with simple backend options. All you need is just to activate the plugin and insert the shortcode  [show_tagwebs_beauty_contact_popup_form id="1"] into the text. This is the plugin for contacting the admin of website which allow users to send email. This plugin built with mobile responsive. Beauty contact popup form looks beautiful in popup which attract your users

Advantage of this Plugin

* Beautiful and Attractive Design.
* Simple admin options.
* Ajax submission.
* Widget drag and drop option.
* Mobile responsive.
* Shortcode option.


Check official website [http://www.uholder.com//](http://www.uholder.com//)

* [Live Demo](http://demo.uholder.com/plugin/beauty-contact-popup-form/)
For Live Demo Click the link


== Installation ==

* Extract the zip file and just drop the contents in the wp-content/plugins/ directory.
* Activate the Plugin from Plugins page.
* Provide contact email id and other information in the admin page under the menu "B popup form" then save the settings.
* Use the short-code [show_tagwebs_beauty_contact_popup_form id="1"] or Drag and drop the widget into the widget area for displaying Beauty contact popup form.


== Frequently Asked Questions ==

For Plugin support please post your questions [Support Form](http://demo.uholder.com/plugin/beauty-contact-popup-form/ "Support Form")

Do you have questions or issues about beauty-contact-form? [Contact Me](tagwebs@live.com)

[Contact](http://www.uholder.com/contact-us/ "Contact")


== Screenshots ==

1. Contact Popup form display in page
2. Contact Popup form display with validation
3. Contact Popup admin panel option

== Changelog ==

= version 6.0 =
* Mobile and responsive style issue fixed


= version 5.0 =
* Popup form fixed to centre position 
* Improved theme compatibility


= version 4.0 =
* Fixed text color issue in text box and text area
* Improved theme compatibility


= version 3.0 =
* Field Background issue fixed.
* One click Support / help added in admin area .


= version 2.0 =
* Bugs Fixed.
* Theme compatibility improved.


= version 1.0 =
First version. Implemented with basic functionalities Ability to send email through popup form.



== Upgrade Notice ==
You should upgrade the plugin to fix theme compatibility issue.


== CREDIT ==

1.This plugin was developed by [Dilip kumar]


== CONTACT ==

Dilip kumar [tagwebs.net/contact-us]

