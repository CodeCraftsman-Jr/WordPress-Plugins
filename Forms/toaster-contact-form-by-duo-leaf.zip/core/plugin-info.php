<?php

class dl_tcf_PluginInfo {

    /**
     * Properties
     */
    public $name;
    public $displayName;

    /**
     * Constructor
     */
    public function __construct() {

        $this->name = "toaster-contact-form-by-duo-leaf";
        $this->displayName = "Toaster Contact Form by Duo Leaf";
    }

}
