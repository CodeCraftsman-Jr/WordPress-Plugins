=== Toaster Contact Form by Duo Leaf ===
Contributors: DuoLeaf
Tags: contact form, tray, popup, toaster, wigdet area, wigdet, tray, tray area, form
Requires at least: 3.0.0
Tested up to: 4.2.3
Stable tag: trunk
License: GPLv3

This plugin creates contact form on the bottom right corner of your site, with a 'toaster' like effect.

== Description ==

This plugin creates contact simple form on the bottom right corner of your site, with a 'toaster' like effect. The form contains name, email and message.

= Features =

* Fully translatable
* Receive contacts through email

= Coming soon features =

* Choose animation
* Choose colors
* Specify individual URLs
* Open on user leaving the page


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload plugin to `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Screenshots ==

1. Toaster Contact Form Opened
2. Toaster Contact Form Full Page
3. Toaster Contact Form Closed
4. Toaster Contact Form Settings

== Changelog ==

= 1.0.3 =
* Added open and close icons to the form

= 1.0.2 =
* Bug Fix

= 1.0.1 =
* Improved the admin area.

= 1.0.0 =
* Initial version.
