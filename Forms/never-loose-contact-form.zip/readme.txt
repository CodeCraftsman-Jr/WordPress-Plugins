=== Never Loose Contact Form ===
Contributors: andymoyle
Donate link: 
Tags: contact form, anti-spam, email, database
Requires at least: 3.3
Tested up to: 4.2
Stable tag: 0.41
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Spam proof contact form  that emails you the message and saves it in database.

== Description ==

Never Loose Contact form provides a spam proof contact form for your Wordpress site that emails you the message and saves it for viewing in the admin area.
If you wish you can enter your contact details in the public settings for display above the contact form
Emails are sent to your installation admin email address.

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Use the shortcode [contact_form] where you want the form
2. Use the widget if you want the form in a sidebar

== Frequently asked questions ==



== Screenshots ==

1. List of messages
2. Look at the complete message in the admin area

== Changelog ==
* 0.1 Initial Release
* 0.2 Spam proofing without Akismet
* 0.21 Clearer settings form (you don't have to display your contact details publicly)
* 0.3 Added Internationalisation
* 0.31 Only show admin bar menu to administrators
* 0.32 More efficient on db calls on initialise
* 0.33 Fixed activation error
* 0.34 Fixed thickbox
* 0.40 HTML5 validation, hitting reply in email client replies to message sender
== Upgrade notice ==





