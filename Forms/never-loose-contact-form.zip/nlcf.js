
 jQuery(document).ready(function($) {

    var content='<p>Check box if you are not a spammer <input type="checkbox" name="nlcf" value="yes"/></p>';
    $(".never-loose-contact-form").html(content);
});


