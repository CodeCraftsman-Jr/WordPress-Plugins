=== Form Styler for Ninja Forms ===
Contributors: aman086
Donate link: http://webholics.in
Requires at least: 3.5
Tags: ninja forms, forms, field,layout,styler,builder,form-builder
Tested up to: 4.2
Stable tag: 1.0.1
License: GPLv2 or later

Style your Ninja Forms from backend

== Description ==
Form Styler for Ninja Forms lets you build and style your Ninja Forms using drag and drop builder.

Features:

* Supports 2 coloum layout
* Option to set form width
* Option to set form height
* Option to set form border
* Option to set form padding
* Option to set form margin
* Option to set form background color
* Option to set field border
* Option to set field padding
* Option to set field margin
* Option to set field background color
* Option Style Label text
* Option to Style Fields
* Style Form Container.


Check out the <a href="http://www.webholics.in/form-styler-for-ninja-forms/?utm_source=wporgplugin&utm_medium=wporg&utm_campaign=nfstyler" >demo form </a> styled using this plugin

== Installation ==
* Upload the plugin to wp-content->plugins directory,
* Activate it from wordpress dashboard
* Edit Form and you will see Form Styler Tab

== Screenshots ==
1. Form Styler Admin Settings

== Changelog ==
= 1.0 (2nd Aug 2015)=
-Bugs:
* Fixed warning message on setting page.


= 1.0 =
Intial Release