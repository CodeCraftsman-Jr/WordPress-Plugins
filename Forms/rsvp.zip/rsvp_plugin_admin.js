jQuery(document).ready(function(){
  jQuery("#associatedAttendeesSelect").multiSelect(); 
  jQuery("#attendeesQuestionSelect").multiSelect();
});