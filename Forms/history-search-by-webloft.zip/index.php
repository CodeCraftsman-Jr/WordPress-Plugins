<?php // Silence is golden

?>
<img src="http://www.nb.no/services/image/resolver?url_ver=geneza&urn=URN:NBN:no-nb_digibok_2009041700058_C1&maxLevel=5&level=1&col=0&row=0&resX=9000&resY=9000&tileWidth=1024&tileHeight=1024">
