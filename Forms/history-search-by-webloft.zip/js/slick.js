jQuery(document).ready(function(){
  jQuery('.kulturslick').slick({
	dots: false,
	infinite: true,
	speed: 300,
	fade: true,
	cssEase: 'linear'
  });
});
