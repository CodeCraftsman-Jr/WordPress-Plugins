# Donately Wordpress Plugin

**Installation**

* Create a 'dntly' folder in your wp-content/plugins directory.
* Clone (or download and extract zip) this repository into the 'dntly' folder.
* Activate it from the Admin and get a token using your email & password from Donately.

**Usage**

* Drop the donation form widget into any page or post sidebar.
* Using the shortcode [dntly_formjs], drop a donation form into any page or post.
* Sync your Campaigns using the 'Sync Campaigns' button on the settings page.
