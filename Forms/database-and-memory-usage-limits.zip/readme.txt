=== Database and Memory Usage Limits by WPFIXIT ===
Contributors: WPFIXIT
Tags: memoray usage, database usage, memory limit, wordpress errors, bump, dashboard, footer, limit, lite, load, memory, overview, show, usage, wp
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv3

This Plugin Show Total Database and Memory Usage with Memory Limits in Admin Dashboard Footer and Admin Dashboard Page
== Description ==
It Shows Total Memory Usage on WordPress Dashboard, and it also shows the Memory Load currently used by WordPress on Footer Admin Control Panel with very less load consumption. It is Compatible with Shared VPS and Dedicated Hosting. 

<p>New Feature added to instantly report any issue with your website</p>
<h2>Following Issues</h2>
<li>Theme Bugs</li>
<li>Plugin Bugs</li>
<li>WordPress Errors</li>
<li>Slow Page Speed</li>
<li>Extra Resource Usage</li>
<li>Database Errors</li>

== Installation ==
<p>Manual</p>
1. Upload the `database-and-memory-usage-limits` folder to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.

<p>Automatic</p>
1. Goto Dasboard Plugin click 'Add New' search for 'Database and Memory Usage Limits by WPFIXIT' .
2. Click Install.
3. Activate Plugin.


== Changelog ==

= 1.0 =

= 1.2 =
* Bug Fixed
* Dashboard Resource Usage
* User Instantly Report Issues

= 1.2.1 =
* Contact Form Fixed


= 1.5 =
* Many Bug Fixed
* Code Simplified