=== Aweber Form Creator ===
Contributors: jeffbullins
Donate link: http://www.thinklandingpages.com
Tags:   contact form, contact form 7, form, aweber, mailinglist, multisite, newsletter, optin, registration form, shortcode, sign-up form, subscribe, opt-in, mailing list, email form, email marketing, forms, subscribe form, subscription, email, marketing, signup, Aweber form, Aweber plugin, aweber signup form, aweber signup widget, aweber widget, aweber wordpress
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An easy way to place a Aweber form on your Wordpress site.

== Description ==

An easy way to place a Aweber form on your Wordpress site.

###Quick Start Guide

* [Aweber form quick start guide at thinklandingpages.com](http://www.thinklandingpages.com/aweber-form-creator/)

###What you get when you use the Aweber Form Creator plugin

*  Place a Aweber form with a simple shortcode [aweber_form_creator id="%postId%"]
*  Put Aweber form on any post or page.
*  Aweber form headline
*  Aweber form background color
*  Aweber form name field
*  Aweber form email field
*  Aweber form message
*  Aweber form button
*  Aweber form list name
*  Unlimited Aweber forms

###Add Aweber forms to any post or page

Whether you are writing a post about your company or another company, you can include a well formatted Aweber form.

You should spread Aweber forms throughout your site to maximize the number of subscribers.

###Unlimited Aweber forms

Add as many Aweber forms to your site as you like.  The Aweber Form Creator plugin lets you create Aweber forms and save them for when ever you are ready to use them.

###Aweber form headline
Use the aweber form headline to capture your audience's attention.

###Quick Start Guide

* [Aweber form quick start guide at thinklandingpages.com](http://www.thinklandingpages.com/aweber-form-creator/)

== Installation ==


1. Upload `aweber-form-creator` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Click **Aweber Form Creator** on the admin menu to enable and set your options.


== Frequently Asked Questions ==

= Do I have to know how to program or design? =

No.  The plugin does the programming and design.

= Is there a limit to the number of Aweber forms I can create? =
You can create an unlimited number of Aweber forms.

= Can the Aweber forms be put on my homepage? =
Yes, you can put Aweber forms on your homepage by using the Aweber Form Creator plugin shortcode on you homepage.

= Can I put Aweber forms on any post or page? =
Yes, use the Aweber forms shortcode, [aweber_form_creator id="%postId%"] on your pages and posts.


== Screenshots ==

[See screenshots at thinklandingpages.com] (http://www.thinklandingpages.com/aweber-form-creator/)


== Changelog ==

= 1.0 =
* First Release


