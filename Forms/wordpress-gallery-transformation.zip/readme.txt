=== Plugin Name ===
Contributors: PsMan, Bouzid Nazim Zitouni, AngryByte
Donate link: http://angrybyte.com/donate/
Tags: gallery, wallpapers, transformation, images, photos
Requires at least: 2.0.2
Tested up to: 3.0.1
Stable Tag:1.5

Transforms Wordpress into an images gallery.
== Description ==

Transforms word press into a gallery, wallpapers website, you name it. 
with ftp upload support, batch URL download, auto resizing. tagging, categorizing, renaming is made so easy! 
This plugin will also create a new  post for every picture in the gallery to make your gallery compatible with any wordpress plugin you may want to use. 
A working copy of this gallery is here http://cosplay-naruto.com

== Installation ==

Just download and start the plugin.

you can now ftp your pictures to the gal/ftp folder that was created in your blogs root.
Or you can "Batch url download" through the admin panel. or upload file by file if you wish.
Just press "Process ftp uploads in the admin panel, it will resize, thumbnail, and create blog entries for each picture.
You just have to put each picture in the right category and that's that.

You can add tags later if you wish, or leave that task to your visitors.

The admin panel is not the most beautiful one ever, but bear with me until I release a better looking version

== Frequently Asked Questions ==

Q. This sux! =
A. You suck! .

Q.can my visitors upload pics?
A. yes they can, they must be registered though, one they did it, you must process it yourself by clicking process ftp uploads.



== Changelog == 
V 0.7
*Now the plugin creates it's own database
* Now it creates its Own Folders.
*Removed the many debug outputs
*made nicer.
*Sorry for all the problems with the old ver.
Corrected the plugin's URL
V 0.5
* first public release.
* good stuff, no known issues.
