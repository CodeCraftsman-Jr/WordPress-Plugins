=== Plugin Name ===
Contributors: mazedlx
Donate link: http://mazedlx.net/
Tags: youtube
Requires at least: 3.3.1
Tested up to: 3.3.1
Stable tag: 1.0

Fetches Preview-Pictures and Links from any Youtube-User or Channel to display in a WP sidebar

== Description ==

Fetches Preview-Pictures and Links from any Youtube-User or Channel to display in a WP sidebar
