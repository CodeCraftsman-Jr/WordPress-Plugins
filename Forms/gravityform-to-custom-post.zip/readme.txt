=== GravityForm to Custom Post ===

Contributors: promz, shashanksahu, mukkiee

Tags: gravityform, custom, post, form

Requires at least: 3.0.1

Tested up to: 4.1

Stable tag: 0.9

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html



This Plugin adds the custom field from gravity form.



== Description ==



This Plugin adds the custom field from gravity form.



== Installation ==



1. Add GravityForm to Custom Post Plugin to your Wordpress.

1. Activate the plugin through the 'Plugins' menu in WordPress.



== Screenshots ==



== Changelog ==



== Upgrade Notice ==