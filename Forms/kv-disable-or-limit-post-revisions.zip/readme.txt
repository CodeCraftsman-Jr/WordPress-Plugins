===  KV Disable or Limit WordPress Post Revisions ===
Contributors: kvvaradha
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=kvvaradha@gmail.com&item_name=KV Plugin Hider	
Tags: hide adminbar, hide, kvcodes, 
Requires at least: 3.1
Tested up to: 4.1

A Simple Plugin which helps to maintain your WordPress Post Revisions and helps to reduce the database load and increase your site speed with it.  

== Description ==

A Simple Plugin which helps to maintain your WordPress Post Revisions and helps to reduce the database load and increase your site speed with it.  

If you want to rework with the code, fine take a look at here before start usging this code, It will be helpful to work with your own project.<a href="http://kvcodes.com/2014/06/disabling-limiting-wordpress-post-revisions/" target="blank" > Kvcodes.com </a> 

**Features**

* Easy install
* Easy to show hide from the plugins directory.

== Installation ==

You can use the built in installer and upgrader, or you can install the plugin manually.

**Installation via Wordpress**

1. Go to the menu 'Plugins' -> 'Install' and search for 'WP List PlugIns'
1. Click 'install'

**Manual Installation**

1. Upload folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Screenshot of Disable or Limit WordPress Post Revisions admin interface.


