=== Click to Change ===
Contributors: Rameez_Iqbal
Tags: post, update post, contents, edit, edit contents, front edit, simple, posts, pages, page, products, product description
Donate link: http://webcodingplace.com/contact-us/
Requires at least: 3.5
Tested up to: 4.1
Stable tag: 2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Just click and change contents of Posts, Pages and Custom Post Types when viewing it.

== Description ==
Very simple plugin to change title and contents of post/pages and custom post types from front end, without having to go to dashboard.

== Installation ==
1. Go to plugins in your dashboard and select \'add new\'
2. Search for \'Click to Change\', install it and activate
3. Now visit page or post and click on title or content to change
4. Press save button and your post/page is updated

== Screenshots ==
1. Click to Change
2. Save alert