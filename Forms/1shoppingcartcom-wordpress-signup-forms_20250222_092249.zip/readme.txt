=== Wordpress Signup Forms ===
Contributors: 1ShoppingCart
Donate Link: www.1shoppingcart.com
Tags: 1ShoppingCart, Email, Optin, Opt-in, Autoresponder, Broadcast, Client
Requires at least: 2.2
Tested up to: 2.7
Stable tag: trunk

add a mailing list signup form to your blog 

== Description ==

Introducing Signup Forms from 1ShoppingCart.com, our first Wordpress plugin: 
Designed to simplify the process of adding a mailing list signup form to your blog, 
Wordpress Signup Forms gives you all the flexibility of our custom forms designed specifically for Wordpress sites. 
Easy to install and highly customizable from a simple user setup menu, 
our new Wordpress plugin will make your list building efforts a cinch.

== Installation ==

Add a 1ShoppingCart.com Custom Form to your blog. Usage: 

Goto 'Appearance >> Widgets' and add the '1SC Custom Forms' widget to the sidebar. 

Then goto 'Signup Form' in the Admin sidbar to setup the form.

== Frequently Asked Questions ==

None

== Screenshots ==

1. Setup screenshot 1
2. Setup screenshot 2
3. Setup screenshot 3
4. Setup screenshot 4
5. Setup screenshot 5
6. Setup screenshot 6
7. Setup screenshot 7
8. Setup screenshot 8
9. Setup screenshot 9
10. Setup screenshot 10
11. Setup screenshot 11
12. Setup screenshot 12

== Changelog ==

= 1.0 =

 Initial release
 
= 1.0.1 =

 Validation bug fix

= 1.0.2 =

 Validation bug fix