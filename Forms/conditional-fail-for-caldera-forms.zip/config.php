<div class="caldera-config-group">
	<label><?php echo __('Fail Message', 'cf-conditional-fail'); ?> </label>
	<div class="caldera-config-field">
		<input type="text" class="block-input field-config required magic-tag-enabled" name="{{_name}}[message]" value="{{message}}">
	</div>
</div>
