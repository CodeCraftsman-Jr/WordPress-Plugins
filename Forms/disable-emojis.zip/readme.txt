=== Disable Emojis ===
Contributors: ryanhellyer
Tags: emojis
Donate link: https://geek.hellyer.kiwi/donate/
Requires at least: 4.2
Tested up to: 4.4
Stable tag: 1.5


This plugin disables the new emoji functionality in WordPress 4.2.


== Description ==

This plugin disables the new emoji functionality in WordPress 4.2.


== Installation ==

After you've downloaded and extracted the files:

1. Upload the complete 'disable-emojis' folder to the '/wp-content/plugins/' directory OR install via the plugin installer
2. Activate the plugin through the 'Plugins' menu in WordPress
3. And yer done!

Visit the <a href="https://geek.hellyer.kiwi/plugins/disable-emojis/">Disable Emojis plugin</a> for more information.


== Changelog ==

Version 1.5: Catering for invalid $plugin array<br />
Version 1.4: Updating to use Otto's code<br />
Version 1.3: Removing extraneous styles<br />
Version 1.2: Bug fix<br />
Version 1.1: Updating to work with latest beta<br />
Version 1.0: Initial release<br />
