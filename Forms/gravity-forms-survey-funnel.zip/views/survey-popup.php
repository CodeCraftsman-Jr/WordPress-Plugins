<div id="gravity-forms-survey-funnel-background"></div>
<div id="gravity-forms-survey-funnel-form">
	<input type="hidden" id="form-id" value="<?php echo $surveyId; ?>" />
	<div id="close"></div>
	<?php echo $form; ?>
</div>