=== Gravity Forms Survey Funnel ===
Contributors: pronamic, remcotolsma
Tags: gravity forms, gravity, forms, form, survey funnel, pop up, survey, question, answer, deprecated, adopt-me
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 1.0.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Deprecated — Welcome the visitor of your website with a survey.

== Description ==

> This plugin is deprecated so Pronamic wil no longer support and maintain this plugin.
>
> If you want to help maintain the plugin, fork it on [GitHub](https://github.com/pronamic/wp-gravityforms-surveyfunnel) and open pull requests.


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your 
WordPress installation and then activate the Plugin from Plugins page.


== F.A.Q. ==


== Screenshots ==


== To-Do ==

*	Recurrence: Once, Weekly, Monthly
*	Show: Show right away, Show on click on banner


== Changelog ==

= 1.0.1 =
*	Added an deprecated notice.

= 1.0.0 =
*	Initial release
