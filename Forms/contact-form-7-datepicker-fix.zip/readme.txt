=== Contact Form 7 IE DatePicker and Number Spinner Fix ===
Contributors: Hackbard23
Tags: contact form, contact form 7, contact, form, number, spinner, datepicker
Requires at least: 3.5
Tested up to: 4.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add the jQuery Datepicker and Spinner functionality to your Contact Form 7

== Description ==
You are using the Contact Forms 7 Plugin and are angy about the none HTML 5 Support?
No Problem. With this Plugin u will have the normal Datepicker & Number Spinner from jQuery in your Internet Explorers and other none HTML5 browsers.

If you have Questions or Feature Request, feel free and contact me.

== Installation ==
1. Upload `cf7-datepicker-ie-fixer.zip` to the `/wp-content/plugins/` directory
2. Extract `cf7-datepicker-ie-fixer`
3. Activate the plugin through the \'Plugins\' menu in WordPress
4. Preview Form
5. Edit your css file and overwrite Plugin settings
6. you have to use `` in your Theme so this Plugins works

== Frequently Asked Questions ==
none

== Changelog ==
= Feature 2.6 =
* using min & max for datepicker
* using min & max for numberpicker


= Feature 2.5: =
* added range for month and year http://wordpress.org/support/topic/contact-form-7-ie-datepicker/page/2?replies=36#post-5135692

= Bugs 2.4: =
* remove window.log
* set dateFormat

= Bugs 2.3: =
* added check for html5 support
* check if it is new IE

= Feature 2.2: = 
* Added the Spinner function for Contact Form 7 number Fields 

= Fix 2.1: = 
* added jquery spinner js files

= Fix 2.0: = 
* Fix the Selector, only Contact Form 7 Forms with class \"wpcf7-date\" will be transformed