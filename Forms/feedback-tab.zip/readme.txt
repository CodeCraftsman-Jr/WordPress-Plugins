=== Feedback Tab ===
Contributors: Scott Underhill
Donate link: http://www.monyta.com/
Tags: feedback tab, feedback, customer data,contact form,bugs,questions,contact
Requires at least: 2.5
Tested up to: 3.0
Stable tag: 0.4.6

Adds a feedback tab to your web site, as part of the monyta system
== Description ==
The plugin is a feedback tab, which allows you to create a feedback tab on your wordpress web site 

You will be required to have an account with www.monyta.com before you can start, once you have signed 
up with monyta, all you will need to do is copy your feedback ID into feedback settings in the administration control panel 
and the feedback tab will appear. 

To configure your feedback tab, just go to www.monyta.com
== Installation ==


1. Upload the feedbactab directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Options/Feedback Tab Settings to configure
4. That's it.Feedback tab will now appear.

== Frequently Asked Questions ==
na
== Screenshots ==

na

== ChangeLog ==

1.0.0 Inital upload

== Upgrade Notice == 

na