=== Plugin Name ===
Contributors: jasonmj
Donate link: http://www.fullsteamlabs.com/
Tags: 
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Auto Collapse the Admin Sidebar and Customizer Sidebar.

== Description ==

Auto Collapse the Admin Sidebar and Customizer Sidebar.

== Installation ==

1. Upload `auto-collapse` director to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

1. It's easy to show/hide the admin sidebar. 
2. Auto Collapse works for the customizer as well. 

== Changelog ==
= 1.2.2 =
* Added better control over hoverIntent for submenus
= 1.2.1 =
* Improved submenu display when menu height is greater than page height
= 1.2.0 =
* Removed animations from Customizer
= 1.1.9 =
* Fixed Mobile Menu margin-left
= 1.1.8 =
* Added Compatibility for WP 4.3 
* Adjusted CSS for Better Cross Version Compatibility
= 1.1.7 =
* Adjusted css for collapsed sidebar on customizer
= 1.1.6 =
* Added Hide on Load
= 1.1.5 =
* The changelog for this version got lost. 
= 1.1.4 =
* Removed animations
* Added hover on current item to keep icons in place. 
= 1.1.3 =
* Quick bug fix for the floating admin menu.
= 1.1.2 =
* Reworked some js and added floating admin sidebar function.
= 1.1.1 =
* Added hover over content for admin sidebar.
= 1.1.0 =
* Fixed a few layout issues and added support for collapsing the customizer.
= 1.0.0 =
* First release
