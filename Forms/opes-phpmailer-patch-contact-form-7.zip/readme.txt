=== Opes PhpMailer Patch - Contact Form 7 ===
Contributors: twapaw
Tags: phpmailer, smtp, patch, contact, form, contact form, contact form 7, field, from, name, from name, fromname
Requires at least: 3.9
Tested up to: 4.1
Stable tag: 1.0.0
License: GPLv2 or later

This plugin fixes a problem with setting the field 'From' and 'FromName'.

== Description ==

This plugin fixes a problem with setting the field 'From' and 'FromName' while sending e-mail forms from the Contact Form 7 plugin i.e. having set SMTP with fixed 'From' and 'FromName' fields.

<strong>Certainly it works with the version 4.0.3 of the Contact Form 7.</strong>

<strong>Major features in Opes PhpMailer Patch - Contact Form 7 include</strong>:

* Very simple!
* No need to set anything!
* Just works!

== Installation ==

* Upload the Opes PhpMailer Patch - Contact Form 7 plugin to your blog and activate it.

== Changelog ==

= 1.0.0 =
*Release Date - 8th January, 2015*

* It is first release
