<?php include sprintf("%s/common.php", dirname(__FILE__)); ?>

<?php echo $templateData['stream_header']; ?>

<div id="stream_holder">
	<?php echo $templateData['stream_html']; ?>
</div>