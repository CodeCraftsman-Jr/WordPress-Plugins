<div class="updated">
	<p>
		<?php echo $msg; ?>
	</p>
</div>