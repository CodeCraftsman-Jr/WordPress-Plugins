=== Link Contact Form 7 to opentaps CRM2 ===
Contributors: sichen
Tags: opentaps, crm2, crm, contact, form
Requires at least: 3.9.3
Tested up to: 4.1
Stable tag: 1.0.0
License: Apache License, Version 2.0

Link Contact Form 7 to opentaps crm2

== Description ==

Create your contacts in WordPress with Contact Form 7 and see them in opentaps CRM2 (www.opentaps.com), the free web/mobile/social CRM that helps your team work together.  See http://youtu.be/6nMg15yWZyM  

This plugin posts contact form 7 fields (first name, last name, company, phone, email, comments only) into CRM2.  

A contact will be automatically created, and you will be able to access it from the web UI or the mobile app.

Stay tuned for more enhancements -- we love wordpress and use it ourselves! 

== Installation ==

1.  Sign up for an account at opentaps.com
2.  Upload plugin to your blog
3.  Activate it
4.  Enter your crm2.opentaps.com client domain and auth token.  See http://bit.ly/1BEqsS7
5.  Put these EXACT fields name in the Contact Form 7 plugin:
* [text first-name]
* [text last-name]
* [text company-name]
* [tel phone-number]
* [email email-address]
* [textarea comment]
