<?php
// Silance is goolden