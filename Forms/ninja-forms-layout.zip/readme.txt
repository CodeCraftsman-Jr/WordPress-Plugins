=== Plugin Name ===
Contributors: marclloyd77
Donate link: http://marclloyd.co.uk/
Tags: Ninja Forms, Layout, fieldset, div, Ninja Forms Layout
Requires at least: 2.8.6
Tested up to: 4.0.1
Stable tag: 4.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ninja Forms Layout adds fieldset and div elements.

== Description ==

Ninja Forms Layout adds fieldset and div elements to the 'Layout' Elements' block. It also includes custom classes for elements to allow for more interesting layouts and styling.

This plugin requires the Ninja Forms plugin.

== Installation ==

1. Upload 'plugin-name.php' to the '/wp-content/plugins/'' directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

1. Fieldset start element.
2. Additional fieldset and div opions.

== Changelog ==

= 1.2 =
* Bug Fix: Checkling ninja_forms_register_field exists before calling

= 1.1 =
* Adjusting file structure

= 1.0 =
* First tagged version

