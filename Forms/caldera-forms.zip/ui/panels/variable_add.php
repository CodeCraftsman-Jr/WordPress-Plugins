<a class="add-new-h2 caldera-panel-action caldera-add-variable" href="#add_var"><?php echo __('Add Variable', 'caldera-forms'); ?></a>
