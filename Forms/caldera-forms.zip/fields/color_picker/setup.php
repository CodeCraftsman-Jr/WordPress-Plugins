<div class="caldera-config-group">
	<label><?php _e('Default'); ?> <?php _e('Color', 'caldera-forms'); ?></label>
	<div class="caldera-config-field">
		<input type="text" class="minicolor-picker field-config" name="{{_name}}[default]" value="{{default}}">
	</div>
</div>
