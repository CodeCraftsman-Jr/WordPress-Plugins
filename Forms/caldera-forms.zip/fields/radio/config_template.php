<div class="caldera-config-group">
	<label></label>
	<div class="caldera-config-field">
		<label><input type="checkbox" class="field-config" name="{{_name}}[inline]" value="1" {{#if inline}}checked="checked"{{/if}}> <?php _e('Inline', 'caldera-forms'); ?></label>
	</div>
</div>