<div class="caldera-config-group">
	<label><?php _e('Content'); ?></label>
</div>
<div style="clear:both;"></div>
<div style="position:relative;">
	<textarea class="block-input field-config magic-tag-enabled" name="{{_name}}[default]" id="{{_id}}editor" style="resize:vertical; height:200px;">{{default}}</textarea>
</div>