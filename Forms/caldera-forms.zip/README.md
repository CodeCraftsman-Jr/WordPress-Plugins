Caldera-Forms
=============
<a href="https://calderawp.com/caldera-forms-add-ons/"><img src="https://calderawp.com/wp-content/uploads/2015/07/caldera-forms-banner-alt-title.png" /></a>


# Drag & Drop Responsive Form Builder

#### By <a href="https://CalderaWP.com" title="CalderaWP: Transform Your WordPress Experience">CalderaWP</a>

### Docs, Add-ons & More Information:
* [Premium Add-ons](https://calderawp.com/caldera-forms-add-ons/)
* [More Information](https://calderawp.com/caldera-forms/)
* [Documentation](http://docs.calderaforms.com/)


### Contributing/ Using This Repo, Etc.
* The default branch is "current-stable" that should be the same as WordPress.org
* Development for version 1.3 and later occurs on "current-dev" branch.
* Pull requests are welcome. Please submit against "current-dev" branch.
