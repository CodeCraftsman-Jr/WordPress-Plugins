=== Hello Chris ===
Contributors: neonleif
Donate link: Do something good for the world instead.
Tags: game design, book excerpts, one-liners, lessons, Chris Crawford
Requires at least: 2.3
Tested up to: 2.7
Stable tag: 0.1

Get Chris Crawford's lessons on game design in your Wordpress admin heading instead of the lyrics from "Hello Dolly"

== Description ==

Based on the "Hello Dolly" plugin, "Hello Chris" provides a random game design lessons (of 96) excerpted from Chris Crawford's "Chris Crawford on Game Design" (New Riders Publishing 2003) shown in the heading of the admin part of wordpress.
 
== Installation ==

To install the plugin just follow these simple steps:

1. Download the plugin and expand it.
2. Upload the 'Hello Chris' folder into your plugins folder (wp-content/plugins/).
3. Login into the WordPress administration area and go to the Plugins page.
4. Locate the Hello Chris plugin and click on the activate link. 
5. Deactivate the Hello Dolly plugin (if you want to read either of the plugins)


== Frequently Asked Questions ==

= Does this plugin violate Mr. Crawford's and Newrider's copyrights? =

I have absolutely no idea. However I have sent an email to the publisher and asked them to take a look. Haven't heard from them yet, so I guess they are all right with it.

= Half the lessons don't make sense to me... What do they mean? =

Please read "Chris Crawford on Game Design" (New Riders Publishing 2003). It's brilliant and this plugin is just meant to keep the book in mind.