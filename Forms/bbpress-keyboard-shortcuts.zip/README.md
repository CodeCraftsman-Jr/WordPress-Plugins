bbPress Keyboard Shortcuts
===================

bbPress keyboard shortcut plugin to simply publish replies. Pretty simple.

Only works if you are clicked on the reply textarea and press the keyboard shortcut within it.

Keyboard Shortcuts Included:

- CMD + Enter
- Control + Enter
