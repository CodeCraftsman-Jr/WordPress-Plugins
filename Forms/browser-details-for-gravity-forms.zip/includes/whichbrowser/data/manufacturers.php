<?php

		Manufacturers::$TELEVISION = array(
			'BANGOLUFSEN'								=> 'Bang & Olufsen',
			'inverto'									=> 'Inverto',
			'LG Electronics'							=> 'LG',
			'LGE'										=> 'LG',
			'TOSHIBA'									=> 'Toshiba',
			'SERAPHIC'									=> 'Seraphic',
			'selevision'								=> 'Selevision',
			'SHARP'										=> 'Sharp',
			'smart'										=> 'Smart',
			'Sky_worth'									=> 'Skyworth',
			'TELEFUNKEN'								=> 'Telefunken',
			'THOM'										=> 'Thomson',
			'THOMSON'									=> 'Thomson',
			'tv2n'										=> 'TV2N',
			'VESTEL'									=> 'Vestel'
		);