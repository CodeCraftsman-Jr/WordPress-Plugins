<?php

		DeviceModels::$S30_MODELS = array(
			'215'										=> array( 'Nokia', '215' ),
			'220'										=> array( 'Nokia', '220' )
		);