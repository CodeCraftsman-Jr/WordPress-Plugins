<?php

		DeviceModels::$BADA_MODELS = array(
			'GT- ?S52(50|53)!'							=> array( 'Samsung', 'Wave 525' ),
			'GT-S53(30|33)!'							=> array( 'Samsung', 'Wave 533' ),
			'GT-S5380!'									=> array( 'Samsung', 'Wave Y' ),
			'GT-S57(50|53)!'							=> array( 'Samsung', 'Wave 575' ),
			'GT-S57(80)!'								=> array( 'Samsung', 'Wave 578' ),
			'GT-S72(30|33)!'							=> array( 'Samsung', 'Wave 723' ),
			'GT-S7250!'									=> array( 'Samsung', 'Wave M' ),
			'GT-S8500!'									=> array( 'Samsung', 'Wave' ),
			'GT- ?S8530!'								=> array( 'Samsung', 'Wave II' ),
			'GT- ?S8600!'								=> array( 'Samsung', 'Wave 3' ),
			'SHW-M410'									=> array( 'Samsung', 'Wave 3' )
		);
