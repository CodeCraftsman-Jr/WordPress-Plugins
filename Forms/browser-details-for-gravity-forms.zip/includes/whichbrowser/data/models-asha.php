<?php

		DeviceModels::$ASHA_MODELS = array(
			'Asha230SingleSIM'							=> array( 'Nokia', 'Asha 230' ),
			'Asha230DualSIM'							=> array( 'Nokia', 'Asha 230' ),
			'500'										=> array( 'Nokia', 'Asha 500' ),
			'Asha500DualSIM'							=> array( 'Nokia', 'Asha 500' ),
			'501'										=> array( 'Nokia', 'Asha 501' ),
			'501s'										=> array( 'Nokia', 'Asha 501' ),
			'501.1'										=> array( 'Nokia', 'Asha 501' ),
			'501.2'										=> array( 'Nokia', 'Asha 501' ),
			'502'										=> array( 'Nokia', 'Asha 502' ),
			'503'										=> array( 'Nokia', 'Asha 503' ),
			'503s'										=> array( 'Nokia', 'Asha 503' ),
		);