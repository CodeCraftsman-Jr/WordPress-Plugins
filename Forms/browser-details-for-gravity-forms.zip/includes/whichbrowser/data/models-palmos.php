<?php

		DeviceModels::$PALMOS_MODELS = array(
			'Palm-D050'								=> array( 'Palm', 'TX' ),
			'Palm-D053'								=> array( 'Palm', 'Treo 680' ),
			'Palm-D061'								=> array( 'Palm', 'Centro' ),
			'Palm-D062'								=> array( 'Palm', 'Centro' ),
			'Palm-TunX'								=> array( 'Palm', 'LifeDrive' ),
			'hspr-H102'								=> array( 'Palm', 'Treo 650' )
		);