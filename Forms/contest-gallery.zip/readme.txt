=== Contest Gallery ===
Contributors: Contest-Gallery
Donate link: http://www.contest-gallery.com
Tags: contest, contest gallery, gallery, galleries, view, height view, thumb view, panorama, panorama views, different views, image, images, image gallery,  pictures, picture gallery, album, albums, photo albums, image album, media, media gallery, photo, photos, photo gallery, picture,thumbnails, thumbnail gallery,  slideshow gallery, slideshow galleries, fancybox, lightbox, responsive, responsive gallery, thumbnail galleries, slideshow, slideshows, responsive galleries, wordpress responsive gallery, wordpress gallery plugin, wordpress photo gallery plugin, wp gallery, wp gallery plugins, best gallery plugin, free photo gallery, singlepic, image captions imagebrowser, watermarks, watermarking, photography, photographer
Requires at least: 3.9
Tested up to: 4.2.2
Stable tag: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin with ability to upload images in frontend, to manage them in backend, to display them in different ways in frontend and to rate them.

== Description == 
Plugin with ability to upload images in frontend, to manage them in backend, to display them in different ways in frontend and to rate them.

== Screenshots ==

1. Height View
2. Thumb View
3. Panorama View
4. Vertical View