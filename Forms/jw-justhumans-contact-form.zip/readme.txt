=== JustHumans Contact Form ===

Contributors:      madjax
Plugin Name:       JustHumans Contact Form
Plugin URI:        http://jacksonwhelan.com/
Tags:              JustHumans, contact form, shortcode
Requires at least: 2.9.2 
Tested up to:      3.0.1
Stable tag:        1.0
Version:           1.0

Simple plugin for inserting JustHumans powered contact forms.

== Description ==

This plugin provides a shortcode for inserting simple contact forms, with JustHumans powered spam protection.

== Installation ==

Activate plugin, visit Tools > JustHumans Settings to enter your form code. Then add shortcode to desired pages and posts where the form should appear.

== Changelog ==

= 1.0 =
* First public release.