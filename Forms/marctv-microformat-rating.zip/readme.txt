=== MarcTV Microformat Rating ===
Contributors: marcdk
Tags: microformat, hreview
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 1.2

== Description ==

Adds a hreview rating below the content of an article. Use custom field "rating" value: [0-10] and "rating_summary" value: [text]

== Installation ==

* Upload the plugin to your blog
* Activate it.
* Use custom field "rating" value: [0-10] and "rating_summary" value: [text]

== Changelog ==

= 1.0 =

* First version.

= 1.1 =

* Fixed $id bug on archive pages

= 1.2 =

* Fixed title bug
