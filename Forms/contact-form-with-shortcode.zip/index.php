<?php
// nothing is here
?>