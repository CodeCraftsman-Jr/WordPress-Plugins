﻿=== Driggle Nachrichten ===
Contributors: DrgFlips
Tags: driggle, nachrichten, news, widget, sidebar
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 1.0

Driggle Nachrichten liefert Ihnen die neusten
Schlagzeilen direkt in den Blog.

== Description ==

Driggle Nachrichten erlaubt es Ihnen auf Ihrem 
Blog die neusten Schlagzeilen anzeigen zu lassen. 
Sie können selber einstellen, aus welchem 
Themenbereich die Schlagzeilen erstellt werden,
wie sie geordnet werden und wie viele angezeigt
werden. 

== Installation ==

Laden Sie die Datei "driggle_news_de.php" in das 
Plugin-Verzeichnis, dieses befindet sich für gewöhnlich im Ordner wp-content.

Haben Sie diesen Schritt beendet, melden Sie 
sich bitte im Admin Panel an und rufen die
Seite Plugins auf.

Dort müssten Sie einen Eintrag mit dem Titel
"Driggle Nachrichten" sehen. Darunter befindet
sich ein Link, über den Sie das Plugin
aktivieren können. Dieser Link trägt in der
deutschen Wordpress Version den Namen
"Aktivieren" und in der Englischen "Activate".

Ist das Plugin Aktiviert, rufen Sie bitte die
Seite Widgets auf. Dort müsste nun ein neues
Widget verfügbar sein "Driggle Nachrichten".
Dieses ziehen Sie in eine verfügbare Sidebar.

Nun ist das Widget aktiv und zeigt die neusten
Schlagzeilen auf Ihrem Blog an.

Das Widget lässt sich bequem über das Admin
Panel konfigurieren.

Öffnen Sie dazu die Seite Widgets im Admin
Panel und Klappen Sie den Eintrag
"Driggle Nachrichten" in der Sidebar aus.

Es erscheint nun ein Formular mit dem Sie
die Einstellungen bearbeiten können.

== Screenshots ==

1. Driggle Nachrichten eingebunden in das Standard Theme
2. Driggle Nachrichten eingebunden in ein anderes Theme
3. Driggle Nachrichten Konfiguration