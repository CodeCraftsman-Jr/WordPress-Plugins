=== Hello Wapuu ===
Contributors: khoshino
Donate link: http://wp3.jp/
Tags: widget, widgets, admin, dashboard, event, events, plugin, plugins, wapuu
Requires at least: 2.9.2
Tested up to: 3.2.1
Stable tag: 0.2

WordPress Japanese official character "Wapuu" is plugin to speak a message on a dashboard.

== Description ==
WordPress Japanese official character "Wapuu" is plugin to speak a message on a dashboard.
Only Japanese supports it now.
In future versions, it is going to support the translation files.

= Functions =
1. The current time is displayed on the dashboard.
2. Last post date until now, how long, you know what the post has not been updated.

== Installation ==
1. Upload the `hello-wapuu` directory to the plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. "Wapuu message" widget is displayed on the dashboard.

== Frequently Asked Questions ==
= What web browsers are supported? =
The supporting Web browser has to be HTML5 and CSS3.
Chrome , Firefox and IE9 are supported.
IE6 , IE7 and IE8 are not supported.

= What is the supporting language? =
Only Japanese supports it now.
In future versions, it is going to support the translation files.

== Screenshots ==
1. WordPress Japanese official character "Wapuu" talks on the dashboard.

== Changelog ==
= 0.2 =
* August 22, 2011
* Public release.
* Added support to display your user name.
* Bugfix: Added support for multi-user.

= 0.1 =
* August 14, 2011
* Initial release.

== Upgrade Notice ==
= 0.2 =
* This version supported multi-user.

== Arbitrary section ==
My name is Kunitoshi Hoshino.
I am Japanese.
This plugin, the WordPress Japanese official character "Wapuu" to commemorate the birth, I made.
I'm not good at English, so, there may be mistakes in English.
The opportunity to publish a new WordPress plugin that, I would like to learn English.
Thanks!
"[WordPress Community](http://wp3.jp/ "WordPress Community")" is my blog.
