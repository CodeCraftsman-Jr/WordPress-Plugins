﻿===Dhonodhanno Pushpo Bhora ===
Contributors: nazmul.hossain.nihal
Tags: ধন ধান্য পুষ্প ভরা,নাজমুল হোসেন নিহাল,বাংলা,কবিতা,গান,dhonodhanno,pushpo,bhora,bengali,bangla
Requires at least: 3.5 
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=FYMPLJ69H9EM6

ধন ধান্য পুষ্প ভরা, আমাদের এই বসুন্ধরা

== Description ==

ওয়ার্ডপ্রেসের "হ্যালো ডলি" প্লাগিনটা দেখার পর আমার ইচ্ছা হয় আমিও আমার প্রিয় কোন গান/কবিতা দিয়ে এরকম একটা প্লাগিন বানাবো।তো আমি দিজেন্দ্রলাল রায়ের লেখা "ধন ধান্য পুষ্প ভরা" দিয়ে প্লাগিনটি বানিয়েছি।প্লাগিনটির কোডিং এ যথা সম্ভব বাংলা ব্যাবহার করার চেষ্টা করেছি।প্লাগিনটি এক্টিভ্যাট করার পর এটি গানের বিভিন্ন পঙতি আপনার এডমিন প্যানেলের উপরে-ডান দিকে প্রদর্শন করবে।

== Screenshots ==

1. প্লাগিনটি গানের কথা দেখাচ্ছে
2. বাংলা ভাষা ব্যাবহার করে কোডিং করা হয়েছে

== Upgrade Notice ==

= 1.0 =
* Plugin Created

== Changelog ==

= 1.0 =
* Plugin Created