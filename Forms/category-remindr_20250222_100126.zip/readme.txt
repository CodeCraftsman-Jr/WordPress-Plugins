=== Category Reminder ===
Contributors: glztt
Tags: categories
Requires at least: 2.0
Tested up to: 2.1
Stable tag: trunk

Category Remindr adds a giant color-changing balloon pointing the categories section just below the Publish button

== Description ==

If you always forget putting categories, you will love this plugin, Category Remindr adds a giant color-changing balloon pointing the categories section just below the 'Publish' button , so you never forget about categorizing again, it comes with support for english and spansish languages or a custom phrase.

== Installation ==

1. Upload 'catrec.php' to '/wp-content/plugins/'.
2. Activate the plugin through the 'Plugins' menu in WordPress.