=== Link Prefetching ===
Contributors: intlect
Tags: link, prefetching
Requires at least: 2.9.2
Tested up to: 3.0
Stable tag: 1.0.1

A simple plugin to add link prefetching links on your homepage (to your latest post) and on your posts (to the previous and next posts). Activate and that's it.

== Description ==

Adds link prefetching tags as supported by Mozilla Firefox. https://developer.mozilla.org/en/link_prefetching_faq

== Installation ==

1. Upload `link-prefetching.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

== Changelog ==

= 1.0.1 =
* Minor change for W3 validation.

= 1.0 =
* Initial release.
