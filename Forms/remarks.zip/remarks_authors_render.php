<div id='author_div' class='startHidden'>
  <?php remarks_renderNavigationOptions('author') ?>
  <br/>
  <div id='author_table'>
    <?php renderAuthorMatrix(); ?>
  </div>
  <br/>
  <?php drawAuthorsBars(); ?>
  <br/>
  <?php drawAuthorsPie(); ?>
  <br/>
</div>