<div id='main_nav_with_comments'><br/>
     <?php 
          populateButtonsList();
          makeAllButtons(); 
      ?>
</div>
<br/>