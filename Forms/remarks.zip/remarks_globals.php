<?php

global $remarks_total_comments;

// posts

global $remarks_posts;
	$remarks_posts = array();

global $remarks_posts_top;
  $remarks_posts_top = array();	
	
// categories	
	
global $remarks_categories;
	$remarks_categories = array();
	
global $remarks_categories_top;
  $remarks_categories_top = array();
  
 // authors
 
global $remarks_authors;
	$remarks_authors = array();
	
global $remarks_authors_top;
	$remarks_authors_top = array();
	
// countries	
	
global $remarks_countries;
	$remarks_countries = array();
	
global $remarks_countries_top;
	$remarks_countries_top = array();
	
// longlats	
	
global $remarks_longlats;
	$remarks_longlats= array();
	
// buttons	
	
global $buttons_List;
     $buttons_List = array();

	
?>