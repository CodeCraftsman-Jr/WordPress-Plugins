<div id='category_div' class='startHidden'>
  <?php remarks_renderNavigationOptions('category') ?>
  <br/>
  <div id='category_table'>
    <?php renderCategoryMatrix(); ?>
  </div>
  <br/>
  <?php drawCategoriesBars(); ?>
  <br/>
  <?php drawCategoriesPie(); ?>
  <br/>
</div>