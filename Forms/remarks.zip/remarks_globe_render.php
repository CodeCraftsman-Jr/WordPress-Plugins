<div id='geolocate_div' class='startHidden'>
    <div id='geolocate_table_div'>
      <?php renderGeolocationCommentsTable(); ?>
    </div>
    <div id='geolocate_map_div'>
      <?php renderMapByComments(); ?>
    </div><br/>
<em>Geolocation powered by <a href='http://www.freegeoip.net/'>FreeGeoIP</a>.</em><br/>
<em>Map powered by <a href="http://lmgtfy.com/?q=google+map+api">Google Map API</a>.</em><br/>
<em>Unfortunately, the above map may be missing the locations of some of your comments. This is because sometimes it's impossible to translate the IP address into a geographic location.</em>
</div>
