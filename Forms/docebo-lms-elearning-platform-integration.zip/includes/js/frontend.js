(function($){
	$(function(){
		// document.ready

		$('.ie8fix').show().bgdSize('cover');
	})
})(jQuery);