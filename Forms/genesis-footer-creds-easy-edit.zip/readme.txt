=== Genesis Footer Creds easy edit ===
Contributors: apcano1978
Donate link: http://alesiadev.com/donate/
Tags: genesis, footer credits, genesiswp, studiopress, footer genesis
Requires at least: 3.4
Tested up to: 4.2.2
Stable tag: 1.0
License: GPL2+

Change the footer credits of your Genesis child theme directly in genesis theme setting without adding any code to functions.php

== Description ==

I always found annoying adding code to functions.php in a Genesis child theme in order to change the default footer credence appearing when using Genesis Framework, so I´ve created this simple plugin that allows you to change the footer credits directly in the Genesis theme setting adding simple html in order to display text, links and so on.

** IMPORTANT **
** Genesis Theme Framework required. **

== Installation ==

1. Upload the entire `genesis-footer-creds-easy-edit` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

Where do I place the custom footer?

Once activated the plugin in the wordpress back end, in Genesis -> Theme settings you have a metabox with an input field where you can add your credits using html tags.

== Plugin Support == 
Please visit (http://alesiadev.com) for support, also suggestions are pretty wellcome!

== Screenshots ==

1. Screenshot-1.png

== Changelog ==

= 1.0 =

First release of the plugin - I hope you enjoy it!