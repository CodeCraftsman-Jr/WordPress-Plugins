﻿=== NE:s faktabubbla ===
Tags: fakta, källa, bubbla, encyklopedi
Tested up to: 3.0.5
Requires at least: 2.0.0
Stable tag: trunk
Contributors: Nationalencyklopedin

English:
Activates a Swedish National Encyclopedia (NE) fact bubble on your website.
Swedish:
Aktiverar NE:s faktabubbla på din sida. 

== Description ==

Detta insticksprogram aktiverar NE:s faktabubbla på din sida. NE:s faktabubblor 
lyfter din hemsida! Med NE:s faktabubblor ger du din hemsidas besökare service 
och mervärde genom att erbjuda källkritiskt granskad information kring 
facktermer, begrepp, personer, organisationer och annat som du nämner på din 
sida. Faktabubblan dyker upp med ordförklaringar när muspekaren förs över ett 
ord som du länkat till i den fria delen av NE.se. Du hjälper dina besökare och 
de behöver inte lämna din sida för utförligare information.


== Installation ==

1. Aktivera insticksprogrammet i menyn 'tillägg'.