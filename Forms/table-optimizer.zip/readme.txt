=== Table Optimizer ===
Contributors: wokamoto
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=9S8AJCY7XB8F4&lc=JP&item_name=WordPress%20Plugins&item_number=wp%2dplugins&currency_code=JPY&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted
Tags: Database, Optimize
Requires at least: 2.5
Tested up to: 2.9.2
Stable tag: 0.1.0

The plugin optimize Your WordPress Database Tables regularly.

== Description ==

The plugin optimize Your WordPress Database Tables regularly.

== Installation ==

1. Upload the entire `table-optimizer` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Upgrade Notice ==

none.

== Frequently Asked Questions ==

none.

== Screenshots ==

none.

== Changelog == 

**0.1.0 - February 25, 2010**  
Initial release.
