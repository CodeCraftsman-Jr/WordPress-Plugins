﻿=== CuCa Validator ===
Contributors:  
Donate link: https://www.paypal.com/it/cgi-bin/webscr?cmd=_flow&SESSION=eORS0ocRI2x8vWQFgROFP4y7p8oM58PXL4TIw7COmk_4NfGAk1PVlUrUyPK&dispatch=5885d80a13c0db1f8e263663d3faee8d66f31424b43e9a70645c907a6cbd8fb4
Tags: Mathematical Captcha
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



We don't want spam bots to control our forms!
But we don't want ugly captcha blocks, either!!



== Description ==

We don't want spam bots to control our forms!
And we don't want ugly captcha blocks to stick on our site and destroy our theme layout!!

**CuCa Validator** comes to prevent spam to overflow into your site, using nicely designed captchas modules.
Choose between the skins built in and have CuCa fit into your theme. Or if you don't want any module at all,
just set up your captcha your way.

Each captcha module is handled by a **shortcode** and can easily be added into any post/page.
Set up the captcha difficulty from the admin page.

**CuCa Validator** stops spams the nice way, and maximize user experience.



**CuCa Math Validator** Makes you solve a simple math operation to validate the form and let you continue your navigation.

**CuCa Word Validator** Makes you solve a standard alphanumeric captcha like the ones you're used to.

**CuCa Color Validator** Coming soon



== Installation ==

-   Download CuCa Validator, extract the folder.
-   Upload it to your \`/wp-content/plugins/\` directory.
-   Activate the plugin through the \'Plugins\' menu in WordPress.  
    [DONE!]

*	Otherwise you can download the plugin from your WordPress blog admin panel and let it do the job for you.



== Screenshots ==  

1.  Admin panel
2.  Example of CuCa

 

== Changelog ==
 
*   Italian - translation added