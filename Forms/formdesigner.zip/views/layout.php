<div class="wrapAll">           
    <div class="wrapHeader">
        <div class="head">
            <div class="logo">
                <a href="<?= admin_url('admin.php?page=formdesigner'); ?>">
                    <img src="<?= FORMDESIGNER__PLUGIN_URL; ?>src/ico-logo.png" alt="FormDesigner" />
                </a>
            </div>
        </div>
    </div>
    <div class="wrapBody roundBorder">
    	<?php echo $content; ?>
    </div>
</div>