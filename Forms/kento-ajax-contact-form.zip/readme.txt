=== Kento Ajax Contact Form ===
Contributors: kentothemes
Donate link: 
Tags: Contact, contact form, contact form plugin, feedback, feedback form, send, contact us, ajax, ajax contact form, ajax contact form plugin, contact without page refresh, wordpress ajax contact form plugin, wordpress ajax form plugin, wordpress contact form using ajax, wordpress plugin for contact form
Requires at least: 3.7
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple contact form plugin using AJAX.

== Description ==

This is an extremely very simple contact form with AJAX which you can use whether in posts or in pages very easily. Using this, site's admin will get the email. You just need to put the shortcode [kento_contact_form] in any page/post. Email will be sent to admin without page refresh.

Live Preview: http://kentothemes.com/demo/kento-ajax-contact-form/kento-ajax-contact-form/

= Features =

* 	Contact form with ajax.
*	Shortcode System.
*	Easy to use and update



== Installation ==


1. Install as regular WordPress plugin.
2. Go your Pluings setting via WordPress Dashboard and activate it.
3. Then go to post or page section in dashboard where you want to show this form.
4. Create a page or a post and insert the shortcode [kento_contact_form] into the textarea.
5. You can add this in your existing posts or pages. Just click edit in your desire post or page and insert the shortcode [kento_contact_form] into the textarea.
6. All mail will recived your WordPress Admin email address.

== Screenshots ==

1. Normal view.
2. Ivalid Email Address.
3. Blank Text Field Error.



== Changelog ==

= 1.0 =
* Initial release

