=== GetResponse Add-On for FormCraft ===
Contributors: nish@ncrafts.net
Tags: getresponse, newsletter form, getresponse form, form builder, contact form 7, form, forms, widget, contact form, email form builder, ajax form builder, captcha, file upload, newsletter form, customer support form builder, drag and drop form builder, lead generation form builder
Requires at least: 3.6
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create gorgeous optin forms for your site  with FormCraft, and grow your GetResponse list.

== Description ==

This add-on allows you to add subscribers to your GetResponse lists, with forms made with [FormCraft](http://formcraft-wp.com/). You can read the tutorial [here](http://formcraft-wp.com/help/how-to-configure-get-response-add-on/)

Please note that this add-on works with [FormCraft Premium](http://formcraft-wp.com/), and not [FormCraft Basic](https://wordpress.org/plugins/formcraft-form-builder/)

== Changelog ==

= 1.0.2 =
* Initial release