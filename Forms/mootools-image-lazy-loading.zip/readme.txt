=== MooTools Image Lazy Load WP ===
Donate link: http://xn----zmcajjd2g4dcbc5b.com/
Tags: images, MooTools, javascript, lazyload
Requires at least: 2.8
Tested up to: 3.0.3
Stable tag: 0.01

add MooTools lazy loading to images

== Description ==

add lazy loading to WP, more info at http://davidwalsh.name/mootools-lazyload

== Installation ==

unzip archive to wp-content/plugins directory, and activate it in Plugins page in wp-admin
