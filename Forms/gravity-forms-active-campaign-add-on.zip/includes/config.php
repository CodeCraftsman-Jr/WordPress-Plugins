<?php

	define("ACTIVECAMPAIGN_URL", "");
	define("ACTIVECAMPAIGN_API_KEY", "");

?>