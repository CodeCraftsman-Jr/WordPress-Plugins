﻿=== Plugin Name ===
Contributors: Launch Control
Donate link: <a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_flow&SESSION=MTeQDkIAer3cuNdtVC44y3hS4artH6g4GKnMh-Em_pgmrxlvmhpPaD2siVm"> Help us develop new features - Donate Here </a>
Tags: maintenance, login, under-construction, administration, offline, unavailable, landing page
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.1.0
License:GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Quick Registration Holding Page - With a click of a button hide your website when you need to change a few things or run an upgrade, making it only accessible admins and allow users to register.

== Description ==

Are you working on a new website and don’t want the public or your users to have access until your masterpiece is complete, but still allow them to register? Yes! Thought so. with a click of a button hide your website when you need to change a few things or run an upgrade, making it only accessible admins. There is also an area to add a custom message which will be shown to the users while your site is down. Users can register and receive their login credentials by email to use later.

Close your website on maintenance. Search engines and regular users don't see your site. Access only by login

== Installation ==

1.	Upload the «launchcontrol» folder to the /wp-content/plugins/ directory
2.	Activate the plugin through the 'Plugins' menu in WordPress
3.	Go to Dashboard > Launch Control

== Screenshots ==
1. Dashboard
1. Login page

== Frequently Asked Questions ==

= Where can I find out the username and password to get to the site? = 

You can use your administrator access or create new user in wordpress dashboard
http://yousite.com/wp-admin/users.php

== Version 1.2.0 ==

*Register users quickly


== Changelog ==

= 2014.12.11 =
* Fix: cleaned up index page
* added redirect thank you page to plugin dir
