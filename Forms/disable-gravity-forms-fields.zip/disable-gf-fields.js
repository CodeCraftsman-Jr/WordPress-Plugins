jQuery(document).ready(function($){
	$(".disabled input").attr('disabled','disabled');
	$(".readonly input").attr('readonly','readonly');
});