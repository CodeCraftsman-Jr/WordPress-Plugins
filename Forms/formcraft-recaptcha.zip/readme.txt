=== reCaptcha Add-On for FormCraft ===
Contributors: nish@ncrafts.net
Tags: recaptcha, captcha, mailchimp form, form builder, contact form 7, form, forms, widget, contact form, email form builder, ajax form builder, captcha, file upload, newsletter form, customer support form builder, drag and drop form builder
Requires at least: 3.6
Tested up to: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add reCaptcha to your FormCraft forms.

== Description ==

This add-on allows you to add Google's reCaptcha SPAM prevention to your forms.

== Changelog ==

= 1.0 =
* Initial release