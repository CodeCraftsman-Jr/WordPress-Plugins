/******* Jquery No Conflict Function *******/
window.$ = jQuery.noConflict();

$(function(){
	$(".user_up_button_color").wpColorPicker();
	$("#git_map_color").wpColorPicker();
	$("#user_button_color").wpColorPicker();	
});