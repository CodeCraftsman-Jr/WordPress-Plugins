=== Prensalista Platform Manager ===
Contributors: prensalista
Tags: social, publishing
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This Prensalista plug-in is a companion with the instance that you can create at Prensalista.com.

== Description ==

This plugin allows posts published from Prensalista.com into your WordPress blog to keep the same username for the author. If the author on the published post doesn't exist in WordPress (check done by looking at email address), this plugin will create a new user in WordPress.
In addition, this plugin allows Prensalista instances to publish to a Custom Type. 
For more information, visit the [Prensalista](https://www. prensalista.com) and [Prensalista Help](https:// prensalista.com/help) websites.
 
== Installation ==

This section describes how to install the plugin and get it working.

1. Upload all the files to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =

* First version

 

 

