Gravity Forms Monthpicker
========

This plugin extends the Gravity Forms plugin. It allows users to add a special form of a datepicker that selects only month and year.

The JavaScript functionality is provided by [jQuery UI Month Picker](https://github.com/KidSysco/jquery-ui-month-picker/)

To use it simply install and activate the plugin and then you can add the Date (Monthpicker) field to your forms, from the Advanced Fields tab.

To style the plugin, regenerate the jquery-ui.datepicker.min.css from the jQuery UI site for datepicker and button.