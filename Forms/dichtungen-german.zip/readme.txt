=== Dichtungen (german) ===
Contributors: Manfred Kuhlemann
Tags: news, widget, sidebar, links, plugin
Requires at least: 2.9
Tested up to: 2.9.2
Stable tag: 1.0

Das Dichtungen-Plugin stellt eine Erweiterung bereit, welche verschiedene Informationen zu [Dichtungen](http://www.dichtungshersteller.info/) im Blog einblenden l&auml;sst.
Das Dichtungen-Plugin ist mit Hilfe einer Konfigurationsseite konfigurierbar.

== Description ==

Das Dichtungen-Plugin stellt eine Erweiterung bereit, welche verschiedene Informationen zu [Dichtungen](http://www.dichtungshersteller.info/) im Blog einblenden l&auml;sst.
Das Dichtungen-Plugin ist mit Hilfe einer Konfigurationsseite konfigurierbar.

== Installation ==

1. Entpacke `dichtungen-german.zip`.
2. Lade den `dichtungen-german`-Ordner in dein Verzeichnis `/wp-content/plugins` hoch.
3. Aktiviere das Plugin im 'Plugins'-Men&uuml; der Wordpress-Administration.
4. F&uuml;ge das Widget unter Design->Widgets deiner Sidebar hinzu und bearbeite die Widget-Optionen.

== Changelog ==

= 1.0 =
Initial release 2010-06-18
