=== Fancy Quotes ===
Contributors: nyousefi
Tags: bloquotes, quotes
Requires at least: 1.5
Tested up to: 2.8
Stable tag: 0.90

Converts standard BLOCKQUOTEs into Fancy Quotes.

== Installation ==

1. Download and unzip.
2. Copy the `fancy-quotes` folder to your `plugins` directory.
3. Activate in the admin panel.
4. Enjoy

== Usage ==

Add `class="fancy"` to a BLOCKQUOTE to have it converted into a Fancy Quote. Remove the class attribute to revert it back to normal.

== Frequently Asked Questions ==


= I don't like the way the fancy quotes look. How can I change that? =

The plugin folder contains the CSS definitions for the fancy quotes. Customize as you see fit.

== Screenshots ==

1. Shows the plugin in action.

== Release Notes ==

0.9 - Beta