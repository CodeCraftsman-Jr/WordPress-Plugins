=== Plugin Name ===
Contributors: Melih Guney
Donate link: http://www.melihguney.com/2008/12/26/wordpress-yeni-yil-eklentisi-v20/
Tags: flash, christmas, new, year, happy, song, js
Requires at least: 2.7
Tested up to: 2.7
Stable tag: 2.0

This plugin will create a good skin in your wordpress blog.

== Description ==

This plugin will create a perfect skin in your wordpress blog.
Adds a image and song in your template.

== Installation ==

The Happy Christmas Plugin can be installed in 3 easy steps:

	1. Unzip "Happy-christmas-plugin" archive and put all files into your "plugins" folder (/wp-content/plugins/) or to create a sub directory into the plugins folder (recommanded), like /wp-content/plugins/happy-christmas-plugin/

	2. Activate the plugin
