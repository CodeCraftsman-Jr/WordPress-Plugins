<div id="wpbo-modal3" class="wpbo-modal wpbo-center" style="width: 460px;">
	<div class="wpbo-inner" data-editable='["backgroundColor","backgroundImage","backgroundRepeat","backgroundPosition","backgroundSize","color","fontFamily"]'>
		<a class="wpbo-close" href="#" title="Close" data-editable='["backgroundColor","color"]' data-editable='["backgroundColor","color"]'>&times;</a>
		<p class="wpbo-lead wpbo-center" data-editable='["color","fontFamily","fontSize","textEdit","textAlign"]'>Subscribe to our mailling list to get the updates to your email inbox...</p>
		<div class="wpbo-textwrap" data-editable='["color","fontFamily","fontSize","tinymce","textAlign"]'>
			<p>Subscribe to our mailling list to get the updates to your email inbox...</p>
		</div>
		<hr>
		<div class="wpbo-form-group">
			<label for="wpbo_email" class="wpbo-sr-only">Enter Your Email...</label>
			<input type="email" class="wpbo-form-control wpbo-input-lg" id="wpbo_email" name="wpbo_email" placeholder="Enter your email" required data-editable='["textEdit"]'>
			<span class="wpbo-help-block" id="email-suggestions"></span>
		</div>
		<button type="submit" class="wpbo-btn wpbo-btn-block" data-editable='["backgroundColor","color","fontFamily","textEdit"]'>Subscribe</button>
	</div>
</div>