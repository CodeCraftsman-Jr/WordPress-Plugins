=== AKM Feedback Form === 

Contributors: Akaal.Media
Donate link: http://www.akaalmedia.com/
Tags: Free feedback form, Simple Contact Form, easy contact form, Easy to use, wordpress, wordpress plugin, top plugins, best plugins, contact form, jquery form.

Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Just insert the [AKMFORM] shortcode in pages of your WordPress site to display a simple and easy to use Feedback form.


== Description == 


Install and activate the plugin. 
Then add the [AKMFORM] shorttag in pages and posts to display a simple and easy to use Feedback form. This Plugin is best to use in sidebar. All Emails are directly forward to admin's Email address
This feedback form includes jquery form validation.


== Installation == 


Install and activate the plugin.
Then add the [AKMFORM] shorttag in pages and posts. 

Or, if you prefer, a Widget form is provided too.

No options, no configuration necessary - message is sent directly to the site administrator's email.

== Screenshots ==

1. Screenshot of Plugin
2. Screenshot of Plugin with validations
