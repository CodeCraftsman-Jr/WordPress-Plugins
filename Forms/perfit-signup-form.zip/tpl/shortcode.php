
<script>
(function(window, document, $){
})(window, document, jQuery);
</script>

<!-- Optin-In Code Start -->
<div id="optin-%%OPTIN%%" %%MODE%%></div>
<link rel="stylesheet" type="text/css" href="https://optin.myperfit.com/res/css/%%ACCOUNT%%/%%OPTIN%%.css">
<script type="text/javascript" src="https://optin.myperfit.com/res/js/%%ACCOUNT%%/%%OPTIN%%.js"></script>
<!-- Optin-In Code End -->
