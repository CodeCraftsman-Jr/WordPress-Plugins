    <div class="p-optin">
        <div class="p-header"></div>
        <div class="p-body">
            <p>
                
            </p>
            <input name="redirect" value="" type="hidden">
                <div class="p-field">
                    <label>
                        <span>
                            Nombre y apellido
                        </span>
                    </label>
                    <input name="fields[1]" placeholder="Nombre y apellido" type="">
                </div>
                <div class="p-field">
                    <label>
                        <span>
                            Email
                        </span>
                    </label>
                    <input name="fields[3]" placeholder="Email" type="">
                </div>
                <div class="p-field">
                    <label>
                        <span>
                            Origen
                        </span>
                    </label>
                    <input name="fields[6]" placeholder="Origen" type="">
                </div>
            <div class="p-interests">
            </div>
            <p></p>
            <button type="button"></button>
        </div>
    </div>
