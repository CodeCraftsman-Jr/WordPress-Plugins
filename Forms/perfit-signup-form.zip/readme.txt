=== Perfit Signup Form ===
Contributors: PerfitDev
Tags: form, subscription
Requires at least: 3.0.1
Tested up to: 4.2.4
Stable tag: 1.1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Header tagline: Inserta un formulario de suscripción en tu página

Inserta un formulario de suscripción en tu página

== Description ==

A través del plugin de Perfit para Wordpress vas a poder incorporar formularios de suscripción a tu sitio web, blog o ecommerce basado en WordPress. Gracias a estos formularios, tus visitas van a poder suscribirse y pasar a formar parte de tus listas de contactos. Lo mejor es que podés activar este plugin de manera muy sencilla, ¡y sin tocar una línea de código!

Es posible personalizar los campos y los textos de los formularios, disponibles en varias modalidades: embebido, popup con botón o popup automático.

== Installation ==

La manera más sencilla es utilizar el instalador de plugins de wordpress.

O, si preferís instalarlo manualmente:
1. Descargá el archivo comprimido que contiene el plugin.
2. Descomprí el contenido del archivo dentro de una carpeta en /wp-content/plugins/
3. Ya debería aparecer disponible en el listado de plugins, solo resta activarlo.

== Screenshots ==

1. Recién instalado, sin optins creados
2. Pantalla de login
3. Listado de optins
4. Creación/modificación de un optin: Datos generales
5. Creación/modificación de un optin: Diseño del formulario -Detalles-
6. Creación/modificación de un optin: Diseño del formulario -Campos-
7. Creación/modificación de un optin: Diseño del formulario -Cambio de nombre de un campo-
8. Creación/modificación de un optin: Diseño del email de confirmación
9. Se puede agregar como widget a cualquier widget area
10. Desde la redacción de un post, se dispondrá de un botón para agregarlo fácilmente
11. Al hacer click en el botón de la barra de un post, se puede seleccionar el optin
