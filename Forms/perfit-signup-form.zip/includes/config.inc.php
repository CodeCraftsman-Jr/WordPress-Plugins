<?php

$config = array(
    'baseUrl' => 'https://apitest.myperfit.com',
    'token' => '7c55e689498455c58077454006ebe888',
);

$perfitConfig = array(
//    'url' => 'https://apitest.myperfit.com',
    'url' => 'https://api.myperfit.com',
    'version' => 2,
    'language' => 'es-es',
);

