jQuery(document).ready(function($){

    /*var $expertSettings = jQuery(' #affilinet_ywidgetpos, #affilinet_ywdensity,#affilinet_ywcap');

    var toggleExpertSettings = function (){
        if (!$('#affilinet_extended_settings').is(':checked')) {
            $('#affilinet_extended_settings_table').addClass('hidden');
            $expertSettings.val('');

        }else {
            $('#affilinet_extended_settings_table').removeClass('hidden');;
        }
    };
    $('#affilinet_extended_settings').on('change', toggleExpertSettings);


    toggleExpertSettings();

    $('.affilinet_colorpicker').wpColorPicker();

    */


});