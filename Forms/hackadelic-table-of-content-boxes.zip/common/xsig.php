<?php if (is_home()) : ?>
<div style="display:none">This website uses a Hackadelic PlugIn, <?php echo "$plugin->title $plugin->version" ?>.</div>
<?php endif ?>