=== Simple jQuery Lazy Load ===
Contributors: tricksofit
Tags: images,lazy load, jquery, optimization
Requires at least: 3.6
Tested up to: 4.2.2
Stable tag: 1.0.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple jQuery Lazy Loading to images for WordPress

== Description ==

This plugin allow you to add lazy loading to your WordPress images. 

= Features =

 - Simple jQuery Lazy Image Loading to WordPress
 - It helps in Optimization
 
== Installation ==

unzip archive to wp-content/plugins directory, and activate it.

== Frequently Asked Questions ==

= how to use this plugin =

Just activate the plug-in and that's it.

== Screenshots ==


== Changelog ==

= 1.0.0 =
* Released on 27/06/2015
* Initial release of Simple jQuery Lazy Load.


== Upgrade Notice ==

= 1.0.0 =
Initial release of Simple jQuery Lazy Load.

