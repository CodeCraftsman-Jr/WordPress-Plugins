=== Beauty Contact Form ===
Contributors: Dilip Kumar
Donate link: 
Tags: beautiful-contact-form,store-contact,store-form-data,contact,contact-us,contact-easy,email-us,email
Requires at least: 2.9.2
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 This Contact form plugin store the user submitted data into the database and display the stored data in frontend. 


== Description ==

It is an simple and easy contact form, that doesn’t require any additional settings. All you need is just to activate the plugin and insert the shortcode [show_tagwebs_beauty_form] into the text. This is the plugin for contacting the admin of website that the data are stored in the wordpress data base,and data can be viewed from front end using shortcode.
 
For Support please visit below website

* [Live Demo click here](http://demo.uholder.com/plugin/beauty-contact-popup-form/) 

* Check official website [uholder.com](http://uholder.com/) for more info.



== Installation ==
 
* Extract the zip file and just drop the contents in the wp-content/plugins/ directory.
* Activate the Plugin from Plugins page.
* Use the short-code for displaying Beauty contact form [show_tagwebs_beauty_form] 
* Use the short-code for displaying Beauty contact form submitted data [display_tagwebs_submited_data]




== Frequently Asked Questions ==

For Plugin support please post your questions [Support Form](http://demo.uholder.com/plugin/beauty-contact-form-2/ "Support Form")

Do you have questions or issues about beauty-contact-form? [Contact Me](tagwebs@live.com)


=How it is work?=


When user submit the data through the form, the plugin create a table in the site hosted database and then it store the data in the table. 
Using this [show_tagwebs_beauty_form] shortcode we can view the data stored in the database 


== Screenshots ==

1. Contact form display with Validation
2. Contact form display with Success message
3. Contact form submitted data display in page using shortcode
4. Contact form submitted data admin panel view

== Changelog ==

= version 1.0 =
Implemented with basic functionalities Ability to submit data through form. Storing the data and displaying the data in admin panel also in pages / post through shortcode

== Upgrade Notice ==
Currently not available.

== CREDIT ==

1.This plugin was developed by [Dilip kumar]


== CONTACT ==

Dilip kumar [tagwebs.net/contact-us]