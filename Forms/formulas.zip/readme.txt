=== Formulas ===
Contributors: amandato, pluginspodcast
Donate link: http://www.pluginspodcast.com/
Tags: cars, automotive, compression, compression ratio, static compression ratio, engine displacement
Requires at least: 3.5
Tested up to: 4.2
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automotive formulas for car enthusiast web sites

== Description ==

Automotive formulas for car enthusiast web sites. Formulas currently include engine displacement and static compression ratio.

=  Features  =
- Engine displacement calculator with the `[formulas ed="true"]` shortcode.
- Static compression ratio calculator with the `[formulas cr="true"]` shortcode.
- Calculators are responsive friendly.
- More features on the way.


== Installation ==

1. Copy/Upload the entire `formulas` directory from the downloaded zip file into the /wp-content/plugins/ directory.
1. Activate the "Formulas" plugin in the 'Plugins' menu in WordPress
1. Enjoy.

== Frequently Asked Questions ==
None at this time.



== Screenshots ==
No screen shots at this time.


== Changelog ==

= 0.1 =
* Released on TBA
* First release

== Upgrade Notice ==

= 0.1 =
None at this time.

