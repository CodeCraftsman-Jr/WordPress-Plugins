function buzzsproutPickHandler(linkElement) {       
    send_to_editor(jQuery(linkElement).attr("data-short-tag")); 
}