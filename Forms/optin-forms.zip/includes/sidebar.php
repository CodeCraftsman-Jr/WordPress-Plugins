<?php ?>

                <div class="optinforms-ad-product">
                    	<h4><a href="https://optinlock.com/?utm_source=sidebar&utm_medium=link&utm_campaign=OptinForms" target="_blank">Get More Subscribers with Optin Lock</a></h4>
                        <p>Boost your conversion rates by locking parts of your posts and pages. Serve your premium content to subscribers only.</p>
                        <ul>
                            <li>Create multiple lead-magnets</li>
                        	<li>Create unlimited optin forms</li>
                            <li>Create unlimited lightbox popups</li>
                            <li>Analyze built-in performance statistics</li>
                        </ul>
                    	<div class="optinforms-ad-product-button"><a href="https://optinlock.com/?utm_source=sidebar&utm_medium=button&utm_campaign=OptinForms" target="_blank">Get Optin Lock Now!</a></div>
                </div><!--optinforms-ad-product-->
                <div class="optinforms-ad">
                    <ul>
                    	<li><a href="http://wordpress.org/support/plugin/optin-forms" target="_blank"><?php echo __('Get support', 'optinforms'); ?></a></li>
                        <li><a href="https://wordpress.org/support/view/plugin-reviews/optin-forms" target="_blank"><?php echo __('Rate the plugin on WordPress.org', 'optinforms'); ?></a></li>
                        <li><a href="https://www.twitter.com/brs" target="_blank"><?php echo __('Follow me on Twitter', 'optinforms'); ?></a></li>
                        <li><a href="https://plus.google.com/+BorisBeo" target="_blank"><?php echo __('Follow me on Google+', 'optinforms'); ?></a></li>
                    </ul>
                </div><!--optinforms-ad-->
                
<?php ?>