=== Novak Solutions JavaScript Infusionsoft Webforms ===
Contributors: joeynovak
Donate link: http://novaksolutions.com/
Requires at least: 2.0.2
Tested up to: 3.3.2
Stable tag: 0.9.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin has been discontinued. Please use the Infusionsoft Web Form JavaScript plugin instead.

== Description ==

This plugin has been discontinued. Please use the [Infusionsoft Web Form JavaScript](http://wordpress.org/plugins/infusionsoft-web-form-javascript/) plugin instead.

== Changelog ==

= 0.9.2 =
* Plugin discontinued. Use [Infusionsoft Web Form JavaScript](http://wordpress.org/plugins/infusionsoft-web-form-javascript/) instead.

= 0.9.1 =
* Initial Release.
