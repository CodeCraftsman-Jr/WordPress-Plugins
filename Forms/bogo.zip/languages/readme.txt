== Translations ==

Translation files in this folder have been created for translating Bogo itself, by the following volunteers:

* Japanese (ja) - [Takayuki Miyoshi](http://ideasilo.wordpress.com)
* Romanian (ro_RO) - [Inbox Translation](http://inboxtranslation.com)

If you have created your own translation, or have an update of an existing one, please send it to me so that I can bundle it into the future release of Bogo.

My email address is: Takayuki Miyoshi <takayukister@gmail.com>
