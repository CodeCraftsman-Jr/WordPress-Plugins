//ABSPATH necessari?  !defined( 'ABSPATH') && 
if(!defined('WP_UNINSTALL_PLUGIN') )
    exit();

delete_option('dotepub_opts');