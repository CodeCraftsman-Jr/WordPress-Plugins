<?php
_deprecated_file( basename(__FILE__), '1.07.11', 'FrmFieldsHelper::replace_shortcodes' );

echo FrmFieldsHelper::replace_shortcodes($field['custom_html'], $field, $errors, $form);