# CHANGELOG

## Version 1.0.6
### 2014-10-14

* Updated last wpXtreme/WPDK framework
* Improved realtime refresh row when 'swipe' status
* Improved count down
* Minor fixes

## Version 1.0.5
### 2014-09-19

* Added real time count down
* Updated last wpXtreme/WPDK framework
* Minor fixes

## Version 1.0.4
### 2014-09-02

* Important updated and alignment to last version of WPDK framework

## Version 1.0.3
### 2014-08-29

* Maintenance release for last wpXtreme plugin version

## Version 1.0.2
### 2014-07-13

* Alignments for wpXtreme v1.3.0

## Version 1.0.1
### 2014-04-28

* Updated kickstart.php to fix potential error when get the mysql version

## Version 1.0.0
### 2014-03-27

* First public release