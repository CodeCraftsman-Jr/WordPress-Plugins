## Preferences

This folder contains the preferences object model and the preferences view controller for UI.