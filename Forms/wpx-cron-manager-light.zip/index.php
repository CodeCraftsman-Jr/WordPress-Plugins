<?php
// Silence is golden or you can use this file for extra doxygen documentation