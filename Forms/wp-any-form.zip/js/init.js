jQuery(function ($) {
    $("input.wp_any_form_jslib[type=hidden]").each(function() {
        var jslibval = $(this).val();
    	switch(jslibval) {
    	   	/*case 'testvalue':
                alert('test value');
                break;*/
	    }
    });    
});