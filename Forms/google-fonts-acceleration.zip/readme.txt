﻿=== 谷歌字体与Gravatar头像加速===

Contributors:cqdaidong

Donate link: http://www.iGeekLab.com/

Tags:Google,CDN,加速,字体,Gravatar,公共库,字体库

Requires at least:1.0

Tested up to: 4.2.3
Stable tag: 4.2.3
License: GPLv2 or later
License URI:http://www.gnu.org/licenses/gpl-2.0.html


本插件可针对中国大陆地区访客较多的网站调用的Google前端库以及字体库服务和Gravatar头像服务进行替换加速,并且支持SSL（https）调用加速源，本插件支持以后的所有Wordpress版本更新，无论您使用的什么版本Wordpress都可以使用本插件，所以请无视“未在您的WordPress版本中测试”提示。

== Description ==

本插件可针对中国大陆地区访客较多的网站调用的Google前端库以及字体库服务和Gravatar头像服务进行替换加速,并且支持SSL（https）调用加速源。

== Installation ==


上传插件到/wp-content/plugins/目录
在插件列表中启用它



== Frequently Asked Questions ==


加速失败请先确认是否有启用其他同类插件或者代码导致互相冲突，如果您能提供更快速的加速源地址并且愿意分享可邮件联系我，我们将增加多个加速源地址切换功能。   邮箱：cqdaidong@gmail.com

== Screenshots ==

启用插件即可自动加速,无设置界面。

== Changelog ==



【1.6 】由于众所周知的原因，我们在维护Google公共库加速的同时，新增了对Gravatar头像的加速。您无需再安装多个插件以及繁琐的修改主题文件，本插件占用极小,对WordPress性能影响可忽略不计。


【1.7 】更换了我们的全新加速源地址,并且支持SSL加密调用加速源，解决之前不支持SSL调用，使得Https访问网站提示风险的问题。（之前的加速源依然有效，但不支持SSL）

== Upgrade Notice ==

= 
1.7=
* 更换了我们的全新加速源地址,并且支持SSL加密调用加速源，解决之前不支持SSL调用，使得Https访问网站提示风险的问题。（之前的加速源依然有效，但不支持SSL）