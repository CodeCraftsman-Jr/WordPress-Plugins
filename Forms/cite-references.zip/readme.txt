=== Cite references ===
Contributors: Dejan SEO
Tags: citing reference, cite referencing, online quotations
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin that will include cite referencing on your site. 

== Description ==

A plugin that will include cite referencing on your site. Cite references plugin will only work if the author has a first and last name set, and only on blog posts. You can disable the option for each individual post in post administration.

== Installation ==

1. Upload `citing.zip` to the `/wp-content/plugins/` directory
2. Unpack .zip archive
3. Activate the plugin through the 'Plugins' menu in WordPress