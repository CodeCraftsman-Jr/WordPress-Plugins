Surbma - Datepicker localization for Gravity Forms
==============================

Localize the Datepicker field with this plugin's automatic localization.
