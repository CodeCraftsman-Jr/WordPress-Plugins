=== FW Fussnoten ===
Contributors: Tikolan
Donate link: http://www.wieser.at/
Tags: fussnoten, content
Tested up to: 3.8.1
Stable tag: 0.6.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Fussnoten ermöglich mit Categorien als Filter, einfach Content als Fussnoten anzulegen und bei Beiträge und Seiten zu nutzen.
== Description ==

mit diesem FW Fussnoten Plugin können flexible Fussnoten für ausgewählte Beiträge erstellt werden.


Mit hinzufügen wird im Textfeld des Fussnoten Editor der Gewünschte Inhalte erstellt und gestaltet, dabei können Texte, Bilder und auch Shortcodes wie bei Beiträge zusammengestellt werden.
Als Selektor wird Kategorie angewählt, bei allen Beiträgen dieser gleichen Kategorie wird der Inhalt der Fussnote angezeigt.
mit dem mitglieferten Shortcode [cf name="metaboxfieldname"] können Metaboxfields (benutzerdefinierte Felder) eingetragen werden.
== Installation ==



1. Upload `Fw Fussnoten` to the `/wp-content/plugins/` directory - Lade das Plugin 'FW Fussnoten' in das Plugin Directory
1. Activate the plugin through the 'Plugins' menu in WordPress - Aktiviere das Plugin
1. Write New Fussnote - schreibe eine neue Fussnote

== Frequently Asked Questions ==

= Wie werden Fussnoten bei Beiträge zugeordnet

die Fussnoten wird einer Category zugeordnet, alle Beiträge/Seiten diese Category erhalten diese Fussnote

= Warum braucht man Fussnoten Plugin =

um Verschiedene Portfolios oder Fixe  Bereiche zu erstellen

== Screenshots ==


== Changelog ==

= 0.6 =
* Fussnote wurde Multifussnoten
* Shortcode

== Upgrade Notice ==
=0.6.4 =
* korrekturen

= 0.6 =

* Multifussnoten
* Shortcode



