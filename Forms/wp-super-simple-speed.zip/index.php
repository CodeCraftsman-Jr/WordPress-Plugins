<?php

/**
 * Nothing much going on here! 
 */
 
?>

<br /><br />
<center><a href="http://wp-superformance.com">WP Superformance - Instantly supercharges your WordPress page speed and performance grade</a></center>