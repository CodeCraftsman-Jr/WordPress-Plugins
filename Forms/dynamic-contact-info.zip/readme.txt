=== Dynamic Contact Info ===
Contributors: Sukhchain, CodeVilsTech
Donate link:http://www.sukhchain.tk/donate-online/
Tags: dynamic , contact, info, upload, sidebar
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 1.8
License:GPLv2 

== Installation ==
1.Download the plugin from wordpress site

2.Install it from plugins menu

3.You are done

== Description ==

A simple wordpress plugin which will make your site's contact info dynamic even if your theme does not support dynamic contact info.
Use shortcode [DCI field="tel"], [DCI field="mobile"] to display contact info. Now you can add your own custom fields with this plugin.

* MU Compatible
* Dynamic Contact Info including telephone, email, fax, mobile, address, postcode etc
* Use Shortcode [DCI field="tel"], [DCI field="mail"] and so on.

== Frequently Asked Questions ==

= Where can i find the nav menu =

Once install you can find a new menu on left side with name Dynamic Contact Info.

== Screenshots ==

1. This screenshot will show the location of nav menu on left side in your admin panel

2. This will show you the actual plugin with shortcodes.

3. Now you can add your own custom fields with custom shortcode.

== Changelog ==

= 1.1 =
* A Change In Author Info

== Upgrade Notice ==

= 1.1 =
* A minor change in author info.

= 1.2 =
* Changes in navigation menu.

= 1.4 =
* Changes in UI.

= 1.5 =
* Added new feature now users can add own custom fields with shortcode.

== Upgrade Notice  ==

= 1.5 =
* Now users can add their own custom fields with custom shortcode.

= 1.6 =
* Fix minor bug with shortcode.

= 1.7 =
* Urgent Bug Fix.

= 1.8 =
* Urgent Bug Fix With Custom Fields.