﻿=== G-prettify ===
Contributors: 云落
Donate link: http://googlo.me
Tags: 代码高亮, prettify, code, highlight
Requires at least: 3.5
Tested up to: 4.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress最简单，最小巧的代码高亮插件/WordPress simplest, most compact, preferably with code highlighting plug

== Description ==
WordPress simplest, most compact, preferably with code highlighting plug, only one can get everything pre labels, compatible with all standard google-code-prettify code highlighting scheme, this plug-in HTML editor environment only by using the visual editor user, do not use! ! !
=================下面是中文========================
WordPress最简单，最小巧，最好用的代码高亮插件，只需要一个pre标签就可以搞定一切，兼容所有的标准的google-code-prettify 代码高亮方案，本插件仅限在HTML编辑器环境下使用，可视化编辑器使用者勿用！！！
== Installation ==

1，下载(Download)
2，解压(unzip)
3，上传(upload)
4，启用(enabled)
5，OVER
== Screenshots ==

1. 安装完毕编辑器出现的按钮
2. 直接包围代码既可
3. 另外一个按钮是用于解决&lt;/pre&gt;对代码的影响
4. 完美显示&lt;/pre&gt;
5. 可以兼容多种标签包围方法（可以自己自定义）
6. 不一样的标签，一样的效果

== Changelog ==
= 2.0.0 =
# 上传插件，本来插件早就发不在开源中国的
= 3.0.0 =
# 修复了无法使用行号的问题
= 4.0.0 =
# 修复了某些主题的很细微的错位