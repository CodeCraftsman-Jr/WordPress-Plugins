=== Contact Form 7 Star Rating ===
Contributors: themelogger
Tags: Star Rating, Stars, Rating, Contact Form 7, form, forms, contactform7, contact form, cf7, cforms ii, cforms, Contact Forms 7, Contact Forms, contacted, contacts,jQuery Star Rating
Requires at least: 3.8
Tested up to: 4.2.4
Stable tag: trunk
License: GPLv2

This plugin adds Star Rating fields to Contact Form 7.

== Description ==

This plugin adds Star Rating fields to Contact Form 7.

<h4>Visit the official <a href="http://www.themelogger.com/contact-form-7-star-rating-plugin/" rel="dofollow">Contact Form 7 Star Rating page</a> for viewd demo & additional information</h4>

== Installation ==
1. Upload plugin files to your plugins folder, or install using WordPress built-in Add New Plugin installer
2. Activate the plugin
3. Edit a form in Contact Form 7
4. Choose "Star Rating" from the Generate Tag dropdown
5. Follow the instructions on the page

= 1.7 =
* Tested WP up to: 4.2.4
* Tested CF7 up to: 4.2.2

= 1.6 =
* Tested up to: 4.0

= 1.5 =
* css & js loading paths corrected

= 1.4 =
* js loading paths corrected

= 1.3 =
* Description update

= 1.2 =
* Description update

= 1.1 =
* Unused files removed

= 1.0 =
* Initial release
