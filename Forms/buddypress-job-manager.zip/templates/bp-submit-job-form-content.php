<?php

/**
 * BuddyPress Job Manager Submit Job Form Screens
 *
 * @package Buddypress Job Manager
 * @subpackage Job Manager Screens Template
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
<?php echo do_shortcode( '[submit_job_form]' ); ?>