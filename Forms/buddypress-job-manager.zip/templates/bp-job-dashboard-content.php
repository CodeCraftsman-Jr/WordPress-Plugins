<?php

/**
 * BuddyPress Job Manager Job Dashboard Screens
 *
 * @package Buddypress Job Manager
 * @subpackage Job Manager Screens Template
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
<?php echo do_shortcode( '[job_dashboard]' ); ?>