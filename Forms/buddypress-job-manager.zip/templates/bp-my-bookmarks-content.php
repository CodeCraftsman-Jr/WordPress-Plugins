<?php

/**
 * BuddyPress Job Manager My Bookmarks Screens
 *
 * @package Buddypress Job Manager
 * @subpackage Job Manager Screens Template
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
<?php echo do_shortcode( '[my_bookmarks]' ); ?>