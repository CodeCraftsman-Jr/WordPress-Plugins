<?php

/**
 * BuddyPress Job Manager Jobs Screens
 *
 * @package Buddypress Job Manager
 * @subpackage Job Manager Screens Template
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
<?php echo do_shortcode( '[jobs]' ); ?>