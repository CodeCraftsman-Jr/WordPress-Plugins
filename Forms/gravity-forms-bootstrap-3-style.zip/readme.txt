=== Bootstrap Gravity Forms ===
Contributors: abrudtkuhl
Tags: bootstrap, gravity forms
Requires at least: 3.5
Tested up to: 4.2.1
Stable tag: trunk
License: GNU GENERAL PUBLIC LICENSE
License URI: https://github.com/abrudtkuhl/WordPress-Bootstrap-Gravity-Forms/blob/master/LICENSE

Adds Bootstrap styles to Gravity Forms

== Description ==
Enqueues a stylesheet that adds Bootstrap styles to Gravity Forms forms.

== Screenshots ==
1. A Gravity Forms form with Bootstrap 3 Style applied

== Installation ==
1. Enable Plugin
2. In Gravity Forms Settings, turn off \"Output CSS\"
3. In Gravity Forms Settings, turn on \"Output HTML5\"

== Changelog ==
= 0.3 =
Fixed multi step form button styles

= 0.2 =
Fixed CSS Path https://github.com/abrudtkuhl/WordPress-Bootstrap-Gravity-Forms/pull/3

= 0.1 =
Plugin Boom
