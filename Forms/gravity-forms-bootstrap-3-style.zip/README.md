Bootstrap Style for Gravity Forms
=================================

A WordPress plugin to apply Bootstrap 3 styles to Gravity Forms plugin

Usage
-----
1) In Gravity Forms Settings, turn off "Output CSS"  
2) In Gravity Forms Settings, turn on "Output HTML5"  
3) Enable Plugin  
4) Drink A Beer  

Changelog
---------
0.3 - Fixed multi step form button styles
0.2 - [Fixed CSS Path](https://github.com/abrudtkuhl/WordPress-Bootstrap-Gravity-Forms/pull/3)
0.1 - Plugin Boom


Thanks
------
[@DevinWalker](https://gist.github.com/DevinWalker/7110951#file-gravity-forms_bootstrap)  
[@wesbeale](https://github.com/wesbeale)
