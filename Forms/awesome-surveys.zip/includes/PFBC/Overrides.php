<?php
class FormOverrides extends Form
{

 protected function renderJSFiles()
 {

  return null;
 }

 protected function renderCSSFiles()
 {

  return null;
 }

 protected function renderCSS()
 {

  return;
 }

 protected function renderJS()
 {
  return;
 }
}