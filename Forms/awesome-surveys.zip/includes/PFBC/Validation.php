<?php
abstract class Validation extends Base {
}
