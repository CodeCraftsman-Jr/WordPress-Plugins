<?php
/*
 These are some strings that were used in an earlier version - it's reasonable
to expect that they may be used again, so preserving the strings in this
file so that translators don't have to do this work over again if it's
already been done
*/

_e( 'Donate to the future development of this plugin:', 'awesome-surveys' );
_e( 'How To Video', 'awesome-surveys' );
_e( 'Debug', 'awesome-surveys' );
_e( 'Clone this survey', 'awesome-surveys' );
_e( 'Delete', 'awesome-surveys' );
_e( 'Review the Awesome Surveys Plugin', 'awesome-surveys' );
_e( 'Fork Me on GitHub', 'awesome-surveys' );
_e( 'Awesome Surveys on github', 'awesome-surveys' );
_e( 'Support for Awesome Surveys', 'awesome-surveys' );
_e( 'Review the Awesome Surveys Plugin', 'awesome-surveys' );
_e( 'Rate Awesome Surveys', 'awesome-surveys' );
_e( 'Shout it From the Rooftops!', 'awesome-surveys' );
_e( 'Tweet this plugin', 'awesome-surveys' );
_e( 'Awesome Surveys News', 'awesome-surveys' );
