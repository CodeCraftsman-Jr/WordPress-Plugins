=== Freedom of Information ===
Contributors: bbqiguana 
Donate link: http://www.bbqiguana.com/donate/
Tags: fun, content, post, redact, black
Requires at least: 2.1
Tested up to: 2.8.5
Stable tag: 0.2

A fun plugin that filters the content of your post and redacts terminology that certain "nefarious conspirators" wouldn't want getting out.

== Description ==

Freedom of Information, my second WordPress plugin, is just for fun. It filters the content of your post and redacts terminology that certain "nefarious conspirators" wouldn't want getting out.  Everything is a conspiracy.  Great for the black helicopter crowd!

= Features =
* Options page
* Choose a custom RegEx pattern for matching terms to redact
* Choose a custom HTML tag and/or CSS result for redacting
* Apply to all post or select posts by use of custom field


== Installation ==

1. Download the Freedom of Information zip file.
2. Extract the files to your WordPress plugins directory.
3. Activate the plugin via the WordPress Plugins tab.

== Frequently Asked Questions ==

none

== Screenshots ==

1. A displayed post on the main page, after being redacted.

== Changelog ==

= 0.2 =
* Added options page
* Allow admin to choose a custom RegEx pattern for matching terms to redact
* Allow admin to choose a custom HTML tag and/or CSS result for redacting
* Can be applied to all posts or select posts by use of custom field

= 0.1 =
* Initial version.
