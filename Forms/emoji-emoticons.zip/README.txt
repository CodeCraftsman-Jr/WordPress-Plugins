=== Emoji Emoticons ===
Contributors: gbaptistas
Tags: emoji, emoticons
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 0.1
License: MIT
License URI: http://opensource.org/licenses/MIT

Support for Emoji Emoticons: http://www.emoji-cheat-sheet.com/

== Description ==

Support for Emoji Emoticons: http://www.emoji-cheat-sheet.com/

See: https://github.com/gbaptista/emoji-emoticons

== Installation ==

Install Emoji Emoticons either via the WordPress.org plugin directory, or by uploading the files to your server.