=== Google Play Appbox ===
Contributors: Marcelismus
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=SH9AAS276RAS6
Tags: google play, google, android, apps, apple, app store, ios, windows, windows phone, mobile, windows store, androidpit, blackberry, appworld, appbox, firefox, firefox marketplace, chrome, chrome web store
Requires at least: 3.4
Tested up to: 3.5
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0

This plugin will not be developed further and therefore can not be downloaded even. Please use WP-Appbox instead.


== Description ==

This plugin will not be developed further and therefore can not be downloaded even. Please use [WP-Appbox](http://wordpress.org/extend/plugins/wp-appbox/ "WP-Appbox") instead.