=== Contact Form7: Autocomplete ===
Contributors: Tran Bang
Tags: wordpress, autocomplete, contact form 7, forms, jqueryui
Requires at least: 3.6.1
Tested up to: 4.2.2
Stable tag: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enables adding a date field for Contact Form 7 Wordpress Plugin using jQuery UI\'s
autocomplete

<strong>Requires Contact form 7 4.2 or higher</strong>

== Installation ==
Please follow the [standard installation procedure for WordPress plugins](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins).

== Screenshots ==
1. The Autocomplete generator tag
2. Value filter
3. Value filter 