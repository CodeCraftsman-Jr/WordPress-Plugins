function cp_contactformpp_insertForm() {
    send_to_editor('[CP_CONTACT_FORM_PAYPAL]');
}