=== Plugin Name ===
Tags: cache, performance, combine, combine css, combine javascript
Requires at least: 3.9
Tested up to: 3.9
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ultimate Performance Boost For Your Site. Merge and cache css/javascript files and reduce server request up to 90%.

== Description ==

Features

*   Combine, minify and cache css files
*   Combine and cache javascript files - in header and footer
*   Doing this job automatically

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `2kb-performance` folder to the `/wp-content/plugins/` directory
1. Activate 2kb-performance plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.1.0 =
Fixed bug with javascript extra data. Now it is not included in the minified version.
= 1.0.0 =
Initial realise version.