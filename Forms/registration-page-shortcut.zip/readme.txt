=== Registration Page Shortcut ===
Contributors: phplaw
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=phplaw%40gmail%2ecom
Tags: registration, shortcut, page
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin allow you to create a page that will display registration form for your user registers.

== Description ==

This plguin allow you to show a registration form for a specific page,
It is really simple just add [registration_form] shortcut to content of a page.
If you have any question, suggest features for this plugin,
Please let me know by send me an email: phplaw@gmail.com
or you can send message to me via Skype: conan_tpn

== Installation ==
How to install and config for this plugin.

1. Upload `registration-page-shortcut.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
2. Create a page that you want to display registration form.
3. Add shotcut [registration_form] to this page content
4. Add menu for this page, take a look and enjoy your registration page.


== Changelog ==

= 1.0 =
* Add plugin to wordpress svn on 20150519