=== Light Comment Form ===
Contributors: karlis.upitis
Tags: comments, form, floating label
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

transforms your old default comment form - to new one.
Credits for the concept to Matt D. Smith (twitter: @mds)

== Description ==

Transforms your old default comment form - to new one.

= Features: =
* uses less space;
* looks simple & sexy;
* "responsive friendly" input fields;
* supports different font families;

= Browser support: =
* Safari
* Chrome
* Firefox
* Opera
* IE
* iPhone Safari

= Tested on themes: =
* Decode by @ScottSmith
* Twenty Fourteen by @Wordpress
* Twenty Thirteen by @Wordpress
* Twenty Twelve by @Wordpress

== Screenshots ==

1. Wordpress comment form Before and After installing this plugin.