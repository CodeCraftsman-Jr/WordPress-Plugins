document.getElementById("uploadBtn").onchange = function () {
    document.getElementById("uploadFile").value = this.value;
};
document.getElementById("fax_icon").onchange = function () {
    document.getElementById("fax_text").value = this.value;
};
document.getElementById("email_icon").onchange = function () {
    document.getElementById("email_text").value = this.value;
};
document.getElementById("mobile_icon").onchange = function () {
    document.getElementById("mobile_text").value = this.value;
};
document.getElementById("address_icon").onchange = function () {
    document.getElementById("address_text").value = this.value;
};