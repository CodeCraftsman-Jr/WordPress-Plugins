=== clean it up ===
Contributors: onmouseenter
Tags: Post, plugin, category, tag, comments, comment, posts, admin, page, pages, wordpress, database, table, optimize, feed, rss, cache
Requires at least: 2.8
Tested up to: 4.2
Stable tag: 0.0.5
License: GPLv2

Clean It Up is a WordPress database cleanup and optimization plugin which helps you to optimize your wordpress database tables.

== Description ==

This plugin helps you to remove empty tag, empty category, autodraft, post revision, spam comments, unapproved comments, transient and various items in the trash can within a single click. It also has a function which helps you to optimize
the wordpress database table.
  
== Frequently Asked Questions == 

= How this plugin can help us to optimize our wordpress database? = 

By deleting the unwanted data from the wordpress tables, we will manage to save lots of database's spaces and thus increased the loading speed of our blog. 

= If I have problem using this plugin, where can I ask for help? =

You can visit the main plugin page and leaved your question under comment then I will reply to you as soon as possible. 

== Installation ==

1) Download this plugin then activated it.

== Upgrade Notice ==

Please upgrade immediately to enjoy the new features included in this latest version.

== Changelog ==

= 0.0.5 =

* Include the remove draft post feature

= 0.0.4 =

* Bug fix

= 0.0.3 =

* Bug fix

= 0.0.2 =

* Incl the remove rss cache feature

= 0.0.1 =

* First official release