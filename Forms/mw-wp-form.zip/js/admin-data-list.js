/**
 * list-table
 */
jQuery( function( $ ) {
	var wp_list_table = $( '.wp-list-table' );
	wp_list_table.wrap( '<div class="mw-wp-form-wp-list-table" />' );
} );