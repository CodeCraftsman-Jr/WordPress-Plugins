<style type="text/css">
#normal-sortables {
	display: none;
}
</style>