<style type="text/css">
h2 a.add-new-h2 {
	display: none;
}
</style>