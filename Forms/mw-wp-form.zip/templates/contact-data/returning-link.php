<p>
	<a href="<?php echo $link; ?>"><?php esc_html_e( '&laquo; Back to the list', 'mw-wp-form' ); ?></a>
</p>