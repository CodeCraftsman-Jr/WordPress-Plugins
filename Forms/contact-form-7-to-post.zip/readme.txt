=== Contact Form 7 to Post ===
Contributors: bastho
Donate link: http://ba.stienho.fr/#don
Tags: contact form 7, contactform7, cf7, Post, edit on front, post on front
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Save contact form 7 submissions as new posts

== Description ==

Save each [contact form 7](https://wordpress.org/plugins/contact-form-7/) submission as a new post.

This feature allow non logged-in users to create new posts within the canvas you will define.

Some options are customizable:

* Post type
* Post status can be **draft** or **published**
* Both title and content are editable with CF7 shotcodes, just like native emails.

== Installation ==

1. Upload `event-post` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress admin

== Changelog ==

= 1.0 =
* Initial release
