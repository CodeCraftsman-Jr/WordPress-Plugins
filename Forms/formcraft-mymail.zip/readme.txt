=== MyMail Add-On for FormCraft ===
Contributors: nish@ncrafts.net
Tags: MyMail, newsletter form, contact form builder, form builder, contact form 7, form, forms, widget, contact form, feedback form builder, email form builder, ajax form builder, captcha, file upload, newsletter form, customer support form builder, drag and drop form builder, lead generation form builder
Requires at least: 3.6
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create gorgeous optin forms for your site  with FormCraft, and grow your MyMail list.

== Description ==

This add-on allows you to add subscribers to your MyMail lists, with forms made with [FormCraft](http://formcraft-wp.com/)

Please note that this add-on works with [FormCraft Premium](http://formcraft-wp.com/), and not [FormCraft Basic](https://wordpress.org/plugins/formcraft-form-builder/)

== Changelog ==

= 1.0.0 =
* Initial release