<?php
/*
function list_events(){
echo "<h1>deu boa</h1>";
	global $wpdb;
	$sql="SELECT * FROM `".WPTEMPUS_TABLE."` ORDER BY id";
	$eventos=$wpdb->get_results($sql);
	return $eventos;
}
add_shortcode('list-events', 'list_events');*/
