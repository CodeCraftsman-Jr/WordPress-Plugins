=== Tempus ===
Contributors: Patrick Kaminski, Sibanir J. Lombardi
Donate link: http://tempusproject.wordpress.com/
Tags: tempus, events, calendar, diary, tasks, to-do, agenda
Requires at least: 2.0
Tested up to: 3.9
Stable tag: 1

Only in Portuguese (BR) yet. Others languages soon. Este plugin tem como objetivo manter um controle simples e eficiente de eventos

== Description ==
Only in Portuguese (Brazil) yet... Others languages soon...
This plugin aims to maintain a simple and efficient control of events and list
them as a widget
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Este plugin tem como objetivo manter um controle simples e eficiente de eventos
de forma a listá-los como widget
Enfim, a ideia desse plugin é oferecer uma opção eficiente para controle e listagem de
eventos, o que atualmente é uma necessidade de muitos sites.

No futuro há a ideia de integrá-lo ao Google Calendar.

== Installation ==

1. Faça o upload do conteúdo para a pasta `/wp-content/plugins/`
1. Ative o menu através do menu 'Plugins' no sistema de administração do WordPress

== Frequently Asked Questions ==

= No question yet =


== Screenshots ==

No screenshots yet

== Upgrade Notice ==

No upgrade yet

== Changelog ==

=1.0.01=
Atualizações na estrutura

=1.0=
Criado plugin para gerenciamento de eventos


== Uso ==

Use [list-events] para listar os eventos em um Post ou Pagina.
Ou utilize as funcoes list_events() e get_events()

Mais informacoes no site oficial do projeto
http://tempusproject.wordpress.com/

