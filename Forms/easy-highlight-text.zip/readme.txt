=== Easy Highlight Text ===
Contributors: jonathanmelgoza
Donate link: http://jonathanmelgoza.com/
Tags: 
Requires at least: 3.1
Tested up to: 4.1
Stable tag: 3.1
License: GPLv2 or later

This plugin allows you highlight any text, let you choose from 6 different types: success, error, tip, warning, simple and message.

== Description ==

This plugin allows you highlight any text, let you choose from 6 different types: success, error, tip, warning, simple and message. Just add the class "eht-success" and so on.. to any span tag and enjoy.

== Installation ==

This section describes how to install the plugin and get it working.

1. Activate the plugin through the 'Plugins' menu in WordPress
2. Add a span tag with the class you want from the list

for example:

<span class="eht-success">an important message</span>

list:
eht-success class.
eht-error class.
eht-tip class.
eht-warning class.
eht-simple class.
eht-message class.

and it's all.

Enjoy.

== Frequently Asked Questions ==

= Can i put the class in a div tag? =

Yes, you can do it.

== Screenshots ==

1. screenshoot-1.JPG

== Upgrade Notice ==

= 1.0 =
Primera version de Easy Highlight Text.

== Changelog ==

= 1.0 =
* First version of Easy Highlight Text
+ Added 6 classes to choose
