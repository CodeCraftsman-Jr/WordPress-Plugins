=== Google Hosted AJAX Libraries ===
Contributors: w3prodigy
Tags: scripts
Requires at least: 3.0
Tested up to: 3.0.1
Stable tag: trunk

Change the internal WordPress scripts to use Google Hosted Scripts

== Description ==

This plugin changes the internal WordPress script queues for the following AJAX Libraries: jQuery, jQuery UI, Prototype, Scriptaculous, MooTools, Yahoo! User Interface, Dojo, SWFObject, Ext-Core, Chrome Frame and WebFont Loader.