=== GZippy ===

Contributors: shamalt
Donate link: http://blog.shamalt.hu/wordpress/
Link: http://blog.shamalt.hu/wordpress/
Tags: gzip, plugin
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 1.0.2.1

GZippy re-enables gzip compression under WordPress.

== Description ==

GZippy re-enables gzip compression under WordPress.

== Frequently Asked Questions ==

== Installation ==

1. Upload the directory `gzippy` to `/wp-content/plugins/`.
1. Activate the plugin under the Plugins menu in WordPress.

== Screenshots ==