=== Wp Sup Contact Form ===
Contributors: Uspdev
Donate link: http://uspdev.net/donate-to-uspdev
Tags: contact form, contact form builder, contact form plugin, contact forms, contact us, feedback form, form, form builder, web form
Requires at least: 3.3
Tested up to: 4.1.1
Stable tag: 3.7.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
Is a plugin where you can display contact form field on the post/page easy using Shortcode. This contact form support for file attachment or file upload.

Feature :
1. Easy installation
2. Short code support
3. File Attachment
4. Page Options
5. User friendly form

== Installation ==
1. Upload the 'wp-sup-contact-form' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the Settings > Sup Contact Form
4. Configure your Email and other settings on it and save.
5. Next Create a Page or Post and insert this short code to the post or page [wpscf_display]
6. You are done.

== Frequently Asked Questions ==

== Screenshots ==

1. Contact Form Display on Page/Post
2. Contact Form Setting Page

== Changelog ==

= 0.0.1 =
* Initial release

= 0.0.2 =
* Added Captcha
* Restyling admin setting

= 0.0.3 =
* Changed recaptcha method
* Added reCaptcha Theme

= 0.0.4 =
* Changed recaptcha method
* Added reCaptcha Theme
* Added Responsive Form 

= 0.0.5 =
* Changed recaptcha method
* Added reCaptcha Theme
* Added Responsive Form 

= 0.6 =
* Fix Spam Message and some bug
* some css revision
* File Attachement Update Method
