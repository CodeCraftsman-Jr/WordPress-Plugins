﻿=== firefoxOS APP Downloader ===
Contributors: hideokamoto
Donate link: https://note.mu/hideokamoto/n/nd0cecce0e758
Tags: shortcode
Requires at least: 4.1.0
Tested up to: 4.1.0
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This app can use shortcode that firefoxOS application download link.

== Description ==

This app can use shortcode that firefoxOS application download link.

If you use shortcode, use [ffapp-dl class="CLASS" text="BUTTON TEXT" link="http://example.com/applicationURL/manifest.webapp"].

Print HTML like "<div class='CLASS' data-ffapp-dllink='http://example.com/applicationURL/manifest.webapp'>BUTTON TEXT</div>".

== Installation ==

1. Upload `firefoxos-app-downloader` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Can set many shortcode ?  =

Sorry, this version only one shortcode.


== Screenshots ==

1. No Images



== Changelog ==

= 1.1 =
2015/03/25 bugFixed

= 1.0 =
2015/03/23 released

== Upgrade Notice ==

= 1.1 =
2015/03/25 bugFixed

== Arbitrary section ==