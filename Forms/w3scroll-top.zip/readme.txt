=== W3Scroll Top ===
Contributors: faruque82
Tags: Scroll to top, jQuery Scroll top, jQuery effect Scroll top ,jQuery Scrolling
Requires at least: 3.3
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will enable scroll to top function. Just active, it will work for your WordPress theme. Impossible to be easier than this one!


== Description ==

### W3Scroll Top  by  <a href="http://w3itinfo.com" target="_blank">http://w3itinfo.com</a>

This plugin will enable scroll to top function in your WordPress theme. Active W3Scroll Top plugin, don't need to do anything. It will work for your WordPress theme. Impossible to be easier than this one!


Plugin Features

* Just Regular Installation in your theme and active plugin.
* Once active W3Scroll Top plugin it will work for your WordPress Theme.
* Very Lightweight. Only 10KB.

Live Preview: <cite><a href="http://w3itinfo.com/plugins/w3scrolltop" target="_blank">http://w3itinfo.com/plugins/w3scrolltop</a></cite>


== Installation ==

* e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Once active W3Scroll Top plugin, don't need to do anything, it will work for your WordPress Theme.


== Screenshots ==

Screenshots

* This is an example of W3Scroll Top.Just Instal and active it.Go to Home/Any page of your site, You will see like this.

== Changelog ==

= 1.0 =
* Initial release


== Upgrade notice ==

* Next Version is Comming Soon....