jQuery(document).ready(function(jQuery) {
	jQuery('body').scrollToTop({skin: 'text'});
});