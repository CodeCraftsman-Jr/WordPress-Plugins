=== Plugin Name ===
Contributors: Did You Know
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=LEUHA52PUM28S&lc=PH&item_name=Light%20Chat&no_note=0&cn=Add%20special%20instructions%20to%20the%20seller&no_shipping=2&currency_code=PHP&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: trivia,did you know
Requires at least: 3.4.1
Tested up to: 3.4.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Slides out a box containing a trivia after 10 seconds.

== Description ==
Slides out a box containing a trivia after 10 seconds.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `did-you-know` folder to `/wp-content/plugins/`
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==

1. Box containing the trivia
2. Clicking `read more` will bring up the lightbox containing the full trivia

== Changelog ==

= 1.0 =
* Initial release