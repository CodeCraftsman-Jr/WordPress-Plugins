<?PHP

	$github_show_string = "Show my repositories";
	$github_hide_string = "Hide my repositories";
	$github_percent_string = "percent of commits";
	$github_error = "GitHub API Error: ";
	$github_description = "A widget for displaying github profiles";
	$github_name = 'Github Profile';
	$github_username = 'GitHub Username';
	$github_password = 'GitHub password';
	$github_warning = 'Failing to set the Password may lead to the API timing out';
	$github_repo = 'Repo list is hidden by default';
	$github_no = "No";
	$github_yes = "Yes";
	
?>