<?PHP

	$github_show_string = "Afficher mes dépôts";
	$github_hide_string = "Cacher mes dépôts";
	$github_percent_string = "pourcentage de commits";
	$github_error = "Erreur de l'API GitHub: ";
	$github_description = "Un widget pour afficher les profils github";
	$github_name = 'Profil Github';
	$github_username = "Nom d'utilisateur GitHub";
	$github_password = 'Mot de passe GitHub';
	$github_warning = "Ne pas fournir la mot de passe peut entrainer des dépassements de temps de l'API";
	$github_repo = 'La liste des dépôts est cachée par défaut';
	$github_no = "Non";
	$github_yes = "Oui";
	
?>
