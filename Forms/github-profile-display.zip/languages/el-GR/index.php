<?PHP
	$github_show_string = "Δείξε τα αποθετήριά μου";
	$github_hide_string = "Κρύψε τα αποθετήριά μου";
	$github_percent_string = "επί τοις εκατό πράξεων";
	$github_error = "Λάθος του GitHub API: ";
	$github_description = "Ένα γραφικό στοιχείο για την επίδειξη του προφίλ GitHub";
	$github_name = 'Προφίλ GitHub';
	$github_username = 'Ψευδώνυμο GitHub';
	$github_password = 'Κωδικός GitHub';
	$github_warning = 'Αν δεν βάλετε κωδικό, μπορεί να ξεπεράσετε το μέγιστο όριο αιτημάτων του GitHub API';
	$github_repo = 'Προεπιλογή απόκρυψης των αποθετηρίων';
	$github_no = "Όχι";
	$github_yes = "Ναί";
?>