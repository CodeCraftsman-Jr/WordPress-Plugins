=== WP Tuning ===
Tags: tuning, memory, sql, ram, cleanup, feed, location, analytics
Requires at least: 2.6
Tested up to: 4.1

Quick and usefull wordpress tunes!

== Description ==
Quick and usefull wordpress tunes!

1. Show resources usage in admin or theme footer
2. Clean up your HEAD section
3. Change theme uri (if you want to use subdomain for it)
4. Quick insert Google Analytics and Yandex Metric codes

== Screenshots ==
1. Plugin Settings