<?php

$class_directory = "classes/";
$GLOBALS['test_directory'] = "tests/";

