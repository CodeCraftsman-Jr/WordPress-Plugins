=== Browsing History ===
Contributors: biztechc
Tags: Contact form 7 browsing history,visitor page history,page history 
Requires at least: 3.6.1
Tested up to: 4.0
Stable tag: 1.0.0
License: GPLv2 or later

Using this plugin admin can view the browsing history of user provided contact form 7 is configured in the site and the user has filled in the form.
== Description ==
1. This pluign is depended on Contact form 7.
2. Users filled in contact form 7 can be tracked.
3. When end user contact to admin through Conatct form 7, attached mail will store browsing histories of user.

== Installation ==

1. Copy the entire /bt-wpcf7-extra-body/ directory into your /wp-content/plugins/ directory.
2. Activate the plugin.

== Frequently Asked Questions ==
Is this plugin prepared for multisites? Yes.

== Screenshots ==

1. screenshot-1.png

== Changelog ==
= 1.0.0 =
* First release this pluign