<!DOCTYPE html>
<html style="background: #f1f1f1;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php _e('No access', 'emd-plugins'); ?></title>
</head>
<body style="margin-top:50px; background: none repeat scroll 0 0 #FFFFFF;box-shadow: 0 1px 3px rgba(0, 0, 0, 0.13);color: #444444;font-family:'Open Sans',sans-serif;max-width: 700px;padding: 1em 2em;margin: 3em auto;">
<p style="font-size:14px;line-height:1.5;margin:25px 0 20px;">
<?php _e('You do not have sufficient permissions to access this page.', 'emd-plugins'); ?>
</p>
</body>
</html>
