=== N5 Upload Form ===
Contributors: Kazuki Niibori
Tags:  form, upload, upload form, file
Requires at least: 3.3
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later

N5-UploadForm is a file uploading tool. This tool enables its user to add a form to static pages as well as articles in WordPress.

== Description ==

"N5-UploadForm" is the plug-in to create a form for uploading a file. No advanced IT skill is required to use this plug-in. This plug-in enables its user to create a file-uploading form with simple procedure.

= four features: =

* The users do not need to know HTML.
* The user can receive the E-mail notification when the upload is completed.
* The administrator of the plugin also can receive the E-mail notification when the upload is made.
* The uploaded file can be downloaded from the administration page. 

== Installation ==

1. Unzip the downloaded zip file.
2. Upload "n5-uploadform" directory to "/wp-content/plugins/".
3. Enable "n5-uploadform" in the WordPress plug-in administration page.


== Screenshots ==

1. This is Form Administration Page. The user can create new forms and manage them.
2. This is Form Administration Page. This enables the user to enlist the uploaded files for each form.

== Changelog ==
= 1.0 =
* first release. 
