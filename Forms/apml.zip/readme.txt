=== APML ===
Contributors: pfefferle
Donate link: http://14101978.de
Tags: APML, Attention Data, Feed, Taxonomy, Tags, Tag, Category, Categories, DataPortability
Requires at least: 2.5
Tested up to: 4.2.2
Stable tag: 3.1.5

This plugin creates an APML Feed using the the native WordPress-Tags, -Categories, -Links and -Feeds.

== Description ==

This plugin creates an APML Feed using the the native WordPress-Tags, -Categories, -Links and -Feeds.

You can find a demo file here: [notizBlog.org/apml](http://notizblog.org/apml).

== Installation ==

* Upload the `apml` folder to your `wp-content/plugins` folder
* Activate it through the admin interface

Thats it

== Changelog ==

= 3.1.5 =
* updated readme

= 3.1.4 =
* better host-meta and webfinger discovery

= 3.1.3 =
* Added function to flush rewrite_rules

= 3.1.2 =
* Added Webfinger discovery (http://wordpress.org/extend/plugins/webfinger/)

= 3.1.1 =
* lowercase concept-keys

== Screenshots ==

You can find a demo file here: [notizBlog.org/apml/](http://notizblog.org/apml/).
