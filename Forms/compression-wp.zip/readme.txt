=== Plugin Name ===
Contributors: Sonicity
Donate link: http://www.sonicity.eu
Tags: plugin, plugins, admin, compression, gzip, page, post, blog
Requires at least: 2.0.2
Tested up to: 3.0.4
Stable tag: 1.0.3

This plugin allows you to compress your webpages to save bandwidth and make your blog load faster!

== Description ==

This plugin allows you to compress your webpages to save bandwidth and make your blog load faster!

As soon as you enable the plugin, compression will be automatically enabled and your blog will load much, much quicker! You should also save between 50% - 80% bandwidth too, just by using this plugin!

== Installation ==

1. Upload `compression-wp.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Frequently Asked Questions ==

= Does this work? =

Yes, it enables GZIP compression on your website to reduce the amount of data which has to be sent to the web browser.

== Changelog ==

= 1.0.3 =
* Enables only if browser requests GZIP
* Works with 3.0.4!

= 1.0.2 =
* How this plugin works
* Better FAQ
* Works with 3.0.2!

= 1.0.1 =
* Cleaner code

= 1.0.0 =
* First Release
