===  Let there be guides! ===
Contributors: Huula
Tags: WalkMe, Guidance, widget, MailChimp, Aweber, Infusionsoft, madmimi, campaign monitor, constant contact, newsletter, get response,  subscribe, popup, exit intent, growth, subscribers, twitter, share, social plugin,  social sharing, subscription, email form, share, admin, posts, sharing, social , social media , links, popover, click to tweet , twitter , analytics , newsletter,  mail, lightbox, analytics, bookmarking, newsletter, bookmarks,  email, Facebook, floating social buttons, gmail, google plus, image bookmarking, Image sharing, email, pinterest plugin, pintrest, share image,   sharebar, sharing, social bookmarking, social media, getresponse, social plugin, tweet button, twitter, heat map, heatmaps, share bar, contact form, pinterest plugin, scroll map, content analytics, inbound marketing, mailing list, share buttons
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Huula, create guides for your site!

Complexity is one thing we all hate. New visitors gets confused by your site and they quickly drop. Customers gets confused by your site and they complain and churn. But we all understand that some complexities are inevitable. Sometimes it's because of your business model and sometimes it's because of the complexity of the problem you are trying to solve! Hmm, what do we do now?

Don't worry, here it is, Huula, it helps solving your complexity problems and educate your users. That's what it's made for and what it's good at! No more phone calls in your sleeping hours, no more angry users, and in return you get boosted sales, profit and growth!

= Features =

1. The easiest creation of guides for any web based systems.
2. The richest guidance content, text, video, picture, links, etc.
3. Different themes for different web systems.
4. Showing progress of the guides during playing.
5. Invisible mode makes Huula work transparently on your site.
6. Different action triggers makes you guide users perform whatever actions you want them to perform.
7. Different starting methods enables Huula just at the moment the user needs your help.
8. Beautiful graphical step overview.
9. Cross page guides work out of the box.
10. No CSS interference.
11. No JavaScript name space pollution whatsoever.
12. 3 seconds easy register.
13. 24x7 support.
14. WordPress plugin makes enabling Huula a breeze on WordPress sites.
15. One line api for any sites.
16. Tons of other features that's just for you!
Check our [website](http://www.huu.la) for more.


== Changelog ==

= 3.0 =
Preview release. Changed domain back to http://huu.la

= 2.5 =
Solved the https iframe issue.

= 2.4 =

Better description and help information for users.

= 1.0 =

First release.
