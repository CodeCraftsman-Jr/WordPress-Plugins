<?php
/*
Plugin Name: Valideratext
Plugin URI: http://wordpress.org/extend/plugins/valideratext/
Description: Koppling till Valideratext.se för redaktionellt stöd (API v3). Valideratext.se hjälper dig att skriva texter som är enkla och lätta att förstå.
Version: 2.0
Author: Flowcom AB, Andreas Ek
Author URI: http://www.flowcom.se
License: GPL2
*/

//include WP_PLUGIN_DIR . '/valideratext/includes/ajax.php';
include WP_PLUGIN_DIR . '/valideratext/includes/settings.php';
include WP_PLUGIN_DIR . '/valideratext/includes/class.settings-api.php';
include WP_PLUGIN_DIR . '/valideratext/includes/media_button.php';

?>