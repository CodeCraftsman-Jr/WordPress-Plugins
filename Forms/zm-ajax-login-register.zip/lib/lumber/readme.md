# Lumber 

A unified way to create form fields between WordPress settings API, WordPress meta sections, and front-end HTML forms.

---

Currently best used with [Quilt](https://github.com/zanematthew/quilt).