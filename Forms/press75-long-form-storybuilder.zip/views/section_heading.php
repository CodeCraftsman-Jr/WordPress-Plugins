<a name="<?php echo $title; ?>"></a>
<div class="lfc-module lfc-section lfc-section_heading module" id="<?php echo $widget_id; ?>">
    <div class="lfc-content">
        <div class="lfc-section_heading-title fontRepaint">
            <?php echo $heading_title; ?>
        </div>
        <div class="lfc-section_heading-subtitle fontRepaint">
            <?php echo $heading_subtitle; ?>
        </div>
        <div class="lfc-section_heading-hr"></div>
    </div>
</div> <!-- END .lfc-section -->