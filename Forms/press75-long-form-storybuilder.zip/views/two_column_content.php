<a name="<?php echo $title; ?>"></a>
<div class="lfc-module lfc-section lfc-section_two_column" id="<?php echo $widget_id; ?>">
	<div class="lfc-container">
		<div class="row">
			<div class="lfc-col-md-6">
				<?php echo $first_column; ?>
			</div>
			<div class="lfc-col-md-6">
				<?php echo $second_column; ?>
			</div>
		</div>
	</div><!-- END .lfc-content -->
</div><!-- END .lfc-section -->