<a name="<?php echo $title; ?>"></a>
<div class="lfc-module lfc-section lfc-section_intro" id="<?php echo $widget_id; ?>">
	<div class="intro windowSized_peak" style="background-image:url(<?php echo $image; ?>);">
        <div class="lfc-section_intro-bg">
        </div>
		<div class="intro-lfc-content fontRepaint">
            <div class="intro-lfc-content-title">
                <h1><?php echo $main_title; ?></h1>
            </div>
            <div class="intro-lfc-content-subtitle">
                <?php echo $subtitle; ?>
            </div>
		</div>
	</div><!-- END .intro -->
</div> <!-- END .lfc-section -->