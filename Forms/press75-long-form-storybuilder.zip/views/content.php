<a name="<?php echo $title; ?>"></a>
<div class="lfc-module lfc-section lfc-section_main" id="<?php echo $widget_id; ?>">
	<div class="lfc-content">
		<?php echo $content; ?>
	</div><!-- END .lfc-content -->
</div><!-- END .lfc-section -->