<a name="<?php echo $title; ?>"></a>
<div class="lfc-module lfc-section lfc-section_three_column" id="<?php echo $widget_id; ?>">
	<div class="lfc-container">
		<div class="row">
			<div class="lfc-col-md-4">
				<?php echo $first_column; ?>
			</div>
			<div class="lfc-col-md-4">
				<?php echo $second_column; ?>
			</div>
			<div class="lfc-col-md-4">
				<?php echo $third_column; ?>
			</div>
		</div>
	</div><!-- END .lfc-content -->
</div><!-- END .lfc-section -->