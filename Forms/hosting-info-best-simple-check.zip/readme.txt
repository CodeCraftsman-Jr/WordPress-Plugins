=== Best Wordpress Hosting - Check ===
Contributors: seo101
Donate link: 
Tags: hosting, php version, php info
Requires at least: 3.1
Tested up to: 4.1
Stable tag: 1.00
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Displays information on your WordPress hosting like mysql version and php version information.

== Description ==

Displays information on your WordPress hosting like mysql version and php version information. It's simple to install and useful to find for example information on the php parameters of your shared wordpress hosting.

After installation you will find a new menu item in your settings menu, click it and all information will be displayed.

For more information visit <a href="http://www.seo101.net/">seo101.net</a>


== Installation ==

1. Upload the zip file to the `/wp-content/plugins/` directory and unzip
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the plugin from the settings menu

== Frequently asked questions ==

None yet

== Screenshots ==

1. 
2. 
3. 
4. 

== Changelog ==
1.00 Release


== Upgrade notice ==



== Arbitrary section 1 ==
