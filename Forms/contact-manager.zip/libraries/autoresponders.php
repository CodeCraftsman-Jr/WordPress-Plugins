<?php $autoresponders = array(
'AWeber',
'CyberMailing',
'GetResponse',
'MailChimp',
'SG Autorépondeur');