<?php $personal_informations = array(
'login',
'first_name',
'last_name',
'email_address',
'website_name',
'website_url',
'address',
'postcode',
'town',
'country',
'country_code',
'phone_number');