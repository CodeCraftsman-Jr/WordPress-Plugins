<?php $api_fields = array(
'aweber_api_key',
'getresponse_api_key',
'mailchimp_api_key',
'recaptcha_private_key',
'recaptcha_public_key',
'sg_autorepondeur_account_id',
'sg_autorepondeur_activation_code');