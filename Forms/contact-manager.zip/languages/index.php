<?php if (!headers_sent()) { header('Location: /'); exit(); }
$strings = array(
__('Filter', 'contact-manager'),
__('Filter by', 'contact-manager'),
__('Search', 'contact-manager'),
__('Search by', 'contact-manager'),
__('active', 'contact-manager'),
__('bottom', 'contact-manager'),
__('inactive', 'contact-manager'),
__('no', 'contact-manager'),
__('paid', 'contact-manager'),
__('top', 'contact-manager'),
__('top, bottom', 'contact-manager'),
__('unlimited', 'contact-manager'),
__('unpaid', 'contact-manager'),
__('yes', 'contact-manager'));