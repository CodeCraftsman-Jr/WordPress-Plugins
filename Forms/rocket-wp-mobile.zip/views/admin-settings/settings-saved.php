<div class="updated settings-error">
	<p><strong><?php _e( 'Settings saved successfully.', 'wpmp' ) ?></strong></p>
</div>