<div class="updated">
	<p>
		<strong>
			<?php _e( 'Enable the mobile mode from the plugin', 'wpmp' ) ?>
			<a href="<?php echo $settings_link ?>"><?php _e( 'settings', 'wpmp' ) ?></a>
		</strong>
	</p>
</div>