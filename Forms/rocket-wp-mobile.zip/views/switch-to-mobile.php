<style type="text/css">

#wpmp-switch-footer {
	height: 22px;
	text-align: center;
}

#wpmp-switch-footer a{
	cursor: pointer;
	font-weight: bold
}

</style>

<div id="wpmp-switch-footer">
	<a href="<?php echo add_query_arg( 'wp-mobile-switch', 'mobile' ) ?>" title="<?php echo $footer_text ?>" rel="nofollow"><?php echo $footer_text ?></a>
</div>