=== WP Mobile Plugin ===
Contributors: Muneeb 
Donate link:http://rocketplugins.com/wordpress-mobile-plugin/
Tags: wordpress mobile site,wordpress,wordpress mobile,wordpress mobile plugin,mobile plugin,wordpress mobile theme,wptouch,iphone,responsive,mobile site,jquery mobile,android,blackberry,theme,mobile theme
Requires at least: 3.1
Tested up to: 3.9.2
Stable tag: 0.4
License: GPLv2 or later

All in one mobile solution for your WordPress powered blog or site. Converts WordPress website into a more mobile-friendly website

== Description ==

If you have a desktop site which is not responsive or mobile compatible this plugin would do the job for you and your mobile visitors. It'll show a beautiful and well-designed mobile theme to only mobile visitors without modifying the code of your regular theme.

= Features =

* Custom Menus/Navigation - Fully compatible with WordPress custom menus. Use an existing menu or assign newly created menu for your mobile theme.
* Set a custom homepage for mobile visitors or by default use WordPress reading options
* Change mobile theme Logo
* Change mobile theme homepage Subtitle text
* Can change themes or create new mobile theme easily.
* Can Enable/Disable mobile mode.
* Can change theme footer text
* Can change Switch To Desktop Text
* Can change Switch To Mobile Text

I hope you like and love my plugin in the same way like I do and to love it you have to actually install and use it. Please install the plugin and use it and then let me know your feedback [here](http://rocketplugins.com/contact)

<strong>For more advanced features, themes and to get guaranteed support be sure to check out our premium version of the plugin, [WordPress Mobile Plugin](http://rocketplugins.com/wordpress-mobile-plugin/)</strong>

== Screenshots ==
Please click on the link to visit <a href="http://rocketplugins.com/wordpress-mobile-plugin/">Screenshots page</a>.

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
