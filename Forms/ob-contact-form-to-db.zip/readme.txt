=== OB Contact Form to DB ===
Contributors: owebest
Donate link: http://owebest.com/
Tags: contact form, simple contact form to db, contact form save entries, OB contact form, email contact form, contact us form, email contact us form, contact form to db
Requires at least: 3.0.1
Tested up to: 4.2.3
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

OB Contact form to DB is an addon to OB Contact Form plugin, to stor all submitted entries into database and show them in back-end.
== Description ==

OB Contact form to DB is an addon to OB Contact Form plugin, which provides feature of saving all the submitted entries from OB Contact Form into database and showing them in the backend. OB Contact Form to DB provieds you feature of exporting entries into CSV file as well. Administrator can also search in all entries for any entry withing any field. Sorting of Entries is also supported.

== Installation ==

1. Upload `OB-contact-form-to-db.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Check the OB Contact Form menu in the left side navigation to see entries.

== Frequently Asked Questions ==

= Can i use it without OB Contact Form plugin? =

No, you can not use this plugin without OB Contact Form, as it works with OB Contact Form plugin only.

= Does it show all the entries in back-end? =
Yes, This plugin will stor all your submitted entries from OB Contact Form into Database and administrator can view all those entries in back-end under Entries page of OB Contact Form menu.


== Screenshots ==

1. OB Contact Form to DB Entries

== Changelog ==
= 1.0 =
Main Release

== Upgrade Notice ==

= 1.0 = 
Main Release


== A brief Markdown Example ==

Ordered list:

1. Ready to save all contact us entries submitted through OB Contact Form plugin
1. All entries as stored in database
1. Admin can see all the entries in admin panel under OB Contact Form menu
1. Search through all entries in table.
1. Export entries into CSV.
