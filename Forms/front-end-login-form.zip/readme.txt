=== Plugin Name ===
Contributors : jigspatel
Donate link: http://fasamfast.com/donate
Tags: wp-login,Front end login,login form 
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A tiny plugin which allows you to add a log-in form to your wordpress blog.


== Description ==

Front end login is a plugin to get login form on the wordpress pages so you can easily be able to login to your wordpress admin without visiting wp-login / wp-admin page. This plugin gives a custom CSS3 based login form ready to be integrated to your theme through shortcode. 



== Installation ==

This plugin has one simple shortcode to have a form on pages.

e.g.

1. Upload `front-end-login` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place [login_form] in your post/pages

== Frequently Asked Questions ==





== Screenshots ==

1. default login form
2. reset password form

== Changelog ==

= 0.1 =
* The initial version

== Upgrade Notice ==
*