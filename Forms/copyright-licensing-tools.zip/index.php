<?php
// Silence, file used to prevent any user from dumping the directory to a browser and viewing all the files.
?>