// JavaScript Document

//function for interactive tools opoup window
function openLicenseWindow(href) {
    popup = window.open(href, 'contentservices', 'width=511, height=550, scrollbars=yes, resizable=yes');
    popup.focus();
}