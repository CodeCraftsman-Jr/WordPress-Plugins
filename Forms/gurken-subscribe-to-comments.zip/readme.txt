=== Gurken Subscribe to Comments (deprecated) ===
Tags: old,deprecated,unsupported
Contributors: infogurke
Stable tag: trunk
Requires at least: 2.5
Tested up to: 1.0

!!!DEAD PLUGIN!!! USE Subscribe to Comments Reloaded

== Description ==

<strong>Gurken Subscribe to Comments is dead!</strong>

<strong>Use <a
href="http://wordpress.org/extend/plugins/subscribe-to-comments-reloaded/">Subscribe
to Comments Reloaded</a> instead.</strong>

I reviewed <a
href="http://wordpress.org/extend/plugins/subscribe-to-comments-reloaded/">Subscribe
to Comments Reloaded</a> and it's working just
fine. StC Reloaded imports all of your data! The update is very smooth and
easy.
