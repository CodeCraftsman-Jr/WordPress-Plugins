GAS Injector for WordPress will help you add Google Analytics on Steroids (GAS) to your WordPress blog.

This will not only add basic Google Analytics tracking but also let you track which outbound links your visitors click on,
how they use your forms, which movies they are watching, how far down on the page do they scroll etc.

You get this and more by using GAS Injector. Just add your Google Analytics tracking code and your domain and you are done!