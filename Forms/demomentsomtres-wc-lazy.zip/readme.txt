=== DeMomentSomTres Lazy Load for WP Canvas - Gallery ===

Contributors: marcqueralt
Donate link: http://demomentsomtres.com/
Tags: masonry gallery, pinterest style gallery, pinterest gallery, gallery slider, slider gallery, carousel gallery, carousel, slider
Requires at least: 3.7
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds BJ Lazy Load compatibility to WP Canvas Gallery

== Description ==
WP Canvas Gallery is a great gallery with a Masonry or Pinterest effect.

However, in very big galleries, it is to slow but it doesn't work fine with BJ-Lazy-Load that implements Lazy Load for WordPress at it losts the Masonry effect.

So, when we were implementing both plugins in http://espaimoble.com where there are really big galleries based on WP Canvas Gallery, we where forced to implement this plugin to implement the compatibility.

=== Thank you ===
This plugin it's been possible thanks to the great job of:
* Bjørn Johansen in (BJ-Lazy-Load|http://wordpress.org/extend/plugins/bj-lazy-load/)
* Chris Baldelomar in (WP Canvas Gallery|http://wordpresscanvas.com/features/gallery/)

== Installation ==

As usual.

== Frequently Asked Questions ==

TBD

== Changelog ==

### Version 1.0

First version