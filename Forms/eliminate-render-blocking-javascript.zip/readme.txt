=== No Longer Supported ===
Contributors: erbj
Donate link: http://wordpress.org/plugins/eliminate-render-blocking-javascript
Tags: no longer supported
Requires at least: 3.0.0
Tested up to: 3.8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

No Longer Supported

== Description ==

No Longer Supported

== Installation ==

No Longer Supported

== Screenshots ==

1. Plugin settings
