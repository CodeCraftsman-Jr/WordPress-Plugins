<?php
	
// 	STOP! DO NOT MODIFY THIS FILE!
//	If you wish to customize the output, you can safely do so by COPYING this file
//	into a new folder called 'gigpress-templates' in your 'wp-content' directory
//	and then making your changes there. When in place, that file will load in place of this one.

// This template displays before each group of artist shows in the sidebar when grouping your shows by artist.

?>

<h3 class="gigpress-list-artist-heading"><?php echo $showdata['artist']; ?></h3>
