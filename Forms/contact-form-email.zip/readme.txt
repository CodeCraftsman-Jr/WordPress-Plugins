=== Contact Form ===
Contributors: jeffbullins
Donate link: http://www.thinklandingpages.com
Tags: contact form, email submit form, message form, email subscription, attachment, contact, contatc, conact, cnotact, contact button, contact form plugin, contact me, contacts, contacts form plugin, copy, feedback, feedback form, form, insert the shortcode, post feedback, request, send, send copy, send messages, shortcode, text, web-page feedback
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily create a contact form for your Wordpress site.

== Description ==

Easily create a contact form for your Wordpress site.


* [Upgrade to the Pro Version - add captcha for Free](http://www.thinklandingpages.com/landingpage/wordpress-contact-form-plugin/)

###What you get when you use the Wordpress contact form plugin

*  Allow users to contact you
*  Create a form with a simple shortcode
*  [think_contact/]


###Why you should use a contact form

If you don't have a contact form on your site now, you may think a contact form is not necessary.  You may think you don't need a contact form because you don't have a lot of visitors to your site.  You may also think a contact form is not necessary because you don't think anyone wants to contact you.

Both of these reasons are wrong assumptions.  You need a contact form on your site.  No matter how little your traffic, you should have a contact form from the moment you start your site.  Real people are coming to your site and they want to contact you.  You need to give them the oppurtunity with a contact form.

The Wordpress Contact Form plugin allows you to collect the basic information you need.  The contact form provides a place for name, email address, subject, and message.

You should collect a visitor's name on your contact form because you want to personalize the communications you send back to them.  Personalizing messages can get a better response rate than not personalizing them.

Of course it goes to say that you will collect the visitor's email address on your contact form.  You need the email address to be able to contact them back.

* [Upgrade to the Pro Version - add captcha for Free](http://www.thinklandingpages.com/landingpage/wordpress-contact-form-plugin/)


== Installation ==


1. Upload `contact-form` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Click **Contact Form** on the admin menu to enable and set your options.


== Frequently Asked Questions ==

= Do I have to know how to program or design to use the contact form plugin? =

No.  The contact form plugin does the programming and design.

= Can I send the contact form message to my email address? =

Yes, there is a place on the contact form settings page to enter the email address you want the message sent to.

= Does the contact form allow the sender to put a subject? =
Yes, the contact form allow the sender to pt a subject.


== Screenshots ==

[See screenshots at thinklandingpages.com](http://www.thinklandingpages.com/contact-form-quick-start-guide/)


== Changelog ==

= 1.0 =
* First Release

= 1.1 =
* Added apply_filters('cf_add_to_form_filter', null) before submit button is created on contact form

= 1.2 =
* Added id to html form


