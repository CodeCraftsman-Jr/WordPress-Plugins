
<html>
<head>
<title>
testingt
</title>

</head>
<body>
<h3>Copy the button shortcode you would like to use and paste it into your Wordpress editor</h3>
<p>[think_button url="http://www.google.com" text="Get Access Now Baby"][/think_button]

<p>[think_button url="http://www.google.com" text="Get Access Now Baby" color="red" font_size="30px" ][/think_button]

<p>[think_button url="http://www.google.com" text="Get Access Now Baby" color="yellow" font_size="30px" ][/think_button]

<p>[think_button url="http://www.google.com" text="Get Access Now Baby" color="blue"][/think_button]

<p>[think_button url="http://www.google.com" text="Get Access Now Baby" color="green"][/think_button]

<p>[think_button url="http://www.google.com" text="Get Access Now Baby" color="purple"][/think_button]
</body>
</html>
