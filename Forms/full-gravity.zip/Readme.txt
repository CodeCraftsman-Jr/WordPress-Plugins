=== Plugin Name ===
Contributors: TaylorHicks ,
Donate link: http://www.fullgravity.tk
Requires at least: 3.5
Tested up to: 3.8
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: Gravity Forms, Full Contact

Full Gravity provides you with rich social profiles of all your leads in gravity forms.

== Description ==
Full Gravity leverages the Full Contact Person API in order to take incomplete and incorrect contacts in Gravity Forms and turn them into complete contacts with rich social profiles. 


== Installation ==

1. Upload `fullgravity` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Register at [Full Contact](https://www.fullcontact.com/developer/pricing/) to receive an API key
4. Enter Full Contact API key in Full Gravity Settings

== Frequently Asked Questions ==

== Screenshots ==


== Changelog ==
= 1.1 =
* Minor Code refactoring
* Added output for errors, and a response if nothing is returned from full contact
= 1.0 =
* Public Release