</td>
        <td width="15">&nbsp;</td>
        <td width="250" valign="top">

            <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th><strong>Usefull Links</strong></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>
                    
                    <div align="center"><a href="http://dnesscarkey.com/jquery-validation/lite-version-demo/" target="_blank" class="jvcf7_btn">Demo & Documentation</a>
                    </div>
                    
                    <ul class="jvcfz_list">
                    	<li><a href="http://dineshkarki.com.np/forums/forum/jquery-validation-for-contact-form" target="_blank">View Support Forum</a></li>
                        <li><a href="http://dineshkarki.com.np/contact" target="_blank">Contact Us</a></li>
                    </ul>
                    </td>
                </tr>
                </tbody>
            </table>
            <br/>
            
            <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th><strong>Why Pro version ?</strong></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>
                    <ul class="jvcfz_list">
                    	<li>Additional validation methods. <a href="http://dnesscarkey.com/jquery-validation/pro-version-demo/" target="_blank">DEMO</a></li>
                        <li>More validation error theme. <a href="http://dnesscarkey.com/jquery-validation/validation-error-theme/" target="_blank">DEMO</a></li>
                        <li>Change default error message. <a href="http://dnesscarkey.com/jquery-validation/change-error-message/" target="_blank">DEMO</a></li>
                        <li>Support Developer to maintain this plugin</li>
                    </ul>
                    <div align="center">
                    <a href="http://dnesscarkey.com/jquery-validation/buy-now"  target="_blank" class="jvcf7_btn">Get Pro Version</a></div>
                    </td>
                </tr>
                </tbody>
            </table>
            <br/>
            
            <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th><strong>Plugins You May Like</strong></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>
                    	<ul class="jvcfz_list">
                        	<li><a href="https://wordpress.org/plugins/wp-masonry-layout/" target="_blank">WP Masonry Layout (Pinterest Like Grid)</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/use-any-font/" target="_blank">Use Any Font</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/any-mobile-theme-switcher/" target="_blank">Any Mobile Theme Switcher</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/add-tags-and-category-to-page/" target="_blank">Add Tags And Category To Page</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/block-specific-plugin-updates/" target="_blank">Block Specific Plugin Updates</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/featured-image-in-rss-feed/" target="_blank">Featured Image In RSS Feed</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/remove-admin-bar-for-client/" target="_blank">Remove Admin Bar</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/html-in-category-and-pages/" target="_blank">.html in category and page url</a></li>
                            
                        </ul>
                    </td>
                </tr>
                </tbody>
            </table>
            <br/>
            <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th><strong>Facebook</strong></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td><iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FDnessCarKey%2F77553779916&amp;width=185&amp;height=180&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;border_color=%23f9f9f9&amp;header=false&amp;appId=215419415167468" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:240px; height:180px;" allowTransparency="true"></iframe>
                    </td>
                </tr>
                </tbody>
            </table>
            <br/>
            
        </td>
    </tr>
</table>
</div>
