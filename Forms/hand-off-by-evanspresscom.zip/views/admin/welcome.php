<div class="welcome-panel-content <?php echo $pre; ?>-welcome-panel-content">
    <div>
        <?php echo $welcome_message; ?>
    </div>
</div>
