<script type="text/javascript">
    if(typeof ajaxurl == "undefined") {
        ajaxurl = "<?php echo admin_url( 'admin-ajax.php' );?>";
    }
</script>
<style type="text/css">
    #wpfooter .submit { padding: 0; }
</style>