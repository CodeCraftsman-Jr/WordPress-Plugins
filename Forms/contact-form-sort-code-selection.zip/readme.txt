=== Contact Form Sortcode Selection ===
Contributors: Commercepundit
Tags: contact form
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Flexible contact form sortcode selection plugin .. Simple to edit and manage.

== Description ==

NOTE : To Use this plugin Contat Form 7 plugin must be installed.

Contact Form Sortcode Selection is dependent on Contact Form 7. this plugin can manage contact forms selection on any post or pages by just selecting dropdown value which contains contact form names in dropdown selection . after selecting value click on button addtopost so sortcode will be added to post or page automatically.



== Installation ==

1. Upload the entire `contact-form-sort-code-selection` folder to the `/wp-content/plugins/` directory.

1. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'Contact Form Selection' section inside any post or page in your WordPress admin panel.

== Screenshots ==

1. screenshot-1.png

