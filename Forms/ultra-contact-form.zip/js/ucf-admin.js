(function($){
	$( function () {
		
		postboxes.add_postbox_toggles( 'ucf_form' );
		
	} );
})(jQuery)