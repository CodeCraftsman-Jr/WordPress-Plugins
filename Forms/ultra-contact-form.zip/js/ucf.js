(function($){
	$( function () {
		console.info( 'ucf.js is loaded.' );
	} );
})(jQuery)