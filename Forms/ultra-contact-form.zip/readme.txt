=== Ultra Contact Form ===
Contributors: ColorChips Co.,Ltd.
Tags: contact, form, admin
Requires at least: 2.8
Tested up to: 3.0.1
Stable tag: 0.0

User-friendly contact form and Intuitive inbox.

== Description ==

This plugin does not work correctly. :-(

== Installation ==

Upload the this plugin to your blog, Activate it.

== Changelog ==

= 0.0 =
* Initial release.
