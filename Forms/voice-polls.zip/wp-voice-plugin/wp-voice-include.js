(function() {
    var poutsch = document.createElement('script'); poutsch.type = 'text/javascript';
    poutsch.src = 'https://voicepolls.com/widget/p.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(poutsch, s);
})();