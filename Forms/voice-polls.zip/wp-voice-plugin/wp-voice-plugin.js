edButtons[edButtons.length] =
new edButton('ed_h1'
	,' '
	,''
	,''
	,'1'
);