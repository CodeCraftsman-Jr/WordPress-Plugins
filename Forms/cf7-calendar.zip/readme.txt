=== Plugin Name ===
Contributors: harrysudana
Donate link: http://blog.inhs.web.id/donation
Tags: post, form 7, contact form, calendar, contact form 7
Requires at least: 3.2
Tested up to: 3.4.2
Stable tag: 3.0.1

JavaScript Calendar for Content, Widget and also work for Contact Form 7 (please DO NOT upgrade if you have older WP Version)

== Description ==

JavaScript Calendar for Content, Widget and also work for Contact Form 7

This plugins using DHTML Calendar JS, JSCal2 version 1.9 please visit www.dynarch.com/projects/calendar

Compatibility:

* Wordpress 3

* Wordpress 2.8 or below please use version 2.0.4


Changelog:

3.0.1 - Many compatibility improvement

2.0.4 - NO MORE NEED TO UPLOAD FILE IN CONTACT FORM 7 MODULES FOLDER

2.0.3 - More Compatible with Contact Form 7 version 2.0 using [cf7cal inputname]

2.0.2 - Bug Fix in Show Time (logical true/false)

2.0.1 - More Costumable With Style, show time function and Date Format

1.1.1 - Compatible with Widget

1.0.3 - First Release


== Installation ==

This section how to install the plugin and get it working.

1. Upload the plugin folder to the `/wp-content/plugins/` directory

2. Activate the plugin through the 'Plugins' menu in WordPress

3. Place a tag [datetimepicker inputname] in your post (remember to switch to HTML) or Contact Form 7 design mode, Please the tag is [datetimepicker inputname] where inputname is UNIQUE!


== Frequently Asked Questions ==

= How to Install =

Please see the installation section.

= How to Contact Developer? =

Please Visit : http://blog.inhs.web.id/cf7-calendar

== Screenshots ==

Please Visit : http://blog.inhs.web.id/cf7-calendar
