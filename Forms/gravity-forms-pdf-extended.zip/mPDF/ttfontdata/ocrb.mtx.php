<?php
$name='ocrb10';
$type='TTF';
$desc=array (
  'Ascent' => 938,
  'Descent' => -335,
  'CapHeight' => 938,
  'Flags' => 4,
  'FontBBox' => '[-87 -335 782 938]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 723,
);
$up=-100;
$ut=50;
$ttffile='G:/Blue Liquid Designs/4) BLUE LIQUID DESIGNS/12) FTP/2.2.0/mPDF/ttfonts/ocrb10.ttf';
$TTCfontID='0';
$originalsize=23112;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ocrb';
$panose=' 0 0 2 0 5 9 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>