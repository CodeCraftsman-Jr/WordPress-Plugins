=== Plugin Name ===
Contributors: Dwainm
Tags: Facebook albums,Facebook gallery
Requires at least: 3.X
Tested up to: 3.1.3
Stable tag: 0.1

Load your Facebook albums on any page by using short codes.

== Description ==

Load your Facebook galleries on any page.

Here are the key features:

* Simple to use, just add your Facebook file page name

= Installation Instructions =
Go to http://wordpress.org/extend/plugins/facebook-album-sync/installation/.

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. See the Plugin at the bottom Menu, edit it with no restrictions

== Frequently Asked Questions ==

= How Does the plugin work =
Go to http://wordpress.org/extend/plugins/facebook-album-sync/installation/ for instructions.

= Do you offer support =

We do offer support via the forum for now, but you can also visit www.miiweb.net for assistance.



== Screenshots ==

1. Will be uploaded.

== Changelog ==
= 0.1 =
* Initial release plugin
* Get the albums from Facebook
* Display all albums with a link to its photos via short code

== Upgrade Notice ==

= 1.0 =


== How to ==

1. To use go to the Settings page then enter your Facebook page there.
2. Copy the short code to your page: [fbalbumsync]
