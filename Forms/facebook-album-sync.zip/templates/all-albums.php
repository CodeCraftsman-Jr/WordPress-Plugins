<?php
/**
*
*  All albums view
*/
?>
<div id="fbalbumsync" class="container">
</div>