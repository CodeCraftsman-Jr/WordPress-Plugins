=== ASI Fare Calculator===
Contributors: Adaptive Solution Inc
Donate link: http://www.adaptivesolutionsinc.com/
Plugin Name: asi-fare-calculator
Description: This is a asi-fare-calculator. Use shortcode [asi-fare] to display form on page or use the widget. For more info please check readme file.
Version: 1.0
Plugin URI: http://www.adaptivesolutionsinc.com/
Author: adaptivesolutionsinc
Author URI: http://www.adaptivesolutionsinc.com/
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tested up to: 4.2.2
Stable tag: trunk
Tags: fare calculator, taxi fare calculator, taxi fare, calculator
Fare calculator is a little utility plugin to allow taxi companies to give an option to their customer to calculate taxi fare before taking a ride.
   
== Description ==
Adaptive Solutions Inc. has several years of expertise in developing auto dispatching taxi system with mobile and web interface.  The purpose of this plugin is to assist companies related to taxi business to allow it's customers to calculate the ride fare.  Please give us your feedback on any additions you would like to see here.  You can contact us at info1@adaptivesolutionsinc.com
Please use shortcode [asi-fare] to display and use the plugin

= Fare Calculation =
From the settings screen in the admin section you can enter currency, price and taxi types.

== Installation == 
Copy the plugin in plugin folder and then activate it from the admin side.
After installation please add shortcode [asi-fare] on your website page for displaying the fare calculator.

== Screenshots ==

1. Fare, currency and background color can be added from this screen.
2. This screenshot display that how to add taxi types and taxi fare
3. This is the asi-fare-calculator screen. Here the customers select taxi type, number of stop and seats to calculate fare for ride. 

== Frequently Asked Questions ==

= why am i getting wrong calculated fare? =
1) Please type all the fare in one currency symbol.

