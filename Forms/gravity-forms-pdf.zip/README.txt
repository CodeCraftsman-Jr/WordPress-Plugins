=== Gravity Forms PDF ===
Contributors: rposborne
Tags: gravity forms, pdf, export
Donate link: https://github.com/rposborne/gravityformspdf
Requires at least: 3.2.3
Tested up to: 3.2.3
Stable tag: 0.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description == 
A basic plugin that allows Gravity Forms Entries to be Viewed and Download in a Printer Friendly PDF Layout

== Installation ==
Standard Wordpress Plugin Operating Procdure. 

This has ONLY been tested on gravity forms latest. 1.6.4.1

== Frequently Asked Questions == 
Please Direct your questions and request to github. 
https://github.com/rposborne/gravityformspdf

== Changelog ==
https://github.com/rposborne/gravityformspdf