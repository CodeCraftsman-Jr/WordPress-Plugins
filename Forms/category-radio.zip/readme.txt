=== Plugin Name ===
Contributors: Harigae
Donate link: http://plugins.svn.wordpress.org/category-radio/
Tags: category,radio
Requires at least: 1.0
Tested up to: 1.0
Stable tag: 1.0
License: GPLv2 or later


== Description ==

Plug -in only to change the radio button a category from the check box in the WordPress Admin screen

WordPress管理画面においてカテゴリーをチェックボックスからラジオボタンに変更させるだけのプラグイン

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `category_radio.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

インストールして有効化すればOK

 == Upgrade Notice ==

None at the moment

今のところないです

== Frequently Asked Questions ==

None at the moment

質問なんてないかと…

== Screenshots ==


http://plugins.svn.wordpress.org/category-radio/assets/img1.jpg


== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

