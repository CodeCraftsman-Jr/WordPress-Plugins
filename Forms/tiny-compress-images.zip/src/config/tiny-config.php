<?php

class Tiny_Config {
    const URL = 'https://api.tinify.com/shrink';
}
