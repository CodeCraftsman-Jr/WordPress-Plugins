<?php

function innerText($e) {
    return $e->getText();
}

function elementName($e) {
    return $e->getAttribute('name');
}