<?php

class Tiny_Config {
    const URL = 'http://webservice/shrink';
}
