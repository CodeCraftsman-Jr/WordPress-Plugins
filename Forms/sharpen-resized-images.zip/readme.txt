=== Sharpen Resized Images ===
Contributors: unsalkorkmaz
Tags: resized, thumbnail, image, sharpen, upload
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.4

Do you realize your resized images looks blur? This plugin fixing it. Sharpening resized jpg image uploads in your WordPress.
== Description ==

This plugin sharpening resized jpg image uploads in your WordPress. You can check screenshot as an example of difference. No settings required.

**Important:** This plugin does NOT affect to uploaded images. It will affect to new uploads after you enabled it.

You can check some examples in [Support Forum](http://wordpress.org/support/topic/plugin-sharpen-resized-images-examples?replies=1)

Sponsored by: [FirmaSite](http://firmasite.com/)

== Installation ==

See [Installing Plugins](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins).

== Screenshots ==

1. Difference

== Changelog ==

= 1.4 =
* Added 3.5 support
* Plugin still using GD library. I will add imagick support for wp3.5 in next release

= 1.3 =
* filters added for users want to change sharpening style
* Check examples: http://wordpress.org/support/topic/plugin-sharpen-resized-images-examples?replies=1

= 1.2.1 =
* an error fix. 

= 1.2 =
* an error fix. 
* a little algorithm change

= 1.1 =
* remove images from memory after resizing

= 1.0 =
* initial release
