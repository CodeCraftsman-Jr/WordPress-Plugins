=== Plugin Name ===
Contributors: nipu.aklima 
Donate link: Not Needed to Donate
Tags: contact, form
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A Simple Contact Form for your WordPress Site.

== Description ==

This contact form can be used for customer feedback or contact.



== Installation ==

1. See "[Installing Plugins](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins "Installing Plugins")" article on the WordPress Codex.
2. To use this plugin on your website, simply activate it in under the �Plugins� section of your WordPress dashboard.
3. Then create a post or page and then simply add the shortcode "[sitepoint_contact_form]" where you want the form to appear.



== Frequently Asked Questions ==

= No questions yet =

An answer to that question will be given if any.


== Changelog ==

No change yet. This is version: 1.0


== Screenshots ==

No screenshots needed, just follow the installation instruction.


== Upgrade Notice ==


No upgrade yet. This is version: 1.0