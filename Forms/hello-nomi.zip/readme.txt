=== Hello Nomi ===
Contributors: Darrell
Requires at least: 3.0
Stable tag: 1.0

This is not just a plugin, it symbolizes my love and undying respect for Showgirls.

== Description ==

Displays a random quote from the movie Showgirls in the uppper corner of your dashboard.