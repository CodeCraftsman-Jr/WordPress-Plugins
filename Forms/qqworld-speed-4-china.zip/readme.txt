=== QQWorld Speed for China ===
Contributors: qqworld
Tags: speed, china
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

如果你的主机在中国，你可能需要这个插件使你的网站跑得更快。If your host is in china, you might need this plugin to make your website to running faster. 

== Description ==

如果你的主机在中国，你可能需要这个插件使你的网站跑得更快。<br />
If your host is in china, you might need this plugin to make your website to running faster.

如果你想更新的时候，不要忘记临时开启这些选项。<br />
If you want to update, don't forget temporarily enable these options.

== Screenshots ==

1. 用户界面
2. User interface

== Installation ==

1. 上传 `qqworld-speed4china` 目录到 `/wp-content/plugins/`
2. 在插件页激活 QQWorld-Speed-for-China插件

1. Upload `qqworld-speed4china` directory into `/wp-content/plugins/`
2. Activate plugin in the plugins admin page

== Changelog ==

= 1.5.4 =
新特性：<br />
前端用360 CDN前端公共资源库替代所有可能的Google字体库<br />
增加后台使用360 CDN前端公共资源库替代Google字体库的选项<br />
New feature:<br />
Using 360 CDN fonts instead all possible googleapi fonts.<br />
Adds option which using 360 CDN fonts instead googleapi fonts on admin page.

= 1.5.3 =
新特性：完善高级加速，开启此项会禁止所有的更新动作，但仍然可以接受核心升级通知。<br />
New feature: Complete advanced speed up, If enabled this option, all update action will be disabled. but still can get update core notification.

= 1.5.2 =
新特性：高级加速，开启此项会禁止所有的更新动作。<br />
New feature: Advanced speed up, If enabled this option, all update action will be disabled..

= 1.5.1 =
修复BUg: 无法上传本地图像
Bug fixed: Can't upload local avatar.<br />

= 1.5 =
新特性：禁用全球通用头像(Gravatar)<br />
New feature: Disabled Gravatar.

= 1.4 =
新特性：重新启用本地字体，因为360网站卫士常用前端公共库CDN服务有时候依然很慢。<br />
New feature: Use local fonts again, becarse of use fonts.useso.com was still slow sometimes.

= 1.3 =
新特性：禁用Dropbox jQuery插件<br />
New feature: Disabled Dropbox-plugin.

= 1.2 =
新特性：使用360网站卫士常用前端公共库CDN服务替代本地字体<br />
New feature: Use fonts.useso.com instead of local fonts.

= 1.1 =
新特性：禁用自动检查更新<br />
New feature: Auto update disabled.

= 1.0 =
新特性：不使用谷歌字体<br />
New feature: Do not using google font.
