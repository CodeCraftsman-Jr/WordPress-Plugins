=== Get Data ===
Contributors: EDC Team
Donate link: http://www.edc.org.kw
Tags: Get, Data, Content, Header, Footer, Ads, Data center, EDC
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 1.0
License: Free

By using Get Data Plugin, you can get content by URL and insert data in header or footer.

== Description ==

By using Get Data Plugin, you can get content by URL and insert data in header or footer.


Features:

* Get content by url
* Insert content in header or footer
* Using start/end element
* You can allow/disallow getting data

Support: [EDC](http://www.edc.org.kw).

== Installation ==

* Upload the Get Data plugin to your blog, Activate it.
* Go to Get Data from menu.
* Insert code <?php if ( function_exists('getting_data') ){ echo getting_data("header"); } ?> in header.php.
* Insert code <?php if ( function_exists('getting_data') ){ echo getting_data("footer"); } ?> in footer.php.


== Screenshots ==

1. In Dashboard
1. Show code
