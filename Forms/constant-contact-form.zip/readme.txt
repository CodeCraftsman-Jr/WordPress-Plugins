=== constant contact form ===
Contributors: gopiplus, www.gopiplus.com 
Donate link: http://www.gopiplus.com/work/2010/07/18/constant-contact/
Author URI: http://www.gopiplus.com/work/2010/07/18/constant-contact/
Plugin URI: http://www.gopiplus.com/work/2010/07/18/constant-contact/
Tags: constant, contact, widget, constant contact
Requires at least: 3.4
Tested up to: 4.3.1
Stable tag: 6.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This constant contact form plugin automatically add your subscribers email address into your constantcontact.com account.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2010/07/18/constant-contact/](http://www.gopiplus.com/work/2010/07/18/constant-contact/)

*   [Live Demo](http://www.gopiplus.com/work/2010/07/18/constant-contact/)	
*   [More info](http://www.gopiplus.com/work/2010/07/18/constant-contact/)				
*   [Comments/Suggestion](http://www.gopiplus.com/work/2010/07/18/constant-contact/)		
*   [About author](http://www.gopiplus.com/work/2010/07/18/constant-contact/)			

This constant contact form plugin automatically add your subscribers email address into your constantcontact.com account.

Very easy and no need any coding language knowledge to use this plug-in. Once the widget is ready, entered emails are automatically stored into your constant contact account.

This WordPress plugin is to integrate constant contact account to your wordpress website.

Add Constant Contact widget email subscribe form to your sidebar with Custom title, Custom text box caption, Custom button style, Custom text box style.

User entered emails are automatically stored in to site admin constant contact account (admin need to provide their own constant contact login details at widget management)

No page refresh, because this widget using Ajax.

**Features of this plugin**

*   Easy to customize
*   Easy styles override option
*   Add email directly to constant contact account
*   Separate CSS file
*   Option to update widget title
*   Option to update email text box caption
*   Option to send auto thanks mail to subscriber
*   Option to set from email address
*   Auto mail to admin when new email subscribed
*   Option to update email subject
*   Option to update email content
*   html email format
*   Option to add the constant contact form into page/post.

[Click here](http://www.gopiplus.com/work/2010/07/18/constant-contact/) to see detail information about this plugin.	

**Plugin configuration**

*   Drag and drop the widget.		
*   Add directly in the theme.		
*   Short code for pages and posts.

**Translators**

* English (en_EN) - [Gopi Ramasamy](http://www.gopiplus.com/)
* Polish (pl_PL) - [Abdul Sattar](https://www.couponmachine.in/)

== Installation ==

[Installation Instruction and Configuration information](http://www.gopiplus.com/work/2010/07/18/constant-contact/)	   

== Frequently Asked Questions ==

[Frequently Asked Questions](http://www.gopiplus.com/work/2010/07/18/constant-contact/)			

== Screenshots ==

1. Front Screen :  http://www.gopiplus.com/work/2010/07/18/constant-contact/	

2. Admin Screen :  http://www.gopiplus.com/work/2010/07/18/constant-contact/

== Changelog ==

= 1.0 =
		
First version.

= 2.0 =

Tested UpTo 3.3

Short code option available(Now we can add this plugin into posts/page using this short code)

JS file included as per wp standard

= 3.0 =

Tested UpTo 3.4

= 4.0 =

New demo link, hhtp://www.gopiplus.com

= 5.0 =

Tested up to 3.4.2

Slight change in the short code, Please find the new short code for your form

= 5.1 =

Tested up to 3.5

= 6.0 =

Tested up to 3.6

= 6.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (constant-contact.po) available in the languages folder.

= 6.2 =

1. Tested up to 3.9

= 6.3 =

1. Tested up to 4.0
2. Form submit files has been changed from this version.

= 6.4 =

1. Tested up to 4.1

= 6.5 =

1. Tested up to 4.2.2

= 6.6 =

1. Tested up to 4.3

= 6.7 =

1. Tested up to 4.3.1
2. Polish language file added in the language directory.
3. Text Domain slug has been added for Language Packs.

== Upgrade Notice ==

= 1.0 =
		
First version.

= 2.0 =

Tested UpTo 3.3

Short code option available(Now we can add this plugin into posts/page using this short code)

JS file included as per wp standard

= 3.0 =

Tested UpTo 3.4

= 4.0 =

New demo link, www.gopiplus.com

= 5.0 =

Tested up to 3.4.2

Slight change in the short code, Please find the new short code for your form

= 5.1 =

Tested up to 3.5

= 6.0 =

Tested up to 3.6

= 6.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (constant-contact.po) available in the languages folder.

= 6.2 =

1. Tested up to 3.9

= 6.3 =

1. Tested up to 4.0
2. Form submit files has been changed from this version.

= 6.4 =

1. Tested up to 4.1

= 6.5 =

1. Tested up to 4.2.2

= 6.6 =

1. Tested up to 4.3

= 6.7 =

1. Tested up to 4.3.1
2. Polish language file added in the language directory.
3. Text Domain slug has been added for Language Packs.