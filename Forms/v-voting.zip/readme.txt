=== v-voting ===
Contributors: niana
Donate link: 
Tags: event voting
Requires at least: 3.3
Tested up to: 3.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

these is a buddypress plugin which held virtual event as contest were user can create  his own event or participate in other members event, every user is been allocated initial number of vote for every event which they can give to the people invited in that particuler event then the conest is held till the last date as specified by event creater at the end of the event top three user based on vote count they got from other user are displayed

== Description ==

these plugin create a custom post type voting which is uses to store the event information it also create database for storing the voting details of every user for particular event

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates



