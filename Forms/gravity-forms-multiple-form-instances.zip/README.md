Gravity Forms: Multiple Form Instances
=====================================

### Version 1.0.9

-----

#### About

**Gravity Forms: Multiple Form Instances** is a small plugin for WordPress.

Used in conjunction with the awesome [Gravity Forms](http://www.gravityforms.com/) plugin.

Allows multiple instances of the same form to be displayed on a single page when using AJAX.

-----

#### Installation & Configuration

This plugin does not need any customization. 

Simply install and activate it, and it will do its magic with your Gravity Forms.