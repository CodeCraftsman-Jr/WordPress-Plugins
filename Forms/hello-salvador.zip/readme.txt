=== Hello Salvador ===
Contributors: sergiuscosta, leobaiano
Donate link: http://www.sergiocosta.net.br/
Tags: salvador, bahia, brasil, beach, missing, city, wordcamp, wordcana, wordcampsalvador, wordpress bahia, wordpress brasil, wordpress salvador
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

For whose missing Salvador, Bahia

== Description ==

= A very fancy way to remember Salvador while working with WordPress :) =

== Installation ==

1. Upload `hello-salvador` folder to the `/wp-content/plugins/` directory or install into the administrator panel
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Enjoy!