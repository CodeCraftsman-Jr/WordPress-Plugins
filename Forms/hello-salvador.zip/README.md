# Hello Salvador

WordPress plugin for whose missing Salvador, Bahia

Just install and enjoy! =D

## License
[![WTFPL](wtfpl-badge.png "WTFPL")](https://github.com/zergiocosta/hello-salvador/blob/master/LICENSE)
