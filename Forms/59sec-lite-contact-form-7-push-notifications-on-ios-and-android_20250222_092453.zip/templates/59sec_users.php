<p>UNANSWERED LEADS: <?php echo $leadsModel->getTotalUnansweredLeads()?></p>
<ul class="subsubsub">
	<li><?php echo $leadsLink?></li>
	<li><?php echo $crmLink?></li>
</ul>
<br class="clear-subsubsub"/>
<ul class="subsubsub">
	<li><?php echo $statisticsLink?></li>
	<li><?php echo $sourcesLink?></li>
	<li><?php echo $usersLink?></li>
	<li><?php echo $notificationsLink?></li>
	<li><?php echo $otherOptionsLink?></li>
	<li><?php echo $helpLink?></li>
</ul>
<h2>Users</h2>
<p>Explanation: Wordpress administrators have full access by default, as sales manager! </p>
<h3>Sales Agents</h3>
<p>If you have sales agents, you should create normal &quot;subscribers&quot; wordpress users,  then check them here to grant them Agent Level access (Leads, Statistics, CRM). This way, they cannot mess up your site! :). This &quot;sales agents&quot; feature is available only for 59sec PRO.</p>
<p><span class="description">
  <label><a href="https://www.59sec.biz/site/subscribe&quot;" target="_blank"><strong>Download now the 59sec PRO plugin!</strong></a></label>
  <br />
<a href="http://www.59sec.com">First month is FREE to test. No credit card, no strings attached! </a>:)</span></p>
<form name="capForm" method="post" action="">
<table class="wp-list-table widefat fixed users" cellspacing="0">
	<thead>
	<tr>
		<th scope="col" id="cb" class="manage-column column-cb check-column" style="">
			<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
			<input id="cb-select-all-1" type="checkbox">
		</th>
		<th scope="col" id="username" class="manage-column column-username" style="">
			<span>Username</span>
		</th>
		<th scope="col" id="name" class="manage-column column-name" style="">
			<span>Name</span>
		</th>
		<th scope="col" id="email" class="manage-column column-email" style="">
			<span>E-mail</span>
		</th>
		<th scope="col" id="key" class="manage-column column-key" style="">
			<span>Key</span>
		</th>
		<th scope="col" id="role" class="manage-column column-role" style="">
			<span>Role</span>
		</th>
	</tr>
	</thead>

	<tfoot>
	<tr>
		<th scope="col" class="manage-column column-cb check-column" style="">
			<label class="screen-reader-text" for="cb-select-all-2">Select All</label>
			<input id="cb-select-all-2" type="checkbox">
		</th>
		<th scope="col" class="manage-column column-username" style="">
			<span>Username</span>
		</th><th scope="col" class="manage-column column-name" style="">
			<span>Name</span>
		</th>
		<th scope="col" class="manage-column column-email" style="">
			<span>E-mail</span>
		</th>
		<th scope="col" id="key" class="manage-column column-key" style="">
			<span>Key</span>
		</th>
		<th scope="col" class="manage-column column-role" style="">
			<span>Role</span>
		</th>
	</tr>
	</tfoot>

	<tbody id="the-list" data-wp-lists="list:user">
	<?php foreach($users as $key => $user):?>
	<tr id="user-<?php echo $user->ID?>" class="<?php if ($key % 2 != 0) echo 'alternate'?>">
		<th scope="row" class="check-column">
			<label class="screen-reader-text" for="cb-select-<?php echo $user->ID?>">Select Agent</label>
			<input type="checkbox" name="users[]" id="user_<?php echo $user->ID?>" class="subscriber" value="<?php echo $user->ID?>" <?php echo $checked?> />
		</th>
		<td class="username column-username">
			<?php echo get_avatar($user->ID, 32)?>
			<strong><?php echo $user->user_login?></strong>
		</td>
		<td class="name column-name"><?php echo $user->display_name?></td>
		<td class="email column-email">
			<a href="mailto:<?php echo $user->user_email?>" title="E-mail: <?php echo $user->user_email?>"><?php echo $user->user_email?></a>
		</td>
		<td class="key column-key"><?php echo _59sec_salt($user->user_login)?></td>
		<td class="role column-role"><?php echo $user->roles['0']?></td>
	</tr>
	<?php endforeach?>
	</tbody>
</table>
<input type="submit" name="op" value="Save" class="button button-primary" />
</form>