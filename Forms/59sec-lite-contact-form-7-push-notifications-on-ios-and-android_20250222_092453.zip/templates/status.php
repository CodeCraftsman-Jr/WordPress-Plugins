<h2>Plugin Status</h2>
<p><?php echo _59SEC_STATUS?></p>
