<p>UNANSWERED LEADS: <?php echo $leadsModel->getTotalUnansweredLeads()?></p>
<ul class="subsubsub">
	<li><?php echo $leadsLink?></li>
	<li><?php echo $crmLink?></li>
</ul>
<br class="clear-subsubsub"/>
<ul class="subsubsub">
	<li><?php echo $statisticsLink?></li>
	<li><?php echo $sourcesLink?></li>
	<li><?php echo $usersLink?></li>
	<li><?php echo $notificationsLink?></li>
	<li><?php echo $otherOptionsLink?></li>
	<li><?php echo $helpLink?></li>
</ul>
<h2>Please Feedback!</h2>
 <p>Hello Wordpress fans (like me)</p>
 <p>I am Constantin Ferseta, founder of 59sec. Thank you for using my &quot;baby&quot;. :)<br />
   As we really want 59sec (lite/pro/enterprise) to work for you, to help you make more money, we need your feedback. Praizes, rotten tomatos, bug reports, features request, etc, etc..</p>
<p>Can you please share with me your thoughts? Any feedback would be highly appreciated!</p>
<p>My email is <strong>noro@59sec.com</strong>. So, hit me:) Thank you in advance.</p>
<p>Have a great day<br />
<a href="https://www.59sec.com/us" target="_blank">Constantin Ferseta</a><br />
 59sec Founder<br />
</p>
