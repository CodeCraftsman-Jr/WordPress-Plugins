=== Plugin Name ===
Contributors: markcoker
Tags: Fancy Date Stamp, DateStamp, Date, Pretty, Fancy, Stamp, Fun, Exciting, Blog, Automatic, Free
Requires at least: 3.0.1
Tested up to: 3.5.1
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This provides you with a nice way of displaying the date in your posts. This took a whole day *sigh* amateur hour.

== Description ==

I made this for a site i was making for a friend, thought others might like to use it. The way its loaded is not the most efficient but feel free to change it!

I tested this on the Twenty Eleven and it seemed to be ok. (needs more testing though)

This concludes my first plugin description :).

Enjoy!!!

== Installation ==

1. Activate the plugin through the 'Plugins' menu in WordPress
2. Type [date-stamp] in your post. It will then appear correctly in post.

== Screenshots ==

1. This is how it looks!

== Changelog ==

= 0.1 =
Let it Begin!
= 0.2 =
Local CSS & Image Reference
= 0.3 =
Fixed strip display issue