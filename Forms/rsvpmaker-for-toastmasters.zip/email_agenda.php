<?php
global $post;
awesome_open_roles($post->ID);
?>
