Translations may be created with POEdit - http://www.poedit.net/

The base file you open for translations opportunities is rsvptoast.pot

Translations should be saved with the filename pattern rsvptoast-[locale].po

Example: rsvptoast-fr_FR.po for French. The POEdit tool will help you identify the correct language and country codes.0

The tool will also generate a compiled version of the translation with a .mo file extension

Please share your work so we can include it in future updates to RSVPMaker for Toastmasters! Submit the files you have create here:
http://wp4toastmasters.com/translations/

Thank you!

How-To Articles
http://codex.wordpress.org/Translating_WordPress
http://urbangiraffe.com/articles/translating-wordpress-themes-and-plugins/