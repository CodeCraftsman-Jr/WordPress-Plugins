<?php

//Incude critical files
require 'load.php';
require 'model.php';
require 'controller.php';

//Call The main Controller
new FC_Controller();

?>