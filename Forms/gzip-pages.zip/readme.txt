=== Plugin Name ===
Contributors: Austin Matzko, filosofo
Donate link: http://www.ilfilosofo.com/blog/2008/02/22/wordpress-gzip-plugin/
Tags: gzip, compression, server
Requires at least: 2.5
Tested up to: 2.8.3
Stable tag: 1.1

Allow GZIPped output for your WordPress blog.  Restores functionality removed in WordPress 2.5.

== Description ==

Allow GZIPped output for your WordPress blog.  Restores functionality removed in WordPress 2.5.

== Installation ==

1. Upload `filosofo-gzip-compression.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
