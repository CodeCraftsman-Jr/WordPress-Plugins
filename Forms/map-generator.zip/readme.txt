=== Map-Generator ===
Contributors: MapGenerator
Donate link: http://map-generator.net/
Tags: maps, google maps, street view, generator, shortcode, marker, infowindow, weather forecast
Requires at least: 3.0
Tested up to: 3.4
License: GPLv3 
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Add Google Maps and Street View Scence to you blog.

== Description ==

This Plugin adds custom maps from <a href="http://map-generator.net/">Map-Generator.net</a> to your blog.
You can insert Maps with:

* Multible markers
* Custom Markers
* Info Windows (Title and Description)
* Street View Windows
* Weather Forecast  (Weather Maps)
* Live Clouds

== Installation ==

1. Install Map-Generator either via the WordPress.org plugin directory, or by uploading the files to your server.
2. After activating Map-Generator in your Plugin Panel, you are ready to go!. 

== Screenshots ==

1. The Plugin adds shortcode functionality for maps from <a href="http://map-generator.net/">Map-Generator.net</a> and a Button in your WYSIWYG-Editor
2. On Click you'll get an interface to insert your Map
3. Some examples...
4. Weather Maps default
5. Weather Maps Info
6. Weather Maps Clouds

== Changelog ==

= 1.3 =
* fixed bug "missin semicolons"

= 1.2 =
* opend Plugin for other providers

= 1.1 =
* update License to GPLv3 

= 1.0 =
* Initial release