<?php

include_once('embed-shortcode.php');
include_once('embed-config.php');

?>