<?php
/**
* ChronoCMS version 1.0
* Copyright (c) 2012 ChronoCMS.com, All rights reserved.
* Author: (ChronoCMS.com Team)
* license: Please read LICENSE.txt
* Visit http://www.ChronoCMS.com for regular updates and information.
**/
namespace GCore\Admin\Modules\Toolbar;
/*** FILE_DIRECT_ACCESS_HEADER ***/
defined("GCORE_SITE") or die;
class Toolbar extends \GCore\Helpers\Module{
	var $helpers = array('\GCore\Helpers\Toolbar', '\GCore\Helpers\Assets');
	
	public static function display($module){
		
	}
}