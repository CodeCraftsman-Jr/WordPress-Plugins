=== Plugin Name ===
Contributors: maxpayne-1, rm2773
Tags: email, form, contact form, web form, contact us, feedback, AJAX, uploads, Auto Responder, Captcha, ReCaptcha, contact, PayPal, Google spreadsheets, Authorize.net, 2Checkout, Bootstrap
Requires at least: 3.0
Tested up to: 4.9.9
Stable tag: 5.0.9
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html

Add any type of forms to your WordPress site quickly using your own HTML code, setup emails, Auto responders, Captcha and more.

== Description ==

The fastest way to have a form on your WordPress website, Design your form using drag and drop wizard or using your preferred HTML editor, control your form's execution using a LEGO like actions and events system, building forms can't be easier or more powerful than Chronoforms!

Many basic and advanced features like Bootstrap support, custom CSS & JS, Emails & auto replies, database read/save, captcha/reCaptcha/HoneyPot protection, CURL, AJAX support, Datepicker, Payment gateways support (PayPal Pro & Authorize.net), server and client fields validation and many more.

Use short code [Chronoforms5 chronoform="YOUR_FORM_NAME"]

All support/docs/FAQs on our website www.ChronoEngine.com

== Changelog ==

= 5.0.9 =
* More enhancements and features including: signature pad widget, Google NoCaptcha, Google sheets support, PayPal Redirect, PDT & Pro, and more...

= 5.0.3 =
* added diagnostics support to the forms manager.
* added new 2Checkout actions for extra payment support.
* made few enhancements to few actions.

= 5.0 =
* V5.0 complete

== Upgrade Notice ==

= 5.0 =
* V5.0 complete