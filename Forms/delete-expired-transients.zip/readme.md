# Delete Expired Transients #

delete old, expired transients from WordPress wp_options table

* [Home](http://shop.webaware.com.au/downloads/delete-expired-transients/)
* [GitHub](https://github.com/webaware/delete-expired-transients)
* [Readme](https://github.com/webaware/delete-expired-transients/blob/master/readme.txt)
* [Download](https://wordpress.org/plugins/delete-expired-transients/)
* [Documentation](https://wordpress.org/plugins/delete-expired-transients/faq/)
* [Support](https://wordpress.org/support/plugin/delete-expired-transients)
* [Translate](https://translate.webaware.com.au/projects/delete-expired-transients)
* [Donate](http://shop.webaware.com.au/downloads/delete-expired-transients/)
