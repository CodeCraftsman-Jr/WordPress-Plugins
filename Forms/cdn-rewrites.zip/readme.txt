=== CDN Rewrites ===
Contributors: Phoenixheart
Donate link: http://www.phoenixheart.net/wp-plugins/cdn-rewrites/
Tags: cdn, content delivery network, bandwidth, rewrites
Requires at least: 2.2
Tested up to: 3.0
Stable tag: 1.0.1