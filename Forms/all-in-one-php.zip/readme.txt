=== All In One Php ===
Contributors: swadeshswain , aiswaryaswain
Tags: page,widget,php,text,sidebar,post,content,title
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 4.2

Executes PHP code on WordPress page ,page and on default Text Widget

== Description ==

All In One Php  Run PHP code inserted into WordPress posts and pages and Text Widget 
also you can add php code in your post or page title section.


The PHP code runs as the page is sent to the browser. Output of the PHP code is published
 directly onto the post , page or widget section where the PHP code   is located.
you  can be activated without any fear.

Examples of use:

<ul>
<li>Use the php code on your page,post ,default text widget ,page title or post title
<?php echo "Hello World !" ; ?>
</li>
</ul>

== Installation ==

1. Put the All in One Php to plugin folder "/wp-content/plugins/"
2. Go into the WordPress admin pannel and activate the plugin
3. Enjoy

== Frequently Asked Questions ==

See the plugin offical page.

== Screenshots ==

1. screen 1
2. screen 2
3. screen 3

== Changelog ==

= 1.0 =


All In One Php  Run PHP code inserted into WordPress posts and pages and Text Widget 
also you can add php code in your post or page title section.