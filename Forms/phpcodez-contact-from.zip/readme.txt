=== PHPCodez Contact From ===

Contributors: Pramod T P
Donate link: http://phpcodez.com/
Tags: Contact Form
Tested up to: 3.4.1
Requires at least: 2.0
Stable tag: 2.0

PHPCodez Contact From allows you to add a feedback form easilly and simply to a post or a page.

== Description ==

PHPCodez Contact From allows you to add a feedback form easilly and simply to a post or a page.

Features

1) We can manage the field labels

2) We can manage error messages

3) We can block/enable fields

4) We can manage the email address

5) We can manage success message

== Installation ==

1. Upload the plugin folder to your /wp-content/plugins/ folder.

2. Go to the **Plugins** page and activate the plugin.

3. Add a new page/post with shortcode [phpcodez-contact-form]

== Screenshots ==

1) Plugin admin panel options
2) Contact form

