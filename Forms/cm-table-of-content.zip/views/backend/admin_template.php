<div class="wrap">
    <h2>
        <div id="icon-<?php echo CMTOC_MENU_OPTION; ?>" class="icon32">
            <br />
        </div>
        <?php CMTOC_Pro::_e(CMTOC_NAME); ?>
    </h2>

    <?php CMTOC_Pro::cmtoc_showNav(); ?>

    <?php echo $content; ?>
</div>