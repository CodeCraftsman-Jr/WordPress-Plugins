jQuery(document).ready(function($) {
    $('html').attr('id','cf7-styles'); 
});