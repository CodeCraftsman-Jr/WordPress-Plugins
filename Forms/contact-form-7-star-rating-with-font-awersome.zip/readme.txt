=== Contact Form 7 Star Rating with font Awesome ===
Contributors: themelogger
Tags: font Awesome, awesome, Star Rating, Stars, Rating, Contact Form 7, form, forms, contactform7, contact form, cf7, cforms ii, cforms, Contact Forms 7, Contact Forms, contacted, contacts,jQuery Star Rating
Requires at least: 3.8
Tested up to: 4.0
Stable tag: trunk
License: GPLv2

This plugin adds Star Rating fields with font Awesome to Contact Form 7.

== Description ==

This plugin adds Star Rating fields with font Awersome to Contact Form 7.

<h4>Visit the official <a href="http://www.themelogger.com/contact-form-7-star-rating-plugin-font-awersome/" rel="dofollow">Contact Form 7 Star Rating field with Font Awesome icons</a> for view demo page & additional information</h4>


Features:
 - setting option 'Required field'
 - setting custom weights to each rating field: 
    - min (start) value of rating (optional, 1 by default)    
    - max value of rating (optional, 10 by default)    
    - step (optional, 1 by default)    
 - setting predefined (default) value of the rating (optional, 0 by default) 
 - using Font Awesome icons instead of images - set different icons for every rating field 
 - setting option 'Show result value of rating' 
 - setting id and class of the rating field (optional) - use it to style icons and result value (size, color, text-shadow) in css file 
 - shortcode to include rating result in email 
 - unlimited rating fields in one form


== Installation ==
1. Upload plugin files to your plugins folder, or install using WordPress  built-in Add New Plugin installer
2. Activate the plugin
3. Edit a form in Contact Form 7
4. Choose "Star Rating Awersome" from the Generate Tag dropdown
5. Follow the instructions on the page


= 1.2 =
* Tested WP up to: 4.2.4
* Tested CF7 up to: 4.2.2
* Tested Font Font-Awesome : 4.4

= 1.1 =
* Tested up to: 4.0
* Font Awesome 4.2.0

= 1.0 =
* Initial release
