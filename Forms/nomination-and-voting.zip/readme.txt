=== Plugin Name ===
Contributors: macmonir
Tags: nomination,nominations, voting, vote, nomination and voting, nominations and voting, nomination and vote, nominations and vote
Requires at least: 2.0.2
Tested up to: 4.2.2

== Description ==
This plugin allows user to nominate their favourites using their facebook or twitter account when the plugin is in nomination mode. And when in voting mode,users can vote using their facebook or twitter account. admin can see the nominee list, voter list in the admin panel.

== Installation ==
1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. for the voting panel to show in a page, admin need to paste this short code "[wp_voting]" to any page. And user can vote by going to that page.

== Frequently Asked Questions ==
1. is it easy to install and use?
Ans: yes it is easy to install and use.
An answer to that question.

== Screenshots ==
1. it allows user to nominate and vote