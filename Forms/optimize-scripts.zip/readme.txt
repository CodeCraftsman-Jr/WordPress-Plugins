=== Optimize Scripts (Obsolete) ===
Contributors: westonruter
Tested up to: 2.8.6
Requires at least: 2.8
Stable tag: trunk

OBSOLETE: Concatenates, minifies & optimizes scripts using Google's Closure Compiler. For other scripts (on CDNs), removes default 'ver' query param.

== Description ==

***DON'T USE THIS PLUGIN***

**This plugin has not been updated in years.** It has been obsoleted by the [Dependency Minification](http://wordpress.org/plugins/dependency-minification/) plugin which does also minifies stylesheets in addition to scripts. Please use it instead.
