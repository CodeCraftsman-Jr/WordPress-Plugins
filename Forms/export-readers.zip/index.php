<?php /*
Plugin Name: ExportReaders
Plugin URI: http://exportreaders.dcoda.co.uk/
Description: Selectively export all your reader details ( users and commenters )
Author: dcoda
Author URI: 
Version: 1.3.47
License: GPLv2 or later
*/