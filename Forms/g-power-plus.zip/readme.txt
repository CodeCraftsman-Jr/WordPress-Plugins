=== G Power Plus List Building Plugin===
Contributors: jennyclicks
Donate link: http://listbuilding.in/
Tags: list, email marketing, marketing, list building, aweber, getresponse, google plus one
Requires at least: 2.0.2
Tested up to: 3.2.1
Stable tag: 4.3

G Power Plus Plugin is part of G Power Plus list building app. The one & only list building and email marketing plugin.

== Description ==

The first list building Wordpress plugin ever developed proving to be a boon to Internet marketers.

G Power Plus Plugin is part of G Power Plus list building app. This plugin adds a customized link to posts, sidebar & footer to turn Google plus one into subscribers OR you can ask your users to SIGN IN with their Google OR Google Apps account for a bonus report or anything & in the background they will be automatically subscribed to your list. Supports Aweber, GetResponse, iContact, ImnicaMail & TrafficWave autoresponders.

For more details about this first ever list building Wordpress plugin visit [www.ListBuilding.in]: http://listbuilding.in "www.ListBuilding.in"


== Installation ==

Installing G Power Plus Wordpress plugin is very easy. Just copy the "gpowerplus.php" file & paste it into your wp-content/plugins folder.
For detailed instruction on how to install manually, visit http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation

After installing the plugin, the next thing you need to do is activate the plugin by logging in to your Wordpress blog admin panel & clicking on installed plugins 
sub menu link. Once you activate G Power Plus plugin, you will find a new tab in Settings tab. Just click on G Power Plus Settings tab & follow the instructions there.

For any help, contact www.jennyclicks.com/support

== Frequently Asked Questions ==

Q.What this plugin is all about?

This is the first ever list building plugin Wordpress has ever seen. It adds a simple link (you can customize anchor text) to your blog posts, side bar & footer to 
turn Google plus ones into subscribers. For more details about the plugin, visit www.ListBuilding.in

Q.I need some help with plugin?

You are more than welcome to contact JennyClicks support for any help, suggestions & feedback by visiting www.jennyclicks.com/support

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot

== Changelog ==

= 1.0 =
The most recent version of G Power Plus plugin.
