<span class="gfeway_recurring_left <?php echo $spanClass; ?>">
<input type="hidden" name="<?php echo $inputName; ?>" value="<?php echo esc_attr($periods[0]); ?>" />
<label class="<?php echo $field['label_class']; ?>" for="<?php echo $field_id; ?>" id="<?php echo $field_id; ?>_label"><?php echo $label; ?></label>
</span>
