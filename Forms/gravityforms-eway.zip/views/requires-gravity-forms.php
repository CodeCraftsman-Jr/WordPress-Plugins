
<div class="error">
	<p>Gravity Forms eWAY requires <a target="_blank" href="http://webaware.com.au/get-gravity-forms">Gravity Forms</a> to be installed and activated.</p>
</div>
