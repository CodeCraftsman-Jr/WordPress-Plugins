
<select name="payment_status">
	<option value="<?php echo esc_attr($payment_status); ?>" selected="selected"><?php echo esc_html($payment_status); ?></option>
	<option value="Approved">Approved</option>
</select>

