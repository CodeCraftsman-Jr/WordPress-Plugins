<span class="gfeway_recurring_left <?php echo $spanClass; ?>">
<input name="<?php echo $inputName; ?>" id="<?php echo $field_id; ?>" type="text" value="<?php echo $value; ?>" class="ginput_amount <?php echo $class; ?>" <?php echo $tabindex; ?> <?php echo $disabled_text; ?> />
<label class="<?php echo $field['label_class']; ?>" for="<?php echo $field_id; ?>" id="<?php echo $field_id; ?>_label"><?php echo $label; ?></label>
</span>
