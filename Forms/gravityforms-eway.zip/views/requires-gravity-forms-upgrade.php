
<div class="error">
	<p>Gravity Forms eWAY requires <a target="_blank" href="http://webaware.com.au/get-gravity-forms">Gravity Forms</a> version
	<?php echo esc_html(GFEwayPlugin::MIN_VERSION_GF); ?> or higher; your website has Gravity Forms version <?php echo esc_html(GFCommon::$version); ?>.</p>
</div>
