# Gravity Forms eWAY #

Integrate [Gravity Forms](http://webaware.com.au/get-gravity-forms) with the eWAY credit card payment gateway

* [Home](http://shop.webaware.com.au/downloads/gravity-forms-eway/)
* [GitHub](https://github.com/webaware/gravityforms-eway/)
* [Readme](https://github.com/webaware/gravityforms-eway/blob/master/readme.txt)
* [Download](https://wordpress.org/plugins/gravityforms-eway/)
* [Documentation](https://wordpress.org/plugins/gravityforms-eway/faq/)
* [Support](https://wordpress.org/support/plugin/gravityforms-eway)
* [Donate](http://shop.webaware.com.au/downloads/gravity-forms-eway/)
