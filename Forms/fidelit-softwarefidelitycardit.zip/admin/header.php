<?php 
$id = isset($_REQUEST['id']) ?  (int)$_REQUEST['id'] : 0;
?>
<div class="icon32"><img src="<?=plugins_url( '/images/favicon-32.png' , __FILE__ );?>" /></div>
<h2>FidEl&iacute;t - Pannello di configurazione</h2>
<p></p>