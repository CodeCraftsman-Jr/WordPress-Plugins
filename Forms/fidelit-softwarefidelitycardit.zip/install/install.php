<?php

add_option("fidelit_api_secret", "");
add_option("fidelit_api_key", "");

?>
