<?php

delete_option("fidelit_api_secret");
delete_option("fidelit_api_key");

?>