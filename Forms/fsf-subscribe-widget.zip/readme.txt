===FSF Subscribe Widget ===
Contributors: sethradio
Tags: fsf,subscribe,widget,free software
Requires at least: 2.8
Tested up to: 4.2
Stable tag: 1.2

Allows visitors to your blog to subscribe to the FSF mailing list.

== Description ==

This plugin is a widget that you can put on your blog that allows users 
to subscribe to the FSF newsletter. More features will come in later 
versions. 
Remember, in the wise words of Matt Mullenweg, "1.0 is the lonliest number."

== Installation ==

1. Install this plugin just like any other one.
2. Drag the FSF Subscribe Widget to your sidebar.

== Changelog ==

= 1.0 =
* First Release.
= 1.1 =
* Added "searchsubmit" id to the button to make it look better.
= 1.2 =
*Changed "searchsubmit" id to "block-button".
