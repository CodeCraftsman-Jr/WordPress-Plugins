<div class="message <?php echo $message->type; ?>">
    <p><?php echo $message->text; ?></p>
</div>