=== ZigOut ===
Contributors: ZigPress
Donate link: http://www.zigpress.com/donations/
Tags: widget, sidebar, image, the out campaign, richard dawkins, scarlet letter, atheism, atheist A, scarlet A, zig, zigpress
Requires at least: 3.6
Tested up to: 4.3
Stable tag: 0.2.6

Puts the famous OUT Campaign "Scarlet A" on your site.

== Description ==

NOTE: ZIGOUT REQUIRES PHP 5.3!

ZigOut gives you a simple widget that shows the OUT Campaign's Atheist "A" on your sidebar or other widget area, with various options available to customise it.

For further information and support, please visit [the ZigOut home page](http://www.zigpress.com/plugins/zigout/).

== Installation ==

1. Unzip the installer and upload the resulting 'zigout' folder to the `/wp-content/plugins/` directory.  Alternatively, go to Admin > Plugins > Add New and enter ZigOut in the search box.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to the Widgets admin page and place the widget.

== Frequently Asked Questions ==

For further information and support, please visit [the ZigOut home page](http://www.zigpress.com/plugins/zigout/).

== Changelog ==

= 0.2.6 =
* Confirmed compatibility with WordPress 4.3
= 0.2.5 =
* Confirmed compatibility with WordPress 4.2.2
* Updated classes to use PHP5 constructors to satisfy WordPress Changeset 32990
* Hide warnings sometimes shown in widget form
= 0.2.4 =
* Confirmed compatibility with WordPress 4.2
* Increased minimum PHP version to 5.3 in accordance with ZigPress policy of gradually dropping support for deprecated platforms
= 0.2.3 =
* Confirmed compatibility with WordPress 4.1
* Minimum compatible version raised to 3.6
= 0.2.2 =
* Confirmed compatibility with WordPress 3.9
= 0.2.1 =
* Confirmed compatibility with WordPress 3.5
= 0.2 =
* Coding style improvements
* Caption now links as well as image
* Fixed bug that prevented the caption from being hidden
* Confirmed compatibility with WordPress 3.4.2
= 0.1.2 =
* Confirmed compatibility with WordPress 3.3.x
= 0.1.1 =
* Confirmed compatibility with WordPress 3.2.x and updated version requirements accordingly
= 0.1 =
* First public release
