﻿=== Plugin Name ===
Contributors: Sumith Harshan 
Donate link: http://webexplorar.com/wordpress-arabic-virtual-keyboard-plugin/
Tags: Sumith Harshan,Arabic,Keyboard,Virtual,Unicode
Requires at least: 2.8
Tested up to: 4.2.2
Stable tag: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Make it very easy to type using this virtual keyboard without any 3rd party Software or Web sites.Really easy to type in Arabic language.

== Description ==

If you have a Wordpress Blog you can use this plugin. This Plugin make it really easy to type in in Arabic language.There is no need of any other Web Sites or Software. 
You can search something in Google or Youtube by using this keyboard.
If your keyboard is not working, or you can type in mobile phone easy using this virtual keyboard.
You can use <strong>[wp-arabic-virtual-keyboard]</strong> shortcode to display the keyboard any page or post.
No usages of images. Only css and text usages.

<h4>Browser Compatible</h4>
* **Firefox 16+**
* **Chrome 20+**
* **Internet Explorer 7,8,9,10**
* **Safari**
* **Opera**


== Installation ==


1. Upload "wp-arabic-keyboard" file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to "Arabic Keyboard" for more instructions. 

* **If you more details visit official plugin Page.**
http://webexplorar.com/wordpress-arabic-virtual-keyboard-plugin/

== Frequently Asked Questions ==

= Not correctly displaying arabic characters. = 
Make sure the following meta tag is exist immediately after head tag.If not exist add it.
`<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />`
	
= Not properly displaying arabic characters and layout in some web browser. = 
Make sure the following meta tag is exist immediately after head tag.If not exist add it.
`<meta http-equiv="X-UA-Compatible" content="IE=Edge, chrome=1"/>`
	 
= More questions? =
Visit the Plugin Page. Ask questions. Plugin author will be glad to answer.
* **http://webexplorar.com/wordpress-arabic-virtual-keyboard-plugin/**


== Screenshots ==

1. Arabic Virtual Keyboard structure.


== Other Notes ==
In the next version you can enable/disable keys of the keyboard and will add responsive compatible features.


== Changelog ==

= 1.0 =
First version os the plugin.


= 1.5 =

* Bugfixes:
	* Fixed "$ is not a function" issue.
	* Fixed jQuery conflicting issue.
 
* Enhancements:
	* Removed settings and added shortcode function.Users can use <strong>[wp-arabic-virtual-keyboard]</strong> shortcode to display the keyboard any page or post.
	* Added jQuery latest library file.(Version 2.1.1)


= 2.0 =
* Added "Copy" key and copy to clipboard function.
* Remove "Youtube Search" key.