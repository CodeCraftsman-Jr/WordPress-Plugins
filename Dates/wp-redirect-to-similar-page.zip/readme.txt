=== WP Redirect to similar page ===
Contributors: librafire
Donate link: http://www.librafire.com/
Tags: 404 redirect, redirect to similar page, no 404 page
Requires at least: 4.0.1
Tested up to: 4.0
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Redirects a user to the most similar page to the url given in adress bar.

== Description ==

Redirects a user to the page (for example) about-me if he typed about-me1 or abbout-me214 or any similar case.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `redirect-to-similar.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Your 404 page won't be reached ever.

== Frequently Asked Questions ==

= A question that someone might have =

Q: What should I do after the instalation?
A: Nothing. You can disable this functionality by disabling the plugin.

== Screenshots ==

== Changelog ==

= 1.0 =

== Upgrade Notice ==

= 1.0 =





