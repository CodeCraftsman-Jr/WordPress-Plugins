<?php 
//This is a premium feature, please upgrade
echo espresso_premium_feature(); 
?>