tinyMCE.loadPlugin('xhtmlxtras', "../wp-content/plugins/tiny-xhtml/xhtmlxtras");
