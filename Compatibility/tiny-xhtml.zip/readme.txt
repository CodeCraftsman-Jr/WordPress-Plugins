=== Tiny XHTML ===
Contributors: tompahoward
Donate link: http://windyroad.org/software/wordpress/tiny-xhtml-plugin/#donate
Tags: Formatting, post, admin, editor, xhtml, id, class, onclick, Windy Road
Requires at least: 2.2
Tested up to: 2.2
Stable tag: 0.0.2

The Tiny XHTML plugin re-adds the xhtmlxtras plugin to the TinyMCE Rich Visual Editor

== Description ==

The Tiny XHTML plugin re-adds the xhtmlxtras plugin support to the TinyMCE Rich Visual Editor.
The TinyMCE table plugin is normally bundled with TinyMCE, but it has be removed from the
version within WordPress.  This plugin puts it back in.

The xhtmlxtras TinyMCE plugin allows you to control common attributes, such as class, id, lang, onclick, etc.
It also provides buttons for creating cite, ins, del, abbr, and acronym elements.

Most of the credit for this plugin belogns to [Moxiecode Systems] (http://tinymce.moxiecode.com/ ),
who wrote the Table plugin for TinyMCE, which this plugin uses.

== Installation ==

1. copy the 'tiny-xhtml' directory to your 'wp-contents/plugins' directory.
1. Activate the Tiny XHTML plugin in your plugins administration page.
1. You will now see extra buttons when using the the TinyMCE Rich Visual Editor.

== Screenshots ==

1. Tiny XHTML in Action

== Frequently Asked Questions ==

Got any questions?

== Release Notes ==
* 0.0.2
	* Added workaround for TinyMCE compressor issues.
* 0.0.1
	* Fixed defect in link to xhtmlxtras stylesheet
* 0.0.0 
	* Initial Release