=== Inspire Dolly ===
Contributors: meabhisek
Tags:   quotes, quote, inspiration, authors, admin, content
Requires at least: 3.0
Tested up to: 4.3
Stable tag: 1.0.2
License: GPLv2

Get random quotes on every page of the admin area inspiring you to be a fearless writer.


== Description == 

Inspire Dolly is based on Matt Mullenweg's [Hello Dolly](https://wordpress.org/plugins/hello-dolly/) Plugin.When you enable this plugin, on every page of the admin area it shows a random quote that inspires you to be a fearless writer and produce awesome content.

Follow the developer on [Twitter](https://twitter.com/twitabhisek)

**Download My Other Plugins**

* [Mini Membership](https://wordpress.org/plugins/mini-membership/)
* [Private Content Login Redirect](https://wordpress.org/plugins/private-content-login-redirect/)
* [Rainbow Status](https://wordpress.org/plugins/rainbow-status/)
* [Restrict Dashboard Access](https://wordpress.org/plugins/restrict-dashboard-access/)
* [WP Admin Color Schemes](https://wordpress.org/plugins/wp-admin-color-schemes/)
* [Frame Breaker](https://wordpress.org/plugins/frame-breaker/)

==Installation== 

1. Download Inspire Dolly package file, extract inspire-dolly directory from ZIP file, upload it to WordPress Plugins directory '/wp-content/plugins/' or install plugin from Plugin panel in WordPress Dashboard.

2. Activate Inspire Dolly via Plugin page.                 

3. Get Inspired.

If you are new to WordPress : [Installing Plugins](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins)