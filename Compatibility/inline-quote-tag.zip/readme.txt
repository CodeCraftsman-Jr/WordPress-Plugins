=== Inline Quote Tag  ===
Contributors: husobj
Donate link: http://www.benhuson.co.uk/donate/
Tags: html, quote, editor
Requires at least: 3.7
Tested up to: 4.2
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This simple plugin adds a button to the WordPress rich HTML editor to add an inline quote tag.

== Description ==

This simple plugin adds a button to the WordPress rich HTML editor to add an inline quote tag.

It inserts `<q>` tags and ensures they work when switching between HTML and rich editor views.

== Installation ==

To install and configure this plugin...

1. Upload or install the plugin through your WordPress admin.
2. Activate the plugin via the 'Plugins' admin menu.

== Frequently Asked Questions ==

None at present.

== Screenshots ==

1. Inline Quote Tag Button

== Changelog ==

= 1.3 =

* Update TinyMCE icon.
* Fix collapsing space when inserting tags.

= 1.2 =

* Improved readme.txt file.
* Checked WordPress 3.4 compatibility.

= 1.1 =

* Fixed URL path to javascript file.

= 1.0 =

* First Release
