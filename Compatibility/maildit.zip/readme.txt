=== Maildit ===
Contributors: pronamic, remcotolsma 
Tags: maildit, newsletter, campaign monitor, mailtomail, mail, news, deprecated
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 1.0.1

Deprecated — This plugin contains some handy WordPress functions and extends the WordPress admin 
interface with some nice functions, widgets and more.


== Description ==

> This plugin is deprecated so Pronamic wil no longer support and maintain this plugin.
>
> If you want to help maintain the plugin, fork it on [GitHub](https://github.com/pronamic/wp-maildit) and open pull requests.


With the Maildit WordPress plugin users can easily create digital newsletters within WordPress. 
The newsletters can then easily be send via Campaign Monitor, Mail Chimp and / or MailToMail. 
The advantage of Maildit is that you can manage your newsletters within your own WordPress 
installation. This allows you to make use of the WordPress template system. This makes it 
easy to integrate your latest post in your newsletters.


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your 
WordPress installation and then activate the Plugin from Plugins page.


== Screenshots ==

...


== Changelog ==

= 1.0.1 =
*	Added deprecated notice.

= 1.0 =
*	Initial release


== Links ==

*	[Pronamic](http://pronamic.eu/)
*	[Remco Tolsma](http://remcotolsma.nl/)
*	[Markdown's Syntax Documentation][markdown syntax]	

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"