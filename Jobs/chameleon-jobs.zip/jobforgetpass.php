<form name="fpass" id="fpass" action="" Method="POST">
<h3>Forget Password</h3>
<input type="text" name="Email" id="Email">
<input type="submit" name="fpass_submit" value="Submit" class="btn btn-primary">  
</form>