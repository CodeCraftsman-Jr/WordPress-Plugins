jQuery(function(){
	jQuery( '.job-manager-category-dropdown' ).chosen({ search_contains: true });
});