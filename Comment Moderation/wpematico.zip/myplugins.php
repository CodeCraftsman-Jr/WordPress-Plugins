					<div class="postbox">
						<h3 class="handle"><?php _e( 'Other plugins that can be useful', self :: TEXTDOMAIN );?></h3>
						<div class="inside" style="margin: 0 -12px -12px -10px;">
							<div class="wpeplugname" id="WPeCounter"><a href="http://wordpress.org/plugins/wpecounter/" target="_Blank" class="wpelinks">WPeCounter</a>
							<div id="wpecounterdesc" class="tsmall" style="display:none;">Visits Post(types) counter. Shown in a sortable column the number of visits on lists of posts, pages, etc. Is extremely lightweight because it works with ajax.</div></div>
							<p></p>
							<div class="wpeplugname" id="wpebanover"><a href="http://wordpress.org/plugins/wpebanover/" target="_Blank" class="wpelinks">WPeBanOver</a>
							<div id="wpebanoverdesc" class="tsmall" style="display:none;">Show a small banner and on mouse event (over, out, click, dblclick) show another big or 2nd banner anywhere in your template, post, page or widget.</div></div>
							<p></p>
							<div class="wpeplugname" id="WPeMatico"><a href="http://wordpress.org/plugins/wpematico/" target="_Blank" class="wpelinks">WPeMatico</a>
							<div id="WPeMaticodesc" class="tsmall" style="display:none;"> WPeMatico is for autoblogging. Drink a coffee meanwhile WPeMatico publish your posts. Post automatically from the RSS/Atom feeds organized into campaigns.</a></div></div>
							<p></p>
							<div class="wpeplugname" id="WPeDPC"><a href="http://wordpress.org/plugins/etruel-del-post-copies/" target="_Blank" class="wpelinks">WP-eDel post copies</a>
							<div id="WPeDPCdesc" class="tsmall" style="display:none;">WPeDPC search for duplicated title name or content in posts in the categories that you selected and let you TRASH all duplicated posts in manual mode or automatic scheduled with WordPress Cron.</a></div></div>
							<p></p>
							<div class="wpeplugname" id="WP-Seller-Events"><a href="http://etruel.com/downloads/wp-seller-events/" target="_Blank" class="wpelinks">WP-Seller-Events</a>
							<div id="WPSellerEvents" class="tsmall" style="display:none;">Premium plugin that allows you to follow your sellers working through events assigned to each salesperson to receive automatic alerts to visit potentials clients and you can follow the results in a specified timeline or reports.</div></div>
							<p></p>
						</div>
					</div>
