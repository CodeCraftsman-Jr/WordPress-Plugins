=== Plugin Name ===
Contributors: silentwind
Donate link: http://bayu.freelancer.web.id/about/
Tags: comment, moderation
Requires at least: 2.7
Tested up to: 2.7.1
Stable tag: 0.1

A wordpress plugin that will allow you to flexibly set comment moderation mode on individual post, wether to automatically approve or moderate the comment. Useful if you want to post a sensitive post where you want to moderate all comment on that post while allow comment on other post to auto approve.
Btw, I created a step by step tutorial on how to build this plugin here: http://bayu.freelancer.web.id/2009/02/27/wordpress-plugin-flexible-comment-moderation-a-step-by-step-guide/

== Description ==

A wordpress plugin that will allow you to flexibly set comment moderation mode on individual post, wether to automatically approve or moderate the comment. Useful if you want to post a sensitive post where you want to moderate all comment on that post while allow comment on other post to auto approve.
Btw, I created a step by step tutorial on how to build this plugin [here](http://bayu.freelancer.web.id/2009/02/27/wordpress-plugin-flexible-comment-moderation-a-step-by-step-guide/ "step by step guide").

== Installation ==

1. Upload `cr-flexible-comment-moderation` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to `Posts » Add New` or `Posts » Edit`, then look for options on `Advanced Moderation`panel.

== Frequently Asked Questions ==

= Do you have question or feature request? =
Then, give it to me. I'll try to answer it.

== Screenshots ==

1. This is how the settings is (as of version 0.1)
