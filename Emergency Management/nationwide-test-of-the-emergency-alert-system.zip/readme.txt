=== Plugin Name ===
Contributors: ShelbyTactical
Donate link: http://shelbytactical.com/
Tags: widget, plugin, sidebar, embed, widgets, wordpress, fema
Requires at least: 2.8
Tested up to: 3.3.1
Stable tag: 1.0.1

Nationwide Test of the Emergency Alert System from http://fema.gov. The plugin widget has been created by Shelby Tactical.

== Description ==

Nationwide Test of the Emergency Alert System is plugin that displays the Nationwide Test of the Emergency Alert System from http://fema.gov as a WordPress widget. 

The widget is displaying the alerts from http://www.fema.gov.

Features:

* No configuration necessary.
* Displays Nationwide Test of the Emergency Alert System in a widget.

== Installation ==

1. Upload the full directory into your wp-content/plugins directory.
2. Log into WordPress and go to Plugins.
3. Activate the plugin at the plugin administration page.
4. Go to Appearance > Widgets.
5. Drag the Nationwide Test of the Emergency Alert System widget to any sidebar.

== Frequently Asked Questions ==

= I installed and activated the plugin, now what? =

Go to Appearance > Widgets and add the plugin to the sidebar.

= My question is not answered here, where can I contact you? =

You can contact us [here](mailto:plugins@shelbytactical.com)

== Screenshots ==

1. Plugin widget.

== Changelog ==

= 1.0.1 =

* WordPress plugin standards update.

= 1.0 =

* First official launch of the plugin.

== Upgrade Notice ==

* None yet.