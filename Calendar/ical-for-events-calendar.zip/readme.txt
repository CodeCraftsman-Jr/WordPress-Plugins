=== iCal for Events Calendar ===
Contributors: YukataNinja
Tags: ical, events calendar, ec, ical feed, feed, icalendar, calendar, events, event, subscribe
Requires at least: 2.7
Tested up to: 2.9.2
Stable tag: 1.1.1

Add an iCal feed to your site for the Events Calendar plugin

== Description ==

Creates an iCal feed for [Events Calendar](http://www.lukehowell.com/events-calendar).

Based on [Gary King's iCal Posts](http://www.kinggary.com/archives/build-an-ical-feed-from-your-wordpress-posts-plugin) and modifications by [Jerome](http://capacity.electronest.com/ical-for-ec-event-calendar).

Feed will be at http://your-web-address/?ical

== Installation ==

1. Unzip in your plugins directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= Where is the feed located? =

At http://your-web-address/?ical

== Updates ==

<pre><code>
Version 1.1.1
	Valid RFC 2445

Version 1.1
	Added location
	Added link out
	Added option for how long to show past events

Version 1.0
	Original Version
</code></pre>
