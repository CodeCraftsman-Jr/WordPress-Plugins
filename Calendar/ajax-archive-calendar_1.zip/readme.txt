=== Ajax Archive Calendar ===
Contributors: osmansorkar
donate link: http://www.projapotibd.com/donate
Tags: Ajax, Ajax Archive,Ajax Calendar,jquery Calendar, Calendar, style,costomazie Calendar,Widget,Calendar Widget
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 2.7.10.11
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ajax Archive Calendar .

== Description ==

Ajax Archive Calendar is not only Calendar is also Archive. It is making by customize WordPress default calendar. I hope every body enjoy this plugin .

== Installation ==

Step 1. Download the Plugin from  from official WordPress Plugin Directory.

Step 2. Upload it in you wp-content/plugins directory.

Step 3. Activate it from Admin panel.


== Frequently Asked Questions ==

=  Can I add more style? = 

Ans: Yeas But you need manually edite.

== Screenshots ==
1. **Example,** - This widget look lick this.


== Changelog ==
= 2.4 =
Fixt Some Bug And Bangla
= 2.0 =
*add bangla calendar.

= 0.01 =
* This is the First Version.
* customize WordPress default calendar
* Add Ajax

== Upgrade Notice == 
= 2.0 =
* Add Bangla Calander for bangla website .
= 1.01 =
* Add Tody Active Color.
= 1.00 =
* This is the First Version.