jQuery(document).ready(function() {
	jQuery('#swc_date').pickadate({
		format : 'dd/mm/yyyy',
		formatSubmit : 'yyyy-mm-dd',
		hiddenName : true
	});
});