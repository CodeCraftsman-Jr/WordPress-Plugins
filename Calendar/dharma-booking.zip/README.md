<h1>dharmaBooking a wordpress accomadation reservation plugin</h1>

<em>
A little open source booking app, made for hostels, backpackers, hotels, lodges and any other place that rents beds per unit. 
</em>

<h2>Some of the features are, </h2>
<ul>
<li>Easly customisable and theamed</li>
<li>checkin staff page </li>
<li>graphical reporting reporting </li>
<li>jquery enhanced </li>
<li>self contained </li>
<li>graphical reporting </li>
</ul>

<h2>install instructions.</h2>

<ul>
<li> install and activate plugin</li>
<li> add at least one rental</li>
<li> configure the "core" and "calendar" sections on the settings page</li>
<li> put [calender-page] and [final-page] short codes in pages or posts</li>
</ul>

<h2>demo</h2>
<em>to view a demo click <a href="http://earthling.za.org">here</a>.</em>

<h2>compatablity</h2>
<ul>
<li>tested for Wordpress 3.5+.</li>
<li>jQuery 1.8+</li>
<li>PHP5</li>
<li>html5</li>
</ul>
