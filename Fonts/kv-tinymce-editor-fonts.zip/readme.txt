=== KVTinyMCE Editor Add Fonts ===
Contributors: kvvaradha
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=kvvaradha@gmail.com&item_name=KV  TinyMCE Editor Fonts
Tags: tinymce editor, add fonts, google fonts tinymce editor, kvcodes
Requires at least: 3.1
Tested up to: 4.1
License: GPL 

A tiny plugin to add a new font to your post editor i.e TinyMCE Editor. 

== Description ==

 Add Extra buttons fonts and its size with your  WordPress admin post editor i.e TinyMCE Editor.
If you want to rework with the code, fine take a look at here before start usging this code, It will be helpful to work with your own project.<a href="http://kvcodes.com/2014/05/how-to-add-google-webfonts-to-wordpress-tinymce-editor/" target="blank" > Kvcodes.com </a> 


= Features =
* Easy use
* Easy to change your fonts 
* Simple Set-up, Less space consuming

 

== Installation ==

1. Upload `kv-tinymce-editor-fonts` to the `/wp-content/plugins/`  directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

N/A


== Screenshots ==

1. Add Nerw Post with different fonts screenshot.. 


== Arbitrary section ==

N/A



== A brief Markdown Example ==



== Upgrade Notice ==

N/A