jQuery(document).ready(function($) {
	$('.font-color-field').wpColorPicker();
});