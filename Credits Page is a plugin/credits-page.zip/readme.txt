=== Plugin Name ===
Contributors: mimiz.fr
Donate link: http://www.mimiz.fr
Tags: Credits Page
Requires at least: 3.0.1
Tested up to: 3.0.1
Stable tag: 1.O
Create a credit page to thanks plugins authors.

== Description ==

This plugin help you to create a Credit page to thanks plugins authors by adding a page with links to their sites

== Installation ==

1. Download credits-page zip archive
1. Extract the `credits-page` directory
1. Upload the directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= what's next ?=
 * Need to add languages support (fr / en ...)
 * Maybe add more options (manage style for example, ... )


== Screenshots ==

1. Credits page menu
2. The credits page configuration page 

== Upgrade Notice ==

 Nothing To say

== Changelog ==

= 1.0 =
* First version of the plugin
