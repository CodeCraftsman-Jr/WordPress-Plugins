=== graphical statistics report ===
Contributors: www.gopiplus.com, gopiplus 
Donate link: http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/
Author URI: http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/
Plugin URI: http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/
Tags: graphical, statistics, report, graph, fusion chart,fusion graph, analysis, admin,
Requires at least: 3.4
Tested up to: 4.3.1
Stable tag: 8.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This plugin will display the graphical report for admin about post count, user registration, comments posted activity.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/](http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/)
	
* [Live Demo](http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/)	
* [More Information](http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/)				
* [Contact](http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/)		

Graphical statistics report wordpress plugin create the graphical report about monthly user registration, monthly post, monthly comment, category wise post count in the admin. All the statistics will be display with the help fusion char. This is very useful plugin to trace your website statistics.

= Features of this plugin =

*  Monthly user registration graphical graph.
*  Monthly post graphical report.
*  Monthly comments posted graphical report.
*  Category wise post graphical report.

**To see the report:**

1. Activate the plugin.
2. Go to 'Graphical statistics' link under Dashboard Setting Menu to see the report graph.  

== Installation ==

[Installation Instruction & Configuration](http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/)

== Frequently Asked Questions ==

= How to display this plug-in to front end? =
 
No, this plugin only for admin report.  
  
== Screenshots ==

1. Menu. http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/

2. Graphical report. http://www.gopiplus.com/work/2010/07/18/graphical-statistics-report/

== Upgrade Notice ==

= Version 8.8 =

1. Tested up to 4.3.1
2. Text Domain slug has been added for Language Packs.

= Version 8.7 =

1. Tested up to 4.3

= Version 8.6 =

1. Tested up to 4.2.2

= Version 8.5 =

1. Tested up to 4.1

= Version 8.4 =

1. Tested up to 4.0

= Version 8.3 =

1. Tested up to 3.9

= Version 8.2 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (graphical-statistics-report.po) available in the languages folder. Translators Welcome.

= Version 8.1 =

Small update in admin layout

= Version 8.0 =

Tested up to 3.6

= Version 7.1 =

Tested up to 3.5

= Version 7.0 =

New demo link, http://www.gopiplus.com

= Version 6.0 =

Tested up to 3.4.1
GPLv2 license text added

= Version 5.0 =

Tested up to 3.4

= Version 4.0 =

Tested up to 3.3

= Version 3.0 =	

Security fixes (Only admin user can see the plugin menu in the dashboard)		
Tested up to 3.1.3

= Version 2.0 =		

Tested up to 3.0

= Version 1.0 =

First version

== Changelog ==

= Version 8.8 =

1. Tested up to 4.3.1
2. Text Domain slug has been added for Language Packs.

= Version 8.7 =

1. Tested up to 4.3

= Version 8.6 =

1. Tested up to 4.2.2

= Version 8.5 =

1. Tested up to 4.1

= Version 8.4 =

1. Tested up to 4.0

= Version 8.3 =

1. Tested up to 3.9

= Version 8.2 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (graphical-statistics-report.po) available in the languages folder. Translators Welcome.

= Version 8.1 =

Small update in admin layout

= Version 8.0 =

Tested up to 3.6

= Version 7.1 =

Tested up to 3.5

= Version 7.0 =

New demo link, http://www.gopiplus.com

= Version 6.0 =

Tested up to 3.4.1
GPLv2 license text added

= Version 5.0 =

Tested up to 3.4

= Version 4.0 =

Tested up to 3.3

= Version 3.0 =	

Security fixes (Only admin user can see the plugin menu in the dashboard)		
Tested up to 3.1.3

= Version 2.0 =		

Tested up to 3.0

= Version 1.0 =

First version