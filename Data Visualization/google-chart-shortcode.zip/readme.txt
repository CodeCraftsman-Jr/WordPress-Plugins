=== Google Chart shortcode ===
Contributors: wokamoto
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=9S8AJCY7XB8F4&lc=JP&item_name=WordPress%20Plugins&item_number=wp%2dplugins&currency_code=JPY&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted
Tags: google chart, shortcode
Requires at least: 2.5
Tested up to: 3.0
Stable tag: 0.1.0

This plugin allow to insert Google charts in your posts or pages, just using a shortcode.

== Description ==

This plugin allow to insert Google charts in your posts or pages, just using a shortcode.
(Only for WordPress 2.5+)

== Installation ==

1. Upload the entire `google-chart-shortcode` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Put `[chart parameter(s)]keyword(s)[/chart]` at the place in your posts where you want the "<a href="http://code.google.com/intl/ja/apis/chart/" title="Google Chart API - Google Code">Google Chart</a>".

== Changelog == 

**0.1.0 - July 15, 2010**  
Initial release.
