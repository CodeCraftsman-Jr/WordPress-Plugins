=== Plugin Name ===
Contributors: vinmatrix
Donate link: 
Tags: custom fields, custom, personalize
Requires at least: 2.7.1
Tested up to: 3.3
Stable tag: trunk

Allows to maintain N number of Custom fields dynamically for site administrator. 
 
== Description ==

Sometimes we need to have more fileds for Wordpress administrator,Lets us take an example, we have only
one admin mail setting in wordpress, and if we need more than one then we need to have an interface to maintain
other email ids. Like this we can maintain N number of custom fileds dynamically through this WP Admin Custom files plugin.


== Installation ==

There are two ways of installing the plugin:

**From the [WordPress plugins page](http://wordpress.org/extend/plugins/)**

1. Download the plugin
2. Upload the `wp-admin-custom-fields` folder to your `/wp-content/plugins/` directory.
3. Active the plugin in the plugin menu panel in your administration area.

**From inside your WordPress installation, in the plugin section.**

1. Search for wp admin custom fileds plugin
2. Download it and then active it.

Once, you have the plugin activated, you will find a new option called 'Custom Field Settings' in your Appearance Settings menu. 
There you have an interface to add/edit/delete new custom fields.

Also You can find simple tutorials with video on the [wp admin custom fileds plugin web page](http://blog.vinmatrix.com/products/wp-plugins/custom-wp-admin-fileds/)







== Screenshots ==

1. screenshot-1.png 


== Changelog ==

= 0.1 =

* Initial release



