=== Convertor valutar curs 3 Banci: BNR, BCR si BT ===
Contributors: bobyrou
Donate link: http://www.casedevanzare.ro
Tags: convertor valutar, curs bnr, convertor online, romania, bucuresti, bnr, curs, convertor euro, convertor, convertor bnr, convertor banca comerciala, convertor banca transilvania, convertor euro ron, convertor euro lei, convertor lei euro, convertor ron euro, converteste online, converteste, conversie valutara
Requires at least: 3.0.1
Tested up to: 4.2.1
Stable tag: 2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ofera vizitatorilor optiunea de a converti din EURO in RON, RON in EURO la cursul zilei pentru urmatoarele 3 banci: BNR, BCR si Banca Transilvania

== Description ==
Multumesc pentru ca ai ales pluginul: Convertor valutar curs BNR

Iti permite afisarea unui convertor pe orice pagina, articol, in widget sau sidebar.

Ofera vizitatorilor optiunea de a converti din EURO in RON / RON in EURO la cursul zilei pentru urmatoarele 3 banci:
- BNR (Banca Nationala a Romaniei)
- BCR (Banca Comerciala Romana)
- BT (Banca Transilvania)

Shortcode-ul [eron_converter] permite afisarea convertorului valutar oriunde doriti.

== Installation ==

Urmeaza instructiunile pentru instalarea pluginului si afisarea convertorului:

* Instalati pluginul in wordpress
* Activati pluginul
* Oriunde doriti sa afisati convertorul valutar (in pagina, intr-un articol, in widget, in sidebar etc.) adaugati textul: [eron_converter]

Shortcode-ul [eron_converter] permite afisarea convertorului valutar oriunde doriti.

Daca esti multumit de acest plugin te rog sa votezi 5 stele pe pagina pluginului:
https://wordpress.org/plugins/convertor-valutar-curs-bnr/

Multumesc,
Stan Nicolae

== Frequently Asked Questions ==
Daca aveti intrebari sau aveti nevoie de ajutor va rog sa folositi pagina de Support de pe pagina pluginului:
http://wordpress.org/support/plugin/convertor-valutar-curs-bnr

== Upgrade Notice ==

= 2 =
In aceasta versiune pluginul a primit imbunatatiri majore, ca de exemplu: mobile friendly, stabilitate si convertor pentru 3 banci (BNR, BCR si BT)

== Screenshots ==
1. Converteste din EURO in RON si RON in EURO la cursul zilei BNR (Banca Nationala a Romaniei)
2. Converteste din EURO in RON si RON in EURO la cursul zilei la Banca Transilvania
3. Converteste din EURO in RON si RON in EURO la cursul zilei la BCR (Banca Comerciala Romana)

== Changelog ==

= 2 =
* Imbunatatiri majore facute la plugin, interfata schimbata, pe langa convertor pentru BNR sa adaugat si pentru Banca Transilvania si BCR
* Pluginul poate fi folosit si pentru widget
* Convertorul este Mobile friendly!
= 1 =
* Lansare plugin