=== dekabotann ===
Contributors: kazunii
Donate link: 
Tags: hatena, google plus one, facebook, twitter, social bookmark
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 0.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

"dekabotann" is a plugin providing big social button. Hatena, Twitter, Facebook, Google+. Especially, this plugin is optimized for Japanese.

== Description ==



== Installation ==

1. Upload `dekabotann` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==



== Screenshots ==

1. /tags/0.1.2/screenshot1.png

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==

