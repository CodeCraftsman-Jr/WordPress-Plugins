(function($) {
    $(function() {
        $( '#highlight_focus_background_color, #highlight_focus_border_color' ).wpColorPicker();
    });
})(jQuery);
