=== Financial Toolbox ===
Contributors: Thomas Nissen
Tags: news, widget, sidebar, links, plugin
Requires at least: 2.9
Tested up to: 2.9.2
Stable tag: 1.0

The financial toolbox includes a news ticker for the latest financial news.

== Description ==

The financial toolbox includes a news ticker for the latest financial news.

You also can enhance your personal blog with integrated credit calculator.

Powred by [http://www.arbeitsgemeinschaft-finanzen.de/](http://www.arbeitsgemeinschaft-finanzen.de/).

== Installation ==

1. Extract `financial-toolbox.zip`.
2. Upload the `financial-toolbox`-folder to your `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.

== Changelog ==

= 1.0 =
Initial release 2010-05-21