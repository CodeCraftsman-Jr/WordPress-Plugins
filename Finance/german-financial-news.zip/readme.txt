=== German Financial News ===
Contributors: Thomas Nissen
Tags: finance, news, widget
Requires at least: 2.9
Tested up to: 2.9.2
Stable tag: 0.1

A customizeable widget which displays the latest news from the financial sector, provided by http://www.arbeitsgemeinschaft-finanzen.de

== Description ==

A customizeable widget which displays the latest news from the financial sector

*Feature List*

* customizable widget
* displays a user-defined number of links
* title shortening

*German*
Flexibles Widget, dass die neuesten Nachrichten aus dem Finanzsektor anzeigt, bereitgestellt von [http://www.arbeitsgemeinschaft-finanzen.de/](http://www.arbeitsgemeinschaft-finanzen.de/)

*Features*

* Anpassbares Widget
* Zeigt eine benutzerdefinierte Anzahl von Links
* Titel Verk&uuml;rzung

== Installation ==

1. Extract `german-financial-news.zip`.
2. Upload the `german-financial-news`-folder to your `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.

*German*
a. Entpacke `german-financial-news.zip`.
b. Lade den `german-financial-news`-Ordner in dein Verzeichnis `/wp-content/plugins` hoch.
c. Aktiviere das Plugin im 'Plugins'-Men&uuml; der Wordpress-Administration.
d. F&uuml;ge das Widget unter Design->Widgets deiner Sidebar hinzu und bearbeite die Widget-Optionen.

== Changelog ==

= 0.1 =
Initial release 2010-04-14