=== Plugin Name ===
Contributors: Jake Ruston
Donate link: http://www.jakeruston.co.uk
Tags: widget, news, finance, widgets, post, posts, new
Requires at least: 2.0.2
Tested up to: 3.0.0
Stable tag: 1.2.3

This plugin allows you to display the latest finance news updates directly on your blog - From any company you wish!

== Description ==

This plugin allows you to display the latest finance news updates directly on your blog - From any company you wish!

Simply enable the plugin through your admin panel, edit the JR Finance settings in the Settings --> JR Finance menu and enable the widget through the Appearance --> Widgets menu! Finance news will now be displayed on your blog!

== Installation ==

1. Upload `jr-finance.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit the JR Finance Settings in your Administration Panel
4. Enable the Widget through the Appearance --> Widgets menu.

== Frequently Asked Questions ==


= Does this work?

Yes.

== Changelog ==

= 1.0.0 =
* Initial Release