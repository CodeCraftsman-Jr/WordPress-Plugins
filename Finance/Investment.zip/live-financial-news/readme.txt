=== live financial news ===
Contributors: akram artoul
Donate link: http://zvoid.com/
Tags: widget, news , stream , stream news ,financial news , financial
Requires at least: 2.0.2
Tested up to: 2.8.4
Stable tag: trunk

This is  plugin it is a stream of  domestic and worldwide news in realtime using ajax.

== Description ==


just install this and see the financial news coming to your site (inside the plugin) in real-time updating every second..

get the latest financial news in real time in a very cool way ... it has more than 3000 headlines a hour from all the major news sources.
just take a look at the **screenshots** its a great widget for every website.

**if you think your site is a great news source  send us an email team(at)zvoid(.)com with
your website link and we will take a look...**





headlines come from:

* cnn
* cnbc 
* bloomberg
* marketwatch
* wsj
* reuters
* guardian
* tradethenews
* fool
* **and many more.......**



== Installation ==

You can use the built in installer and upgrader, or you can install the plugin
manually.

1. Upload `livefinancialnews.php` to the `/wp-content/plugins/` directory or to `/wp-content/plugins/livefinancialnews/`
2. Activate the plugin through the 'Plugins' menu in WordPress
1. Place widget `Stream News Live` to Sidebar and configure it.

1. You can either use the automatic plugin installer or your FTP program to upload it to your /wp-content/plugins/streamnewslive/ directory
if streamnewslive is not there just make one
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Configure any options as desired (you dont need to this), and then enable the plugin
1. That's it!

If you have to upgrade manually simply repeat the installation steps and re-enable the plugin.

== Screenshots ==

1. this is the widget after the page has been loaded for 2-4 seconds
2. this is the widget after the page has been loaded for more than 6-7 seconds and it will keep updating with live news
3. this how it looks but you can change everything
4. this how it look when you add the photos option
== Changelog ==

= 1.0 =
* Start version


