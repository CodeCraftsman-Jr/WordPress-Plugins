﻿                                      EMI Calculator


Description: This EMI Calculator is basically run from shortcode in page or widget area without editing theme files.

Shortcode: [Bank_EMI_calc][/Bank_EMI_calc]
This shortcode can be use to show EMI Calculator in page or widget. No need to change in shortcode accoding to your theme.

Installation: 
01. click on add new plugins and click on 'upload plugins' button.
02. click on 'choose file' button and select compress file of Emi calculator and then click on 'install now' button.
03. Activate the plugin through the 'Plugins' menu in WordPress.
04. Now use the given Shortcode in your page or widget.
                                    Or
you can dirctly paste complete folder after extract the file in plugins folder (location: /wp-content/plugins/ directory) and Activate the plugin through the plugins menu from your admin panel.










































































