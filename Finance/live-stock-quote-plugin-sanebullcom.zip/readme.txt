=== Live Stock Market Quotes - SaneBull ===
Contributors: fshnir
Tags: stocks, nadsaq, stock market, stock, dow jones, trading, sanebull
Requires at least: 2.0
Tested up to: 2.6
Stable tag: 1.0.1

SaneBull contextual stock symbol information plugin.

== Description ==
This plugin will give you the flexibility of linking stock symbols to keywords (by default, the keywords are stock symbols).
For a visual example, please see this example blog post.

By default, we open the Short symbol display, but upon clicking the symbol, a full view is presented.

This plugin installation is no different from any other WordPress plugin. All you need to do is unzip the files and upload them to your /wp-content/plugins/ directory.

After uploading, activate the plugin through the WP Admin -> Plugins page. To use it, you will need to define the keywords in Options -> SaneBull Quote.

That's it! From now on, whenever you use any of the specified keywords in your posts or pages, they will automatically convert to the SaneBull Live Stock widget.

== Installation ==

This plugin installation is no different from any other WordPress plugin. All you need to do is unzip the files and upload them to your /wp-content/plugins/ directory.

After uploading, activate the plugin through the WP Admin -> Plugins page. To use it, you will need to define the keywords in Options -> SaneBull Quote.

== Screenshots ==

1. Plugin in action
