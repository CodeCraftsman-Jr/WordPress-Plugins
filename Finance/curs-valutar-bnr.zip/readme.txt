=== Curs Valutar BNR ===

Contributors: Anghel Petre
Tags: curs, valutar, bnr, sidebar, widget, preluare, RON, valuta, cursul
Requires at least: 2.0
Stable tag: 1.1


== Description ==

Acest plugin ofera posibilitatea de a alege pt afisare cursul valutar BNR in RON pt oricare dintre valute plus otiunea de a modifca culorile sau dimensiunea modulului. 

Plugin dezvoltat din [Preluare curs valutar BNR](http://cursul-valutar.net/preluare_curs_valutar.php)

Pentru instalare urmati pasii:

1. copiati fisierul "curs_valutar_bnr.php" in directorul /wp-content/plugins al blogului
2. activati plugin-ul
3. accesati meniul Appearance ==> Widgets
4. adaugati pluginul "Curs Valutar BNR" in sidebar
5. salvati setarile

== Installation ==

1. copiati fisierul "curs_valutar_bnr.php" in directorul /wp-content/plugins al blogului
2. activati plugin-ul
3. accesati meniul Appearance ==> Widgets
4. adaugati pluginul "Curs Valutar BNR" in sidebar
5. salvati setarile

== Screenshots ==

1. Optiuni afisare
[curs valutar bnr](http://cursul-valutar.net)