jQuery(document).ajaxComplete(function() {
    jQuery('#widgets-right .cc-color-field, .inactive-sidebar .cc-color-field').wpColorPicker();
});

jQuery(document).ready(function(){
    jQuery('#widgets-right .cc-color-field, .inactive-sidebar .cc-color-field').wpColorPicker();
});

