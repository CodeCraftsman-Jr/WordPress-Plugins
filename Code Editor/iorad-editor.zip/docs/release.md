Release Process
===============

readme.txt
----------

- update `Stable tag`

- update `Changelog` section


iorad-editor.php
----------------

- update versions
