<?php
/**
 *   @copyright Copyright (c) 2007 Quality Unit s.r.o.
 *   @author Juraj Simon
 *   @package WpLiveAgentPlugin
 *   @version 1.0.0
 *
 *   Licensed under GPL2
 */
if (!class_exists('liveagent_LoadClassException')) {
	class liveagent_LoadClassException extends Exception {
	    
	}
}

?>