jQuery(document).ready(function($){
	// fade away update messages
	setTimeout(function(){
		$('.fade').fadeOut('slow');
	}, 5000);
});
