<?php
/* Template Name: udscript */
?>
<script language="JavaScript">
<!--
	function doMenu(item) { 
        obj = document.getElementById(item);
        col = document.getElementById("x" + item);

        if (obj.style.display == "block") {
            obj.style.display = "none";
            col.innerHTML = "[Open]";
        } 
        else { 
            obj.style.display = "block";
            col.innerHTML = "[Close]";
        }
    } 
	function doMenu1(item) { 
        obj = document.getElementById(item);
        col = document.getElementById("x" + item);

        if (obj.style.display == "block") {
            obj.style.display = "none";
            col.innerHTML = "[Open]";
        } 
        else { 
            obj.style.display = "block";
            col.innerHTML = "[Close]";
        }
    } 
	function doMenu2(item) { 
        obj = document.getElementById(item);
        col = document.getElementById("x" + item);

        if (obj.style.display == "block") {
            obj.style.display = "none";
            col.innerHTML = "[+]";
        } 
        else { 
            obj.style.display = "block";
            col.innerHTML = "[-]";
        }
    }
// -->
</script>