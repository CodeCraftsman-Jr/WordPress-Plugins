	<style type="text/css">
		#mab{
			position:fixed;
			text-align:justify;
			text-justify:newspaper;
			bottom:50px;
			right:20px;
			height:500px;
			width:25%;
			background-color:#888;
			border:0.1px solid #ccc;
			padding:10px;
			background-image: -webkit-gradient(linear, 50% 0%, 50% 100%, color-stop(0%, #888), color-stop(100%, #333));
			background-image: -webkit-linear-gradient(#888,#333);
			background-image: -moz-linear-gradient(#888,#333);
			background-image: -o-linear-gradient(#888,#333);
			background-image: linear-gradient(#888,#333);
			box-shadow:0 0 2px 2px #ddd;
		}
		#mab-t{
			height:480px;
			border:1px solid #fff;
			padding:10px;
			margin:10px;
			background-color:#ddd;
			color:#fff;
			background-image: -webkit-gradient(linear, 50% 0%, 50% 100%, color-stop(0%, #ddd), color-stop(100%, #fff));
			background-image: -webkit-linear-gradient(#ddd,#fff);
			background-image: -moz-linear-gradient(#ddd,#fff);
			background-image: -o-linear-gradient(#ddd,#fff);
			background-image: linear-gradient(#ddd,#fff);
		}
		#mab-wrap{
			float:left;
			width:65%;
		}
		 #bsc-tab tr:nth-child(2n+2),
		 #adv-tab tr:nth-child(2n+1) {
      background: #555;
      color:#fff;
      font-weight:bold;
    }
    #bsc-tab tr:nth-child(2n+1),
    #adv-tab tr:nth-child(2n+2) {
      background: #eee;
    }
    #bsc-tab,
    #adv-tab{ width:100%; }
	</style>
	<div id="fb-root"></div>
		<script>(function(d, s, id) {
  			var js, fjs = d.getElementsByTagName(s)[0];
  			if (d.getElementById(id)) return;
  			js = d.createElement(s); js.id = id;
  			js.src = "//connect.facebook.net/tr_TR/all.js#xfbml=1&appId=443488615681566";
  			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));
		</script>
	<div id="mab">
		<table id="mab-t">
			<thead>
				<tr align="center">
					<td>
						<strong>Thanks for using my plugin!</strong> 
					</td>
				</tr>
			</thead>
			<tbody>
				<tr valign="top">
					<td>
						<h2 style="text-align:center;"><mark>IF YOU LIKED THIS PLUGIN</mark></h2>
  						<h3>Think about the time and effort I put into&hellip;so please consider a small amount of donation&hellip;</h3>
   					<small style="color:black;">This is my first plugin so I would love to get some feedback about it.Please drop by my plugin Page and tell me what you think...</small>
					</td>
				</tr>
				<tr align="center">
					<td>
						<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHLwYJKoZIhvcNAQcEoIIHIDCCBxwCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYDAfRxXqcbGQm+xNSguav2s8MPmixaw1SvzbiE1bNGHSLF5KtMfcL2K0ejLGZp+KWu1Z/rG9u5fCZyVkGk+xTKmverAoB2TRjzp9GrfTHwbqlfTbVhGh/pezWk5I95Bh21VWVC2R43y2eAWauh1PPT0T3cijWSNeiYW3CBtX3MvYzELMAkGBSsOAwIaBQAwgawGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIZ8ECXnlvg2SAgYgRDhyXOn55UjdDkKNnTOvz8b4rox7yUvBvKqH4wbzqoWRFgeK0Vg9WkmLJ3f7YNqGIHKj39iv7/IRG/iw4oVCWtYdlmhLGwZbSgCKAhWZsLAOfh148r/r242SFBx4ilbvHytaBAZ1VAyVlrdDobD48HIqGaSBGOAFHw88E0hrPldKB9U6LJjJSoIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTIwODE4MTQyNzQyWjAjBgkqhkiG9w0BCQQxFgQU3SmGXEAlyVu0aKrezeuJaMNcZxYwDQYJKoZIhvcNAQEBBQAEgYA1zK9h6Dt3pjkku1gERB3XQTIVT9zP07nGiHix2cmWw+x9RZrO9Yw+ADKm5gJ41bBHXSEz+9oM9Sdsdypcp7GqBUx47ZrylFiPOmKLIy4dYIU9IDECL1o1tj9Fmi7Fwep2b7m8QXGpnCqgV1BnGSBddEZ8CeqDOEmySzJKNZK+6w==-----END PKCS7-----">
							<input type="image" src="https://www.paypalobjects.com/en_US/TR/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
							<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
						</form>
					</td>
				</tr>
				<tr align="center">
					<td>
						<div class="fb-like" data-href="http://sebla.dk/mab" data-send="true" data-layout="box_count" data-width="0" data-show-faces="true" data-colorscheme="light" data-font="arial"></div>
					</td>
				</tr>
			</tbody>
			<tfoot>
				<tr align="center">
					<td>
						<a href="http://www.sebla.dk/mab">Visit Plugin Site</a>&nbsp;|&nbsp;<a href="http://www.sebla.dk/mab">Support</a>&nbsp;|&nbsp;<a href="http://www.sebla.dk/mab">FAQ</a>&nbsp;|&nbsp;<a href="http://www.sebla.dk/mab">Contact</a> 
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
	<div id="mab-wrap" class="wrap">
		<div id="icon-options-general" class="icon32"></div>
			<?php
		 	$active_tab = 'basic_settings';
			if( isset( $_GET[ 'tab' ] ) ) {
    			$active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'basic_settings';
			}
			?>
				<h2 class="nav-tab-wrapper">
					<a href="?page=mab_plugin_settings&tab=basic_settings" class="nav-tab <?php echo $active_tab == 'basic_settings' ? 'nav-tab-active' : ''; ?>">Basic Settings</a>
					<a href="?page=mab_plugin_settings&tab=advanced_settings" class="nav-tab <?php echo $active_tab == 'advanced_settings' ? 'nav-tab-active' : ''; ?>">Advanced Settings</a>
					<a href="?page=mab_plugin_settings&tab=mab_info" class="nav-tab <?php echo $active_tab == 'mab_info' ? 'nav-tab-active' : ''; ?>">Info</a>
				</h2>
			<form id="mab-form" method="post" action="options.php">
			<?php settings_errors(); ?>
			<h2>Multipurpose CSS3 Animated Buttons</h2>
				<?php if( $active_tab == 'basic_settings' ) { ?>
						<!-- jscolor, JavaScript Color Picker | 1.4.0 | Jan Odvarko, http://odvarko.cz | 2012-07-06 | http://jscolor.com -->
							<script type="text/javascript" src="<?php echo plugins_url( '/js/jscolor/jscolor.js' , dirname(__FILE__) ); ?>" ></script>
						<!-- end jscolor -->
				<?php
						settings_fields( 'mab_plugin_basic_settings' );
						do_settings_sections( 'mab_plugin_basic_settings' );
					} elseif( $active_tab == 'advanced_settings' ) {
						settings_fields( 'mab_plugin_advanced_settings' );
						do_settings_sections( 'mab_plugin_advanced_settings' );
					} elseif( $active_tab == 'mab_info' ) {
						settings_fields( 'mab_plugin_info_settings' );
						do_settings_sections( 'mab_plugin_info_settings' );
						echo '<table id="bsc-tab" cellspacing="0" cellpadding="5" style="float:left; padding:5px;"><caption><h3 style="text-align:left;">&nbsp;&nbsp;Basic Settings</h3></caption>' .	
						'<tr><td>basic_button_count :</td><td>' . $GLOBALS['basic_button_count'] . '</td></tr>' .
						'<tr><td>basic_button_type :</td><td>' . $GLOBALS['basic_button_type'] . '</td></tr>' .
						'<tr><td>basic_link_font_size :</td><td>' . $GLOBALS['basic_link_font_size'] . '</td></tr>' . 
						'<tr><td>basic_link_font_color :</td><td>' . $GLOBALS['basic_link_font_color'] . '</td></tr>' .           
						'<tr><td>basic_link_1 :</td><td>' . $GLOBALS['basic_link_1'] . '</td></tr>' .  
						'<tr><td>basic_link_2 :</td><td>' . $GLOBALS['basic_link_2'] . '</td></tr>' .      
						'<tr><td>basic_link_3 :</td><td>' . $GLOBALS['basic_link_3'] . '</td></tr>' .       
						'<tr><td>basic_link_4 :</td><td>' . $GLOBALS['basic_link_4'] . '</td></tr>' .       
						'<tr><td>basic_link_5 :</td><td>' . $GLOBALS['basic_link_5'] . '</td></tr>' .       				
						'<tr><td>basic_link_1_title :</td><td>' . $GLOBALS['basic_link_1_title'] . '</td></tr>' .         
						'<tr><td>basic_link_2_title :</td><td>' . $GLOBALS['basic_link_2_title'] . '</td></tr>' .
						'<tr><td>basic_link_3_title :</td><td>' . $GLOBALS['basic_link_3_title'] . '</td></tr>' .       
						'<tr><td>basic_link_4_title :</td><td>' . $GLOBALS['basic_link_4_title'] . '</td></tr>' .
						'<tr><td>basic_link_5_title :</td><td>' . $GLOBALS['basic_link_5_title'] . '</td></tr>' .
						'<tr><td>basic_facebook :</td><td>' . $GLOBALS['basic_facebook'] . '</td></tr>' .
						'<tr><td>basic_facebook_app_id :</td><td>' . $GLOBALS['basic_facebook_app_id'] . '</td></tr>' .
						'<tr><td>basic_twitter :</td><td>' . $GLOBALS['basic_twitter'] . '</td></tr>' .
						'<tr><td>basic_google :</td><td>' . $GLOBALS['basic_google'] . '</td></tr>' .
						'<tr><td>basic_pinterest :</td><td>' . $GLOBALS['basic_pinterest'] . '</td></tr>' .
						'<tr><td>basic_feed :</td><td>' . $GLOBALS['basic_feed'] . '</td></tr>' .
						'<tr><td>basic_feed_src :</td><td>' . $GLOBALS['basic_feed_src'] . '</td></tr>' .
						'<tr><td>basic_gradient_color_1 :</td><td>' . $GLOBALS['basic_gradient_color_1'] . '</td></tr>' .
						'<tr><td>basic_gradient_color_2 :</td><td>' . $GLOBALS['basic_gradient_color_2'] . '</td></tr>' .
						'<tr><td>basic_shadow_color :</td><td>' . $GLOBALS['basic_shadow_color'] . '</tr>
						</table><table id="adv-tab" cellspacing="0" cellpadding="5" style="float:left; padding:5px;"><caption><h3 style="text-align:left;">&nbsp;&nbsp;Advanced Settings</h3></caption>' .
						'<tr><td>advanced_toggle_cookies :</td><td>' . $GLOBALS['advanced_toggle_cookies'] . '</td></tr>' .
						'<tr><td>advanced_toggle_custom_css :</td><td>' . $GLOBALS['advanced_toggle_custom_css'] .	'</tr>' .
						'<tr><td>advanced_custom_css :</td><td>' . $GLOBALS['advanced_custom_css'] . '</td></tr>' .
						'<tr><td>advanced_toggle_social_js :</td><td>' . $GLOBALS['advanced_toggle_social_js'] . '</td></tr>' .	
						'<tr><td>advanced_toggle_footer_link:</td><td>' . $GLOBALS['advanced_toggle_footer_link'] . '</td></tr>' .
						'<tr><td>cookie3d1 :</td><td>' . $GLOBALS['cookie3d1'] . '</td></tr>' .																	
						'<tr><td>cookie3d2 :</td><td>' . $GLOBALS['cookie3d2'] . '</td></tr>' .
						'<tr><td>cookie3d3 :</td><td>' . $GLOBALS['cookie3d3'] . '</td></tr>' .
						'<tr><td>cookie3d4 :</td><td>' . $GLOBALS['cookie3d4'] . '</td></tr>' .
						'<tr><td>cookie3d5 :</td><td>' . $GLOBALS['cookie3d5'] . '</td></tr>' .
						'<tr><td>cookie3d6 :</td><td>' . $GLOBALS['cookie3d6'] . '</td></tr>' .
						'<tr><td>cookie3d7 :</td><td>' . $GLOBALS['cookie3d7'] . '</td></tr>' .
						'<tr><td>cookie3d8 :</td><td>' . $GLOBALS['cookie3d8'] . '</td></tr>' .
						'<tr><td>cookie3d9 :</td><td>' . $GLOBALS['cookie3d9'] . '</td></tr>' .
						'<tr><td>cookie3d0 :</td><td>' . $GLOBALS['cookie3d0'] . '</td></tr>' .
						'</table>';	
   				}
				if ( $active_tab  != 'mab_info' ) {
					if ( $active_tab  == 'basic_settings' ) {
    					submit_button('Save Basic Settings' );
    				}
    				else {
    					submit_button('Save Advanced Settings' );
    				}
    			}
				?>
				<script type="text/javascript">
					jQuery("#toggle_custom_css,#button_type,#button_count").change(function() {
  						jQuery("#submit").click();
					});
				</script>
			</form>
	</div>