<!-- MAB FOOTER BACKLINK -->

	<div style="
		background-color:#fff;
		position:absolute;
		right:-1px;
		border:1px solid #ccc;
		border-radius:10px 0 0 0;
		padding:5px;
		font-size:10px;
		text-align:left;
		z-index:9999;
	">

		<a href="http://sebla.dk/mab">Powered by Multipurpose CSS3 Animated Buttons</a>

	</div>

<!-- END -->