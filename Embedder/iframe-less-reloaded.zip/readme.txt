=== iFrame-less Reloaded ===
Contributors: toddhalfpenny
Donate link: http://gingerbreaddesign.co.uk/wordpress/plugins/plugins.php
Tags: iframe
Requires at least: 2.8
Tested up to: 3.3.1
Stable tag: 0.0.1

iFrame-less Reloaded plugin is a simple and SEO friendly way to embed non-PHP dynamic content directly onto a wordpress page. Based on the IFrame-less plugin


== Description ==

iFrame-less Reloaded plugin is a simple and SEO friendly way to embed non-PHP dynamic content directly onto a wordpress page.

Based on the IFrame-less plugin by Fiach Reid (http://profiles.wordpress.org/users/freebiesms/) but extended to allow multiple widgets per sidebar.

Original Desc taken from IFrame-less : Not everyone who uses wordpress knows PHP. Perhaps you are more familiar with ASP.NET or JSP,but you can not just put ASP.NET or JSP code in the middle of wordpress, especially if your server does not support it.

Using an IFrame is a possibility, but it has some SEO (Search Engine Optimization) downsides, since, search engines will view that content as part of another page, and give your blog no extra credit for this content.

This plugin allows you to specify a URL, which this plugin will fetch for you, and re-display on the page, as part of the page content. Giving you the SEO advantage that an IFrame looses.

Note, this plugin should only be used to import content which you own or have rights to display on your site


== Installation ==

1. Install the plugin from within the Dashboard or upload the directory `iframe-less-reloaded` and all its contents to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Add the widgets via the Widgets options page and enter the URL of the page that you want to import


== Frequently Asked Questions ==

= Why is this better than IFrame-less = 

This version of the plugin allows the use of the widget mulitple times... and as such you can import content from multiple sites

= Can I import content into pages and posts as well as the sidebar? =

Yes, this can be done using the Widgets on Pages plugin

== Screenshots ==




== Changelog ==

= 0.0.1 = 

First Release based on the IFrame-less plugin by Fiach Reid

