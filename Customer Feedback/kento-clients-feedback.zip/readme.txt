=== Kento Clients Feedback ===
Contributors: kentothemes
Donate link: 
Tags:  Quote, Testimonial Rotator, Quote Slider, clients Feedback, clients Testimonial, testimonial slider
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display Cleants Feedback or Testimonials 


== Description ==

This plugin will add clients testimonial or feedback via shortcode with author image in page or post or sidebar or .php files.

Plugin Features

* Shortcode System
* Wordpress Custom Post Enabled.
* Post Thumbnail.
* TinyMCE Button added for generating Shortcode.
* Very Lightweight.
* Unlimited Color


Live Preview: http://kentothemes.com/demo/plugins/kento-clicents-feedback/

== Installation ==

Via WordPress -
1. Install as a regular WordPress plugin.
2. The plugin supports custom post. After installing you can see a menu called 'Kento CF'. There, you can add testimonials. After adding 'Kento CF' you can use shourcode`[KentoCF  postcount="3" current="2" bgcolor="#08cd98" ]` 
3. you could use for .php file any where `<?php echo do_shortcode('[KentoCF  postcount="3" current="2" bgcolor="#08cd98" ]'); ?>`


Via FTP -

1. Upload .zip file to your WordPress plugin directory and unzip it.
2. Go your Pluings setting via WordPress Dashboard and activate it.
3. Then Publish some post on 'Kento CF' post type with thumbnail.
4. Post Title will display as testimonial Name.
5. and use this shortcode anywhere to display  `[KentoCF  postcount="3" current="2" bgcolor="#08cd98" ]`
6. you could use for .php file any where `<?php echo do_shortcode('[KentoCF  postcount="3" current="2" bgcolor="#08cd98" ]'); ?>`

Shortcodes Attribute
 postcount => Total Feedback to display.
 current => Which post you want to highlight or current display.
 bgcolor => background color.
 
**Keep in mind "current" value must not greater than "postcount"

== Frequently asked questions ==


== Screenshots ==

1. Kento Clients Feedback 1
2. Kento Clients Feedback 2
3. Kento Clients Feedback 3
4. Kento Clients Feedback Admin


== Changelog ==

= 1.0 =
* Initial release

