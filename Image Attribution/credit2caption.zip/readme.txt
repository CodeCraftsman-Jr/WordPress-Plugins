=== Plugin Name ===
Contributors: Marco Buttarini
Donate link: http://marbu.org
Tags:              caption,iptc,credit,upload,image
Requires at least: 3.0
Tested up to:      3.0.1
Stable Tag:        1.2
Plugin Name:       Credit2Caption
Plugin URI:        http://marbu.org/marbu/credit2caption/
Author URI:        http://marbu.org
Author:            Marco Buttarini
Version:           1.2


== Description ==

Add *IPTC credit* to the *caption* of the image after have uploaded it.

== Installation ==

Copy into wp-content/plugins and activate plugin

== Upgrade Notice ==

== Screenshots ==
1. Here is where credit is saved after image upload

== Frequently Asked Questions ==
= Which IPTC field is used to get Picture Credit? =
There is not a real standard about picture captioning.  For my purpouse I use IPTC number 2#110, in a future release I will add a configuration panel to choose where to take Credit Information

