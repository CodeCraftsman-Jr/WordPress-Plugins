<div class="wrap">
        
	<h2><strong>About the PHP-KeyCodes plugin</strong></h2>
	<p>This plugin is Version 1.0</p>        
    <p>For details of the plugin refer to web site http://www.withinweb.com/wordpresskeycodes/</p>
        
</div>