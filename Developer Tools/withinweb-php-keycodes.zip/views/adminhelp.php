<div class="wrap">
        
	<h2><strong>Help for the PHP-KeyCodes plugin</strong></h2>
    
    <h3>Short codes</h3>
    
	<p>The PayPal buttons are created using short codes as follows:
    <br/>    
    [keycodesbutton recid='x']
    <br/>
    where x is the record id of the product item.
    </p>     
  
  	<p>You can get the record id of the product by going to 'Item List'.</p>
  
</div>