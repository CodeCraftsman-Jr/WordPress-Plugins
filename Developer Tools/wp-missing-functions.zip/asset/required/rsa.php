<?php
echo"

<h3>About the PLugin</h3>
<div class='inside'>
<p class='inner'>Configuration:  <a href='http://thainetworks.net/shop/plugins/wp-missing-functions/' target='_blank' title='Plugin URL'>Plugin URI</a></p>
<p></p><hr>
<h4 class='inner'>Do you like this plugin?</h4>
<p class='inner'>Please, <a href='http://wordpress.org/support/view/plugin-reviews/wp-missing-functions' target='_blank' title='rate it'>rate it</a> on WordPress.org<br>          
</p><hr>
<div class='up-pic'><a href='http://thainetworks.net/shop/plugins/wp-missing-functions/' target='_blank'><img width='170' height='70' src='/wp-content/plugins/wp-missing-functions/asset/images/wpmf-pro.png'></a></div>
</div>
        
        "
?>