<?php
require_once(ABSPATH.'wp-includes/pluggable.php');
$dir = dirname(__FILE__);
require_once($dir .'/functions/tab1-fun.php');
require_once($dir .'/functions/tab2-fun.php');
require_once($dir .'/tab3-fun.php');
require_once($dir .'/tab4-fun.php');

