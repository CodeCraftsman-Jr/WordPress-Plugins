<?php

/**
 * Fired during plugin activation.
 */
class Grid_Element_Trash_Activator {

	/**
	 * FIRE
	 */
	public static function activate() {
		
	}

}
