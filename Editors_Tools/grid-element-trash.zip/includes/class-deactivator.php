<?php

/**
 * Fired during plugin deactivation.
 * 
 */
class Grid_Element_Trash_Deactivator {

	/**
	 * FIRE
	 */
	public static function deactivate() {
		
	}

}
