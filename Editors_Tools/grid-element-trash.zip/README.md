grid-element-trash-wordpress
============================

Plugin for trashing containers and boxes from grid toolbar by hook
