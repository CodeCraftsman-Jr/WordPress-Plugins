=== Grid Element Trash ===
Contributors: edwardbock
Donate link: http://palasthotel.de/
Tags: grid, extension, trash
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 0.9
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl

You can hide containers and boxes from the Grid toolbar.

== Description ==

This plugin extends the grid plugin. You can hide containers and boxes from the toolbar.

== Installation ==

1. Upload `grid-element-trash.zip` to the `/wp-content/plugins/` directory
1. Extract the Plugin to a `grid-element-trash` Folder
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Goto Tools->Grid Element Trash
1. Drop Boxes and Containers to the Trash

== Frequently Asked Questions ==



== Screenshots ==



== Changelog ==

= 0.9 =
First release

== Arbitrary section ==

There’s a documentation at doc.the-grid.ws (english is coming soon)


