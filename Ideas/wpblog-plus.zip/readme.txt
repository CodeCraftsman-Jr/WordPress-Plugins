﻿=== WordPress Plus + ===
Contributors: msceo
Donate link: http://blog.czelo.com/
Tags: wordpressplus, wpplus
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.3
License: GPLv2 or later

== Description ==
极致迷你和轻巧的 WordPress Plus + 插件，轻松加速和增强你的WordPress博客！（仅建议中国大陆博主使用）

WordPress的许多内置功能（例如使用的 Google Fonts Api 和 Gravatar 头像）在大陆地区使用遭到了限制，导致这些内置功能拖慢了网站的打开速度，WordPress Plus + 通过一些非常简单的方式就可以将这些内置功能加速，从而加速你的博客。

同时，WordPress Plus + 还拥有一些SEO优化功能，帮助优化博客的SEO！

== Installation ==
1. 通过 WordPress 插件库或者手动安装 WordPress Plus + 并启用
2. 启用后将自动跳转至设置页面，按照需要开启对应功能保存设置即可

== Frequently Asked Questions ==
1. 插件导致博客异常

在插件更新发布之前作者都会进行调试，如果出现了问题可以反馈到http://ceoblog.gq/wordpress-plus，反馈后我会第一时间进行处理。

== Screenshots ==
1. WordPress Plus +

== Changelog ==

= 1.7 =
抱歉！来晚了！
由于想不到有什么新的实用功能加进来所以插件一直都没有更新，现在1.7版本已发布，更新了两个新功能：禁止全英文评论 和 禁用WordPress的emoji表情 的功能，并兼容了最新的WordPress4.2.2版本，么么哒！

= 1.6 =
修复 pingback选项不起作用的问题
新增 使用必应美图作为登陆界面背景功能（背景图每日更新）

= 1.5.1 =
Google Fonts Api 相关资源已解封，出于稳定性考虑，Open-Sans加载源替换为360前端库CDN功能已被取消。

= 1.5 =
功能新增：
禁止站内文章PingBack
自动为博客内的连接添加nofollow属性并在新窗口打开链接

= 1.4 =
优化使用SSL调用Gravatar头像的方式，现在不会出现某些地方仍任是HTTP头像无法显示的问题了

= 1.3.2 =
Bug fixes and performance…解决了保存设置时的一个小问题

= 1.3.1 =
优化插件代码

= 1.3 =
提交到WordPress插件库的第一个版本，包含基础功能，并优化了代码

== Upgrade Notice ==
= 1.3 =
正式提交至WordPress插件库