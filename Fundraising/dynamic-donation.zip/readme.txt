=== Dynamic Donation paypal payflow ===
Contributors: faaiq
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=KK6VKQZYN8RB2
Tags: Donation, Donation form, paypal donation, paypal website pro donation, payflow pro donation, credit card donation, donation post type
Requires at least: 3.3
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create Donation form by adding various type of fields, export form html to theme directory, paypal,payflow and paypal pro.

== Description ==

If You want to creates a donation form with you own choice of fields then this is a correct plugin for you. With this plugin you can create you own donation form with various type of fields. then you can export donation form html to your theme directory. this plugin support paypal standard payment method, paypal website pro and payflow pro.


1. Creates your donation form by adding fields.
2. Export donation form in theme directory and changes the design according to your need.
3. Show donation form anywhere with short code [render_donation_form]
4. support paypal standard payment method, paypal website pro and payflow pro.




== Installation ==

1. Upload `dynamic-donation` to `/wp-content/plugins/` directory
2. Activate plugin through the 'Plugins' menu in WordPress
3. click on Post order.

== Frequently asked questions ==



== Screenshots ==



== Changelog ==


== Upgrade notice ==



== Arbitrary section 1 ==
