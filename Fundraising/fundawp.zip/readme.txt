=== Wordpress Funda XML ===
Tags: Wordpress Funda XML
Requires at least: 3.8.1
Tested up to: 4.0.1
Stable tag: 1.0
License: private

== Installation ==

Install like you would install any other wordpress plugin.
Go to Settings -> Funda Options and put in the category name of your realestates pages/posts.

== Changelog ==

= 1.6 =

* Removed the option to use the checkbox
* Added Jaap XD scheme to communicate with the Jaap extension
* Added integration for Real Homes - WordPress Real Estate Theme

= 2.0 =

* Removed further references to checkbox
* Removed individual theme support
* Removed JAAP XD Scheme
* Improvements Stability