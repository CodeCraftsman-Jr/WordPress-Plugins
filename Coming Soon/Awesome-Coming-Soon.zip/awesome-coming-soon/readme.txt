=== Awesome Coming Soon ===
Contributors:iamaliiraja
Donate link: http://wwww.hashwp.com
Tags: comingsoon, landing page, mantaince mode 
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Awesome Coming Soon plugin allows you to create a responsive and professional coming soon page in few minutes.

== Description ==

Add a Coming soon page to your blog that lets visitors know your blog is coming soon. User with admin rights gets full access to the blog including the front end.
Activate the plugin and your blog is in As Coming Soon , works and only registered users with enough rights can see the front end. 

### Features:

* Works with any WordPress Theme
* Responsive Frontend
* Responsive Option Panel
* Provide Social connectivity(Facebook, Twitter, Google+)
* Free Coming soon page template
* Flexible and user-friendly setup
* Coming soon Active mode menu bar on wordpress admin dashboard.
* Visible only non logged user.
* Easily update and post content in your site when “Awesome Coming Soon" is in Active mode. 

*If you have any suggestions or Questions you can contact us at [HashWP &raquo;](http://www.hashwp.com/)

*[Click here to see live demo!&raquo;](http://photontechs.com/awesomecomingsoon/)

== Installation ==

Manual Installation 

1. Download Awesome Coming Soon Plugin
2. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Go to As Coming Soon in left menu and manage your coming soon page from there.

== Frequently Asked Questions ==

== Screenshots ==

1. Awesome Coming Soon Will look like this to your users
2. You can simply enable or disable coming soon mode.
3. You can your own content(Title,Heading,Text)
4. You can change Background colours or image, and can add social media links.

== Changelog ==

= 1.0 =

* Plugin Submitted.
* Background image and colour features added,
