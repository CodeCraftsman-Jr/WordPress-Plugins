=== Easy Coming Soon ===
Contributors: a.ankit, deepeshpaliwal
Donate link: http://www.webriti.com/
Tags: coming soon, wordpress coming soon, wordpress under construction, wordpress maintenance mode, maintenance mode, under construction, coming soon page, launch page, maintenance, construction, offline,landing page 
Requires at least: 3.3+
Tested up to: 4.1
Stable tag: 1.8.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy coming Soon plugin allows you to quickly create a launch / under construction page for your website. Collects E-mails and connect with users on Social Networks. 

== Description ==

The **Easy Coming Soon** plugin allows you quckly create a Launch page / Coming Soon page for your wordpress website.  Simply activate the plugin, Setup Page Title , Description and you are ready to go. 

The Easy Coming Soon plugin works with any WordPress theme you have installed on your site. Looged out users will see the coming soon page while logged-in users will have access to the website. This is ideal for web developers who want to present their clients with a Under construction page while working on the website. 

Give **Easy Coming Soon** a try. We are sure you will like it. 

In case you face any problem, contact us via the [Forums](http://wordpress.org/support/plugin/easy-coming-soon). 


**Features**

* Works with any WordPress Theme
* Responsive
* Provide Social connectivity(Facebook, Twitter, Google+)
* Free Coming soon page template
* Flexible and user-friendly setup
* Live Preview of coming soon page
* Subscribe feature / Easily collect visitor emails
* Add Google Analytics Tracking to the Coming Soon Page
* Very easy customization of coming soon page template setup


== Installation ==

1. Download Easy coming soon plugin.
2. Upload the easy-coming-soon folder to the /wp-content/plugins/ directory.
3. Activate the plugin through the 'Plugins' menu in WordPress and Enjoy.


== Frequently Asked Questions ==




== Screenshots ==

1. Create Coming soon page like this
2. Coming soon plugin general setting panel
3. Coming soon plugin Design panel

== Changelog ==

= 0.5 =
This version provides basic functionality to craete easily coming soon or launching page and get e-mail on wordpress blog.