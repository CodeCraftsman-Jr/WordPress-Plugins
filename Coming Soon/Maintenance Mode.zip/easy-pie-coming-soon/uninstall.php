<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
if(defined('WP_UNINSTALL_PLUGIN')) {
    
    delete_option("easy-pie-cs-options");
}
?>
