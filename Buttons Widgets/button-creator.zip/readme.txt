=== Wordpress Button Creator ===
Contributors: jeffbullins
Donate link: http://www.thinklandingpages.com
Tags: buttons, create buttons, call to action button, sales button, form button, html button 
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily create a submit button for your Wordpress site.

== Description ==

Easily create a submit button for your Wordpress site.

*  [Button Creator quick start guide](http://www.thinklandingpages.com/wordpress-button-creator/)

###What you get when you use the Wordpress Button creator plugin

*  Submit buttons
*  Create a button with a simple shortcode
*  [think_button url="http://www.google.com" text="Get Access Now Baby"][/think_button]


###Additional Features in the full Advanced version

*  More colors
*  Google Web Fonts
*  More sizes

*  [Button Creator quick start guide](http://www.thinklandingpages.com/wordpress-button-creator/)

== Installation ==


1. Upload `button-creator` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Click **Button Creator** on the admin menu to enable and set your options.


== Frequently Asked Questions ==

= Do I have to know how to program or design? =

No.  The plugin does the programming and design.


== Screenshots ==




== Changelog ==

= 1.0 =
* First Release


