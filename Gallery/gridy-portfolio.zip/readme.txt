=== Gridy Portfolio ===

Tags: portfolio, grid, grid portfolio, expandable
Requires at least: 3.0.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

Gridy portfolio display your work effectively with google like expandable preview with title, description and project link.

<a target="_blank" href="#"> DEMO (under maintenance) </a>

For project url add custom field 'g_link' while adding new project.



== Installation ==

1. Log in to your website administrator panel.
2. Go to Plugins page, and add new plugin.
3. Upload plugin zip file.
4. Click Install Now button.
5. Then click Activate Plugin button.
6. Use shortcode [gportfolio] to any page to list all portfolio items. Add optional column number, [gportfolio col=4]. There are three options at the moment. 2, 3(default), 4. 




