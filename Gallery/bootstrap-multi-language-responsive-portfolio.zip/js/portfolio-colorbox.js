$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				$(".portfolio").colorbox({rel:'portfolio', height:"75%"});
});