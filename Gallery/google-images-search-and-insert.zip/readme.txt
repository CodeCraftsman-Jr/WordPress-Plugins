=== Google Images Search And Insert ===
Contributors: baby2j
Donate link: http://dunghv.com/downloads/wordpress-google-images-search-and-insert
Tags: google image, google images, google photo, google photos, google search, wordpress google images, google library, google images api
Requires at least: 3.5
Tested up to: 4.2.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin help you search images on internet (powered by Google Images API) and insert to content or set featured image very quickly.

== Description ==

This plugin help you search images on internet (powered by Google Images API) and insert to content or set featured image very quickly.

Feature:

- Search images and insert to content
- Change title and size
- Add caption
- Set featured image

Note: To have full version with "Save to Media Library" feature, please go to http://dunghv.com

== Installation ==

1. Unzip the google-images-search-and-insert.zip
2. Copy google-images-search-and-insert folder to wp-content/plugins
3. Go to Plugins/Installed Plugins, find Google Images Search And Insert and click Active
4. Enjoy!

== Screenshots ==

1. "Google Images" button
1. Search images with powerfull options
1. User searched image with many purposes
1. Enjoy

== Frequently Asked Questions ==

= Need support? =

Visit [plugin documentation website](http://dunghv.com "plugin documentation")

== Changelog ==

= 2.2 =
* Improve UI

= 2.1 =
* Optimized code

= 2.0 =
* Included "Set Featured Image" feature

= 1.0.4 =
* Improve UI

= 1.0.3 =
* Fix some issues

= 1.0.2 =
* Compatible up to WordPress 4.2.2

= 1.0.1 =
* Google Images Search And Insert plugin released