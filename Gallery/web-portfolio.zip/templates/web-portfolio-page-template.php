<?php get_header(); ?>
<div class="portfolio_wrapper">
	<?php echo do_shortcode( '[web_portfolio]' );?>
</div>
<?php get_footer(); ?>