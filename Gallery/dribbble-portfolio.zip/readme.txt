=== Dribbble Portfolio ===
Contributors: kentothemes
Donate link: 
Tags:  dribbble shots wordpress, dribbble shots, dribbble portfolio wordpress, dribbble shots display website
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display dribbble.com shots to your website

== Description ==

By this plugin you can display your dribbble.com shots as Portfolio to your website anywhere via shortcodes.

Live Preview: http://kentothemes.com/demo/dribbble-portfolio/

Plugin Features

* Use via shortcodes.
* Any number of shots you can display up to 15.
* Big popup view on click.
* Shots player thumbnail, name, location at top.
* Shots title.
* Shots view count.
* Shots comment count.
* Shots like count.
* Unlimited items border color.
* Unlimited background color.



== Installation ==

1. Install as regular WordPress plugin.
2. Go your Pluings setting via WordPress Dashboard and activate it.
3. use this shortcodes <strong>[deribble_shots  userid="usename" bgcolor="#fff" border_color="#e8e8e8" count="12" ]</strong><br />

<strong>shortsodes parameter info</strong><br />

<strong>userid:</strong> same as dribbble.com username <br />
<strong>bgcolor:</strong> background color for shots area, default #ffffff<br />
<strong>border color:</strong> border color for shots items,  default  #ffffff<br />


== Screenshots ==

1. Display shots.
2. Shortcodes on post.
3. Display shots.


== Changelog ==

= 1.0 =
* Initial release.

