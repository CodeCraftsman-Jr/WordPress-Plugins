window.jQuery = window.$ = jQuery;

var EditSherkPortfolioMain=function(){
	/**upload**/
	$( document ).ready(function() {
	
		$('#sherky_portfolio').jportilio({ratio: 1});
		
	});

}

new EditSherkPortfolioMain();