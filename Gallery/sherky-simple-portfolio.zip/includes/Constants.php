<?php


global $wpdb;

//Table Constants
define('SHERKPORTFOLIOPERSONAL', $wpdb->prefix . 'sherkportfoliopersonal');
define('SHERKPORTFOLIOPROJECTS', $wpdb->prefix . 'sherkportfolioprojects');
define('SHERKPORTFOLIOPOSTS', $wpdb->prefix . 'posts');        


?>