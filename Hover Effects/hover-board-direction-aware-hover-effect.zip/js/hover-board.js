  (function( $ ) {
      "use strict";

      $(function() {

$(function() {
        // $(' .serice-image-side > li ').each( function() { $(this).hoverdir(); } );
            $( script_vars.alert ).each( function() { $(this).hoverdir(); } );

        $(' .portfolio-image > li ').each( function() { $(this).hoverdir(); } );
       //alert( script_vars.alert );

      });
      });
  }(jQuery));
