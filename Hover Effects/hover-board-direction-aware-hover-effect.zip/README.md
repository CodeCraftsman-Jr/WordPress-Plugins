# Hover Board - Direction awear hover effect Wordpress Plugin

Demo here: http://fmsftw.com/hover-board-demo/

## Installation

Installation process

	Upload plugin to wp-content/plugins/

## Usage

<h2>Hover Board Demo</h2>

. Download the plugin HERE
. Upload the plugin to your WordPress installation
. At your WordPress dashboard, under settings, select Hover Board
. Enter your chosen outer and inner class names and click SAVE
. Copy the generated sample code to a post or page, modify and enjoy!

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## History

None yet, version 0.1!

## Credits

Part of the jQuery written at: http://tympanus.net/codrops/2012/04/09/direction-aware-hover-effect-with-css3-and-jquery/

WordPress plugin by: http://fmsftw.com

## License

GPLv2
