=== DeMomentSomTres DEBUG ===
Contributors: marcqueralt
Tags: custom debug, multisite
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later

Debug only one of my sites in a multisite network

== Description ==

I needed to debug only one of my sites in a multisite network so I was not allowed to use WP_DEBUG.

So, I implemented the changes that WP_DEBUG does but only for the website it is installed.

It also saves results on wp-content/errors.log

== Installation ==

Upload and activate it. Debug messages will start.

= Uninstall =

To stop showing debug messages, you only need to deactivate this plugin.

== Changelog ==

= 1.0 =

* First release