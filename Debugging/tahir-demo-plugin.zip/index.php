<?php
/*
Plugin Name: tahir-demo-plugin
version:1.0
Author: Tahir Yasin
*/


?>