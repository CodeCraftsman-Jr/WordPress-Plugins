wordpress-log-plugin
====================

Wordpress log plugin
