=== Plugin Name ===
Contributors: ugurcatak
Donate link: http://www.dictionarybox.com/donate.html
Tags: dictionary, translator, translation, translate, glossary, lexicon, thesaurus, definitions, words, english, spanish, dutch, italian, german, french, portuguese, greek, chinese, japanese, korean, turkish, russian, plugin, multilingual, language, vocabullary, tooltips
Requires at least: 2.0.2
Tested up to: 3.2
Stable tag: 1.0

Provides an internal double click dictionary on the footer of your pages.

== Description ==


Click here for quick demo page : [Dictionary for your website](http://www.dictionarybox.com/) 

Dictionary Box provides an internal dictionary on the footer of your pages with double click functionality and audio pronounce. Dictionary Box does not open a new page to translate words, the visitors stay at your website.

Dictionary Box provides translations in English, Spanish, Portuguese, German, French, Italian, Russian, Turkish, Dutch, Greek, Albanian, Chinese, Japanese and Korean dictionaries.

Please rate the Dictionary Box translator plugin if you find it useful, thank you.

== Installation ==

1. Download the .zip file
2. Extract the contents and upload into your wp-content/plugins directory
3. Activate the plugin in your WordPress Dashboard
4. Set glossary options via plugin settings page. Default glossary is English &hArr; Spanish.
   
== Frequently Asked Questions ==

= I have Installed the plugin but nothing is showing up on my site? =

Please check your Wordpress theme, all themes must have wp_footer() function. This is a WordPress theme development standart. See how to fix this: http://www.youtube.com/watch?v=h59sy3tUQrc

http://www.dictionarybox.com/feedback.html

== Screenshots ==

1. screenshot-1.gif
2. screenshot-2.jpg

== Changelog ==

= 1.0 =
* This is the first version of the plugin.

== Upgrade Notice ==
There have been no upgrades yet.
