<?php
class IDF {
	function __construct() {
		
	}
}
?>