Any problem, please visit http://www.phpfastcache.com -> Issues

We will fix it fast for you!