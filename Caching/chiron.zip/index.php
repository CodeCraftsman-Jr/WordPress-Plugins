<?php

// Silence is golden, and silver, and bronze

?>
