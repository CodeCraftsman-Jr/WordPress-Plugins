<!DOCTYPE html SYSTEM "about:legacy-compat">
<html>
	<head>
		<title>Chiron – The Teacher of Heros</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="style.css" type="text/css" media="screen" />  		
	</head>
	<body>
		<h1><a href="/">Chiron</a> - The Teacher of Heros</h1>
		
	
		  
		  