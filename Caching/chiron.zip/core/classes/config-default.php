<?php 

/* Basic Configuration */

$home = "http://example.com/";
$db_srv = "";
$db_pwd = "";
$db_usr = "";
$db_dbs = "";
$opml = "";
$feeds_per_cron = 1;

define(DB_SRV,$db_srv);
define(DB_PWD,$db_pwd);
define(DB_USR,$db_usr);
define(DB_DBS,$db_dbs);
define(FEEDS_PER_CRON,$feeds_per_cron);
