=== Custom Metaboxes and Fields ===
Contributors:	Andrew Norcross (@norcross / andrewnorcross.com)
				Jared Atchison (@jaredatch / jaredatchison.com)
				Bill Erickson (@billerickson / billerickson.net)
Version: 0.4
Requires at least: 3.0
Tested up to: 3.1
 
== Description ==

This will create metaboxes with custom fields that will blow your mind.

== Installation ==

This script is easy to install. If you can't figure it out you probably shouldn't be using it.

1. Place `metabox` directory inside a 'lib' directory of your (activated) theme. E.g. inside /themes/twentyten/lib/.
2. Edit theme's function.php to include /lib/metabox/init.php.
3. See example-functions.php for further guidance.

== Frequently Asked Questions ==

None yet.

== Changelog ==

= 0.4 =
* Think we have a release that is mostly working. We'll say the initial release :)


