  === downloadmanager ===

Contributors: n4nirob
Donate link: #
Tags: wp-download manager, Download, Download Manager, Data view, Data table, Wp download manager, Wordpress download manager
Author: n4nirob
Author URI: http://profiles.wordpress.org/n4nirob
Author e-mail: n4nirob@gmail.com
Requires at least: 3.2
Tested up to: 3.5.1
Stable tag: 1.01
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows you to implement download option into your web site.

== Description ==

This is a free download manager plugin.

Downloadmanager, A very simple Wordpress plugin to show your data from a specific data table. You can store Album name, Title, Author name, Category name, Download link from plugin menu. Also you can show any categories data in any page in your site.
Very simple, easy wordpress download manager plugin.

<a href="http://www.extensions.3jon.com/support/" target="_blank">Support</a>  
  

= Features =

* Actions: save any quantity of the category data.
* Description: You can store Album name, Title, Author name, Category name, Download link from plugin menu.
* Actions: Possibility to load any number of data to each category in the post.

= Technical support =

Dear users, if you have any questions or propositions regarding our plugins please feel free to contact. You may contact through mail support@3jon.com  Please note that we accept requests in English only.


== Installation ==

1. Upload `downloadmanager` folder to the directory `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Screenshots ==

1. Downloadmanager Admin page.
2. Galleries albums page on frontend.


== Changelog ==

= V1.01 =
The first version of the wordpress downloadmanager plugin

= V1.02 =
The first version update of the wordpress downloadmanager plugin

= V1.03 =
The second version update of the wordpress downloadmanager plugin