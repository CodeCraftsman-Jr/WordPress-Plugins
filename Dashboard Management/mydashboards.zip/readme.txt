=== My Dashboards ===
Contributors: V.J.Catkick
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2933164
Tags: dashboard, multipul, link, administoration,
Requires at least: 2.5
Tested up to: 2.8
Stable tag: 4.3

Adding WordPress's dashboard link on your dashboard if you have more than one WordPress blog.

== Description ==

Most of WordPress users are having more than two blogs such as main blog and test blog. If you so, it is troublesome to go two dashboards each time you log in.

This tiny plugin adds additional links below 'Dashboard' menu at your dashboard.

You can add up to 5 links.

== Installation ==

Place the php file in your /wp-content/plugins/ directory
and activate through the administration panel.

== Screenshots ==

1. Main View
2. Option Panel

