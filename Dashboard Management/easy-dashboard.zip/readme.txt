=== Easy Dashboard ===
Contributors: Milmor
Tags: dashboard, easy, clean, tiny
Requires at least: 3.6
Tested up to: 4.2
Version: 1.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Refresh your WordPress dashboard with this new elegant, metro-based one.

== Description ==

Easy Dashboard is a tiny, elegant and clean plugin that helps you and your clients to feel more confortable with WordPress.

Once installed, you will find a new Dashboard and some things wrapped up with "metro-style" shortcuts that give you quick access to your menu pages. The new dashboard will show an elegant, localized "welcome message", quick access to your post type (custom ones too) and to every menu item based on current user role.


== Installation ==

1. Download the plugin and install in WordPress
2. Activate it

== Screenshots ==

1. Demo for simple website
2. Website with custom post types

== Changelog ==

= 1.1 17.07.2015 =
* Added option to customize tagline
* Minor changes
* ReadMe changes

= 1.0 26.02.2015 =
* First release