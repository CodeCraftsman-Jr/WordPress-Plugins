=== DashPress ===
Contributors: andre renaut
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=andre%2erenaut%40gmail%2ecom&lc=US&item_name=MailPress&item_number=gg&amount=5%2e00&currency_code=EUR&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHostedGuest
Tags: Feed, Aggregator, SimplePie, Widget, Dashboard, Wordpress, Plugin, Management
Requires at least: 3.8
Tested up to: 3.8
Stable tag: 3.5

Allows you to display the last items of several feeds on your dashboard 

== Description ==

**Allows you** to display the last items of several feeds in your dashboard 

For *each* widget, **aggregates** as much feeds as you like (1 to 10) and display the last items (3 to 99).

Up to **5** different DashPress widgets on your Dashboard !!!

Supported languages : English, French	(.pot provided)

== Installation ==

1. **Extract** all files from the ZIP file, making sure to keep the file structure intact.
1. Upload it in your plugin directory (e.g. `/wp-content/plugins/`).
1. **See Also:** ["Installing Plugins" article on the WP Codex](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins)
1. Then just visit your admin area and activate the plugin. 

== Frequently Asked Questions ==
 * 

== Screenshots ==
1. screenshot 1
2. screenshot 2

== Changelog ==

 **3.2**		2011/08/01 wp 3.2 compatibility

 3.1		2010/12/21 first release

== Upgrade notice ==
*

== Next features ==

**Any new idea** or **code improvement** can be posted at : contact@nogent94.com