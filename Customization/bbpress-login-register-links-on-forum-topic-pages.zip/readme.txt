=== Bbpress Login Register Links On Forum Topic Pages ===
Contributors: zhuyi
Author URI: http://tomas.zhu.bz/
Donate link: http://tomas.zhu.bz/
Tags:bbpress,forum,template,login,register,log in,links,login link,register link,logged in,signup,user friendly,topic,forum index, forum pages,topic pages.
Requires at least: 2.0
Tested up to: 4.1.1
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add bbpress login link, register link, forget password links in bbpress forum index pages or bbpress single forum pages or bbpress forum pages or bbpress topic pages.

== Description ==
Plugin Support Forum: http://tomas.zhu.bz/bbpress-plugin-bbpress-login-register-links-on-forum-page-and-topic.html/<br>

Bbpress is a great forum product, I used it build many forums, but in recent days when I build a site which focus the forum, I found a problem -- there are no bbpress login link, bbpress register link, bbpress forget password links in bbpress forum index pages or bbpress single forum pages or bbpress forum pages or bbpress topic pages. 
I try to find a solution, the result is I understand in the current time, I had to put the forum login link at the widget or I had to tell users to how to find the log in link in forum topics or add register/login links in the menu items... 
For webmasters, the widget is rare asset and the sidebar area have no so many place to put a big log in widget..., for users, many of users/clients is not good at forum scripts or web sites, and they have no time to find the log in link in your sites..., the result is many of users just leave away from your forums, as a webmaster, this is not good because you used so many days/nights to build the site and offer the services. 
I think the most easy way is put the log in/register links in the forum pages or in the topic pages, for this reason, I developed a new bbpress plugin: Bbpress Login Register Links On Forum Page And Topic. 

<h4>How To Use:</h4>
It is very easy to install and use, please just upload the plugin and active it, no any setting in backend needed, you will find at the top of forum pages, there are log in / register and Lost / Password links,  when a user is logged in, the login link will turn into logout link. Also if you use some log in plugins like theme my login which changed login/register links, the plugin will still works well, how it looks? Please check screenshots. :)

== Installation ==

1:Upload the Bbpress Login Register Links On Forum Topic Pages to your site
2:Activate it 
3:No any setting needed in back end, the bbpress login link and the  bbpress register link and forget password links will shown at the top/bottom of your forum pages or topic pages.

1, 2, 3: You're done!

== Frequently Asked Questions ==
FAQs can be found here: http://tomas.zhu.bz/bbpress-plugin-bbpress-login-register-links-on-forum-page-and-topic.html/

== Screenshots ==

1. Login link at the top of forum pages
2. Login link at the bottom of forum pages
3. Login link at the top of topic pages
4. Login link at the bottom of topic pages

== Changelog ==
= Version 1.1.0 =
* When a user is logged in, the login link will turn into logout link

= Version 1.0.1 =
* Add the readme.txt and request add this plugin into bbpress directory.

= Version 1.0.0 =

* Spell out that the license is GPLv2
* Finished the first version
* General code clean up

== Upgrade Notice ==
= Version 1.0.1 =
First version

== Download ==
http://tomas.zhu.bz/bbpress-plugin-bbpress-login-register-links-on-forum-page-and-topic.html/