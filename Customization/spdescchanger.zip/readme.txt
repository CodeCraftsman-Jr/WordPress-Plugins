=== spDescChanger ===
Contributors: SebastianK 
Donate link: http://www.scriptpara.de/skripte/spdescchanger/
Tags: jquery, fade, description, change
Requires at least: 2.7
Tested up to: 2.8.2
Stable tag: 0.1
	
With this Plugin you can set several descriptions for your blog. They change randomized without reloading the page.

== Description ==

With this Plugin you can set several descriptions for your blog. They change randomized without reloading the page.
You will find an example video on the plugin-page at http://www.scriptpara.de/skripte/spdescchanger/
	
== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

Be sure, that in your header.php the code is as follows:

< div class="description">< ?php bloginfo('description'); ? ></div >

The important thing is the class "description"!!
 
== Changelog ==

= 0.6 24.07.2009 =
* initial release