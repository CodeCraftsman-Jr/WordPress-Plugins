jQuery(document).ready(function($) {
	
	// In order to move the hidden badge parameter out of the main metabox.
	// Not a great solution, but there aren't any other options I'm aware of.
	$("<p><strong>Hidden Badge</strong></p>").appendTo("#pageparentdiv .inside");
	$("#simplebadges_badge_hidetoggle").appendTo("#pageparentdiv .inside");
	$("#simplebadges_badge_hidetoggle-label").appendTo("#pageparentdiv .inside");
	
	// Maybe I don't need CSS for now
	$("#simplebadges-meta-box tr:eq(1)").hide();
	$("#simplebadges-meta-box tr:eq(3)").hide();
	$("#simplebadges-meta-box tr:eq(4)").hide();
	
	// Tweak the featured thumbnail metabox
	$("#postimagediv h3.hndle span").text("Badge Image");
	//$("#set-post-thumbnail").text("Set badge image");
	$("#remove-post-thumbnail").text("Remove badge image");
	
	// Adjust the conditional dropdowns
	$("#simplebadges_badge_conditional_parttwo").appendTo("#simplebadges-meta-box tr:eq(2) td");
	$("#simplebadges_badge_conditional_partthree").appendTo("#simplebadges-meta-box tr:eq(2) td");
	
	// Display none the row unless the automatic option is chosen
	if ( $("#simplebadges-meta-box tr:eq(0) input:eq(1)").is(":checked") ) {
		$("#simplebadges-meta-box tr:eq(2)").css( "display", "table-row" );	
	} else {
		$("#simplebadges-meta-box tr:eq(2)").css( "display", "none" );
	}
	
	$("#simplebadges-meta-box tr:eq(0) input:eq(1), #simplebadges-meta-box tr:eq(0) td label:eq(1)").click(function() {
		$("#simplebadges-meta-box tr:eq(2)").css( "display", "table-row" );	
	});
	
	$("#simplebadges-meta-box tr:eq(0) input:eq(0), #simplebadges-meta-box tr:eq(0) td label:eq(0)").click(function() {
		$("#simplebadges-meta-box tr:eq(2)").css( "display", "none" );	
	});

});