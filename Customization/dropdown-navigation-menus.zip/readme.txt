=== Dropdown Navigation Menus ===
Contributors: shazdeh
Plugin Name: Dropdown Navigation Menus
Tags: menu, dropdown, nav-menu, widget, theme
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 0.1

A widget to create dropdown menus powered by jQuery Superfish.

== Description ==

This widgets enables you to make dropdown menus. It doesn't have any skins, but you can optionaly choose to load and apply Superfish's default styles.

== Installation ==

1. Upload the whole plugin directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Goto Appearance -> Widgets and,
5. Enjoy!

== Screenshots ==

1. Widget options