=== DeleteCustom ===
Contributors: sisifodichoso
Donate link: http://sisifodichoso.org/proyectos/deletecustom/
Tags: metadata, custom, admin, custom field
Requires at least: 2.0
Tested up to: 3.0
Stable tag: 1.1

DeleteCustom helps you to delete the custom fields of your posts. Very easy to install and use.

== Description ==

This plugin helps you to remove Custom Fields from your blog without access to your database. Choose easily the custom field and the posts on which you want to remove it. There are english and spanish versions of this plugin and more information in the plugin page.
Este plugin te ayuda a borrar campos personalizados de tu blog sin que tengas que acceder a tu base de datos. Elige fácilmente el campo personalizado y los posts de los que quieres borrarlo. Hay versiones del plugin en español e inglés y más información en la página del plugin.




== Installation ==

This section describes how to install the plugin and get it working.



1. Upload `deletecustom.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

There is no questions yet ;-)

== Screenshots ==

1. Screenshot 1

== Changelog ==

= 1.1 =
* Fixed Not wp_ prefix in data base bug. 

= 1.0 =
* First Version.

== Upgrade Notice ==

= 1.1 =
Fixed Not wp_ prefix in data base bug. 

