=== Remove Ozh unobstrusive credits in footer ===
Tags: ozh,remove,footer,plugin,backend,admin
Requires at least: 3.5
Tested up to: 4.1
Stable tag: stable
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Removes Ozh footer text from the admin backend.

Author: Polemos

== Description ==
This plugin removes the unobtrusive footer text installed by "Ozh Admin Drop Down Menu" in the backend (admin) of wordpress.

== Installation ==
1. Upload files to your /wp-content/plugins/ directory (preserve sub-directory structure if applicable)
2. Activate the plugin through the \'Plugins\' menu in WordPress

== Frequently Asked Questions ==
-What is "Ozh Admin Drop Down Menu"?

The lazy and the productive will love it : all admin links available in a neat horizontal CSS driven drop down menu. No need to click on \"Manage\" then \"Pages\" to edit pages. And plenty more space on your screen. For documentation, examples, screenshot and a live demo, please refer to the official plugin page for Admin Drop Down Menu.


-Where can I find it?

Here: http://wordpress.org/plugins/ozh-admin-drop-down-menu/


-Hey your plugin is ultra simple, why should I download it?

Well it wasn't made for you... You can just take the code from inside and add it to your functions.php (theme).