=== Gallefrey ===
Contributors: binnyva
Donate link: http://binnyva.com/
Tags: gallery, image, gallifrey
Requires at least: 2.5
Tested up to: 2.8

A image gallery based on the Galleriffic jQuery plugin.

== Description ==

Just insert the gallery as usual and activate this plugin. All the galleries in the site will be changed automatically.

== Installation ==

1. Download the zipped file.
1. Extract and upload the contents of the folder to /wp-contents/plugins/ folder
1. Enable the plugin from Wordpress admin area

== ChangeLog ==

= 1.00.0 =
* Beta release made - as part of the Plugin Week #2.
