Gravity Forms Extended Merge Tags
================================

Enables adding $_COOKIE, $_SERVER and $_SESSION data to a Gravity Form through merge tags
