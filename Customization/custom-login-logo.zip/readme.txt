=== Custom Login Logo ===
Contributors: hchouhan, themeist, dreamsmedia
Donate link: http://themeist.co
Tags: customize, login, login screen, logo, custom logo
Stable tag: 1.0.2
Requires at least: 3.5
Tested up to: 4.2.2
Last Updated: 2014-FEB-17
Plugin Name: Custom Login Logo
Plugin URI: http://www.dreamsonline.net/wordpress-plugins/custom-login-logo/
Author: Harish Chouhan
Author URI: http://www.dreamsonline.net/wordpress-themes/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom Login Logo lets you to add a custom logo in your wordpress login page instead of the usual wordpress logo using built-in media uploader.


== Description ==

You no longer need to copy paste logo path or manually upload logo through FTP. Simply activate the plugin and visit the setting page to use built-in media manager to upload and set a login logo and customize your login page.


Please report any bugs you find via http://www.dreamsonline.net/wordpress-plugins/custom-login-logo/



= My Links =

* Twitter @[harishchouhan](https://twitter.com/dreams_media)
* Google+ [Harish Chouhan](https://plus.google.com/u/0/103138475844539274387/)


If you love the plugin, please consider rating it and clicking on "it works" button.


== Installation ==

1. Upload the directory `/custom-login-logo/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on the Settings link below the plugin name on the plugins page to add your custom logo for the login screen and favicon.



== Frequently Asked Questions ==

Take a look at the [official "Custom Login Logo" FAQ](http://www.dreamsonline.net/wordpress-plugins/custom-login-logo/).

You can also visit the [support center](http://www.dreamsonline.net/wordpress-plugins/custom-login-logo/) and start a discussion if needed.



== Changelog ==

= 1.0.2
* Changed WP_PLUGIN_URL to plugins_url()

= 1.0.1
* Fixed auto width issue by adding width property.

= 1.0.0
* This is the first version