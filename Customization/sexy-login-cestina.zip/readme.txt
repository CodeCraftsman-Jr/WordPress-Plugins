=== Sexy Login čeština ===
Contributors: expres-web
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7F53XKXAB2HSG
Tags: Sexy Login, čeština, Sexy Login čeština,
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Přeloží plugin Sexy Login do češtiny.


== Installation ==

Instalace je velmi jednoduchá

1. Nainstalujte plugin přes administraci v Pluginy.
1. Activujte plugin.

== Screenshots ==
Již brzy

== Frequently Asked Questions ==

Našel jsem chybu, co mám dělat?

Pokud naleznete chybu, sdělte nám to prosím

== Changelog ==

= 1.0 =
Spustění a zveřejnění pluginu.