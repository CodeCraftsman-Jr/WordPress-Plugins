=== Plugin Name ===
Contributors: rlecour
Donate link: http://www.richardsramblings.com/donate/
Tags: comments, posts, nofollow, links, seo
Requires at least: 2.3.1
Tested up to: 4.1.1
Stable tag: 1.00

The Remove-Nofollow plugin removes the "nofollow" attribute.

== Description ==

The simple Remove-Nofollow plugin removes the "nofollow" attribute added by WordPress from links in comments and author URLs.

Visit the plugin homepage for more information, usage, and release notes.

== Installation ==

1. Copy all the files into the "wp-content/plugins/remove-nofollow/" directory.
2. Activate the plugin in the WordPress Plugin Admin panel.

Visit [Richard's Ramblings][rr] for more information and options.

[rr]: http://www.richardsramblings.com/plugins/wp-remove-nofollow/
