=== WordPress Site Condition ===
Contributors: zinger252
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=alisaleem252@gmail.com&currency_code=&amount=&return=&item_name=Donation+for+WP+Condition
Tags: condition, query, counter, developer, debug, memory, footprint, social graph
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Display WordPress Site Condition in Charts for Database Performance, Memory Usage, Peak Memory Usage, Page load time, Average Page load time & Social Performance.

== Description ==

Display Your WordPress Condition in Charts for 
<li>Database Performance, </li>
<li>Memory Usage, </li>
<li>Peak Memory Usage, </li>
<li>Page load time, </li>
<li>Average Page load time, </li>
<li>Social Performance</li>
this is a free Version of WP-Condition a Pro Version will soon be available.
<br />
Pro Verions will also Include:
<li>SEO Performance in detail.</li>
== Installation ==

1. Unzip into your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it :)

== Changelog ==


= 1.0.0 =
* Initial release!