<?php defined( 'WP_UNINSTALL_PLUGIN' ) or exit;

delete_option( 'wpfixit_con_admin_load_times' );
delete_option( 'wpfixit_con_load_times' );
