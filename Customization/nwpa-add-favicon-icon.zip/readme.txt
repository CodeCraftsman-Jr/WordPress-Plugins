=== NWPA Add Favicon Icon ===
Contributors: appstorenwpa
Donate link: http://store.newworldltd.com/
Tags: favicon, icon, nwpa, new world public actions
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin Add favicon.ico to Wordpress.

== Description ==

Thank you for your interest in NWPA Add Favicon Icon.
Plugin Add favicon.ico to Wordpress. 

== Installation ==

This section describes how to install the plugin and get it working.

1. Unpack Plugin.
2. Copy Your favicon.ico to Plugin folder, or use default icon.
3. Upload plugin folder to the /wp-content/plugins/ directory.
4. Activate "NWPA Add Favicon Icon" Plugin.
5. Go to "ADMIN SETTINGS -> NWPA Favicon" 
6. Check ON/OFF to display/hide favicon.ico.

That's all...

== Frequently Asked Questions ==

= No Question =
No answer... :)

== Screenshots ==

No Screenshots... :)

== Changelog ==

= 1.0.0 =
* First version.

== Upgrade Notice ==

= 1.0.0 =
* First version.



