=== exif-filter ===
Tags: images
Contributors: dreamerfi

This is based off the Pictorialis II code from this site:

http://weblogtoolscollection.com/archives/2004/06/14/pictorialis-ii-ready-for-download/


Installation is simple: drop the contents of the plugins folder into your wordpress plugins folder. Activate the plugin from the admin screen.

Here's how it works. When you post an entry on your weblog with one or more images on them, and you want exif info added to the entry, do this:

<img src="/images/url-to-your-picture.jpg">
<!--EXIF:/home/users/htdocs/images/url-to-your-picture.jpg-->

In other words, add a html comment field exactly formatted as I showed here. Note that "/home/users/htdocs/images/url-to-your-picture.jpg" is the full path to the image on disk on your server. If you make this a relative path, make it relative to the plugins directory.

Any questions:

john@sinteur.com
http://weblog.sinteur.com
