== For Translators ==

If you have added your own translation, or have updated an existing one, please send it to me (mail@weweave.net) and I will bundle it into the next release. Thank you!
See http://codex.wordpress.org/I18n_for_WordPress_Developers for further information about i18n.