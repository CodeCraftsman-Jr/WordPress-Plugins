
jQuery( document ).ready(function( $ ){
    jQuery.assignTab();
    jQuery('.nav-vertical > .gtab-content-con').css('min-height',jQuery('.nav-vertical > .gnav').height());
});