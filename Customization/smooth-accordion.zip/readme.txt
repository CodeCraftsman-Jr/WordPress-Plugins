=== Smooth Accordion ===
Contributors: zakirbd63
Tags: smooth, accordion, page, post, nice accordion
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple and easy collapse accordion plugin for post and page. 

== Description ==
Simple and easy collapse accordion plugin for post and page. You can easily insert accordion in your post or page. You don't need to remember the shortcode. Just install and you will find a shortcode button in your WordPress TinyMCE editor.


I am available for Wordpress theme development work. Do you want to start a project with me? Please contact - 
http://zakirinfo.com/contact/

== Installation ==
1. Download the zip file and Install as a regular WordPress plugin.
2. You have to use shortcode for generate accordion in post or page. Example shortcode is given below.
`[sawarp][sawcon title="Here Is Your Title"]Your content goes here....[/sawcon] [sawcon title="Here Is Your Title"]Your content goes here....[/sawcon] [sawcon title="Here Is Your Title"]Your content goes here....[/sawcon][/sawarp]` 

== Screenshots ==
1. Accordion in a page
2. Accordion shortcode button in TinyMCE editor

== Changelog ==

= 1.2 =
= 1.0 =
* Initial release

== Upgrade Notice ==
Now the icon clickable.