=== Genesis Grid ===
Contributors: wpsmith
Plugin URI: http://www.wpsmith.net/genesis-grid
Donate link: http://www.wpsmith.net/donation
Tags: genesis, genesiswp, studiopress, grid, loop, grid loop, gridloop
Requires at least: 3.0
Tested up to: 3.2

This plugin will provide a page template and a GUI for using the Genesis Grid Loop.

== Description ==

Extends the Genesis Grid to a page template. More information coming soon...

IMPORTANT: 
**You must have [Genesis](http://wpsmith.net/get-genesis "Learn more about Genesis") installed. Click [here](http://wpsmith.net/get-genesis "Learn more about Genesis") to learn more about [Genesis](http://wpsmith.net/get-genesis "Learn more about Genesis")**


== Installation ==

1. Upload the entire `genesis-grid` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Copy page-gridblog.php from the plugin to your Child Theme Directory
1. Configure the plugin and upload images via Genesis > Theme Settings

== Frequently Asked Questions ==

= Do you have future plans for this plugin? =
1. Automate the moving of page-gridblog.php to the Child Theme Directory.

== Screenshots ==

None at this time

== Changelog ==

= 0.1 =
* Private Beta

== Special Thanks ==
I owe a huge debt of gratitude to all the folks at [StudioPress](http://wpsmith.net/go/studiopress "StudioPress"), their [themes](http://wpsmith.net/go/spthemes "StudioPress Themes") make life easier.

And thanks to the various individuals who helped me through the beta testing.