=== Theme Reset ===
Contributors: mrwiblog
Donate link: http://www.stillbreathing.co.uk/donate
Tags: reset, theme, multisite
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 4.2
Stable tag: 0.1

Resets the theme for all sites in a MultiSite network.

== Description ==

Resets the theme for all sites in a MultiSite network.

== Installation ==

Just install and activate the plugin as usual. A new menu option can be found under Themes in your network admin menu.

== Frequently Asked Questions ==

Why? The usual reason: I needed it :0)

== Screenshots ==

Sorry, no screenshots yet.

== Upgrade Notice ==

As there's only one version so far there's no need for any upgrade information.

== Changelog ==

= 0.1 =
- Initial Revision
