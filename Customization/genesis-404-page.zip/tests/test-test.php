<?php

/**
 * @group genesis-404-page
 */
class BE_Genesis_404_Test extends BE_Genesis_404_TestCase {
	function test_test() {
		$this->assertTrue( true );
	}
}
