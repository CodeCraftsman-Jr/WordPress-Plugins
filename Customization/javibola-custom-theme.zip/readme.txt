=== JaviBola Custom Theme Test ===
Contributors: JaviBola
Donate link: https://www.paypal.com/es/cgi-bin/webscr?cmd=_flow&SESSION=x5Rs4aJ8oHqdqvQOM7o5vXKHX1TXIwurCeKLKcWLhmFaXPI2rZwfWkMcg48&dispatch=5885d80a13c0db1f8e263663d3faee8d96f000117187ac9edec8a65b311f447e
Tags: admin, custom theme, change, theme, role, administrator, administrador, roles, tema, personalizado, logueado, logged, test, testar, testear, test theme, admin theme, theme test
Requires at least: 3.6
Tested up to: 3.6
Stable tag: 3.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin enables a custom theme when the administrator is logged for a safely testing.

== Description ==

**ENGLISH**

This plugin enables a custom theme when the administrator is logged.
It is very useful for working with a new theme and normal users will not see the changes that are being made.

**SPANISH**

Este plugin habilita un tema específico cuando el administrador está registrado. 
Es muy indicado para trabajar con un tema nuevo y que los usuarios normales no vean las modificaciones que se están realizando.


== Changelog ==

= 2.0.2 =
* Problem with no named themes. // Problema con los temas sin nombre.
= 2.0 =
* New design // Nuevo diseño.
* New features // Nuevas funcionalidades.
= 1.7 =
* Fichero de scripts.
= 1.6 =
* Se ha arreglado la funcionalidad de obtener los temas instalados.

== Screenshots ==

1. Theme selector screen.