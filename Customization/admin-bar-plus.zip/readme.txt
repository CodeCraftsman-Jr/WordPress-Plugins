=== Admin Bar+ ===
Contributors: kosvrouvas, codesigns.gr
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8DH2U6LZZZLBL
Tags: admin, bar, admin bar, front-end, menu, site-name
Requires at least: 3.3
Stable tag: 1.0.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin adds all WordPress pages from the admin sidebar under the "site-name" menu on the front-end.

== Description ==

This plugin adds all WordPress pages from the admin sidebar under the "site-name" menu on the front-end. For now, it also supports RevSlider & Woocommerce (if they are installed)

Feedback is much appreciated & more features will follow.

== Screenshots ==

1. Plugin activated showing the menus with Revolution Slider installed.

== Changelog ==
= 1.0.1 =
- Third party plugin support

= 1.0 =
- Initial release