=== WpCss ===
Contributors: nazmul.hossain.nihal
Tags: css,custom css,wpcss,.css,stylesheet
Requires at least: 3.5 
Tested up to: 4.1.1
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=FYMPLJ69H9EM6

This plugin is for adding custom css

== Description ==

If your theme dosen't give you freedom to add your own css tags then this plugin is best solution for you.Using this plugin you can add your own css codes to your site's frontend,admin panel and login screen.You can attach a .css file also.Using %BLOG_URL% shortcode you can easyly link your css file. 

Using this you can add css to :

*   Home Page 
*   Login Screen
*   Admin Panel


== Installation ==

1. Upload `wpcss` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Then go to the Settings >> Custom Css page to make changes

Note: Don't change "wpcss" directory name

== Screenshots ==

1. Admin Panel

== Upgrade Notice ==

= 1.0 =
* Plugin Created

= 1.1 =
* Code editor added

= 1.2 =
* Bug Fixed

== Changelog ==

= 1.0 =
* Plugin Created

= 1.1 =
* Code editor added

= 1.2 =
* Bug Fixed