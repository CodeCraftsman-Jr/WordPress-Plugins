<?php 
	/******************************
	-Display files are included here
	******************************/
	include("inc/site.php"); // Css For Site
	
	include("inc/login.php"); // Css For Login Screen
	
	include("inc/admin.php"); // Css For Admin Dashboard
?>