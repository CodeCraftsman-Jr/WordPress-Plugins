/**
 * Color picker script for the "Icon Fonts" Wordpress plugin
 */
 
(function() {
	jQuery(document).ready(function($){
    $( '#icon-fonts-color-picker' ).wpColorPicker();
	});
})();