All icons can be viewed at: http://themify.me/themify-icons

LICENSE

- Themify Icons font licensed under: http://scripts.sil.org/OFL
- Code licensed under: http://opensource.org/licenses/mit-license.html
- All brand icons are copyright/trademarks of their respective owners.

VERSIONS

Version 1.0.1 (May 27, 2014)
- Added SVG format
- Fixed some icon naming issues
- Added rss icon

Version 1.0.0 (May 16, 2014)
- Initial release