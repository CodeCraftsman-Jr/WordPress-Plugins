Sosa-Icon-Font-CSS
==================

A CSS file for Sosa Icon Font. 
All the credit for the font goes to Ed Merrit from TenByTwenty (http://www.tenbytwenty.com/sosa.php).
Check out the classes at http://jaicab.github.com/Sosa-Icon-Font-CSS/ or the `index.html` file included.

License
-------
Sosa Icon Font CSS by Jaime Caballero is licensed under a Creative Commons Attribution 3.0 Unported License. http://creativecommons.org/licenses/by/3.0/