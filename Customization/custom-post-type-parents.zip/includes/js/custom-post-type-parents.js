/*! Custom Post Type Parents - v1.0.0
 * http://wordpress.org/plugins/custom-post-type-parents
 * Copyright (c) 2015; * Licensed GPLv2+ */
