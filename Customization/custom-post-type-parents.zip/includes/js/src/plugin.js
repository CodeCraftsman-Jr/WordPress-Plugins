/**
 * Custom Post Type Parents
 * http://wordpress.org/plugins/custom-post-type-parents
 *
 * Copyright (c) 2015 McGuive7
 * Licensed under the GPLv2+ license.
 */
 
( function( window, undefined ) {
	'use strict';


} )( this );