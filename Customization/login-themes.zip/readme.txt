=== login themes ===
Contributors: amin3d
Donate link: http://panateam.ir/salavat/
Tags: login form,themes,customize login form
Requires at least: 3.4
Tested up to: 3.4
Stable tag: 0.1


== Description ==

In the name of Allah,This plugin lets you to chose a theme for login form and change the default to a desire one!


Some features:


* selecting from a list of themes
* compatible with ie7+,chrome,firefox


== Installation ==

You can use the built in installer and upgrader, or you can install the plugin
manually.

1. You can either use the automatic plugin installer or your FTP program to upload it to your wp-content/plugins directory
the top-level folder. Don't just upload all the php files and put them in `/wp-content/plugins/`.
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Visit your login form options
1. select your desire theme and then save it,as soon as it saves it becomes active
1. That's it!

== Frequently Asked Questions ==

== Screenshots ==

1. screenshot-1.png


