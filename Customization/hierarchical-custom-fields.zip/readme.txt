=== Plugin Name ===
Contributors: csand10045
Donate link: http://www.cjsand.com
Tags: Hierarchical, Chain Select, Secondary Category
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 4.3

This plugin will allow a user to add/edit/delete parent and child custom fields within a hierarchical structure.

== Description ==

This plugin will allow a user to add/edit/delete parent and child custom fields within a hierarchical structure.

For example, if each post referred to a type of grant sponsor- you would have the ability to enter different
primary sponsors and then enter and select sub-sponsors within the parent organization.

== Installation ==

1. Upload `hierarchical-custom-fields.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How can I find out more information about the developer? =

www.cjsand.com

== Screenshots ==

No screenshots currently available.

== Changelog ==

= 1.0 =
* First Version

* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.0 =
First Version

`<?php code(); // goes in backticks ?>`
