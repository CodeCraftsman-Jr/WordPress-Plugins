=== Remove Special Characters ===

Contributors: chrdesigner
Donate link: http://www.chrdesigner.com/donate/
Tags: remove, special characters, characters, function

Requires at least: 3.0

Tested up to: 4.0.1

Stable tag: 1.0.0
License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Localizations ==

* English

== Description ==

This plugin will help when you add images with special characters, after activated it will remove all special characters of new images added.

= Language: =

* English (Default)

= Look for all my plugins =

Sign in for see the demos, all my plugins...

Front-end: http://www.chrdesigner.com/demo/

Back-end: http://www.chrdesigner.com/demo/login/

Username: demo - Password: demo

== Installation ==

= Installation =

* Upload the plugin to the wp-content/plugins folder;
* Activate the plugin;

= How to use: =

* Only active the plugin.


== Frequently Asked Questions ==

= 
What is the plugin license?
=

This plugin is licensed under GPL.

== Screenshots ==

1. Plugin Deactivated
2. Plugin Activated

== Changelog ==

= 1.0.0 =

* Initial version of the plugin.

== Upgrade Notice ==

= 1.0.0 =

* Enjoy it.

== License ==

Remove Special Characters is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

Remove Special Characters is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with CodexFree. If not, see <http://www.gnu.org/licenses/>.