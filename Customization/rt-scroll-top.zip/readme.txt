=== Plugin Name ===
Contributors: royaltechbd
Donate link: http://www.royaltechbd.com/donate.html
Tags: jQuery, scroll, scrolltotop, scroll to top
Requires at least: 3.3
Tested up to: 4.2
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin simply add a jQuery Scroll to Top icon to your blog

== Description ==

Very simple Scroll to Top plugin

### Features
* Add scroll to top icon.
* No additional settings required.



### More
* Thank you for using our plugin.
* Vist the [blog post](#) to know more.
* [Give a Rating & Write a Review](#)


== Installation ==

1. Upload the plugin to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently asked questions ==

= Is it need any settings =

No need, Just active this plugin & get a scroll to top icon right bottom.


== Screenshots ==
1. Royal Scroll to Top in action.


== Changelog ==

= 1.0.0 =
* Initial release


== Upgrade notice ==
= 1.0.0 =
It is Initial release