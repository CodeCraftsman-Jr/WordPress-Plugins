=== Karedas Favicons ===
Contributors: Xavier Derrey
Tags: url, favicon, link, posts
Requires at least: 1.5
Tested up to: 9.9
Stable tag: 1.0

Adds corresponding favicon from Google Shared Stuff after every links in your posts.

== Description ==

Add 16x16 favicon after all the links in your posts.
The favicon's <img> tag has a 'favlink' class so you can CSS it as you wish.


== Installation ==

Installation is, as usual :

1. Upload files to your `/wp-content/plugins/` directory (preserve sub-directory structure if applicable)
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Refer to the official plugin page for documentation, usage and tips
