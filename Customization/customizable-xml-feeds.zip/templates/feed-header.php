<?php
header('Content-Type: application/xml; charset=' . get_option('blog_charset'), true);
echo '<?xml version="1.0" encoding="UTF-8" ?>';
?>
<rss>
	<language>en-US</language>
	<channel>