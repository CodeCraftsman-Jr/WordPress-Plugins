=== Plugin Name ===
Contributors: Stemwinder Productions
Donate link: http://stemwinderproductions.com
Tags: templates
Requires at least: 2.0
Tested up to: 2.5
Stable tag: 1.0

Persistent Templates makes your custom templates "persistent", in that all child sub-pages inherit their parent's template setting.

== Description ==

Persistent Templates makes your custom templates "persistent", in that all child sub-pages inherit their parent's template setting. This is a hard override, and any attempt at setting any child's template will be ignored. In future releases, the ability to specify individually different templates for children will be added.

== Installation ==

1. Upload `persistentTemplates.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress