  === Osynlig Localization ===
Contributors: osynligstefan
Requires at least: 3.0.1
Stable tag: 1.0
Tags: translation
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Basic Wordpress plugin that makes it possible to choose different website and admin locales.

== Description ==

Basic Wordpress plugin that makes it possible to choose different website and admin locales.

== Installation ==

1. Download the plugin here (and name it osynlig-localization) or from wordpress.org and put it in your plugins folder. Activate the plugin.
2. Add your website translations to a folder named languages in your current theme. Make sure they are named as the locale. For example sv_SE.mo.
3. Go to "Settings -> Localization" and choose the locale.
4. Done! Your front-end should now display in the locale you choose (don't forget load_theme_textdomain).

== Screenshots ==

== Changelog ==

= 1.0.0 =
* First release
