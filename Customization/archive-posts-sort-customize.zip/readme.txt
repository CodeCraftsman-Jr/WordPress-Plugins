=== Archive Posts Sort Customize ===
Contributors: gqevu6bsiz
Donate link: http://gqevu6bsiz.chicappa.jp/please-donation/?utm_source=wporg&utm_medium=donate&utm_content=apsc&utm_campaign=1_5_1
Tags: home, category, post, posts, tag, archive, sort
Requires at least: 3.6.1
Tested up to: 4.2.2
Stable tag: 1.5.1
License: GPL2

Customize the display order of the list of Archive Posts.

== Description ==

* Home Posts Archive Customize
* Categories Posts Archive Customize
* Tags Posts Archive Customize

These lists to Customization is possible.

== Installation ==

1. Upload the entire archive-posts-sort-customize folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. You will find 'Category Archive Sort Customize' menu in your WordPress admin panel.

== Frequently Asked Questions ==

= A question that someone might have =

= What about foo bar? =

== Screenshots ==

1. Settings Interface
2. Sort support of Custom fields

== Changelog ==

= 1.5.1 =
* Security enhancement: Escape to add_query_arg/remove_query_arg.

= 1.5 =
* Added: Order field of Page Attributes of the Sort Target.
* Added: Ignore words of Post Title order of Sort.

= 1.4 =
* Added: Custon Taxonomies.
* Fixed: Get data mistake when category settings.

= 1.3.1 =
* Fixed: Javascript toggle miss.

= 1.3 =
* Updated: Settings for per Categories.
* Changed: Data version.

= 1.2.4.2 =
* Fixed: Data update way.

= 1.2.4.1 =
* Updated: Screen shots.
* BUg Fixed: Monthly archive link on settings screen.

= 1.2.4 =
* Changed: Data save process.
* Supported: Compatible to 3.8-RC1.
* Added: Customize sort for Monthly archive.
* Bug Fixed: Empty setting when order by is custom field.

= 1.2.3 =
* Added: Last modified of Sort target(orderby).
* Updated: Translations.

= 1.2.2 =
* Support for SSL.
* Check to 3.6.

= 1.2.1 =
* Added a confirmation of Nonce field.

= 1.2 =
* Added Search support.

= 1.1.1 =
* Some translation fixed.

= 1.1 =
Made it possible to sort of home.

= 1.0 =
This is the initial release.

== Upgrade Notice ==

= 1.0 =

== 日本語でのご説明 ==

* ホーム記事一覧
* カテゴリ記事一覧
* タグ記事一覧
* 検索結果一覧

これらのフロントの一覧表示をカスタマイズするプラグインです。
