=== Plugin Name ===
Contributors: opensourcedevelopers2011
Plugin Name: Custom Widget Area
Description: A simple plugin to create custom widget area.
Plugin URI: http://wordpress.opensourcedevelopers.net/downloads/
Tags: Header Widget, Custom Widget, widget
Author URI: http://opensourcedevelopers.net/
Author: Shakti Kumar
Donate link: 
Requires at least: 3.0.1
Tested up to: 3.2.1
Stable tag: Plugin's stable version
Version: 1.1
License: GPLv2 or later

== Description ==
A simple plugin to create custom widget area.  
Simply copy and paste these lines where you want to show custom widget content.  
  
 After installing and activating this plugin, it will create Header Widget Area.  
     Assign any widget in This Header Widget Area Plugin.  
	 
 Simply copy and paste these lines within php tag, where you want to show custom widget content.  
  
 if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Header Widget Area')) : 
 
 endif;
 
 You will need to write some css for it. That's it.

== Installation ==
= How to install Custom Widget Area =
1. Download Custom Widget Area.  
2. Upload it into your plugins directory from Plugin Add Feature or FTP.  
3. It will create a directory /wp-content/plugins/custom-widget-area/  
4. Active Custom Widget Area Plugin.  

After installing and activating this plugin, it will create Header Widget Area.  
     Assign any widget in This Header Widget Area Plugin.  
	 
 Simply copy and paste these lines within php tag, where you want to show custom widget content.  
  
 if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Header Widget Area')) : 
 
 endif;
 
 You will need to write some css for it. That's it.

== Frequently Asked Questions ==
Que. How can we use it in Header Section    
Ans. After installing and activating this plugin, it will create Header Widget Area.  
     Assign any widget in This Header Widget Area Plugin.  
	 
 Simply copy and paste these lines within php tag, where you want to show custom widget content.  
  
 if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Header Widget Area')) : 
 
 endif;
 
 You will need to write some css for it. That's it.

== Changelog ==
No Change Log

== Upgrade Notice ==
It is stable version. Feel free to use.

== Screenshots ==
No Screenshot available


Configuration
-------------


*******************************************************
*******************************************************


Happy Coding...