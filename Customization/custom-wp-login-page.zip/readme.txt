=== Plugin Name ===
Contributors: pankajadhyapak
Tags: wp login,coustom login page
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.0

Allows you to change the default wordpress logo and color on login page.

== Description ==

Allows you to change the default wordpress logo and color on login page.you can add your own photos and even add the coustom color to the login page

Visit [http://www.w3effects.com/wpplugin](http://www.w3effects.com/wpplugin)
== Installation ==
1. Ensure you have latest version of Wordpress installed or atleast 3.0
2. Unzip and upload contents of the plugin to your /wp-content/plugins/ directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==
1. setting page
2.login page


== Configuration ==

1. Visit the  settings page in setting menu.
2. Click upload to upload new image / or select from your media library and  change the color(if you want)
3. Save the changed option or you can reset to the defaults

== Changelog ==

= 1.0 =
* First Public Release.

