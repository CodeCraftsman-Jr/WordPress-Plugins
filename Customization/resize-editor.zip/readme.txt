=== Plugin Name ===
Contributors: s-hiroshi
Tags: editor
Requires at least: 4.2.4
Tested up to: 4.2.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Resize post editor width.

== Description ==

Resize post editor width.


== Installation ==

1. Upload `resize-editor` directory to the `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. set editor width
2. resize post editor width


== Changelog ==

= 1.1.0 =
* Improve security and test up 4.2.4

= 1.0.4 =
* Improve instalation of readme.txt

= 1.0.3 =
* Improve instalation of readme.txt

= 1.0.2 =
* Improve instalation of readme.txt

= 1.0.1 =
* Fix width value is reset by mistake

== Upgrade Notice ==

= 1.0.1 =
* Fix width value is reset by mistake


== Arbitrary section ==

投稿エディタ横幅を指定サイズで表示します。
