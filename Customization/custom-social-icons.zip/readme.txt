=== Custom Social Icons ===
Contributors: bilalnaseer
Donate link: http://websensepro.com/plugins/donation/
Tags: custom social icon,custom social icons,social icon,social icons,social,social share,follow,followus,follow us,share,icon
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.0

Easily upload your own social icon, set your social URL in vertical and horizontal style, no need to code no technical knowledge required.

== Description ==

You can upload your own social icon, set your social URL, choose weather you want to display vertical or horizontal. You can use the shortcode [ws-social-icon] in page/post, template tag for php file <?php if ( function_exists('ws_social_icon') ) echo ws_social_icon(); ?> also you can use the widget "Custom Social Icons" for sidebar.

Initial this plugin dont have icons, you can download it from website below.

Visit http://websensepro.com/custom-social-icons for more information

== Installation ==

1. Download the plugin and extract the files
2. Upload "custom-social-icons" to your wp-content/plugins/ directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Check the "Custom Social Icon" Tab created by this plugins for setup.

== Frequently Asked Questions ==

Question : How to use this plugins?
Ans : Use this shortcode for page/post [ws-social-icon], for php code use this template tag {if ( function_exists('ws_social_icon') ) echo ws_social_icon()} (use php opening and closing tag)

Also you can use the widget for the sidebar.


== Screenshots ==

For complete demo visit http://websensepro.com/custom-social-icons 

== Changelog ==


= 1.0 =
* Initial realease of the plugin