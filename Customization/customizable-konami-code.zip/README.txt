=== Plugin Name ===
Contributors: GraveHeart
Donate link: http://www.guravehaato.info/blog/tenha-o-konami-code-no-seu-blog
Tags: header, konami
Requires at least: 2.0.2
Tested up to: 2.7
Stable tag: 1.0

Inserts the Konami Code on your blog

== Description ==

Inserts the Konami Code on your blog. You can customize the message, the effect and even the code! 

Plugin only in pt_BR, soon I will transtale it. But you can use this version. :)

== Installation ==

Upload the folder to your plugins folder, and activate it. In Settings > Konami Code, you can set your plugin to show messages and load another pages. :)