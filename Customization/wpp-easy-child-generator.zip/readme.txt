===Wpp Easy Child Generator ===

Contributors: Piyushkapoor786
Tags: wordpress, theme, child, child themes, easy, creator, generator,style, parent, clone, copy, configure 
Requires at least: 3.0
Tested up to: 4.2.3
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

wpp easy Child Generator is a sidebar widget that create child theme of your selected theme.Plugins supports the selection of theme and use . You can select you theme and create a child theme of that theme very easily so you can work with that child theme.




= Features =
* Easy to install
* Easy to Use
* Create child theme from parent theme
* works well with all themes



== Installation ==

1. Download the wpp easy child theme Generator  plugin from webplusplus.in/childtheme.zip
2. Simply go under the Plugins page, then click on Add new and select the plugin's .zip file
3. Alternatively you can extract the contents of the zip file directly to your *wp-content/plugins/* folder
4. Finally, just go under Plugins and activate the plugin
5. on dashboard click on Easy Child Creator button 
6. Select You Theme
7. click on generate button
8 go to your theme page, your child theme is there

