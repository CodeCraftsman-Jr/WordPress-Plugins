=== SC Custom Login ===
Contributors: sergiuscosta
Donate link: http://www.sergiocosta.net.br/
Tags: login, custom login, login page, error messages, error message, login error, login logo, login background, login bg, background, logo
Requires at least: 3.2
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple way to customize your login page

== Description ==

= A very simple way to customize your login page =


The plugin injects:


* 	Custom login error messages
*	Custom logo URL
*	Custom logo title attr
*	Custom background (Soon)
*	Custom logo (Soon)
*	Custom Colors (Soon)
*	Custom CSS (Soon)


New features are coming soon!!!

== Installation ==

1. Upload `sc-custom-login` folder to the `/wp-content/plugins/` directory or install into the administrator panel
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Configure through the `SC Custom Login` page into the Administrator panel
1. Enjoy!

== Frequently Asked Questions ==

= How can I see if the plugin is working properly? =

Just check your login page =)

== Screenshots ==

1. No screenshots for now

== Changelog ==

= 1.0 =
* Plugin created

== Upgrade Notice ==

= 1.0 =
* Plugin created