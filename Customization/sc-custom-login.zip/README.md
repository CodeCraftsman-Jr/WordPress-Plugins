# SC Custom Login

### A very simple WordPress plugin to customize your login page

* Custom error mesages
* Custom logo URL
* Custom logo title attr
* Custom background (Soon)
* Custom logo (Soon)
* Custom Colors (Soon)
* Custom CSS (Soon)

### Download from the WordPress plugin repository
[SC Custom Login](https://wordpress.org/plugins/sc-custom-login/)


## License
[![WTFPL](wtfpl-badge.png "WTFPL")](https://github.com/zergiocosta/SC-Custom-Login/blob/master/SCLOGIN_LICENSE)