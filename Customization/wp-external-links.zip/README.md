WP-External-Links
=================

Put it on Github so everybody can contribute code changes.

See http://wordpress.org/plugins/wp-external-links/
