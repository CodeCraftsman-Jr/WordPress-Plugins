<?php

class WP_Customize_Partial_Refresh_Exception extends Exception {}
