=== Scrollbar ===
Contributors: themepoints
Donate link: http://themepoints.com
Tags: scrollbar, custom scrollbar, navigation, scroll, scrollbar, scrollbars, wordpress scrollbar
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Customize your browser scrollbars with unlimited styling and color using scrollbar wp plugin.

== Description ==

Scrollbar wp is fully customizable wordpress scrollbar plugin.You can change scrollbar color, border radius, scroll speed, width, border style & other settings using plugin option page.

### Scrollbar by http://themepoints.com

* [Live demo!&raquo;](http://themepoints.com)



<strong>Plugin Features </strong>

* Unlimited colors.
* CSS3 animation.
* All browser supported
* Custom Width.
* Lightweight Responsive.
* Easy Option Panel.
* Easy Documentation.




== Installation ==

1. Install as regular WordPress plugin.
2. Go your Pluings setting via WordPress Dashboard and activate it.
3. After activate plugin you will see "Scrollbar Wp" menu at left side on WordPress dashboard and find "Scrollbar Option Settings"<br />





== Screenshots ==

1. screenshot-1
2. screenshot-2

== Changelog ==

= 1.0 =
* Support wordpress latest version

= 1.0 =
* Initial release
