=== Tweak Option ===
Contributors: opajaap
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=OpaJaap@OpaJaap.nl&item_name=Tweak-option&item_number=Support-Open-Source&currency_code=USD&lc=US
Tags: developer, options, tweak
Requires at least: 3.0.1
Tested up to: 4.2
Version 1.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is a developers tool to inspect, add, modify and remove entries from the wp options database table.

== Description ==

This plugin is a developers tool to inspect, add, modify and remove entries from the wp options database table.

== Installation ==

1. Activate the plugin through the 'Plugins' menu in WordPress
1. You will find Tweak Option in the **Tools** admin menu.

== Changelog ==
= 1.6 =
* Compatible with WP 3.8
= 1.5 =
* Undo now shows the new option_id correctly
= 1.4 =
* option_id added
* Tested on 3.6
= 1.3 =
* Ajaxified delete with undo option. There is a problem with undoing deleted backslashes, they vanish.
* You can no longer delete "active_plugins".
= 1.2 =
* Arrays are now also updated correctly.
= 1.1 =
* Fix for special characters.
= 1.0 =
* Initial release.
