The favicons folder will hold all favicon.ico files
uploaded through the plugin. In a MultiSite environment the
blog id will append to the file name. "favicon-{blog_ID}.ico"

