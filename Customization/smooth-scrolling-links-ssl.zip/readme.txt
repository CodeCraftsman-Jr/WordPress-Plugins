===Smooth Scroll Links [SSL]===
Contributors: cchetanonline
Donate link: http://www.thechetan.com/smoothscrolllinks/#donate
Tags: post, posts, links, plugin, page, url, smooth, effects, javascript, design, scroll, look, looks, footer
Requires at least: 2
Tested up to: 4.2
Stable tag: 1.1.0

This plugin will give special smooth scroll effect to your **BACK TO TOP**, **TOP TO BOTTOM** like links. It also has capacity to add such links in your Wordpress blog, if they are not present.

== Description ==

This plugin will give special smooth scroll effect to your **BACK TO TOP**, **TOP TO BOTTOM** like links. 
It also has capacity to add such links in your Wordpress blog, if they are not present.

You can special [add smooth scroll effect](http://www.thechetan.com/smoothscrolllinks/) in your blog for page navigation links.

By [Chetan Gole](http://chetangole.com/).

== Installation ==

1. Upload the entire content of plugin archive to your /wp-content/plugins/ directory, so that everything will remain in a /wp-content/plugins/smooth-scrolling-links-ssl/ folder 
2. Remember: DO not change the folder name.
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Go to **Settings** and then **Smooth Scroll Links [SSL]** to configure and enable the effect.
5. Enjoy the UP and DOWN. :)

== Frequently Asked Questions ==

= Why Footer link is not added even after enabling option ? =

Actually your theme doesn't have `<?php wp_footer(); ?>` in footer, so please edit the footer of your theme and insert that code. 
To edit the theme  go to Design >> Theme Editor >> Select "Footer.php" from right hand list >>  and paste `<?php wp_footer(); ?>` just before the '< /body >' tag.
If possible add this code near to Wordpress link. 

= I have problems and questions =

Catch me on [Smooth Scroll Links Homepage](http://www.thechetan.com/smoothscrolllinks/)

== Screenshots ==
1. Configuration page


== Change Log ==
* ver : 1.1.0 : Blog url problem solved when installed in other than "root directory".
* ver : 1.0.0 : SSL Launched.
