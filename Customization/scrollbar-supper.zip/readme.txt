=== Scrollbar Supper ===


Tags: Scroll, scrollbar, custom scrollbar, custom scrollbar wordpress, scrollbar wordpress, awesome scrollbar wordpress, awesome scrollbar, scrollbar item, scrollbar Jquery, how to create scrollbar?, how to set up scrollbar?, how to customize scrollbar?, how to build scrollbar?, how to build scrollbar wordpress?, scrollbars, scrolls, 

Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Scrollbar Supper is awesome, supper flexible wordpress plugin. By installing the plugin you will get eye catching scrollbar in your website.

== Description ==

Scrollbar Supper is a Jquery Scrollbar for wordpress website. The Scrollbar Supper are easy to embed especially document, and have smooth option features. The Scrollbar Supper are portions of your wordpress web page automatically updates itself and also can use easy to customize both business and personal wordpress website.

Please contact with me in my Email address freelencermamunur@gmail.com beside i am available to work for your own website.  

Please see demo URL: http://websitebuilderbd.com/plugins/scrollbar-supper/


== Installation ==

This section describes how to install the plugin and get it working.

Installing the plugins is just like installing other wordpress plugins. If you don't know how to install plugins, please review the two options bellow:

Install by ZIP file


1. From your wordpress dashboard, choose 'add new' under the 'plugins' catagory
2. Select 'upload' from the set of links at the top of the page (The second links) button
3. From here, browse for the zip file include in your plugin purchase titled 'Scrollbar-super.zip' and click the 'install now'
4. Once installation is complete, active the plugin to enable it's features.

Install by FTP

1. Find the directory titled 'Scrollbar-super' and upload it and all files within to the plugins directory of your wordpress install (/WORDPRESS-DIRECTRY/wp-content/plugins/) [e.g.www.yourdomain.com/wp-content/plugins/]
2. Select 'upload' from the set of links at the top of the page (The second links) button
3. From your wordpress dashboard, choose 'add new' under the 'plugins' catagory
4. Locate the newly added plugin and click on the 'active' link to enable it's features


== Frequently Asked Questions ==

=Why the plugin doesn't support for scrollbar? =

If you need to link support for scrollnar, you have to extra charge.

== Screenshots ==

1. Installed in demo server 



== Changelog ==

= 1.0 =

Initial Release