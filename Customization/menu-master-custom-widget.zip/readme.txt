=== Menu Master Custom Widget ===
Contributors: wpcolor
Donate link: 
Tags: 
Requires at least: 3.3.1
Tested up to: 3.4.1
Stable tag: 2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is no longer supported

== Description ==

This plugin is no longer supported