=== Genesis - Comment Title ===
Contributors: Hit Reach
Donate link: 
Tags: Comment Title, Genesis, Genesis Framework, Comments
Requires at least: 2.0
Tested up to: 3.1
Stable tag: 1

Genesis � Comment Title allows you to change the default title on the comments area on WordPress posts and pages.

== Description ==

Genesis � Comment Title allows you to change the default title on the comments area on WordPress posts and pages.

This is done through a dashboard widget.

Please note this plugin requires the Genesis theme framework

== Usage ==

Set your custom reply title in the box added to the WordPress dashboard to instantly update the comment title

== Installation ==

Installation is Quick, just upload the PHP files to a folder within wp-content/plugins and then activate the plugin through the admin dashboard, or find the plugin using the Wordpress plugin search and click install

== Frequently Asked Questions ==

= My Question Is Not Answered Here! =
If your question is not listed here please look on: [http://www.hitreach.co.uk/wordpress-plugins/genesis-comment-title/](http://www.hitreach.co.uk/wordpress-plugins/genesis-comment-title/ "Web Design Arbroath") and if the answer is not listed there, just leave a comment!

== Change Log ==
= 1.0.0 =
Initial Release

== Screenshots ==

== Upgrade Notice ==
