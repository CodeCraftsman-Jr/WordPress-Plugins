<div class="header_image">
	<img src="<?php echo $img_url; ?>" />
</div>