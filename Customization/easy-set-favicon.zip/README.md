Set Fav Icon

Versions: 1.1

Set the fav-icon in your blog or website just by putting a link.
=================================================================================

Authors:

Md. Eftakhairul Islam <eftakhairul@gmail.com> Web: http://eftakhairul.com

Sirajus Salayhin <salayhin@gmail.com> Web: http://salayhin.com



