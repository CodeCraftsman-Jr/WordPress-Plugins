=== Plugin Name ===
Contributors: eftakhairul, salayhin
Donate link:
Tags: fav-icon, icon, easy, plugin, image, png
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Set the fav-icon in your blog or website just by putting a link.

== Description ==

Set the fav-icon in your blog or website just by putting a link.

= Features =
  * Easy and simple.
  * You can make any types of image as your fav-icon in your wordpress website.
  * You can put any link either from website or from media library.

= Author =
Brought to you by [Md. Eftakhairul Islam](http://eftakhairul.com) & [Sirajus Salayhin](https://salayhin.wordpress.com)

= Contribute =
This may have bugs and lack of many features. If you want to contribute on this project, you are more than welcome. Please fork the repository from [Github](https://github.com/eftakhairul/Set-Fav-Icon).

== Installation ==

Just flow the following easy steps..

1. Select any link of image (png or any kind of image) from any website or upload a image to media and take the link from media
2. Click on 'set Fav Icon url' button at admin menu.
3. put that as Fav Icon Url. Click the "Save Changes" button for updating the setting.

== Frequently Asked Questions ==

= Q. Media Link is possible for fav-icon? =
A. Yes, possible. You  can upload image to media. Then, just take link and put that as fav-icon

= Q. Can I put a like from another website? =

A. Yes, you can. You can put any valid link.

= Q. What types of file extension does it support ? =
A. It supports ico, png, jpg, jpeg or other image types.

== Screenshots ==

1. Click the 'Set Fav Icon Url' button at admin menu.
2. Take any link from any website or link from media and put that as Fav Icon Url. Click the "Save Changes" button for updating the setting

== Changelog ==

= 1.1 =
Admin template favicon's support added

= 1.0 =
Initial version released

== Upgrade Notice ==
Nothing here


