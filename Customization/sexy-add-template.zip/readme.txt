=== Plugin Name ===
Contributors: adwordsmogul
Donate link: http://www.adwordsmogul.com/sexy-add-template
Tags: theme editor, appearance, wordpress theme, customize theme, theme
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 1.0

Allows you to easily add extra page templates or css files to your theme.
== Description ==

Sexy Add Template allows you to easily add extra page templates, css or any other file you may desire into your current theme.

It is much more convenient than uploading files via ftp or your site host's web panel.

You can put in the file content before creating it or simply create a blank file.

== Installation ==

1. Upload the content of `sexy-add-template.zip` to the `/wp-content/plugins/` directory

== Frequently Asked Questions ==

= What happens if a file already exist? =

Sexy Add Template will inform you and the file will not be created/

= How can I see the plugin in my WP Admin Menu =

You will see it in your 'Appearance' menu. Simply click on 'Sexy Add Template' and create your file

= Why is this plugin Sexy? =

Because it's so smooth and it's something you've wanted to have for a long, long time.

== Screenshots ==

1. http://www.adwordsmogul.com/wp-content/uploads/2010/10/screenshot-2.png 

== Changelog ==

= 1.0 =
* Original version of the plugin is created

== Upgrade Notice ==

=1.0=
No current upgrades