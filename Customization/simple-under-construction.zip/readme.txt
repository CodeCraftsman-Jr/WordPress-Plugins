﻿=== Simple Under Construction ===
Contributors: shrinitech
Donate link: http://techsini.com/our-wordpress-plugins/simple-under-construction
Tags: under construction, coming soon, coming soon page, under development, website maintenance, maintenance mode
Requires at least: 3.0
Tested up to: 4.2.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Simple under construction adds a mobile friendly, animated under construction page to your website with social media icons.

<strong>Features of Simple Under Construction</strong>
<ul>
<li>Easy to use with minimal options</li>
<li>Animated under construction symbol</li>
<li>Social media icons</li>
</ul>

Check out the live demo of <a href="http://techsini.com/our-wordpress-plugins/simple-under-construction">Simple under construction</a>

<strong>Checkout Our other WordPress Plugins</strong>
<ul>
<li><a href="http://techsini.com/our-wordpress-plugins/fluid-notification-bar/">Fluid Notification Bar</a></li>
<li><a href="http://techsini.com/our-wordpress-plugins/simple-adblock-notice/">Simple Adblock Notice</a></li>
<li><a href="http://techsini.com/our-wordpress-plugins/elegant-subscription-popup/">Elegant Subscription Popup</a></li>
<li><a href="http://masterblogster.com/plugins/disable-right-click/">Disable Right Click</a></li>
<li><a href="http://masterblogster.com/plugins/ads-within-paragraph/">Ads Within Paragraph</a></li>
</ul>

<strong>Credits</strong>

Under construction animation credit http://codepen.io/JoeAnzalone/pen/dAnsb

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

== Screenshots ==
1. Take a look at the live demo of <a href="http://techsini.com/our-wordpress-plugins/simple-under-construction">Simple under construction wordpress plugin</a>

== Changelog ==

= 1.0 =
* Initial release
