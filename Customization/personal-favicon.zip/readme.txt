=== Personal Favicon ===
Author: Dejan Major
Contributors: 
Tags: favicon.ico, Favorit, icon
Requires at least: 3.*
Tested up to: 3.4.1
Version: 2.0
Stable tag: trunk

Personal Favicon is plugin that enable to customize favicon for your Blog.

== Description ==

Personal Favicon is plugin that enable to customize favicon for your Blog.

== Installation ==

1. Upload the folder `personal-favicon` to the `/wp-content/plugins/` directory
2. Activate the plugin `Personal Favicon` through the 'Plugins' menu in WordPress
3. In preferens menu chek setup page and configure favicon url and where to apply change.

Note: if You have some error with header (after upadate) , delete from plugin dir old version file "personal favicon.php" and than enable plugin!

== Changelog ==
= 2.0 =
  Compativility up to 3.4.1 ver.
= 1.3 =
* Compatibility with new version of wordpress 3.0
= 1.2 =
* Added donator list with links as thanks!
= 1.1 =
* Compatibility with new version of wordpress 2.9.1


== Upgrade Notice ==

= 1.3 =
* Compatibility with new version of wordpress 3.0
