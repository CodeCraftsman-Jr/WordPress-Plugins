<?php

/**
 * The response from running a Flag query
 * @author Tyler
 * @package Factual
 * @license Apache 2.0
 */
class FlagResponse extends FactualResponse {


}
?>