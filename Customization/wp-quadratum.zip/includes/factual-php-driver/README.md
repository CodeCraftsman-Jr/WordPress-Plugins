This is the official [PHP driver](https://github.com/Factual/factual-php-driver) for [Factual's API](http://developer.factual.com). It is crafted with artisanal skill from native hardwoods: 

## PHP Documentation

The Factual API is supported at [http://support.factual.com/](http://support.factual.com/); this PHP Driver is supported at [https://github.com/Factual/factual-php-driver/issues](https://github.com/Factual/factual-php-driver/issues)

*    [Getting Started](https://github.com/Factual/factual-php-driver/wiki/Getting-Started)
*    [Factual PHP Driver Documentation](https://github.com/Factual/factual-php-driver/wiki)
*    [Factual REST API Documentation](http://developer.factual.com)
*    [Factual Support](http://support.factual.com)
