=== Plugin Name ===
Contributors: sojweb
Tags: favicon
Requires at least: 2.0
Tested up to: 2.7
Stable tag: 1.0.2

Just a real simple plugin to change the favicon for the admin pages; helpful if you've got a bunch of tabs open in Firefox so you can quickly see which tab is admin and which is not.

== Description ==

* 1.0.2: output <link> tags as XHTML
* 1.0.1: fixes a path problem.

Just a real simple plugin to change the favicon for the admin pages; helpful if you've got a bunch of tabs open in Firefox (or some other browser that displays favicons in the tabs) so you can quickly see which tab is admin and which is not.

The WordPress icon is provided by default. To set your own, just copy it to the plugin folder.

Let me know of any problems: jj56@indiana.edu

== Installation ==

1. Copy the desired favicon to the plugin folder (the WordPress icon is there by default)
1. Upload the `soj-favicon` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

Nothing here yet.

== Screenshots ==

Nothing here yet.