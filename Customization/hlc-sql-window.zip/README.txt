=== Plugin Name ===
Contributors: hlcsoftware
Donate link: http://hlc-software.eu/donation/
Tags: sql, database
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

SQL Window plugin is a really helpfull tool for Administrators and developers. Can execute database commands and return results in a new page.

== Description ==

SQL Window plugin is a powerfull tool to inspect your wordpress database easy and fast.
It should be used by administrators and developers. 
It creates two private pages in your pages section, one for running the sql commands and the other is for getting the data results.
Simple in use with the ability to display any sql command errors.

== Installation ==
1. Download `hlc-sql-window.zip`
2. Upload `hlc-sql-window.zip` to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==
* Nothing yet :)

== Screenshots ==
1. /assets/screenshot-1.png
2. /assets/screenshot-2.png

== Changelog ==

= 1.0 =
* First version

== Upgrade Notice ==
* First version

== Arbitrary section ==
* *** This plugin should be used only from administrators ***
