=== Advanced Custom Fields: W4 Post List Bridge ===
Contributors: pmill
Tags: acf, shortcode, post list, custom post list
Requires at least: 3.0.0
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin provides a [post_field field="field-name"] shortcode connecting an Advanced Custom Fields field to your W4
Post List list template.

== Description ==

This plugin provides a [post_field field="field-name"] shortcode connecting an Advanced Custom Fields field to your W4
Post List list template.

== Installation ==

1. Install Advanced Custom Forms plugin
2. Install W4 Post List plugin
3. Upload `acf-w4-post-list-bridge.php` to the `/wp-content/plugins/` directory
4. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =
* Initial release
