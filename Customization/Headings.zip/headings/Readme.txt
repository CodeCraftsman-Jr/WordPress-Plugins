=== Plugin Name ===



Contributors: Shivendu Madhava

Modified By:Vedant Kumar

Donate link: http://www.technozeast.com/go/donate-wp-plugins-themes/

Modifier Blog: http://www.hackingtools.co.in

Tags: Headings, Style Box

Requires at least: 2.0.2

Tested up to: 3.2.1

Stable tag: 1.1



== Description ==



Make Styled Note box, Alert box, Help box, Tip Box, Important Box and loads of of other boxes in your posts using classes.



== Installation ==



To install the plugin follow these steps :



1. Download the headings.zip file to your local machine.

2. Unzip the file 

3. Upload "headings" folder to the "/wp-content/plugins/" directory

4. Activate the plugin through the 'Plugins' menu in WordPress



That's it.



== Frequently Asked Questions ==



How to use this plugin?



See codes.txt for usage guide

You can also find that info in codex.png



== Screenshots ==



See Screenshot-1.png,screenshot-2.png for preview of all boxes.
See Screenshot-3.png,screenshot-4.png for the appropriate codes.



== Changelog ==



1.0

* It's First Version of Headings Wordpress Plugin



1.1

* We have added two more boxes for those who love to write about Linux and Windows



== Upgrade Notice ==

1.0

Install this plugin to Make Styled Note box, Alert box, Help box, Tip Box, Important Box in your posts using classes.



1.1

Upgrade the plugin from Plugins Options Panel in your admin panel.

Modified By Vedant Kumar - Added 18 More boxes 

Modified By Vedant Kumar - Added option for icon on both sides 