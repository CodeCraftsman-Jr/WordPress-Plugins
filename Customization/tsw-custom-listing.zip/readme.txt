=== TSW Custom Listing Post Type ===
Contributors: larry judd
Tags: post-format
Requires at least: 0.1
Tested up to: 1.0
Stable tag: 1.0
License: GPLv2 or later

TSW custom Listing makes a post type file available for using in Larrys List theme as a custom post type for posting listings to the theme.

== Description ==
Plugin creates a custom post type for WordPress CMS and uses that post for creating, outputting and editing posts as a custom listing article which can be sued currently in the larryslist theme for WordPress by TSW. 
