<?php
$wpsmiliestrans = array(
	':)' => '1.gif',	
	':(' => '2.gif',
	';)' => '3.gif',	
	':D' => '4.gif',
	';;)' => '5.gif',
);