<?php
/**
  *Silence is what?
 **/
?>