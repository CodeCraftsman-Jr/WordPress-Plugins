=== Simple Alert Boxes ===
Contributors: mardojai
Tags: shortcodes, alert, boxes, mensajes, alertas, mensagges
Requires at least: 3.0.1
Tested up to: 4.3.0
Stable tag: 4.3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Use responsives alert boxes with shortcodes.

== Description ==

Use responsives alert boxes with shortcodes.

Is easy, only use the shortcodes.

Example: For a success mensagge use: [alert type="success"]Your text here[/alert], for a info mensagge: [alert type="info"]Your text here[/alert], for a warning mensagge: [alert type="warning"]Your text here[/alert] and for a danger mensagge: [alert type="danger"]Your text here[/alert].

* DEMO HERE: http://www.rafael.mardojai.com/simple-alert-boxes-plugin/
* GITHUB REPOSITORY: https://github.com/mardojai/Simple-Alert-Boxes-Wordpress-Plugin


== Installation ==

1. Download the plugin
2. Upload the plugin directory to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. screenshot-1.png
1. screenshot-2.png

== Changelog ==

= 1.2 =
* TinyMCE Plugin

= 1.1 =
* Optimized Shortcodes
* Support bold, italic, links and more

= 1.0 =
* Responsive Design
* Shortcodes