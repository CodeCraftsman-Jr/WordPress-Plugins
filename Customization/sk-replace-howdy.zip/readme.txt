=== Plugin Name ===
Contributors: wprelief
Donate link: http://spottedkoi.com/
Tags: replace howdy, howdy, introduction, admin, greeting
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 1.0

Allows you to change the greeting message that is at the top of your wp-admin screens

== Description ==

Allows you to change the greeting message that is at the top of your wp-admin screens

== Installation ==

1. Upload the zip file through your plugins->add new screen OR Unzip the archive and upload the sk-replace-howdy directory via FTP to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Navigate to your Settings > General page and enter information in the field labeled 'Replace "Howdy" with:'

== Frequently Asked Questions ==

= What is this plugin for? =

Allows you to change the greeting message that is at the top of your wp-admin screens

== Screenshots ==

1. What your new greeting could look like
2. The field where you change your greeting

== Changelog ==

= 1.0 =
* Plugin created

== Upgrade Notice ==