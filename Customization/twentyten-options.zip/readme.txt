=== TwentyTen Options ===
Contributors: shazdeh
Plugin Name: TwentyTen Options
Tags: twentyten, theme, customizer, options
Requires at least: 3.4
Tested up to: 3.4.1
Stable tag: 0.2

A set of options to customize the TwentyTen theme.

== Description ==

Customize the TwentyTen theme with lots of options:

* Upload a logo image to replace the site title
* Choose from 6 different layouts
* Google Fonts integration
* Change links colors
* Decorate the footer with background


== Installation ==

1. Upload the whole plugin directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Goto Appearance -> Themes and click Customize button and have fun!

== Changelog ==

= 0.2 =
* Removed options page in favor of WordPress Customizer
* Added Google Fonts support