=== Orbisius Blank Slate ===
Contributors: lordspace
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7APYDVPBCSY9A
Tags: wordpress-reset,wordpress,reset,admin,delete,content,bulk,comment,delete,draft,mass,page,Post,Revision
Requires at least: 2.6
Tested up to: 3.5.1
Stable tag: 1.0.1
License: GPLv2 or later

This plugin allows you to delete content from your WordPress site/blog.

== Description ==

= Support =
> Support is handled on our site: <a href="http://club.orbisius.com/" target="_blank" title="[new window]">http://club.orbisius.com/</a>
> Please do NOT use the WordPress forums or other places to seek support.
>
> If you want more features check <a href="http://club.orbisius.com/products/wordpress-plugins/orbisius-blank-slate-pro/" target="_blank" title="[new window]">Orbisius Blank Slate Pro</a>

This plugin allows you to delete (selected) content from your WordPress site/blog.
For example you are testing WordPress and have entered lots of lorem ipsum posts, pages, or attachments
with this plugin you can select what the content to delete it.
When you visit plugin's page (Admin > Tools > Orbisius Blank Slate) you will be shown how many posts, pages, comments, and attachments you currently have.

= Usage =

Go to Admin > Tools > Orbisius Blank Slate then select the content you want to delete and click on the delete button.

= Support =
* Support is handled on our site: <a href="http://club.orbisius.com/support/" target="_blank" title="[new window]">http://club.orbisius.com/support/</a>
* Please do NOT use the WordPress forums or other places to seek support.

= Author =

Do you need an amazing plugin created especially for your needs? Contact me.
Svetoslav Marinov (Slavi) | <a href="http://orbisius.com" title="Custom Web Programming, Web Design, e-commerce, e-store, Wordpress Plugin Development, Facebook and Mobile App Development in Niagara Falls, St. Catharines, Ontario, Canada" target="_blank">Custom Web and Mobile Programming by Orbisius.com</a>

== Upgrade Notice ==
n/a

== Screenshots ==
1. Orbisius Blank Slate in Admin > Plugins
2. Initial Plugin page
3. About to delete content. Showing confirmation popup/alert message.
4. Result messages after the deletion

== Installation ==

1. Unzip the package, and upload `orbisius-blank-slate` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How to use this plugin? =
Just install the plugin and activate it. There is no need to configure anything.

== Changelog ==

= 1.0.0 =
Initial release