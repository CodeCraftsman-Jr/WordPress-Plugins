=== Simpler Editor Styles ===
Contributors: rowbory
Donate link: http://blog.rowbory.co.uk/sw/wordpress
Tags: TinyMCE, editor, CMS, styles
Requires at least: 2.0.2
Tested up to: 3.1
Stable tag: 0.1

Trims the list of formats available in TinyMCE to the ones that are actually helpful for normal editing (that is, not H1, H2 and others that the theme should set).

== Description ==

Trims the list of formats available in TinyMCE to the ones that are actually helpful for normal editing (that is, not H1, H2 and others that the theme should set).

This is very easily customisable, but as of this version the styles recommended are:

* h3
* h4
* p
* sub
* sup
* blockquote

Really it�s only h3 and h4 which are particularly of interest.
