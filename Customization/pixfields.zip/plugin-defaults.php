<?php return array(

	# Hidden fields
	'settings_saved_once' => '0',
	# General

	'display_on_post_types' => array('post' => 'on', 'page' => 'on'),
	'fields_manager' => '',
	'allow_edit_on_post_page' => 1,
	'display_place' => 'template_function'

); # config
