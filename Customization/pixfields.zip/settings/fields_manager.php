<?php

return array(
	'type'    => 'postbox',
	'label'   => 'Fields',
	'options' => array(
		'pixfields_list' => array(
			'label'          => __( 'Manage Fields', 'pixfields_txtd' ),
//			'default'        => true,
			'type'           => 'pixfields',
		),
	)
);