=== Get_Theme ===
Contributors: photozero
Donate link: http://photozero.net/donate
Tags: theme,download
Requires at least: 2.7
Tested up to: 2.7
Stable tag: 1.2.0

Just one click to download the ZIP formatting theme pack from http://wordpress.org/extend/themes/ quickly, and unzip it to your themes folder.


== Description ==

<h3><a href="http://photozero.net/get_theme/">Plugin Homepage</a></h3>

<p> Are you tired of downloading,unziping,uploading,testing...the ZIP file just for a wordpress theme?
 Yes! You need a easy installing themes' plugin.It named Get_Theme!<p>

<p> Now,you only need a theme URL like  
<address>http://wordpress.org/extend/themes/download/dum-dum.1.3.zip</address>
and one click, you can install a theme easily and quickly!<p>

<p>When you installed the plugin, go to WP-admin -> `Appearance` -> `Download Themes`, 
put your theme URL on the form , then click Download. 
While downloaded and unziped , go to WP-admin -> `Appearance` -> `Themes` and activate the theme.<p>
………………………………………………………
<p> 厌烦了从网上下载主题，解压，上传，测试...？ 现在就安装一件安装主题的插件“Get_Theme”<p>

<p> 现在，仅仅需要一个主题的URL，如
<address>http://wordpress.org/extend/themes/download/dum-dum.1.3.zip</address>
和一次点击，就可以轻松安装主题，正如您在后台安装插件一样简单！<p>

<p>安装插件，到 WP-admin -> `外观` -> `下载主题`, 
把主题的URL放在框中，然后点击“下载”. 
下载完成以后，到 WP-admin -> `外观` -> `主题` 启用该主题即可.<p>



== Installation ==

Upload the folder `/get-theme/` to the `/wp-content/plugins/` directory
Activate the plugin through the 'Plugins' menu in WordPress
Go to WP-admin -> `Appearance` -> `Download Themes` and do it.
………………………………………………………
1. 把文件夹 `/get-theme/` 放在 `/wp-content/plugins/` 目录下。
2. 在Wordpress后台启用该插件即可。
3. 在 WP-admin -> `外观` -> `主题` 使用它。

== Screenshots ==

1. screenshot.
2. 截图.