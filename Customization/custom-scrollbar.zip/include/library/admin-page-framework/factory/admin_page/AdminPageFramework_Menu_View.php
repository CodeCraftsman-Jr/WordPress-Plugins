<?php
abstract class CustomScrollbar_AdminPageFramework_Menu_View extends CustomScrollbar_AdminPageFramework_Menu_Model {
}