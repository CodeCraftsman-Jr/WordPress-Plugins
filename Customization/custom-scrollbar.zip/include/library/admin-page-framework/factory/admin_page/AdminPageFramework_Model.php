<?php
abstract class CustomScrollbar_AdminPageFramework_Model extends CustomScrollbar_AdminPageFramework_Menu_Controller {
}