<?php
abstract class CustomScrollbar_AdminPageFramework_HelpPane_Base extends CustomScrollbar_AdminPageFramework_Debug {
    public $oProp;
    public $oUtil;
    protected $_oScreen;
    function __construct($oProp) {
        $this->oProp = $oProp;
        $this->oUtil = new CustomScrollbar_AdminPageFramework_WPUtility;
    }
    protected function _setHelpTab($sID, $sTitle, $aContents, $aSideBarContents = array()) {
        if (empty($aContents)) {
            return;
        }
        $this->_oScreen = isset($this->_oScreen) ? $this->_oScreen : get_current_screen();
        $this->_oScreen->add_help_tab(array('id' => $sID, 'title' => $sTitle, 'content' => implode(PHP_EOL, $aContents),));
        if (!empty($aSideBarContents)) {
            $this->_oScreen->set_help_sidebar(implode(PHP_EOL, $aSideBarContents));
        }
    }
    protected function _formatHelpDescription($sHelpDescription) {
        return "<div class='contextual-help-description'>" . $sHelpDescription . "</div>";
    }
}