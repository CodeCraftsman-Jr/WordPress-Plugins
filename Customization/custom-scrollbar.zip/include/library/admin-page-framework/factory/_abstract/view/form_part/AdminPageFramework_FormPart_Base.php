<?php
abstract class CustomScrollbar_AdminPageFramework_FormPart_Base extends CustomScrollbar_AdminPageFramework_WPUtility {
}