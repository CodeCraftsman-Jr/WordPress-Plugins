<?php
class CustomScrollbar_AdminPageFramework_Format_SubSection extends CustomScrollbar_AdminPageFramework_Format_Base {
    public function __construct() {
    }
    public function get() {
        return array();
    }
}