<?php
abstract class CustomScrollbar_AdminPageFramework_Modifier_Base extends CustomScrollbar_AdminPageFramework_WPUtility {
    public function get() {
        return array();
    }
}