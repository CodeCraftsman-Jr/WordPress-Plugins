<?php
/**
 * Custom Scrollbar
 * 
 * http://en.michaeluno.jp/custom-scrollbar/
 * Copyright (c) 2015 Michael Uno
 * 
 */

/**
 * Provides plugin specific utility methods that uses WordPerss built-in functions.
 *
 * @package     Custom Scrollbar
 * @since        1       
 */
class CustomScrollbar_PluginUtility extends CustomScrollbar_WPUtility {
}