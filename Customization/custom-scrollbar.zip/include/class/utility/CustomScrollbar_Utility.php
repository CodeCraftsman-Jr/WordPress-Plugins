<?php
/**
 * Custom Scrollbar
 * 
 * http://en.michaeluno.jp/custom-scrollbar/
 * Copyright (c) 2015 Michael Uno
 * 
 */

/**
 * Provides utility methods.
 * @since       2
 * @since        1       Changed the name from `CustomScrollbar_Utilities`.
 */
class CustomScrollbar_Utility extends CustomScrollbar_AdminPageFramework_WPUtility {}