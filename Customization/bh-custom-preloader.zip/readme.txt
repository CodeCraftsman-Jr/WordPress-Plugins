﻿=== BH Custom Preloader ===
Contributors: masumbd
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=TAXUBBKCANHLA&lc=US&item_name=bograhost¤cy_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: custom preloader, flat preloader, nice preloader, masum billah, getmasum, preloader, preloader plugin,awesome preloader, beautiful preloader, preloader spinner, flat preloader spinner, nice preloader spinner 
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is BH Custom Preloader  plugin.It will be enable Preloader on your web site. You can change Every things from preloader settings

== Description ==

BH Custom Preloader is a jQuery Custom Preloader for your wordpress website. This plugin will enable awesome custom Preloader.

You can change preloader image, Upload your desire image, preloader body backgrond color,preloader effects, preloader speed & other settings & by using the options of this plugin.
<h3>Features:</h3>

<p>After install, the plugin will add a menu under Settings called "BH Custom Preloader Settings". </p>
		
		<p>In this settings, you can configure images. Lets describe. </p>
		
		<p><strong>Preloader Images</strong></p>
		<p>You can change preloader image here. you will be see many images there, just select any one of these.</p>		
		
		<p><strong>Upload Preloader Images</strong></p>
		<p>You can upload your desire preloader image here. Image size will be maximum width: 200px and maximum height : 200px.</p>
		
		<p><strong>Preloader background color</strong></p>
		<p>You can Select Preloader background color here. Please use px. Example: #ffffff</p>
		
		<p><strong>Preloader Delay time</strong></p>
		<p>You can Select Preloader Delay time here. Only use number. Default value is 350. Example: 350</p>	
		
		<p><strong>Preloader Effects</strong></p>
		<p>Prelaoder Effects has two part. 1.FadeOut - if you select this option in your preloader will active fadeout option. 2.SlideUp - if you select this option in your preloader will active SlideUp option . Default value selected 'fadeout'</p>
		
		<p><strong>Body Delay time</strong></p>
		<p>You can Select Preloader Delay time here. Only use number. Default value is 100. Example: 100</p>
		
		<p><strong>Preloader body Opacity</strong></p>
		<p>You can Select Preloader body Opacity here. Default value is 1. Example: 1</p>
		
		<p><strong>Preloader Fadeout Speed</strong></p>
		<p>You can change Preloader Fadeout Speed here. There are two options for it. Lets learn!</p>
		<ul>
			<li><strong>Fast:</strong> If you select this option, the Preloader will be fadeout fast.</li>	
			<li><strong>Slow:</strong> If you select this option, the Preloader will be fadeout slow.</li>

		</ul>

== Installation ==

1. Upload `bh-custom-preloader` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings menus change option what you want.

== Frequently asked questions ==

= Can i use this Plugin in any version of wordpress ?=

Yes. You can use this in any version of wordpress.

= How i can use this plugin ?=

After install, the plugin will add a menu under Settings called "BH Custom Preloader Settings", from here you can change everythings

== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==

