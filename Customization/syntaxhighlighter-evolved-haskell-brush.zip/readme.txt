﻿=== SyntaxHighlighter Evolved: Haskell Brush ===
Contributors: kuyur
Tags: Haskell, SyntaxHighlight
Requires at least: 2.7
Tested up to: 4.2
Stable tag: trunk

Haskell Brush for SyntaxHighlighter Evolved plugin.

== Description ==

Adds support for the Haskell language to the SyntaxHighlighter Evolved plugin. 
You should install SyntaxHighlighter Evolved first.

Thanks to ArieShout(http://http://arieshout.me) for his shBrushHaskell.js.

Usage:
[hs][/hs]
[hask][/hask]
[haskell][/haskell]

== ChangeLog ==

= Version 1.0.0 =

* Initial release.