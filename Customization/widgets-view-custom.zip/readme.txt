=== WIDGETS VIEW CUSTOM ===
Contributors: gqevu6bsiz
Donate link: http://gqevu6bsiz.chicappa.jp/please-donation/?utm_source=wporg&utm_medium=donate&utm_content=wvc&utm_campaign=1_1_2
Tags: admin, widgets, widget, custom
Requires at least: 3.4.2
Tested up to: 3.5.1
Stable tag: 1.1.2
License: GPL2

Select only the widget you want to use, Customize the widgets list.

== Description ==

This plug-in is a plug-in that Customize the widgets list.
Selected widgets will be is hidden.

== Installation ==

1. Upload the full directory into your wp-content/plugins directory
2. Activate the plugin at the plugin administration page
3. Open the plugin configuration page,
   which is located under Options -> widgets view custom.

== Frequently Asked Questions ==

= A question that someone might have =

= What about foo bar? =

== Screenshots ==

1. Interface in setting
2. While setting
3. Screen widget

== Changelog ==

= 1.2 =
Check of the 3.6 beta 3

= 1.1 =
Add hook that miss.

= 1.1 =
Layout changes.
To be able to quickly reset.

= 1.0.2 =
I've changed the readme.txt.

= 1.0.1 =
Bug fixes translation.

= 1.0 =
This is the initial release.

== Upgrade Notice ==

= 1.0 =

== 日本語でのご説明 ==

このプラグインは、多くなりすぎたウィジェットのなかから、
よく使う必要なウィジェットのみを表示するプラグインです。
あるとちょっと便利なプラグインです。
