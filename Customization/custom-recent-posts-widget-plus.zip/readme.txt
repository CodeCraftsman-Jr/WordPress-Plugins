=== Custom Recent Posts Widget Plus ===
Contributors: javierjara
Tags: widget, category, categories, recent posts, sidebar
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Nice widget it is like the default Recent Posts widget except you can choose a category and in addition show the thumbnails.

== Description ==

This plugin adds a simple widget that you can customize easily it allows you to display a number of recent blog posts from a specific category. You have the options to choose a title, category, number of posts and whether or not to show the post date or to show the image featured (Post Thumbnails).The posts will be ordered by date just like the default Recent Posts widget included with WordPress.
check the category you want to show.

== Installation ==

1. Upload the 'custom-recent-posts-widget-plus' directory to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to the 'Widgets' page found under the 'Appearance' menu item
4. Drag 'Recent Posts Widget Plus' to the target widget area and choose your options

== Screenshots ==

1. The widget UI
2. The widget UI

== Changelog ==

= 1.0 =
* Initial release.