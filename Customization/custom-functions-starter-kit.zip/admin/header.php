<div class="wrap">

	<div class="wpsite_plugin_wrapper">

		<div class="wpsite_plugin_header">
					<!-- ** UPDATE THE UTM LINK BELOW ** -->
					<!--
					<div class="masthead-msg">
						<h2><span class="dashicons dashicons-admin-plugins">&nbsp;</span>
						<?php _e('Visit', self::$text_domain); ?> <strong><?php _e('WPsite.net', self::$text_domain); ?></strong> <?php _e('for more WordPress plugins, resources, and news.', self::$text_domain); ?></h2>
						<a  class="show-me" href="http://www.wpsite.net/?utm_source=plugin-config&utm_medium=announce&amp;utm_campaign=top"><?php _e('Visit WPsite', self::$text_domain); ?></a>
					</div>
					-->
 
					<header class="headercontent">
 
						<div class="head-left">
							<div class="logowrap">
								<a href="http://www.wpsite.net" target="_blank"><h1 class="logo">&nbsp;</h1></a>
							</div>
						</div>
 
						<!-- ** UPDATE THE NAME ** -->
						<div class="head-middle">
							<div class="plugin-info">
								<span class="plugin-name"><?php _e('Custom Functions Starter Kit', self::$text_domain); ?></span>
							</div>
						</div>
 
						<div class="head-right">
							<a class="sqbutton" href="http://www.wpsite.net/plugins?utm_source=plugin-config&amp;utm_medium=headerlink&amp;utm_campaign=top" target="_blank">More Plugins</a>
							<!-- <a class="sqbutton" href="http://www.wpsite.net/themes?utm_source=plugin-config&amp;utm_medium=headerlink&amp;utm_campaign=top" target="_blank">View Themes</a> -->
						</div>
 
					</header>
			</div> <!-- /wpsite_plugin_header -->