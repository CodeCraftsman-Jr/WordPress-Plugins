// Color picker
jQuery(document).ready(function($) {
	$('.color-picker').wpColorPicker();
});