=== Custom Adsense Plugin ===
Author: Umakant Patil
Contributors: Ravi Penna
Tags: Ad-sense
Requires at least: 2.9
Tested up to: 3.0
Stable tag: trunk

The plugin shows Ads on the blog's pages. The Ad is shown only on the listing page of the blogs.

== Description ==

The plugin shows Ads on the blog's pages. The Ad is shown only on the listing page of the blogs.

== Installation ==

1. Upload the .zip file of the plugin to the `/wp-content/plugins/` directory
2. Unzip the plugin contents from the .zip file and then delete the .zip file
3. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How can I use this plugin? =

Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =
* First version

= 1.1 =
* Minor edits

= 1.2 =
* Minor edits

= 1.3 =
* Minor edits

== Upgrade Notice ==

= 1.0 =
Functional code availabe

= 1.1 =
Functional code availabe

= 1.2 =
Functional code availabe

= 1.3 =
Functional code availabe

== Screenshots ==

No screen shots available