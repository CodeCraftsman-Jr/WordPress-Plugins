=== Smart Arrow Shortcodes ===
Contributors: ishan001
Tags: arrows, arrow, format, formatting
Requires at least: 3.0.1
Tested up to: 3.5.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically replace "<-" and "->" with nice arrow symbols in your posts.

== Description ==

If you have a blog that requires giving instructions to users, like moving following Settings &rarr; General, this plugin is for you. Just put [arl] on [arr] in your post and it will replace them with &larr; and &rarr; respectively. 

If you want have any questions or feature requests, please contact us via http://wpblogexperts.com/contact-us

== Installation ==

To install the plugin, download the zip file to your computer, unzip it and upload the AutoFooterCopyright folder to /wp-content/plugins folder