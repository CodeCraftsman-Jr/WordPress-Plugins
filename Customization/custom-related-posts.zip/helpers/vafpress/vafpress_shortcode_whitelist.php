<?php
// No need for any whitelisting for now