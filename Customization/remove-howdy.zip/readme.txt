=== Remove Howdy ===
Contributors: revaultmedia, nickadamstv
Tags: remove howdy, replace howdy, customize dashboard, change howdy, howdy
Requires at least: 3.0
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Remove the "Howdy" text in the top right corner of your dashboard. 

== Description ==

This plugin will remove the "Howdy" text in the top right corner of your dashboard. 

== Installation ==

1. Activate 'Remove Howdy' through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Can I change "Howdy" to something else? =

This plugin only removes "Howdy".  Others can change it.

== Screenshots ==

1. With and without "Howdy"

== Changelog ==

Version 1.0
Plugin removes "Howdy" in the dashboard
