<?php
/*
Plugin Name: Custom Post Type Attachment ( PDF )
Plugin URI: http://avifoujdar.wordpress.com/category/my-wp-plugins/
Description: This plugin will allow you to upload pdf files to your post or pages or any other custom post types. You can either use shortcodes or functions to display attachments. You can upload at most 10 PDF files as attachments. :)
Version: 2.2.0
Author: avimegladon
Author URI: http://avifoujdar.wordpress.com/
*/

/**
	  |||||   
	<(`0_0`)> 	
	()(afo)()
	  ()-()
**/

include_once dirname( __FILE__ ) . '/pdf_attachment.php';
include_once dirname( __FILE__ ) . '/shortcode_function.php';
include_once dirname( __FILE__ ) . '/settings.php';
include_once dirname( __FILE__ ) . '/ap_news.php';