/* 
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */

jQuery( document ).ready( function (){

});
