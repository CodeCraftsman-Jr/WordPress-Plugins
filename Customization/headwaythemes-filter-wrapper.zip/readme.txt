=== headwaythemes-filter-wrapper ===
Contributors: jeannot.muller
Donate link: http://www.ramgad.com/
Tags: headway,headway themes,headwaythemes,wrapper,filters,hooks
Requires at least: 2.5.0
Tested up to: 3.1.1
Stable tag: 1.0.7

Possibility for non-programmers to use some filters through the setting's panel of this plugin. 

== Description ==
Possibility for non-programmers to use some filters through the setting's panel of this plugin. Works only with the headwaythemes.com!

== Installation ==
1. Upload 'headwaythemes-filter-wrapper.php' to the '/wp-content/plugins/headwaythemes-filter-wrapper' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Customize the settings under /Settings/HFW/
4. Have fun, and drop me a comment on <a href="http://www.ramgad.com" target="_blank">ramgad.com</a> if you have any comments, remarks, advices, wishes or if you're just happy.

== Frequently Asked Questions ==
Please read the FAQ <a href="http://www.ramgad.com/software/wordpress/wordpress-plugins/" target="_blank">here</a>.

== Screenshots ==
1. Option panel

== Arbitrary section ==
Written by Jeannot Muller, please feel free to drop me a comment at: <a href="http://www.ramgad.com/software/wordpress/wordpress-plugins/">http://www.ramgad.com/software/wordpress/wordpress-plugins/</a>
