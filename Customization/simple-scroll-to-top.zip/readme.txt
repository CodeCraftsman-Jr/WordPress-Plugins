=== Simple Scroll To Top ===
Contributors: mrvijayakumar
Plugin Site: http://vijayakumar.org/
Tags: Scroll to top, back to top, smooth back to top
Requires at least: 2.8
Tested up to: 4.3
Stable tag: 2.4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is the most efficient way to add smooth scroll to top option in your wordpress blog.

== Description ==
Smooth & simple scroll to top plug & play plugin helps to add "Back to top" in your blog. Activate the plugin & see the result. Nothing to configure.
Note: This is the initial setup. Adding many features in future releases.

Demo: 

1) http://oddanchatram.in/ <br />
2) http://kkeeranur.com/ <br />
3) http://vijayakumar.org/ <br />

== Installation ==

Very easy to install, similar to rest of the plugins.

1. Download and unzip the plugin simple_scroll_top.zip.<br />
2. Copy the unzipped folder in your Plugins directory under wordpress installation. (wp-content/plugins)<br />
3. Activate the plugin through the plugin window in the admin panel.

== Frequently Asked Questions ==


Do you have questions or issues with Simple Scroll To Top? write to me (vijay [at] vijayakumar.org).


== Changelog ==

= 1.0 =
This is the first release. Ask questions in forum, let me fix the issues ASAP.