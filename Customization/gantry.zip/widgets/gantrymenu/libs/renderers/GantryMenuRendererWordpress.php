<?php
/**
 * @version   $Id: GantryMenuRendererWordpress.php 58623 2012-12-15 22:01:32Z btowles $
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2015 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

class GantryMenuRendererWordpress extends RokMenuDefaultRenderer
{
//    public function renderHeader(){
//        parent::renderHeader();
//        $doc = &JFactory::getDocument();
//
//        foreach($this->layout->getScriptFiles() as $script){
//            $doc->addScript($script['relative']);
//        }
//
//        foreach($this->layout->getStyleFiles() as $style){
//            $doc->addStyleSheet($style['relative']);
//        }
//        $doc->addScriptDeclaration($this->layout->getInlineScript());
//        $doc->addStyleDeclaration($this->layout->getInlineStyle());
//    }
}
