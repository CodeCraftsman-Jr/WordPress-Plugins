<?php
/**
 * @version   $Id: CssFileResolver.php 58836 2013-01-15 01:40:58Z btowles $
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2015 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

class Gantry_CssFileResolver extends Gantry_FileResolver
{
	protected $browser_checks = array();
	protected $platform_checks = array();


}
