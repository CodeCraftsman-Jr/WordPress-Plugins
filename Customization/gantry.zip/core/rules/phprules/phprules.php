<?php
	define('PHPRULES_VERSION', '0.5.3');

    require_once('phprules/ActionFassade.class.php');
	require_once('phprules/Fact.class.php');
	require_once('phprules/Rule.class.php');
	require_once('phprules/RuleBase.class.php');
	require_once('phprules/RuleReader.class.php');
	require_once('phprules/RuleSession.class.php');
	require_once('phprules/WorkingMemory.class.php');
 ?>