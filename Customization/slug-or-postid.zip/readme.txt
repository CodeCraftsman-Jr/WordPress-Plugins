=== Slug or PostID ===
Contributors: unimakura
Donate link: 
Tags: Plugin,Post,Slug
Requires at least: 3.1
Tested up to: 3.4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin uses Slug or PostID for PostName. It is done automatically.

== Description ==



== Installation ==

1. Upload `slug-or-postid.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use `%postname%` to permalink through the 'Permalink option' menu in WordPress

== Frequently asked questions ==



== Screenshots ==



== Changelog ==



== Upgrade notice ==



== Arbitrary section ==

If you would like to post from other application for example "windows live writer", you must use to WordPress 3.3 or higher. If you want to use PostId forcibly, please enter "postid" to slug.