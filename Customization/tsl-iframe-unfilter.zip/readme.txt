=== Plugin Name ===
Contributors: osomphane
Donate link: http://www.twoslowlorises.com
Tags: iframe, filter, unfilter
Requires at least: 2.6
Tested up to: 2.9.2
Stable tag: 1.0

A simple plugin that prevents the Tiny MCE editor from removing iframe tags. Wordpress will still block iframes based on privileges.

== Description ==

A simple plugin that prevents the Tiny MCE editor from removing iframe tags. Wordpress will still block iframes based on privileges, so you will need a privileges plugin. Wordpress 3.0 appears to allow iframes for Administrators and Editors by default.

== Installation ==

1. Upload files to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

No questions :)

== Screenshots ==

No sceenshots :(

== Changelog ==

= 1.0 =
* New plugin