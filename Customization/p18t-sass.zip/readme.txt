=== P18T Sass ===
Contributors: p18t
Tags: programmierwerkstatt, p18t, css, stylesheet, stylesheets, sass, scss, phamlp, theme, themes
Requires at least: 3.2
Tested up to: 3.5
Stable tag: 1.0.0

== Description ==

This plugin will enable scss/sass feature of <a href="http://code.google.com/p/phamlp/">PHamlP</a>
 
Related Links:

* <a href="http://programmierwerkstatt.com/plugins/wordpress/p18t-sass/">Plugin Homepage</a>
* <a href="http://code.google.com/p/phamlp/">PHamlP</a>

== Installation ==

1. Upload the full directory into your wp-content/plugins directory
2. Activate the plugin at the plugin administration page
3. Open the plugin configuration page, which is located under Options -> P18T Sass  If you get a permission error, check the file permissions of the specified files.
4. The plugin will automatically update the css file, if Sass/Scss File is changed.

== License ==

New BSD License

== Translations ==

No translations yet.