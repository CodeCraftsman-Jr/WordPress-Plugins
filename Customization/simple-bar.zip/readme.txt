=== Simple Bar ===
Contributors: umarbajwa
Author:umarbajwa
Tags: notify,notification,advertising, announce bar, attention bar, bar, conversion, floating bar, highlight bar, important, mailpoet, message, message bar, notification bar, offer, simple, special offer, Sticky Footer, sticky header, WPML, top notification bar,announcement bar,alert bar,attention bar, floating bar, highlight bar, notification, notification bar,Hello Bar,Bar,simple bar,WP Bar,email subscribe,Bar Plugin,popup,traffic,seo,promotions bar,announcement bar,alert bar,message bar,message,email,subscriber box,notification box,widget,post,admin,shortcode,wp,images,comments,sidebar,google,image,contact form,email form,plugin,twitter,Facebook,
Donate Link : http://web-settler.com/
Requires at least:3.4
Stable Tag: 1.4
Tested up to :4.2
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple Bar plugin is beautifully designed with focus on ease of use,takes only 30 seconds, No developer logo. 

== Description ==

Simple Bar plugin offers simple and user friendly user interface. Customize your own bar via options panel with important features which most of the bar plugins do not offer. 
Responsive , zero coding skills required, fulfill your needs.

> You can add any type of content Ads,Images,HTML,Embed Videos,or even embed contact forms of any Wordpress form plugin with simple short-code and collect leads or let people contact you. This plugin will offer end-less possibilities.

> You should Get the premium Version right now to access all features. <a href="http://web-settler.com/notification-bar/">Get Premium Version</a>


Guaranteed Increase in sales, Conversions and subscribers.

* Provides easy and simple user interface.
* Shortcode Content Supported.
* Call to action Button
* Responsive/Fluid .
* Add CSS Gradients.
* Top & Bottom positioning.
* Enable/Disable  Close button.
* Close Button available at both left and right.
* Add custom html,style, buttons and much more.
* Design your own bar according to your theme.
* No developer logo or water mark.
* Allow you to make your custom bar.
* Most important features included.


> The best way to Increase your sales or conversions <a href="http://web-settler.com/notification-bar/"> Get Premium Version Now</a>



<a href="http://web-settler.com/notification-bar/">Get Premium Version</a>

NOTE : Some features mentioned above are not available in free version you can access them by purchasing premium version.


== Installation ==
* Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

== Screenshots ==

For Screenshots Visit: <a href="http://web-settler.com/notification-bar/">Screen Shots</a>


== Changelog ==

=V.1.2= 

Features added Cookies + Shortcodes Support

