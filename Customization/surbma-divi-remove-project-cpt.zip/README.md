Surbma - Divi Remove Project CPT
===============================

Removes the Project Custom Post Type from Divi theme.