=== Rename default post Labels===
Contributors: AboZain
Donate link: http://unitone.ps
Tags: rename, change, default, post, news, article
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple, lightweight WordPress plugin Rename your Default Post labels to custom name in admin menu

== Description ==
Rename Default Post is a simple plugin gives you the ability to Rename your Default Post label to custom name in admin menu. =

How the plugin works: =
Go to Settings -> Rename default post.

== Installation ==

This section describes how to install the plugin and get it working.
1. Upload `rename-default-post` to the `/wp-content/plugins/` directory =
2. Activate the plugin through the 'Plugins' menu in WordPress =

== Frequently Asked Questions ==

= Where can I find the setting after activate the plugin =

Go to Settings -> Rename default post.



== Screenshots ==

1. This screen shot description the fields you can change the default post labels.

== Changelog ==

= 1.0 =
* First version.
