=== HTML in Author Bio ===
Contributors: itsabhik
Donate link: 
Tags: HTML, bio, description, author, user, admin
Requires at least: 3.0
Tested up to: 3.3
Stable tag: 1.0
Enables the use of HTML formatting in Author Bio

== Description ==
The Plugin stops the stripping of html formatting from the description (bio) field and sanitize content for allowed HTML tags for post content. Once you put this up, you can go and use all the HTML formatting allowed in posts in author�s bio. Pluginized by <a href="http://www.itsabhik.com">Abhik</a>. Add me on Circles on <a href="https://plus.google.com/106671843900352433725?rel=author">Google +</a>.

== Installation ==
1. Upload 'html-in-author-bio' directory to the `/wp-content/plugins/` directory.
2. Activate the plugin in the 'Plugins' menu in WordPress

== Frequently Asked Questions == 
Sorry, no FAQ

== Changelog == 
= 1.0 =
* First Release

== Upgrade Notice ==
= 1.0 =
* First Release

== Screenshots ==
Sorry, no Screenshots