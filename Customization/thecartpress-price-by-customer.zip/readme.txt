=== Price by Customers for TheCartPress eCommerce Shopping Cart ===
Contributors: thecartpress
Tags: price, prices, CartPress, ecommerce, e-commerce, store, shop, shopping, shopping cart, cart, custom post type, taxonomy, taxonomies, ecomerce, products, TheCartPress, html5, Australia
Requires at least: 3.1
Tested up to: 4.3
Stable Tag: 1.1

Adds Prices by Customers to TheCartPress, the eCommerce Shopping Cart plugin for WordPress

== Description ==

Adds Prices by Customers to TheCartPress, the eCommerce plugin for WordPress

= More info and Community =
* [TheCartPress Extend](http://extend.thecartpress.com): plugins, themes and custom development
* [TheCartPress Site](http://thecartpress.com)
* [TheCartPress Community/Support](http://community.thecartpress.com/activity/)
* [TheCartPress Demo](http://demo.thecartpress.com)

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload TheCartpress Price by Customer to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Requirements =

Up to WodPress 3.1

= What is the plugin license? =

This plugin is released under a GPL license.

== Screenshots ==

== Changelog ==
= 1.1 =
* Updated version
* Donation

= 1.0.3 =
* Compatible with TheCartPress 1.2.4

= 1.0.2 =
* Compatible with TheCartPress 1.2

= 1.0.1 =
* Price as initial price

= 1.0.0 =
*First public version.