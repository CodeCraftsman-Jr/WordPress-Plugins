=== Jeba Map Plugin ===
Tags: map, Smart map, awesome map, google map, jeba gmap, easy map plugin, premium map 
Requires at least: 3.0.1
Tested up to: 4.0.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Jeba Smart Map Plugin, super lightweight plugin for your wordpress website using map like premium quality map plugin. 

== Description ==

This is Jeba smart google map wordpress premium quality map plugin. Really the map looking awesome and easy to use. By using [jeba_gmap] shortcode use the map  every where post, page and template.
Demo Link: http://prowpexpert.com/jeba-smart-map-plugin-demo/

Jeba more plugin: https://wordpress.org/plugins/jeba

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use [jeba_gmap] shortcode in template, page, post or in widgets. 
4. If you want use the jeba map plugin in your theme php, Place `<?php echo do_shortcode('[jeba_gmap]'); ?>` in your templates.
5. In the [jeba_gmap] shortcode you can change location="", text="", zoom="", type="", width="", height="" .

Shortcodes

<strong>Use Jeba Map Plugin shortcode</strong>
<pre>[jeba_gmap]</pre>

<strong>Here can change</strong>
<pre>[jeba_gmap location="", text="", zoom="", type="", width="", height=""]</pre>

<strong>A test use</strong>
<pre>[jeba_gmap text="Eta may oder gramer location<br/> Ar beshi kichu jana hoyni.<br/> <a href='mailto:prowpexperts@gmail.com'>Email</a>" location="Bajalia, Chittagong, Bangladesh"]</pre>

== Frequently Asked Questions ==
= How can use location? 
In location="" use your_area, city, country like this location use.



== Screenshots ==

1. How to use shortcode in editor.
2. Another demo.



== Changelog ==

= 1.0 =
* Initial Release