/*
 * A jQuery ui tabs function
 */

jQuery(document).ready(function($) {
	//Create the tabs
	$('#tabs').tabs();

});