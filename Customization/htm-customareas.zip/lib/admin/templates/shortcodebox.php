<?php 
  /*
 * Output the shortcode details
 */
?>
<p>Use this shortcode to embed this post: [HTMCustomAreas id="<?php echo $id;?>"]</p>