jQuery(function($){ 

	/**
	 * Show The Ul inside the FAQ
	 */
	
	$('.wpb_af_area > li > ul > li > ul').show();	

});