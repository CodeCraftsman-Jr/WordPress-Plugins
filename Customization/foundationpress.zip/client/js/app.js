;
(function ($) {
    $(document).ready(function () {
        window.foundation_init($);
        $(document).foundation();
    });
})(jQuery);