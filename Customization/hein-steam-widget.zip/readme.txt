=== Hein-Steam-Widget ===
Contributors: MarcHein
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=MZWA7J43US96G&lc=US&item_name=Marc%20Hein&no_note=1&no_shipping=1&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: steam, widget, video games
Requires at least: 2.8
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A Wordpress widget for displaying your Steam account information and statistics.

== Installation ==

1. Unzip the contents downloaded from the Wordpress plugins page.
2. Upload the extracted folder to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Appearance > Widgets - Drag the 'Xan Mania Steam Widget' into a widget area
5. Apply a custom title (optional) and enter your Steam Profile URL (required).

== Frequently Asked Questions ==

There are now questions at the moment...

== Upgrade Notice ==

At the moment there is nothing to notice...

== Screenshots ==

1. In the image, screenshot-1.png, you can see the Hein-Steam-Widget on a sample site.
2. In the image, screenshot-2.png, you can see the settings of the Hein-Steam-Widget.

== Changelog ==

= 1.0 =
* Initial release
