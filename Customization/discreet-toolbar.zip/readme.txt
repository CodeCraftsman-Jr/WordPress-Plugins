=== Discreet Toolbar ===
Contributors: trepmal
Donate link: http://kaileylampert.com/donate
Tags: toolbar, admin bar
Requires at least: 2.3
Tested up to: 3.5-alpha
Stable tag: 0.3

Hide Toolbar till cursor is near it. Front-end only.

== Description ==

Hide Toolbar till cursor is near it. Front-end only. [screencast demo](http://screencast.com/t/wQFad1nNe)

**Beta!!**

Limited browser and theme testing*. Please report bugs before leaving a bad review.

Find me on [twitter](http://twitter.com/trepmal)

[]()* So far so good, but please report issues (include OS, browser, and theme please)!

== Installation ==

1. Nothing unusual here

== Frequently Asked Questions ==

No questions yet, ask away

== Screenshots ==

1. Now you see it, now you don't

== Upgrade Notice ==

= 0.2 =
Faster animation

= 0.1 =
First!!1!

== Changelog ==

= 0.3 =
* Code improvements
* Verified for 3.5-alpha

= 0.2 =
* Faster animation

= 0.1 =
* First release
