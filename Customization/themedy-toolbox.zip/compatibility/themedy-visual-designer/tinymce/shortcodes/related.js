themedyShortcodeMeta={
	attributes:[
		{
			label:"Limit",
			id:"limit",
			help:"Number of posts to show (default: 5)."
		}
		],
		disablePreview:true,
		defaultContent:"",
		shortcode:"related_posts"
};