themedyShortcodeMeta={
	attributes:[
		{
			label:"Float",
			id:"float",
			help:"Values: none, left, right (default: none).",
			controlType:"select-control", 
			selectValues:['', 'left', 'right'],
			defaultValue: '', 
			defaultText: 'none (Default)'
		}
		],
		defaultContent:"",
		shortcode:"digg"
};