=== Surbma - Twitter Bootstrap 2 ===
Contributors: Surbma
Donate link: http://surbma.com/
Tags: twitter bootstrap, twitter, bootstrap
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 1.5.3
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Use Twitter Bootstrap 2 styles on your site.

== Description ==

Twitter Bootstrap 2 styles.

== Installation ==

1. Upload the `surbma-twitter-bootstrap-2` folder to the `/wp-content/plugins/` directory.
1. Activate the Surbma - Twitter Bootstrap 2 plugin through the 'Plugins' menu in WordPress.
1. That's it. You can now use Twitter Bootstrap 2 styles on your site. (Not all of them!)

== Frequently Asked Questions ==

= What does Surbma mean? =

It is the reverse version of my last name. ;)

== Changelog ==

= 1.5.3 =

- Fix localization.
- Prevent direct access to the plugin.

= 1.5.2 =

- Added pot file for localization
- Fixed $allowedposttags missing global attributes.

= 1.5.1 =

- Changed README.md content.
- Changed readme.txt content.
- First commit to the official WordPress repo.

= 1.5.0 =

- Renamed plugin.
- Added localization.
- Fixed readme.txt content.
- Twitter Bootstrap 2.3.1

= 20120529 =

- First stable version.