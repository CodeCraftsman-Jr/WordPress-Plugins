body {
    background-attachment: fixed !important;
    backface-visibility: visible !important;
    display: block !important;
}

.mb_YTVPlayer {
    transform: inherit;
    transform-style: inherit;
}