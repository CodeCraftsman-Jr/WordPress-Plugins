=== Plugin Name ===
Contributors: obenland, wordpressdotorg
Tags: favicon
Requires at least: 4.2
Tested up to: 4.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

DO NOT USE! Site Icons have been added to WordPress core.

== Description ==

Proof of concept plugin for site icons in the settings screen.

== Installation ==

In your WordPress Admin under Plugins > Add New, search for `wporg-site-icon` and hit install.

== Changelog ==

= 1 =
Initial version.
