=== Plugin Name ===
Contributors: wpexpand
Donate link: http://wpexpand.com/donate
Tags: coming soon, wp coming soon, wp expand coming soon, wordpress coming soon, Maintenance wp, wordpress Maintenance mode, Maintenance mode
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Expand coming soon is an awesome coming soon plugin for wordpress website. 


== Description ==

Expand coming soon enables awesome coming soon feature for your wordpress website. The plugin adds an unique countdown timer too. You can change settings form its settings panel. 

<h2>Main Features</h2>

<ul>
    <li>Lightweight</li>
    <li>Easy installation.</li>
    <li>Countdown timer</li>
    <li>Newsletter feature</li>
    <li>Responsive</li>
</ul>

See live demo here: http://demos.wpexpand.com/?theme=Expand%20Coming%20Soon

== Installation ==

Installing this plugin as regular wordpress plugin. 

After install, you can see a menu, settings > WP Expand coming soon settings. You can change settings form here.

== Screenshots ==

1. Option panel
2. How this will look

== Changelog ==

= 1.0 =
* First Release