=== Headway Donation Block ===
Contributors: ch0cbk0b3ar
Donate link: http://headway101.com/blocks/donation/
Tags: paypal, donate, headway themes, headway blocks
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily add a Paypal donation button anywhere on your headway themes powered website and generate support for your organization or cause.

== Description ==

The "Headway Donation Block" is an add-on block for Headway Themes that lets you easily add a Paypal powered donation button anywhere on your website. The plugin supports all available Paypal currencies and just requires a valid Paypal email to work.
== Installation ==

1. Upload the `headway-donation-block` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Open the Headway Visual Editor in Grid Mode
1. Create a new block and choose "Donation" to add the block to your layouts.

== Frequently Asked Questions ==

= Do you have to have Headway Themes installed to use this plugin? =

Yes. This plugin is built specifically for Headway Themes.