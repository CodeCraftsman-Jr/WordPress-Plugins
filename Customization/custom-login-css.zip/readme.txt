=== Custom Login Css ===

Contributors: graphicedit
Donate link: http://graphicedit.com/ 
Tags: custom login, login page, custom page, header and footer
 
Requires at least: 4.2.2
Tested up to: 4.3 
Stable tag: 1.0.1

Adding the header and footer to your login page.

== Description ==

Designed for users which want to include the header and footer to the login page. You can also change the design. 

Links: [Author Homepage](http://graphicedit.com/)

== Installation ==

This section describes how to install the plugin and get it working.

It can be installed in two ways, firstly by downloading the plugin from the Wordpress directory website or by via the Wordpress admin page for adding a new plugin

Downloading from Wordpress Website

1. Download the plugin from the wordpress plugin directory
2. Unzip the plugin
3. Upload `/custom-login-css/` directory to the `/wp-content/plugins/` directory
4. Activate the plugin through the 'Plugins' menu in WordPress
5. done

Using the Wordpress Admin page for installing

1. Go to the admin page and select the 'Plugins' menu, using the 'Add new' menu item
2. Search for 'Custom Login Css'
3. Select install for the plugin 'Custom Login Css' by graphicedit
4. Activate the plugin through the 'Installing Plugin' page in WordPress
5. done


== Screenshots ==

1. Custom Login Css.


== Changelog ==

= 1.0.0 =
* Initial release