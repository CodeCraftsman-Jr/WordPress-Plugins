=== Lubuntu sidebar lite ===
Contributors: zpop
Donate link: http://zeljko.popivoda.com/donacije
Tags: linux, ubuntu, lubuntu, spreadubuntu, sidebar
Requires at least: 2.0.2
Tested up to: 4.1
Stable tag: 0.1
License: GPLv2

A Lubuntu menu for your website shows Lubuntu networking icons in a un-obtrusive way.

== Description ==

Lubuntu sidebar lite is made to promote Lubuntu.

This plugin is lite version of [Ubuntu sidebar](http://wordpress.org/plugins/ubuntu-sidebar/) without javascript just php, xhtml and css. (Parts of code from [Social sidebar](http://wordpress.org/plugins/social-sidebar) and logo from [Ubuntu pictogram](http://design.ubuntu.com/assets/pictograms) are used for make Lubuntu sidebar.)

Plugin add Lubuntu media buttons to the right side of your website with style and ease.

In serbian at [Željko Popivoda](http://zeljko.popivoda.com/lubuntu-sidebar-lite-wordpress-plugin) blog plugin page.

My other plugins:

* [Ubuntu sidebar](http://wordpress.org/plugins/ubuntu-sidebar/)
* [Ubuntu sidebar lite](http://wordpress.org/plugins/ubuntu-sidebar-lite/)
* [Ubuntu ribbon](http://wordpress.org/plugins/ubuntu-ribbon/)
* [Lubuntu ribbon](http://wordpress.org/plugins/lubuntu-ribbon/)
* [Debian sidebar](http://wordpress.org/plugins/debian-sidebar/)
* [Debian sidebar lite](http://wordpress.org/plugins/debian-sidebar-lite/)
* [Debian ribbon](http://wordpress.org/plugins/debian-ribbon/)

== Installation ==

1. Upload folder `lubuntu-sidebar-lite` in Wordpress plugin directory `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Your done!

== Frequently Asked Questions ==

If you have any questions, ask them on [Željko Popivoda](http://zeljko.popivoda.com/lubuntu-sidebar-lite-wordpress-plugin) blog plugin page.

== Screenshots ==

1. What the plugin looks like once installed on your blog or website.

== Changelog ==

= 0.1 =
* First version.

== Upgrade Notice ==


