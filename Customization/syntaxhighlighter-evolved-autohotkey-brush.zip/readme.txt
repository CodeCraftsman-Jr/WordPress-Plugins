=== SyntaxHighlighter Evolved: Autohotkey Brush ===
Contributors: sytone
Donate link: http://sytone.com/
Tags: syntax, highlight, autohotkey, ahk
Requires at least: 3.1
Tested up to: 3.1.3
Stable tag: trunk

Adds support for the Autohotkey language to the SyntaxHighlighter Evolved plugin.

== Description ==

Adds support for the Autohotkey language to the SyntaxHighlighter Evolved plugin. 

This plugin needs the SyntaxHighlighter Evolved plugin to be installed and it was tested with verion: 3.1.2

Example can be seen at http://www.sytone.com/syntaxhighlighter-evolved-autohotkey-brush/

== Installation ==

1. Create a directory called 'syntaxhighlighter-autohotkey' in the '/wp-content/plugins/' directory.
1. Upload 'syntaxhighlighter-autohotkey.php' and 'shBrushAhk.js' to the '/wp-content/plugins/syntaxhighlighter-autohotkey' directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. Place '[code lang="ahk"] [/code] around the AHK script in your posts.

== Frequently Asked Questions ==

= None Yet! =

So no answer...

== Screenshots ==

1. Example of marked up Ahutohotkey script.

== Changelog ==

= 1.0 =
* First Release.

== Upgrade Notice ==

= 1.0 =
Inital Version.

== Arbitrary section ==

Nothing to see here.


