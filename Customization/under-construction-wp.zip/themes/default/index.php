<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>{Title}</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		{Privacy}
		{Head}
	</head>
<body>
<div id="seed-ucp-page">
<div id="seed-ucp-content">
	{Description}
</div><!-- / #seed-ucp-content -->
</div>
{Credit}
</body>
</html>

<!-- Under Construction by SeedProd. Learn more: http://www.seedprod.com -->
