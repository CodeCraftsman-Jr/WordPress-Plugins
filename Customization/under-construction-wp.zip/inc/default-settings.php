<?php
$seed_ucp_settings_deafults = array (
  'seed_ucp_settings_content' => 'a:5:{s:6:"status";s:1:"0";s:11:"description";s:0:"";s:8:"bg_image";s:0:"";s:13:"footer_credit";s:1:"0";s:11:"custom_html";s:0:"";}',
);