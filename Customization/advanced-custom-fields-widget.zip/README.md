# ACF Widget

A widget that is able to use content from an ACF field group.

## Full documentation & Support

https://www.directbasing.com/resources/wordpress/advanced-custom-fields-widget/