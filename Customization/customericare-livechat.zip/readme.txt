﻿=== CustomerICare live chat ===
Contributors: customericare
Tags: free live chat, free chat for wordpress, free wordpress chat plugin, Chat software for small business, customer help, customer service, customer support, ecommerce, increase sales, live chat, live chat software, live support, livechat, online support, live chat plugin, customericare, convertion, increase, ROI, shopping cart, livechat wordpress, live chat wordpress, live video chat, Chat, tidio, casengo, clickdesk, formilla, user tracking, real time monitoring, sneak peek, chat window, chat box, zopim, olark, snapengage 
Stable tag: 1.0.0
Requires at least: 2.5
Tested up to: 4.2



== Description ==
A **free live chat plugin** built to help small businesses increase their online sales. CustomerIcare is the best live chat solution for small businesses looking to talk to website visitors in order to grow their online sales. And it’s free!

Our WordPress live chat plugin lets you add the chat window to your website in few seconds without any coding knowledge! You will then be able to see who is browsing your website, where they come from, what page they are seeing and proactively invite them to chat.

**- How does it work?**

[youtube https://www.youtube.com/watch?v=xNxQAWJy2-w]

After you install the plugin, click on the CustomerICare icon in your Wordpress Plugin list. It will show „Live Chat”. By clicking on it you will sign into the chat and see people online!

Visit our [WordPress live chat plugin page](https://customericare.com/live-chat-plugin-for-wordpress/) to learn more!

**- Features**

   * One-click installation. Can’t be easier.
   * You can see people browsing your website
   * You can contact hand-picked people on your website
   * Paint it with any color you want
   * Chat in any language you know - it will even work in Chinese!
   * Positionable design - put the chat box left or right
   * Grabbing messages from customers who want to chat when you’re not available
   * Automatically send chat invitations to your most engaged visitors
   * See what customers are typing before they hit send
   * Never loose information thanks to our unlimited chat archives
   * Export chats and users data to CSV files
   * Track conversions and see how much live chat helps you sell


**- Is the free live chat plan free forever?**

Absolutely! We designed our free plan for small businesses who can’t afford a paid solution. You can update to our $10 / month plan anytime if you realize the free plan doesn’t meet your needs anymore.

**- What’s included in the free forever plan?**

All features are included in the free plan with some basic limitations:
   * 1 concurrent chat
   * Default logo on the chat window
   * Archive limits
   * 1 active automatic message
   * 1 operator

**- Supported languages**

   * English
   * Polish
   * Spanish 
   * German
   * French
   * Russian
   * Hebrew

If you want another language for the chat window please contact us on https://customericare.com!

If you like the plugin, please [leave us a review](https://wordpress.org/support/view/plugin-reviews/customericare-livechat) on WordPress!


== Installation ==
Simple instructions, instant Live Chat!

- Log on to your wp-admin
- Click "Plugins", then "Add New"
- Type in „CustomerICare” and click "Search Plugins"
- Download and install the Plugin
- Click on the "Activate Plugin" button
- Scroll down to the ”CustomerICare” icon in the left hand menu
- Open a free CustomerIcare account and then click „Live Chat” to log in

== Screenshots ==

1. The Live Chat window on your website
2. Live video chat with visitors. No extra plugin needed
3. See what customers are doing on your website
4. Chat with customers from around the world

== Changelog ==

= 1.0.0 =
* First plugin version

= 1.0.1 =
* Fix for Wordpress 4.x in admin panel
* Fix function "install plugin" when licence is empty

= 1.0.2 =
* Block button 'Save' in async function to prevent creating multiple licenses

= 1.0.3 =
* Changed success info

= 1.0.4 =
* Sign In - automatic login

= 1.0.5 =
* Create account - automatic login into app

= 1.1.0 =
* One time payment

= 1.1.1 =
* Sign in - submenu

= 1.2.0 =
* Legal form feature, 3x faster app

= 1.2.1 =
* Redirect to monitoring after create new account

= 1.2.2 =
* Add one payment by PayPal

= 1.2.3 =
* End of promotion One time payment

= 1.2.4 =
* Survey after deactivation plugin

== Frequently Asked Questions ==

= Is this plugin really free? = 

Yes! We have a free live chat plan with some limitations and an all-inclusive prestige plan for $10/month/seat. You will get 7 day free on the Prestige plan when you signup and will be downgraded to the free plan afterwards. 

= How do I start? = 

After you install the plugin and create an account you simply log on to app.customericare.com. You can then monitor your website’s visitors and chat with them!

= Why do I need to create a CustomerIcare account? = 

Our WordPress plugin is meant to help you with the installation of the chat window on your website. Since we constantly add new features and improvements to our admin panel, it would be impossible to offer the best experience building a separate WordPress panel. Just check out our external panel and tell us what you think!

= How many agents can I have? = 

Our free plan is limited to 1 agent only. 
You can add as many agents as you want on the paid plan. You will only pay for the « seats » (the number of agents that can log in at the same time)

= Can I change the color of the chat box? = 

Sure you can. Log on to the Settings in your app.customericare.com and choose colors that fit your WordPress website.

= Do I have to use programming to install this live chat plugin? = 

Absolutely not. All it takes is a few clicks in the plugin menu.

= Can I use it on all my Wordpress pages? = 

Yes! Just install the plugin on both of them and use the same account. It will allow you to monitor and chat with visitors from both websites. 

= Can I use my picture or change the logo? = 

You can do that. It’s a simple upload in the CustomerICare app.

= What happens when I’m not online? = 

The chat box turns into a leave a message form where visitors can leave their e-mail and questions.

= Can I use CustomerICare live chat outside of Wordpress? = 

Yes. You can simply add the code into another page. 

= Does it support canned responses? =

Yes. We recently added a feature called Quick Responses for fast answers. Use them by clicking # when chatting.

= Can I translate the chat box? =

Yes! We are rolling out new languages. Currently available include:

- German
- English
- Polish
- Spanish
- Russian
- French

NOTE: We limit the translation feature to paid customers only at the moment but will be rolling out a do-it-yourself translation platform for everyone in the near future.

= Can I see what my visitors are typing? =

Yes you can. We added a feature called Sneak Peek which displays what your visitors are typing before they send it. It's available in the updated version!


= What kind of reporting is available? =

Total chats, Availability, Performance, Queue, Invitations, all possible to filter by Operators and Departments. Live chat reports allow you to always be sure your staff is doing their best to help customers.

= Is it TCPA compliant live chat? =

Yes. Plus you can add a legal form in pre-chat survey configuration.

= How will I receive messages from my customers? =

You can simply start your computer, log on to our app in your browser, and 
mind your own business. The app will notify you when chats arrive.

= How stable is CustomerICare when it comes to uptime? =

We use load balancing to ensure that the software is always fast and reliable.

= Can I temporarily remove it from the website but keep my setup? =

Yes you can. Of course by doing that you lose the chance to meet your customers. Don’t do it! :)

= Do I need any other software? =

No. All you need is a computer with an internet connection.

= Is CustomerICare a new company? =

We started in 2012 so we know the business quite well.

= Which web browsers work best with this plugin? =

Latest versions of IE, Safari, Firefox, Chrome, Opera and others! :)

= Does it work on mobiles? =

Yes. CustomerICare will display with no problem on mobile devices! We are also planning to launch iOS and Android apps very soon. Stay tuned!

== Features Include: ==

== Chat, audio and video conversations ==

Engage in chats on your website. Escalate to a phone call-esque experience or even video to help your customers.

==  Visitor monitoring (with details of visitors) ==

See people browsing your website in real time. You can immediately spot which pages attract the most people.

==  Behavioral targeting of prospects ==

Our chat can automatically find people who need help and invite them into a conversation with you.

==  Automatic and manual chat invitations ==

With the help of chat invitations you’re able to immediately start chats with people on your websites.

==  Statistics ==

Data is the centerpiece of operations. With our solution you will always see the results.

==  Typing sneak peek ==

It’s like predicting the future. You actually get to see what your customers type before they send it. This means you can write your response faster and more accurately.

==  Consultant rating ==

Customers get to rate their experience during chats. This helps in finding the best conversations.

==  Archive of conversations ==

Of course we store every chat and contact, so you can look them up at any time.

==  E-mailing of conversations ==

If your customers want to get a transcript of their chat you can easily send it to them.

==  Integration with CMS systems and Zendesk ==

Integrating is a breeze. There is really no need for coding.

==  Sending files ==

Visitors can send files and documents to chat operators to keep eveyrhing in one place.

==  Multiple chats simultaneously ==

Operators can handle any number of chats at a time. This definitely beats a phone line!

==  Conversation transfers ==

When a chat is handed off to another representative the entire conversation is preserved so the visitor needn’t repeat himself.

==  Away mode for operators ==

Taking a break isn’t a hassle. Operators just change their status and get removed from the chat queue. When they get back they just turn it back on.

==  Goals for ecommerce ==

You can measure how many sales you had thanks to live chat. Automatically.

==  Customization (colors, fields) ==

Make the chat window stand out. Apply your branding and colors to make it fit your website

==  9 Languages ==

The chat allows to change the language it’s being displayed in.

==  After hours messages ==

The chat keeps working for you while your operators are away. It will ask people to leave their contact and message, to which you can get back the next day!

==  Few button types for chat initiation ==

If you don’t like the glued-on-top type of live chat you can always go for the vintage button and pop-up.

==  Departments ==

Sales, support, or maybe IT? No problem. Departments allow you to set up separate chat queues.

==  Admin and consultant levels of account ==

For security reasons you can set up account privileges for Admins and Consultants. This way Admins get to be responsible for the setup and Consultants for chatting.

==  SSL Encryption ==

SSL means your conversations won’t spill all over the internet. It’s secure with us.

== For customers with special requirements: server sided Enterprise version.  ==

By the way - we have a heavy, powerful server-side bundle available. Anybody requiring enhanced security and on-premise data storage can benefit from it.