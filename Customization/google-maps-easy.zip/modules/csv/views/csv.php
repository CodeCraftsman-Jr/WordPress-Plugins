<?php
class csvViewGmp extends viewGmp {
	public function getTabContent() {
		return parent::getContent('csvTabContent');
	}
}