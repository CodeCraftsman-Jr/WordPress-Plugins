<?php /** Template version: 1.0.0 */ ?>

<ul class="cuar-item-list">