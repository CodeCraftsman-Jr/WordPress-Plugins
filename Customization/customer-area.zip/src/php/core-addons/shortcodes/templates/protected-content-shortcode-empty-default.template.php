<?php /** Template version: 1.0.0 */ ?>

<p><?php _e( 'There is no content to show', 'cuar' ); ?></p>