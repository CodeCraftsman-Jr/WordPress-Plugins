<?php /** Template version: 1.0.0 */ ?>

<div class="cuar-content-block">
    <div class="cuar-item-list">