<?php /** Template version: 1.0.0 */ ?>

<p><?php _e( 'You currently have no pages.', 'cuar' ); ?></p>