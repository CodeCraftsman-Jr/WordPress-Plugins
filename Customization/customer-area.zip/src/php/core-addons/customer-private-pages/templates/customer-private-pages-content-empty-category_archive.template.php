<?php /** Template version: 1.0.0 */ ?>

<p><?php _e( 'There are no pages in that category.', 'cuar' ); ?></p>