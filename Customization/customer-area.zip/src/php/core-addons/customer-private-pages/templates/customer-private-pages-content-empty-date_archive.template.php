<?php /** Template version: 1.0.0 */ ?>

<p><?php _e( 'There are no pages for that period.', 'cuar' ); ?></p>