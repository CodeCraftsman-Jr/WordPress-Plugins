<?php /** Template version: 1.0.0 */ ?>

<p><?php _e( 'There are no files for that period.', 'cuar' ); ?></p>