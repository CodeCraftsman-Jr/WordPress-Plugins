<?php /** Template version: 1.0.0 */ ?>

<p><?php _e( 'There are no files in that category.', 'cuar' ); ?></p>