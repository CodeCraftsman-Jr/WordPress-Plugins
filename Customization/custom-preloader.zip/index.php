<?php 
	wp_die( __('Cheating Huuu??, Not Here....') );
?>