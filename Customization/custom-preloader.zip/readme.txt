=== Custom Preloader ===
Contributors: NikosTsolakos
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=MM7GG79LVV4T8
Tags: preloader, custom, image, image loader, image preloader, loader, page preloader, site preloader, colorful background, colorful
Requires at least: 3.x
Tested up to: 4.1.1
Stable tag: 1.4
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Easy and Simple - make your website more cool
== Description ==
### Custom Preloader
Custom Preloader it's a plugin that it shows to you something, and behind that your website is loading. When your website it's ready then Custom Preloader Goes Off
This Plugin it more for Design Reasons! because a few websites are slow to load and they don't look nice.
Custom Preloader Hides your Website and shows something such as an image and when your website it's ready Custom Preloader Goes Off
### The Features
* Set Your color
* Set Your Image
* Set Image Width - Height
* Set Margins Options
* Set Simple Background
* Set ColorFul Background
### Rate This Plugin
* [Rate My Plugin](https://wordpress.org/support/view/plugin-reviews/custom-preloader)
### My Plugins
* [Required Fields](https://wordpress.org/plugins/required-fields/)
### Demo
* Custom Preloader Demo: [CPreloader](https://plugins.nikostsolakos.com/wp-login.php)

### Thanks To
* For The ColorFul Background: [@WebCoreIT](https://www.twitter.com/WebCoreIT)

== Installation ==
1. Extract the `Custom-Preloader` folder to your `wp-content/plugins` directory
2. Activate the plugin through the admin interface

== Frequently Asked Questions ==
= Are there any settings I can adjust?
= Nope, Just install it | Active it and your Ready.
= Can i turn off the plugin anytime i want?
= Sure! you can Deactivate Custom Preloader without lose your settings!= why i can't disable  a tool?= only one tool can be on. ColorFul Background or Simple.
= how can i upload my image?
= you can put the url of image to the "Set Image" field

= how can i change the position of image?
= click to Positions section and play with the margins "left,top,right,bottom"

= What is colorful background?
= ColorFul Background it's a gradient Background. find it in ColorFul Background Section
== Screenshots ==
1. Screenshot For All Settings
2. Screenshot For ColorFul Background Settings
3. Screenshot For Positions Settings
== Upgrade Notice === 1.4 =* FIX IMPORTANT BUGS* Real Preview Edit (Thanks to JQuery & Javascript)= 1.3 =* Set Preview For Plugin
= 1.2 =
* Fix Important Bugs ( ON/OFF Buttons)

= 1.1 =
* Set ColorFul Background
* Fix Bugs
= 1.0 =
* Set Background Color
== Changelog === 1.4 =* FIX IMPORTANT BUGS* Real Preview Edit (Thanks to JQuery & Javascript)= 1.3 =* Set Preview For Plugin= 1.2 =* Fix Important Bugs ( ON/OFF Buttons)

= 1.1 =
* Set ColorFul Background
* Fix Bugs

= 1.0 =
* First stable release