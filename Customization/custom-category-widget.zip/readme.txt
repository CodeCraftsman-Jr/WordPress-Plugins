=== Custom Category Widget ===
Contributors: srsujon
Donate link: http://srsujon.com/donate/
Tags: categories, categories lists, category list, category menu, category, list, custom css widget, custom css category list.
Requires at least: 3.0
Tested up to: 4.2.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin to display categories by a widget. You can insert your categories by IDs and Custom CSS code for them on the same page. 

== Description ==
This is a plugin which will give you facilites for showing your categories at the sidebars of your theme and you can insert your custom 

css code to style them. Maximum Category widgets show categories automatically and you can not exclude any of them if you want. 

By this widget you can insert you category IDs specifically and Custom CSS code to style them at the same time. 

= Widget options =

* Title
* Categories IDs
* Your custom CSS code

Brought to you by [srsujon.com](http://www.srsujon.com) and [srsujon.com](http://srsujon.com)

== Installation ==

1. Upload the entire `simple-seo-categories-posts` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

Please use the support forum of the plugin on wordpress.org

== Screenshots ==

1. Widget admin screenshot.

== Changelog ==

= 1.0 =

== Upgrade Notice ==

= 1.0 =