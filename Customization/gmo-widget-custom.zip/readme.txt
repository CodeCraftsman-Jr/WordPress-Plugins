=== Plugin Name ===

Plugin Name: GMO Widget Custom
Plugin URI: 
Author: GMO WP Cloud
Author URI: https://www.wpcloud.jp/en/
Contributors: Takeaki Nagashima
Donation Link: 
Tags: Widget
Requires at least: 3.8
Tested up to: 4.1.1 
Stable tag: Version 1.1 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This is a useful widget customizer plugin which enables you to insert images, ad and recommendation banners.


== Installation ==

Install and activate a plugin.  Go to Appearance > Widgets and drag and drop a widget to the desired area.
Image size will not exceed the width of the widget area. 


Time required for installation: Approximately 15 seconds.


== Frequently Asked Questions ==

How do I change images? 
-Delete existing image then insert a new one.


== Changelog == 
= 1.1 =
* Updated Author Profile

= 1.0 =
* Initial Release

== Upgrade Notice ==

== Screenshots ==

1. button image

