=== LH Custom Dashboard ===
Contributors: shawfactor
Donate link: http://lhero.org/plugins/lh-custom-dashboard/
Tags: dashboard, custom-dashboard, wordpress-custom-dashboard, wp-admin
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Customise your Wordpress dashboard backend

== Description ==

LH Custom Dashboard plugin changes the left and right footer text and the top left icon in your backed dashboard. More features will added in time.


Features of this plugin:

*  Left and right footer text changed via configuration
*  Remove the WordPress top left icon and replace with an icon of your choice

== Installation ==

1. Upload the entire `lh-custom-dashboard` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to Settings->LH Custom Dashboard and configure the options


== Changelog ==

**1.0 July 13, 2015**  
Initial release.
