=== SiteBuilder Dynamic Components ===
Contributors: sphoid
Donate link: 
Tags: ajax,dynamic,html
Requires at least: 3.0 or higher
Tested up to: 3.5.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a WordPress plugin that automates the injection of dynamic html or javascript into a static page. The idea is to be able to use full page caching on your WordPress site without sacrificing a more dynamic user experience.

== Description ==

This is a WordPress plugin that automates the injection of dynamic html or javascript into a static page. The idea is to be able to use full page caching on your WordPress site without sacrificing a more dynamic user experience. Dynamic content is injected into placeholders using an ajax request that is triggered after the page loads.

Dynamic Components is part of the SiteBuilder suite of plugins designed to unleash the full potential of WordPress as a full Content Management System.

== Installation ==

Copy sb-dynamic-components folder into the 'plugins' folder of your WordPress installation. Activate plugin through the WordPress Admin interface.

== Frequently asked questions ==



== Screenshots ==



== Changelog ==



