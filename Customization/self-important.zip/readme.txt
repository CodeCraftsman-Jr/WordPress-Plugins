=== Self Important ===
Contributors: croakingtoad
Tags: self important, hello dolly fork, top 3
Requires at least: 3.0
Tested up to: 3.0
Stable tag: trunk

This is not just a plugin, it symbolizes the hope and enthusiasm of all WordPress programmers, developers and designers everywhere. When activated you will become one of the three most important people in WordPress.

== Description ==
Do you want to be one of the <a href="http://seoserpent.com/wordpress/self-important">three most important people in WordPress</a> too?

Now you can! Download and activate this plug-in and in your dashboard, you will see the proclamation: "Congratulations! You are now one of the three most important people in WordPress!".

You're only a few steps away. Thanks to Matt Mullenweg for his GPL'd "Hello Dolly" plug-in of which this is a fork. Also thanks 
to Chris Pearson for the inspiration.

== Changelog ==

Version 1.0 
- The first official release of the plugin.


== Installation ==
You can install the plugin from the "Add New" tab under the plugins section of your Wordpress admin. Or, upload the plugin folder to your server and do it the old fashioned way.
