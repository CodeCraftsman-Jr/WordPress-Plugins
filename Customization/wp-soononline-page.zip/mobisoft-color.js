jQuery(document).ready(function($){
    $('.mobicolor-field').wpColorPicker();
});