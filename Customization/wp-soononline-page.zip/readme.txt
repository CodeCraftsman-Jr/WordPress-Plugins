=== WPsoonOnlinePage ===
Contributors: elsteno
Tags: soon online, under construction, construction, security, underconstruction, maintance mode
Requires at least: 3.3
Tested up to: 4.4.2
Stable tag: 1.9
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=62E77MLP4MR34

Creates a Soon Online Page (cooning soon) that is visible by all not logged in wordpress users.

== Description ==

Creates a Soon Online Page (cooning soon) that is visible by all not logged in wordpress users.
It is very useful for new sites that are underconstruction!


== Installation ==

1. Upload the folder to the default wordpress plugin directory \`/wp-content/plugins/\`
2. Activate the plugin through your \'Plugins\' menu in your WordPress installation
3. Click Settings->WP Soon Online Page menu and change the settings as you wish.

== Frequently Asked Questions ==

**I have an idea for your plugin!**
That\'s great. We are always open to your input, and we would like to add anything we think will be useful to a lot of people. Please send your comment/idea to info@mobisoft.gr

**I found a bug!**
Oops. Please send a comment to info@mobisoft.gr and we will try to fix it.
== Screenshots ==
1. The editing screen

== Changelog ==
**1.0**
First version

**1.01**
Added : Upload background image, Option to stretch background image, Option to repeat background image

**1.02**
Fix strech image width problem

**1.03**
Fix 2 bugs

**1.9**
Preparing for new big change realease (2.0)