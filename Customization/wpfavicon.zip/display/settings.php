<?php 
	/******************************
	-Display files are included here
	******************************/
	include("inc/site.php"); // Favicon For Site
	
	include("inc/login.php"); // Favicon For Login Screen
	
	include("inc/admin.php"); // Favicon For Admin Dashboard
?>