=== WPFavicon ===
Contributors: nazmul.hossain.nihal
Tags: favicon,wpfavicons,icon,icons,Nazmul Hossain Nihal,NihalsCode.com,login screen,admin,site
Requires at least: 3.5 
Tested up to: 4.1
Stable tag: 2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=FYMPLJ69H9EM6

This plugin is for adding favicons to WordPress site.

== Description ==

This plugin is for adding favicons to WordPress site.

Using this you can add favicons to :

*   Home Page 
*   Login Screen
*   Admin Panel


== Installation ==

1. Upload `favicon` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Then go to the Settings >> Favicons page to make changes

Note: Don't change "favicon" directory name

== Frequently Asked Questions ==

= Where should I upload the favicons? =

Go to the Media >> Add new and upload your favicons.Then copy the link of the files.After that go to Settings >> Favicons and paste the link of the favicon.

== Screenshots ==

1. A Favicon
2. Admin Panel

== Upgrade Notice ==

= 1.0.1 =
* Admin Page updated
= 1.0.2 =
* Update now!
= 2.0 =
* Shortcodes feature added!Update now!
= 2.1 =
* Language files added.

== Changelog ==

= 1.0 =
* Plugin Created

= 1.0.1 =
* Admin Page updated
= 1.0.2 =
* Admin Page updated
= 2.0 =
* Shortcodes feature added.
= 2.1 =
* Language files added.