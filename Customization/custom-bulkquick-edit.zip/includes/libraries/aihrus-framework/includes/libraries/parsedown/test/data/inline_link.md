[link](http://example.com) and [another link](/tests/)

[`link`](http://example.com)

[![MD Logo](http://parsedown.org/md.png)](http://example.com)

[![MD Logo](http://parsedown.org/md.png) and text](http://example.com)