# TODO Custom Bulk/Quick Edit

Is there something you want done? Write it up on the [support forums](http://wordpress.org/support/plugin/custom-bulkquick-edit) and then [donate](http://aihr.us/about-aihrus/donate/) or [write an awesome testimonial](http://aihr.us/about-aihrus/testimonials/add-testimonial/).

* Abstract bulk/quick edit panel layout
* BUG Multiple checkbox values with [apostrophes](http://stackoverflow.com/questions/6474958/jquery-how-to-escape-quotes) ' not saving
* Support [filter manage_pages_columns](http://codex.wordpress.org/Plugin_API/Filter_Reference/manage_pages_columns)
* Support [filter manage_posts_columns](http://codex.wordpress.org/Plugin_API/Filter_Reference/manage_posts_columns)