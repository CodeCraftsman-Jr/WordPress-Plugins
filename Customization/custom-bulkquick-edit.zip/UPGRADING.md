# Upgrade Notices - Custom Bulk/Quick Edit

## 1.5.0

* Alters option `active_plugins` so that this plugin is among first loaded.

## 1.3.0

* Requires PHP 5.3+ [notice](https://nodedesk.zendesk.com/hc/en-us/articles/202331041)

## 1.1.0

* Please review your settings as some option keys have changed. There's no auto-upgrade at this time.
