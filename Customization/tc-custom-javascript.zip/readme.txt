=== TC Custom JavaScript ===
Contributors: Tiny Code
Tags: custom javascript, javascript editor, custom js, edit js theme
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add custom JavaScript to your site from a professional editor in the WordPress admin.

== Description ==

Add custom JavaScript to your site from a professional editor in the WordPress admin.

<strong>TC Custom JavaScript</strong>'s still in early stage. If you have any troubles when using it, or any ideas to improve its features to fit with your work, please do not hesitate to contact us.

== Installation ==

1. Upload WR PageBuilder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. The back end editor

== Changelog ==

= 1.0 =
The first version.
