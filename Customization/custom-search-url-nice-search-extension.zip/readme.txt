=== Custom Search URL ===
Contributors: markjaquith,markking
Donate link: http://txfx.net/wordpress-plugins/donate
Tags: custom search,search URL, ?s replace,redirect, canonical, search
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin lets you replace default search page syntax "?s" in wordpress search page with the word you choose. 

== Description ==

Extension for Nice Search plugin (http://wordpress.org/extend/plugins/nice-search/) which lets you replace default search page syntax "?s" in wordpress search page with the word you choose.It can be anything(results,downloads,page,topic...etc) 

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently asked questions ==

= A question that someone might have =
Do you offer support?

An answer to that question.
Yes.Contact me.

== Screenshots ==

1. 
2. 

== Changelog ==

* First version 0.1

== Upgrade notice ==



== Arbitrary section 1 ==

