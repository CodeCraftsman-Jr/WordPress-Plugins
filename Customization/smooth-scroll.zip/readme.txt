=== Smooth Scroll ===
Contributors: diennk
Donate link: http://nguyendien.com/
Tags: smooth scroll, scroll
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

By default our browsers have scroll not smooth. It seem lag when mouse wheel.

A plugin was make browser's scroll smoother.

No settings required. Just install plugin and active it then see your scroll bar scroll smoother

== Description ==

== Installation ==

1. Upload `smooth-scroll` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =
* The first release