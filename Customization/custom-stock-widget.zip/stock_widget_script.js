jQuery(document).ready(function(){
	var stock_table=jQuery('.stock_table');
	stock_table.fadeIn('slow');
});
