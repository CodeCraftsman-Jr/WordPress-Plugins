=== Plugin Name ===
Contributors: wpexpand
Donate link: http://wpexpand.com/expand-tabs
Tags: tabs, wpexpand, post tabs, easy tab, easy tabs
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Expand tabs is an easy tabs plugin for your wordpress website. Just use shortcode & see the awesomeness! 


== Description ==



Expand tabs is a jQuery tabs plugin for your wordpress website. This plugin will enable awesome lightweight tabs function.

You can change tabs color, effect, & other settings & by using the shortcode attributes of this plugin.


<h2>Features</h2>

<ul>
    <li>Super easy Installation. </li>
    <li>Unlimited colors. </li>
    <li>Responsive for all devices.</li>
    <li>All Major browser supported. </li>
    <li>Very lightweight.</li>
</ul>

<h3>We also offer premium version</h3>

Premium Version includes
<hr/>

<h4>Tab Category Support</h4>

Using premium version, you can work with tab categories. You can add multiple category & you can embed that easily. 

<h4>Tabs form other custom post</h4>

Do you have exiting custom post type & you want to embed tab form that? Yes, you can do that via premium version

<h4>Multiple tabs in a page</h4>

Using premium version, you can embed multiple tab in one page as your needs, You just have to use multiple shortcode in one page.

<strong>Cool!</strong> you are ready to enable those features in only $5.

Watch demo before purchase. I know you like the demos. Thanks for reading features. Good luck with creating tabs in your wordpress site.

<a href="http://www.wpexpand.com/item/expand-tabs-pro/">Purchase premium version only for $5</a>


== Installation ==

Installing this plugin as regular wordpress plugin.

After install, you are ready to generate tabs in post or page or anywhere by using shortcode. You can add tabs in two ways, 

1. Go on post or page editor, click on Click Expand Tabs Shortcode on tiny mce editor, then you will get shortcode. Now modify with your content.

2. Add some tab content on tabs custom post with a category. You can add multiple tab items in a category. Now go to post of page editor, go to visual editor. Click Expand Tabs Shortcode & Use Tabs form custom post & fill with your information. Now save the post/page & view page. You will see tabs there. 


See some generated shortcode <a href="http://wpexpand.com/plugins/premium-plugins/wp-expand-tabs-pro/">here.</a>


== Screenshots ==

1. Shortcode Generator
2. Tabs Demo

== Changelog ==

= 1.0 =
* First Release