=== Simple WP Maintenance Mode ===
Contributors: lucascaires
Tags: maintenance mode, simple maintenance mode, maintenance, wordpress maintenance, maintance, maintence
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This tiny plugin actives the maintenance mode with standard messages from WordPress.

== Description ==

The Simple WP Maintenance Mode will activate a maintenance page with the standard WP messages.
Just logged-in users with editing template capability will be able to access the website while this plugin is activeted.
There is no need any configuration. Just enable or disable the plugin.

== Installation ==

The quickest method for installing the importer is:

1. Visit Tools -> Import in the WordPress dashboard
1. Click on the WordPress link in the list of importers
1. Click "Install Now"
1. Finally click "Activate Plugin & Run Simple WP Maintenance Mode"

If you would prefer to do things manually then follow these instructions:

1. Upload the `simple-wp-maintenance-mode` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 0.1 =
* First release of the plugin