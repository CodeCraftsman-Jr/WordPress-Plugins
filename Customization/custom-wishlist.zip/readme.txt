=== Custom Wishlist ===
Contributors: alancf
Tags: custom post type, free, wishlist
Requires at least: 4.0
Tested up to: 4.2.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create wishlists with custom post types

== Description ==

Create wishlists with custom post types

== Installation ==

1. Upload free-woocommerce-wishlist to the `/wp-content/plugins/` directory
2. Go to the plugins page and activate the plugin through the 'Plugins' menu in WordPress
3. Use the shortcode [cwl_button] or the code <?php CWL::render_button_wishlist(); ?> to show the "Add to my wishlist" button anywhere you like
4. Use the shortcode [cwl_wishlist] or the code <?php CWL::render_wishlist(); ?> to show the user's wishlist anywhere you like

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

== Upgrade Notice ==
