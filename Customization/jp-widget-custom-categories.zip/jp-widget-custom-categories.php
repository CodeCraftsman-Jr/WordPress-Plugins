<?php

	/*

		Plugin Name: JP Custom Categories
		Plugin URI: http://johannes.jarolim.com
		Description: Zeigt ausgewählte Kategorien an
		Version: 1.0
		Author: J.P.Jarolim <office@jarolim.com>
		Author URI: http://johannes.jarolim.com

	 */

	 /* Short and Sweet */

	 require_once 'lib/jp-widget-custom-categories.class.php';
	 JpWidgetCustomCategories::init();

?>
