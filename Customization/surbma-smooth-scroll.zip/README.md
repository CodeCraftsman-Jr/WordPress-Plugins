Surbma - Smooth Scroll
===============================

A very simple and lightweight smooth scroll plugin.
