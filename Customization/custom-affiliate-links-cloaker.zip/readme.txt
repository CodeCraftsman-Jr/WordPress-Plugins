=== Custom Affiliate Links Cloaker ===

Contributors: Ahmad Alinat, Mousewell
Donate link: http://www.sosasu.fi
Tags: wordpress, Cloacking, Custom Affiliate Links Cloacker
Requires at least: 3.0.0
Tested up to: 3.3.2
Stable tag: 1.4.3.1
 
 This plugin gathers link information via web service and cloaks affiliate links on page

== Description ==
 
 This plugin gathers link information via web service and cloaks affiliate links on page.
 
 Note: you need to set up your own webservice before using this plugin. 

== Installation ==

1. Upload the plugin directory(wp-affliate-cloacker) to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. **options page**

== Changelog ==
 
= 1.4.2.1 =
* Fixed bug causing header 500 error
 
= 1.4.2 =
* Fixed bug with redirection and output buffering
 
= 1.0 =
* First version out
 