jQuery(document).ready(function(){
   jQuery('#wpchandra_custom_scrollbar_bgcolor,#wpchandra_custom_scrollbar_border_color').wpColorPicker();
});
