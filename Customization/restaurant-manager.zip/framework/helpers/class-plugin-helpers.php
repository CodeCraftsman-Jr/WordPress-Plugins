<?php

namespace syntaxthemes\restaurant;

/**
 * Description of class-synth-session
 *
 * @author Ryan Haworth
 */
class plugin_helpers {

    public function __construct() {
        
    }
    
    public function create_new_option($id, $value){
        
       $option = get_option($id, null);       
       
    }

}

?>