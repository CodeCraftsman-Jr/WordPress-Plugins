=== Ubuntu sidebar lite ===
Contributors: zpop
Donate link: http://zeljko.popivoda.com/donacije
Tags: linux, ubuntu, spreadubuntu, sidebar
Requires at least: 2.0.2
Tested up to: 3.9.2
Stable tag: 0.1
License: GPLv2

A Ubuntu menu for your website shows Ubuntu networking icons in a un-obtrusive way.

== Description ==

Ubuntu sidebar lite is made to promote Ubuntu.

This plugin is lite version of [Ubuntu sidebar](http://wordpress.org/plugins/ubuntu-sidebar/) without javascript just php, xhtml and css. (Parts of code from [Social sidebar](http://wordpress.org/plugins/social-sidebar) and logo from [Ubuntu pictogram](http://design.ubuntu.com/assets/pictograms) are used for make Ubuntu sidebar.)

Plugin add Ubuntu media buttons to the right side of your website with style and ease.

In serbian at [Željko Popivoda](http://zeljko.popivoda.com/ubuntu-sidebar-lite-wordpress-plugin) blog plugin page.

My other plugins:

* [Ubuntu sidebar](http://wordpress.org/plugins/ubuntu-sidebar/)
* [Ubuntu ribbon](http://wordpress.org/plugins/ubuntu-ribbon/)
* [Lubuntu ribbon](http://wordpress.org/plugins/lubuntu-ribbon/)
* [Lubuntu sidebar lite](http://wordpress.org/plugins/lubuntu-sidebar-lite/)
* [Debian sidebar](http://wordpress.org/plugins/debian-sidebar/)
* [Debian sidebar lite](http://wordpress.org/plugins/debian-sidebar-lite/)
* [Debian ribbon](http://wordpress.org/plugins/debian-ribbon/)

== Installation ==

1. Upload folder `ubuntu-sidebar-lite` in Wordpress plugin directory `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Your done!

== Frequently Asked Questions ==

If you have any questions, ask them on [Željko Popivoda](http://zeljko.popivoda.com/ubuntu-sidebar-lite-wordpress-plugin) blog plugin page.

== Screenshots ==

1. What the plugin looks like once installed on your blog or website.

== Changelog ==

= 0.1 =
* First version.

== Upgrade Notice ==


