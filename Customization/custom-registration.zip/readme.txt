=== Plugin Name ===
Contributors: burakkaptan
Donate link: http://burak-aydin.com/
Tags: login, registration, custom
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin disable auto-generated registration password and allow users to create own password on registration page.

== Description ==

This plugin disable auto-generated registration password and allow users to create own password on registration page.


== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it. That's it. No need to do anything. 


== Screenshots ==

1. Plugin appearance


== Changelog ==

= 1.0 =
* Initial release