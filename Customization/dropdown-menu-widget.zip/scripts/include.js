// Dom Ready
jQuery(document).ready(function($) {
    // Dropdown menu support for IE
    $('.dropdown li').hover( function(){ $(this).addClass('hover'); }, function(){ $(this).removeClass('hover'); });
	$(".dropdown li:has(ul)").addClass("parent");
	// Add child classes to lists
	$('ul li:first-child').addClass('first-child');	$('ul li:last-child').addClass('last-child');
});