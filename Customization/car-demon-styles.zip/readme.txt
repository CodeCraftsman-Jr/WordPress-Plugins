=== Car Demon Styles ===
Contributors: Jay Mailen, Evan Parsons 
Donate link: http://www.cardemons.com/donate/
Tags: car dealer, automotive, car sales, car lots, auto dealer
Requires at least: 3.4.2
Tested up to: 3.4.2
Stable tag: 1.0.2
License: GPLv2

Car Demon Styles was developed to work with the Car Demon PlugIn and allows you to change the look and feel of vehicle listings and detail pages. It also provides support for several popular themes like Suffusion, Responsive and CatchBox.

== Description ==

Car Demon Styles was developed to work with the Car Demon PlugIn and allows you to change the look and feel of vehicle listings and detail pages. It also provides support for several popular themes like Suffusion, Responsive and CatchBox.

== Installation ==

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==
1.0.2
* Updated price on highway theme
= 1.0.1 =
* Cleaned up styles
* Ran debug and fixed a small group of errors
* Added a few more styles to demo
* Removed blank icons in admin area
= 1.0.0 =
* Initial Public Release, lots of clean up left to do, more styles coming.
* This is a very rough first draft version.

== Upgrade Notice ==
None