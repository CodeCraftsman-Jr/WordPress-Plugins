=== Custom Gravatar ===
Contributors: vtsvang
Tags: gravatar
Requires at least: 2.0.2
Tested up to: 3.0.4
Stable tag: 1.0

Add widget with custom gravatar page

== Description ==

You can add block with your gravatar account information on your site
Supports fields

*   Style from gravatar
*   Name And Surname
*   About Me
*   My Location
*   IMS
*   Accounts
*   Web Pages
*   E-Mails

== Screenshots ==

1. Widget customization