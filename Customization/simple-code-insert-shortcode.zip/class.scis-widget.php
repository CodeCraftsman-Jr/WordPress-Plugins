<?php

class Scis_Widget extends WP_Widget {

}
