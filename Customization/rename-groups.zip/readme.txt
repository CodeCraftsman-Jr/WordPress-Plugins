=== Rename groups ===
Contributors: tpoxa
Donate link: http://tpoxa.com/
Tags: user roles
Requires at least: 2.0.2
Tested up to: 2.9.1
Stable tag: trunk

That plugin provides easy renaming of user roles.

== Description ==

That plugin provides easy renaming of user roles.

== Installation ==


1. Upload `rename_roles.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==


= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. Settings page

== Changelog ==

= 0.1 =
Initial release

== Upgrade Notice ==
= 0.1 =
Initial release