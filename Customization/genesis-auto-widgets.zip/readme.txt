=== Genesis Auto Widgets ===
Contributors: carlomanf
Tags: genesis, widget
Tested up to: 4.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This library of automatically configured and styled widgets is the easiest way to get your new Genesis site to look like the theme demo.

== Description ==

Genesis Auto Widgets is the easiest way to get your new Genesis site to look like the theme demo.

It provides you with widgets that are automatically configured and styled to match the demo of your Genesis theme.

This is NOT an official StudioPress plugin.

= Full List of Widgets =

Altitude Pro:

- Front page widget
- Pricing table widget
- Testimonial widget

Education Pro:

- Home Middle icon widget
- Footer 1 info widget

Parallax Pro:

- Featured area widget
- Pricing table widget

== Changelog ==

= 1.0 =
* Initial release on Bitbucket (private repository)

= 1.1 =
* Initial public release on wordpress.org

= 1.2 =
* Add widgets for Altitude Pro

= 1.3.0 =
* Auto activate widgets based on active theme
