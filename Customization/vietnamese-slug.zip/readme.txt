=== Vietnamese slug ===
Contributors: mcjambi
Tags: nice permalink, nice slug, permalink in vietnamese, vietnamese, vietnamese slug, duong dan tieng viet, tieng viet
Requires at least: 3.0
Tested up to: 4.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.jamviet.com/


This plugin will help you have a nice permalink in Post, category or tag's slug if your blog in Vietnamese, This is the best version than ever !

== Description ==

This plugin will help you have a nice permalink in Post, category or tag's slug if your blog in Vietnamese, This is the best version than ever !
<br />
<br />
If you have any question, or found a bug, please [let me know](http://www.jamviet.com/) !
<br />
<br />
Enjoy ! 
<br />
<br />

Vietnamese: plugin này tự động chuyển tiếng Việt có dấu trong permalink của Post hay Page/category/tag thành không dấu, dễ dàng cho SEO, đặc biệt phiên bản này có thể convert hầu hết tất cả các kí tự Việt Nam cùng các kiểu gõ khác nhau !

== Installation ==
Just unzip plugin and move all of theme to plugins folder inside Wordpress directory, then go to Admin > Plugins to active it, Done !

== Screenshots ==

== Changelog ==
= 1.0 =
First version release !

== Upgrade Notice ==
= 1.0 =
First version release !