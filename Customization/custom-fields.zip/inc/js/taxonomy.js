jQuery(document).ready(function() {
	// Add div for apply WP default style on Visual editor
	jQuery("#edittag table.form-table").wrap('<div id="poststuff" />');
});