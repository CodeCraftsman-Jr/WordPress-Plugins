=== Event Manager Theme Functionality ===
Contributors: billerickson, emjulius
Tags: events, event-manager, functionality
Requires at least: 3.3
Tested up to: 3.3.1
Stable tag: 0.9.2

This plugin contains the core functionality for the Event Manager theme. This allows us to provide ongoing improvements and new features easily without interfering with any of your theme customizations.


== Changelog ==

= 0.9.2 =
* Decrease widget-speakers image size by 1px so widget shows 4 per row

= 0.9.1 =
* Add Connect Widget

= 0.9 =
* Initial release
