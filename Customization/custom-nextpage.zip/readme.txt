=== Custom Nextpage ===

Contributors: Webnist,understandard
Tags: nextpage multipage
Requires at least: 3.6
Tested up to: 4.2.2
Version: 1.1.1
License: GPLv2 or later

MultiPage is a customizable plugin

== Description ==

MultiPage is a customizable plugin.
Can any title on the page.

= Contributors =

* [Webnist](https://profiles.wordpress.org/webnist)
* [understandard](https://profiles.wordpress.org/understandard/)

== Installation ==

* A plug-in installation screen is displayed on the WordPress admin panel.
* It installs it in `wp-content/plugins`.
* The plug-in is made effective.
* Open \'Settings\' -> \'Custom Nextpage\' menu.

== Screenshots ==

1. Short code insertion button
2. Title insertion form
3. It looks after you insert
4. Next page appearance

== Frequently Asked Questions ==

Automatically replace the wp_link_pages. To check?
Or the  Please insert a template.

`<?php if ( function_exists( 'custom_next_page_link_pages' ) ) : custom_next_page_link_pages(); endif; ?>`

== Changelog ==

= 1.1.1 =
Fixed bug: Quicktags

= 1.1.0 =
Add Grouping multiple pages

= 1.0.6 =
Fixed bug: Change WP_PLUGIN_URL to WP_PLUGIN_DIR for file_get_contents

= 1.0.5 =
Fixed bug: Processing was enclosed in tags.

= 1.0.4 =
ja languages file update

= 1.0.3 =
Fixed bug: cannot save

= 1.0.2 =
Clean style sheet

= 1.0.1 =
Add Reset CSS button

= 1.0.0 =
Add CSS Edit

= 0.9.10 =
Fix

= 0.9.9 =
Add First page link
Add Last page link
Add Link display options

= 0.9.8 =
Class adjustment

= 0.9.5 =
The first release.
