=== Simple Reverse Comments ===
Contributors: Sudar 
Donate link:http://sudarmuthu.com
Tags: comment, theme, template, reverse
Requires at least: 2.0
Tested up to: 2.5.1
Stable tag: 0.1
	
Displays the comments in reverse order. 
	
== Description ==

Simple Reverse Comments is a WordPress Plugin, which can be used to reverse the order in which the comments are shown in a WordPress blog, without modifying the theme.

You can also find out what really [motivated me to write this Plugin at my blog][1].

 [1]: http://sudarmuthu.com/blog/2008/02/09/reverse-the-order-of-comments-without-editing-theme.html
	
== Installation ==

Upload the file to your WordPress Plugin directory and then activate it from the Plugins page.
