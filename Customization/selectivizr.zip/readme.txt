=== Plugin Name ===
Contributors: Ramoonus
Donate link: http://www.ramoonus.nl/donate/
Tags: html5, javascript, internet explorer, css3, selectivizr
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 2.0.3.1

selectivizr is a JavaScript utility that emulates CSS3 pseudo-classes and attribute selectors in Internet Explorer 6-8. 

== Description ==
selectivizr is a JavaScript utility that emulates CSS3 pseudo-classes and attribute selectors in Internet Explorer 6-8. Simply include the script in your pages and selectivizr will do the rest.

== Installation ==
1. Upload `selectivizr.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions == 
None at this moment.

== Upgrade Notice == 
Its recommended to flush the cache after upgrading.

== Screenshots ==
Not relevant.

== Changelog ==
= 2.0.3.1 =
* Bugfix, bug present since 2.0.2

= 2.0.3 =
* Updated Selectivizr to 1.0.3b

= 2.0.2 =
* Recoded the plugin

= 1.0.3 = 
* Added improved browser caching

= 1.0.2 =
* Updated Selectivizr to 1.0.2 ... javascript plugin and wordpress plugin version are now equal

= 1.0.1 =
* Fixes the JS loading bug.

= 1.0 =
* First version, based on Selectivizr 1.0.1