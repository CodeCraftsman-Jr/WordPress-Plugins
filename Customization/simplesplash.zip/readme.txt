=== SimpleSplash ===
Contributors: Thomas Lass
Tags: splash
Requires at least: 2.8
Tested up to: 3.0.1
Stable tag: 0.2.1


== Description ==

Shows a SplashScreen to visitors who enter the websites in their Browser or come from another site by referer. The SplashScreen appears only at the frontpage.

== Installation ==

1. Upload the entire 'simplesplash' folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

After that, you will get a SplashScreen, when you visit the frontpage of your website and the referersite does not belong to your website.
You can change the SplashScreen by create a new 'splash.php' file in your template-directory.

== Changelog ==

= 0.2 =
* added multi-language (english/german)
