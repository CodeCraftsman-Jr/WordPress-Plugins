﻿=== Test Theme Preview ===
contributors: selnomeria
Tags: theme,switch,different,temporary, preview,test,mode,
License: GPLv2
Requires at least: 2.7
Tested up to: 3.8
Stable tag: 1.2

Temporary/securely Preview your site with different(Test) themes. After activation, enter "Settings>Theme Test".

== Description ==
After activation, Settings>Test themes. IN CASE OF PROBLEMS, JUST REMOVE the plugin.


>  (P.S. Note! This is a <a href="http://codesphpjs.blogspot.com/2014/10/nsp-non-slowing-plugins-for-wordpress.html" target="_blank">Non-Slowing</a> Plugin.  See OTHER MUST-HAVE PLUGINS FOR EVERYONE: http://bitly.com/MWPLUGINS  )



== Installation ==
1. Download and extract archive to `wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==
= 1.1.0 =
* First release.


== Screenshots ==

1. screenshot-1.png 

== Frequently Asked Questions ==
Nothing


== Upgrade Notice ==
nothing