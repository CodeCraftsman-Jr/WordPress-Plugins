=== Remove duplicated post content on comments pages ===
Author: Jehy
Tags: seo, link, links, publisher, post, posts, comments
Requires at least: 2.6
Tested up to: 4.2
Stable tag: 1.4
Plugin replaces post content with just a link on comments pages.
Neccessary for wordpress 2.7+, or you will be rated low for duplicate content. 

== Description ==

Plugin replaces post content on comments pages with a customized text and link to full post text.    
Neccessary for wordpress 2.7+, or you will be rated low for duplicate content. 

####History

0.1 - First release    
1.0 - Multilanguagal version with customizable text.    
1.1 - Updated for compatibility with PHP4.    
1.2 - Fixed language inclusion problem which sometimes apperared.    
1.3 - Fixed compatibility fixes    
1.4 - Added localization

####Localization

* English
* Russian


####Donate or help?
If you want to ensure the future development and support of this plugin, you can make donation [on this page](http://jehy.ru/articles/donate/) or just write about this plugin in your blog.

####Please!
If you don't rate my plugin as 5/5 - please write why - and I will add or change options and fix bugs. It's very unpleasant to see silient low rates.  
If you don't understand what this plugin does - also don't rate it. SEO specialists only.


== Installation ==

1. Upload the complete folder `wp-noexternallinks` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enjoy =^___^=

== Frequently Asked Questions ==
Still none.