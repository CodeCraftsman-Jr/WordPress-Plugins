=== Plugin Name ===
Contributors: Avranu
Donate link: http://jess-mann.com/index.php?action=contact
Tags: widgets, admin, hide, customize, clutter, simplify, reduce, fewer widgets, whitebox, extra widgets, hide widgets 
Requires at least: 3.0.1
Tested up to: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Too many widgets cluttering up your wordpress install? This plugin allows you
to hide unwanted widgets from the Appearance > Widgets panel, and anywhere
else they appear.

== Description ==
This plugin adds an additional admin page which shows you every registered
widget, and allows you to deactivate any you do not want to appear. For
example, when you are adding widgets to a sidebar, the Post Loop widget is
usually not wanted, and just adds additional clutter you must sort through. On
this widget's admin page, simply click on the widgets you would like to
disable, and then hit the "Save" button at the very bottom of the page!

== Installation ==

1. Upload the 'customize-widgets' folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

1. A screenshot of the admin page, which can be found in Appearance >
Customize Widgets

== Changelog ==
