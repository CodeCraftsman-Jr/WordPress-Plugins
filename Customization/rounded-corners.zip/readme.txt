=== Rounded Corners ===
Contributors: Nick Berlette
Donate link: http://www.pancak.es/plugins/rounded-corners/
Tags: design, rendering, javascript, corners, post
Requires at least: 2.0
Stable tag: 0.2a

Selectively add rounded corners to elements with pure JavaScript. Still in experimental phases.

== Description ==

Selectively add rounded corners to elements with pure JavaScript. Still in experimental phases.

Please note, the code may be buggy and probably doesn't work with all browsers. Hence the experimental status.

== Installation ==

1. Upload whole /rounded-corners/ folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Apply rounded corners with the menu under Design.

See also: [Plugin Homepage](http://www.pancak.es/plugins/rounded-corners/), [Author Homepage](http://www.pancak.es/).

== Screenshots ==

1. Overview of the Rounded Corners backend. Add elements to be rounded with JavaScript.