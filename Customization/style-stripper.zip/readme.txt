=== Style Stripper ===
Contributors: ericjuden
Tags: remove, delete, styles, inline styles, multisite
Requires at least: 3.0
Tested up to: 4.0
Stable tag: trunk 

== Description ==
Removes all inline style tags from the content of posts/pages/custom post types.

== Installation ==
1. Copy the plugin files to <code>wp-content/plugins/</code>

2. Activate plugin from Plugins page or Network Activate for multisite

3. Enjoy!

== Changelog ==
= 1.0 =
* Initial release
