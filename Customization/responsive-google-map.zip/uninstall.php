<?php

// If not called form wordpress then exit.
if( ! defined('WP_UNINSTALL_PLUGIN') ) {
    exit;
}