<?php

/**
 * Fired during Plugin Activation
 * 
 * @link http://webomnizz.com
 * @since 2.1
 * 
 * @package responsive-google-map
 * @subpackage responsive-google-map/includes
 */
class RGM_Activator {
    
    
        public static function activate() {
            
        }
            
    
}