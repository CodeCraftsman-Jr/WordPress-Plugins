<?php

/**
 * Fired during Plugin Deactivation
 * 
 * @link http://webomnizz.com
 * @since 2.1
 */
class RGM_Deactivator {
    
    
        public static function deactivate() {
            
        }    
}
