### 2.0

* Add the ability to change the `[]` syntax
* Tested on wordpress 4.1.1

### 1.0.3

* Tested on wordpress 4.1.0

### 1.0.2

* Fixed [Issue#1](https://github.com/hyyan/flexible-widget-title/issues/1)

### 1.0.1

* Prevented direct access for the plugin file

### 1.0.0

* Added screenshot.png
* Added wordpress ```readme.txt``` file

###0.2.1

Avoided notice which are generated because of titles which are shorter than two chars

###0.2

* Added support for "github-updater" plugin
* Changed plugin name to ```Hyyan Flexible Widget Title```

###0.1

* Initial commit
