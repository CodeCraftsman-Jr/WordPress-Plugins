=== Remove Links in Comments ===
Contributors: Ducedo
Tags: comments, comment, link, links, hyperlink, remove, prevent, stop, automatic
Requires at least: 2.x
Tested up to: 3.3.1
Stable tag: 1.1

A very simple plugin that prevents Wordpress from automatically creating hyperlinks in the comments section.

== Description ==

By using this plugin you can stop Wordpress from automatically creating hyperlinks from links in your visitors comments. There may be several reasons for doing so but the main purpose for my client was to stop all outgoing links he could not control.

Since this plugin only effects your output your visitors links will show up as normal hyperlinks as soon as you deactivate this plugin.

== Installation ==

1. Unzip, upload the 'remove-links-in-comments' folder to your WordPress plugin directory (usually '/wp-content/plugins/');
1. Activate the plugin through the 'Plugins' menu in WordPress;
1. You're done (no configuration needed)!

== Changelog ==

= 1.1 =
* Rewrote the plugin to work with latest version of WordPress.
= 1.0 =
* First public release

== Donations ==

If you like this plugin, feel free to **donate a link** to [my blog](http://www.stefannilsson.com/ "Stefan Nilsson").

== Feedback ==

Please send me your feedback via this [comment form](http://www.stefannilsson.com/contact).
