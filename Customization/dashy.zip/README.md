# Dashy

Dashy gives you a search field to get to admin pages quicker. More keyboard shortcuts right inside of WordPress. Get to pages, post, plugins, faster. You can even search and get a to single post with the keyboard. Activate with Control+Space.

-----------------------

