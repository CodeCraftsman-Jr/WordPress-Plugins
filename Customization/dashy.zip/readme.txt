=== Dashy ===
Contributors: ktheisen
Tags: admin, quick, keyboard, shortcut
Requires at least: 4.0.0
Tested up to: 4.1
Stable tag: 1.0.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Dashy gives you a search field to get to admin pages quicker. 

== Description ==

Dashy gives you a search field to get to admin pages quicker. More keyboard shortcuts right inside of WordPress. Get to pages, post, plugins, custom post types, faster. You can even search and get a to single post with the keyboard. To activate, use Control+Space.

To get to a specific page, type "list" and choose "List Pages". From there you will be showing all of your pages that you can edit. Start searching the page name, and hit enter to go directly to editing that page. This supports posts, pages, and custom post types.


== Installation ==

1. Upload 'dashy' to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Press Control+Shift+D to activate.

== Screenshots ==

1. View of Dashy when activated.
2. Search for menu items to get to them quickly.
3. Go directly to pages, posts, and CPTs from the "List ___" option.