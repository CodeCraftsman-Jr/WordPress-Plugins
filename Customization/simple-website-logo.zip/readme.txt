=== Website Logo ===
Contributors: lpkapil
Tags: website logo, logo
Requires at least: 2.8
Tested up to: 4.1.1
Stable tag: 1.0

A plugin to manage wordpress website logo, shortcode [WEBSITE_LOGO]

== Description ==
A plugin to manage wordpress website logo, shortcode [WEBSITE_LOGO]

== Installation ==
1.Upload plugin zip file \'website-logo.zip\' and activate plugin
2. use shortcode [WEBSITE_LOGO] to display logo 

== Frequently Asked Questions ==
Question: How can i use this in page templates or php files ?

Answer: just simply add this code:

 

$height,$width = height and width of logo image numeric, eg: getWebsiteLogo(10,10);



== Screenshots ==
1. http://s3.postimg.org/iy0r5qeer/website_logo.png

== Changelog ==
released starting version 1.0