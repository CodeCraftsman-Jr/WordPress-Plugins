=== Make it Yours ===
Contributors: shazdeh
Plugin Name: Make it Yours
Tags: custom-css, custom-functions, theme-options, theme
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 0.1.2

Gives you two panels to insert custom CSS and PHP codes, so you can customize your theme.

== Description ==

This is useful when you can't or don't want to edit your theme files. just put your custom CSS and PHP codes and enjoy the magic. Note that PHP codes will run safely, so your site won't break if you misspell or typed wrong codes.

== Installation ==

1. Upload the whole plugin directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Goto Appearance -> Custome CSS or Custom Functions pages
5. Enjoy!

== Screenshots ==

1. Admin interface

== Changelog ==

= 0.1.2 =
* CodeMirror library is removed, the plugin is now consistent with WordPress built-in theme and plugin editor.
* Custom CSS codes are now minified.

= 0.1.1 =
* Custom Functions in now hooked to 'after_setup_theme' to allow greater flexibility.