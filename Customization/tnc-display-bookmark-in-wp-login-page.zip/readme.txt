=== TNC Display Bookmark In WP-Login Page ===
Contributors: tunaucom
Donate Link: http://anybuy.vn/tu-com-cong-nghiep.htm
License: GPLv2 or later
Tags: tnc, bookmark, link manager, wp-login
Requires at least: 3.0
Tested up to: Wordpress 4.1
Stable tag: 1.0.0

== Description ==

Display all bookmarks (link manager) in your WordPress login page.

== Installation ==

1. Upload the the plugin folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Upgrade Notice ==
= 1.0.0 =
This is first version.

== Screenshots ==

1. Demo in anybuy

== Changelog ==

= 1.0.0 =
* First version of plugin.

== Frequently Asked Questions ==

= Why this plugin remove wordpress logo in wp-login page? =

This plugin remove wordpress logo in wp-login page to compact and easy see.