=== RA - Mod Multibyt Slug ===
Contributors: skuramoto
Tags: rains, slug, multibyte, Japanese
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0.4

When the multi-byte character is used in slug of new creation post, it changes so that post_type and post_ID may be used.

== Description ==
When the multi-byte character is used in slug of new creation post, it changes so that post_type and post_ID may be used.

== Installation ==
1. Upload the "ra-modify-multibyte-slug-newpost" folder to the "/wp-content/plugins/" directory.
2. Activate the plugin through the Plugins menu in WordPress.

== Changelog ==

= 1.0.4 =
* Fix spellmiss

= 1.0.3 =
* Compatibility Check.

= 1.0.2 =
* Version Number fix.

= 1.0.1 =
* Contributors name fix.

= 1.0.0 =
* Registration to the plug-in directory.
* First release.
