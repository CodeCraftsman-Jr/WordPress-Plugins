=== Responsive Background by DJJMZ ===
Contributors: djjmz
Requires at least: 3.6
Tags: responsive, full background, responsive background, full, background, option, options, widget, Post, plugin, admin, posts, sidebar, google, twitter, images, comments, page, shortcode, image
Tested up to: 4.1 
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WYDR4ADESD2KU&lc=LT&item_name=Donate&no_note=1&no_shipping=1&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==
= 1.2 =
* Add upload function

= 1.1 =
* Small code update

= 1.0 =
* First Release

== Description ==

Easy way change background image/color to fully responsive image. Compatible with all browsers: computers, all phone and tablets.
 

== Installation ==

1.  Upload responsive-background folder to plugins folder.

2.  Go to Plugins menu and active.



== Frequently Asked Questions ==

= Can I use this plugin for Free? =

Yes absolutely.





