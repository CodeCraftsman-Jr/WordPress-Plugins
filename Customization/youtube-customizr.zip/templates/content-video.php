<article class="video">

    <div class="player-container player-container-<?php ytc_count(); ?>">
        <div id="player-<?php ytc_count(); ?>"></div>
    </div>
    <?php the_title('<h3 class="video-title"><span>','</span></h3>'); ?>

</article>