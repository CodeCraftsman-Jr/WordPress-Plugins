<?php
delete_option('mdc_show_sticky_bar');
delete_option('mdc_sticky_bar_position');
delete_option('mdc_themes_to_show');
delete_option('mdc_ts_shortcode_enable');
delete_option('mdc_theme_switcher_custom_css');
delete_option('mdc_ts_remove_credit');