=== Remove WordPress Version ===
Contributors: ShinoRex	
Plugin Name: Remove WordPress Version
Plugin URI: http://learnwebtipz.com/
Tags: hide version, remove version, delete, hide, wordpress version, wordpress
Author URI: http://learnwebtipz.com/
Author: ShinoRex
Donate link:
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.0

Remove the version from your WordPress website completely and Increase security and prevent from hacks.

== Description ==

Remove the version from your WordPress website completely and Increase security and prevent hacks.

== Installation ==

1. Upload `remover.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to your homepage, CTRL+U to view source, and confirm that the version number has been removed from Meta, as well as the parameters on your CSS and javascript files

== Frequently Asked Questions ==

= Why should I use this plugin when I can just put the code into my functions.php file? =

You can do that - but when you update or change your theme, it will be removed (along with any other modifications done to the functions.php file).

= So this plugin will persist on my WordPress installation no matter which theme is activated, or if a theme is updated? =

Yes.

== Screenshots ==

1. screenshot-1.png

== Plugin Support ==



== Changelog ==

= 1.0 =
* Initial Release

