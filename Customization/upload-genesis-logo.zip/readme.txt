=== Upload Genesis Logo ===
Contributors: Corlax Technologies
Tags:  Membership, Plugins, WordPress
Requires at least: 3.9
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Looking for tutorials for change logo of genesis framework and don�t able to do so far because don�t know css and hard php code�s then you came at right place you can do it easily within a min just activate this plugin and start uploading your logo.
Features:-
*Upload Geneis Logo From Backend
*Customize Its style easily
*No requirement of codding languages

==Installation==
1. Upload the /upload-genesis/ directory to your plugins folder and activate
2. Go to the �Genesis>>Upload Logo� Settings Page and customize your options