simple-header-footer-html
=========================

A simple plugin for injecting HTML into various places in your Wordpress theme output.
