=== XT Corporate ToolKit ===

Contributors: xylus
Tags: corporate, business, toolkit
Requires at least: 3.9
Tested up to: 4.2.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Adding Custom post type and Taxonomy functionality to themes.


== Installation ==

Copy the plugin into the `/wp-content/plugins/` folder, and activate it.


== Changelog ==

= 1.0.0 =
* Initial Version.