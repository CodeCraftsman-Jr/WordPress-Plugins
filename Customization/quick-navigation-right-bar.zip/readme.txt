=== Quick Navigation Right Bar ===
Contributors: noitrangbanhcuon
Donate link: http://anybuy.vn/noi-trang-banh-cuon.htm
Tags: quick navigation, right bar, quick bar, navigation bar
Requires at least: 2.8.0
Tested up to: 4.0.1 
Stable tag: trunk
License: GPLv2 or later

== Description ==

This plugin add a navgation bar in right website. You can add social button on this bar, quick login button, custom html button...

Feature:

- Added many socials website

== Installation ==

1. Unzip the quick-navigation-right-bar.zip
2. Copy quick-navigation-right-bar folder to wp-content/plugins
3. Go to Plugins/Installed Plugins, find WeHeartIt Image Embed and click Active
4. Enjoy!

== Screenshots ==

1. `/assets/screenshot-1.jpg`
2. `/assets/screenshot-2.jpg`
3. `/assets/screenshot-3.jpg`
4. `/assets/screenshot-4.jpg`

== Frequently Asked Questions ==

= Need support? =

Comment to my twitter (https://twitter.com/noitrangbanh)

== Changelog ==

= 1.0 =
*  Quick Navigation Right Bar plugin released

== Upgrade Notice ==

= 1.0 =
* This is first version