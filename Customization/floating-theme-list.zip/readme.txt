=== Floating Theme List ===
Contributors: mosheeshel
Donate link: http://www.eshel.us/wordpress-donate/?plugin=floating-theme-list
Tags: themes
Requires at least: 2.8
Tested up to: 3.3.1
Stable tag: 0.1

This plugin extends Theme Switcher (/Reloaded), it displays a floating list of available themes, enabling EASY creation of a theme demo site.

== Description ==

This plugin extends Theme Switcher and Theme Switcher Reloaded, this plugin detects the existing active plugin and uses it to display a floating list of available themes, to enable creating a Theme demo site.

Basically it enables anyone to create a demo site of all his available themes, just create a site with all the demo pages you can think of. The download and Enable either Theme Switcher or  Theme Switcher Reloaded plugins, and this plugin, and when you access any page on the site a floating div will appear on the top left side of the site, showing  a dropdown menu wutg the current theme selected. When you choose a different theme from the list, the site will switch to have that theme as the selected site theme.

Note: that this plugin is dependant on either the Theme Switcher or the Theme Switcher Reloaded plugins, and what it does would not be possible without the work done on those plugins.
== Installation ==

1. Download and extract the floating-theme-list plugin file.
2. Upload the theme-switcher directory to the /wp-content/plugins/ directory.
3. Activate the plugin under the 'Plugins' menu in the WordPress admin.

== Frequently Asked Questions ==

= Why isn't anything hapening =

Did you for get to install the dependant plugins Theme Switcher or Theme Switcher Reloaded?

== Screenshots ==


== Changelog ==

= 0.1 =
* Uploaded first working version of plugin, hopefully the last as well!

