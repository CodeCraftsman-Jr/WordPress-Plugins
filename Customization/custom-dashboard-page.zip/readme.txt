=== Custom Dashboard Page ===

Contributors: raficsedu
Author URI: http://myplugin.tophostbd.com/
Plugin URI: http://myplugin.tophostbd.com/
Tags: dashboard,custom dashboard,dashboard page, metaboxe, metaboxes, customization, administration, panel
Requires at least: 3.0
Tested up to: 4.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://myplugin.tophostbd.com/

Display a custom page into dashboard

== Description ==

After login to wordpress admin panel the home page looks ugly as it contains many meta boxes and some custom stuffs . So my plugin will remove those ugly things . You can set a specific page to display in dashboard from plugin settings .

If you have suggestions or bugfixes for the plugin, contact me in my official site (http://myplugin.tophostbd.com/)

If you want to translate the plugin into your language, [contact me](http://myplugin.tophostbd.com/)

Note : Multisite Compatible

== Installation ==

1. Upload the plugin
2. Activate the plugin then go to "CDP Settings"
3. Select the page from page list to display into Dashboard
4. Now click to the Dashboard menu to see your result .


== Screenshots ==

1. Preview a custom WordPress dashboard
2. Admin Settings to select a page

== Changelog ==

= 1.0 =
* Initial release.