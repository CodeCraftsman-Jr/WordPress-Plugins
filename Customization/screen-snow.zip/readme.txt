=== Screen Snow ===
Contributors: Haandvaerkeren
Tags: Snow , Screen Snow , site Snow , Snow effect , christmas
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://www.bygoghjem.dk/
Version: 1.0.0

Screen Snow is a plugin that add snow effect to the wordpress site.

== Description ==

Screen Snow is a plugin that add snow effect to the wordpress site. Very simple, Once you activated the plugin you can control speed, density, Size and color of snow.

Screen Snow doesn't include or depend on any external scripts, images or any other external files.


== Installation ==

**Plugin Directory** 

1. Seach the plugin directory for plugin.
2. Click 'Install Now'.
3. Activate the plugin.
4. 'Screen Snow' should be added to the side admin menu with the default settings.
5. You can modify the settings as needed.

**Upload** 

1. Download the plugin Zip file.
2. Go to plugins in the Wordpress Admin area.
3. Select 'Upload Plugin'
4. Activate the plugin.
5. 'Screen Snow' should be added to the side admin menu with the default settings.
6. You can modify the settings as needed.


== Frequently Asked Questions ==

**Does this plugin use external scripts ?**

No, the plugin is full self dependent.


**Does this plugin use flashs ?**

No, this plugin doesn't use any flashs.


== Screenshots ==

1. Snow Effect.
2. Plugin Control Panel.


