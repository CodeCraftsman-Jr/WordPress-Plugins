=== Change Howdy ===
Contributors: pankajanupam
Tags: change howdy, admin bar
Requires at least: 2.8
Tested up to: 4.1

Change Howdy to welcome or any other text

== Description ==
Change Howdy to welcome or any other text

== Installation ==

You can install Change Howdy directly from the WordPress admin panel.

	Visit the Plugins > Add New and search for 'Change Howdy'.

	Click to install. 
	
	Once installed, activate and it is functional.


Manual Installation Change Howdy plugin:

    Download and unzip the file

    Upload the full extracted folder to the /wp-content/plugins/ directory

    Activate the plugin through the 'Change Howdy' menu in WordPress.

You're done! The Plugin ready to use according to the directions in the description.


== Frequently Asked Questions ==

None

== Screenshots ==

None

== Changelog ==
=2.0=
add compatibility tag

=1.2=
add compatibility tag

=1.1=
add compatibility tag

=1.0=
add tag

= 0.9 =
First Release