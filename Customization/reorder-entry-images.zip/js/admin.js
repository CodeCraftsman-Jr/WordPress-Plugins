(function ($) {
	"use strict";
	$(function () {
		$('#attachmentcontainer').sortable();
	});
}(jQuery));