=== Auto Update Themes ===
Contributors: Geenyous
Donate link: http://www.geenyous.com/payment/
Tags: theme, themes, plugin, update, auto, automatic, automatically
Requires at least: 3.7
Tested up to: 4.2.2
Stable tag: 0.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin sets Wordpress to automatically download and install theme updates.

No configuration needed, simply install the plugin and activate it.

== Description ==

This plugin sets Wordpress to automatically download and install theme updates.

No configuration needed, simply install the plugin and activate it.

== Installation ==

1. Upload the `auto-update-plugins` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

This plugin should activate the automatic downloading of theme updates within Wordpress.

You should normally see the automatic update routine execute within 12 hours of receiving the manual upgrade notice.

== Upgrade Notice ==

0.1.1 - Updated information

0.1.0 - First version

== Screenshots ==

None

== Changelog ==

= 0.1.1 =
Updated information

= 0.1.0 =
This is the first version of this plugin.
