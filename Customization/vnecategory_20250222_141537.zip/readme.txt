=== VNEcategory  ===
Contributors: drmen8x
Donate link: http://casanova.vn
Tags: category, sub category,post in sub category, each category, each post, vnexpress, vnecategory, vne
Requires at least: 2.8
Tested up to: 3.4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show category and subcategory and post in these categories

== Description ==

Show category and subcategory and post in these categories

Please see screenshot to know more...

Features:

* Show the parent category and subcategory
* Show posts in these categories like vnexpress.net
* You can limit post to show
* You can show or hide subcategory

== Installation ==

1. Download the plugin.
2. Upload it to the plugins folder of your blog and active it.
3. Create your category and subcategory
4. Create posts in these categories
5. Goto Apperance --> Widget --> drag VNEcategory Posts to your widgets.

== Upgrade Notice ==
This is the first version

== Screenshots ==

1. Categories structure
2. Widget configuration
3. Display in fronend

== Changelog ==

= 1.0 =
* This is the first version and no changelog. 

== Frequently Asked Questions ==
Please goto my blog http://blog.casanova.vn and give comment at the bottom of  article about this plugin
