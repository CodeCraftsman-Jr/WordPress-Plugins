=== Simple custom post likes ===
Contributors: richymilo , leogopal
Donate link: http://wobble.co.za/
Tags: custom post types, likes, featured
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Appends a custom likes box that allows a user to like any post type from the front end.

== Description ==

Appends a custom likes box that allows a user to like any post type from the front end.
Only one like is allowed per user/ip address.
Once a user has liked the post type they can unlike it again by clicking on the same button.
Plugin runs by using meta data and ajax.

The Plugin is configured via the admin page which is listed as a sub-menu item under "Settings".
The element that the box should be appended to as well as the post type to target should be selected. 

== Installation ==


1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

The Plugin is configured via the admin page which is listed as a sub-menu item under "Settings".
The element that the box should be appended to as well as the post type to target should be selected. 

== Frequently Asked Questions ==

== Screenshots ==


== Changelog ==
= 1.0 =
* First Version, Basic Working copy

= 1.0.1 =
* Support added for single post
