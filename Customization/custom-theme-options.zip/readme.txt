=== Custom Theme Options ===
Contributors: pv.jinesh
Donate link: http://weblumia.com/donate/
Tags: lumia-slider, sliders, image slider,responsive, responsive slider, content slider, video slider
Requires at least: 3.3
Tested up to: 4.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom Theme Options plugin easy to manage your custom theme options like copyright text,youtube, facebook, twitter links etc.

== Description ==

Features

1. Admin interface to add, edit and manage custom theme options.




Theme Functions

For Eg: if your label name is "Linked In", please use these functions   $options = get_option( 'lumia_theme_options' );   echo $options['header_option_values']['linked_in'];


Support

So that others can share in the answer, please submit your support requests through the WordPress forums for [Custom Theme Options](http://wordpress.org/plugins/custom-theme-options/).

If you want private or priority support, please [donate](http://weblumia.com/donate) at least $5 USD to cover my time.

== Installation ==

== Installation ==

1.     Via WordPress Admin > Plugins > Add New, Upload the custom-theme-options.zip file
2.     Alternately, via FTP, upload Custom Theme Options directory to the /wp-content/plugins/ directory
3.     Activate the 'Custom Theme Options' plugin after uploading or through WordPress Admin > Plugins

Usage

For Eg: if your label name is "Linked In", please use these functions   $options = get_option( 'lumia_theme_options' );   echo $options['header_option_values']['linked_in'].

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. screenshot-1

== Changelog ==

== Upgrade notice ==

== Arbitrary section 1 ==

== Upgrade Notice ==