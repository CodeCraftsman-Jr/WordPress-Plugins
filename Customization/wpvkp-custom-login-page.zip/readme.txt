===WPVKP Custom Login Page===
Contributors: designvkp
Donate link: http://wpvkp.com/
Tags: : admin, branding, custom login, custom login pro, customization, error, login, login error, logo, admin, admin custom login, admin login, admin login form, admin login page, background, background slideshow, branding, captcha, CSS, custom login, custom login page, custom login plugin, custom login pro, custom logo, customization, customize, customize wordpress login form, customizer, error, Facebook, form style, google plug, html, image, jquery, jquery form, linkedin, log in, login, login error, login form, login form plugin, logo, ogin page, plugin, role, security login, sideshow, social connect, social form, social share, style log in, style login, subscriber, themes, twitter, wordpress admin login, wordpress login, wp login form, wp-login,admin login, author, author profile, Avatar, avatar upload, builder, captcha, custom field registration, custom fields, custom login, custom password reset, custom redirects, custom registration, custom registration form, custom registration page, custom user profile, customize profile, customize registration email, edit profile, email confirmation, extra user fields, Facebook Login, file uploads, form builder, front end, front-end edit profile, front-end login, front-end profile, front-end register, front-end registration, front-end user listing, front-end user registration, frontend, github, github login, google, Google Login, gravatar, hide wp-admin, linkedin, linkedin login, log in, login, login redirect, login widget, member directory, members, minimum password length, minimum password strength, multiple registration forms, password reset, password strength meter, profile, profile builder, recaptcha, register, register form, registration, registration page, shortcode, shortcodes, sidebar, sidebar login, social, social login, tab widget, twitter, twitter login, user, user approval, user custom fields, user email, user listing, user login, user profile, user profile page, User Registration, user registration form, user-fields, users, widget, wordpress login, custom, e-mail, gravatar, log in, login, redirection, register, registration, sidebar, theme, widget, bbPress, buddypress, captcha, capture social data, facebook connect, free social sharing, Google Login, Hubspot, linkedin login, LoginRadius, mailchimp, multisite, Online Identity, OpenID integration, post to social networks, salesforce, share post, single sign-on, Social Analytics, social api, social app, social authentication, social commenting, social login, social media tools, Social Plugins, social share, social sharing, social sign-in, SSO technology, twitter, User Profile Data, User Registration, widget, wordpress multisite, yahoo openID, active, add client logo to login page, additional html, admin, admin login logo, admin logo, brand, brand login, branding, captcha, change admin logo, change login logo, code script, coffee2code, CSS, custom, custom admin logo, custom code, custom color, custom css, custom dashboard, custom fields, custom footer, custom footer script, custom head, custom head script, custom header, custom header script, custom js, custom login, custom login color, custom login page, custom login pro, custom logo, custom page, custom post, customisation, customise, customization, customize, customizer, dashboard, data, erident, error, extra, foolproof, footer, footer code, footer javascript, footer script, form, form border, form radius, fronted css, fronted js, gettext, google analytics, Google Analytics code, Google Analytics conversion code, Google Analytics conversion script, Google Analytics footer code, Google Analytics footer script, Google Analytics head code, Google Analytics head script, Google Analytics javascript, Google Analytics remarketing code, Google Analytics remarketing script, Google Analytics script, Google Analytics tracking code, Google Analytics tracking script, google captcha, google recaptcha, head, head code, head footer code, head footer script, head javascript, head script, header, header code, header footer, header footer code, header footer script, header javascript, header script, info, inject css, input color, input text color, insert, javascript, javascript code, JS, log, login, login customizer, login error, login form change, login logo, login page, login redirect, login widget, logo, logo change, meta, multisite, nocaptcha recaptcha, own css, own look, page, pages, plugin, Post, posts, re-marketing code, script, security, shortcode, show, source, super simple, tracking code, tracking javascript, tracking script, transparent background, transparent form, welcome text, widget, widgets, wordpress, wordpress security, wp-admin
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag:1.0
License:GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Customize Wordpress login page  easily according to your theme or any other custom style with Custom Login Page Styler.

==Description==
This easy to use plugin gives you the power to convert the boring wordpress login page with much more attractive and personalized login page. This plugin helps to improve your brand authority and also helps to improve user experince. Now can customize the logo, the background, the login button and various different css aspects of every element on the login page through easy to use control panel.
</br></br>

<strong>Important Features Of WPVKP C-Login Plugin</strong>
* Add your own custom logo.
* Add your own personal background.
* Choose to have background color
* Set the size of logo
* Choose the color or form
* You can set form background image
* You can modify the login button
* You can change the button radius
* Add custom button border color
* More features comming soon..

<strong>This plugin is developed by [WPVKP - WordPress Community Support](http://wpvkp.com).</strong>

== Installation ==
You can either install this plugin from your wordpress administration panel or by downloading it from here.

<strong>From WP-Admin Panel</strong>
1. Login to your wordpress control panel.
2. Visit Plugins
3. Click on Add New on left hand side top button.
4. Search for WPVKP Custom Login Page plugin
5. Install it.
6. Activate the plugin, enjoy.

<strong>Manually uploading the plugin</strong>
1. Download plugin from here.
2. unzip the plugin folder.
3. Upload the wpvkp-cutom-login-page folder to wordpress wp-content/plugin folder.
4. Visit wordpress control panel
5. Activate the plugin, enjoy.

== Frequently Asked Questions ==
There are no FAQ just yet

== Screenshots ==
1. Great Interface


== Changelog ==

Just Released

== Upgrade Notice ==

New features coming soon