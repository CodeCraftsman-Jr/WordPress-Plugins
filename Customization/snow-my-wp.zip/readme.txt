=== Plugin Name ===
Contributors: ChetanVengurlekar, SarviSolutions
Donate link: http://www.sarvisolutions.com/donate/
Tags: christmas, snow, snow my website, website snow, snow on my website, christmas celebration, december snow
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Spread some snow on your website with this amazing plugin.

== Description ==
This is a plugin for the festive season. This plugin displays a snowfall with various snowflakes colors and sizes. Amaze your website visitors with a snowfall in winter or for that matter any season you want!

If you are facing any problem, let us know here: https://wordpress.org/support/plugin/snow-my-wp

== Installation ==

1. Upload `snow-my-wp.zip` via `wp-admin/plugin-install.php?tab=upload` or upload the unzipped content to the `/wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the `Plugins` menu in WordPress
3. You will see the snowfall on all your front-end pages as soon as you activate the plugin.

== Frequently Asked Questions ==

= How do I turn off the snow ? =
You can deactivate the plugin from `wp-admin/plugin.php` if you want to stop the snowfall on your website.

== Screenshots ==

1. Plugin output on Twenty Tweleve
2. Plugin output on Twenty Thirteen
3. Plugin output on Twenty Fourteen
4. Plugin output on Twenty Fifteen

== Changelog ==

= 1.0 =
* This version of the plugin works perfectly with 4.0.1.

= 0.1 =
* This is the first version of the plugin.

== Upgrade Notice ==

= 1.0 =
* This version of the plugin works perfectly with 4.0.1.

= 0.1 =
Upgrade immediately.