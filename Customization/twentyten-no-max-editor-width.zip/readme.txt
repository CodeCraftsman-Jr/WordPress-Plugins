=== TwentyTen: No Max Editor Width ===
Contributors: dd32
Tags: 3.0, twentyten
Requires at least: 3.0-dev
Stable tag: 0.1

TwentyTen is a great new theme for WordPress, However the Visual editor is limited to 640px content width, This restores it to full width editing
== Description ==

TwentyTen is a great new theme for WordPress, In my mind however, It suffers one fault, The TinyMCE editor is limited to just 640px content width. This is to allow you to get a visual indication of the layout of a post (For example, Floating images and text wraping). This plugin removes the ability for the theme to modify TinyMCE's content width.

See <a href="http://dd32.id.au/2010/06/01/introducing-twentyten-remove-max-editor-width/">http://dd32.id.au/2010/06/01/introducing-twentyten-remove-max-editor-width/</a> for more information.

== Changelog ==

= 0.1 =
 * First Release