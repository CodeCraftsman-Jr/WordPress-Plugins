=== Meaty Avatars ===
Contributors: technosailor, gungeekatx
Tags: comments, avatars
Requires at least: 4.1
Tested up to: 4.2
Stable tag: 1.0.0
License: MIT
License URI: http://opensource.org/licenses/MIT

Leverages the baconmockup.com web site to replace WordPress avatars with images of meat.  Forked from Technosailor's Superheroes Avatar plugin.

== Description ==

Leverages the baconmockup.com web site to replace WordPress avatars with images of meat.  Forked from Technosailor's Superheroes Avatar plugin.

== Frequently Asked Questions ==

Any questions that come up frequently will be here.

== Installation ==

1. Upload `meaty-avatars` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

 1. Example of the standard avatars being replaced with images of meat.

== Changelog ==

= 1.0 =
* Initial release


== Upgrade Notice ==

= 1.0 =
* Initial release
