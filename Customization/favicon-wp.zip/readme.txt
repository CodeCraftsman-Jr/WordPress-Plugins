=== Plugin Name ===
Contributors: ExtendedProduct
Donate link: http://www.extendedproduct.com
Tags: plugin, plugins, javascript, page, pages, post, posts, blog, wordpress, image, images, graphic, graphics
Requires at least: 2.0.2
Tested up to: 3.0.5
Stable tag: 1.0.0

This plugin allows you to display a favicon on your blog - With maximum compatibility!

== Description ==

This plugin allows you to display a favicon on your blog - With maximum compatibility!

Simply enter the URLs of the favicon and your blog will use this as the favicon - Less than a minute setup time!

== Installation ==

1. Upload `/favicon-wp.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit the Favicon WP Settings in your Administration Panel
4. Done!

== Frequently Asked Questions ==

= Does this work? =

Yes.

== Changelog ==

= 1.0.0 =
* First Release
