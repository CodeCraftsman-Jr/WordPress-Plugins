<?php

define('PIZZAZZ_VERSION', '1.4.0');

define('PIZZAZZ_PATH', plugin_dir_path(__FILE__));
define('PIZZAZZ_URL', plugin_dir_url(__FILE__));
define('PIZZAZZ_INCLUDES_PATH', PIZZAZZ_PATH . 'includes/');
