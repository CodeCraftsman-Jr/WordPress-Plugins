<?php

if(!defined('ABSPATH')) die(-1);
?>
<div id="pizzazz">
    <h4><?php echo __('No items published in this portfolio.', 'pizzazz'); ?></h4>
</div>