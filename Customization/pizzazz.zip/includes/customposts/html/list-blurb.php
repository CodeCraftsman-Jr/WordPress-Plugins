
<div class="updated survey-link">
    <p>
        Insert your portfolio into a post or page using the shortcode [pizzazz].
        <a href="http://giveitpizzazz.com/wp-portfolio-support/documentation" target="_blank">See the documentation</a> for more help.
        Got feedback? Email <a href="mailto:john@bluebridgedev.com">john@bluebridgedev.com</a>.
    </p>
</div>