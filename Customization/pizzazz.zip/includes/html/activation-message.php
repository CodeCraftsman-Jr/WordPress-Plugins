<?php if (!defined('ABSPATH')) die(-1); ?>

<div class="updated">

    <p>
        Pizzazz from <a href="http://bluebridgedev.com" target="_blank">Blue Bridge Development</a>
    </p>

    <em>Created using</em>:

    <ul>
        <li>
            <a href="http://gmarwaha.com/jquery/jcarousellite/" target="_blank">jCarousel Lite</a> Copyright (c) 2007
            Ganeshji Marwaha (gmarwaha.com)
        </li>
        <li>
            <a href="http://noelboss.github.io/featherlight/" target="_blank">Featherlight</a> Noël Bossart (noelboss.com)
        </li>
        <li>
            <a href="http://www.mobileesp.com" target="_blank">MobileESP</a> Copyright 2010-2013 Anthony Hand
        </li>
    </ul>

    <p>
        Licensed under the GPL, MIT and Apache license
    </p>

</div>