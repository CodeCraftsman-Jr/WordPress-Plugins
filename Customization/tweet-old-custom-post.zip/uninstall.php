<?php
/**
 * Created by PhpStorm.
 * User: Dejan Markovic
 * Date: 02/09/14
 * Time: 10:48 AM
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}
//delete options from tocp
delete_option( 'top_settings' );
delete_option( 'top_opt_admin_url' );
delete_option( 'top_opt_last_update' );
delete_option( 'top_opt_omit_cats' );
delete_option( 'top_opt_omit_cust_cats' );
delete_option( 'top_opt_max_age_limit' );
delete_option( 'top_opt_age_limit' );
delete_option( 'top_opt_excluded_post' );
delete_option( 'top_opt_post_type' );
delete_option( 'top_opt_no_of_tweet' );
delete_option( 'top_opt_tweeted_posts' );
delete_option( 'top_opt_tweet_type' );
delete_option( 'top_opt_add_text' );
delete_option( 'top_opt_add_text_at' );
delete_option( 'top_opt_include_link' );
delete_option( 'top_opt_custom_hashtag_option' );
delete_option( 'top_opt_custom_hashtag_field' );
delete_option( 'top_opt_hashtags' );
delete_option( 'top_opt_url_shortener' );
delete_option( 'top_opt_custom_url_option' );
delete_option( 'top_opt_use_url_shortner' );
delete_option( 'top_opt_use_inline_hashtags' );
delete_option( 'top_opt_hashtag_length' );
delete_option( 'top_opt_custom_url_field' );
delete_option( 'top_opt_bitly_key' );
delete_option( 'top_opt_bitly_user' );
delete_option( 'top_opt_interval' );
delete_option( 'top_settings' );
delete_option( 'top_enable_log' );
delete_option( 'top_opt_add_text' );
delete_option( 'top_opt_add_text_at' );
delete_option( 'top_opt_use_inline_hashtags' );
delete_option( 'top_opt_use_url_shortner' );
delete_option( 'top_reauthorize' );
//delete options from tocp
delete_option( 'tocp_settings' );
delete_option( 'tocp_opt_admin_url' );
delete_option( 'tocp_opt_last_update' );
delete_option( 'tocp_opt_omit_cats' );
delete_option( 'tocp_opt_omit_cust_cats' );
delete_option( 'tocp_opt_max_age_limit' );
delete_option( 'tocp_opt_age_limit' );
delete_option( 'tocp_opt_excluded_post' );
delete_option( 'tocp_opt_post_type' );
delete_option( 'tocp_opt_no_of_tweet' );
delete_option( 'tocp_opt_tweeted_posts' );
delete_option( 'tocp_opt_tweet_type' );
delete_option( 'tocp_opt_add_text' );
delete_option( 'tocp_opt_add_text_at' );
delete_option( 'tocp_opt_include_link' );
delete_option( 'tocp_opt_custom_hashtag_option' );
delete_option( 'tocp_opt_custom_hashtag_field' );
delete_option( 'tocp_opt_hashtags' );
delete_option( 'tocp_opt_url_shortener' );
delete_option( 'tocp_opt_custom_url_option' );
delete_option( 'tocp_opt_use_url_shortner' );
delete_option( 'tocp_opt_use_inline_hashtags' );
delete_option( 'tocp_opt_hashtag_length' );
delete_option( 'tocp_opt_custom_url_field' );
delete_option( 'tocp_opt_bitly_key' );
delete_option( 'tocp_opt_bitly_user' );
delete_option( 'tocp_opt_interval' );
delete_option( 'tocp_settings' );
delete_option( 'tocp_enable_log' );
delete_option( 'tocp_opt_add_text' );
delete_option( 'tocp_opt_add_text_at' );
delete_option( 'tocp_opt_use_inline_hashtags' );
delete_option( 'tocp_opt_use_url_shortner' );
delete_option( 'tocp_reauthorize' );


