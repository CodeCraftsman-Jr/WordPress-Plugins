=== WordPress Custom Settings ===
Contributors: Davinder Singh
Tags: WordPress Custom Settings, Custom Settings, Update Options ,save content ,options, get_options , custom configuration
Requires at least: 3.1
Tested up to: 4.1
Stable tag: 3.0.4
License: GPLv2 or later

WordPress Custom Settings enables to save your custom settings like social media links some html block , text line, upload logo and files easily.

== Description ==

WordPress Custom Settings enables you to save your custom settings like social media links some html block a small text line upload a logo and file etc.

To minimal use of widgets it gives you a options to create sections for categorization of your fields you can edit delete your sections also give you a interface to add multiple fields and manage them.you can call all the fields using shortcode as well.

[Support WPC on GitHub](https://github.com/honeydhi/WordPress-Theme-Settings/issues "Support WPC on GitHub") your support is valuable.
 

Major features in WordPress Custom Settings include:

* User and Developer friendly
* Section Management available
* Field Management available
* shortcode to get values


== Installation ==

Upload the WordPress Custom Settings plugin to your plugin directory, Activate it, and use it simply.

You're done!


== Screenshots ==

1. Add New Section

2. Add New Field

3. Just add the above code snippet in your template (Add your field slug in place of $options)

4. Use the following screenshot to call in WordPress Editor

== Changelog ==

= 1.0.0 =
*Release Date - 11 July, 2015

* Release first build

