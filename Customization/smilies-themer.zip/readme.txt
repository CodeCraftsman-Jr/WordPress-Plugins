=== Smilies Themer ===
Tags: smilies, themes, emoticons
Requires at least: 2.0
Tested up to: 2.8
Stable tag: trunk
Donate link: http://rick.jinlabs.com/donate/

Smilies Themer allows you to use smilies (emoticons) themes (or packs) to replace the wordpress default ones.

== Description ==

Smilies Themer allows you to use smilies (emoticons) themes (or packs) to replace the wordpress default ones.

View page plugin for more info.

**Features**

    * Works (with WP 2.2+)
    * Compatible with More Smilies themes
    * Options page
    * Multilinguage support

**Usage**

No user interaction needed. Just activate the plugin, select a smilies theme and profit!

For more info (themes, translations, etc.) visit [the plugin homepage](http://rick.jinlabs.com/code/smilies-themer "Smilies Themer").

**Credits**

Matt Read - The plugin is a a crop of his More Smilies (now unsupported), so the major part of the credits goes to him.

**License**

This plugin is released in a GPL license.

**Contact**

Suggestion, fixes, rants, congratulations, gifts et al to rick[at]jinlabs.com or by my contact page.