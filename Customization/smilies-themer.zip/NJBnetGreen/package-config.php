<?php

/*
 * Package-Name: nyssajbrown.net Smilies - Green
 * Package-URI: http://ramblings.nyssajbrown.net/
 * Package-Description: Smilies for Wordpress.
 * Package-Author: Nyssa J. Brown
 * Package-Author-URI: http://ramblings.nyssajbrown.net/
 */

$wp_smilies = array(
	':blush:'     => 'blush.gif',
	':X'     => 'blush.gif',
	':cool:'   => 'cool.gif',
	'8)'     => 'cool.gif',
	':grin:'    => 'grin.gif',
	':D'    => 'grin.gif',
	'=D'  => 'grin.gif',
	':grinnod:'  => 'grinnod.gif',
	':lol:'    => 'lol.gif',
	':love:'  => 'love.gif',
	':|' => 'neutral.gif',
	'=|'  => 'neutral.gif',
	':no:' => 'no.gif',
	':P'     => 'razz.gif',
	':razz:'    => 'razz.gif',
	'=P' => 'razz.gif',
	':sad:'   => 'sad.gif',
  ':('  => 'sad.gif',
  '=('	=> 'sad.gif',
  ':)'	=> 'smile.gif',
  '=)'	=> 'smile.gif',
  ':smile:'	=> 'smile.gif',
  ':wink:'	=> 'wink.gif',
  ':wow:'	=> 'wow.gif',
  ':O'	=> 'wow.gif',
  '=O'	=> 'wow.gif',
  ':nod:'	=> 'yes.gif',
  ':yes:'	=> 'yes.gif',
	':roll:' => 'roll.gif',
		);

?>