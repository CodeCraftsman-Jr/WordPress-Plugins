<?php

/*
 * Package-Name: Julianus, a tribute to Julien
 * Package-URI: http://www.ikiru.ch/blog/?p=189
 * Package-Description: A Wordpress smilies packages.
 * Package-Author: Psykotik
 * Package-Author-URI: http://www.ikiru.ch/
 */

$wp_smilies = array(
	':p'        => '20x20-hell_boy.png',
  ':-p'        => '20x20-hell_boy.png',  
	'8)'        => '20x20-boss.png',
  '8-)'        => '20x20-boss.png', 
	':lol:'      => '20x20-after_boom.png',
	'=('        => '20x20-too_sad.png',
  ':('        => '20x20-too_sad.png',
  ':-('        => '20x20-too_sad.png',
	':8'        => '20x20-adore.png',
	';)'        => '20x20-feel_good.png',
  ';-)'        => '20x20-feel_good.png', 
	':(('       => '20x20-angry.png',
	':o:'       => '20x20-ah.png',
	':['        => '20x20-waaaht.png',
	':)'        => '20x20-big_smile.png',
  ':-)'        => '20x20-big_smile.png', 
  ':D'        => '20x20-look_down.png',
  ':-D'        => '20x20-look_down.png',
	':-|'       => '20x20-amazed.png',
  ':-[)'      => '20x20-confident.png',   
	':bloody:'   => '20x20-extreme_sexy_girl.png',     
	':cool:'     => '20x20-cold.png',   
  ':choler:'   => '20x20-choler.png',
	':love:'     => '20x20-beauty.png',    
  ':oups:'     => '20x20-confuse.png',  
	':aie:'      => '20x20-beat_brick.png', 
	':beurk:'    => '20x20-bad_smelly.png', 
    
    /*        
	':canny:'  => '20x20-canny.png',
	':go:'       => '20x20-go.png',
	':miam:'     => '20x20-hungry.png',
	':neo:'      => '20x20-matrix.png',
	':ueue:'     => '20x20-misdoubt.png',
	':nose:'     => '20x20-nosebleed.png',
	':oh:'       => '20x20-oh.png',
	':oups2:'    => '20x20-ops.png',
	':prud:'     => '20x20-pudency.png',
	':yo:'       => '20x20-rap.png',
    ':sadd:'     => '20x20-sad.png',
	':bloody2:'  => '20x20-sexy_girl.png',
	':cache:'    => '20x20-shame.png',
	':rose:'     => '20x20-smile.png',
	':spd:'      => '20x20-spiderman.png',
	':dream:'    => '20x20-still_dreaming.png',
	':sure:'     => '20x20-sure.png',
	':yes:'      => '20x20-surrender.png',
	':sweat:'    => '20x20-sweat.png',
	':kiss:'     => '20x20-sweet_kiss.png',
	':creve:'    => '20x20-tire.png',
	':what:'     => '20x20-what.png',
	':pff:'      => '20x20-haha.png',
	':hm:'       => '20x20-doubt.png',
	':bobo:'     => '20x20-beated.png',
    ':aie2:'     => '20x20-beat_plaster.png', 
	':aie3:'     => '20x20-beat_shot.png',
	':ciao:'     => '20x20-byebye.png',
	':dribble:'  => '20x20-dribble.png',
	':gene:'     => '20x20-embarrassed.png',
    */
	);

?>
