<?php

/*
 * Package-Name: Nomicons - The Full Monty
 * Package-URI: http://www.invisionadds.com/files/index.php?act=file&f=153
 * Presenting, Nomicons: The Full Monty
 * Credits:
 * Oscar Gruno, aka Nominell v. 2.0 -> oscargruno@mac.com
 * Andy Fedosjeenko, aka Nightwolf -> bobo@animevanguard.com
 * Copyright � 2001-Infinity, Oscar Gruno & Andy Fedosjeenko
 * You can redistribute these files as much as you like, 
 * as long as you keep this file with them and give us the proper credit. 
 * You may even rape them if you please, just give us credit for our work.
 * Package-Description: Nomicons - The Full Monty
 * Package-Author: Norman Delhey
 * Package-Author-URI: http://www.delhey.nl
 */

$wp_smilies = array(
   ':alien:'       => 'alien.png',
   ':angel:'       => 'angel.png',
   ':angry:'       => 'angry.png',
   ':blink:'       => 'blink.png',
   ':blush:'       => 'blush.png',
   ':cheerful:'    => 'cheerful.png',
   ':cool:'        => 'cool.png',
   ':cwy:'         => 'cwy.png',
   ':devil:'       => 'devil.png',
   ':dizzy:'       => 'dizzy.png',
   ':ermm:'        => 'ermm.png',
   ':face:'        => 'face.png',
   ':getlost:'     => 'getlost.png',
   ':biggrin:'     => 'grin.png',
   ':happy:'       => 'happy.png',
   ':heart:'       => 'heart.png',
   ':kissing:'     => 'kissing.png',
   ':lol:'         => 'laughing.png',
   ':ninja:'       => 'ninja.png',
   ':pinch:'       => 'pinch.png',
   ':pouty:'       => 'pouty.png',
   ':sad:'         => 'sad.png',
   ':shocked:'     => 'shocked.png',
   ':sick:'        => 'sick.png',
   ':sideways:'    => 'sideways.png',
   ':silly:'       => 'silly.png',
   ':sleeping:'    => 'sleeping.png',
   ':smile:'       => 'smile.png',
   ':tongue:'      => 'tongue.png',
   ':unsure:'      => 'unsure.png',
   ':w00t:'        => 'w00t.png',
   ':wassat:'      => 'wassat.png',
   ':whistle:'     => 'whistling.png',
   ':wink:'        => 'wink.png',
   ':wub:'         => 'wub.png'
);

?>