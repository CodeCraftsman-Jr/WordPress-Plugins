=== Plugin Name ===
Contributors: wpchildthemes
Donate link: http://www.wpchildthemes.com/donate
Tags: footer, genesis, genesiswp, studiopress, wpchildthemes
Requires at least: 3.0
Tested up to: 3.0.1
Stable tag: 0.1.1

This plugin allows you to modify Genesis-powered-website footer via Genesis theme settings.

== Description ==

By simply editing your Genesis Theme Settings, you can easily change your footer.

[Genesis Plugins](http://www.wpchildthemes.com/plugins)

[Plugin Page](http://www.wpchildthemes.com/plugin/genesis-footer)

[The Author](http://www.wpchildthemes.com)

== Installation ==

1. Upload the entire genesis-footer folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. In your Genesis Theme Setting menu, customize your footer from "WPChildThemes - Footer" box.

== Frequently Asked Questions ==

= Is it free? =

Yes, of course, but you need Genesis Theme Framework to use this plugin.

== Screenshots ==

1. Genesis Theme Setting Page
2. Website Footer

== Changelog ==

= 0.1.1 =
* fix small bugs

= 0.1 =
* First release

== Upgrade Notice ==

= 0.1 =
First release. Download immediately. :)

