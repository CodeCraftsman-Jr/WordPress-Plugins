=== Flag Icons ===
Contributors: havengr
Donate link: 
Tags: language, flags, multisite, icons, switch, select, flag, icon, country, countries
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 1.95
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Flags Icons Language Switcher.

== Description ==

This plugin helps you to add the flag icons with the targeted links on your site by choosing desired position or using a shortcode.

You just have to select position,flag and add the link!

Flags Icons: English, Bosnia, Klingon, Iceland, Switzerland, Mongolia, Moldova, Greece, Belgium, EU, UAE, Indonesia, Hong Kong, Brazil, Estonia, Lithuania, Latvia, Argentina, Finland, Norway, Germany, Spain, Wales, Ireland, Romania, India, Hungary, Portugal, Usa, Turkey, Japan, Israel, Saudi Arabia, Sweden, France, Italy, Netherlands, s. Korea, China, Czech , Cyprus, Russia, Malaysia, Singapore, Thailand, Denmark, Bulgaria , Canad, Dominician Republic, Croatia, Egypt, Algeria, Australia, Esperado, Iran, Iraq, Catalan, Ukraine and Poland.

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Goto settings -> Language Icon Switcher for options.

For Multisite:

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Deactive in the netweork dashboard
4. Activate in seperate site.
5. Goto settings -> Language Icon Switcher for options for each site.

== Frequently asked questions ==

= My language is not there, what can i do? =

You can send me in http://www.webcraft.gr/muli/ to add your country flag to the new version!

Thanks

== Screenshots ==

1. http://webcraft.gr/wp-content/uploads/2013/07/icons1.jpg

2. http://webcraft.gr/wp-content/uploads/2013/07/iconsenv.jpg

== Changelog ==



== Upgrade notice ==

Sort Icons by Order
Donate Button


== Arbitrary section 1 ==

Thanks for using! Its my first plugin i hope it will help!