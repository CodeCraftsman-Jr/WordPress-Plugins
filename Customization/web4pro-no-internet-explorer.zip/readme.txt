=== Web4pro NoIE ===
Contributors: WEB4PRO_co
Donate link: http://www.web4pro.net
Tags: Kill Internet Explorer, Kill IE, No IE, No Internet Explorer, NoIE
Requires at least: 3.5.1
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
This plugin creates a page which is shown when user is logged from Internet Explorer 6 or 7.
This page offers the user to install new browser and provides the most popular browsers download links.

== Installation ==

1. Upload or extract the `web4pro noie` folder to your site's `/wp-content/plugins/` directory. You can also use the *Add new* option found in the *Plugins* menu in WordPress.
2. Enable the plugin from the *Plugins* menu in WordPress.
3. Now the Web4pro NoIE settings is available on your admin menu.

= Usage =

1. Go to No Internet Explorer menu on your admin page.
2. Enable the plugin (set 'enable').
3. Choose which IE version a plugin can block
4. Click save.

== Screenshots ==

1. Web4pro NoIE settings page
2. Page which user can view when opens a site with Web4pro NoIE plugin from Internet Explorer 6 or 7.

== Changelog ==

= 1.0 =