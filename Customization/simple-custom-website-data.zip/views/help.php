<h3>Advanced Storage</h3>
To store an array use the following syntax:<br>
<ul>
    <li>Seperate keys and values with the equals sign (=).</li>
    <li>Each item on a new line</li>
</ul>
<h4>Example</h4>
<code>
key1=value1 <br> key2=value2
</code>

<h4>Usage</h4>
<code>&lt;?php  cwd_getThe($reference) ?&gt;</code>