<div class="wrap">
    <h2>
        Custom Website Data
        <a class="add-new-h2" href="<?php echo site_url();?>/wp-admin/admin.php?page=cwd-management&view=add">Add New</a>
    </h2>

    <div class="cwd-wrapper">
        <div class="cwd-left">
