=== Themeable Sticky Posts ===

Contributors: husobj
Donate link: http://www.benhuson.co.uk/donate
Tags: widgets, sticky, theme, posts, featured
Requires at least: 3.0
Tested up to: 3.0.1
Stable tag: 1.0

A widget to display featured sticky posts. The built-in template displays a simple list of links, or you can create a template file in your theme for more complex layouts.

== Description ==

More details to follow with the next release.

== Changelog ==

=== 1.0 ===

* First release.

== Frequently Asked Questions ==

Q: What is a sticky post?
A: A sticky post will always show on top of your posts regardless of the post date. It can be used for highlighting a post that you want to remain current.

Q: How do I make a sticky post?
A: When creating or editing a post, in the publish box under the "visibility" options there is an option to make your post sticky.
