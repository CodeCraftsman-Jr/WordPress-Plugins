<?php

echo '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';

?>