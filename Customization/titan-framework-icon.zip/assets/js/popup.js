
jQuery(function() {
    
    jQuery('.icp-auto').iconpicker();
    
});