=== Titan Framework Icon ===
Contributors: onetarek, mrromi-1
Tags: Titan Framework, Font Awesome, Icon
Requires at least: 3.8.0
Tested up to: 4.1.1
Stable tag: 1.1
License: GPLv2+
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add functionality to use Font Awesome Icon as a new type of option field for Titan Framework.

== Description ==

"**[Titan Framework Icon](http://onetarek.com/my-wordpress-plugins/titan-framework-icon/)**" is an addon plugin for the main plugin "Titan Framework". Titan Framework does not have option to add icon chooser field. This plugin adds functionality to use Font Awesome Icon as a new type of option field for Titan Framework.This plugin requires Titan Framework plugin.

**Required:**

*   **[Titan Framework](https://wordpress.org/plugins/titan-framework/)** Plugin.


== Installation ==

= Modern Way: =
1. Go to the WordPress Dashboard "Titan Framework Icon" section.
2. Search For "Titan Framework Icon". 
3. Install, then Activate it.

= Old Way: =
1. Upload the `titan-framework-icon` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.


= How To Use Titan Framework Icon: =
For more detail guide you should **[follow this page](http://onetarek.com/my-wordpress-plugins/titan-framework-icon/)**.

== Screenshots ==

1. Icon Field



== Changelog ==

= 1.1 =
* Simple JavaScript Update

= 1.0 =
* Initial release


== Upgrade Notice ==

= 1.1 =
* Simple JavaScript Update

= 1.0 =
* Initial release