function doReload(OrderBy){
    document.location = '?orderby=' + OrderBy;
}