=== iMeud Auto-hide header ===
Contributors: Main53 Solutions
Donate link: http://www.main53.com/wordpress/
Tags: nav, imeud, scroll top, top, up, scroll to top, scroll up, wordpress scroll up, back to top, link to top, navigation, scroll, scroll back to top, wordpress
Requires at least: 4.1 (not lower test).
Tested up to: 4.1
Stable tag: -
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy auto-hide header bar.

== Description ==
Auto-hide the header bar. covers a theme within nav tag. *Effective with Theme with header tag.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `imeud-auto-hide-header` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
= Supports the following browsers =
Chrome last ver, Internet Explorer 10 or heigher, Firefox or heigher.

== Screenshots ==
1. Preview (Animation)

== Upgrade Notice ==
Initial version.

== Changelog == 

= 1.0 =
* Initial version.