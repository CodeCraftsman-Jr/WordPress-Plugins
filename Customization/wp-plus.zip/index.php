<?php
Header("HTTP/1.1 301 Moved Permanently");
Header("Location: http://blog.lwl12.com");
?>