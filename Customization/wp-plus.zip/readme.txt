﻿=== WP-Plus ===
Contributors: liwanglin12
Donate link: http://lwl12.com/
Tags: wordpressplus, wpplus, 增强, 优化, Enhancement, optimization
Requires at least: 3.0
Tested up to: 4.2
Stable tag: 1.3
License: GPLv2 or later

== Description ==
于是，她，终于来了。<br />
全新的架构，意味着一切都是新的，一切都更专业；<br />
全新的功能，意味着复杂的内心不排斥简约优美的外表；<br />
全新的逻辑，意味着Wordpress能更自由地奔跑、飞翔；<br />
全新的面板，意味着她有了可以真正沟通的心灵。<br />
WP-Plus 是一款免费插件，但我仍会更专注于其稳定性与专业性。<br />

== Installation ==
1. 通过 WordPress 插件库或者手动安装 WP-Plus 并启用
2. 启用后将自动跳转至设置页面，按照需要开启对应功能保存设置即可

== Frequently Asked Questions ==
1. 插件导致博客异常

在插件更新发布之前作者都会进行调试，如果出现了问题可以反馈到http://blog.lwl12.com/read/wp-plus.html，反馈后我会第一时间进行处理。

== Screenshots ==
1. WP-Plus

== Changelog ==
= 1.65 =
[新增]代码高亮
= 1.64 =
[优化]HTTPS兼容性
= 1.63 =
[修复]Gravatar替换BUG
= 1.62 =
[修复]Gravatar替换BUG
= 1.60 =
[新增]启用WP原生链接管理器功能
[恢复]Google API替换功能
= 1.59 =
[新增]低版本IE更新提示功能
= 1.58 =
[移除]禁止自动给文章段落添加p标签<br />
[新增]访客欢迎信息显示（Beta）
= 1.57 =
[新增]使用Bing背景作为登录页背景功能（背景图每日更新）<br />
[新增]禁止自动给文章段落添加p标签<br />
[新增]使用相对链接替换绝对链接<br />
[新增]移除部分风险/无用头部信息<br />
[优化]独立插件设置页PHP<br />

= 1.55 =
[新增]DEBUG中心

= 1.54 =
[修复]计划任务异常的BUG

= 1.53 =
[修复]重大BUG一枚

= 1.52 =
[优化]上报系统

= 1.51 =
[优化]上报系统

= 1.50 =
提交到WordPress插件库的第一个版本，包含基础功能，并优化了代码

== Upgrade Notice ==
= 1.65 =
[新增]代码高亮
= 1.64 =
[优化]HTTPS兼容性
= 1.63 =
[修复]Gravatar替换BUG
= 1.62 =
[修复]Gravatar替换BUG
= 1.60 =
[新增]启用WP原生链接管理器功能
[恢复]Google API替换功能
= 1.59 =
[新增]低版本IE更新提示功能
= 1.58 =
[移除]禁止自动给文章段落添加p标签
[新增]访客欢迎信息显示（Beta）
= 1.57 =
新增大量功能，小伙伴们快来试~

= 1.55 =
[新增]DEBUG中心

= 1.54 =
[修复]计划任务异常的BUG

= 1.53 =
[修复]重大BUG一枚

= 1.52 =
[优化]上报系统

= 1.51 =
[优化]上报系统

= 1.50 =
提交到WordPress插件库的第一个版本，包含基础功能，并优化了代码