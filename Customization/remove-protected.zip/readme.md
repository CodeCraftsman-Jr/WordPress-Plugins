# Remove Protected

Small script that removes "Protected:" from titles of posts and pages that are password protected.

# Changelog

## 1.0.1

- Some re-work as a class-based plugin

## 1.0

- First Release