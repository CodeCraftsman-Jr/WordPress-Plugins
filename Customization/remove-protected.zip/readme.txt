=== Remove Protected ===
Contributors: aubreypwd
Donate link: http://aubreypwd.com
Tags: password, protected, title, remove
Requires at least: 2.7
Tested up to: 4.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Small script that removes "Protected:" from titles of posts and pages that are password protected.

== Description ==

Small script that removes "Protected:" from titles of posts and pages that are password protected.

== Installation ==

Best way to install is using your WordPress Dashboard!

== Changelog ==

= 1.0.1 =

- Some re-work as a class-based plugin

= 1.0 =

- First Release

== Development ==

This plugin is developed over at [Github](https://github.com/aubreypwd/remove-protected) and is deployed here with each release.