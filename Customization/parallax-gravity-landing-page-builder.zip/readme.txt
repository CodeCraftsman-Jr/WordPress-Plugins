=== Parallax Gravity - Landing Page Builder ===
Contributors: sakurapixel
Donate link: http://sakuraplugins.com/donate/
Tags: landing page, wordpress, parallax, marketing, leads, creative
Requires at least: 3.9
Tested up to: 4.3
Stable tag: 2.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Parallax Gravity is a WordPress plugin that allows you to create unlimited landing pages. 

== Description ==

Parallax Gravity is a WordPress plugin that allows you to create unlimited landing pages. With Parallax Gravity you can add multiple sections within each page, for each section you can set a background, add any type of content including shortcodes from third party plugins and much more. Please note that there is also a premium version for this plugin.

[PREVIEW](http://www.sakuraplugins.com/products-list/parallax-gravity-landing-page-builder/)
[SUPPORT](http://sakuraplugins.com/)
[ADMIN VIDEO](http://www.youtube.com/watch?v=V6oss5hfMxc)


== Installation ==

1. Upload the plugin: Plugins > Add new > Upload.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Admin > Parallax Gravity > New Landing Page
4. Go to main menu "Parallax Gravity" > "Options" (edit settings and see shortcodes).
5. Add sections, than add content for each section, you can change the section's order just by drag and drop.

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. Front end screenshot
2. Front end screenshot
3. Front end screenshot
4. Admin screenshot

== Changelog ==

= 1.8 =
* Fix issues caused by WP 4.0
* Update to the latest version of TweenMax animation engine (v 1.13.1)
= 1.5 =
* Admin Bug fix .
= 1.4 =
* Admin Bug fix.
= 1.2 =
* Bug fix.
= 1.1 =
* Bug fix.
= 1.0 =
* First release.

== Upgrade notice ==



== Arbitrary section 1 ==

