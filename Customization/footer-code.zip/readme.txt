=== Plugin Name ===
Contributors: GZep
Donate link: http://gzep.ru/donate/
Tags: footer, code, inject, insert, metrika, analytics
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: trunk
License: MIT
License URI: http://opensource.org/licenses/MIT

Simplest plugin that injects any code into footer of a web page.

== Description ==

Simplest plugin that allow to inject any code into footer of a web page.

This plugin requires at least PHP 5.4

== Installation ==

1. Upload `footer-code` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Inserted your code in Settings > Footer Code
