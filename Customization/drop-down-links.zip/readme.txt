=== Drop Down Links ===
Contributors: mrfroasty
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=admin%40mzalendo%2enet&lc=GB&item_name=MZALENDO%2eNET&item_number=mzalendo&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: links, drop-down
Requires at least: 2.7
Tested up to: 3.0.1
Stable tag: 0.0.5

== Description ==

This widget takes all the links and put them in a drop-down select instead of displaying them as links scattered all over the sidebar.
Its meant to be very light weight and down to earth.

== Installation ==

You install this plugin just like any other WordPress plugin.
The basic way is to extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.


== Frequently Asked Questions ==
-

== Screenshots ==
1.[drop-down-links Screenshots] (http://plugins.svn.wordpress.org/drop-down-links/trunk/drop-down-links.png "Sidebar widget"

== Changelog ==

= 0.0.2 =
* Adds better widget support

= 0.0.3 =
* Fixes the warning on E_STRICT

= 0.0.4 =
* Aug 19, 2010
* Fixes js compatibilities with the WP Image Editing.

= 0.0.5 =
* February 13,2011
* Fixes js compatibility with other libraries

== Upgrade Notice ==
