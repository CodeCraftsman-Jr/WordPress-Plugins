<?php 
/*plugin configs*/
global $wpdb;
$kz_db_version = '1.1.5';
$table_name = $wpdb->prefix . 'cwa';
$charset_collate = '';
?>