=== Remove Howdy ===
Contributors: swadeshswain
Tags: howdy, replace howdy, customize howdy, change howdy , custom text
Requires at least: 3.0
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will Replace the "Howdy" with your custom text in the top right corner of your dashboard. 

== Description ==

This plugin will Replace the "Howdy" with your custom text in the top right corner of your dashboard. 


== Screenshots ==

1. After

2. Befor

3. Option page

== Installation ==

1. Activate 'Replace Howdy' through the 'Plugins' menu in WordPress


1. With and without "Howdy"

== Changelog ==

Version 1.0
Plugin Replace "Howdy" in the dashboard
Version 1.1
Plugin Replace "Howdy" with you custom text.
