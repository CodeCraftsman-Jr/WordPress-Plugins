=== Add custom content after post ===

Contributors: fazua

Tags: disclaimer, author info, custom content 

Requires at least: 3.1

Tested up to: 4.0

License: GPLv2



Add custom content after every post. It'is indicate for add disclaimer, notice, author info.





== Description ==



> Add custom content after every post. It'is indicate for add disclaimer, notice, author info.





= Disclaimer =

 This plugin does require above average technical knowledge.  



= Please Note =

This project is currently in Beta.




== Installation ==



1. Upload `custom_content_after_post` folder to the `/wp-content/plugins/` directory

2. Activate the plugin through the 'Plugins' menu in WordPress

3. Click on the Add Custom Content After Post link from the Setting menu

4. Insert your custom content and click Save.





== Frequently Asked Questions ==








== Screenshots ==

 



 



== Changelog ==













== Upgrade Notice ==































