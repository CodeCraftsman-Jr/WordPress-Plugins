<?php
/**
 * For example
 * Here is the text field rendering
 */
class OptionsBuddy_Settings_Field_Text extends OptionsBuddy_Settings_Field{
    
    
    public function __construct($field) {
        parent::__construct($field);
    }
    
    
    public function render($args) {
        parent::render($args);
    }
}
