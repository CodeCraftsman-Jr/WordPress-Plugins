=== Plugin Name ===
Contributors: ryanyockey
Donate link: http://www.ryanyockey.com/
Tags: oldest, to, newest
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 1.2

Take the oldest post and make it the newest post if there has not been a new post in 24 hours, thereby changing the order on home page and other lists. The number of hours may be adjusted with a simple edit. This should only be activated after you have multiple posts on the website. Updated for wordpress 2.7.

== Description ==

Take the oldest post and make it the newest post if there has not been a new post in 24 hours, thereby changing the order on home page and other lists. The number of hours may be adjusted with a simple edit. This should only be activated after you have multiple posts on the website. Updated for wordpress 2.7. Original at [Rich Hamilton Original Oldest2Newest](http://ryowebsite.com/?cat=11)
== Installation ==

This section describes how to install the plugin and get it working.

1. Edit the plugin and add how many hours until the blog needs a new post. $hours = 24
2. Upload `oldest2newest.php` to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Now its running on its own. Nothing else to do.

== Frequently Asked Questions ==

= How do I know if this is working? =

Set the time to 1 hour and then check back. You will see your oldest post reposted as the newest one. 

== Screenshots ==
