# Change Log

## [1.0.0] - 2015-07-08

### Added

* Added French translation files.
* Created separate `changelog.md` file.

## [0.1.1]

* Fixed for translations where there was a typo in the textdomain.
* Updated plugin file headers.

## [0.1.0]

* Everything's new!