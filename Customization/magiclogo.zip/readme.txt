=== Magic Logo ===
Contributors: slloyd@timequest.org, MagicLogo.net
Donate link: http://www.magiclogo.net/donate
Tags: magic logo, magiclogo, holiday logo, holidays, holiday icons, logo changer, holiday theme, themed logo
Requires at least: 1.1.0
Tested up to: 1.1.0
Stable tag: 1.1.0

Automatically adds holiday themes to your logo that show up for the holidays and go away after they are over.

== Description ==

MagicLogo provided by [MagicLogo.net](http://www.magiclogo.net/ "Magically add holidays to your logo") magically transforms your website's logo on holidays and other special occasions without you lifting a finger. 
Your logo magically transforms into the appropriate festive logo for the current holiday and magically transforms back once the holiday is over. 
That's it! No more having to stay up, or have your web developer stay up, until midnight to change your logo back and forth.

= Simple to use =
MagicLogo is simple to setup and requires almost no maintenance. As long as your account has credits available, it works.

= Do you have suggestions? =
Try our plugin out and let us know what you think.  If you decide not to use it we would love to know why so we can make it better.
Please send your suggestions, likes, dislikes, etc to [suggest@magiclogo.net](mailto:suggest@magiclogo.net)

== Installation ==
1. Install using the install link on WordPress.org
1. Go to [MagicLogo.net](http://www.magiclogo.net/ "Magically add holidays to your logo"), register or sign in
1. Add credits to your account and select the holidays you want
1. Use the logo [link wizard](http://www.magiclogo.net/wizard "Wizard to Magically add holidays to your logo") to give you your new logo src link
1. Change your logo src location to the new src.

== Changelog ==
Magic Logo Version 1.1.0 is now available!
I recommend you update to the latest version.

= Version 1.1.0 - Released on 11/11/2011 =
1. Installs magiclogo.php and supporting files


== Frequently Asked Questions ==
none yet


== Upgrade Notice ==
Magic Logo Version 1.1.0 is now available!
I recommend you update to the latest version.


== Screenshots ==
none yet

