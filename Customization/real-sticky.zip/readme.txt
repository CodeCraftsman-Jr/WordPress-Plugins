=== Real Sticky ===

Contributors: graphicedit
Donate link: http://graphicedit.com/
Tags: quick, easy, simple, free, real, sticky, page, title
Requires at least: 4.2.2
Tested up to: 4.3 
Stable tag: 1.3.1

Import a Sticky page to top of site.

== Description ==

This is a plugin which enables you to show a specific page or a post you choose at the top of your website. 
It enables you to present the page/post always above, even inside the post or categorie(s) page(s) 

Links: [Author Homepage](http://graphicedit.com/)

* Spanish (es_ES) - [Andrew Kurtis](andrewk@webhostinghub.com)


== Installation ==

1. Upload the "Real Sticky" folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Creat a "Page" and add a text(anything)
4. Goto "Real Sticky Options" tab and set-up "Page Title"
5. Done

== Frequently Asked Questions ==
not yet

== Screenshots ==
1. Page Title.
2. Options. 


= Translators =

* Spanish (es_ES) - [Andrew Kurtis](andrewk@webhostinghub.com)


== Upgrade Notice ==
not yet

== Changelog ==

= 1.2.2 =
* Minor code tweaks 

= 1.2.1 =
* Added a "Page Name/Title" select option  

= 1.2.0 =
* Added a CSS control  
* Added a option "page"


= 1.1.1 =
* Initial release


