=== Category Image ===
Contributors: pankajanupam
Tags: Category Image, admin, texonomy image, category icon
Requires at least: 2.8
Tested up to: 4.1
Stable tag: 1.4

The Category Image Plugin allow you to add image with category.

== Description ==

The Category Image Plugin allow you to add image with category.

Use sortcode [print-image] to display category images.

You can also use this <?php echo print_image_function(); ?> any where in your template.

== Installation ==

You can install Category Image directly from the WordPress admin panel.

	Visit the Plugins > Add New and search for 'Category Image'.

	Click to install. 
	
	Once installed, activate and it is functional.


Manual Installation Category Image plugin:

    Download and unzip the file

    Upload the full extracted folder to the /wp-content/plugins/ directory
    * Maintain the directory structure of the archive (all extracted files
        should exist in 'wp-content/plugins/category-image/'

    Activate the plugin through the 'Plugins' menu in WordPress.

You're done! The Plugin ready to use according to the directions in the description.


= More documentation =

Go to [http://pankajanupam.in/wordpress-plugin/category-image](http://pankajanupam.in/wordpress-plugin/category-image)

== Frequently Asked Questions ==

None

== Screenshots ==

None

== Changelog ==

= 2.0 =
add support tag

= 1.5 =
add support tag

= 1.4 =
add support tag

= 1.3 =
add shortcode support [print-image]

= 1.2 =
javascript bug fix

= 1.1 =
javascript bug fix

= 1.0 =
first Release