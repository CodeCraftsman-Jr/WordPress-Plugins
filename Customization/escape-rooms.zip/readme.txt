=== Plugin Name ===
Contributors: Simosf
Donate link: http://www.waza.gr/escape-rooms/
Tags: escape, room, booking, escape room, escape rooms
Requires at least: 4.1.1
Tested up to: 4.1.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Escape Room Booking plugin for Wordpress

== Description ==

Escape Room Booking plugin for wordpress. Made for those Escape Room companies that want to list several rooms they have to their customers and finalize a booking.  Features: <br>1. Unlimeted number of rooms <br>2. Customization of each room with the details and specific hours and duration the room is available <br>3. Booking form

== Installation ==

To install the plugin please follow the following steps. If you have any problems, we'd be happy to assist by contanting us!

1. Add the plugin (zip file) through the Plugins>Add New>Upload Plugin
2. Make a page for your menu and add shortcode [escape-rooms] inside
3. Your navigation bar must me assigned a menu, as the plugin will add two pages called 'ESCAPE ROOM BOOKING PAGE' & 'ESCAPE ROOM DETAILS PAGE' and these need to be hidden from your top menu
4. The plugin is responsive and will play with any theme that is bootstrap 3 friendly. Will still work for non-bootstrap themes.

== Frequently Asked Questions ==

= Can i contact you if there is some feature missing or i cannot make it work ? =

It is our first plugin and it must be pretty basic. But we are very happy to take any critisism and help you by installination or adding more features that you may need.

= What about the price? =

This plugin is free to use.

== Screenshots ==

1. List of Escape Rooms
2. Details screen of a Escape Room
3. Booking Form for a specific escape room

== Changelog ==

= 1.0 =
* This is our initial release.

== Upgrade Notice ==

= 1.0 =
This is our initial release.