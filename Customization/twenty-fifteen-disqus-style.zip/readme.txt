=== Twenty Fifteen Disqus Style ===
Contributors: abrudtkuhl
Tags: twenty fifteen, disqus comments,
Requires at least: 3.9
Tested up to: 4.1.2
Stable tag: trunk
License: GPL
License URI: https://raw.githubusercontent.com/abrudtkuhl/twentyfifteen-disqus/master/LICENSE

Style Disqus Comments Plugin for use in the Twenty Fifteen theme.

== Description ==
A plugin that styles the Disqus Comments Plugin for use in the Twenty Fifteen theme.

Inspired by http://www.alexdresko.com/2014/12/23/fixing-disqus-in-the-wordpress-twenty-fifteen-theme

== Installation ==
Install and activate from the WordPress plugin repository

== Changelog ==
0.3 - finally fixing the CSS path...  
0.2 - Fix CSS path
0.1 - Plugin Release
