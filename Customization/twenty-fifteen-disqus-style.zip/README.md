# Twenty Fifteen Disqus Style
A plugin to make Disqus comments work with the Twenty Fifteen WordPress Theme

CSS styles from [@alexdresko](https://github.com/alexdresko) on this [Blog Post](http://www.alexdresko.com/2014/12/23/fixing-disqus-in-the-wordpress-twenty-fifteen-theme/)
