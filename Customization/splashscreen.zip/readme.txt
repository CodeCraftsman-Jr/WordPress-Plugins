=== Splashscreen ===
Contributors: djpushplay
Donate link: http://cochinoman.com/2009/02/16/wordpress-plugin-for-splash-screen/
Tags: splashscreen, splash screen, splash page
Requires at least: 2.3.1
Tested up to: 2.7
Stable tag: 0.20

Display a splash screen before allowing visitor to see blog.

== Description ==

Display a splash screen to give information, or to direct your visitor to different areas of the site, before they get to the wordpress blog.

The administrator can use different templates for the splash screen.

== Installation ==

1. Extract the zip file content after download and copy the directory "splashscreen" to the plugin directory located at "wp-content/plugins". 2. Login as administrator and enable "Splashscreen" via plugin tab.
3. Click on Splashscreen under Settings tab to configure Splashscreen.

== Frequently Asked Questions ==

= Are there more documentation? =

Yes.
http://cochinoman.com/2009/02/16/wordpress-plugin-for-splash-screen/

== Screenshots ==

1. Screen shot of the setting screen.
2. Sample output of the splash screen using the default template.

