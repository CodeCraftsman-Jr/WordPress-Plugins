<?php 
/**
 * Easy Custom Sidebars Admin Page Closing Container
 *
 * This file contains the closing the tags for the 
 * html settings page.
 * 
 * @package     Easy_Custom_Sidebars
 * @author      Sunny Johal - Titanium Themes <support@titaniumthemes.com>
 * @license     GPL-2.0+
 * @copyright   Copyright (c) 2015, Titanium Themes
 * @version     1.0.5
 * 
 */
?>
</div><!-- /.wrap -->