=== Plugin Name ===
Contributors: jnewmano, truthislight
Donate link: http://www.mattlsmith.com/
Tags: sidebar,quotes
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

LDS Quotes inserts quotes from LDS conference talks and the Book of Mormon into you blog's 
sidebar, posts, and/or pages.

== Description ==

LDS Quotes is a plugin and widget that displays your favorite quotes from The Book of Mormon, General Conference, and other sources. Within the plugin you can select from a variety of LDS categories you want to display quotes from. You can then add the widget to your website or embed a small piece of code that puts the quotes anywhere on your website.

Quotes are download from quote.mattlsmith.com.

== Installation ==

Search and click install.

== Frequently Asked Questions ==

= Where do these quotes come from? =

The quotes are from the Book of Mormon and General Conference talks and are downloaded from quote.mattlsmith.com

== Screenshots ==


== Changelog ==

= 2.0 =

Initial public release.

== Upgrade Notice == 

No issues.