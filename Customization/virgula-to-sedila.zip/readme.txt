=== Virgulă To Sedilă ===
Contributors: radubilei
Tags: română, diacritice, sedilă, virgulă 
Requires at least: 2.0
Tested up to: 2.9
Stable tag: 0.1.1

Înlocuieşte diacriticele "corecte", cu virgulă, cu cele "incorecte", cu sedilă, dar care se afişează corespunzător şi în Windows XP.

== Description ==

Înlocuieşte diacriticele "corecte", cu virgulă, cu cele "incorecte", cu sedilă, dar care se afişează corespunzător şi în Windows XP.

Inspirat de plugin-ul lui John Kilroy, XHTML to HTML - http://www.kilroyjames.co.uk/2008/07/xhtml-to-html-wordpress-plugin/

== Installation ==

1. Upload `virgulaToSedila.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it!

