<?php

class DMPPanelWPSoaVisMain       extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('WP SoaVis');
    }
}
