<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://www.soavis.eu
 *
 * @package    WP_SoaVis
 * @subpackage WP_SoaVis/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
