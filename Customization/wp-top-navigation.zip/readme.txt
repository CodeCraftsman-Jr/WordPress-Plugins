=== WP Top Navigation ===
Contributors: sdellow
Donate link: http://hellostew.com
Tags: navigation, top, scroll
Requires at least: 3.8
Tested up to: 4.2
Stable tag: 1.4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Puts the WordPress admin navigation at the top of the screen providing more screen estate for the rest of WordPress.

== Description ==

WP Top Navigation puts the WordPress admin navigation at the top of the screen providing more screen estate for the rest of WordPress. Its non-destructive nature still allows for a responsive admin area.

Works with WordPress admin theme colours.

== Installation ==

1. Upload `wp-top-navigation` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. There are no settings! Just enjoy.

== Frequently Asked Questions ==

== Screenshots ==
N/A

== Changelog ==

= 1.4.0 =
* Improvements
* Fixed issue on some installs with admin page not being clickable.
= 1.3.0 =
* Fixes and improvements.
= 1.2.1 =
* Formatting
= 1.2.0 =
* Released

== Upgrade Notice ==

= 1.4.0 =
* Released
= 1.3.0 =
* Released
= 1.2.1 =
* Released
= 1.2.0 =
* Released
