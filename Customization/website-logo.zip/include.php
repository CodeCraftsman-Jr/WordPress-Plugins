<?php
	$url =plugins_url();
?>
<link href="<?php echo $url;?>/website-logo/css/ri_main_style.css" rel="stylesheet"/>