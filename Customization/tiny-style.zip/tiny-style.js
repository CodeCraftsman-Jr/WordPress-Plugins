tinyMCE.loadPlugin('style', "../wp-content/plugins/tiny-style/style");
