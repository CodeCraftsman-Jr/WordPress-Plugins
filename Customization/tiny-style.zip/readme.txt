=== Tiny Style ===
Contributors: tompahoward
Donate link: http://windyroad.org/software/wordpress/tiny-Style/#donate
Tags: Formatting, post, admin, editor, style, html, Windy Road
Requires at least: 2.2
Tested up to: 2.2
Stable tag: 0.0.1

The Tiny Style plugin re-adds style editing support to the TinyMCE Rich Visual Editor

== Description ==

The Tiny Style plugin re-adds style editing support to the TinyMCE Rich Visual Editor.
The TinyMCE style plugin is normally bundled with TinyMCE, but it has be removed from the
version within WordPress.  This plugin puts it back in.

Most of the credit for this plugin belogns to [Moxiecode Systems] (http://tinymce.moxiecode.com/ ),
who wrote the style plugin for TinyMCE, which this plugin uses.

== Installation ==

1. copy the 'tiny-style' directory to your 'wp-contents/plugins' directory.
1. Activate the Tiny Style in your plugins administration page.
1. You will now see a style button when using the the TinyMCE Rich Visual Editor.

== Screenshots ==

1. Tiny Style in Action

== Frequently Asked Questions ==

Got any questions?

== Release Notes ==
* 0.0.1
	* Added workaround for TinyMCE compressor issues.
* 0.0.0 
	* Initial Release