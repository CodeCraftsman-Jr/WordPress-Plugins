DX-Remove-Unused-CFs
====================

Remove unused custom fields left from deleted posts

Go to Settings -> Remove Unused CF. The page lists all post IDs where post meta exists, but these posts are no longer available in the posts table.
