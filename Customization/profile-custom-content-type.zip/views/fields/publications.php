<?php 
/**
 * profile_cct_publications_shell function.
 * 
 * @access public
 * @param mixed $options
 * @param mixed $data (default: null)
 * @return void
 */
function profile_cct_publications_shell( $options, $data = null ) {
	Profile_CCT_Textarea::shell( $options, $data );
}