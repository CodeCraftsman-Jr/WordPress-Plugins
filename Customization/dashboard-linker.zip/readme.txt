=== Dashboard linker ===
Contributors: SPaiS Inc.
Link: http://spais.co.jp/
Tags: dashboard, link
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 0.1.0

== Description ==

Create a link to the dashboard

== Installation ==

1. Unpack the *.zip file and extract the /dashboard-linker/ folder and the files.
2. Using an FTP program, upload the /dashboard-linker/ folder to your WordPress plugins directory (Example: /wp-content/plugins).
3. Open your WordPress Admin panel and go to the Plugins page. Locate the "Dashboard Linker" plugin and click on the "Activate" link.
4. Once activated, go to the Dashboard admin section.

== Frequently Asked Questions ==

You can now view the FAQ in the documentation: http://spais.co.jp/%E3%83%97%E3%83%AD%E3%83%80%E3%82%AF%E3%83%88-product/wordpress/dashboard-linker/

== Changelog ==

= 0.1.0 =
* First release.

== Usage ==

Full Usage instructions and documentation can be found here: http://spais.co.jp/%E3%83%97%E3%83%AD%E3%83%80%E3%82%AF%E3%83%88-product/wordpress/dashboard-linker/