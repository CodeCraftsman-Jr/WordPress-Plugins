=== WP No Base Permalink ===
Contributors: 23r9i0
Donate link:
Tags: permalink, base, category, tag, parents, categories, parents categories
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 0.2.3
License: GPL/MIT

Removes base from your category.
Removes parents categories in permalinks (optional).
Removes base tag in permalinks (optional).

== Description ==

Removes base from your category and tag in permalinks (optional) and remove parents categories in permalinks (optional). WPML and Multisite Compatible.
Add Rewrites for oldest categories or tags base.

== Installation ==

1. Upload the 'wp-no-base-permalink' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure optional settings in permalink page.


== Changelog ==
= 0.2.3 =
* Update Tested Version
* Add Disabled plugin update on PHP 5.3, last updated Require 5.4 or later
= 0.2.2 =
* fix constant developer
= 0.2.1 =
 * Update code for personal options (developer)
= 0.2 =
 * Fix 404 in not latin letters ( tested locally)
 * Fix 404 for not admin users
= 0.1 =
 * init version

== Upgrade Notice ==
= 0.2.3 =
Add Disabled plugin update on PHP 5.3, last updated Require 5.4 or later