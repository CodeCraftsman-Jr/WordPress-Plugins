=== Warna Rainbow ===
Contributors: Klick Arie
Donate link: http://warna.tk/
Tags: Link, hover, Beautiful
Requires at least: 4.0.1
Tested up to: 4.0
Stable tag: 0.9.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 This is a plugin to provide a rainbow effect on the current link on hover

== Description ==

 This is a plugin to provide a rainbow effect on the current link on hover.
 you just need to install and activate the plugin without the need to add a script , the link in your wewsite already can be made into a rainbow effect when in hover

== Installation ==


1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How can i use this for texts =

you can, only add <a> for begin the write a text for you want make rainbow effect.
 

== Screenshots ==

 

== Changelog ==

`<?php code(); // goes in backticks ?>`
