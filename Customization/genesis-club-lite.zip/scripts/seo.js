
function genesis_club_confirm_delete($name) {
	return confirm("You are about to delete "+$name+" permanently.\n Press `Cancel` to stop, `OK` to delete." );
}