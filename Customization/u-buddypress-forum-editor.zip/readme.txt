=== U BuddyPress Forum Editor ===
Tags:

This plugin has been moved to 
https://wordpress.org/plugins/bp-forum-editor/