=== Customizer Remove All Parts ===
Contributors: peterdog, parallelus, pmgllc
Tags: customizer, remove, remove customizer, prevent
Requires at least: 3.4
Tested up to: 4.4-alpha
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Customizer Remove All Parts plugin allows you to get the Customizer out of your WordPress install.

== Description ==

The Customizer Remove All Parts plugin allows you to get the Customizer out of your WordPress install. It prevents any Customizer scripts from loading and removes all links and buttons to Customizer in the dashboard and admin toolbar.

== Installation ==

Upload the plugin to your WordPress plugins directory, or use the dashboard to 'Add New' plugins and activate it. That's it! No options needed. Customizer is gone.

== Changelog ==

= 1.0.4 =
*Update - 14 July 2015*

* Changed priority of remove_action for JavaScript

= 1.0.3 =
*Update - 24 June 2015*

* Capability filter returns empty array

= 1.0.2 =
*Update - 17 June 2015*

* Output at activation removed
* Simplified plugin structure

= 1.0.1 =
*Bugfix - 13 June 2015*

* Activation bug with some plugins

= 1.0.0 =
*Release Date - 11 June 2015*

* Initial Release