=== نویسه‌های پارسی سپیدمان ===
Contributors: zartosht
Donate link: http://www.sepideman.com
Tags: Themes, Fonts, BYekan, IranianSans, BBCNassim, GE SS MEDIUM, Persian, فونت, سپیدمان, نویسه
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

تبدیل تمام فونت‌های تم شما به فونت‌های محبوب به سادگی.

== Description ==

افزونه فونت های پارسی سپیدمان با ارائه یک پنل مجزا به شما امکان می‌دهد تا فونت‌های هر پوسته ای را به فونت های محبوب پارسی تغییر دهید.
در حال حاضر فونت های: Iranian-Sans, BYekan, BBCNassim و GE SS MEDIUM.

برای پیدا کردن شناسه و یا نام هر المان می‌توانید از منوی Inspect Element مرورگر خود استفاده کنید. برای تغییر جزئی می‌توانید روی المان کلیک راست کرده و با استفاده از بخش Copy Unique Selector ادرس دقیق انتخاب یک المان را کپی کنید.

نویسه‌ی ایران‌سریف در نمایش نقطه سوم حروف سه نقطه پایین مثل «پ» مشکل دارد و در حال بروزرسانیست. در صورت انتشار نسخه جدید این نویسه در افزونه جایگذاری می‌شود.

* http://www.SecuritExperts.com
* http://www.Sepideman.com
* http://www.ZartoshtSepideman.com

* fb/SecuritExperts
* insta/SecuritExperts
* insta/ImenWeb
* G+/+ImenWeb
* twitter/SecuritExperts

== Installation ==

1. پوشه `sepideman-persian-fonts` را در پوشه افزونه های وردپرس `/wp-content/plugins/` بارگذاری کنید.
1. افزونه را در منوی افزونه ها فعال کنید.

== Changelog ==

= 1.5.0 =
حذف فونت وب‌یکان به دلیل درخواست ناشر فونت و جایگزینی فونت ایرانیان (http://soozanchi.ir). حذف کدکوتاه (shortcode) از افزونه.

= 1.0.0 =
انتشار نسخه اولیه فونت های پارسی سپیدمان

== Upgrade Notice ==

= 1.5.0 =
حذف فونت وب‌یکان به دلیل درخواست ناشر فونت و جایگزینی فونت ایرانیان (http://soozanchi.ir) توجه داشته باشید با بروزرسانی فونت وب یکان از بین می‌رود و فونت ایرانیان جایگزین آن می‌شود. حذف کد کوتاه. لطفا کد کوتاه را از صفحه یا ابزارک خود حذف کنید، دیگر نیازی به استفاده از کد کوتاه نیست.

== امکانات ==

1. اولویت نصبت به تمام افزونه ها و پوسته ها
1. استفاده آسان