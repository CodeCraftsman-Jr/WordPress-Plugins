=== Advanced Custom Facebook Likebox Widget ===

Plugin URI: http://www.sparxseo.com
Author Name : Alan Ferdinand
Author URL : http://www.sparxseo.com
Tags: advanced custom facebook likebox widget, wordpress widget, advanced facebook, custom facebook, facebook likebox, facebook widget, facebook for wordpress, facebook widget for wordpress, super customizable facebook likebox
Requires at least: 3.0.1
Tested up to: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Advanced Custom Facebook Likebox Widget is free facebook likebox display widget. Using this widget you can show facebook connections on your wordpress website.

== Description ==

Thanks for installing our developed wordpress widget.
Everybody enjoys corresponding with friends, sharing photos, and posting comments. Technology has truly played a momentous role in today’s age, and it has spread to all nations. Technology has evolved significantly over time, once very simplistic, and now, highly innovative and complex. In previous years, technology was a precious commodity intended for the elite and wealthy. Now, it can be accessed by individuals of all socioeconomic classes. 
Facebook has disseminated rapidly throughout the world, and many Facebook users are highly addicted to this interface. 
Facebook is widely acclaimed as one of the best online, social networking interfaces to ever grace the web. Facebook has harnessed an unparalleled level of popularity. 
Using this module is very easy.

Features of Advanced Custom Facebook Likebox Widget

	* Can set a custom background on your facebook likebox.
	* Many customizable options you can ever think can possible with facebook likebox before.
	* Highly Customizable - as well can easily make tons of changes from backend.
	* Work with most of recent wordpress released versions.
	* Responsive - it make sure you able to enjoy our widget on mobile devices as well.
	* Two color schemes available.

== Installation ==

Check the documentation folder. or go here - http://sparxseo.com/documentation/advanced-custom-facebook-likebox-widget.html

== Frequently Asked Questions ==
 Contact us for any kind of support - admin@sparxseo.com

== Screenshots ==

1. Frontend Screenshot
2. Backend Screenshot

== Changelog ==

= 1.0 =
Stable version release - 19th March 2014

= 1.1 =
simple bug fixes

= 1.2 =
simple bug fixes
can show facebook page stream now