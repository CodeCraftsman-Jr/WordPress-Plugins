=== RH Devnia Webfonts ===
Contributors: waheeds
Tags: web fonts, fonts, arabic, bootstrap
Requires at least: 3.9
Donate link: 
Tested up to: 4.1
Stable tag: 2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

this plugin is change your body font with devnia web fonts service if yout site was in arabic language.

== Description ==



You may through this plugin to change your font in your arabic Web site using a modern fonts Devina Web Font Service

A few notes about the sections above:

*   with out change any thing or write code in theme
*   just choose font and save option
*   fonts are hosted by maxcdn and files will dont lose or be offline
*   you can preview font after select
*   tetsed up to wordpress 4.1


== Installation ==



1. Upload `rh-devnia-arabic-webfonts` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to  `RH Devnia webfonts` in your setting

== Frequently Asked Questions ==


= my site in not arabic can i use it? =

no you can use it if your site in arabic .

== Screenshots ==

1. Plugin Overview.

== Upgrade Notice ==

no thing here...

== Changelog ==

= 2.0 =
* add preview font in admin.

= 1.0 =
* First plugin release.

