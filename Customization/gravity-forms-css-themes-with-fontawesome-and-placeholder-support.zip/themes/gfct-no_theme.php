<?php
function gfct_no_theme_theme(){
    $output = '/*  
    Name : No Theme Theme
   Description: This theme does not output anything
   ------------------------------------------------
   */';
return $output;
}