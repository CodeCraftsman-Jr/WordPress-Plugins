jQuery(document).ready(function($){
    $('.gfct-color-field').wpColorPicker();
});