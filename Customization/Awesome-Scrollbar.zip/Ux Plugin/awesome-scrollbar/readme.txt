=== Awesome-WordPress-ScrollBar  ===
Tags: ScrollBar   awesome, free ScrollBar  ,best ScrollBar ,wordpress ScrollBar  ,wp ScrollBar  ,awesome ScrollBar  ,best wordpress ScrollBar  ,free ScrollBar.
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

 This plugin will create awesome custom ScroolBar in your wordpress site.You can change any settings of this ScrollBar from Option Panel.
 
 Demo: http://hf-it.org/plugins/scrollbar-test/


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Screenshots ==

1.  Logo
2.  Option Panel 
3.  Option Panel &  Settings details
4.  Unlimited Color
5.  Live Demo 1
6.  Live Demo 2
7.  Live Demo 3
8.  Live Demo 4
9.  Live Demo 5
10. Live Demo 6
11. Live Demo 7


== Changelog ==

= 1.0 =
* Initial Release

