=== Custom Upload Folders Plus ===
Contributors: John Wight
Tags: media, upload, folder, custom upload folders
Requires at least: 3.8
Tested up to: 4.2
Stable tag: 1.0.4
License: GPLv2 or later

Organize file uploads by File Type (mov, gif, png, mp3...) and Logged in user (nickname, first-name, last-name...).

== Description ==
Organize file uploads by File Type (mov, gif, png, mp3...) and Logged in user (nickname, first-name, last-name...).

== Installation ==

**From Your WordPress Dashboard**  
1. Visit 'Plugins -> Add New'  
2. Search for 'Custom Upload Folders Plus'  
3. Activate 'Custom Upload Folders Plus' from your Plugins page.  
4. Visit 'Settings ->  Media'  

**From WordPress.org**  
1. Download Custom Upload Folders Plus  
2. Unzip and upload the 'Custom Upload Folders Plus' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate 'Custom Upload Folders Plus' from your Plugins page.  
4. Visit 'Settings ->  Media'  

**Uninstall**  
The plugin option will be deleted via unsinstall.php.  

== Screenshots ==  
1. You can organize your media by associating your folder name with mime types  
2. You can also organize media via user name, nickname, first name, last name.  

== Changelog ==

Version 1.0.4  
BugFix: filter fix

Version 1.0.3  
BugFix: Fix Multisite

Version 1.0.2  
Add: auto populate select2 dropdown with logged in user data  
Add: drag sorting for logged in user data   
   

Version 1.0.1  
Fix bug: "Parse error: syntax error, unexpected '['" reported by: Anilarya947  

Version 1.0  
Plugin Launched  



 