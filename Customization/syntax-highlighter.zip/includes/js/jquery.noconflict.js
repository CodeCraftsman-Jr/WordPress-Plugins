(function(A){if(typeof A!=="undefined"){A.noConflict()}})(jQuery);
