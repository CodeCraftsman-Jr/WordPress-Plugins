<?php
/*
 * Description: Custom post type funxtions
 * Author: Wangbin
*/

	function custom_test(){
		
	}
?>
