=== Search box on Navigation Menu ===

Contributors: re_enter_rupok
Donate link: http://www.rupok.me/donate
Tags: menu, search, search box, search box on menu, navigation menu
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin will add the default search box on main navigation menu that will save the space and flexibly fit with the menu. 
Here you can get more information about this plugin with screenshots - http://www.rupok.me/projects

== Installation ==

1. Upload `Search box on Navigation Menu` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==


Q: Is it will add the default search box of my theme?

A: Yes, This plugin will just add your default search box on navigation menu.

Q: Can I able to change the style of the search box?

A: Yes you can! But you have to just change the style of your theme's search style (may be on search.php and style.css)

Q: Is it flexible to add on any theme?

A: This will flexibly add search box on those theme which dosen't have search box on navigation menu.


== Screenshots ==

1. When you activate this plugin you will get the default search box of your theme on the main navigation menu. 
2. Here you can get more information about this plugin with screenshots - http://www.rupok.me/projects

== Changelog ==

= 1.1 =
* Some attributes added to fit on most of the theme.

== Upgrade Notice ==

= 1.1 =

* Some attributes added to fit on most of the theme.