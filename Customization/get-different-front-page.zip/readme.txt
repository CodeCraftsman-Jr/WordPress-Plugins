=== GET Different Front Page ===
Contributors: theode
Tags: home, page, front, custom
Requires at least: 3.0
Tested up to: 4.3.1
Stable tag: 0.11
License: GPLv2 or later

Have different primary menus for different viewers.

== Description ==

I once thought I need a different home page for different viewers.
In best case those users have a GET parameter which decides which page has to be shown.

For Example: 
You go into WordPress and add a page with a name of your choice (in this case the page slug). I chose "music".
Now if you want somebody view the music page you have the parameter http://www.example.com/?view=music.
You can do this with every page you have.

In case you leave it empty nothing happen at all.

== Installation ==

1. Upload 'GET-Different-Front-Page' folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Frequently asked questions ==

= Where can I get support? =
Contact us at http://www.wp-plugin-dev.com/support-contact/


== Changelog ==

= 0.1 =  Initial release
