=== Storefront Jetpack ===

Contributors: pootlepress, nickburne
Plugin Name: Storefront Jetpack
Plugin URI: http://www.pootlepress.com/storefront-jetpack
Tags: storefront, store front, storefront jetpack, storefront extensions, store front extensions, storefront align menu right, storefront logo, store front logo, storefront custom logo, storefront plugins, store front plugins
Author URI: http://www.pootlepress.com
Author: PootlePress
Donate link:
Requires at least: 4.1.0
Tested up to: 4.2.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

This plugin gives you lots of options for customizing the WooThemes Storefront theme for WooCommerce.

== Usage ==

Install and activate the plugin. In your WordPress dashboard simply go to Appearance > Storefront Jetpack and there you will find various modules you can enable or disable for Storefront.

== Installation ==

Installing "Storefront Jetpack" can be done either by searching for "Storefront Jetpack" via the "Plugins > Add New" screen in your WordPress dashboard, or by using the following steps:

1. Download the plugin via WordPress.org.
2. Upload the ZIP file through the "Plugins > Add New > Upload" screen in your WordPress dashboard.
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Visit the settings screen and configure, as desired.

== Frequently Asked Questions ==

== Screenshots ==

1. Main settings page under Appearance > Storefront Jetpack

== Upgrade Notice ==

= 0.1 =
* 2015-04-06
* Initial release. Woo!

== Changelog ==

= 0.1 =
* 2015-04-06
* Initial release. Woo!
