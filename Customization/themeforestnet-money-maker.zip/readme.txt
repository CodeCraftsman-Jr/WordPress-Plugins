===Themeforest.net Money Maker===
Contributors: djjmz
Requires at least: 3.6
Tested up to: 4.1
Stable tag: 1.0.1
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WYDR4ADESD2KU&lc=LT&item_name=Donate&no_note=1&no_shipping=1&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: themeforest, make, money, referral

== Changelog ==
= 1.0.0 =
* First Release

== Description ==
Simple way earn more money from you web page. In widget show newest Wordpress themes from themeforest.net and you get % from every referral.
- 

== Installation ==

1.  Upload TMM folder to plugins folder.

2.  Go to Plugins menu and active.

3.  Widget show newest themes in sidebar.

4.  Go to Themeforest.net and create new account.

5.  New account username write in Themeforest.net Money Maker widget settings (widget settings example you can see in screenshot.png picture).



== Frequently Asked Questions ==

= Can I use this plugin for Free? =

Yes absolutely.





