=== JinMenu ===
Contributors: aniketan
Donate link: http://buffernow.com/donate/
Tags: jquery code in menu, onclick in wp menu, javascript, wp menu, jQuery, onclick event
Requires at least: 3.4.1
Tested up to:  4.2.2
Stable tag: 1.3.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
The Jin Menu adds onclick event in wordpress custom menu,so that you can use your javascript/jQuery code from wordpress menu.
== Description ==
The Jin Menu adds onclick event in wordpress custom Menu, so that you can use your javascript/jQuery code from wordpress menu.
Features:
* Add Onclick In Wordpress Custom Menu.
* No Extra Panel.
* Just Activate and write your code in Custom menu.
For support and further information about the JinMenu plugin see the plugins homepage at [http://buffernow.com/jinmenu-faq/](http://buffernow.com/jinmenu-faq/ "Link to JinMenu faq").
== Installation ==
If you have ever installed a WordPress plugin, then installation will be pretty easy:
1. Download the JinMenu plugin archive and extract the files
1. Copy the resulting jinMenu directory into /wp-content/plugins/
1. Activate the plugin through the 'Plugins' menu of WordPress
1. Configure blog and user settings if needed
For support and further information about the JinMenu plugin see the plugins homepage at [http://buffernow.com/jinmenu](http://buffernow.com/jinmenu "Link to JinMenu Homepage").
== Screenshots ==
1. Insert javascript function directly from wordpress menu
2. Menu admin panel
== Frequently Asked Questions ==
= Where do I get support and further information =
For support and further information about the JinMenu plugin see the plugins homepage at [http://buffernow.com/jinmenu-faq/](http://buffernow.com/jinmenu-faq/ "Link to JinMenu faq").
== Changelog ==
= 1.2.1 =
* Plugin Panel Removed
* No extra js ,CSS
* Textbox replaced with multiline textarea
* Option will appear only on custom menu
* compatibility with WordPress 3.8.1. 
= 1.1.1 =
* compatibility with WordPress 4.2.2
* fix multi execution if multiple menu
= 1.2.1 =
* Plugin Panel Removed
* No extra js ,CSS
* Textbox replaced with multiline textarea
* Option will appear only on custom menu
* compatibility with WordPress 3.8.1. 
= 1.1.1 =
* jQuery bug fix
* Remove unnecessary js and css
* Increase performance
* compatibility with WordPress 3..2. 
= 1.1.0 =
* css bug fix
* js on footer bug fix
* Added option to insert javascript function directly from wordpress menu
* auto load jquery if not loaded in theme.
= 1.0  =
* Initial public release.
== Upgrade Notice ==
this is first version of jin menu.