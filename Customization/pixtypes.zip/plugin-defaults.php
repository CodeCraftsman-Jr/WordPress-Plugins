<?php return array
	(

	# Hidden fields

		'settings_saved_once' => '0',

	# "Post Types" fields
	'enable_portfolio' => true,

		'portfolio_single_item_label' => 'Project',
		'portfolio_multiple_items_label' => 'Projects',

		'portfolio_change_single_item_slug' => true,
		'portfolio_new_single_item_slug' => 'portfolio',

		'portfolio_change_archive_slug' => false,
		'portfolio_new_archive_slug' => '',

//		'portfolio_use_tags' => false,

	'enable_gallery' => true,
		'gallery_change_single_item_slug' => true,
		'gallery_new_single_item_slug' => 'gallery',

		'gallery_change_archive_slug' => true,
		'gallery_new_archive_slug' => 'galleries',
	# "Taxonomies" fields
		'enable_portfolio_categories' => true,
			'portfolio_categories_change_archive_slug' => true,
			'portfolio_categories_new_archive_slug' => 'portfolio_category',
		'enable_gallery_categories' => true,
			'gallery_categories_change_archive_slug' => true,
			'gallery_categories_new_archive_slug' => 'gallery_category',

		'enable_portfolio-type' => true,
			'portfolio-type_change_archive_slug' => true,
			'portfolio-type_new_archive_slug' => 'project-type',

		'enable_portfolio-tag' => true,
			'portfolio-tag_change_archive_slug' => true,
			'portfolio-tag_new_archive_slug' => 'project-tag',

	); # config
