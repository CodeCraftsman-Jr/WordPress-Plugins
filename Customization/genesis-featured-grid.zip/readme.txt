=== Plugin Name ===
Contributors: HeavyDigital
Donate link: http://www.HeavyDigitalCreative.com/
Tags: genesis, grid, featured, posts, widget
Requires at least: 2.0.2
Tested up to: 3.1
Stable tag: 1.0

Genesis Featured Grid adds a Genesis Featured Grid widget with grid layout functionality

== Description ==

Genesis Featured Grid adds a Genesis Featured Grid widget with grid layout functionality. It works almost identically to the Genesis Featured Posts widget by StudioPress, but displays the posts in an a grid of 2 posts across and 
a user selectable number of posts down.

This plugin requires the Genesis Theme Framework

== Installation ==

   1. Upload the entire genesis-featured-grid folder to the /wp-content/plugins/ directory
   2. Activate the plugin through the .Plugins. menu in WordPress
   3. Go to the Widget Screen
   4. Drag the Widget to the desired sidebar
   5. Enter widget settings

== Frequently Asked Questions ==

== Upgrade Notice==

== Screenshots  ==

== Changelog ==

= 1.0 =
* Initial Release

