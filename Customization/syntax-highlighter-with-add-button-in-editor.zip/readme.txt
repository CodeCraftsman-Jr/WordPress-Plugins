=== Syntax Highlighter++ ===
Contributors: leo108
Donate link: http://leo108.com/
Tags: editor, syntax , highlighter , code , syntax-highlight , syntax-highlighter , syntax-highlighter++ , highlight
Requires at least: 2.0
Tested up to: 3.8.0
Stable tag: 2.5.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

You can add code with syntax highlighter easily when you are editing an article.
方便的代码高亮插件。

== Description ==

This plugin not only provides you syntax-highlighter , but also add a textarea and a button in the post page .
you just have to select the language , add code to the textarea and click the 'OK' button , and you will get
your code highlighted in your atricle.
这个插件不仅仅提供了代码高亮，还在编辑页面增加了一个代码框和一个按钮，你只要选择好你的代码语言，把代码贴入代码框，
再点击一下OK按钮，你的带高亮的代码就会被插入到文章里去。

Supported Languge:
	Bash
	C
	C++
	C#
	CSS
	Delphi
	Diff
	Erlang
	Groovy
	HTML
	Java
	Javascript
	Perl
	PHP
    PowerShell
	Python
	Ruby
	SQL
	VisualBasic
	VB.NET
	XML

== Installation ==

1. Upload all files to your Wordpress plugins directory, usually `wp-content/plugins/` .
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Done.

== Screenshots ==

1. Your code will be similar to this in you article.
2. The textarea and button in your post page .
3. Settings .

== Frequently Asked Questions ==

[Leave your FAQ](http://leo108.com/pid-1304.asp)

== Changelog ==

2.5.0: Fix display problem in 'Media'->'edit'

2.4.2: Add some editor support , thanks to huangzhiqun(http://huangzhiqun.com/).

2.4.1: Fix the bug , when you change the tagName , it doesn't work.

2.4.0: Fix some bugs after update .

2.3.1:Adjust some syntax .

2.3.0:Roll back the SyntaxHighlighter core to version 2 , but preserve the AutoLoader.js to load .js file dynamically .

2.2.0:Update SyntaxHighlighter to version 3.0.83 && add option page .

2.1.0:Compress css and js files to make it faster .

2.0.3:Change the Core.css to make line auto-break , but still has some problem with firefox .

2.0.2:Fix a bug .

2.0.1:Add 'Other' type .

2.0:Improve the compatibility to the new version of wordpress .

1.1.0:Improve the compatibility to all editors.

== Upgrade Notice ==

= 2.3.1 =
Important ! Please Reactive This Plugin After Upgrade .

= 2.3.0 =
Important ! Please Reactive This Plugin After Upgrade .

= 2.2.0 =
Important ! Please Reactive This Plugin After Upgrade .
