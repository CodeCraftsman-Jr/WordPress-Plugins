=== Plugin Name ===
Contributors: Eraph
Tags: final fantasy, final fantasy xi, ffxi, ff11, character, profile
Requires at least: 2.9.2
Tested up to: 2.9.2
Stable tag: 1

This plugin adds a widget that displays information on your Final Fantasy XI character.

== Description ==

This plugin adds a widget that displays information on your Final Fantasy XI character. The information is entered using the provided profile editor, under the 'Appearance' menu in your WordPress administration. Quick updates to your character (including main job level and a small status field) can be entered using the Dashboard widget.

== Installation ==

1. Upload the 'final-fantasy-xi-character-profile' folder into the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress administration.
3. Add the widget to your page using the 'Widgets' menu.

== Frequently Asked Questions ==

= Why aren't there any questions yet? =

No-one's asked any questions! Questions and suggestions can be left on the [project page](http://wp.rakhama.com/projects/ffxi-character-profile/).

== Screenshots ==

1. An example widget. The information shown here does not include all configurable properties (e.g. sub-job, as my character does not yet have a sub-job, or linkshell).
2. Part of the profile editor.

== Changelog ==

= 1.0 =
* Released!

== Upgrade Notice ==

= 1.0 =
First version!