=== Wordpress Remove Post Attachment ===
Contributors
Tags: media, post, image, remove, attachment
Requires at least: 3.7.0
Tested up to: 3.8.1
License: MIT
License URI: https://github.com/romainberger/wordpress-remove-post-attachment/blob/master/LICENSE.md

Adds a "detach from post" link on attachments so you can remove it from the post without deleting the file.

== Description ==

Adds a "detach from post" link on attachments so you can remove it from the post without deleting the file.

Wordpress doesn't give a simple way to add links in the media lightbox, so this plugin does its thing in a pretty hacky way. If it stops working or if you see any issue, please create an issue precising the Wordpress version you're using.

== Installation ==

Simply upload the plugin (as a zip) from the extension page.

== Screenshots ==
1. Detach an attachment
