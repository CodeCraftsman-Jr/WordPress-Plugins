<?php

//	prevent direct access
if ( ! defined( 'ABSPATH' ) )  
	die( 'Direct access to this script is not allowed!' );

echo '<p><strong>' . __( 'Values copied from the right to the left panel.', 'fpw-category-thumbnails' ) . '</strong></p>';
die();
