<?php
//	prevent direct access
if ( ! defined( 'ABSPATH' ) )  
	die( 'Direct access to this script is not allowed!' );

echo '<p><strong>' . __( 'Values copied from the left to the right panel.', 'fpw-category-thumbnails' ) . '</strong></p>';
die();
