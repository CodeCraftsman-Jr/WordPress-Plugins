
/*
 * @package WP Toolbar Removal
 * @subpackage External JS Enqueue Script
 * @branche 2014
 * @build   2014-08-15
 * @since   3.7+
 * @tested  3.9+
 * @version 2014.0816.0392
 * @target  2014.1210.0410
 * @status STABLE (trunk) release
 * @development Code in Becoming!
 * @author slangjis
 * @license GPLv2 or later
 * @indentation GNU style coding standard
*/

	/**
	 * Please contact me @ slangji.wordpress.com/contact/
	 * to know how to get this file and test new features
	 * that will be developed offline on github.com/slangji
	 */


