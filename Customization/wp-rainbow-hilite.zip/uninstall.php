<?php

delete_option( 'wprainbow_load_minified' );
delete_option( 'wprainbow_languages' );
delete_option( 'wprainbow_theme' );
delete_option( 'wprainbow_line_numbers' );