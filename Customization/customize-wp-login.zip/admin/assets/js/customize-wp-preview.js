jQuery.noConflict();
jQuery(document).ready(function ($) {
	
	jQuery('#preview_login_image_button').click(function() {
	 	tb_show('Customize WP-Login Preview', '../../wp-login.phpTB_iframe=true');
	 	return false;
	});
        }); 

