(function($) {
  "use strict";

  $(function() {
    $('#tabs').tabs();
    // Place your administration-specific JavaScript here

  });

}(jQuery));
