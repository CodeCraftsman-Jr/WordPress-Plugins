jQuery(document).ready(function(){
    if (typeof delay !== 'undefined') {
        setTimeout(function(){
            jQuery('#simple-sticky-footer-container').effect( effect, 500 );
        },delay);
    }
});  