=== Custom Sitemap Template ===
Contributors: anil.oxzin 
Donate link: http://www.divyanshiinfotech.com/
Tags: wordpress, sitemap, template
Requires at least: 4.2
Tested up to: 4.2.4
Stable tag: 1.0.1
License: GPLv2 or later

Plugin provides a custom sitemap template. You can fully customize your sitemap using plugin settings.

== Description ==

Plugin provides a custom sitemap template. You can fully customize your sitemap using plugin settings.

== Installation ==

  
1. Upload \`custom-sitemap-template-plugin\` to the \`/wp-content/plugins/\` directory  
2. Activate the plugin through the 'Plugins' menu in WordPress  
3. Assign 'Custom Sitemap Template' on any page where you want to display sitemap.


== Screenshots ==

1. Sitemap plugin admin settings.

2. Sitemap page template view 1.

3. Sitemap page template view 2.


== Frequently Asked Questions ==

= Can I customize sitemap layout? =

Yes you can easily customize sitemap layout as required.

= Can I exclude any post/page from sitemap? =

Yes you can exclude any post/page/taxonomy by put its id in exclude named input field from plugin settings page..

== Changelog ==

= 1.0.1 =
* Release Date: June 30, 2015
* Fixed null value bug.

= 1.0 =
* Release Date: June 18, 2015
* First version of plugin.

== Upgrade Notice ==

= 1.0 =
This is first version of plugin.
