===Atomic Penguins Mind-Blowing Hover Effects ===

Contributors: hesusko
Plugin Name: Mind Blown
Tags: Hover, Effects, animate.css
Author URL: atomicpenguins.com/wordpress
Author: Atomic Penguins
Version: 1.1.3
License: GPLv2 or later
Donate link: none
Tested up to: 4.2
Requires at least: 4.1.1
Stable Tag: 1.1.3

==Description==

The Mind.Blown plugin is a hover effect plugin. You can customize the effect of the hover entrance, the text inside the div, the title of the hover div and the link for the hover div. This is a great plugin if you want to create several links with special hover effects.

Free Version

Features 
<li>6 entrance animation</li>
<li>Main Box Customization</li>
<li>Hover Box Customization</li>

Contact developer at john@atomicpenguins.com for the premium version.


Premium Version

Features
<li>31 Entrance Features</li>
<li>Main Box Customization</li>
<li>Hover Box Customization</li>

==Installation==

1. Upload plugin.zip to wp/content/plugins directory
2. Activate the plugins through the 'Plugins' menu in Wordpress Admin
3. A new menu titled 'Hover Effect' will be added to the side menu. Click it and start working with your first hover effect.



== Changelog ==
= Version 1.1 =
* Font size on hover title
* Font size on hover content
* Font spacing on hover content

= Version 1.1.1 = 
* Bug Fix

== Frequently Asked Questions ==

= Is the plugin output responsive =

Yes it is.

= What about the admin view? =

It is responsive as well.

== Upgrade Notice ==
= Version 1.1 =
* Upgrade of Version 1

= Version 1.1 = 
*Bug Fix


== Screenshots ==
1. UI for the admin view.
2. List of hover projects stored on the database.