=== Plugin Name ===
Contributors: royaltechbd
Donate link: http://royaltechbd.com/donate.html
Tags: Royal, Custom CSS, CSS, Page, Post
Requires at least: 3.3
Tested up to: 4.2.2
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will give a custum css option for every page and post separately.


== Description ==

Royal Custom CSS for Page and Post

### Features
* Easy to use
* Light weight
* No need to configure



### More
* Thank you for using our plugin.
* Vist the [blog post](#) to know more.
* [Give a Rating & Write a Review](#)


== Installation ==


1. Upload the plugin to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use #rtdate, #startdate, #enddate, #eventdate IDs to show date picker


### Examples:



== Frequently asked questions ==

= Is this custom CSS globally =

No, Custom CSS for separately by post or page IDs.


== Screenshots ==
1. How Custom CSS use for Page/Post.


== Changelog ==
= 1.1 =
* Version update

= 1.0 =
* Initial release


== Upgrade notice ==
= 1.1 =
* Version update

= 1.0 =
It is Initial release