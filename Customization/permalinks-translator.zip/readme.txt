=== Permalinks Translator ===
Contributors: andyhot
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5BE4P5J6CQVUG
Tags: permalink, title
Requires at least: 2.9.0
Tested up to: 2.9.2
Stable tag: 0.5.1

Translates your permalinks in the language of your choice.

== Description ==

Translates your permalinks.

Useful for languages such as greek, where you can write your title as normal and instead of greek or greeklish, you want to use translated permalinks.

Translation languages are configurable.

== Installation ==

1. Upload `permalinks-translator` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Configure the desired languages from the 'Settings' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==
