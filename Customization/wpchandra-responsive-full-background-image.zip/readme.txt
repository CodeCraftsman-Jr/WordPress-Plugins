=== Responsive Background Image ===
Contributors: chandrakeshkumar, wp-chandra
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2V34FUDP29MLC
Tags: wordpress resposnive, responsive, full background, responsive background, background
Requires at least: 3.0
Tested up to: 4.2.3 
Stable tag: 1.0.1 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy way to add fixed resposive background image to your blog & website. This plugin helps you to easy to add resposive background image.

== Description ==

### Responsive Full Background                                                              

Easy way to add fixed resposive background image to your blog & website. This plugin helps you to easy to add resposive background image!

### Find Us on Social Media

* [Facebook](https://www.facebook.com/pages/WPChandra-To-Start-for-Web-Development/325741047605388?fref=ts)
* [Twitter](https://twitter.com/webchandra)
* [LinkedIn](https://www.linkedin.com/company/wpchandra)


== Installation ==

* Upload 'wpchandra-responsive-full-background-image' folder to the '/wp-content/plugins/' directory.
* Activate the plugin through the 'Plugins' menu in WordPress.
* Go to Appearance menu > Responsive Full Background Image.
* Enter your background image url or upload your image.
* Click on 'Save Changes' button.
* After all injoy this plugin.

== Frequently Asked Questions ==

There are no FAQ just yet

== Screenshots ==

1. Enter your background image url or upload your image.
2. After all see results like!
