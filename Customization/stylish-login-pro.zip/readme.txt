=== Plugin Name ===

Contributors: Rimaz Rauf
Plugin Name: Stylish Login Pro
Plugin URI: http://blog.rimazrauf.com/free-wordpress-login-plugin-stylish-login-pro/
Tags:  admin, branding, custom login, custom login pro, customization, login, logo
Author URI: http://www.rimazrauf.com
Author: Rimaz Rauf
Requires at least: 2.0.1
Tested up to: 4.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Version: 1.5 

Stylish Login Pro is a simple modern plugin I made so that I could customize the login screen on my own websit.

== Description ==

Stylish Login Pro is a simple modern plugin I made so that I could customize the login screen on my own website by utilizing in-built WordPress functions and the WordPress media uploader.

Stylish Login Pro allows you to customize your admin by adding your own logo to the header. It also replaces the WordPress logo on the login screen with the same custom logo. Also it gives a modern Flat UI to the Login page.

If you are a web developer you can even edit the CSS manually if you like.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the directory /custom-login-logo/ to the /wp-content/plugins/directory or Simply upland the Zip file to you site.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on the Settings link below the plugin name on the plugins page to add your custom logo for the login screen and favicon.

== Screenshots ==

If you are a web developer you can even edit the CSS manually if you like.