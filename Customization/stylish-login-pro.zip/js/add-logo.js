( function($) {
    $( '.wrap' ).prepend( '<div id="admin-logo"><img src="' + add_logo_image + '" alt="" /></div>' );
} )( jQuery );