;(function($){

    $(document).ready(function(){
        //some code here pls :)
    });

})(jQuery);