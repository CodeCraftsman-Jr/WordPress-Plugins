=== WP-Parsi Admin Font Editor ===
Contributors: Ghaem
Tags: admin, admin font, font, wordpress font, change font, parsi font, fonts, persian, persian fonts, persian font, admin font editor, wp-parsi admin font editor
Requires at least: 3.7
Stable tag: 4.1
Tested up to: 4.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Change WordPress dashboard font

== Description ==

Change WordPress dashboard font

= List of some features: =
* Settings Page
* The ability to choose the font size
* Select a font from the available fonts in plugin
* Change fonts of WordPress admin
* Preview of the selected font(s) and font size

= Tested on =
* PC Firefox
* PC IE
* PC Chrome

= Support Forum =
http://forum.wp-parsi.com/

== Installation ==

1. Upload 'parsi-font' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on the new menu item "Parsi Font" and see settings of this plugin.
4. Or you can install the plugin in: "Plugins ==> Add ==> enter the name of plugin (WP-Parsi Admin Font Editor) in search box and press Enter
5. Install plugin, activate it and enjoy of plugin 

== Frequently Asked Questions ==

= Q. How to use this plugin? = 
A. To use this plugin you should only install plugin, select your custom font in settings page, save changes and refresh page.

== Screenshots ==

1. Settings Page with B Homa and Comic Sans MS fonts.
== Changelog ==

= 1.0 =
* Start Plugin
= 2.0 =
* Change codes of plugin
= 3.0 =
* Solve a problem
= 3.9.1 =
* Change style of settings page
* Add Feedback form
= 4.0 =
* Add new fonts
* Add font pack (.zip) for download
= 4.1 =
* Add new fonts