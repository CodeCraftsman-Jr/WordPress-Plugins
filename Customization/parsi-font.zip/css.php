
   html .mceContentBody, body, p {  
        font-size: <?php echo $_GET['size'];?>px;
        font-family: <?php echo $_GET['font'];?>;       
        
    }
    
