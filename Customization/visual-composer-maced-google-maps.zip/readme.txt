=== Visual Composer Maced Google Maps ===
Contributors: macerier
Tags: Visual Composer, Visual Composer Addon, google maps, address
Requires at least: 4.0
Tested up to: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simply creates google maps with Visual Composer or via shortcode.

== Description ==

This plugin extends Visual Composer so you can easily create sleek Google maps on your website.

[Developer on Google+](https://plus.google.com/114124611804630905228 "Developer on Google+")

== Installation ==

1. Download the plugin and unzip it.
2. Upload the folder vc-maced-gmap/ to your /wp-content/plugins/ folder.
3. Activate the plugin from your WordPress admin panel.
4. Installation finished.

== Screenshots ==

None yet. :(


== Changelog ==

= 1.0 =
* Initial release