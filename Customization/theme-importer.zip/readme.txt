=== Theme Importer ===
Contributors: Stev
Donate link: Give it to charity.
Tags: themes, import, copy, ftp, 3rd party
Requires at least: 3.8
Tested up to: 4.2.3
Stable tag: trunk
License: GPLv2 or later

Import theme zips from Wordpress.org and other websites into your themes folder.

== Description ==

Located in the Appearance menu (Import), Theme Importer lets you enter a theme URL in the import field, click the Import button and it 

will be copied into your theme folder. No need to download the theme first then upload it. One simple button click is all that's required.

#### Top features
* Saves time manually downloading themes and uploading theme's into Wordpress
* Very fast import speeds

#### Languages/translations

The plugin is available in English:


#### Donation and more plugins
* If you like this plugin checkout more. If you want to donate, give it to charity.
* Check out some [more WordPress Plugins & Software](http://www.stevs.net/plugins/) by the same author.

== Installation ==

1. Upload the theme-importer.zip - Plugins > Add New > Upload New
2. Activate the plugin through the "Plugins" menu in WordPress
3. Done!


== Screenshots ==

1. Visit http://www.stevs.net/plugins/theme-importer/

== Frequently Asked Questions ==

=Are there any frequently asked questions? =

Not yet

== Changelog ==

= 0.1 =
- It's alive!

== Upgrade Notice ==

=1.0=