=== Hower effect for Links ===
Contributors: kamlesh4kumar
Donate link: 
Tags: Link Hover effect, Links hover animation, Link button hover effect, Link css3 hover effect
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 4.2
License: GPLv2 or later

Hover effect plugin is to create hover effect for links and Link buttons

== Description ==

**Hover effect plugin is to create hover effect for links and Link buttons



== Installation ==

Please follow the steps below.

Step 1: Download Hover Effect Plugins

Step 2: Login to your wordpress website admin panel

Step 3: Unzip hover-effect.zip and Upload online-booking-engine directory to the /wp-content/plugins/ directory

Step 4: Activate the plugin through the 'Plugins' menu in WordPress

Step 5:          Plugin allow to set to 2 type of hover button effects for link

                    Hover effect type:   
                    1. sub-a
                    2. sub-b    
                               
                   To use hover effect for links  [hoverbtn class="hover effect type" hrefvalue="page or website url" ]Text to dispay[/hoverbtn]

                   Set effect value in class
                   Set Page or website url in hrefvalue
                   Replace your link text with Text to dispay

                   eg.  [hoverbtn class="sub-a" hrefvalue="http://www.google.com" ]Google[/hoverbtn] <br><br>

== Screenshots ==
    
== Frequently Asked Questions ==