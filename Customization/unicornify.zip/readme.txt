=== Unicornify ===
Contributors: Otto42
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=otto%40ottodestruct%2ecom
Tags: unicorn, otto42, avatar, unicornify, gravatar
Requires at least: 2.9
Tested up to: 3.0.1
Stable tag: trunk

== Description ==

Changes all gravatars into algorithimically generated pictures of unicorns. See http://unicornify.appspot.com for more information.

== Installation ==

1. Upload the files to the `/wp-content/plugins/unicornify/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= I get some kind of error. =

You have a plugin or theme that is interfering with WordPress' normal avatar generation method. Find it and then fix it or remove it. 

This plugin is unsupported, don't email me about it.

== Changelog ==

= 0.1 =

* First, and probably only, version.