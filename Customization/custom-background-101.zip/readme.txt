=== Custom Backgrounds ===

Contributors: jacky.smith5858
Donate link: http://www.mycolorcopies.com/
Tags: Background, Background Changer, background color, bg-color, background image changer 
Requires at least: 3.4
Tested up to: 3.5.1
Stable tag: 1.1
License: GPLv2

This is a highly customizable Background image uploader, background color plugin. You can set background image, background color, background reapet options.

== Description ==

This is a highly customizable Background image uploader, background color plugin. You can set background image, background color, background reapet options.

We developed this for our printing company which prints things like flyers, brochures, posters and banners for real estate agents etc. Figured we would share it :-)


For more details, please visit: http://www.avincos.com

== Installation ==

1. Download the plugin
2. Upload the `custom_background` folder to the `/wp-content/plugins/` folder
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. This is how the slider will look on you post or page.
2. Go to wp-admin/admin.php?page=page=bc_options to configure the slider.

== Changelog ==


= 1.1 =
* Added background image option, background color.


