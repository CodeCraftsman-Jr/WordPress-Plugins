== For Translators ==

If you have created a translation, please either submit it via WP-Translations at https://www.transifex.com/projects/p/smooth-scroll-up/ or email it to me at <kouratoras@gmail.com> so I can include it with the next release.

Thanks!
