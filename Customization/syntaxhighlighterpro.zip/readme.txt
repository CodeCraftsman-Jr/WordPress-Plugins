=== SyntaxHighlighterPro ===
Contributors: Joe
Donate link: http://www.blogcube.org/
Tags: Code,Code Snippet,Syntax Highlighter
Requires at least: 2.0.2
Tested up to: 2.9.1
Stable tag: 1.1

SyntaxHighlighterPro is a wordpress plugin which uses the [SyntaxHighlighter](http://alexgorbatchev.com/wiki/SyntaxHighlighter "Syntax Highlighter") to highlight code snippets.

== Description ==
[Live demo](http://www.blogcube.org/wordpress-plugins/syntax-highlighter/syntaxhighlighterpro-demo/)  
SyntaxHighlighterPro is a wordpress plugin which uses the SyntaxHighlighter to highlight code snippets.
Major features:
   * Support up to 24 languages, including Java,C++,C#,Php,JavaScript,Groovy,Ruby,Python,Perl,XML,SQL etc.
   * Support up to 5 theme styles, that are Default,Django,Eclipse,Emacs,FadeToGrey,Midnight,RDark. You can easily change the theme in plugin settings.
   * Allow you to choose what languages will support, which is great to avoid unnecessary JavaScript imports. 
   * BBCode support

[More Description](http://www.blogcube.org/wordpress-plugins/syntax-highlighter/syntaxhighlighterpro/)  
[Document](http://www.blogcube.org/wordpress-plugins/syntax-highlighter/syntaxhighlighterpro-document/)  
[Live demo](http://www.blogcube.org/wordpress-plugins/syntax-highlighter/syntaxhighlighterpro-demo/)  

== Installation ==

1. Unpack the *.zip file and extract the /syntaxhighlighterpro/ folder. Drop the 'autolinks' folder into your 'wp-content/plugins' folder.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Setup options through 'Settings/Syntax Highlighter Pro' menu in WordPress.

== Changelog ==
= 1.0 =
First stable release version.
