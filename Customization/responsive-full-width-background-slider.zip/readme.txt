=== Responsive Full Width Background Slider ===
Contributors: wptreasure
Donate link: http://www.wptreasure.com
Tags: wordpress slider, wordpress slider plugin, responsive slider, rotator, background slider, background image slider, responsive full width background slider, slider, image slider, full width background slider, full page background slider, full width image slider, slideshow, responsive slideshow, responsive rotator, jquery slider, javascript slider, jquery rotator, javascript rotator, picture slider, photo rotator, wordpress slideshow, photo slider, responsive picture slider, photo gallery, wordpress photo gallery
Requires at least: 3.5.0
Tested up to: 4.0
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Awesome Responsive Full Width Background Slider Plugin for full screen slide show in background of your WordPress site.

== Description ==

Awesome Responsive Full Width Background Slider Plugin for WordPress provides you a very attractive full screen slide show in background of your WordPress site.

= Features =
* Can define a place where to show or where not to show a slider through out the site.  
* Can set Slide Duration between multiple slides.  
* Can set Transition speed of slides.
* Can show/hide navigation(Next/Previous),bullets and toggle slider button.
* Can toggle a slider to show it on front of the screen.
* Can set the position of navigation bar to show it on left side of screen or to show it on right side of screen.
* Can set Auto play to rotate a slider automatically.
* Can change the slide animation type that is fade / slide.
* Can set overlay screen over image.
* Can add multiple images to rotate as a slider.
* Can re-order slides via simply Drag & Drop method.
* Can arrange a slides in a random order.

== Installation ==

* Upload the plugin folder to the /wp-content/plugins/ folder of your WordPress installation.  
* Activate the plugin.   
* You will see an option at the left side WordPress options option panel named "RFWB Slider".  
* Click on it to set the options.
Enjoy it......  


== Frequently asked questions ==
= A question that will be asked by users =

== Screenshots ==
1. The admin settings page.
2. Page/Post Meta Checkbox.

== Changelog ==

=Version 1.0.5=

* Removed Iframe from admin settings.

=Version 1.0.4=

* Comatible with the WordPress latest version (4.0).
* Fixed slider css issues.
* Fixed slider enable/disable issue in page/post editor.

=Version 1.0.3=

* Fixed Fade animation issue in few browsers.

=Version 1.0.2=

* Added random slides option in admin settings.

=Version 1.0.1=

* Fixed slider css issues.
* Fixed single image disappear issue.

=Version 1.0.0=

* Initial Release

== Upgrade notice ==

* Initial Release

== Arbitrary section 1 ==