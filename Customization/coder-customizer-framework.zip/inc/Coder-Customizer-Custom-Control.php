<?php
$coder_current_path = plugin_dir_path( __FILE__ );
require_once trailingslashit( $coder_current_path ) . '/custom-control/coder-radio-image-control.php';
require_once trailingslashit( $coder_current_path ) . '/custom-control/coder-category-control.php';
require_once trailingslashit( $coder_current_path ) . '/custom-control/coder-post-dropdown-control.php';
require_once trailingslashit( $coder_current_path ) . '/custom-control/coder-tags-dropdown-control.php';
require_once trailingslashit( $coder_current_path ) . '/custom-control/coder-user-dropdown-control.php';
