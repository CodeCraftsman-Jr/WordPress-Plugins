=== Custom post types and taxonomies manager ===
Contributors: pravdomil
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=BCL2X3AFQBAP2&item_name=CustomPostTypesMan%20vine
Tags: CPT, custom, custom post types, Post, post type, tax, Taxonomy, types
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: trunk

Admin UI for creating custom post types and custom taxonomies in WordPress.

== Description ==

Install the plugin, click on Post types in admin menu and get started!

If you will find this plugin very helpful, you can buy me <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=BCL2X3AFQBAP2&item_name=CustomPostTypesMan%20vine">a vine</a>.

== Screenshots ==

1. Admin panel
2. Manage Post type
3. Manage Taxonomy

== Changelog ==

<a href="https://github.com/Pravdomil/wp-custom-post-types-man/commits">GitHub</a>

== Installation ==

Same as others.

== Frequently Asked Questions ==

Not yet.

== Upgrade Notice ==

Will be fine.
