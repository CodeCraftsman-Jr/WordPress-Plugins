<tr id="field_<?php print $data['i']; ?>" class="inactive" style="color:gray;">
    <td><?php print $data['name']; ?></td>
    <td><?php print $data['label']; ?></td>
    <td><?php print $data['type']; ?></td>
    <td><em><?php _e('Already Defined', CCTM_TXTDOMAIN); ?></em></td>
</tr>