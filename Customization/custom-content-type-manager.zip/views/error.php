<div class="wrap">
    <div class="warning"><?php print $data->msg; ?></div>
</div>