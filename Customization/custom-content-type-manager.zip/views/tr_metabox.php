<tr id="cctm_custom_field_<?php print $data['id']; ?>" class="active">
	<td class="plugin-title"><a href="?page=cctm&a=edit_metabox&id=<?php print $data['id']; ?>"><?php print $data['title']; ?></a></td>
	<td class="column-description desc"><?php print $data['context']; ?></td>
	<td class="column-description desc"><?php print $data['priority']; ?></td>
</tr>