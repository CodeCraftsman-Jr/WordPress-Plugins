<?php

/**
 * Provide a admin footer view for the plugin
 *
 * @link       http://www.69signals.com
 * @since      0.1
 * @package    Signals_Maintenance_Mode
 */

?>

	</div><!-- .signals-fix-wp38 -->
</div><!-- .signals-cnt-fix -->