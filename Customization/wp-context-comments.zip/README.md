# WP Context Comments

Working Prototype for a Wordpress Plugin which enables you to attach comments to inline text.

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
