jQuery(function( $ ){

  $(".site-header").after('<div class="bumper"></div>');

});
