<?php

/**
 * Provides a dashboard view if needed.
 *
 * @link       http://supercustomizer.com
 * @since      1.0.0
 *
 * @package    Geneis_Super_Customizer
 * @subpackage Geneis_Super_Customizer/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
