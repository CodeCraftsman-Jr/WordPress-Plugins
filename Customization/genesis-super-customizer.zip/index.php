<?php // Silence is indeed very golden.
