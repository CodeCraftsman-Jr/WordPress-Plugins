=== Custom Private Post ===
Contributors: allarem
Donate link: http://amzn.com/w/D4WJ5SD3PW5W
Tags: private,post,custom
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 1.0.1

License: GPLv2 or later

Make your Private Post customizable

== Description ==

Make your private post customizable, which can be setup in General Setting easily. You can even use specified tags to make each of private posts different. If you like this plugin please vote it, donations are very welcome and also ANY bug-reports and suggestions(you can post in wordpress forum).



== Installation ==

Upload the Custom private post plugin to your blog, Activate it.
You've done it !

== Screenshots ==

1. Option in General Setting, Easy to Post
2. Show in index(default setting)

== Languages ==
If you like to translate this plugins, the .po files(translation file) in the "languages" directory under plugin directory. 
 after you've translated it please send it to wordpress(at)mengzhuo.org, and attach with po file name by what your language called in English.

== Changelog ==
= 1.1 = 

REMOVE:checkbox2boolean for a little bit effiency 

= 1.0 =
Brand New start

