<?php
/**
 * A basic module with the id 'header'.
 *
 * @package Elastic
 * @author Daryl Koopersmith
 */
class Header extends Module {
	function __construct() {
		parent::__construct('header');
	}
}

?>