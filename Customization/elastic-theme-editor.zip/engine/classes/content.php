<?php
/**
 * A basic module with the id 'content'.
 *
 * @package Elastic
 * @author Daryl Koopersmith
 */
class Content extends Module {
	function __construct() {
		parent::__construct('content');
	}
}

?>