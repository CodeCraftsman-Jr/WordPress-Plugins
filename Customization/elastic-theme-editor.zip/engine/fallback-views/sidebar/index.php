<div id="<?php echo $module->id ?>-widget-area" class="widget-area aside">
	<ul class="xoxo">
		<?php dynamic_sidebar($module->id); ?>
	</ul>
</div>