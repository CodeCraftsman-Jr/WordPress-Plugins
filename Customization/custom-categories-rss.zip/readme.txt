=== Custom Categories RSS ===
Contributors: JohnnyPea
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=FUT8H7SGMYE5E
Tags: rss, feed, custom feed, categories, 
Requires at least: 2.8
Tested up to: 2.9.2
Stable tag: 0.1

Grab RSS only from specific categories.

== Description ==
Really simple plugin allowing visitors to grab RSS only from specific categories. 

I am open to suggestions to improve the plugin !

**Note that you must enable permalinks to use this plugin !**

== Installation ==
**Note that you must enable permalinks to use this plugin !**

1. Upload `custom-category-rss` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Use widget "Custom Categories RSS Widget" or `[ccrss exids='X']` (replace "X" with a comma separated list of category IDs you want to exclude if you want display all leave it blank) shortcode in page/post content or place `<?php cc_rss_front_form( $exids = 'X'); ?>` (replace "X" with a comma separated list of category IDs you want to exclude if you want display all leave it blank) in your templates

== Frequently Asked Questions ==

= Can I use your plugin ? =

Yes, of course.

= Can I email you with the support questions ? =

No. Please use integrated forum support system.

= Do you provide some extra "premium" customization ? =

Yes. You can email me in this case.


== Screenshots ==

Simple checkbox form layout.

== Changelog ==

= 0.1 =
initial release

== Upgrade Notice ==

= 0.1 =
initial release