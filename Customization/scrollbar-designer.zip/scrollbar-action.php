<?php 
 add_action('wp_head', 'scrollbar_add_scripts_to_head');
?>