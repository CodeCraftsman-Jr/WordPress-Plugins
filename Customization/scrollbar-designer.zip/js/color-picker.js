jQuery(document).ready(function() {
	jQuery('.color_picker').wpColorPicker();
});