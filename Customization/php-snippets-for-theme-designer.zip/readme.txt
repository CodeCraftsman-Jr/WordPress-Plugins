=== Plugin Name ===
Contributors: ounziw 
Donate link: http://pledgie.com/campaigns/8706
Tags: category, admin, dashboard, php
Requires at least: 3.7
Tested up to: 4.3
Stable tag: trunk

PHP Snippets for Theme Designer

== Description ==
This plugin diplays a is_page()/is_category()/is_tag() snippet for page/category/tag list. You can go to the page/category/tag list in the admin area, and you can copy one (and paste it to a theme file).

== Installation ==
Copy the folder and files into your plugin directoy, and activate it.

== Screenshots ==

1. Page
2. Category
== Changelog ==

= 5.0 =
supports child theme
= 4.1 =
fixed bug. (same name on different folder)
= 4.0 =
add wp_enqueue_script / wp_enqueue_style snippet
= 3.2 =
add prefix for function name
= 3.1 =
add category/tag link
= 3.0 =
support custom post type
= 2.0 =
add get_page_link
= 1.0 =
New Release
