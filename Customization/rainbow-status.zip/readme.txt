=== Rainbow Status ===
Contributors: meabhisek
Tags:   admin, dashboard, status, post, page, color, draft, pending, published, scheduled
Requires at least: 3.0
Tested up to: 4.3
Stable tag: 1.0.1
License: GPLv2

Different background colors for Draft, Pending, Published, Scheduled and Private posts/pages.


== Description == 

Let Rainbow Status help you visually manage your WordPress publishing.Install Rainbow Status to get separate background colors for Draft, Pending, Published, Scheduled and Private posts/pages.Small plugin, big impact.


Follow the developer on [Twitter](https://twitter.com/twitabhisek)
Visit [Developer Website](http://increasy.com)

**Download My Other Plugins**

* [Mini Membership](https://wordpress.org/plugins/mini-membership/)
* [Private Content Login Redirect](https://wordpress.org/plugins/private-content-login-redirect/)
* [Romance Admin Color Scheme](https://wordpress.org/plugins/romance-admin-color-scheme/)
* [Frame Breaker](https://wordpress.org/plugins/frame-breaker/)
* [Inspire Dolly](https://wordpress.org/plugins/inspire-dolly/)


==Installation== 

1. Download Rainbow Status package file, extract rainbow-status directory from ZIP file, upload it to WordPress Plugins directory '/wp-content/plugins/' or install plugin from Plugin panel in WordPress Dashboard.

2. Activate Rainbow Status via Plugin page.                 

3. Check out the Rainbow.

If you are new to WordPress : [Installing Plugins](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins)

== Changelog ==

= 1.0.1 =

* A small tweak
* Tested with WordPress 4.2.4
