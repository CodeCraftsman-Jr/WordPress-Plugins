<?php
/* 
Plugin Name: Favicon Rotator
Plugin URI: http://archetyped.com/tools/favicon-rotator/
Description: Easily set site favicon and even rotate through multiple icons
Version: 1.2.5
Author: Archetyped
Author URI: http://archetyped.com
*/

require_once 'model.php';
$fvrt = new FaviconRotator();