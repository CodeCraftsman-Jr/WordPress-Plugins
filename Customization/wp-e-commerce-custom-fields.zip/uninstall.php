<?php
$prefix = 'wpsc_cf';

delete_option( $prefix . '_data' );
?>