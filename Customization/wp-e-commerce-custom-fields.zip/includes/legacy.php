<?php
if( !is_admin() ) {

	/* Start of: Storefront */

	function wpsc_cf_the_custom_fields( $args = null ) {

		wpsc_the_custom_fields( $args );

	}

	/* End of: Storefront */

}
?>