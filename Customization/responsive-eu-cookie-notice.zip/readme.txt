=== Responsive EU Cookie Notice ===
Contributors: robertpeake, robert.peake
Tags: responsive banner, responsive notice, popup, nag, cookie, eu cookie, cookie law
Requires at least: 2.1
Tested up to: 4.3
Stable tag: 1.0
License: GPL2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple, configurable notice that appears at the top of the page. Easily closed by the user. Javascript-based cookie handling works with caching.

== Description ==

A simple, configurable notice that appears at the top of the page. Easily closed by the user. Javascript-based cookie handling is compatible with Wordpress front-end caching strategies.

== Changelog ==

 * 1.0 Initial Release
