=== Plugin Name ===
Contributors: NerdNextDoor
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZZJD8LKR2UAE8
Tags: Gravatar
Requires at least: 3.0.0.1
Tested up to: 3.4.2
Stable tag: 2.0

Allows you to add your own custom default avatar

== Description ==

Allows you to add your own custom default avatar


== Installation ==

This section describes how to install the plugin and get it working.

1. Activate the plugin through the 'Plugins' menu in WordPress
2. Enter the URL to the image you want to use for your custom Gravatar under the settings.
3. Go to 'Discussion' and select 'Custom Gravatar'

== Frequently Asked Questions ==

= What if I want it to do something else? =

Contact me at CodeMonkey@BostonSuperBlog.com and I'll do my best to get it working

== Screenshots ==

1. A Custom Gravatar!!! WOWEE!

== Changelog ==

= 1.0 =
First go at this...

= 2.0 =
Added the settings screen which allows you to input a URL for your Custom Gravatar

== Upgrade Notice ==

= 1.0 =
Only version out there!

= 2.0 =
Added the settings screen which allows you to input a URL for your Custom Gravatar