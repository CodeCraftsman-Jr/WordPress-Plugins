<?php
include_once( dirname(__FILE__) . '/hc_lib.php' );
include_once( dirname(__FILE__) . '/hc_renderer.php' );
include_once( dirname(__FILE__) . '/hc_main_menu.php' );
include_once( dirname(__FILE__) . '/hc_html.php' );
