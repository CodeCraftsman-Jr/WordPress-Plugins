<?php
require( dirname(__FILE__) . '/index_action.php' );
require( dirname(__FILE__) . '/index_view.php' );
?>