<?php
class MY_Controller extends MY_BaseController 
{
}