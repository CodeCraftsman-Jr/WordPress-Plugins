<?php
$is_module = TRUE;
require( dirname(__FILE__) . '/main.php' );
?>