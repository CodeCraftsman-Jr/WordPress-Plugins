<div class="page-header">
<h2><small><?php echo lang('common_actions'); ?></small></h2>
</div>
<?php $this->load->view( $include_submenu ); ?>