<ul class="nav nav-list">
<li><?php echo ci_anchor( 'auth/password', '<i class="fa fa-lock"></i>' . ' ' . lang('common_change_password') ); ?></li>
</ul>