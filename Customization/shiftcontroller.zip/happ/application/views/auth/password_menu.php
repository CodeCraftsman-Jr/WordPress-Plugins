<ul class="nav nav-list">
<li><?php echo ci_anchor( 'auth/profile', '<i class="fa fa-user"></i>' . ' ' . lang('auth_profile') ); ?></li>
</ul>