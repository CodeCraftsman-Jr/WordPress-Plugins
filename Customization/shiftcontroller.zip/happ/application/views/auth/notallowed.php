<div class="page-header">
<h2><?php echo lang('common_not_allowed'); ?></h2>
</div>

<p>
<?php echo lang('common_not_allowed'); ?>
