<?php
$hook['post_controller'][] = array(
	'function' => 'hc_run_notifier',
	'filename' => 'hitcode_helper.php',
	'filepath' => 'helpers',
	);
