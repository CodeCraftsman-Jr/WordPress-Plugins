<?php defined('BASEPATH') OR exit('No direct script access allowed');
/* menu example */
$config = array();

/*
$config[User_model::LEVEL_ADMIN]['100m'] = array( 
	lang('customers'),
	'customers/admin',
	10
	);
$config[User_model::LEVEL_ADMIN]['200m'] = array( 
	lang('menu_conf_settings'),	
	array(
		array( lang('menu_conf_settings'),	'conf/admin' ),
		array( lang('menu_conf_settings'),	'conf/admin' ),
		array( lang('menu_conf_settings'),	'conf/admin' ),
		),
	100
	);
*/
/* End of file menu.php */
/* Location: ./application/config/menu.php */