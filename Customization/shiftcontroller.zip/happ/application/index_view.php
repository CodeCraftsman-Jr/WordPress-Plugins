<?php
$CI =& ci_get_instance();
$CI->output->_display();
?>