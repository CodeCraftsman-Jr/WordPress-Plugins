<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['migration_enabled'] = TRUE;
$config['migration_version'] = 1;

/* End of file application/modules/my_module/config/migration.php */