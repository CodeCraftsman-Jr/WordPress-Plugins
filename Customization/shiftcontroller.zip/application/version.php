<?php
define('HC_APP_VERSION', '2.4.1');
