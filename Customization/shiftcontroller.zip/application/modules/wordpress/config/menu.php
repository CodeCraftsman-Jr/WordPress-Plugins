<?php
$config = array();
$config[USER_MODEL::LEVEL_ADMIN . '/conf/wordpress'] = array(
	'title'	=> '<i class="fa fa-cog"></i> ' . 'Shortcode',
	'link'	=> 'wordpress/admin/shortcode',
	);
?>