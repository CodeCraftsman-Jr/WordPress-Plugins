<h2>
<i class="fa fa-coffee"></i> 
<?php echo lang('my_timeoffs'); ?>
</h2>