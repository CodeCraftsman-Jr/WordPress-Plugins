<h2>
<i class="fa fa-calendar"></i> 
<?php echo lang('my_schedule'); ?>
</h2>