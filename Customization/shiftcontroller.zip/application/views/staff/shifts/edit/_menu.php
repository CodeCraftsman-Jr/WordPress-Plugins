<?php
$menu = array(
	'list'	=> ci_anchor( array($this->conf['path']), '<i class="fa fa-list"></i>' . ' ' . lang('my_schedule') ),
	);
?>
<?php require( NTS_SYSTEM_APPPATH . 'views/_boilerplate/_print_menu.php' ); ?>