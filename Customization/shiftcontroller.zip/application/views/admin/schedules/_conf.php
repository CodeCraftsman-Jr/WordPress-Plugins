<?php
$conf = array(
	'header'	=> FALSE,
	);
?>