<h2><?php echo $object->title(TRUE); ?></h2>
