=== WPCS ( Wordpress Custom Search ) ===
Contributors: Tech9logy
Donate link: http://www.tech9logy.com/pay-with-paypal/
Tags: Search, custom, custom search, advanced search, search anything, search taxonomy, taxonomy, custom taxonomy, search custom taxonomy, advanced taxonomy search, taxonomy search, advanced search for taxonomy, advanced search for custom taxonomy, search wp category, category search, search category, tags, tags search, custom tags search, search tags,view count, post count, post view count,top viewed post, most viewed post, widgets, search widgets, post widgets, post count widget, search box widget, custom search widget, customize widget
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

WP Custom Search is a simple and lightweight Plugin that allows you to search anything on your wordpress.

After the WPCS Plugin activation you can instantly install, setup and utilize it to its full extent. It was designed to help developers in every aspect, empowering them subtle control and customization.It allows the users to search posts, custom post type, taxomonies, custom taxonomies, tags and many more..

A Turnkey Solution that changes search into something relevant. 

The domestic WordPress Search overlooks critical website content.The visitors may not understand from where to find what they're seeking for, just from your navigation. As search is the usual next step, so it is important to make your search as productive as your website!

Just install and activate and use a simple shortcode or widget anywhere to replace WordPress native search using your existing results template.

= Key Features =

1. Easy to Install.
2. Search WP Category.
3. Search WP Tags.
4. Search Taxonomies.
5. Search Posts and Pages
6. Search Custom Post Type
7. Search Custom Taxonomies.
8. Easy Search Form styling.
9. Simple Shortcodes.
10. Search Widget.
11. Post Count.
12. Top Viewed Post widget.
13. Widget Customization
14. Easy to operate.
15. No major setting.
16. Easy to Customize.

= Note =

You Can Easily use WP Custom Search Plugin with a simple shortcode. [wpcs_search] or you can use widgets, add it anywhere and enjoy searching..


== Installation ==

This section describes how to install the plugin and get it working. 

E.g.

1. Upload the entire 'wp-custom-search' folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'WP Custom Search' menu in your WordPress admin panel.

== Frequently Asked Questions ==

= Does it give any Widget ? =

Yes, after plugin activation you can find two widgets in widget area.

1. WPCS Search - For search box
2. Most Viewed Posts - This widget gives you top most viewed posts

= Does it work fine with the latest version of wordpress?  =

  It has been tested upto Version 4.2.2

= Can I customize it, as per my need? =

  It is easy to customize but skill is a factor here.

* If you face any issue, you may reach us [here](http://www.tech9logy.com/contact/) or write us at hello@tech9logy.com.

== Screenshots ==

1. Front-end view
2. Search Settings
3. Widget Settings

== Changelog ==

= 1.0 =

* Initial Release

= 1.1 =
* Newly identfied bugs fixed


== Upgrade Notice ==

= 1.0 =
* This is the initial release of the plugin.

= 1.1 =
* Settings isuue fixed 
* Compatible on all browesers
* Plugin menu changed
* Plugin Icon upload
