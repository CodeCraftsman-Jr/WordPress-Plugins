=== Remove Default Widgets ===
Contributors: kovshenin
Tags: widgets, admin
Requires at least: 2.2.0
Tested up to: 3.4
Stable tag: 1.0

Removes the default WordPress widgets. Period.

== Description ==

Seriously, this plugin doesn't do anything else. It just prevents WordPress from registering its default widgets.

== Installation ==

Upload the plugin to your blog, and activate it. Browse to Appearance - Widgets to make sure it's working.

== Changelog ==

= 1.0 =
* Boom!