=== WordPress Remove Old Slugs ===
Contributors: algoritmika
Donate link: http://algoritmika.com/donate/
Tags: remove old slug,remove old slugs,remove old permalink,remove old permalinks,delete old slug,delete old slugs,delete old permalink,delete old permalinks,purge old slug,purge old slugs,purge old permalink,purge old permalinks
Requires at least: 3.5.1
Tested up to: 3.5.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin removes old slugs/permalinks from database.

== Description ==

Plugin removes old slugs/permalinks from database.

To remove old slugs/permalinks go to Tools -> Remove Old Slugs and press Start button.

This plugin was tested with Wordpress 3.5.1.

= Feedback =
* We are open to your suggestions and feedback - Thank you for using or trying out one of our plugins!
* Drop us a line at [www.algoritmika.com](http://www.algoritmika.com)

= More =
* Vist the [Wordpress Remove Old Slugs plugin page](http://www.algoritmika.com/shop/wordpress-remove-old-slugs-plugin/)

== Installation ==

1. Upload the entire 'wordpress-remove-old-slugs' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. All options will be automatically added to product's edit page.

== Frequently Asked Questions ==

= Is it possible to delete only certain old slugs? =

At this time - no. Only all old slugs can be deleted.

== Screenshots ==

1. Tools -> Remove Old Slugs screenshot.

== Changelog ==

= 1.0.1 =
* Refresh link added
* Minor bug fixed

= 1.0.0 =
* Initial Release

== Upgrade Notice ==

= 1.0.0 =
This version was tested with Wordpress 3.5.1.