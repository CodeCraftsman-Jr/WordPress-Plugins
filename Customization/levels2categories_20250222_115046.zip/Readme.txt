=== Level2Categories ===
Contributors: LeoGermani
Donate link: http://pirex.com.br/wordpress-plugins
Tags: categories, user levels, capabilities, roles, limit, restrict, post
Requires at least: 2.0
Tested up to: 2.1
Stable tag: 0.5

Allows you to create a relationship between User Levels and Categories, so only users with a defined level will be able to post on a chosen category. Its useful if you want to reserve a category only for Editors or Administrators (or whoever you choose) to post on.

== Description ==

Permite que voc� relacione N�veis de Usu�rios a Categorias, fazendo com que somente usu�rios com um n�vel m�nimo possam publicar posts em determinada categoria. � �til para quem quer reservar uma categoria onde somente Editores ou Administradores (ou qualquer um que voc� escolher) poderem publicar.

Allows you to create a relationship between User Levels and Categories, so only users with a defined level will be able to post on a chosen category. Its useful if you want to reserve a category only for Editors or Administrators (or whoever you choose) to post on.

== Installation ==

. Fa�a o download do arquivo
. Descompacte � conte�do do pacote no diret�rio "plugins" do seu wordpress
. Acesse o Painel de Administra��o > Plugins e ative o plugin

. Download the package
. Extract it to the "plugins" folder of your wordpress
. In the Admin Panes go to "Plugins" and activate it

Modo de usar / Usage

. Go to Manage > Level2Categories
. Select the Category and choose the minimum level a user must have to post on this category

. Acesse Manage > Level2Categories
. Selecione a Categoria e o N�vel M�nimo que um usu�rio deve ter para postar naquela categoria
	
