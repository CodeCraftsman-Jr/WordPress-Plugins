<?php
/**
 * PW
 *
 * A global class to define variables 
 *
 * @package PW_Framework
 * @since 0.1
 */

class PW
{

}