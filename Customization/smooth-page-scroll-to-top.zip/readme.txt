=== Smooth Page Scroll to Top ===
Contributors: DarkWolf
Donate link: http://www.darkwolf.it/donate-wp
Tags: smooth, page, scroll, top, jquery, gazpo, darkwolf
Requires at least: 3.0
Tested up to: 3.6.1
Stable tag: 0.3

With this plugin you can simply have a Smooth Page Scroll "to Top" in your blog :)

== Description ==

Maked by Salvatore Noschese (DarkWolf): http://www.darkwolf.it/

Original script by: http://gazpo.com/2012/02/scrolltop/

With this plugin you can simply have a Smooth Page Scroll "to Top" in your blog :)

No settings, no edit! Simply install and active ;)

You can see in action here: http://vegamami.altervista.org/ :)

= Links =

Author and demo:

* Author Homepage: [DarkWolf](http://www.darkwolf.it/)
* Plugin maked for: [VegAmami](http://vegamami.altervista.org/)
* Script and css by: [Gazpo](http://gazpo.com/2012/02/scrolltop/)

== Screenshots ==

1. With low resolution
2. With big resolution (it maintain absolute position)!

== Installation ==

1. Upload `smooth-page-scroll-to-top` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Upgrade Notice ==

New release available!

== Changelog ==

= 0.3 =
* No more in mobile browser (thanks to detectmobilebrowsers.com script)!

= 0.2 =
* Some little changes! Nothing to important!

= 0.1 =
* First release