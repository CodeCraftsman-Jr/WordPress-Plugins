=== WPB Circliful ===
Contributors: wpbean
Donate link: 
Tags: Circliful, data,show percent
Requires at least: 3.3
Tested up to: 3.9
Stable tag: 1.01
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will add a responsive Circliful. Very easy to use, just put a shortcode. 

== Description ==

### WPB Circliful by http://wpbean.com

This plugin will add a responsive Circliful.

Plugin Features

* Shortcode System
* Wordpress Custom Post Enabled. 
* Wordpress Custom Metaboxes.
* Fully Responsive.  
* Very Lightweight.
& many More


== Installation ==

* Install it as a regular WordPress plugin

* You have to use a shortcode to make the circliful. After activating the plugin you have to put a shortcode where you want to see this Circliful.

* The plugin supports a custom post & custom metaboxes. After installing it you can see the menu called Circliful. From there, you can add Circliful Item. Make sure you are following the metabox help texs. After adding Circliful items you can use shortcode `[wpb-circliful]`



== Frequently asked questions ==


= How can I change Circliful settings like color width dimension  etc? =
I have created some metaboxes for this plugin. When you add a new Circliful item you can different value for different Circliful.

= I added two Circliful in my page/post. But, one is working on other one is not. What is my fault? =
Currently, there is no multi Circliful function is added. You must use one Circliful in a page. 

= Can I use more than three Circliful? =
Currently not. We will add this feature in next version. 

== Screenshots ==
1. WPB Circliful in a post
2. WPB Circliful in admin panel


== Changelog ==

= 1.0 =
* Initial release



== Upgrade notice ==
