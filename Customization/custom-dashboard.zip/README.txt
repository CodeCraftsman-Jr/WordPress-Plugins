=== Custom Dashboard ===
Contributors: dipto99
Donate link: http://freelancertestbd.blogspot.com
Tags: dashboard, custom-dashboard, style, wordpress-custom-dashboard
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Make your wordpress dashboard more style and customize by use this plug-in.

== Description ==

Custom Dashboard plugin make your wordpress default style totally change and you see a nice dashboard interface.  


Features of this plugin:

*  Wordpress new dashboard color interface.
*  Left Menu and Top Menu color change and make a good menu bar.
*  Submit Button color change
*  Add Font Awesome icon in menu bar.

= What Next version = 

* Unlimited Color change options
* More change on dashboard

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `custom-dashboard` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. Custom Dashboard Screenshort.

== Changelog ==

= 1.0 =

* Make it 12 February, 2015


Here's a link to [WordPress](http://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`