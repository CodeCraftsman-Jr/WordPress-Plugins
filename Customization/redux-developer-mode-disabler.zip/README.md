redux-developer-mode-disabler
=====================

A simple plugin to help the users of developers who ship a Redux based product with developer mode on. This plugin globally disables developer mode for all Redux instances.

If you are a user seeing all the upgrade notices, we are sorry. Tell your developer to fix their code and disable `dev_mode`. Until then, you can use this plugin.