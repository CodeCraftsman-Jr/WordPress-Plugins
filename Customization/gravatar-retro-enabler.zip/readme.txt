=== Plugin Name ===
Contributors: apokalyptik
Tags: gravatar
Requires at least: 2.5
Tested up to: 3.1
Stable: trunk

Enabled the retro option for your gravatar default setting
