=== Custom CSS classes for images ===
Contributors: nivijah
Tags: media, images, classes, add class, add classes, media uploader class, featured image class, editor class, nivijah, additional class for images
Requires at least: 3.0.1
Tested up to: 4.2
Stable tag: 1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This simple plugin adds two additional fields to the media window, that lets you set additional classes to images on top of the default ones.

== Description ==

This simple plugin adds two additional fields to the media window, that lets you set additional classes to images on top of the default ones.

After installation two fields will be added to the media window under an image, One for custom class for featured image, and the other for images who are added into the WordPress editor.

Multiple class should be seperated by "space". 

== Installation ==


1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. start editing images

