;(function ($) {
 	// Manual
	WPCP_Create_Auto_Status = {
		init: function (e) {

		},

		overlay: function (e) {
		},

	} 
})(jQuery);