<div class="trigger-warning-deluxe post-warning" title="<?php esc_attr_e( $warninglabel ) ?>">
	<span class="warning"><?php esc_html_e( $warning ) ?></span>
</div>
<?php echo $content ?>