<div class="trigger-warning-deluxe inline-warning" title="<?php esc_attr_e( $title ) ?>">
	<small class="warning"><?php esc_html_e( $warning ) ?></small>
	<div class="veiled-content"><?php echo $content ?></div>
</div>