<?php
/*
 * Template Name: Register
 */
do_action('sb_login_page_init');
get_header();
include SB_LOGIN_PAGE_INC_PATH . '/content/content-page-register.php';
get_footer();