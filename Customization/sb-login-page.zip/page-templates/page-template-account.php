<?php
/*
 * Template Name: Account
 */
do_action('sb_login_page_init');
get_header();
include SB_LOGIN_PAGE_INC_PATH . '/content/content-page-account.php';
get_footer();