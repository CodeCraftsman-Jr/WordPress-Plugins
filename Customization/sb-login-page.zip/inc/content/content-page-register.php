<div class="sb-login-page-box sb-accounts">
    <div class="sb-wrap container">
        <div class="sb-login-page-container">
            <?php include SB_LOGIN_PAGE_INC_PATH . '/module/module-register.php'; ?>
        </div>
    </div>
</div>