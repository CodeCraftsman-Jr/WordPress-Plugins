<?php
define('SB_LOGIN_PAGE_ACCOUNT_TEMPLATE', 'page-template-account.php');

define('SB_LOGIN_PAGE_LOGIN_TEMPLATE', 'page-template-login.php');

define('SB_LOGIN_PAGE_LOST_PASSWORD_TEMPLATE', 'page-template-lost-password.php');

define('SB_LOGIN_PAGE_REGISTER_TEMPLATE', 'page-template-register.php');