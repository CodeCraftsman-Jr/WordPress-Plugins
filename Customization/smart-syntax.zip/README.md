Smart Syntax For Jetpack Markdown & Fenced Code Blocks
=================================

Automatic google prettify syntax highlighting for jetpack markdown fenced code blocks

## Description ##

[Smart Syntax](http://www.smartpixels.net/?post_type=products&p=190) plugin automatically adds Google prettify syntax highlighting to the fenced code blocks.

It's made with [Jetpack](http://jetpack.me/) markdown in mind, which brings the power of markdown extra to WordPress and gives you an easy to use markdown syntax for fenced code blocks.

For more information on usage and features, check out [smartpixels](http://www.smartpixels.net/?post_type=products&p=190).
