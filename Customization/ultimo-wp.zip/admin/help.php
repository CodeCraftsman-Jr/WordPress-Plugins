<?php
/*
// Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
$this->args['help_tabs'][] = array(
'id' => 'redux-opts-1',
'title' => __('Theme Information 1', 'redux-framework-demo'),
'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo')
);

$this->args['help_tabs'][] = array(
'id' => 'redux-opts-2',
'title' => __('Theme Information 2', 'redux-framework-demo'),
'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo')
);

// Set the help sidebar
$this->args['help_sidebar'] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'redux-framework-demo');*/