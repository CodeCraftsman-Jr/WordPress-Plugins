=== Ultimo WP ===
Contributors: aanduque
Donate link: http://weare732.com/demos
Tags: admin theme, admin interface, admin ui, admin, theme, customize admin, custom admin, dashboard theme, dashboard
Requires at least: 3.8
Tested up to: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Get a clean, beautiful and customizable new look on your WordPress Admin Dasboard.

== Description ==

Are you already tired of the way WordPress 3.8 looks? 

Did you wish to be able to change and personalize, and even whitelabel some of the WordPress signatures on the WP Dashboard?

*Well, you can do all of that with Ultimo WP!*

With Utimo WP Dashboard Theme you can:

1. Personalize the entire look and feel of the WordPress dashboard, based on *8 beautifully designed presets* (and counting).
1. *Personalize the login screen* of the WordPress dashboard.
1. Whitelable some of the WordPress signatures, like the footer texts and adding your company logo to the dashboard and login page.

[Check out my premium plugins!](http://codecanyon.net/user/732/portfolio?ref=732)

== Installation ==

1. Upload `ultimo-wp.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. The new style of your dashboard.
2. Personalize your login page.
3. 8 Presets.

== Changelog ==

= 0.1 =
Initial release