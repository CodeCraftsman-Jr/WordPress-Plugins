=== Click skin - Website enhancements and an alternative to banner ads ===
Contributors: reaveyo
Donate link: http://www.clickskins.com/
Tags: clickskin, Ads, alternative,  enhancements, Website
Requires at least: 3.0.0
Tested up to: 4.1.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Website enhancements and an alternative to banner ads.

== Description ==

[Click skin](http://www.clickskins.com/) - Website enhancements and an alternative to banner ads. 



> **Premium Version:**<br>
> This plugin has a premium version, with live link enable and many other features. Get the affordable Premium Version from [clickskins.com/](http://www.clickskins.com/)

== Installation ==

This section describes how to install the plugin and get it working.

= 1) Install =

= Modern Way: =
1. Go to the WordPress Dashboard "Add New Plugin" section.
2. Search For "clickskin". 
3. Install, then Activate it.

= Old Way: =
1. Unzip (if it is zipped) and Upload `clickskin` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Create New ad section.


== Changelog ==

= 1.0.0 - 2015-3-11 =
* Initial Release.

= 1.0.1 - 2015-4-14 =

* Make ads responsive 
* Show specific ads on specific post/page

== Donation ==

You may buy the premium version to support the development.

hhttp://clickskins.com/