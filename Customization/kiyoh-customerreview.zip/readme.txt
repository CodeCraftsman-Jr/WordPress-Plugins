Requires at least: 3.6.0
Tested up to: 4.2.2
Stable tag: kiyoh, review, customerreview, rate, send mail

The Interactivated.me developed plugin for the Kiyoh reviews network, you can easily integrate Kiyoh into your Wordpress.

== Description ==
The Interactivated.me developed plugin for the Kiyoh reviews network, you can easily integrate Kiyoh into your Wordpress. Customers will automatically receive a review invitation email to write a responce about your store. The Kiyoh customerreview plugin knows numerous benefits in compare to other Review modules by also linking independant reviews to individual products in Wordpress and offering microdata integration with the review stars to show them in the search results in search engines such as Google. The newest release now works with both KIyoh International (.com) and Kiyoh Netherlands (.nl) networks from one interfase. Multistores can work with both networks at different stores in one admin.

== Installation ==
1. Upload or extract the kiyoh_customerreview folder to your site\'s /wp-content/plugins/ directory. You can also use the Add new option found in the Plugins menu in WordPress.
2. Enable the plugin from the Plugins menu in WordPress.
3. Install & enable WooCommerce plugin from the Plugins menu in WordPress.
4. You should install and enable Group plugin (https://wordpress.org/plugins/groups) if you want groups to use "Exclude customer groups"

== Screenshots ==
1. Settings
2. setting widget 
3. widget